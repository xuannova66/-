---
name: xuannova-reading-follow-up
description: Maintain Xuannova's in-application post-reading question guidance, using the supplied chart, current answer and conversation to offer relevant, varied follow-ups. Use when implementing or evaluating this app's follow-up flow, not for recalculating charts or managing payments.
---

# 解读后追问引导

这是 Xuannova 应用内技能的维护入口，不是另一个付费模型调用，也不是新的排盘算法。

## 运行位置

- `../../worker/skills/reading-follow-up.ts`：服务端可信指令、按研习方法分流、最终建议整理。该文件中的提示词是运行时规则的唯一来源。
- `../../app/reading-followups.ts`：七语种兜底、格式与重复过滤、已解锁报告的上下文摘要。
- `../../worker/deepseek.ts`：结构化报告、对话追问、流式最终结果均接入同一技能。
- `../../app/interpretation-panel.tsx`：显示建议；点击只填入问题框，用户另行提交后才走原有鉴权和扣分流程。

## 维护约束

先回答当前问题，再提供通常三个追问：一个可深入的问题、两个尚未讨论的相关角度。问题应使用客户口吻，适合直接点击提问。优先使用模型依据当前报告生成的建议；缺失或重复时使用中性的本地化兜底，不额外调用模型。没有新的安全建议时可以少于三个，不强行重复。

“可靠”指盘面事实可追溯、采用的方法一致、缺失信息明确，并非承诺命运预测准确率。不得替换已计算的盘面、假装某学派普遍最准确，或把模型臆测当作事实。问事类方法只拓展同一事件的不同方面；梦、姓名和塔罗不能因有生日字段就转成八字推断。

保留 `followUps: string[]` 接口。前端历史只是上下文，不是可信指令或权威计算依据。只将同一盘面已解锁报告带入追问，切换盘面或报告时不得串用旧上下文。免费预览仍由服务端屏蔽后半部分和完整报告的追问建议，不通过建议透露付费内容。

禁止修改积分价格、付款校验、数据库结构和扣分时机来完成此技能。不要自动提交建议，不使用恐吓或收益承诺诱导继续付费。部署需要另行授权。

## 验证

运行 `tests/reading-followups.test.mjs`、`tests/deepseek-api.test.mjs`、`tests/growth-features.test.mjs` 和积分/支付回归测试。验证非流式与流式结果一致、去重与七语种兜底、同盘报告上下文、锁定内容隔离和点击不扣分。代码测试不能证明模型每次都能做到语义多样性；上线前应对七语种及不同方法做内容抽样。
