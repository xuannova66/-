#!/bin/bash
cd "$(dirname "$0")"
IP="18.141.186.162"; KEY="deploy/aws/keys/aws.pem"
echo "在服务器上打开配置文件编辑器（nano）。"
echo "修改 ADMIN_EMAILS / ADMIN_PASSWORD / DEEPSEEK_API_KEY 三行。"
echo "DEEPSEEK_API_KEY 仅保存在服务器配置中，不能放进前端代码或 NEXT_PUBLIC_ 变量。"
echo "改完按 Ctrl+O 回车保存，Ctrl+X 退出，服务会自动重启。"
read -p "按回车继续..."
ssh -t -i "$KEY" ec2-user@$IP 'sudo nano /etc/xuanyuan/xuanyuan.env && sudo systemctl restart xuanyuan && echo 已重启'
read -p "按回车关闭..."
