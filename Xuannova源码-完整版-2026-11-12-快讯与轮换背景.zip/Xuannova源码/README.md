# Xuannova — local edition

`Xuannova` is a multilingual, browser-only study experience for Eastern cosmology and symbolic reflection. It is an independent local build: it keeps the supplied Xuanyuan brand, original copy and local artwork, and does not include Qingnang source code, artwork, private data or paid content.

## Run locally

Requires Node.js 22.13 or later.

```bash
pnpm install
pnpm dev -- --port 3001
```

Then open `http://localhost:3001/`.

## Included local flows

- 7 languages: English, Simplified Chinese, Traditional Chinese, Japanese, Korean, Vietnamese and Thai.
- 3 visual themes: Aureate, Paper and Nocturne.
- 11 study routes: synthesis, BaZi, deep BaZi, compatibility, Zi Wei, celestial chart, Liuyao, Qi Men, Da Liu Ren, inquiry synthesis and mirror reflection.
- Birth-profile forms with solar, lunar and manual Four Pillars input; year/month/day/time, place, orientation and a true-solar-time disclosure.
- Compatibility with independently configurable second profile data.
- Inquiry forms for Qi Men, Da Liu Ren and Liuyao. Liuyao includes automatic, manual coin-line and direct Yin/Yang-line input.
- 7-tool study toolkit, daily rhythm, original knowledge library and local-only recent-study list.
- Local solar/lunar conversion, Four Pillars, zodiac, NaYin, Five Elements counts and day-reference data through `lunar-javascript`.

## Wallet sign-in and USDT checkout (BSC)

Members sign in either with email + password (unchanged) or with a browser wallet (MetaMask, TokenPocket, Binance Web3 Wallet, OKX Wallet); an email account can link a wallet later. Credits can be bought on-chain in USDT (BEP20) through the `XuanyuanCreditStore` contract on BNB Smart Chain, or via the original manual USDT transfer (TRC20 / BSC hash reviewed by an administrator). Every purchase carries a flat **0.00007 BNB** platform fee forwarded in the same transaction to the fee wallet. Credits are issued automatically once the worker verifies the `Purchased` event on chain — no manual review.

Flow: `eth_requestAccounts` → `/api/auth/wallet/nonce` → wallet signs the message (EIP-191) → `/api/auth/wallet/verify` → package `approve` (USDT) + `buy(packageId)` with `0.00007 BNB` → `/api/orders` with the tx hash → worker reads the receipt (3 confirmations), checks buyer / package / amount / fee, and credits the account.

### 1. Deploy the contract

`contracts/XuanyuanCreditStore.sol` (Solidity ^0.8.24; ABI in `contracts/XuanyuanCreditStore.abi.json`). Deploy on BSC mainnet (chainId 56) with Remix, Foundry or Hardhat using:

| constructor arg | value |
| --- | --- |
| `usdtToken` | `0x55d398326f99059fF775485246999027B3197955` (USDT BEP20) |
| `treasuryWallet` | your USDT receiving wallet (e.g. `0x9E946751c432E4FCd05C463956122793ab64202e`) |
| `feeWallet` | `0xf749AcaB0be460667Bd15922b48c821E4Fb3c13d` (BNB fee wallet) |
| `initialFeeWei` | `70000000000000` (0.00007 BNB) |

Packages (`seed` 4.99 U/20, `path` 9.90 U/50, `ritual` 19.90 U/120, `synthesis` 39.90 U/280) are seeded in the constructor and must stay in sync with `worker/commerce-policy.ts`. Owner functions: `setPackage`, `setTreasury`, `setFeeRecipient`, `setFee`, `setPaused`, `sweep`, `transferOwnership`.

### 2. Configure the worker

Set these environment variables (Cloudflare / hosting secrets):

- `CREDIT_STORE_ADDRESS` — the deployed contract address (or fill `creditStoreAddress` in `worker/commerce-policy.ts`). Checkout stays disabled until this is set.
- `BSC_RPC_URLS` — optional, comma-separated HTTPS JSON-RPC endpoints; defaults to public BSC dataseeds.
- `SESSION_SECRET`, `ADMIN_EMAILS`, `ADMIN_PASSWORD`, `DEEPSEEK_API_KEY` as before.

### 3. Apply the database migration

`migrations/0003_wallet_accounts.sql` (mirrored as `drizzle/0001_wallet_accounts.sql`) makes `members.email` nullable, adds `wallet_address`, extends `payment_orders` with on-chain fields and adds `wallet_nonces`. Existing email accounts keep working unchanged.

After pulling, run `pnpm install` once — `viem` was added as a dependency and `pnpm-lock.yaml` needs refreshing.

## Deploy on AWS EC2 (self-hosted Node + SQLite)

The same code also runs as a plain Node server: `DEPLOY_TARGET=node` builds without the Cloudflare plugin, `app/api/[...path]/route.ts` serves the API, and `server/sqlite-db.ts` replaces D1 with a local SQLite file (`node:sqlite`, Node ≥ 22.13). Everything needed is in `deploy/aws/`.

### 1. Launch the instance

| setting | value |
| --- | --- |
| AMI | Ubuntu Server 24.04 LTS (64-bit x86 or Arm) |
| type | `t3.small` / `t4g.small` (2 GB RAM — the build needs it) |
| storage | 20 GB gp3 |
| security group | inbound TCP 22 (your IP only), 80, 443 (anywhere) |
| key pair | create/download a `.pem` for SSH |

Point your domain's A record at the instance's public IP (allocate an Elastic IP first so it never changes). No domain yet? Use `<ip-with-dashes>.sslip.io`, e.g. `3-1-2-3.sslip.io` — Caddy can still issue a certificate for it.

### 2. Provision

```bash
# from your computer
rsync -av --exclude node_modules --exclude dist --exclude data --exclude .env --exclude "deploy/aws/keys" -e "ssh -i deploy/aws/keys/aws.pem" ./ ubuntu@<ip>:/home/ubuntu/xuanyuan/
ssh -i key.pem ubuntu@<ip>
sudo bash /home/ubuntu/xuanyuan/deploy/aws/setup.sh study.example.com
```

`setup.sh` installs Node 22 + pnpm + Caddy, creates the `xuanyuan` service user, copies the code to `/opt/xuanyuan`, generates `/etc/xuanyuan/xuanyuan.env` with a random `SESSION_SECRET`, builds, applies `migrations/*.sql` to `/var/lib/xuanyuan/xuanyuan.sqlite`, and starts the `xuanyuan` systemd service behind Caddy with automatic HTTPS. (Pass a Git URL as the second argument to clone instead of rsync.)

### 3. Configure secrets

```bash
sudo nano /etc/xuanyuan/xuanyuan.env   # CREDIT_STORE_ADDRESS, ADMIN_EMAILS, ADMIN_PASSWORD, DEEPSEEK_API_KEY
sudo systemctl restart xuanyuan
```

For AI readings, set a valid DeepSeek key in the same file and keep it on the
server only — never put it in `NEXT_PUBLIC_*` variables or browser code:

```dotenv
DEEPSEEK_API_KEY=sk-your-key-here
# Optional. This is also the default when omitted.
DEEPSEEK_MODEL=deepseek-chat
```

After saving, restart the service and sign in with a member account that has
at least 20 credits. A reading calls the AI first; credits are deducted and a
ledger entry is committed together only after a successful response. Failed,
invalid, or unauthenticated requests do not consume credits.

### 4. Operate

- Update code: `rsync` again (or `git pull`) then `sudo xuanyuan-deploy` — builds, migrates, restarts.
- Logs: `journalctl -u xuanyuan -f` · Caddy: `journalctl -u caddy -f`.
- Backups: `xuanyuan-backup.timer` snapshots the database nightly to `/var/backups/xuanyuan` (14 days kept). Set `BACKUP_S3_URI=s3://bucket/prefix` in the env file and attach an instance role with S3 write access to copy off-box.
- Local run of the same mode: `pnpm run build:node && pnpm run db:migrate && pnpm run start:node`.

## Important scope

This is a cultural-learning and reflection tool, not fate prediction, medical advice, supernatural intervention or a guarantee of outcomes. The local edition uses transparent local calculations where included. Exact parity with a separate commercial product's undisclosed rules would require written authorisation plus that product's source or algorithm specification.

## Verify

```bash
pnpm run lint
pnpm test
```

`pnpm test` builds the app and executes the rendered HTML test.
