-- LOCAL DRAFT ONLY: not applied or connected to authentication.
CREATE TABLE wallet_link_challenges_draft (
  nonce TEXT PRIMARY KEY NOT NULL CHECK(length(nonce)=64 AND nonce NOT GLOB '*[^0-9a-f]*'),
  member_id TEXT NOT NULL REFERENCES members(id),
  chain TEXT NOT NULL CHECK(chain IN ('solana','tron')),
  address TEXT NOT NULL CHECK(length(address)>0),
  origin TEXT NOT NULL CHECK(length(origin)>0),
  issued_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL CHECK(expires_at > issued_at AND expires_at - issued_at <= 300),
  consumed_at INTEGER CHECK(consumed_at IS NULL OR (consumed_at >= issued_at AND consumed_at < expires_at))
);
CREATE TABLE member_wallet_links_draft (
  chain TEXT NOT NULL CHECK(chain IN ('solana','tron')),
  address TEXT NOT NULL CHECK(length(address)>0),
  member_id TEXT NOT NULL REFERENCES members(id),
  linked_at INTEGER NOT NULL,
  PRIMARY KEY (chain, address)
);
