-- LOCAL DRAFT ONLY. Not a migration, not wired to API, not for real funds.
-- Application must validate a trusted, final on-chain proof against immutable
-- server-created order details BEFORE transitioning an order to credited.
CREATE TABLE multichain_orders_draft (
  id TEXT PRIMARY KEY NOT NULL,
  member_id TEXT NOT NULL REFERENCES members(id),
  chain TEXT NOT NULL CHECK (chain IN ('bsc', 'ethereum', 'solana', 'tron')),
  package_id TEXT NOT NULL CHECK (package_id IN ('seed', 'path', 'ritual', 'synthesis')),
  credits INTEGER NOT NULL CHECK (credits = CASE package_id WHEN 'seed' THEN 20 WHEN 'path' THEN 50 WHEN 'ritual' THEN 120 WHEN 'synthesis' THEN 280 END),
  buyer TEXT NOT NULL CHECK (length(buyer) > 0),
  recipient TEXT NOT NULL CHECK (length(recipient) > 0),
  settlement_asset TEXT NOT NULL CHECK (length(settlement_asset) > 0),
  amount_units TEXT NOT NULL CHECK (length(amount_units) > 0 AND amount_units NOT GLOB '*[^0-9]*' AND amount_units NOT LIKE '0%'),
  order_reference TEXT NOT NULL UNIQUE CHECK (length(order_reference) = 64 AND order_reference NOT GLOB '*[^0-9a-f]*'),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'credited')),
  transaction_id TEXT,
  event_index INTEGER,
  created_at TEXT NOT NULL,
  credited_at TEXT,
  CHECK (amount_units = CASE chain WHEN 'bsc' THEN
      CASE package_id WHEN 'seed' THEN '4990000000000000000' WHEN 'path' THEN '9900000000000000000' WHEN 'ritual' THEN '19900000000000000000' WHEN 'synthesis' THEN '39900000000000000000' END
    ELSE CASE package_id WHEN 'seed' THEN '4990000' WHEN 'path' THEN '9900000' WHEN 'ritual' THEN '19900000' WHEN 'synthesis' THEN '39900000' END END),
  CHECK ((status = 'pending' AND transaction_id IS NULL AND event_index IS NULL AND credited_at IS NULL)
      OR (status = 'credited' AND transaction_id IS NOT NULL AND length(transaction_id) > 0 AND typeof(event_index) = 'integer' AND event_index >= 0 AND credited_at IS NOT NULL)),
  CHECK (transaction_id IS NULL OR chain = 'solana' OR (length(transaction_id) = 64 AND transaction_id NOT GLOB '*[^0-9a-f]*'))
);
CREATE UNIQUE INDEX multichain_draft_settlement_once ON multichain_orders_draft(chain, transaction_id, event_index) WHERE transaction_id IS NOT NULL;
-- Existing manual TRC20 orders may identify the same transfer without an event
-- index. Conservatively reserve the whole transaction across the old and new
-- ledgers, regardless of review status; resolve collisions manually.
CREATE TRIGGER multichain_draft_block_legacy_tron BEFORE UPDATE OF status ON multichain_orders_draft
WHEN NEW.chain='tron' AND NEW.status='credited' AND EXISTS (
  SELECT 1 FROM payment_orders p WHERE p.network='trc20'
  AND replace(lower(p.transaction_hash), '0x', '')=NEW.transaction_id
)
BEGIN SELECT RAISE(ABORT, 'transaction reserved by legacy order'); END;
CREATE TRIGGER multichain_draft_block_new_legacy_tron BEFORE INSERT ON payment_orders
WHEN NEW.network='trc20' AND EXISTS (
  SELECT 1 FROM multichain_orders_draft m WHERE m.chain='tron' AND m.status='credited'
  AND m.transaction_id=replace(lower(NEW.transaction_hash), '0x', '')
)
BEGIN SELECT RAISE(ABORT, 'transaction reserved by multichain order'); END;
CREATE TRIGGER multichain_draft_block_legacy_tron_update BEFORE UPDATE OF network,transaction_hash ON payment_orders
WHEN NEW.network='trc20' AND EXISTS (
  SELECT 1 FROM multichain_orders_draft m WHERE m.chain='tron' AND m.status='credited'
  AND m.transaction_id=replace(lower(NEW.transaction_hash), '0x', '')
)
BEGIN SELECT RAISE(ABORT, 'transaction reserved by multichain order'); END;
CREATE TRIGGER multichain_draft_pending_only BEFORE INSERT ON multichain_orders_draft WHEN NEW.status <> 'pending'
BEGIN SELECT RAISE(ABORT, 'order must start pending'); END;
-- Enforce the same per-member pending limit atomically at insertion time;
-- an API pre-check alone can be bypassed by concurrent requests.
CREATE TRIGGER multichain_draft_pending_limit BEFORE INSERT ON multichain_orders_draft
WHEN (SELECT count(*) FROM multichain_orders_draft WHERE member_id=NEW.member_id AND status='pending') >= 20
BEGIN SELECT RAISE(ABORT, 'too many pending orders'); END;
CREATE TRIGGER multichain_draft_order_immutable BEFORE UPDATE ON multichain_orders_draft
WHEN OLD.id <> NEW.id OR OLD.member_id <> NEW.member_id OR OLD.chain <> NEW.chain OR OLD.package_id <> NEW.package_id OR OLD.credits <> NEW.credits OR OLD.buyer <> NEW.buyer OR OLD.recipient <> NEW.recipient OR OLD.settlement_asset <> NEW.settlement_asset OR OLD.amount_units <> NEW.amount_units OR OLD.order_reference <> NEW.order_reference OR OLD.created_at <> NEW.created_at OR OLD.status = 'credited'
BEGIN SELECT RAISE(ABORT, 'order is immutable'); END;
CREATE TRIGGER multichain_draft_credit_once AFTER UPDATE OF status ON multichain_orders_draft
WHEN OLD.status = 'pending' AND NEW.status = 'credited'
BEGIN
  UPDATE members SET credits = credits + NEW.credits, updated_at = NEW.credited_at WHERE id = NEW.member_id;
  SELECT CASE WHEN changes() <> 1 THEN RAISE(ABORT, 'credit member missing') END;
  INSERT INTO credit_ledger(id,member_id,order_id,delta,balance_after,reason,created_at)
  SELECT 'multichain-draft:' || NEW.id, NEW.member_id, NULL, NEW.credits, credits + daily_credits, 'payment_approval', NEW.credited_at FROM members WHERE id = NEW.member_id;
  SELECT CASE WHEN changes() <> 1 THEN RAISE(ABORT, 'credit ledger missing') END;
END;

-- A submitted hash is merely a candidate, never proof of payment. Retain it
-- separately until a trusted chain verifier credits the immutable order.
CREATE TABLE multichain_payment_attempts_draft (
  order_id TEXT NOT NULL REFERENCES multichain_orders_draft(id),
  transaction_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  last_checked_at TEXT,
  check_count INTEGER NOT NULL DEFAULT 0 CHECK(check_count>=0),
  PRIMARY KEY(order_id, transaction_id)
);
CREATE INDEX multichain_attempts_draft_retry ON multichain_payment_attempts_draft(last_checked_at, created_at);
CREATE TABLE ethereum_event_cursor_draft (
  checkout TEXT PRIMARY KEY NOT NULL,
  next_block TEXT NOT NULL CHECK(length(next_block)>0 AND next_block NOT GLOB '*[^0-9]*')
);
