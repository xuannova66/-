import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync,readdirSync} from "node:fs";
import {openDatabase} from "../server/sqlite-db.ts";
import {handleCommerceApi,createSessionToken} from "../worker/commerce-api.ts";

test("draft order creation is feature gated, authenticated, wallet-bound and server-priced",async()=>{
 const db=openDatabase(":memory:");try{
  const dir=new URL("../migrations/",import.meta.url);for(const f of readdirSync(dir).filter(x=>x.endsWith(".sql")).sort())db.raw.exec(readFileSync(new URL(f,dir),"utf8"));
  db.raw.exec(readFileSync(new URL("../db/drafts/multichain-orders.sql",import.meta.url),"utf8"));
  const now="2026-01-01T00:00:00Z",buyer="TNUC9Qb1rRpS5CbWLmNMxXBjyFoydXjWFR";
  db.raw.prepare("INSERT INTO members(id,credits,role,created_at,updated_at) VALUES(?,?,?,?,?)").run("one",0,"member",now,now);
  db.raw.prepare("INSERT INTO members(id,credits,role,created_at,updated_at) VALUES(?,?,?,?,?)").run("two",0,"member",now,now);
  const secret="test-secret-that-is-longer-than-thirty-two-bytes",base={DB:db,SESSION_SECRET:secret,SITE_URL:"https://xuannova.test"},enabled={...base,MULTICHAIN_DRAFT_ORDERS_ENABLED:"true"};
  const session=await createSessionToken({sub:"one",role:"member",email:"one@example.test"},secret);
  const other=await createSessionToken({sub:"two",role:"member",email:"two@example.test"},secret);
  const request=(cookie,origin="https://xuannova.test",payload={chain:"tron",buyer,packageId:"seed",amountUnits:"1",recipient:"attacker"})=>new Request("https://xuannova.test/api/draft/multichain-orders",{method:"POST",headers:{"content-type":"application/json",...(origin?{origin}:{}),...(cookie?{cookie:`xuanyuan_session=${cookie}`}:{})},body:JSON.stringify(payload)});
  assert.equal((await handleCommerceApi(request(session),base)).status,503);
  assert.equal((await handleCommerceApi(request(null),enabled)).status,401);
  assert.equal((await handleCommerceApi(request(session,"https://evil.test"),enabled)).status,403);
  assert.equal((await handleCommerceApi(request(session),enabled)).status,403);
  db.raw.prepare("INSERT INTO member_wallet_links_v2(chain,address,member_id,linked_at) VALUES(?,?,?,?)").run("tron",buyer,"one",1);
  const response=await handleCommerceApi(request(session),enabled);assert.equal(response.status,200);
  const order=await response.json();assert.equal(order.amountUnits,"4990000");assert.equal(order.recipient,"TMkFTkWbkjnUpCTiYx87QyTTjXiS2ogGqi");
  const status=(cookie,id=order.id)=>new Request(`https://xuannova.test/api/draft/multichain-orders/status?id=${id}`,{headers:cookie?{cookie:`xuanyuan_session=${cookie}`}:{}});
  assert.equal((await handleCommerceApi(status(session),base)).status,503);
  assert.equal((await handleCommerceApi(status(null),enabled)).status,401);
  assert.equal((await handleCommerceApi(status(other),enabled)).status,404);
  const before=await handleCommerceApi(status(session),enabled);assert.equal(before.headers.get("cache-control"),"no-store");assert.equal((await before.json()).status,"awaiting_payment");
  db.raw.prepare("INSERT INTO multichain_payment_attempts_draft(order_id,transaction_id,created_at) VALUES(?,?,?)").run(order.id,"ab".repeat(32),now);
  assert.equal((await (await handleCommerceApi(status(session),enabled)).json()).status,"submitted");
  db.raw.prepare("UPDATE multichain_orders_draft SET status='credited',transaction_id=?,event_index=0,credited_at=? WHERE id=?").run("ab".repeat(32),now,order.id);
  assert.equal((await (await handleCommerceApi(status(session),enabled)).json()).status,"credited");
  assert.equal(db.raw.prepare("SELECT credits FROM members WHERE id='one'").get().credits,20);
  assert.equal((await handleCommerceApi(request(session,"https://xuannova.test",{chain:"ethereum",buyer:"0x1111111111111111111111111111111111111111",packageId:"seed"}),enabled)).status,503);
  const insert=db.raw.prepare("INSERT INTO multichain_orders_draft(id,member_id,chain,package_id,credits,buyer,recipient,settlement_asset,amount_units,order_reference,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)");
  for(let i=0;i<20;i++)insert.run(`pending-${i}`,"one","tron","seed",20,buyer,"recipient","token","4990000",i.toString(16).padStart(64,"0"),now);
  assert.throws(()=>insert.run("overflow","one","tron","seed",20,buyer,"recipient","token","4990000","f".repeat(64),now),/too many pending orders/);
  assert.equal((await handleCommerceApi(request(session),enabled)).status,429);
 }finally{db.raw.close();}
});
