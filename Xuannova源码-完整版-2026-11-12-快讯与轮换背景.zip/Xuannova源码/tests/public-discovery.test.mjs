import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const publicFile = (name) => new URL(`../public/${name}`, import.meta.url);

test("crawler policy keeps account, admin, and API paths out of every crawler group", async () => {
  const robots = await readFile(publicFile("robots.txt"), "utf8");
  for (const privatePath of ["/account", "/admin", "/api/", "/reading/private/"]) {
    assert.equal((robots.match(new RegExp(`Disallow: ${privatePath.replaceAll("/", "\\/")}`, "g")) ?? []).length, 2);
  }
  assert.match(robots, /Sitemap: https:\/\/xuannova\.com\/sitemap\.xml/);
});

test("LLM index links use the deployed single-page routes instead of nonexistent locale paths", async () => {
  const index = await readFile(publicFile("llms.txt"), "utf8");
  assert.match(index, /https:\/\/xuannova\.com\/bazi/);
  assert.match(index, /\/zh-hans, \/zh-hant, \/ja, \/ko, \/vi, \/th/);
  assert.doesNotMatch(index, /xuannova\.com\/en\//, "English has no prefix");
  assert.doesNotMatch(index, /\bAI\b/);
});

test("sitemap only advertises the canonical crawlable page", async () => {
  const sitemap = await readFile(publicFile("sitemap.xml"), "utf8");
  assert.match(sitemap, /<loc>https:\/\/xuannova\.com\/<\/loc>/);
  assert.equal((sitemap.match(/<loc>/g) ?? []).length, 196, "28 public pages × 7 languages");
  assert.match(sitemap, /hreflang="ja" href="https:\/\/xuannova\.com\/ja\/bazi"/);
});
