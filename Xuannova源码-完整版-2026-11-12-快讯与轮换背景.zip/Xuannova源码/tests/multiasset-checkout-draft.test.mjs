import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { readFileSync, readdirSync } from "node:fs";
import { createPublicClient, createWalletClient, custom, keccak256, toBytes, decodeEventLog } from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { inspectEvmCheckoutReceipt } from "../worker/evm-checkout-proof.draft.ts";
import { createEthereumDraftOrder, settleEthereumDraftOrder } from "../worker/ethereum-order-settlement.draft.ts";
import { openDatabase } from "../server/sqlite-db.ts";
import { submitEthereumDraftCheckout } from "../app/ethereum-checkout-transaction.draft.ts";
import { requestEthereumDraftApproval } from "../app/ethereum-token-approval.draft.ts";
import { runEthereumEventRecoveryDraft } from "../worker/ethereum-event-recovery.draft.ts";
if (!process.env.XUANNOVA_TEST_TOOLS) throw new Error("Set XUANNOVA_TEST_TOOLS for local solc and ganache");
const require = createRequire(`${process.env.XUANNOVA_TEST_TOOLS}/package.json`);
const solc = require("solc"), ganache = require("ganache");
const draft = readFileSync(new URL("../contracts/MultiAssetCheckoutDraft.sol", import.meta.url), "utf8");
const mocks = `// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;
contract Token { event Transfer(address indexed from,address indexed to,uint value); mapping(address=>uint) public balanceOf; mapping(address=>mapping(address=>uint)) public allowance;
 function mint(address a,uint n) external {balanceOf[a]+=n;} function approve(address a,uint n) external returns(bool){allowance[msg.sender][a]=n;return true;}
 function transfer(address a,uint n) external returns(bool){balanceOf[msg.sender]-=n;balanceOf[a]+=n;emit Transfer(msg.sender,a,n);return true;}
 function transferFrom(address a,address b,uint n) external returns(bool){allowance[a][msg.sender]-=n;balanceOf[a]-=n;balanceOf[b]+=n;return true;} }
interface T { function transfer(address,uint) external returns(bool); function transferFrom(address,address,uint) external returns(bool); }
contract Router { address public immutable WETH; constructor(address w){WETH=w;}
 function swapTokensForExactTokens(uint out,uint max,address[] calldata p,address to,uint) external returns(uint[] memory a){require(max>=out);T(p[0]).transferFrom(msg.sender,address(this),out);T(p[p.length-1]).transfer(to,out);a=new uint[](p.length);for(uint i;i<p.length;i++)a[i]=out;}
 function swapETHForExactTokens(uint out,address[] calldata p,address to,uint) external payable returns(uint[] memory a){require(msg.value>=out);T(p[p.length-1]).transfer(to,out);(bool ok,)=msg.sender.call{value:msg.value-out}("");require(ok);a=new uint[](p.length);for(uint i;i<p.length;i++)a[i]=out;} }
contract FeeToken { mapping(address=>uint) public balanceOf; mapping(address=>mapping(address=>uint)) public allowance;
 function mint(address a,uint n) external {balanceOf[a]+=n;} function approve(address a,uint n) external returns(bool){allowance[msg.sender][a]=n;return true;}
 function transfer(address a,uint n) external returns(bool){balanceOf[msg.sender]-=n;balanceOf[a]+=n;return true;}
 function transferFrom(address a,address b,uint n) external returns(bool){allowance[a][msg.sender]-=n;balanceOf[a]-=n;balanceOf[b]+=n-1;return true;} }`;
const input = { language:"Solidity", sources:{ "Draft.sol":{content:draft}, "Mocks.sol":{content:mocks} }, settings:{optimizer:{enabled:true,runs:200},outputSelection:{"*":{"*":["abi","evm.bytecode.object"]}}} };
const compiled = JSON.parse(solc.compile(JSON.stringify(input)));
assert.deepEqual((compiled.errors ?? []).filter((e) => e.severity === "error"), []);

test("draft permits exact-output payment, owner-managed assets, and rejects transfer-tax tokens", async () => {
 const provider = ganache.provider({logging:{quiet:true},chain:{chainId:1,hardfork:"shanghai"}});
 const db=openDatabase(":memory:");
 try {
  const dir=new URL("../migrations/",import.meta.url);
  for(const f of readdirSync(dir).filter(x=>x.endsWith(".sql")).sort()) db.raw.exec(readFileSync(new URL(f,dir),"utf8"));
  db.raw.exec(readFileSync(new URL("../db/drafts/multichain-orders.sql",import.meta.url),"utf8"));
  const accounts = await provider.request({method:"eth_accounts",params:[]});
  const account = privateKeyToAccount(provider.getInitialAccounts()[accounts[0].toLowerCase()].secretKey);
  const pub = createPublicClient({transport:custom(provider),pollingInterval:30});
  const wallet = createWalletClient({account,transport:custom(provider)});
  const deploy = async (file,name,args=[]) => {const a=compiled.contracts[file][name];const h=await wallet.deployContract({abi:a.abi,bytecode:`0x${a.evm.bytecode.object}`,args,chain:null});return {address:(await pub.waitForTransactionReceipt({hash:h})).contractAddress,abi:a.abi};};
  const send = async (a,fn,args=[],value=0n) => {const h=await wallet.writeContract({address:a.address,abi:a.abi,functionName:fn,args,value,chain:null});return pub.waitForTransactionReceipt({hash:h});};
  const stable=await deploy("Mocks.sol","Token"), asset=await deploy("Mocks.sol","Token"), tax=await deploy("Mocks.sol","FeeToken"), router=await deploy("Mocks.sol","Router",[asset.address]);
  const recipient="0x84F33708ab4b7DEFd9Be5EC50911797E34009caA";
  const store=await deploy("Draft.sol","MultiAssetCheckoutDraft",[stable.address,router.address,recipient,6]);
  const id=keccak256(toBytes("seed")); const deadline=BigInt(Math.floor(Date.now()/1000)+600);
  assert.deepEqual(await pub.readContract({address:store.address,abi:store.abi,functionName:"packageDetails",args:[id]}),[4990000n,20]);
  await send(stable,"mint",[account.address,10000000n]);
  const approval=await requestEthereumDraftApproval({provider,session:{network:"ethereum",chainId:"0x1",address:account.address},token:stable.address,checkout:store.address,allowedTokens:[stable.address],amount:4990000n,onHash:async()=>{}});
  assert.equal(approval.status,"submitted");assert.equal((await pub.waitForTransactionReceipt({hash:approval.hash})).status,"success");
  const now="2026-01-01T00:00:00Z";
  db.raw.prepare("INSERT INTO members(id,wallet_address,credits,daily_credits,role,created_at,updated_at) VALUES(?,?,?,?,?,?,?)").run("m",account.address,10,0,"member",now,now);
  const order=await createEthereumDraftOrder(db,{memberId:"m",buyer:account.address,packageId:"seed",settlementToken:stable.address,now});
  const ref1=order.reference, ref2=keccak256(toBytes("order-two"));
  const seconds=Math.floor(Date.now()/1000);
  const submitted=await submitEthereumDraftCheckout({provider,session:{network:"ethereum",chainId:"0x1",address:account.address},order:{id:order.id,packageId:"seed",buyer:account.address,reference:ref1},config:{checkout:store.address,settlement:stable.address,wrappedNative:asset.address,allowedAssets:[],intermediates:[]},quote:{asset:stable.address,inputUnits:4990000n,maxInputUnits:4990000n,outputUnits:4990000n,path:[],expiresAt:seconds+110},clock:()=>Math.floor(Date.now()/1000),onHash:async()=>{throw Error("browser offline");}});
  assert.equal(submitted.recoveryRecorded,false);
  const first=await pub.waitForTransactionReceipt({hash:submitted.hash});
  assert.equal(first.status,"success");
  const purchase=first.logs.filter(log=>log.address.toLowerCase()===store.address.toLowerCase()).map(log=>{try{return decodeEventLog({abi:store.abi,data:log.data,topics:log.topics});}catch{return null;}}).find(log=>log?.eventName==="Purchased");
  assert.equal(purchase.args.orderReference,ref1);
  const expected={network:"ethereum",chainId:1,expectedChainId:1,final:true,txHash:first.transactionHash,checkout:store.address,settlementToken:stable.address,buyer:account.address,recipient,packageId:"seed",reference:ref1};
  assert.equal(inspectEvmCheckoutReceipt(first,expected).credits,20);
  assert.throws(()=>inspectEvmCheckoutReceipt(first,{...expected,final:false}),/TRANSACTION_NOT_FINAL_SUCCESS/);
  assert.throws(()=>inspectEvmCheckoutReceipt(first,{...expected,reference:ref2}),/PURCHASE_EVENT_MISMATCH/);
  assert.throws(()=>inspectEvmCheckoutReceipt(first,{...expected,settlementToken:asset.address}),/SETTLEMENT_TRANSFER_MISMATCH/);
  assert.throws(()=>inspectEvmCheckoutReceipt(first,{...expected,recipient:accounts[1]}),/WRONG_RECIPIENT/);
  assert.throws(()=>inspectEvmCheckoutReceipt({...first,status:'reverted'},expected),/TRANSACTION_NOT_FINAL_SUCCESS/);
  const purchaseLog=first.logs.find(log=>log.address.toLowerCase()===store.address.toLowerCase());
  const transferLog=first.logs.find(log=>log.address.toLowerCase()===stable.address.toLowerCase());
  assert.ok(purchaseLog && transferLog);
  assert.throws(()=>inspectEvmCheckoutReceipt({...first,logs:first.logs.filter(log=>log!==transferLog)},expected),/SETTLEMENT_TRANSFER_MISMATCH/);
  assert.throws(()=>inspectEvmCheckoutReceipt({...first,logs:[...first.logs,purchaseLog]},expected),/PURCHASE_EVENT_MISMATCH/);
  assert.throws(()=>inspectEvmCheckoutReceipt({...first,logs:[...first.logs,transferLog]},expected),/SETTLEMENT_TRANSFER_MISMATCH/);
  const rpc={getChainId:()=>pub.getChainId(),getBlockNumber:()=>pub.getBlockNumber(),getTransactionReceipt:args=>pub.getTransactionReceipt(args),getBlock:args=>"blockTag" in args?pub.getBlock({blockNumber:first.blockNumber}):pub.getBlock(args)};
  const settlement={memberId:"m",orderId:order.id,txHash:first.transactionHash,checkout:store.address,settlementToken:stable.address,confirmations:1,rpc,now};
  await assert.rejects(settleEthereumDraftOrder(db,{...settlement,memberId:"other"}),/ORDER_NOT_FOUND/);
  await assert.rejects(settleEthereumDraftOrder(db,{...settlement,confirmations:100}),/TRANSACTION_NOT_FINAL_SUCCESS/);
  await assert.rejects(settleEthereumDraftOrder(db,{...settlement,rpc:{...rpc,getBlock:async args=>"blockTag" in args?{number:0n,hash:first.blockHash}:rpc.getBlock(args)}}),/TRANSACTION_NOT_FINAL_SUCCESS/);
  const scanRpc={...rpc,getLogs:async()=>first.logs.filter(log=>log.address.toLowerCase()===store.address.toLowerCase())};
  assert.equal(db.raw.prepare("SELECT count(*) AS n FROM multichain_payment_attempts_draft").get().n,0);
  const scanInput={rpc:scanRpc,checkout:store.address,settlementToken:stable.address,confirmations:1,startBlock:first.blockNumber,now};
  await assert.rejects(runEthereumEventRecoveryDraft(db,{...scanInput,rpc:{...scanRpc,getTransactionReceipt:async()=>{throw Error("RPC down");}}}),/RPC down/);
  assert.equal(db.raw.prepare("SELECT credits FROM members WHERE id='m'").get().credits,10);
  assert.equal(db.raw.prepare("SELECT next_block FROM ethereum_event_cursor_draft").get().next_block,first.blockNumber.toString());
  await assert.rejects(runEthereumEventRecoveryDraft(db,{...scanInput,rpc:{...scanRpc,getLogs:async()=>[{...purchaseLog,blockNumber:first.blockNumber+1n}]}}),/INVALID_CHAIN_LOG/);
  assert.equal(db.raw.prepare("SELECT next_block FROM ethereum_event_cursor_draft").get().next_block,first.blockNumber.toString());
  assert.equal(db.raw.prepare("SELECT credits FROM members WHERE id='m'").get().credits,10);
  assert.deepEqual(await runEthereumEventRecoveryDraft(db,scanInput),{matched:1,credited:1,nextBlock:first.blockNumber+1n});
  assert.deepEqual(await runEthereumEventRecoveryDraft(db,scanInput),{matched:0,credited:0,nextBlock:first.blockNumber+1n});
  const settled=await Promise.all([settleEthereumDraftOrder(db,settlement),settleEthereumDraftOrder(db,settlement)]);
  assert.equal(settled.filter(x=>!x.alreadyCredited).length,0);
  assert.equal(db.raw.prepare("SELECT credits FROM members WHERE id='m'").get().credits,30);
  await assert.rejects(pub.simulateContract({account,address:store.address,abi:store.abi,functionName:"buy",args:[id,stable.address,4990000n,[],deadline,ref1]}));
  assert.equal(await pub.readContract({address:stable.address,abi:stable.abi,functionName:"balanceOf",args:[recipient]}),4990000n);
  await send(store,"setAsset",[asset.address,true]); await send(stable,"mint",[router.address,10000000n]);
  await send(asset,"mint",[account.address,6000000n]); await send(asset,"approve",[store.address,6000000n]);
  assert.equal((await send(store,"buy",[id,asset.address,6000000n,[asset.address,stable.address],deadline,ref2])).status,"success");
  assert.equal(await pub.readContract({address:asset.address,abi:asset.abi,functionName:"balanceOf",args:[account.address]}),1010000n);
  await send(store,"setAsset",[tax.address,true]); await send(tax,"mint",[account.address,6000000n]); await send(tax,"approve",[store.address,6000000n]);
  await assert.rejects(pub.simulateContract({account,address:store.address,abi:store.abi,functionName:"buy",args:[id,tax.address,6000000n,[tax.address,stable.address],deadline,keccak256(toBytes("tax"))]}));
  assert.equal(await pub.readContract({address:stable.address,abi:stable.abi,functionName:"balanceOf",args:[recipient]}),9980000n);
  await assert.rejects(pub.simulateContract({account:accounts[1],address:store.address,abi:store.abi,functionName:"setAsset",args:[asset.address,false]}));
  await send(store,"setPaused",[true]); await assert.rejects(pub.simulateContract({account,address:store.address,abi:store.abi,functionName:"buy",args:[id,stable.address,4990000n,[],deadline,keccak256(toBytes("paused"))]}));
 } finally { db.raw.close(); await provider.disconnect(); }
});
