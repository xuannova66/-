// 点亮祈福灯: free at launch; with HALL_LAMP_COST set, credits are debited (daily first) together with the ledger row and
// the lamp. Lamps glow 24 hours, wishes are filtered, only real lamps are shown.
import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import test from "node:test";

const { openDatabase } = await import("../server/sqlite-db.ts");
const { handleCommerceApi } = await import("../worker/commerce-api.ts");
const { cleanWish } = await import("../worker/hall-lamps.ts");
const LAMP_COST = 2;
const ORIGIN = "https://xuannova.test";

function freshEnv() {
  const db = openDatabase(":memory:");
  for (const file of readdirSync(new URL("../migrations/", import.meta.url)).filter((name) => name.endsWith(".sql")).sort()) db.raw.exec(readFileSync(new URL(`../migrations/${file}`, import.meta.url), "utf8"));
  return { DB: db, SESSION_SECRET: "test-session-signing-key-that-is-long-enough" };
}
function client(env, device, origin = ORIGIN) {
  const jar = new Map([["xn_device", device]]);
  return async (path, body, method = body === undefined ? "GET" : "POST") => {
    const headers = { origin, cookie: [...jar].map(([k, v]) => `${k}=${v}`).join("; "), "content-type": "application/json" };
    const response = await handleCommerceApi(new Request(`${ORIGIN}${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) }), env);
    for (const cookie of response.headers.getSetCookie?.() ?? []) { const [pair] = cookie.split(";"); const [name, value] = pair.split("="); if (value) jar.set(name, value); else jar.delete(name); }
    return { status: response.status, body: await response.json() };
  };
}
const setCredits = (env, email, credits, daily = 0) => env.DB.raw.prepare("UPDATE members SET credits = ?, daily_credits = ?, daily_credit_date = ? WHERE email = ?").run(credits, daily, new Date().toISOString().slice(0, 10), email);

test("wishes: short text with punctuation; links, contacts and abuse refused", () => {
  assert.equal(cleanWish(""), null);
  assert.equal(cleanWish("  愿家人平安，考试顺利！ "), "愿家人平安，考试顺利！");
  assert.equal(cleanWish("Peace for my mom."), "Peace for my mom.");
  for (const bad of ["x".repeat(41), "加我微信", "visit www.x.com", "call 13800138000", "<script>", 42]) assert.equal(cleanWish(bad), false, String(bad));
});

test("with a price set, a member lights a lamp for 2 credits; it shows for everyone, private wishes stay private", async () => {
  const env = { ...freshEnv(), HALL_LAMP_COST: "2" };
  const alice = client(env, "device-lamp-00000000000001");
  const bob = client(env, "device-lamp-00000000000002");
  const guest = client(env, "device-lamp-00000000000003");
  for (const [c, email] of [[alice, "alice@example.com"], [bob, "bob@example.com"]]) assert.equal((await c("/api/auth/register", { email, password: "secret-pass" })).status, 201);

  assert.deepEqual((await guest("/api/hall/lamps")).body.lamps, [], "no made-up lamps");
  assert.equal((await guest("/api/hall/lamps", { wish: "hi" })).status, 401);
  assert.equal((await client(env, "device-lamp-00000000000001", "https://evil.test")("/api/hall/lamps", {})).status, 403);

  setCredits(env, "alice@example.com", 0, 1);
  assert.equal((await alice("/api/hall/lamps", { wish: "平安" })).status, 402, "1 credit is not enough");

  setCredits(env, "alice@example.com", 10, 1);
  const lit = await alice("/api/hall/lamps", { wish: "愿家人平安", kind: "family", name: "清风" });
  assert.equal(lit.status, 201);
  assert.equal(lit.body.lamp.name, "清风"); assert.equal(lit.body.lamp.kind, "family");
  assert.equal(lit.body.member.balance, 11 - LAMP_COST, "daily credit used first, then 1 paid credit");
  const row = env.DB.raw.prepare("SELECT credits, daily_credits FROM members WHERE email = 'alice@example.com'").get();
  assert.deepEqual([row.credits, row.daily_credits], [9, 0]);
  const ledger = env.DB.raw.prepare("SELECT delta, reason FROM credit_ledger WHERE reason LIKE 'hall_lamp%'").all();
  assert.deepEqual(ledger.map((r) => [r.delta, r.reason]), [[-2, "hall_lamp:family"]]);
  const hours = (Date.parse(lit.body.lamp.expiresAt) - Date.parse(lit.body.lamp.createdAt)) / 3600000;
  assert.equal(hours, 24);

  const hidden = await alice("/api/hall/lamps", { wish: "秘密的心愿", public: false });
  assert.equal(hidden.status, 201);
  const seenByGuest = (await guest("/api/hall/lamps")).body.lamps;
  assert.equal(seenByGuest.length, 1, "private lamps are not listed for others");
  assert.equal(seenByGuest[0].wish, "愿家人平安"); assert.equal(seenByGuest[0].mine, false);
  const seenByAlice = (await alice("/api/hall/lamps")).body.lamps;
  assert.equal(seenByAlice.length, 2); assert.ok(seenByAlice.every((l) => l.mine));
  assert.ok(seenByAlice.some((l) => l.wish === "秘密的心愿"));

  assert.equal((await alice("/api/hall/lamps", { wish: "加我微信" })).status, 400);
  assert.equal((await alice("/api/hall/lamps", { name: "www.x.com" })).status, 400);
  const balanceBefore = env.DB.raw.prepare("SELECT credits FROM members WHERE email = 'alice@example.com'").get().credits;
  assert.equal(balanceBefore, 7, "refused requests are not charged");
});

test("free at launch: no credits needed, nothing debited, still members only", async () => {
  const env = freshEnv();
  const c = client(env, "device-lamp-00000000000007");
  assert.equal((await c("/api/hall/lamps")).body.cost, 0);
  assert.equal((await c("/api/hall/lamps", {})).status, 401);
  await c("/api/auth/register", { email: "free@example.com", password: "secret-pass" });
  setCredits(env, "free@example.com", 0, 0);
  const lit = await c("/api/hall/lamps", { wish: "平安", kind: "peace" });
  assert.equal(lit.status, 201); assert.equal(lit.body.cost, 0);
  assert.equal(env.DB.raw.prepare("SELECT credits FROM members WHERE email = 'free@example.com'").get().credits, 0);
  assert.equal(env.DB.raw.prepare("SELECT COUNT(*) AS n FROM credit_ledger WHERE reason LIKE 'hall_lamp%'").get().n, 0);
  assert.equal((await c("/api/hall/lamps")).body.lamps.length, 1);
});

test("daily limit of five lamps", async () => {
  const env = { ...freshEnv(), HALL_LAMP_COST: "2" };
  const c = client(env, "device-lamp-00000000000009");
  await c("/api/auth/register", { email: "many@example.com", password: "secret-pass" });
  setCredits(env, "many@example.com", 100);
  for (let i = 0; i < 5; i += 1) assert.equal((await c("/api/hall/lamps", {})).status, 201);
  assert.equal((await c("/api/hall/lamps", {})).status, 429);
  assert.equal(env.DB.raw.prepare("SELECT credits FROM members WHERE email = 'many@example.com'").get().credits, 90);
});
