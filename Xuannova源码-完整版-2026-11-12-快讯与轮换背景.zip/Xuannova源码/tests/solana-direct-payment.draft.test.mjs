import test from "node:test";
import assert from "node:assert/strict";
import { inspectSolanaDirectPayment } from "../worker/solana-direct-payment.draft.ts";

const token = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA", memo = "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr";
const expected = { signature: "A".repeat(88), buyer: "buyer", recipient: "owner", recipientTokenAccount: "receiver-ata", mint: "usdc-mint", decimals: 6, amountUnits: 4990000n, orderReference: "a".repeat(64) };
const balance = (amount) => ({ accountIndex: 1, mint: expected.mint, owner: expected.recipient, programId: token, uiTokenAmount: { amount, decimals: 6 } });
const transfer = { programId: token, parsed: { type: "transferChecked", info: { authority: expected.buyer, mint: expected.mint, destination: expected.recipientTokenAccount, tokenAmount: { amount: "4990000", decimals: 6 } } } };
const reference = { programId: memo, parsed: expected.orderReference };
const tx = { meta: { err: null, preTokenBalances: [balance("0")], postTokenBalances: [balance("4990000")] }, transaction: { signatures: [expected.signature], message: { accountKeys: [{ pubkey: "buyer", signer: true }, { pubkey: "receiver-ata", signer: false }], instructions: [transfer, reference] } } };

test("requires a finalized direct token transfer with exact owner, mint, signer, amount and unique order reference", () => {
  assert.equal(inspectSolanaDirectPayment(tx, true, expected).instructionIndex, 0);
  assert.throws(() => inspectSolanaDirectPayment(tx, false, expected));
  for (const override of [{ buyer: "other" }, { recipient: "other" }, { mint: "other" }, { amountUnits: 4989999n }, { orderReference: "b".repeat(64) }]) assert.throws(() => inspectSolanaDirectPayment(tx, true, { ...expected, ...override }));
  assert.throws(() => inspectSolanaDirectPayment({ ...tx, meta: { ...tx.meta, err: { custom: 1 } } }, true, expected));
  assert.throws(() => inspectSolanaDirectPayment({ ...tx, transaction: { ...tx.transaction, message: { ...tx.transaction.message, instructions: [transfer, transfer, reference] } } }, true, expected));
  assert.throws(() => inspectSolanaDirectPayment({ ...tx, meta: { ...tx.meta, postTokenBalances: [balance("4989999")] } }, true, expected));
});
