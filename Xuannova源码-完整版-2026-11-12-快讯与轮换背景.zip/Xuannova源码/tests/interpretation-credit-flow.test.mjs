import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";

const panel = await readFile(new URL("../app/interpretation-panel.tsx", import.meta.url), "utf8");
const account = await readFile(new URL("../app/account-contact-center.tsx", import.meta.url), "utf8");
const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");

test("interpretation panel requests a server-generated reading with the chart and selected mode", () => {
  assert.match(panel, /fetch\("\/api\/interpretations"/);
  assert.match(panel, /followUpHistory\(chartFingerprint, conversationContext, draft\)/);
  assert.match(panel, /const chartFingerprint = JSON\.stringify\(request\.chart\)/);
  assert.match(panel, /setConversationContext\(\{ chartFingerprint, draftId, turns: \[\.\.\.currentTurns, \{ question: question\.trim\(\), answer \}\]\.slice\(-10\) \}\)/);
  assert.doesNotMatch(panel, /createLocalInterpretation\(request\)/);
  assert.match(panel, /onOpenMembership/);
});

test("membership renders the credit catalogue and an honest payment state", () => {
  assert.match(account, /creditPackages\.map/);
  assert.match(account, /paymentPending/);
  assert.match(account, /wallet\.balance/);
});

test("both reading routes receive the shared credit wallet and membership handoff", () => {
  assert.match(page, /readCreditWallet/);
  assert.match(page, /spendCredits/);
  assert.match(page, /<InterpretationPanel[\s\S]*onSpend/);
  assert.match(page, /onOpenMembership/);
});

test("reading uses the live interpretation service and offers structured and conversation modes", () => {
  assert.match(panel, /\/api\/interpretations/);
  assert.match(panel, /method: "POST"/);
  assert.match(panel, /mode === "conversation"/);
  assert.match(panel, /structured/);
  assert.match(panel, /conversation/);
});

test("reading always shows the server-backed balance and distinguishes an empty balance from sign-in", () => {
  assert.match(panel, /fetch\("\/api\/member\/me\?soft=1"/);
  assert.match(panel, /insufficientCredits/);
  assert.match(panel, /balance !== null && balance < cost/);
  assert.doesNotMatch(panel, /onSpend\(chart\.tool\)/);
});

test("reading prevents only an empty question from being sent to the AI endpoint", () => {
  assert.match(panel, /question\.trim\(\)\.length === 0/);
  assert.match(panel, /QUESTION_REQUIRED/);
  assert.match(panel, /const \[needsMembership, setNeedsMembership\] = useState\(false\)/);
  assert.match(panel, /\{needsMembership && <button/);
});

test("an insufficient server balance keeps a direct route to credit packages", () => {
  assert.match(panel, /const insufficientBalance = balance !== null && balance < cost/);
  assert.match(panel, /insufficientBalance && <aside[\s\S]*onOpenMembership[\s\S]*walletText\.viewMembership/);
});
