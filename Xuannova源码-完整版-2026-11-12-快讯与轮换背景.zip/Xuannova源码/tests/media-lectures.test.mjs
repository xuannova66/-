// Uploaded lecture videos: administrator upload, members-only streaming with HTTP Range.
import assert from "node:assert/strict";
import { readdirSync, readFileSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import test from "node:test";

process.env.MEDIA_DIR = mkdtempSync(path.join(tmpdir(), "xn-media-"));
const { openDatabase } = await import("../server/sqlite-db.ts");
const api = await import("../worker/commerce-api.ts");
const { handleMediaStream, handleMediaUpload } = await import("../server/media.ts");
const ORIGIN = "https://xuannova.test";

function freshEnv() {
  const db = openDatabase(":memory:");
  for (const file of readdirSync(new URL("../migrations/", import.meta.url)).filter((name) => name.endsWith(".sql")).sort()) db.raw.exec(readFileSync(new URL(`../migrations/${file}`, import.meta.url), "utf8"));
  return { db, env: { DB: db, ADMIN_EMAILS: "owner@example.com", ADMIN_PASSWORD: "admin-password-123", SESSION_SECRET: "test-session-signing-key-that-is-long-enough" } };
}
const cookieFor = async (env, payload) => `xuanyuan_session=${await api.createSessionToken(payload, env.SESSION_SECRET)}`;

test("lecture videos: admin uploads, only signed-in members stream, Range requests work", async () => {
  const { env } = freshEnv();
  const admin = await cookieFor(env, { sub: "admin", email: "owner@example.com", role: "admin" });
  const video = new Uint8Array(4096).map((_, index) => index % 251);
  const anonymousUpload = await handleMediaUpload(new Request(`${ORIGIN}/api/admin/lectures/upload`, { method: "POST", headers: { origin: ORIGIN, "x-file-name": "intro.mp4" }, body: video }), env);
  assert.equal(anonymousUpload.status, 403, "only administrators upload");
  const wrongType = await handleMediaUpload(new Request(`${ORIGIN}/api/admin/lectures/upload`, { method: "POST", headers: { origin: ORIGIN, cookie: admin, "x-file-name": "intro.exe" }, body: video }), env);
  assert.equal(wrongType.status, 400);
  const upload = await handleMediaUpload(new Request(`${ORIGIN}/api/admin/lectures/upload`, { method: "POST", headers: { origin: ORIGIN, cookie: admin, "x-file-name": "intro.mp4" }, body: video, duplex: "half" }), env);
  assert.equal(upload.status, 201);
  const { file, bytes } = await upload.json();
  assert.equal(bytes, 4096);
  const save = await api.handleCommerceApi(new Request(`${ORIGIN}/api/admin/lectures`, { method: "POST", headers: { origin: ORIGIN, cookie: admin, "content-type": "application/json" }, body: JSON.stringify({ title: { en: "Intro", "zh-Hans": "入门" }, mediaFile: file, membersOnly: true, published: true }) }), env);
  assert.equal(save.status, 201);
  const list = await (await api.handleCommerceApi(new Request(`${ORIGIN}/api/lectures`), env)).json();
  assert.equal(list.lectures[0].locked, true);
  assert.equal(list.lectures[0].mediaUrl, null, "visitors see the lesson but not its address");
  const adminList = await (await api.handleCommerceApi(new Request(`${ORIGIN}/api/lectures`, { headers: { cookie: admin } }), env)).json();
  assert.equal(adminList.lectures[0].mediaUrl, `/api/media/${file}`);
  assert.equal(list.lectures[0].membersOnly, true);
  assert.equal((await handleMediaStream(new Request(`${ORIGIN}/api/media/${file}`), env, file)).status, 401, "members only");
  const member = await cookieFor(env, { sub: "member-1", email: "m@example.com", role: "member" });
  const full = await handleMediaStream(new Request(`${ORIGIN}/api/media/${file}`, { headers: { cookie: member } }), env, file);
  assert.equal(full.status, 200);
  assert.equal((await full.arrayBuffer()).byteLength, 4096);
  const part = await handleMediaStream(new Request(`${ORIGIN}/api/media/${file}`, { headers: { cookie: member, range: "bytes=100-199" } }), env, file);
  assert.equal(part.status, 206);
  assert.equal(part.headers.get("content-range"), "bytes 100-199/4096");
  assert.deepEqual(new Uint8Array(await part.arrayBuffer())[0], 100 % 251);
  assert.equal((await handleMediaStream(new Request(`${ORIGIN}/api/media/00000000-0000-0000-0000-000000000000.mp4`, { headers: { cookie: member } }), env, "00000000-0000-0000-0000-000000000000.mp4")).status, 404);
});
