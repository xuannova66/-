import assert from "node:assert/strict";
import test from "node:test";

const { calculateTrueSolarTime } = await import("../app/solar-time.ts");

test("true solar time corrects civil time at the selected longitude", () => {
  const solar = calculateTrueSolarTime({ date: "2024-03-20", time: "12:00", longitude: 120, timezone: "Asia/Shanghai" });
  assert.equal(solar.civilTime, "12:00");
  assert.equal(solar.timezoneOffsetMinutes, 480);
  assert.ok(solar.equationOfTimeMinutes < 0);
  assert.ok(solar.correctionMinutes < 0);
  assert.match(solar.trueSolarTime, /^11:5\d$/);
});

test("true solar time applies the location time zone and rolls dates correctly", () => {
  const solar = calculateTrueSolarTime({ date: "2024-06-01", time: "00:05", longitude: -82.9988, timezone: "America/New_York" });
  assert.equal(solar.timezoneOffsetMinutes, -240);
  assert.ok(solar.standardOffsetMinutes <= -240);
  assert.match(solar.trueSolarDate, /^2024-05-3[01]$/);
  assert.match(solar.trueSolarTime, /^2[23]:/);
});
