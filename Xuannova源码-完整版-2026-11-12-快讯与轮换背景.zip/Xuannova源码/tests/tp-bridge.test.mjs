import assert from "node:assert/strict";
import test from "node:test";

test("TokenPocket wallet switch sends getWallet with the chain id and reloads after a switch", async () => {
  const sent = []; let reloaded = false;
  const timers = [];
  globalThis.window = { TPJSBrigeClient: { callMessage: (method, params, callback) => { sent.push({ method, params: JSON.parse(params), callback }); } }, setTimeout: (fn) => { timers.push(fn); return timers.length; }, clearTimeout: () => {}, location: { reload: () => { reloaded = true; } } };
  const { tpSwitchWallet, tpBridgeAvailable } = await import("../app/tp-bridge.ts");
  assert.equal(tpBridgeAvailable(), true);
  const pending = tpSwitchWallet("tron");
  assert.equal(sent[0].method, "getWallet");
  assert.deepEqual(sent[0].params, { walletTypes: ["10"], switch: true });
  window[sent[0].callback](JSON.stringify({ result: true, data: { address: "T...", blockchain_id: 10 } }));
  assert.equal(await pending, true);
  timers.at(-1)(); assert.equal(reloaded, true);
  const cancelled = tpSwitchWallet("solana");
  assert.deepEqual(sent[1].params.walletTypes, ["27"]);
  window[sent[1].callback]("{\"result\":false}");
  assert.equal(await cancelled, false);
  delete globalThis.window;
});
