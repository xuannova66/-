import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const { createCompleteChart, createInterpretationRequest, createLocalInterpretation } = await import("../app/chart-model.ts");
const { createStudyResult } = await import("../app/study-engine.ts");
const { localizeBoardTerm, localizeZiWeiPalace } = await import("../app/complete-chart-board.tsx");

const sharedInput = {
  birthDate: "1994-08-18",
  birthTime: "12:00",
  calendar: "solar",
  focus: "A work transition",
  name: "Local study",
  companionName: "",
  module: "qimen",
  version: 1,
  place: "Global",
};

test("Qi Men local chart includes a complete nine-palace study board", () => {
  const chart = createCompleteChart(sharedInput);

  assert.equal(chart.tool, "qimen");
  assert.equal(chart.board.kind, "nine-palace");
  assert.equal(chart.board.cells.length, 9);
  assert.ok(chart.board.cells.every((cell) => cell.items.some((item) => item.label === "Direction")));
  assert.ok(chart.board.cells.every((cell) => cell.items.some((item) => item.label === "Void")));
  assert.ok(chart.sections.some((section) => section.id === "gates"));
  assert.ok(chart.sections.some((section) => section.id === "stars"));
  assert.ok(chart.sections.some((section) => section.id === "deities"));
  assert.ok(chart.sections.some((section) => section.id === "duty-markers"));
  assert.ok(chart.sections.some((section) => section.id === "key-patterns"));
});

test("daily rhythm has an independent local calendar study board", () => {
  const chart = createCompleteChart({ ...sharedInput, module: "daily" });

  assert.equal(chart.board.label, "Daily rhythm study field");
  for (const id of ["daily-calendar", "solar-term-context", "twelve-windows", "elemental-climate", "grounded-sequence"]) {
    assert.ok(chart.sections.some((section) => section.id === id), `daily route needs ${id}`);
  }
});

test("Liuyao local chart preserves manual lines and exposes ritual reading layers", () => {
  const chart = createCompleteChart({
    ...sharedInput,
    module: "liuyao",
    lines: [true, false, true, false, false, true],
  });

  assert.equal(chart.board.kind, "hexagram");
  assert.equal(chart.board.cells.length, 12);
  assert.equal(chart.board.cells[0].items.some((item) => item.label === "Line"), true);
  assert.ok(chart.sections.some((section) => section.id === "six-spirits"));
  assert.ok(chart.sections.some((section) => section.id === "moving-lines"));
  assert.ok(chart.sections.some((section) => section.id === "transformed-lines"));
  assert.ok(chart.board.cells.some((cell) => cell.id.startsWith("original-")));
  assert.ok(chart.board.cells.some((cell) => cell.id.startsWith("changed-")));
});

test("Liuyao chart preserves moving lines produced by a three-coin cast", () => {
  const result = createStudyResult({
    ...sharedInput,
    module: "liuyao",
    lines: [false, true, false, true, true, false],
    movingLines: [true, false, false, true, false, false],
  });
  const chart = createCompleteChart({
    ...sharedInput,
    module: "liuyao",
    lines: result.lines,
    movingLines: result.movingLines,
  });
  const moving = chart.sections.find((section) => section.id === "moving-lines");

  assert.deepEqual(result.movingLines, [true, false, false, true, false, false]);
  assert.equal(moving?.items.filter((item) => item.value === "Moving").length, 2);
});

test("Liuyao renders the first three-coin throw as the bottom line", () => {
  const chart = createCompleteChart({
    ...sharedInput,
    module: "liuyao",
    lines: [false, true, false, true, true, true],
    movingLines: [true, false, false, false, false, false],
  });
  const firstThrow = chart.board.cells.find((cell) => cell.id === "original-1");
  const sixthThrow = chart.board.cells.find((cell) => cell.id === "original-6");

  assert.equal(firstThrow?.items.find((item) => item.label === "Line")?.value, "Yin");
  assert.equal(firstThrow?.items.find((item) => item.label === "Change")?.value, "Moving");
  assert.equal(sixthThrow?.items.find((item) => item.label === "Line")?.value, "Yang");
  assert.equal(sixthThrow?.items.find((item) => item.label === "Change")?.value, "Still");
});

test("birth and palace tools expose their complete local study layers", () => {
  const bazi = createCompleteChart({ ...sharedInput, module: "bazi" });
  const ziwei = createCompleteChart({ ...sharedInput, module: "ziwei" });
  const qizheng = createCompleteChart({ ...sharedInput, module: "qizheng" });
  const daliuren = createCompleteChart({ ...sharedInput, module: "daliuren" });

  assert.ok(bazi.sections.some((section) => section.id === "day-master"));
  assert.ok(bazi.sections.some((section) => section.id === "branch-relations"));
  assert.ok(bazi.sections.some((section) => section.id === "luck-cycles"));
  assert.ok(bazi.sections.some((section) => section.id === "annual-cycle"));
  assert.ok(ziwei.sections.some((section) => section.id === "decadal-limits"));
  assert.ok(ziwei.sections.some((section) => section.id === "annual-limits"));
  assert.ok(qizheng.sections.some((section) => section.id === "lunar-mansions"));
  assert.ok(qizheng.sections.some((section) => section.id === "planetary-dignities"));
  assert.ok(daliuren.sections.some((section) => section.id === "heaven-generals"));
  assert.ok(daliuren.sections.some((section) => section.id === "horse-and-void"));
});

test("primary charts include their extended method-specific reference layers", () => {
  const bazi = createCompleteChart({ ...sharedInput, module: "bazi" });
  const ziwei = createCompleteChart({ ...sharedInput, module: "ziwei" });
  const qimen = createCompleteChart({ ...sharedInput, module: "qimen" });
  const liuyao = createCompleteChart({ ...sharedInput, module: "liuyao" });
  const daliuren = createCompleteChart({ ...sharedInput, module: "daliuren" });

  assert.ok(bazi.sections.some((section) => section.id === "nayin-cross-reference"));
  assert.ok(ziwei.sections.some((section) => section.id === "star-dispositions"));
  assert.ok(qimen.sections.some((section) => section.id === "configuration-triad"));
  assert.ok(liuyao.sections.some((section) => section.id === "hexagram-identity"));
  assert.ok(daliuren.sections.some((section) => section.id === "transmission-context"));
});

test("BaZi exposes a dense four-pillar matrix and long-form study layers", () => {
  const chart = createCompleteChart({ ...sharedInput, module: "bazi" });

  assert.ok(chart.board.cells.every((cell) => cell.items.length >= 10));
  for (const id of ["pillar-matrix", "element-strength", "seasonal-command", "relation-matrix", "month-cadence"]) {
    assert.ok(chart.sections.some((section) => section.id === id));
  }
  assert.ok(chart.sections.length >= 14);
});

test("core chart methods expose their method-specific completeness contracts", () => {
  const bazi = createCompleteChart({ ...sharedInput, module: "bazi" });
  const ziwei = createCompleteChart({ ...sharedInput, module: "ziwei" });
  const qimen = createCompleteChart({ ...sharedInput, module: "qimen" });
  const liuyao = createCompleteChart({ ...sharedInput, module: "liuyao" });
  const daliuren = createCompleteChart({ ...sharedInput, module: "daliuren" });

  assert.ok(bazi.sections.some((section) => section.id === "shen-sha-register"));
  assert.ok(ziwei.sections.some((section) => section.id === "three-harmony"));
  assert.ok(qimen.sections.some((section) => section.id === "bureau-frame"));
  assert.ok(liuyao.sections.some((section) => section.id === "hidden-spirits"));
  assert.ok(daliuren.sections.some((section) => section.id === "day-night-noble"));
});

test("BaZi shen-sha register exposes twelve markers and pillar lanes", () => {
  const chart = createCompleteChart({ ...sharedInput, module: "bazi" });
  assert.equal(chart.sections.find((section) => section.id === "shen-sha-register")?.items.length, 12);
  for (const id of ["year-markers", "month-markers", "day-markers", "start-luck"]) {
    assert.ok(chart.sections.some((section) => section.id === id));
  }
  assert.ok(chart.board.cells.every((cell) => cell.items.some((item) => item.label === "Pillar shen-sha")));
});

test("Zi Wei and Qi Men expose their distinct full board layers", () => {
  const ziwei = createCompleteChart({ ...sharedInput, module: "ziwei" });
  const qimen = createCompleteChart({ ...sharedInput, module: "qimen" });
  assert.ok(ziwei.board.cells.every((cell) => cell.items.length >= 12));
  for (const id of ["three-harmony", "life-body-axis", "palace-stems", "palace-branches"]) {
    assert.ok(ziwei.sections.some((section) => section.id === id));
  }
  for (const id of ["bureau-frame", "duty-location", "door-trajectory", "star-field", "deity-field"]) {
    assert.ok(qimen.sections.some((section) => section.id === id));
  }
});

test("Liuyao and Da Liu Ren expose full independent context layers", () => {
  const liuyao = createCompleteChart({ ...sharedInput, module: "liuyao" });
  const daliuren = createCompleteChart({ ...sharedInput, module: "daliuren" });
  assert.ok(liuyao.board.cells.every((cell) => cell.items.length >= 10));
  for (const id of ["hidden-spirits", "trigram-frame", "line-correspondence"]) {
    assert.ok(liuyao.sections.some((section) => section.id === id));
  }
  assert.ok(daliuren.board.cells.every((cell) => cell.items.length >= 10));
  for (const id of ["day-night-noble", "general-relations", "branch-interactions"]) {
    assert.ok(daliuren.sections.some((section) => section.id === id));
  }
});

test("complete chart board declares a compact reference deck", async () => {
  const source = await readFile(new URL("../app/complete-chart-board.tsx", import.meta.url), "utf8");
  assert.match(source, /chart-reference-deck/);
  assert.match(source, /keySections/);
});

test("BaZi and Zi Wei select specialist chart surfaces", async () => {
  const source = await readFile(new URL("../app/complete-chart-board.tsx", import.meta.url), "utf8");
  assert.match(source, /professional-bazi-board/);
  assert.match(source, /professional-ziwei-board/);
  assert.match(source, /chart\.tool === "bazi" \|\| chart\.tool === "detail"/);
  assert.match(source, /chart\.tool === "ziwei"/);
});

test("specialist four-pillar and twelve-palace surfaces retain their dense relation fields", async () => {
  const source = await readFile(new URL("../app/complete-chart-board.tsx", import.meta.url), "utf8");
  const baziSurface = source.slice(source.indexOf("function ProfessionalBaZiBoard"), source.indexOf("function ZiWeiPalace"));
  const ziweiSurface = source.slice(source.indexOf("function ZiWeiPalace"), source.indexOf("function ProfessionalZiWeiBoard"));

  for (const label of ["Stem element", "Branch element", "Pillar role", "Day-stem relation", "Seasonal status", "Auxiliary star"]) {
    assert.match(baziSurface, new RegExp(`"${label}"`));
  }
  for (const label of ["Opposing palace", "Three-harmony group", "Life-body marker"]) {
    assert.match(ziweiSurface, new RegExp(`"${label}"`));
  }
});

test("BaZi has the dense data needed by the four-pillar matrix", () => {
  const chart = createCompleteChart({ ...sharedInput, module: "bazi" });
  for (const label of ["Stem", "Branch", "Ten God", "Hidden stems", "NaYin", "Life stage", "Pillar shen-sha"]) {
    assert.ok(chart.board.cells.every((cell) => cell.items.some((item) => item.label === label)));
  }
});

test("Zi Wei has the twelve-palace data needed by the perimeter chart", () => {
  const chart = createCompleteChart({ ...sharedInput, module: "ziwei" });
  assert.equal(chart.board.cells.length, 12);
  for (const label of ["Palace branch", "Palace stem", "Core star", "Support star", "Transformation", "Minor star", "Decade limit", "Annual focus"]) {
    assert.ok(chart.board.cells.every((cell) => cell.items.some((item) => item.label === label)));
  }
});

test("dedicated BaZi and Zi Wei surfaces include desktop and mobile layout rules", async () => {
  const source = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");
  assert.match(source, /\.professional-bazi-board\s*\{/);
  assert.match(source, /\.professional-ziwei-board\s*\{/);
  assert.match(source, /\.ziwei-centre-well\s*\{/);
  assert.match(source, /@media \(max-width: 650px\)[\s\S]*\.professional-bazi-board/);
});

test("interpretation request is self-contained and local interpretation is structured", () => {
  const chart = createCompleteChart({ ...sharedInput, module: "bazi" });
  const request = createInterpretationRequest({ tool: "bazi", locale: "en", question: "How can I plan this transition?", chart });
  const response = createLocalInterpretation(request);

  assert.deepEqual(Object.keys(request).sort(), ["chart", "disclaimer", "locale", "question", "tool"]);
  assert.equal(request.chart.board.cells.length, 4);
  assert.equal(response.sections.length, 3);
  assert.equal(response.followUps.length, 3);
});

test("toolkit chart adapters use tool-appropriate ceremonial board families", () => {
  const base = { ...sharedInput, version: 2 };
  assert.equal(createCompleteChart({ ...base, module: "toolkit-tarot" }).board.kind, "spread");
  assert.equal(createCompleteChart({ ...base, module: "toolkit-iching" }).board.kind, "hexagram");
  assert.equal(createCompleteChart({ ...base, module: "toolkit-natal" }).board.kind, "twelve-palace");
});

test("local interpretation uses the selected interface language", () => {
  const chart = createCompleteChart({ ...sharedInput, module: "qimen" });
  const response = createLocalInterpretation(createInterpretationRequest({ tool: "qimen", locale: "ja", question: "次の一歩は？", chart }));
  assert.match(response.title, /解釈/);
  assert.match(response.sections[0].title, /盤|配置/);
  assert.doesNotMatch(response.followUps.join(" "), /What is already clear/);
});

test("board terms localize for non-English study interfaces", () => {
  assert.equal(localizeBoardTerm("Direction", "ja"), "方位");
  assert.equal(localizeBoardTerm("Moving lines", "th"), "เส้นที่เปลี่ยน");
  assert.equal(localizeBoardTerm("Day master", "zh-Hans"), "日主");
  assert.equal(localizeBoardTerm("Original hexagram", "ko"), "본괘");
  assert.equal(localizeBoardTerm("Eight Gates", "th"), "แปดประตู");
  assert.equal(localizeBoardTerm("Action and passage layer", "ja"), "行動と通過のレイヤー");
  assert.equal(localizeBoardTerm("Southeast · 4", "th"), "ตะวันออกเฉียงใต้ · 4");
  assert.equal(localizeBoardTerm("Open", "ko"), "개문");
  assert.equal(localizeBoardTerm("Timing layers", "ja"), "時刻のレイヤー");
  assert.equal(localizeBoardTerm("Pillar cross-check", "ko"), "사주 교차 확인");
  assert.equal(localizeBoardTerm("Dream images", "vi"), "Hình ảnh giấc mơ");
  assert.equal(localizeBoardTerm("Celestial axes", "th"), "แกนท้องฟ้า");
});

test("daily rhythm board terms stay in the selected interface language", () => {
  assert.equal(localizeBoardTerm("Daily calendar", "zh-Hans"), "每日历法");
  assert.equal(localizeBoardTerm("Daily rhythm study field", "zh-Hant"), "每日時序研習場");
  assert.equal(localizeBoardTerm("Day window 3", "ja"), "時間帯 3");
  assert.equal(localizeBoardTerm("Grounded sequence", "ko"), "안정된 순서");
  assert.equal(localizeBoardTerm("Pause", "vi"), "Tạm dừng");
  assert.equal(localizeBoardTerm("Choose", "th"), "เลือกสรร");
});

test("daily rhythm chart does not leak English labels in localized interfaces", () => {
  const chart = createCompleteChart({ ...sharedInput, module: "daily" });
  const terms = [
    chart.board.label,
    ...chart.board.cells.flatMap((cell) => [cell.title, cell.subtitle, ...cell.items.flatMap((item) => [item.label, item.value])]),
    ...chart.sections.flatMap((section) => [section.title, section.lead, ...section.items.flatMap((item) => [item.label, item.value])]),
  ].filter(Boolean);

  for (const locale of ["zh-Hans", "zh-Hant", "ja", "ko", "th"]) {
    const leaked = terms.map((term) => localizeBoardTerm(term, locale)).filter((term) => /[A-Za-z]/.test(term));
    assert.deepEqual(leaked, [], `${locale} should not receive English daily chart terms`);
  }
  const vietnameseTerms = terms.map((term) => localizeBoardTerm(term, "vi"));
  assert.equal(vietnameseTerms.includes("Tham chiếu biểu tượng"), false);
});

test("unknown localized board terms retain their source text instead of a fabricated symbolic reference", () => {
  assert.equal(localizeBoardTerm("Unlisted board term", "zh-Hans"), "Unlisted board term");
  assert.equal(localizeBoardTerm("Unlisted board term", "th"), "Unlisted board term");
});

test("Zi Wei palace labels use the distinct twelve-palace vocabulary", () => {
  assert.equal(localizeZiWeiPalace("Life", "zh-Hans"), "命宫");
  assert.equal(localizeZiWeiPalace("Siblings", "ja"), "兄弟宮");
  assert.equal(localizeZiWeiPalace("Wealth", "ko"), "재백궁");
  assert.equal(localizeZiWeiPalace("Travel", "vi"), "Cung Thiên Di");
  assert.equal(localizeZiWeiPalace("Parents", "th"), "วังบิดามารดา");
});

test("BaZi deep study adds decade luck cycles and a day-master strength reference; plain BaZi does not", () => {
  const base = { ...sharedInput, gender: "yang" };
  const plain = createCompleteChart({ ...base, module: "bazi" });
  const deep = createCompleteChart({ ...base, module: "detail" });
  const ids = (chart) => [...chart.sections, ...(chart.board.sections ?? [])].map((section) => section.id);
  assert.ok(!ids(plain).includes("luck-cycles-detail"));
  assert.ok(!ids(plain).includes("day-master-strength"));
  assert.ok(ids(deep).includes("luck-cycles-detail"), ids(deep).join(","));
  assert.ok(ids(deep).includes("day-master-strength"));
  const all = [...deep.sections, ...(deep.board.sections ?? [])];
  const cycles = all.find((section) => section.id === "luck-cycles-detail");
  assert.ok(cycles.items.length >= 8);
  assert.ok(cycles.items.filter((item) => item.value.includes("Current")).length <= 1);
  const strength = all.find((section) => section.id === "day-master-strength");
  assert.ok(["Leaning strong", "Balanced", "Leaning weak"].includes(strength.items.at(-1).value));
  for (const locale of ["zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"]) {
    for (const term of ["Luck cycles in depth", "Day-master strength", "Supporting forces", "Strength reference", "Leaning strong", "Current"]) {
      assert.notEqual(localizeBoardTerm(term, locale), term, `${term} in ${locale}`);
    }
  }
});
