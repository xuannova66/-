import test from "node:test";
import assert from "node:assert/strict";
import { parseAssetAmount, displayAssetAmount } from "../app/asset-amounts.ts";

test("handles six, eight, nine and eighteen decimal assets without floating point", () => {
  for (const [decimals, expected] of [[6, 4990000n], [8, 499000000n], [9, 4990000000n], [18, 4990000000000000000n]]) {
    assert.equal(parseAssetAmount("4.99", decimals), expected);
    assert.equal(displayAssetAmount(expected, decimals), "4.99");
  }
});

test("rejects excess precision, invalid input and invalid decimals rather than rounding", () => {
  for (const [amount, decimals] of [["0.0000001", 6], ["1.000000001", 8]]) assert.throws(() => parseAssetAmount(amount, decimals), /ASSET_PRECISION_EXCEEDED/);
  for (const amount of ["0", "-1", "1e3", " 1", ".5", "1.", "NaN"]) assert.throws(() => parseAssetAmount(amount, 6), /INVALID_ASSET_AMOUNT/);
  for (const decimals of [-1, 37, 1.5]) assert.throws(() => parseAssetAmount("1", decimals), /INVALID_ASSET_DECIMALS/);
  assert.throws(() => displayAssetAmount(-1n, 6), /INVALID_ASSET_AMOUNT/);
});
