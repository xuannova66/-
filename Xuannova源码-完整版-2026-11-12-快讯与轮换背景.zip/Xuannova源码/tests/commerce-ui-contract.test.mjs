import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";

const root = new URL("../", import.meta.url);
const read = (path) => readFile(new URL(path, root), "utf8");
const { siteContent } = await import("../app/site-content.ts");

test("member checkout signs in with a wallet and pays through the BSC credit-store contract", async () => {
  const [memberCenter, walletConnect, policy] = await Promise.all([read("app/member-commerce-center.tsx"), read("app/wallet-connect.ts"), read("worker/commerce-policy.ts")]);
  assert.match(policy, /USDT · BNB Chain \(BEP20\)/);
  assert.match(policy, /USDT · TRON \(TRC20\)/);
  for (const wallet of ["MetaMask", "TokenPocket", "Binance Web3 Wallet", "OKX Wallet"]) assert.match(policy, new RegExp(wallet));
  assert.match(policy, /platformFeeBnb = "0\.00007"/);
  assert.match(memberCenter, /\/api\/auth\/wallet\/nonce/);
  assert.match(memberCenter, /\/api\/auth\/wallet\/verify/);
  assert.match(memberCenter, /\/api\/checkout\/config/);
  assert.match(memberCenter, /purchasePackage\(/);
  assert.match(memberCenter, /transactionHash: hash/);
  assert.match(memberCenter, /\/api\/orders/);
  assert.match(memberCenter, /\/api\/member\/me/);
  assert.match(memberCenter, /type="password"/);
  assert.match(memberCenter, /\/api\/auth\/register/);
  assert.match(memberCenter, /\/api\/orders\/manual/);
  assert.match(memberCenter, /paymentNetworks\.map/);
  assert.match(walletConnect, /eip6963:announceProvider/);
  assert.match(walletConnect, /wallet_switchEthereumChain/);
  assert.match(walletConnect, /functionName: "approve"/);
  assert.match(walletConnect, /functionName: "buy"/);
  assert.match(walletConnect, /value: fee/);
});

test("owner console is isolated behind its own admin session and can approve pending orders", async () => {
  const adminConsole = await read("app/admin-console.tsx");
  const adminPage = await read("app/admin/page.tsx");
  assert.match(adminConsole, /\/api\/auth\/admin\/login/);
  assert.match(adminConsole, /\/api\/admin\/orders/);
  assert.match(adminConsole, /decision: "approve"/);
  assert.match(adminPage, /<AdminConsole locale=\{locale\} \/>/);
});

test("owner console exposes member, invitation, ledger, and credit-adjustment operations", async () => {
  const adminConsole = await read("app/admin-console.tsx");
  assert.match(adminConsole, /\/api\/admin\/overview/);
  assert.match(adminConsole, /\/api\/admin\/members/);
  assert.match(adminConsole, /\/api\/admin\/invitations/);
  assert.match(adminConsole, /\/api\/admin\/ledger/);
  assert.match(adminConsole, /\/credits/);
  assert.match(adminConsole, /invitationCredits/);
  assert.match(adminConsole, /memberSearch/);
});

test("the operations console lives on its own /admin page and is not linked from the public navigation", async () => {
  const page = await read("app/page.tsx");
  assert.doesNotMatch(page, /className="admin-button"/);
  assert.doesNotMatch(page, /"membership",\s*"admin",/);
  assert.match(page, /window\.location\.replace\("\/admin"\)/);
});

test("new members can create an email account or connect one of the four supported wallets", async () => {
  const memberCenter = await read("app/member-commerce-center.tsx");
  // Email first: one form signs in, and a new email is registered with the entered password.
  assert.match(memberCenter, /useState<"wallet" \| "email">\("email"\)/);
  assert.match(memberCenter, /autoRegister: true/);
  assert.match(memberCenter, /minLength=\{6\}/);
  assert.match(memberCenter, /text\.linkWallet/);
  assert.match(memberCenter, /availableWallets\(\)/);
  assert.match(memberCenter, /signInWith\(wallet\.id\)/);
  assert.match(memberCenter, /walletInstallUrl\(wallet\.id\)/);
  assert.match(memberCenter, /signMessage\(provider, address, challenge\.message\)/);
});

test("member credits refresh after payment review instead of staying stale in the browser", async () => {
  const memberCenter = await read("app/member-commerce-center.tsx");
  assert.match(memberCenter, /setInterval/);
  assert.match(memberCenter, /onClick=\{\(\) => void refresh\(true\)\}/);
  assert.match(memberCenter, /refreshBalance/);
});

test("every localized homepage uses its own service and tool language", () => {
  assert.equal(siteContent["zh-Hant"].tools.bazi.title, "八字");
  assert.equal(siteContent["zh-Hant"].tools.bazi.subtitle, "先天能量藍圖解析");
  assert.equal(siteContent["zh-Hant"].services[0].title, "先天命盤研習");
  assert.equal(siteContent.ko.services[0].title, "명반 학습");
  assert.equal(siteContent.ko.tools.bazi.title, "사주");
  assert.equal(siteContent.vi.services[1].title, "Văn hóa phương hướng nhà ở");
  assert.equal(siteContent.vi.tools.bazi.title, "Bát Tự");
  assert.equal(siteContent.th.services[2].title, "วัฒนธรรมปฏิทินและการเลือกวัน");
  // Service copy stays within cultural learning (no energy-clearing or luck claims).
  for (const locale of Object.keys(siteContent)) assert.doesNotMatch(JSON.stringify(siteContent[locale].services), /负能量|改运|招财|clear stagnant energy|aura/i);
  assert.equal(siteContent.th.tools.bazi.title, "ปาจื้อ");
});
