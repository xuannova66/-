/** BSC fork simulation only: never submits transactions to the live chain. */
import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { readFileSync } from "node:fs";
import { createPublicClient, createWalletClient, custom, parseEther, parseAbi, getAddress, numberToHex } from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { getUsdcCheckoutQuote, purchaseUsdcPackage } from "../app/wallet-connect.ts";
import { BSC_USDC_ASSETS, BSC_V2_ROUTER } from "../app/usdc-payment-quote.ts";
import { treasuryAddress, platformFeeRecipient } from "../worker/commerce-policy.ts";
if (!process.env.XUANNOVA_TEST_TOOLS || !process.env.XUANNOVA_BSC_FORK_RPC) throw new Error("Set XUANNOVA_TEST_TOOLS and XUANNOVA_BSC_FORK_RPC for the local BSC fork test");
const require = createRequire(`${process.env.XUANNOVA_TEST_TOOLS}/package.json`);
const solc = require("solc"), ganache = require("ganache");
const source = readFileSync(new URL("../contracts/UsdcCheckoutPrototype.sol", import.meta.url), "utf8");
const output = JSON.parse(solc.compile(JSON.stringify({ language: "Solidity", sources: { "Checkout.sol": { content: source } }, settings: { optimizer: { enabled: true, runs: 200 }, outputSelection: { "*": { "*": ["abi", "evm.bytecode.object"] } } } })));
assert.deepEqual((output.errors ?? []).filter((item) => item.severity === "error"), []);
const artifact = output.contracts["Checkout.sol"].UsdcCheckoutPrototype;
const pairs = {
  USDC: "0xd99c7F6C65857AC913a8f880A4cb84032AB2FC5b",
  USDT: "0x16b9a82891338f9bA80E2D6970FddA79D1eb0daE",
  ASTER: "0x8A71e31Fd7259b52b5B59317dA8A45D3612ED42b",
};
const tokenAbi = parseAbi(["function transfer(address,uint256) returns (bool)", "function balanceOf(address) view returns (uint256)"]);
const pairAbi = parseAbi(["function sync()"]);

test("four-payment checkout against a local fork of real BSC contracts", { timeout: 180000 }, async () => {
  const provider = ganache.provider({ logging: { quiet: true }, chain: { chainId: 56, hardfork: "shanghai" }, fork: { url: process.env.XUANNOVA_BSC_FORK_RPC }, wallet: { unlockedAccounts: Object.values(pairs), defaultBalance: 100 } });
  try {
    // Ganache's Shanghai VM cannot execute the mainnet fee wallet's EIP-7702
    // delegation marker. Clear it ON THIS LOCAL FORK ONLY; a separate mainnet
    // eth_call must check whether the real wallet accepts the BNB transfer.
    await provider.request({ method: "evm_setAccountCode", params: [platformFeeRecipient, "0x"] });
    const accounts = await provider.request({ method: "eth_accounts", params: [] });
    const account = privateKeyToAccount(provider.getInitialAccounts()[accounts[0].toLowerCase()].secretKey);
    const pub = createPublicClient({ transport: custom(provider), pollingInterval: 100 });
    const wallet = createWalletClient({ account, transport: custom(provider) });
    // For the local fork only, impersonate liquid pool addresses to fund a disposable wallet.
    for (const name of ["USDC", "USDT", "ASTER"]) {
      const pair = pairs[name], token = BSC_USDC_ASSETS[name];
      await provider.request({ method: "evm_setAccountBalance", params: [pair, numberToHex(parseEther("2"))] });
      const poolWallet = createWalletClient({ account: getAddress(pair), transport: custom(provider) });
      const hash = await poolWallet.writeContract({ chain: null, address: token, abi: tokenAbi, functionName: "transfer", args: [account.address, parseEther(name === "ASTER" ? "30" : "20")], gas: 500000n });
      assert.equal((await pub.waitForTransactionReceipt({ hash })).status, "success");
      const sync = await wallet.writeContract({ chain: null, address: pair, abi: pairAbi, functionName: "sync", gas: 500000n });
      assert.equal((await pub.waitForTransactionReceipt({ hash: sync })).status, "success");
    }
    const fee = 70000000000000n;
    const deploy = await wallet.deployContract({ chain: null, abi: artifact.abi, bytecode: `0x${artifact.evm.bytecode.object}`, args: [BSC_USDC_ASSETS.USDC, BSC_USDC_ASSETS.USDT, BSC_USDC_ASSETS.ASTER, BSC_V2_ROUTER, treasuryAddress, platformFeeRecipient, fee] });
    const store = (await pub.waitForTransactionReceipt({ hash: deploy })).contractAddress;
    const config = { chainId: 56, chainHexId: "0x38", chainName: "BNB Smart Chain", nativeSymbol: "BNB", rpcUrls: [], explorerUrl: "https://bscscan.com", testnet: false, usdtAddress: BSC_USDC_ASSETS.USDT, contractAddress: null, usdcCheckoutAddress: store, platformFeeWei: fee.toString(), confirmations: 1, enabled: true };
    const balance = () => pub.readContract({ address: BSC_USDC_ASSETS.USDC, abi: tokenAbi, functionName: "balanceOf", args: [treasuryAddress] });
    for (const token of ["BNB", "USDC", "USDT", "ASTER"]) {
      const quote = await getUsdcCheckoutQuote({ provider, config, packageId: "seed", token });
      const before = await balance();
      const hash = await purchaseUsdcPackage({ provider, address: account.address, packageId: "seed", config, quote });
      assert.equal((await pub.getTransactionReceipt({ hash })).status, "success");
      assert.equal((await balance()) - before, parseEther("4.99"), `${token} settles exactly 4.99 USDC`);
    }
  } finally { await provider.disconnect(); }
});
