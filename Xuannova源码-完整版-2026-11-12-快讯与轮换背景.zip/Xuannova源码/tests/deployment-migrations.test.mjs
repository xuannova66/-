import assert from "node:assert/strict";
import { readdir, readFile } from "node:fs/promises";
import test from "node:test";

test("deployment bundle contains the commerce schema migration", async () => {
  const journal = JSON.parse(await readFile(new URL("../drizzle/meta/_journal.json", import.meta.url), "utf8"));
  assert.ok(journal.entries.length > 0, "the deployed D1 database needs at least one recorded migration");

  const files = await readdir(new URL("../drizzle/", import.meta.url));
  const sqlFile = files.find((file) => file.endsWith(".sql"));
  assert.ok(sqlFile, "the deployed D1 database needs a SQL migration file");

  const sql = await readFile(new URL(`../drizzle/${sqlFile}`, import.meta.url), "utf8");
  for (const table of ["members", "payment_orders", "credit_ledger", "admin_audit"]) {
    assert.match(sql, new RegExp(`CREATE TABLE IF NOT EXISTS ${table}`));
  }
  assert.match(sql, /payment_order_approved_credit_once/);
});
