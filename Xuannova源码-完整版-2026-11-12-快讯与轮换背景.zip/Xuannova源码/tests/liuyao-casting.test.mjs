import assert from "node:assert/strict";
import test from "node:test";

const {
  resolveThreeCoinThrow,
  lineStatesFromThrows,
} = await import("../app/liuyao-casting.ts");

test("three-coin casting follows the standard six-seven-eight-nine line mapping", () => {
  assert.deepEqual(
    resolveThreeCoinThrow(["tails", "tails", "tails"]),
    { coins: ["tails", "tails", "tails"], total: 6, yang: false, moving: true, kind: "old-yin" },
  );
  assert.deepEqual(
    resolveThreeCoinThrow(["heads", "tails", "tails"]),
    { coins: ["heads", "tails", "tails"], total: 7, yang: true, moving: false, kind: "young-yang" },
  );
  assert.deepEqual(
    resolveThreeCoinThrow(["heads", "heads", "tails"]),
    { coins: ["heads", "heads", "tails"], total: 8, yang: false, moving: false, kind: "young-yin" },
  );
  assert.deepEqual(
    resolveThreeCoinThrow(["heads", "heads", "heads"]),
    { coins: ["heads", "heads", "heads"], total: 9, yang: true, moving: true, kind: "old-yang" },
  );
});

test("six recorded coin throws preserve bottom-to-top lines and moving positions", () => {
  const casts = [
    resolveThreeCoinThrow(["tails", "tails", "tails"]),
    resolveThreeCoinThrow(["heads", "tails", "tails"]),
    resolveThreeCoinThrow(["heads", "heads", "tails"]),
    resolveThreeCoinThrow(["heads", "heads", "heads"]),
    resolveThreeCoinThrow(["heads", "tails", "tails"]),
    resolveThreeCoinThrow(["heads", "heads", "tails"]),
  ];

  assert.deepEqual(lineStatesFromThrows(casts), {
    lines: [false, true, false, true, true, false],
    movingLines: [true, false, false, true, false, false],
  });
});
