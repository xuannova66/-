import test from "node:test";
import assert from "node:assert/strict";
import { saveRecoveryCandidate, flushRecoveryCandidates } from "../app/payment-recovery-buffer.draft.ts";

function memory() {const values=new Map();return {getItem:k=>values.get(k)??null,setItem:(k,v)=>values.set(k,v),removeItem:k=>values.delete(k),values};}
const entry={memberId:"member_1",orderId:"order_1",chain:"ethereum",transactionId:`0x${"AB".repeat(32)}`,createdAt:"2026-01-01T00:00:00.000Z"};
test("buffers submitted hashes without treating them as paid and restores per member",async()=>{
  const storage=memory();saveRecoveryCandidate(storage,entry);saveRecoveryCandidate(storage,entry);
  saveRecoveryCandidate(storage,{...entry,memberId:"other",orderId:"other"});
  assert.deepEqual(await flushRecoveryCandidates(storage,"member_1",async()=>{throw Error("offline");}),{sent:0,pending:1});
  let calls=0;
  assert.deepEqual(await flushRecoveryCandidates(storage,"member_1",async x=>{calls++;assert.equal(x.transactionId,"ab".repeat(32));return {recorded:false};}),{sent:1,pending:0});
  assert.equal(calls,1);
  assert.deepEqual(await flushRecoveryCandidates(storage,"other",async()=>({recorded:true})),{sent:1,pending:0});
  assert.equal(storage.values.size,0);
});
test("never drops records on an invalid response, corrupt storage or storage failure",async()=>{
  const storage=memory();saveRecoveryCandidate(storage,entry);
  assert.deepEqual(await flushRecoveryCandidates(storage,"member_1",async()=>({})),{sent:0,pending:1});
  const key=[...storage.values.keys()][0];storage.values.set(key,"not-json");
  assert.throws(()=>saveRecoveryCandidate(storage,entry),/RECOVERY_BUFFER_CORRUPT/);
  assert.throws(()=>saveRecoveryCandidate({...memory(),setItem(){throw Error("quota");}},entry),/RECOVERY_STORAGE_UNAVAILABLE/);
});
