import test from "node:test";
import assert from "node:assert/strict";
import { connectEvmForNetwork, assertEvmSession, watchEvmSession } from "../app/evm-wallet-session.draft.ts";

const address = "0x746C10c7CaA5Afa67aAC559e3a7CEE6B971e659C";
const other = "0x1111111111111111111111111111111111111111";
function makeWallet({ refusal = false, changeAccount = false, fakeSwitch = false } = {}) {
  let selected = "0x1", accounts = [address]; const calls = [], listeners = new Map();
  return { calls, listeners, setChain: (v) => { selected = v; }, setAccounts: (v) => { accounts = v; },
    on: (event, handler) => listeners.set(event, handler), removeListener: (event) => listeners.delete(event),
    request: async ({ method, params }) => { calls.push(method); if(method === "eth_requestAccounts") return accounts;
      if(method === "eth_accounts") return accounts; if(method === "eth_chainId") return selected;
      if(method === "wallet_switchEthereumChain") { if(refusal) throw Object.assign(new Error("rejected"),{code:4001}); if(!fakeSwitch) selected = params[0].chainId; if(changeAccount) accounts = [other]; return null; }
      throw new Error("unexpected method"); } };
}
test("connects on user action, switches chain and rechecks both chain and wallet", async () => {
  const wallet=makeWallet(); const session=await connectEvmForNetwork(wallet,"bsc");
  assert.equal(session.chainId,"0x38"); assert.equal(session.address,address); await assertEvmSession(wallet,session);
  wallet.setChain("0x1"); await assert.rejects(assertEvmSession(wallet,session),/WALLET_NETWORK_CHANGED/);
  wallet.setChain("0x38"); wallet.setAccounts([other]); await assert.rejects(assertEvmSession(wallet,session),/WALLET_ACCOUNT_CHANGED/);
  assert.ok(!wallet.calls.includes("eth_sendTransaction"));
});
test("rejects declined/ineffective switch or account change and invalidates stale UI", async () => {
  await assert.rejects(connectEvmForNetwork(makeWallet({refusal:true}),"bsc"),/rejected/);
  await assert.rejects(connectEvmForNetwork(makeWallet({fakeSwitch:true}),"bsc"),/WALLET_NETWORK_NOT_SWITCHED/);
  await assert.rejects(connectEvmForNetwork(makeWallet({changeAccount:true}),"bsc"),/WALLET_ACCOUNT_CHANGED/);
  const wallet=makeWallet(); let invalidations=0; const stop=watchEvmSession(wallet,()=>invalidations++);
  wallet.listeners.get("chainChanged")(); wallet.listeners.get("accountsChanged")(); wallet.listeners.get("disconnect")();
  assert.equal(invalidations,3); stop(); assert.equal(wallet.listeners.size,0);
});
