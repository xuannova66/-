import assert from "node:assert/strict";
import test from "node:test";

const { createLocalSession, isValidEmail } = await import("../app/local-account.ts");
const { contactConfig, hasConfiguredContact } = await import("../app/contact-config.ts");

test("local account validates email and keeps the session device-local", () => {
  assert.equal(isValidEmail("reader@example.com"), true);
  assert.equal(isValidEmail("reader-at-example"), false);
  assert.deepEqual(createLocalSession(" Reader@Example.com "), {
    email: "reader@example.com",
    mode: "local",
  });
});

test("publishes the owner-provided contact handles without exposing backend credentials", () => {
  assert.equal(contactConfig.supportEmail, "Xuannova66@gmail.com");
  assert.equal(contactConfig.telegram.url, "https://t.me/xuannova3");
  assert.equal(contactConfig.telegram.handle, "@xuannova3");
  assert.equal(contactConfig.x.url, "https://x.com/xuannova");
  assert.equal(contactConfig.x.handle, "@xuannova");
  assert.equal(hasConfiguredContact, true);
});
