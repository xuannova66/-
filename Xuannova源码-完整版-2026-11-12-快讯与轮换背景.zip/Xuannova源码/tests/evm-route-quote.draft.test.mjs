import test from "node:test";
import assert from "node:assert/strict";
import {quoteEvmDraft} from "../app/evm-route-quote.draft.ts";
const asset="0x1111111111111111111111111111111111111111",stable="0x2222222222222222222222222222222222222222",middle="0x3333333333333333333333333333333333333333",router="0x4444444444444444444444444444444444444444";
const config={network:"ethereum",router,settlement:stable,assets:[{symbol:"TEST",address:asset,decimals:8,transferFee:"none-verified",evidence:{identityVerified:true,decimalsVerified:true,transferBehavior:"standard",routeVerified:true,enabled:true}}],intermediates:[middle]};
const reader={getChainId:async()=>1,quote:async(_router,out,path)=>path.length===2?[100n,out]:[90n,95n,out]};
const input={config,reader,packageId:"seed",asset,paths:[[asset,stable],[asset,middle,stable]],clock:()=>1000,slippageBps:100,getReference:async()=>({inputUnits:90n,observedAt:990})};
test("quotes configured exact output paths, selects lowest input and rounds maximum up",async()=>{
 const quote=await quoteEvmDraft(input);assert.equal(quote.outputUnits,4990000n);assert.equal(quote.inputUnits,90n);assert.equal(quote.maxInputUnits,91n);assert.deepEqual(quote.path,[asset,middle,stable]);assert.equal(quote.expiresAt,1020);
});
test("quote expires with its reference and rejects expired or future references",async()=>{
 assert.equal((await quoteEvmDraft({...input,getReference:async()=>({inputUnits:90n,observedAt:971})})).expiresAt,1001);
 await assert.rejects(quoteEvmDraft({...input,getReference:async()=>({inputUnits:90n,observedAt:970})}),/INVALID_REFERENCE_PRICE/);
 await assert.rejects(quoteEvmDraft({...input,getReference:async()=>({inputUnits:90n,observedAt:1001})}),/INVALID_REFERENCE_PRICE/);
});
test("fails closed on wrong chain, unverified token tax, invalid path and unavailable routes",async()=>{
 await assert.rejects(quoteEvmDraft({...input,reader:{...reader,getChainId:async()=>56}}),/WRONG_CHAIN/);
 await assert.rejects(quoteEvmDraft({...input,config:{...config,assets:[{...config.assets[0],transferFee:"unknown"}]}}),/TOKEN_TRANSFER_FEE_UNSUPPORTED/);
 await assert.rejects(quoteEvmDraft({...input,config:{...config,assets:[{...config.assets[0],evidence:{...config.assets[0].evidence,identityVerified:false}}]}}),/ASSET_NOT_APPROVED/);
 await assert.rejects(quoteEvmDraft({...input,paths:[[asset,router,stable]]}),/INVALID_ROUTE/);
 await assert.rejects(quoteEvmDraft({...input,reader:{...reader,quote:async()=>{throw Error("no liquidity");}}}),/NO_VALID_ROUTE/);
 await assert.rejects(quoteEvmDraft({...input,reader:{...reader,quote:async()=>[1n,2n]}}),/NO_VALID_ROUTE/);
 await assert.rejects(quoteEvmDraft({...input,getReference:async()=>({inputUnits:70n,observedAt:990})}),/QUOTE_PRICE_DEVIATION/);
 await assert.rejects(quoteEvmDraft({...input,getReference:async()=>({inputUnits:100n,observedAt:990})}),/QUOTE_PRICE_DEVIATION/);
 await assert.rejects(quoteEvmDraft({...input,getReference:async()=>({inputUnits:90n,observedAt:900})}),/INVALID_REFERENCE_PRICE/);
 await assert.rejects(quoteEvmDraft({...input,getReference:async()=>{throw Error("unavailable");}}),/REFERENCE_PRICE_UNAVAILABLE/);
 let calls=0;await quoteEvmDraft({...input,getReference:async()=>{calls++;return {inputUnits:90n,observedAt:1000};}});await quoteEvmDraft({...input,getReference:async()=>{calls++;return {inputUnits:90n,observedAt:1000};}});assert.equal(calls,2);
});
