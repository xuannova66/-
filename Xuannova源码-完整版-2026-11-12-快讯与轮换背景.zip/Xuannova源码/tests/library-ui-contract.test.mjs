import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

test("library explorer presents a compact reading list with the full text on the site", () => {
  const explorer = readFileSync("app/library-explorer.tsx", "utf8");
  assert.match(explorer, /<LibraryReader /, "every record opens the on-site reader");
  assert.doesNotMatch(explorer, /公开原典|公開原典|Public source/, "no 'public original source' wording");
  assert.match(explorer, /archive-list/);
  assert.doesNotMatch(explorer, /backgroundImage/);
  assert.match(explorer, /zh-Hant/);
  assert.match(explorer, /ja:/);
  assert.match(explorer, /ko:/);
  assert.match(explorer, /vi:/);
  assert.match(explorer, /th:/);
});

test("every archive record is rendered with an authored book cover in list and record views", () => {
  const explorer = readFileSync("app/library-explorer.tsx", "utf8");
  const styles = readFileSync("app/globals.css", "utf8");
  assert.match(explorer, /function ArchiveBookCover/);
  assert.match(explorer, /data-cover=\{work\.cover\}/);
  assert.match(explorer, /archive-book-cover/);
  assert.match(explorer, /<ArchiveBookCover work=\{work\} locale=\{locale\} \/>/);
  assert.match(explorer, /<ArchiveBookCover work=\{selected\} locale=\{locale\} large \/>/);
  assert.match(styles, /\.archive-book-cover/);
  assert.match(styles, /\[data-cover="ink"\]/);
});

test("dedicated credits route is reachable from navigation and paywalls", () => {
  const suite = readFileSync("app/study-suite.ts", "utf8");
  const navigation = readFileSync("app/study-navigation.ts", "utf8");
  const page = readFileSync("app/page.tsx", "utf8");
  assert.match(suite, /\| "credits"/);
  assert.match(suite, /credits: string/);
  assert.match(navigation, /"credits"/);
  assert.match(page, /data-route="credits"/);
  assert.match(page, /navigate\("credits"\)/);
});
