// 分享来源统计: posters made/saved/shared and visits are counted per day; new accounts keep the first share source.
import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import test from "node:test";

const { openDatabase } = await import("../server/sqlite-db.ts");
const { handleCommerceApi } = await import("../worker/commerce-api.ts");
const { shareReport } = await import("../worker/share-stats.ts");
const ORIGIN = "https://xuannova.test";
const PURCHASES = "SELECT member_id, SUM(amount) AS total, SUM(credits) AS credits FROM (SELECT member_id, CAST(amount_usdt AS REAL) AS amount, credits FROM payment_orders WHERE status = 'approved' UNION ALL SELECT member_id, CAST(amount_usd AS REAL) AS amount, credits FROM dodo_orders WHERE status = 'paid') GROUP BY member_id";

function freshEnv() {
  const db = openDatabase(":memory:");
  for (const file of readdirSync(new URL("../migrations/", import.meta.url)).filter((name) => name.endsWith(".sql")).sort()) db.raw.exec(readFileSync(new URL(`../migrations/${file}`, import.meta.url), "utf8"));
  return { DB: db, SESSION_SECRET: "test-session-signing-key-that-is-long-enough" };
}
function client(env, cookies) {
  const jar = new Map(Object.entries(cookies));
  return async (path, body, method = body === undefined ? "GET" : "POST", origin = ORIGIN) => {
    const headers = { origin, cookie: [...jar].map(([k, v]) => `${k}=${v}`).join("; "), "content-type": "application/json" };
    const response = await handleCommerceApi(new Request(`${ORIGIN}${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) }), env);
    for (const cookie of response.headers.getSetCookie?.() ?? []) { const [pair] = cookie.split(";"); const [name, value] = pair.split("="); if (value) jar.set(name, value); else jar.delete(name); }
    return { status: response.status, body: await response.json() };
  };
}

test("poster counts: valid sources and actions only, same-origin, repeats within 10 s ignored", async () => {
  const env = freshEnv();
  const c = client(env, { xn_device: "device-share-000000000001" });
  assert.equal((await c("/api/stats/share", { source: "daily-card", action: "made" })).status, 200);
  assert.equal((await c("/api/stats/share", { source: "daily-card", action: "made" })).body.throttled, true);
  assert.equal((await c("/api/stats/share", { source: "daily-card", action: "saved" })).status, 200);
  assert.equal((await c("/api/stats/share", { source: "evil", action: "made" })).status, 400);
  assert.equal((await c("/api/stats/share", { source: "daily-card", action: "delete" })).status, 400);
  assert.equal((await c("/api/stats/share", { source: "daily-card", action: "made" }, "POST", "https://evil.test")).status, 403);
  const other = client(env, { xn_device: "device-share-000000000002" });
  await other("/api/stats/share", { source: "daily-card", action: "made" });
  const rows = env.DB.raw.prepare("SELECT action, count FROM share_stats WHERE source = 'daily-card' ORDER BY action").all();
  assert.deepEqual(rows.map((r) => [r.action, r.count]), [["made", 2], ["saved", 1]]);
});

test("a new account keeps the share source of the device; the inviter sees where invitees came from", async () => {
  const env = freshEnv();
  const inviter = client(env, { xn_device: "device-share-000000000010" });
  assert.equal((await inviter("/api/auth/register", { email: "host@example.com", password: "secret-pass" })).status, 201);
  const code = env.DB.raw.prepare("SELECT invite_code FROM members WHERE email = 'host@example.com'").get().invite_code;
  const friend = client(env, { xn_device: "device-share-000000000011", xn_src: "daily-card" });
  assert.equal((await friend("/api/auth/register", { email: "friend@example.com", password: "secret-pass", inviteCode: code })).status, 201);
  const stranger = client(env, { xn_device: "device-share-000000000012", xn_src: "not-a-source" });
  assert.equal((await stranger("/api/auth/register", { email: "plain@example.com", password: "secret-pass", inviteCode: code })).status, 201);
  const sources = Object.fromEntries(env.DB.raw.prepare("SELECT email, signup_source FROM members").all().map((r) => [r.email, r.signup_source]));
  assert.deepEqual(sources, { "host@example.com": null, "friend@example.com": "daily-card", "plain@example.com": null });
  const team = (await inviter("/api/member/team")).body;
  assert.equal(team.invited, 2);
  assert.deepEqual(team.sources.map((r) => [r.source, r.invited]).sort(), [["daily-card", 1], ["other", 1]]);
  const report = await shareReport(env.DB, new Date(), 30, PURCHASES);
  const daily = report.rows.find((row) => row.source === "daily-card");
  assert.equal(daily.signups, 1); assert.equal(daily.invitedSignups, 1); assert.equal(report.rows[0].source, "daily-card");
  assert.equal((await inviter("/api/admin/share-report")).status === 401 || (await inviter("/api/admin/share-report")).status === 403, true);
});
