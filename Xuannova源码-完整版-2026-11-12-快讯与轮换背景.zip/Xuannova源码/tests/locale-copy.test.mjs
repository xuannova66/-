import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";

const { uiCopy } = await import("../app/ui-copy.ts");
const { cleanVisibleBoardText, localizeBoardTerm, localizeLunarDate } = await import("../app/complete-chart-board.tsx");
const { createCompleteChart } = await import("../app/chart-model.ts");
const { siteContent } = await import("../app/site-content.ts");
const { suiteCopy } = await import("../app/study-suite.ts");
const { classicalWorks, localizedLibraryTitle } = await import("../app/library-catalogue.ts");
const interpretationModule = await import("../app/interpretation-panel.tsx");

test("all seven interface languages include stage and chart actions", () => {
  for (const locale of ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"]) {
    assert.ok(uiCopy(locale).chart.openReading.length > 0);
    assert.ok(uiCopy(locale).stage.generating.length > 0);
    assert.ok(uiCopy(locale).account.access.length > 0);
    assert.ok(uiCopy(locale).home.sourceLabel.length > 0);
    assert.equal(uiCopy(locale).home.ribbon.length, 7);
    assert.ok(uiCopy(locale).footer.brand.length > 0);
    assert.ok(suiteCopy[locale].nav.homeLabel.length > 0);
    assert.ok(suiteCopy[locale].nav.primaryNavigation.length > 0);
    assert.ok(suiteCopy[locale].nav.openNavigation.length > 0);
    assert.ok(suiteCopy[locale].nav.mobileNavigation.length > 0);
  }
});

test("unknown runtime locale falls back to complete English interface copy", () => {
  assert.equal(uiCopy("not-a-locale").chart.openReading, uiCopy("en").chart.openReading);
});

test("phone typography and route error recovery remain localized", async () => {
  const [mobileStyles, errorBoundary] = await Promise.all([
    readFile(new URL("../app/mobile-polish.css", import.meta.url), "utf8"),
    readFile(new URL("../app/error.tsx", import.meta.url), "utf8"),
  ]);
  assert.match(mobileStyles, /\.bazi-row > span, \.bazi-context-rail dd, \.ziwei-palace dd \{ font-size: 12.5px; \}/);
  assert.match(mobileStyles, /@media \(max-width: 650px\)[\s\S]*min-height: 44px/);
  for (const locale of ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"]) {
    assert.match(errorBoundary, new RegExp(`^.*${locale.replace(/[.*+?^${}()|[\\]\\\\]/g, "\\\\$&")}.*$`, "m"));
  }
  assert.match(errorBoundary, /onClick=\{\(\) => reset\(\)\}/);
});

test("every published language has specific AI service-state copy", () => {
  assert.ok(interpretationModule.interpretationCopy, "interpretation copy must be testable as a published locale record");
  for (const locale of ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"]) {
    const text = interpretationModule.interpretationCopy[locale];
    for (const key of ["serviceError", "configurationError", "providerBusyError", "responseRetryError"]) {
      assert.equal(typeof text[key], "string", `${locale} must translate ${key}`);
      assert.ok(text[key].trim().length > 0, `${locale} must not leave ${key} blank`);
    }
  }
});

test("English home mark uses the Xuannova brand", () => {
  assert.equal(uiCopy("en").home.heroBrand, "Xuannova");
  assert.equal(uiCopy("en").footer.brand, "Xuannova");
});

test("the visible header uses the shared localized brand copy", async () => {
  const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
  assert.match(page, /<b>\{shared\.home\.heroBrand\}<\/b>/);
  assert.match(page, /<span>Xuannova<\/span>/);
  assert.doesNotMatch(page, /XUANYUAN · INSTITUTE/);
});

test("non-Chinese interfaces do not reuse Chinese decorative tool marks", async () => {
  const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
  assert.match(page, /function localizedMark\(mark: string, locale: Locale\)/);
  assert.match(page, /ko: \{[^}]*"参": "통"/);
  assert.match(page, /vi: \{[^}]*"参": "T"/);
  assert.match(page, /th: \{[^}]*"参": "ร"/);
  assert.match(page, /<i>\{localizedMark\(card\.mark, locale\)\}<\/i>/);
  assert.match(page, /function localizedFloatingMarks\(locale: Locale\)/);
  assert.match(page, /\{localizedFloatingMarks\(locale\)\.map/);
});

test("navigation, result and specialist-board labels remain locale-aware", async () => {
  const [page, board] = await Promise.all([
    readFile(new URL("../app/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/complete-chart-board.tsx", import.meta.url), "utf8"),
  ]);

  for (const leakedLabel of [
    'aria-label="Xuanyuan home"',
    'aria-label="Primary navigation"',
    'aria-label="Open navigation"',
    'aria-label="Mobile navigation"',
    "玄院 · LOCAL RESULT",
  ]) {
    assert.equal(page.includes(leakedLabel), false, `page must not retain ${leakedLabel}`);
  }

  assert.equal(board.includes('aria-label="BaZi four-pillar matrix"'), false);
  assert.equal(board.includes('aria-label="Zi Wei twelve-palace chart"'), false);
  assert.match(board, /baziMatrix: string; ziweiMatrix: string/);
});

test("study visuals localize their calendar and seasonal labels", async () => {
  const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
  assert.match(page, /const studyVisualCopy: Record<Locale,/);
  assert.match(page, /<StudyVisual result=\{result\} visual=\{visual\} locale=\{locale\}/);
  assert.doesNotMatch(page, /<small>SEASONAL RHYTHM<\/small>/);
});

test("board labels and generated identifiers are localized away from English", () => {
  assert.equal(localizeBoardTerm("Eight Gates", "th"), "แปดประตู");
  assert.notEqual(localizeBoardTerm("palace · 1", "ja"), "palace · 1");
  assert.notEqual(localizeBoardTerm("Original line · 2", "ko"), "Original line · 2");
  assert.equal(localizeBoardTerm("Ten-God relationships", "zh-Hans"), "十神关系");
  assert.equal(localizeBoardTerm("pillar 0", "zh-Hans"), "四柱 01");
  assert.equal(localizeBoardTerm("Year +0", "zh-Hans"), "流年 +0");
  assert.equal(localizeBoardTerm("涧下水", "vi"), "Giản Hạ Thủy");
  assert.equal(localizeBoardTerm("涧下水", "th"), "น้ำใต้ลำธาร");
  assert.equal(localizeBoardTerm("涧下水", "ko"), "간하수");
  assert.equal(localizeLunarDate("一九九四年七月十二", "vi"), "Âm lịch 12/07/1994");
  assert.equal(localizeLunarDate("一九九四年七月十二", "th"), "จันทรคติ 12/07/1994");
});

test("published chart copy removes placeholder symbolic and reference labels in every language", () => {
  const blockedTerms = {
    en: /\bsymbolic\b|\breference\b/i,
    "zh-Hans": /象征|参照/,
    "zh-Hant": /象徵|參照/,
    ja: /象徴|参照/,
    ko: /상징|참조|참고/,
    vi: /biểu tượng|tham chiếu/i,
    th: /สัญลักษณ์|อ้างอิง/,
  };
  const labels = [
    "Symbolic and environmental layer",
    "A symbolic seasonal sequence",
    "Palace reference",
    "Plate reference",
    "Location reference: Global",
  ];

  for (const locale of Object.keys(blockedTerms)) {
    for (const label of labels) {
      assert.doesNotMatch(cleanVisibleBoardText(label, locale), blockedTerms[locale], `${locale} must not publish placeholder reference language`);
    }
  }
});

test("new method-specific chart layers never fall back to English in the six non-English interfaces", () => {
  const methodTerms = ["Pillar shen-sha", "Palace condition", "Bureau frame", "Hidden spirits", "Day-night noble", "True solar time"];
  const expected = {
    "zh-Hans": "柱神煞", "zh-Hant": "柱神煞", ja: "柱の神煞", ko: "주신살", vi: "Thần sát theo trụ", th: "เสินซาตามเสา",
  };
  for (const locale of ["zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"]) {
    for (const term of methodTerms) {
      assert.notEqual(localizeBoardTerm(term, locale), term, `${locale} must localize ${term}`);
    }
    assert.equal(localizeBoardTerm("Pillar shen-sha", locale), expected[locale]);
  }
});

test("all generated chart copy is translated in every non-English interface", () => {
  const input = {
    birthDate: "1994-08-18",
    birthTime: "12:00",
    calendar: "solar",
    focus: "焦点",
    name: "玄",
    companionName: "同参",
    module: "qimen",
    version: 1,
    place: "Global",
  };
  const modules = ["bazi", "detail", "compatibility", "liuyao", "ziwei", "qizheng", "qimen", "daliuren", "meihua", "jinkoujue", "heluo", "tieban", "taiyi", "zhuzhai", "zeri", "wenshi", "mirror", "toolkit-time", "toolkit-elements", "toolkit-dream", "toolkit-name", "toolkit-tarot", "toolkit-iching", "toolkit-natal", "hecan", "daily"];
  const terms = new Set();

  for (const tool of modules) {
    const chart = createCompleteChart({ ...input, module: tool });
    const values = [
      chart.board.label,
      ...chart.board.cells.flatMap((cell) => [cell.title, cell.subtitle, ...cell.items.flatMap((item) => [item.label, item.value])]),
      ...chart.sections.flatMap((section) => [section.title, section.lead, ...section.items.flatMap((item) => [item.label, item.value])]),
    ];
    for (const value of values) if (typeof value === "string" && /[A-Za-z]/.test(value)) terms.add(value);
  }

  for (const locale of ["zh-Hans", "zh-Hant", "ja", "ko", "th"]) {
    const leaked = [...terms].map((term) => localizeBoardTerm(term, locale)).filter((term) => /[A-Za-z]/.test(term));
    assert.deepEqual(leaked, [], `${locale} must not expose raw English chart copy`);
  }
  const untranslatedVietnamese = [...terms].filter((term) => localizeBoardTerm(term, "vi") === term);
  assert.deepEqual(untranslatedVietnamese, [], "Vietnamese must not expose raw English chart copy");
});

test("Vietnamese, Thai, and Korean chart surfaces do not fall back to Han-script chart text", () => {
  const modules = ["hecan", "bazi", "detail", "compatibility", "liuyao", "ziwei", "qizheng", "qimen", "daliuren", "meihua", "jinkoujue", "heluo", "tieban", "taiyi", "zhuzhai", "zeri", "wenshi", "mirror", "toolkit-time", "toolkit-elements", "toolkit-dream", "toolkit-name", "toolkit-tarot", "toolkit-iching", "toolkit-natal", "daily"];
  const strings = new Set();
  const collect = (value) => {
    if (typeof value === "string") strings.add(value);
    else if (Array.isArray(value)) value.forEach(collect);
    else if (value && typeof value === "object") Object.values(value).forEach(collect);
  };

  for (const method of modules) {
    const chart = createCompleteChart({
      birthDate: "1994-08-18",
      birthTime: "12:00",
      calendar: "solar",
      focus: "Career direction",
      name: "Sample",
      companionName: "Partner",
      module: method,
      version: 1,
      place: "Singapore",
    });
    collect(chart.board);
    collect(chart.sections);
    collect(chart.calendar.zodiac);
    collect(chart.calendar.naYin);
    collect(chart.calendar.yi);
    collect(chart.calendar.ji);
  }

  for (const locale of ["ko", "vi", "th"]) {
    for (const value of strings) {
      assert.doesNotMatch(localizeBoardTerm(value, locale), /[\u3400-\u9fff]/, `${locale} chart output must not retain untranslated Han text: ${value}`);
    }
  }
});

test("every archive book cover and title has a localized reading in each published language", () => {
  for (const work of classicalWorks) {
    for (const locale of ["zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"]) {
      const title = localizedLibraryTitle(work, locale);
      assert.ok(title.trim().length > 0, `${work.id} needs a ${locale} library title`);
    }
    for (const locale of ["ko", "vi", "th"]) {
      assert.doesNotMatch(localizedLibraryTitle(work, locale), /[\u3400-\u9fff]/, `${work.id} must not publish a Han-script title in ${locale}`);
    }
  }
});

test("dense chart narration stays specific instead of falling back to generic cultural filler", () => {
  const narrative = localizeBoardTerm("A grounded gesture after recording a dream", "zh-Hans");
  assert.equal(narrative, "记录梦境后，以呼吸、身体感受与一件可执行小事回到当下");
  assert.doesNotMatch(narrative, /象征参照|文化研习说明/);
});

test("tool charts use method-specific fields instead of symbolic-reference filler in every locale", () => {
  const input = {
    birthDate: "1994-08-18",
    birthTime: "12:00",
    calendar: "solar",
    focus: "Focus",
    name: "Xuanyuan",
    companionName: "Companion",
    version: 1,
    place: "Tokyo, Japan",
  };
  const modules = ["bazi", "detail", "compatibility", "liuyao", "ziwei", "qizheng", "qimen", "daliuren", "meihua", "jinkoujue", "heluo", "tieban", "taiyi", "zhuzhai", "zeri", "wenshi", "mirror", "toolkit-time", "toolkit-elements", "toolkit-dream", "toolkit-name", "toolkit-tarot", "toolkit-iching", "toolkit-natal", "hecan", "daily"];
  const locales = ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"];
  const forbidden = /symbolic|象征|象徵|象徴|상징|biểu tượng|สัญลักษณ์|cultural-study reference|文化研习说明|文化研習說明/i;

  for (const tool of modules) {
    const chart = createCompleteChart({ ...input, module: tool });
    const terms = [
      chart.board.label,
      ...chart.board.cells.flatMap((cell) => [cell.title, cell.subtitle, ...cell.items.flatMap((item) => [item.label, item.value])]),
      ...chart.sections.flatMap((section) => [section.title, section.lead, ...section.items.flatMap((item) => [item.label, item.value])]),
    ].filter((value) => typeof value === "string");

    for (const locale of locales) {
      for (const term of terms) {
        assert.doesNotMatch(localizeBoardTerm(term, locale), forbidden, `${tool}/${locale}: ${term}`);
      }
    }
  }
});

test("visible site, library and suite copy never reintroduces symbolic-reference filler", () => {
  const forbidden = /symbolic|symbols|象征|象徵|象徴|상징|biểu tượng|สัญลักษณ์/i;

  assert.doesNotMatch(JSON.stringify(siteContent), forbidden);
  assert.doesNotMatch(JSON.stringify(suiteCopy), forbidden);
  assert.doesNotMatch(JSON.stringify(classicalWorks), forbidden);
});

test("board display never surfaces symbolic-reference labels in any supported language", () => {
  const forbidden = /symbolic|象征|象徵|象徴|상징|biểu tượng|สัญลักษณ์/i;
  const labels = [
    "Symbolic markers",
    "Symbolic marker",
    "Symbolic and environmental layer",
    "A symbolic seasonal sequence",
    "A local symbolic map of the four visible branches",
  ];

  for (const locale of ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"]) {
    for (const label of labels) assert.doesNotMatch(localizeBoardTerm(label, locale), forbidden, `${locale}: ${label}`);
  }
});
