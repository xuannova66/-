import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const { createCompleteChart } = await import("../app/chart-model.ts");
const { getStudyRoute } = await import("../app/study-suite.ts");

const base = {
  birthDate: "1994-08-18",
  birthTime: "12:00",
  calendar: "solar",
  focus: "A work transition",
  name: "Local study",
  companionName: "Companion",
  version: 7,
  place: "Global",
};

test("every toolkit method has its own complete chart contract", () => {
  const contracts = {
    // Contracts follow the rule-based engines: placeholder layers (seeded "sound rhythm", invented
    // tarot tones, 28 mansions inside a Western natal chart …) were removed on purpose.
    "toolkit-time": ["timing-layers", "seasonal-frame", "calendar-reference"],
    "toolkit-elements": ["element-count", "visible-roots", "hidden-roots", "cycle-map", "seasonal-balance"],
    "toolkit-dream": ["dream-symbols", "dream-associations", "elemental-tone", "reflection-threads", "dream-day"],
    "toolkit-name": ["character-form", "birth-balance", "name-method-note"],
    "toolkit-tarot": ["positions", "card-keywords", "actions"],
    "toolkit-iching": ["original-lines", "transformed-lines", "six-relatives", "six-spirits", "trigram-frame"],
    "toolkit-natal": ["bodies", "aspects", "ascendant", "seasonal-sky"],
  };

  for (const [tool, ids] of Object.entries(contracts)) {
    const chart = createCompleteChart({ ...base, module: tool });
    assert.notEqual(chart.board.label, "Synthesis local study map", `${tool} cannot fall through to the generic board`);
    assert.ok(chart.sections.length >= ids.length + 1, `${tool} needs a layered chart`);
    for (const id of ids) assert.ok(chart.sections.some((section) => section.id === id), `${tool} needs ${id}`);
  }
});

test("every study tool preserves a visible calculation basis inside its own chart", () => {
  const tools = [
    "hecan", "bazi", "detail", "compatibility", "liuyao", "ziwei", "qizheng", "qimen", "daliuren", "meihua", "jinkoujue", "heluo", "tieban", "taiyi", "zhuzhai", "zeri", "wenshi", "mirror", "daily",
    "toolkit-time", "toolkit-elements", "toolkit-dream", "toolkit-name", "toolkit-tarot", "toolkit-iching", "toolkit-natal",
  ];

  for (const tool of tools) {
    const chart = createCompleteChart({ ...base, module: tool });
    const basis = chart.sections.find((section) => section.id === "calculation-basis");
    assert.ok(basis, `${tool} needs a calculation-basis layer`);
    assert.deepEqual(basis.items.map((item) => item.label).slice(0, 5), ["Solar", "Lunar", "Civil time", "True solar time", "Chart time"]);
  }
});

test("all board families support focused drill-down for a selected chart position", async () => {
  const source = await readFile(new URL("../app/complete-chart-board.tsx", import.meta.url), "utf8");

  assert.match(source, /const \[selectedCellId, setSelectedCellId\]/);
  assert.match(source, /chart-cell-inspector/);
  assert.match(source, /onSelectCell/);
  assert.match(source, /aria-pressed=\{selectedCell\.id === cell\.id\}/);
  assert.match(source, /<ProfessionalBaZiBoard chart=\{chart\} locale=\{locale\} onSelectCell=\{setSelectedCellId\} \/>/);
  assert.match(source, /<ProfessionalZiWeiBoard chart=\{chart\} locale=\{locale\} onSelectCell=\{setSelectedCellId\} \/>/);
});

test("daily rhythm is a first-class study route with a source shelf", () => {
  const daily = getStudyRoute("daily");

  assert.equal(daily?.form, "daily");
  assert.equal(daily?.group, "rhythm");
  assert.equal(daily?.libraryCategory, "foundation");
  assert.equal(getStudyRoute("missing-route"), undefined);
});

test("synthesis routes retain independent cross-check layers", () => {
  const hecan = createCompleteChart({ ...base, module: "hecan" });
  const compatibility = createCompleteChart({ ...base, module: "compatibility" });
  const wenshi = createCompleteChart({ ...base, module: "wenshi" });
  assert.ok(hecan.sections.some((section) => section.id === "pillar-crosscheck"));
  assert.ok(compatibility.sections.some((section) => section.id === "pair-resonance"));
  assert.ok(wenshi.sections.some((section) => section.id === "inquiry-triangulation"));
});

test("celestial, synthesis and reflective methods retain their full independent layers", () => {
  const contracts = {
    qizheng: ["bodies", "lunar-mansions", "planetary-dignities", "celestial-longitude", "celestial-axis", "seasonal-sky", "method-note"],
    hecan: ["pillar-crosscheck", "profile-structure", "element-correspondence", "timing-correspondence"],
    compatibility: ["pair-resonance"],
    wenshi: ["inquiry-triangulation", "line-context", "inquiry-frame"],
    mirror: ["positions", "card-keywords", "actions"],
    "toolkit-tarot": ["positions", "card-keywords", "actions"],
  };

  for (const [tool, ids] of Object.entries(contracts)) {
    const chart = createCompleteChart({ ...base, module: tool });
    assert.ok(chart.sections.length >= ids.length, `${tool} needs all of its intended method layers`);
    for (const id of ids) assert.ok(chart.sections.some((section) => section.id === id), `${tool} needs ${id}`);
  }
});

test("toolkit launch cards reveal and focus the selected workspace", async () => {
  const source = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");

  assert.match(source, /const workspaceRef = useRef<HTMLDivElement>\(null\)/);
  assert.match(source, /workspaceRef\.current\?\.scrollIntoView\(\{ behavior: "smooth", block: "start" \}\)/);
  assert.match(source, /ref=\{workspaceRef\}/);
  assert.match(source, /toolkit-active-label/);
});
