import assert from "node:assert/strict";
import test from "node:test";

const { hashForStudyStage, parseStudyLocation } = await import("../app/study-navigation.ts");

test("study locations preserve a tool route and explicit presentation stage", () => {
  assert.deepEqual(parseStudyLocation("#qimen/chart"), { route: "qimen", stage: "chart" });
  assert.deepEqual(parseStudyLocation("#daily/reading"), { route: "daily", stage: "reading" });
  assert.deepEqual(parseStudyLocation("#bazi"), { route: "bazi", stage: "input" });
  assert.equal(hashForStudyStage("ziwei", "reading"), "#ziwei/reading");
});

test("non-study locations cannot opt into a generated-chart state", () => {
  assert.deepEqual(parseStudyLocation("#library/chart"), { route: "library", stage: "input" });
  assert.equal(hashForStudyStage("home", "ritual"), "#home");
});
