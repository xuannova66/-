import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

import { calculateBaziReference } from "../app/bazi-reference.ts";
import { createCompleteChart } from "../app/chart-model.ts";
import { createStudyResult } from "../app/study-engine.ts";

const original = JSON.parse(await readFile(new URL("./bazi15_site_sample.json", import.meta.url), "utf8"));

test("site-derived BaZi reference fields match the independent reference sample across all 15 charts", () => {
  for (const row of original) {
    const [birthDate, birthTime, sex] = row.in.split(" ");
    const gender = sex === "yin" ? "yin" : "yang";
    const study = createStudyResult({ birthDate, birthTime, calendar: "solar", gender, focus: "", name: "", companionName: "", module: "bazi", version: 0 });
    assert.deepEqual(study.pillars, row.pillars, `${row.in}: calendar pillars`);
    const chart = createCompleteChart({ birthDate, birthTime, calendar: "pillars", manualPillars: study.pillars, gender, focus: "", name: "", companionName: "", module: "bazi", version: 0 });
    const derived = calculateBaziReference(study.pillars, gender);
    const field = (label, index) => chart.board.cells[index].items.find((item) => item.label === label)?.value;

    assert.deepEqual(study.pillars.map((_, index) => field("Ten God", index)), derived.tenGods, `${row.in}: ten gods`);
    // Day-stem relation lists the ten god of every hidden stem (the day master's own stem is shown as 日主).
    assert.deepEqual(study.pillars.map((_, index) => field("Day-stem relation", index).split(" · ").length), derived.hiddenStems.map((stems) => stems.length), `${row.in}: day-stem relation`);
    assert.deepEqual(study.pillars.map((_, index) => field("NaYin", index)), derived.naYin, `${row.in}: NaYin`);
    assert.deepEqual(study.pillars.map((_, index) => field("Life stage", index)), derived.lifeStages, `${row.in}: twelve life stages`);
    assert.deepEqual(study.pillars.map((_, index) => field("Hidden stems", index).split(" · ")), derived.hiddenStems, `${row.in}: hidden stems`);
    assert.deepEqual(chart.sections.find((section) => section.id === "luck-cycles").items.map((item) => item.value.split(" · ")[0]), derived.dayun.cycles, `${row.in}: dayun sequence`);
    assert.equal(chart.sections.find((section) => section.id === "start-luck").items.find((item) => item.label === "Orientation").value, derived.dayun.direction === "顺行" ? "Forward" : "Backward", `${row.in}: dayun direction`);
  }
});

test("BaZi reference rejects invalid pillar data instead of returning misleading values", () => {
  assert.throws(() => calculateBaziReference(["甲子", "乙丑", "bad", "丁卯"]), /four valid stem-branch pillars/);
});
