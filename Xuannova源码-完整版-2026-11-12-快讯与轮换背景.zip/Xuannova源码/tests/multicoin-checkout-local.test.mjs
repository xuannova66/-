// MultiCoinCheckout on a real local EVM (ganache via the anvil shim): every extra BNB Chain coin is quoted, paid and
// verified through the site's own front-end and back-end code; owner controls, rescue and fee-on-transfer rejection.
import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { readFileSync, readdirSync } from "node:fs";
import { createPublicClient, createWalletClient, custom, parseEther, getAddress, keccak256, toBytes } from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { getUsdcCheckoutQuote, purchaseUsdcPackage } from "../app/wallet-connect.ts";
import { BSC_USDC_ASSETS, BSC_V2_ROUTER, EXTRA_CHECKOUT_TOKENS } from "../app/usdc-payment-quote.ts";
import { treasuryAddress, platformFeeRecipient } from "../worker/commerce-policy.ts";
import { verifyPurchaseReceipt } from "../worker/wallet-chain.ts";
import { handleCommerceApi, createSessionToken } from "../worker/commerce-api.ts";
import { openDatabase } from "../server/sqlite-db.ts";
if (!process.env.XUANNOVA_TEST_TOOLS) throw new Error("Set XUANNOVA_TEST_TOOLS to a directory containing solc and ganache");
const require = createRequire(`${process.env.XUANNOVA_TEST_TOOLS}/package.json`);
const solc = require("solc"), ganache = require("ganache");
const contract = readFileSync(new URL("../contracts/MultiCoinCheckout.sol", import.meta.url), "utf8");
const mocks = `// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;
contract Token { mapping(address=>uint) public balanceOf; mapping(address=>mapping(address=>uint)) public allowance;
function mint(address a,uint v) external {balanceOf[a]+=v;}
function approve(address s,uint v) external returns(bool){allowance[msg.sender][s]=v;return true;}
function transfer(address to,uint v) external returns(bool){balanceOf[msg.sender]-=v;balanceOf[to]+=v;return true;}
function transferFrom(address f,address t,uint v) external returns(bool){allowance[f][msg.sender]-=v;balanceOf[f]-=v;balanceOf[t]+=v;return true;} }
contract FeeToken { mapping(address=>uint) public balanceOf; mapping(address=>mapping(address=>uint)) public allowance;
function mint(address a,uint v) external {balanceOf[a]+=v;}
function approve(address s,uint v) external returns(bool){allowance[msg.sender][s]=v;return true;}
function transfer(address to,uint v) external returns(bool){balanceOf[msg.sender]-=v;balanceOf[to]+=v*99/100;return true;}
function transferFrom(address f,address t,uint v) external returns(bool){allowance[f][msg.sender]-=v;balanceOf[f]-=v;balanceOf[t]+=v*99/100;return true;} }
interface T {function transfer(address,uint) external returns(bool);function transferFrom(address,address,uint) external returns(bool);}
contract Router {address public immutable WETH; constructor(address w){WETH=w;}
function getAmountsIn(uint out,address[] calldata p) external pure returns(uint[] memory a){a=new uint[](p.length);for(uint i;i<p.length;i++)a[i]=out;}
function swapTokensForExactTokens(uint out,uint m,address[] calldata p,address to,uint) external returns(uint[] memory a){require(m>=out);T(p[0]).transferFrom(msg.sender,address(this),out);T(p[p.length-1]).transfer(to,out);a=new uint[](p.length);for(uint i;i<p.length;i++)a[i]=out;}
function swapETHForExactTokens(uint out,address[] calldata p,address to,uint) external payable returns(uint[] memory a){require(msg.value>=out);T(p[p.length-1]).transfer(to,out);(bool ok,)=msg.sender.call{value:msg.value-out}("");require(ok);a=new uint[](p.length);for(uint i;i<p.length;i++)a[i]=out;} }`;
const compiled = JSON.parse(solc.compile(JSON.stringify({ language: "Solidity", sources: { "Checkout.sol": { content: contract }, "Mocks.sol": { content: mocks } }, settings: { optimizer: { enabled: true, runs: 200 }, evmVersion: "shanghai", outputSelection: { "*": { "*": ["abi", "evm.bytecode.object"] } } } })));
assert.deepEqual((compiled.errors ?? []).filter((item) => item.severity === "error"), []);

test("MultiCoinCheckout: each extra coin pays the exact USDC price, is verified and credited; owner controls hold", async () => {
  const provider = ganache.provider({ logging: { quiet: true }, chain: { chainId: 56, hardfork: "shanghai" }, miner: { instamine: "eager" } });
  const accounts = await provider.request({ method: "eth_accounts", params: [] });
  const account = privateKeyToAccount(provider.getInitialAccounts()[accounts[0].toLowerCase()].secretKey);
  const stranger = getAddress(accounts[1]);
  const pub = createPublicClient({ transport: custom(provider), pollingInterval: 50 });
  const wallet = createWalletClient({ account, transport: custom(provider) });
  const deploy = async (file, name, args = []) => { const artifact = compiled.contracts[file][name]; const hash = await wallet.deployContract({ abi: artifact.abi, bytecode: `0x${artifact.evm.bytecode.object}`, args, chain: null }); return { address: (await pub.waitForTransactionReceipt({ hash })).contractAddress, abi: artifact.abi }; };
  const tx = async (target, name, args = []) => { const hash = await wallet.writeContract({ address: target.address, abi: target.abi, functionName: name, args, chain: null }); return pub.waitForTransactionReceipt({ hash }); };
  const tokenSource = await deploy("Mocks.sol", "Token");
  const tokenCode = await pub.getCode({ address: tokenSource.address });
  const coins = ["USDC", "USDT", "ASTER", ...EXTRA_CHECKOUT_TOKENS];
  for (const coin of coins) await provider.request({ method: "evm_setAccountCode", params: [BSC_USDC_ASSETS[coin], tokenCode] });
  const token = (coin) => ({ address: BSC_USDC_ASSETS[coin], abi: tokenSource.abi });
  const routerSource = await deploy("Mocks.sol", "Router", [BSC_USDC_ASSETS.WBNB]);
  await provider.request({ method: "evm_setAccountCode", params: [BSC_V2_ROUTER, await pub.getCode({ address: routerSource.address })] });
  const fee = 70000000000000n;
  const store = await deploy("Checkout.sol", "MultiCoinCheckout", [BSC_USDC_ASSETS.USDC, BSC_USDC_ASSETS.USDT, BSC_USDC_ASSETS.ASTER, BSC_V2_ROUTER, treasuryAddress, platformFeeRecipient, fee]);
  await tx(token("USDC"), "mint", [BSC_V2_ROUTER, parseEther("1000")]);
  for (const coin of coins) await tx(token(coin), "mint", [account.address, parseEther("100")]);
  const read = (target, name, args = []) => pub.readContract({ address: target.address, abi: target.abi, functionName: name, args });
  const treasuryUsdc = () => read(token("USDC"), "balanceOf", [treasuryAddress]);

  // Server: the extra coins appear in the checkout config only when listed in USDC_CHECKOUT_TOKENS.
  const db = openDatabase(":memory:");
  const migrationDir = new URL("../migrations/", import.meta.url);
  for (const file of readdirSync(migrationDir).filter((item) => item.endsWith(".sql")).sort()) db.raw.exec(readFileSync(new URL(file, migrationDir), "utf8"));
  db.raw.prepare("INSERT INTO members (id,wallet_address,credits,role,created_at,updated_at) VALUES (?,?,?,?,?,?)").run("buyer", account.address, 0, "member", new Date().toISOString(), new Date().toISOString());
  const secret = "local-test-secret-that-is-at-least-thirty-two-bytes";
  const session = await createSessionToken({ sub: "buyer", wallet: account.address, role: "member" }, secret);
  const apiEnv = { DB: db, SESSION_SECRET: secret, CREDIT_STORE_ADDRESS: "0x1111111111111111111111111111111111111111", USDC_CHECKOUT_ADDRESS: store.address, USDC_CHECKOUT_ENABLED: "true", USDC_CHECKOUT_TOKENS: "cake, btcb,WETH,USD1,XRP,SOL,DOGE,LINK,UNI,AAVE,XAUt,SHIB,NOPE", BSC_RPC_URLS: "https://local.invalid" };
  const served = await (await handleCommerceApi(new Request("https://xuannova.test/api/checkout/config"), apiEnv)).json();
  assert.deepEqual(served.checkoutTokens, [...EXTRA_CHECKOUT_TOKENS], "listed coins only, unknown names ignored");
  const none = await (await handleCommerceApi(new Request("https://xuannova.test/api/checkout/config"), { ...apiEnv, USDC_CHECKOUT_TOKENS: "" })).json();
  assert.deepEqual(none.checkoutTokens, []);

  const config = { chainId: 56, chainHexId: "0x38", chainName: "BNB Smart Chain", nativeSymbol: "BNB", rpcUrls: [], explorerUrl: "https://bscscan.com", testnet: false, usdtAddress: BSC_USDC_ASSETS.USDT, contractAddress: null, usdcCheckoutAddress: store.address, platformFeeWei: fee.toString(), confirmations: 1, enabled: true, checkoutTokens: [...EXTRA_CHECKOUT_TOKENS] };
  const viaChain = async (run) => {
    const prior = globalThis.fetch;
    globalThis.fetch = async (_url, init) => { const input = JSON.parse(init.body); const calls = Array.isArray(input) ? input : [input]; const results = await Promise.all(calls.map(async (call) => ({ jsonrpc: "2.0", id: call.id, result: await provider.request({ method: call.method, params: call.params ?? [] }) }))); return new Response(JSON.stringify(Array.isArray(input) ? results : results[0]), { headers: { "content-type": "application/json" } }); };
    try { return await run(); } finally { globalThis.fetch = prior; }
  };

  // Not allowed yet: the page refuses before any wallet prompt, and the contract itself refuses a direct buy.
  const early = await getUsdcCheckoutQuote({ provider, config, packageId: "seed", token: "CAKE" });
  await assert.rejects(purchaseUsdcPackage({ provider, address: account.address, packageId: "seed", config, quote: early }), /not enabled/);
  await assert.rejects(pub.simulateContract({ account: account.address, address: store.address, abi: store.abi, functionName: "buy", args: [keccak256(toBytes("seed")), BSC_USDC_ASSETS.CAKE, parseEther("5"), [BSC_USDC_ASSETS.CAKE, BSC_USDC_ASSETS.USDC], BigInt(Math.floor(Date.now() / 1000) + 120)], value: fee }));

  // Owner controls.
  await assert.rejects(pub.simulateContract({ account: stranger, address: store.address, abi: store.abi, functionName: "setToken", args: [BSC_USDC_ASSETS.CAKE, true] }), "only the owner lists coins");
  await assert.rejects(pub.simulateContract({ account: account.address, address: store.address, abi: store.abi, functionName: "setToken", args: [BSC_USDC_ASSETS.USDC, true] }), "USDC is never listed");
  await assert.rejects(pub.simulateContract({ account: account.address, address: store.address, abi: store.abi, functionName: "setToken", args: [stranger, true] }), "an address without code is refused");
  for (const coin of EXTRA_CHECKOUT_TOKENS) await tx(store, "setToken", [BSC_USDC_ASSETS[coin], true]);
  assert.equal(await read(store, "allowedToken", [BSC_USDC_ASSETS.USDT]), true, "USDT allowed from the start");

  let credits = 0;
  for (const coin of [...EXTRA_CHECKOUT_TOKENS, "BNB", "USDC", "USDT", "ASTER"]) {
    for (const packageId of ["seed", "synthesis"]) {
      const quote = await getUsdcCheckoutQuote({ provider, config, packageId, token: coin });
      const before = await treasuryUsdc();
      const coinBefore = coin === "BNB" ? 0n : await read(token(coin), "balanceOf", [account.address]);
      const hash = await purchaseUsdcPackage({ provider, address: account.address, packageId, config, quote });
      const receipt = await pub.getTransactionReceipt({ hash });
      assert.equal(receipt.status, "success", `${coin} ${packageId}`);
      const price = packageId === "seed" ? parseEther("4.99") : parseEther("39.9");
      assert.equal((await treasuryUsdc()) - before, price, `${coin}: treasury receives exactly the package price in USDC`);
      if (coin !== "BNB") assert.equal(coinBefore - (await read(token(coin), "balanceOf", [account.address])), quote.estimatedInput, `${coin}: buyer pays the swap amount; the 1% buffer is refunded`);
      for (const item of [store.address]) for (const c of coins) assert.equal(await read(token(c), "balanceOf", [item]), 0n, "the contract keeps nothing");
      for (let i = 0; i < 3; i += 1) await provider.request({ method: "evm_mine", params: [] });
      await viaChain(async () => {
        const checked = await verifyPurchaseReceipt({ transactionHash: hash, expectedBuyer: account.address, contractAddress: getAddress(store.address), rpcUrls: ["https://local.invalid"], minimumConfirmations: 1 });
        assert.equal(checked.ok, true, `back end verifies the ${coin} payment`);
        const saved = await handleCommerceApi(new Request("https://xuannova.test/api/orders", { method: "POST", headers: { origin: "https://xuannova.test", cookie: `xuanyuan_session=${session}`, "content-type": "application/json" }, body: JSON.stringify({ transactionHash: hash, packageId, checkout: "usdc" }) }), apiEnv);
        assert.equal(saved.status, 201, `${coin} ${packageId} credited`);
      });
      credits += packageId === "seed" ? 20 : 280;
    }
  }
  assert.equal(db.raw.prepare("SELECT credits FROM members WHERE id = ?").get("buyer").credits, credits);

  // Stopping a coin takes effect immediately.
  await tx(store, "setToken", [BSC_USDC_ASSETS.SHIB, false]);
  const stopped = await getUsdcCheckoutQuote({ provider, config, packageId: "seed", token: "SHIB" });
  await assert.rejects(purchaseUsdcPackage({ provider, address: account.address, packageId: "seed", config, quote: stopped }), /not enabled/);

  // Fee-on-transfer coins are refused by the exact-balance check, even if listed by mistake.
  const feeToken = await deploy("Mocks.sol", "FeeToken");
  await tx(feeToken, "mint", [account.address, parseEther("100")]);
  await tx(store, "setToken", [feeToken.address, true]);
  await tx(feeToken, "approve", [store.address, parseEther("10")]);
  await assert.rejects(pub.simulateContract({ account: account.address, address: store.address, abi: store.abi, functionName: "buy", args: [keccak256(toBytes("seed")), feeToken.address, parseEther("5"), [feeToken.address, BSC_USDC_ASSETS.USDC], BigInt(Math.floor(Date.now() / 1000) + 120)], value: fee }));

  // Coins sent to the contract by mistake can only go to the treasury, and only the owner can move them.
  await tx(token("DOGE"), "transfer", [store.address, parseEther("1")]);
  await assert.rejects(pub.simulateContract({ account: stranger, address: store.address, abi: store.abi, functionName: "rescue", args: [BSC_USDC_ASSETS.DOGE] }));
  await tx(store, "rescue", [BSC_USDC_ASSETS.DOGE]);
  assert.equal(await read(token("DOGE"), "balanceOf", [treasuryAddress]), parseEther("1"));
  assert.equal(await read(token("DOGE"), "balanceOf", [store.address]), 0n);

  // Pause stops everything.
  await tx(store, "setPaused", [true]);
  const paused = await getUsdcCheckoutQuote({ provider, config, packageId: "seed", token: "CAKE" });
  const beforePause = await treasuryUsdc();
  await assert.rejects(purchaseUsdcPackage({ provider, address: account.address, packageId: "seed", config, quote: paused }));
  assert.equal(await treasuryUsdc(), beforePause);
  db.raw.close();
  await provider.disconnect();
});
