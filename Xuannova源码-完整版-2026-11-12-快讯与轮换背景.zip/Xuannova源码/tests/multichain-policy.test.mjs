import test from "node:test";
import assert from "node:assert/strict";
import { packageSettlement } from "../worker/multichain-policy.ts";
import { creditPackages as browserPackages } from "../app/credit-wallet.ts";

test("all four chains use the existing four package prices and credit values", () => {
  const expected = [["seed", "4.99", 20], ["path", "9.90", 50], ["ritual", "19.90", 120], ["synthesis", "39.90", 280]];
  assert.deepEqual(browserPackages.map(({id,usdt,credits}) => [id,usdt,credits]), expected);
  for (const network of ["bsc", "ethereum", "solana", "tron"]) for (const [id, price, credits] of expected) {
    const quote = packageSettlement(network, id);
    assert.equal(quote.price, price);
    assert.equal(quote.credits, credits);
    assert.equal(quote.symbol, network === "tron" ? "USDT" : "USDC");
    const cents = BigInt(price.replace(".", ""));
    assert.equal(quote.amountUnits, cents * 10n ** BigInt(quote.decimals - 2));
  }
});

test("unknown network and package do not produce a payment request", () => {
  assert.throws(() => packageSettlement("invalid", "seed"), /UNSUPPORTED_SETTLEMENT_NETWORK/);
  assert.throws(() => packageSettlement("__proto__", "seed"), /UNSUPPORTED_SETTLEMENT_NETWORK/);
  assert.throws(() => packageSettlement("bsc", "invalid"), /UNKNOWN_CREDIT_PACKAGE/);
});
