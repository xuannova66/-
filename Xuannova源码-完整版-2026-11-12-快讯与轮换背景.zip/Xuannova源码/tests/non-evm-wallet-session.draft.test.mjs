import test from "node:test";
import assert from "node:assert/strict";
import { connectSolanaDraft, connectTronDraft } from "../app/non-evm-wallet-session.draft.ts";
const sol="BzDaU6VKyMtN14QeVuCMva2SGmHLeeYy2GAAG9muJNq2", tron="TMkFTkWbkjnUpCTiYx87QyTTjXiS2ogGqi";
test("Solana connection validates address but never claims network or member authentication",async()=>{
 const publicKey={toString:()=>sol}; const result=await connectSolanaDraft({connect:async()=>({publicKey}),publicKey});
 assert.equal(result.address,sol); assert.equal(result.networkVerified,false);
 await assert.rejects(connectSolanaDraft({connect:async()=>({publicKey:{toString:()=>"bad"}})}),/INVALID_WALLET_ADDRESS/);
 await assert.rejects(connectSolanaDraft({connect:async()=>({publicKey}),publicKey:{toString:()=>"different"}}),/WALLET_ACCOUNT_CHANGED/);
});
test("TRON connection checks authorization and base58 checksum, but not network",async()=>{
 const provider={request:async({method})=>{assert.equal(method,"eth_requestAccounts");return [tron]},tronWeb:{ready:true,defaultAddress:{base58:tron}}};
 assert.equal((await connectTronDraft(provider)).networkVerified,false);
 await assert.rejects(connectTronDraft({...provider,request:async()=>[`${tron.slice(0,-1)}a`]}),/INVALID_WALLET_ADDRESS/);
 await assert.rejects(connectTronDraft({...provider,tronWeb:false}),/WALLET_ACCOUNT_UNAVAILABLE_OR_CHANGED/);
});
