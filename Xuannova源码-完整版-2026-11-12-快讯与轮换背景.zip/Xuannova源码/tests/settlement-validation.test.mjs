import test from "node:test";
import assert from "node:assert/strict";
import { validateSettlement } from "../worker/settlement-validation.ts";

const expected = { chain: "solana-mainnet", asset: "UsDcCaseSensitive", recipient: "WalletCaseSensitive", buyer: "BuyerCaseSensitive", amount: 4990000n };
const proof = { ...expected, transactionId: "signature", eventIndex: 0, successful: true, finalized: true };

test("requires finalized matching on-chain settlement", () => {
  assert.doesNotThrow(() => validateSettlement(proof, expected));
  for (const bad of [{ successful: false }, { finalized: false }, { chain: "ethereum" }, { asset: "usdccasesensitive" }, { recipient: "walletcasesensitive" }, { buyer: "someone-else" }, { amount: 4989999n }, { transactionId: "" }, { eventIndex: -1 }]) {
    assert.throws(() => validateSettlement({ ...proof, ...bad }, expected));
  }
  assert.throws(() => validateSettlement({ ...proof, amount: 0n }, { ...expected, amount: 0n }));
});
