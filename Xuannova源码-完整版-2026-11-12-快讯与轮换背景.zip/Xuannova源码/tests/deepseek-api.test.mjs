import assert from "node:assert/strict";
import test from "node:test";

const deepseek = await import("../worker/deepseek.ts");

const request = {
  tool: "bazi",
  locale: "en",
  question: "How can I approach a career transition?",
  chart: {
    calendar: {
      solar: "2026-10-15",
      lunar: "Sample lunar date",
      naYin: "Sample NaYin",
      zodiac: "Horse",
      elements: [{ name: "Wood", count: 2 }],
      yi: ["Study"],
      ji: ["Rush"],
    },
    pillars: ["甲子", "乙丑", "丙寅", "丁卯"],
    board: { kind: "pillars", label: "Four pillars", cells: [] },
    sections: [],
    sourceFacts: [],
    inputSummary: { focus: "Career", place: "Singapore", version: 1 },
  },
};

test("reading prompt follows the Xuannova safety, chart-source, date, and locale rules", () => {
  const messages = deepseek.buildInterpretationMessages(request, "structured", "2026-10-27");

  assert.equal(messages.length, 2);
  assert.match(messages[0].content, /JSON/i);
  assert.match(messages[0].content, /Xuannova's traditional-culture study service/);
  assert.match(messages[0].content, /2026-10-27/);
  assert.match(messages[0].content, /untrusted data/);
  assert.match(messages[0].content, /medical, legal, investment/);
  assert.match(messages[0].content, /Never promise or assert certainty/);
  assert.match(messages[0].content, /do not include Chinese characters/);
  assert.match(messages[0].content, /Address the user's question directly/i);
  assert.match(messages[1].content, /career transition/i);
  assert.match(messages[1].content, /\"locale\":\"en\"/);
  assert.match(messages[1].content, /2026-10-15/);
  assert.match(messages[1].content, /\"Wood\"/);
  assert.match(messages[0].content, /authoritative, already-calculated result/);
  assert.match(messages[0].content, /exactly 6 distinct sections/);
  assert.match(messages[0].content, /three paragraphs/);
  assert.match(messages[0].content, /at least 400 and up to 550 characters/);
  assert.match(messages[0].content, /exactly three concise follow-up prompts/);

  const chineseMessages = deepseek.buildInterpretationMessages({ ...request, locale: "zh-Hans" }, "structured", "2026-10-27");
  assert.match(chineseMessages[0].content, /Simplified Chinese/);
  assert.match(chineseMessages[0].content, /Do not answer in English/);
});

test("DeepSeek response parser accepts the reading contract and rejects blank output", () => {
  const reading = {
    title: "BaZi reflection",
    summary: "Use this chart as a reflective cultural-study reference.",
    sections: [{ title: "Orientation", text: "Observe the pillars before deciding." }],
    followUps: ["What is within your control?"],
  };

  assert.deepEqual(deepseek.parseInterpretationResponse(JSON.stringify(reading)), reading);
  assert.throws(() => deepseek.parseInterpretationResponse("   "), /valid JSON/i);
});

test("conversation prompt carries only the ten latest server-supplied turns", () => {
  const history = Array.from({ length: 12 }, (_, index) => ({ question: `Question ${index + 1}`, answer: `Answer ${index + 1}` }));
  const messages = deepseek.buildInterpretationMessages({ ...request, conversationHistory: history }, "conversation", "2026-10-27");
  const body = JSON.parse(messages[1].content.split("Chart request JSON: ")[1]);
  assert.equal(body.recentConversation.length, 10);
  assert.equal(body.recentConversation[0].question, "Question 3");
  assert.equal(body.recentConversation.at(-1).answer, "Answer 12");
  assert.match(messages[0].content, /do not repeat the full prior report/);

  const structured = deepseek.buildInterpretationMessages({ ...request, conversationHistory: history }, "structured", "2026-10-27");
  assert.doesNotMatch(structured[1].content, /recentConversation/);
});

test("DeepSeek response parser displays a minimal JSON answer and a plain-text answer", () => {
  assert.deepEqual(deepseek.parseInterpretationResponse(JSON.stringify({ answer: "A concise provider reply." })), {
    title: "Reading",
    summary: "A concise provider reply.",
    sections: [],
    followUps: [],
  });
  assert.deepEqual(deepseek.parseInterpretationResponse("A plain provider reply."), {
    title: "Reading",
    summary: "A plain provider reply.",
    sections: [],
    followUps: [],
  });
});

test("DeepSeek response parser accepts a fenced JSON object from the provider", () => {
  const reading = {
    title: "BaZi reflection",
    summary: "Keep the next action modest and observable.",
    sections: [{ title: "Orientation", text: "Begin with the current calendar context." }],
    followUps: ["What is already clear?"],
  };

  assert.deepEqual(
    deepseek.parseInterpretationResponse(`\`\`\`json\n${JSON.stringify(reading)}\n\`\`\``),
    reading,
  );
});

test("DeepSeek retries one malformed provider result before reporting the reading unavailable", async () => {
  const reading = {
    title: "BaZi reflection",
    summary: "Keep the next action modest and observable.",
    sections: [{ title: "Orientation", text: "Begin with the current calendar context." }],
    followUps: ["What is already clear?"],
  };
  let attempts = 0;
  const result = await deepseek.requestDeepSeekInterpretation(
    request,
    "structured",
    "test-key",
    "deepseek-v4-flash",
    async () => {
      attempts += 1;
      return new Response(JSON.stringify({ choices: [{ message: { content: attempts === 1 ? "{}" : JSON.stringify(reading) } }] }));
    },
  );

  assert.equal(attempts, 2);
  assert.deepEqual({ ...result, followUps: reading.followUps }, reading);
  assert.equal(result.followUps[0], reading.followUps[0]);
  assert.equal(result.followUps.length, 3);
});

test("DeepSeek reports a rejected credential separately from a temporary provider outage", async () => {
  await assert.rejects(
    () => deepseek.requestDeepSeekInterpretation(
      request,
      "structured",
      "test-key",
      "deepseek-v4-flash",
      async () => new Response(JSON.stringify({ error: { message: "Unauthorized" } }), { status: 401 }),
    ),
    (error) => error instanceof deepseek.DeepSeekServiceError && error.code === "AI_AUTH_FAILED",
  );
});
