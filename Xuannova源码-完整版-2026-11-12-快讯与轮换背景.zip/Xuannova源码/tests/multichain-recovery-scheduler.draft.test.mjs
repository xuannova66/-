import test from "node:test";
import assert from "node:assert/strict";
import { createRecoveryScheduler } from "../worker/multichain-recovery-scheduler.draft.ts";

test("scheduler is opt-in, non-overlapping, and stop prevents further scheduling", async () => {
  let runs=0, finish;
  const pending=new Promise(resolve=>{finish=resolve;});
  const scheduler=createRecoveryScheduler({intervalMs:30000,run:async()=>{runs++;await pending;return {checked:1,credited:0,pending:1};}});
  assert.deepEqual(scheduler.state(),{active:false,running:false});
  scheduler.start();scheduler.start();
  assert.equal(runs,1);assert.deepEqual(scheduler.state(),{active:true,running:true});
  scheduler.stop();assert.deepEqual(scheduler.state(),{active:false,running:true});
  finish();await new Promise(resolve=>setImmediate(resolve));
  assert.deepEqual(scheduler.state(),{active:false,running:false});
  assert.throws(()=>createRecoveryScheduler({intervalMs:1000,run:async()=>({checked:0,credited:0,pending:0})}),/INVALID_RECOVERY_INTERVAL/);
});

test("restart while a pass is in flight does not run concurrently", async () => {
  let runs=0, finish;
  const pending=new Promise(resolve=>{finish=resolve;});
  const scheduler=createRecoveryScheduler({intervalMs:30000,run:async()=>{runs++;await pending;return {checked:0,credited:0,pending:0};},onResult:()=>{throw Error("metric failure");}});
  scheduler.start();scheduler.stop();scheduler.start();
  assert.equal(runs,1);finish();await new Promise(resolve=>setImmediate(resolve));
  assert.equal(runs,1);assert.deepEqual(scheduler.state(),{active:true,running:false});scheduler.stop();
});
