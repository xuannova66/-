import assert from "node:assert/strict";
import test from "node:test";
import { privateKeyToAccount } from "viem/accounts";
import { encodeAbiParameters, encodeEventTopics, numberToHex, pad } from "viem";

const api = await import("../worker/commerce-api.ts");
const chain = await import("../worker/wallet-chain.ts");
const policy = await import("../worker/commerce-policy.ts");

const env = {
  SESSION_SECRET: "test-session-signing-key-that-is-long-enough",
  CREDIT_STORE_ADDRESS: "0x1111111111111111111111111111111111111111",
  BSC_RPC_URLS: "https://rpc.test.invalid",
};
const buyer = privateKeyToAccount("0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d");
const headers = { origin: "https://preview.example", "content-type": "application/json" };

function walletDatabase() {
  const members = [];
  const nonces = new Map();
  const orders = [];
  const ledger = [];
  const batches = [];
  const claims = new Map();
  function statementFor(query) {
    let bindings = [];
    const statement = {
      bind(...values) { bindings = values; return statement; },
      async first() { if (query.startsWith("SELECT member_id FROM daily_bonus_claims")) return { member_id: claims.get(`${bindings[0]}|${bindings[1]}`) ?? null };
        if (query.startsWith("SELECT nonce, expires_at FROM wallet_nonces")) return nonces.get(bindings[0].toLowerCase()) ?? null;
        if (query.includes("FROM members WHERE wallet_address = ?")) return members.find((m) => m.wallet_address?.toLowerCase() === bindings[0].toLowerCase()) ?? null;
        if (query.includes("FROM members WHERE invite_code = ?")) return members.find((m) => m.invite_code === bindings[0]) ?? null;
        if (query.includes("FROM members WHERE id = ?")) return members.find((m) => m.id === bindings[0]) ?? null;
        if (query.includes("FROM payment_orders WHERE transaction_hash = ?")) return orders.find((o) => o.transaction_hash === bindings[0]) ?? null;
        return null;
      },
      async all() { return { results: [] }; },
      async run() {
          if (query.startsWith("INSERT OR IGNORE INTO daily_bonus_claims")) { const key = `${bindings[0]}|${bindings[1]}`; if (!claims.has(key)) claims.set(key, bindings[2]); return { meta: { changes: 1 } }; }
          if (query.startsWith("UPDATE members SET daily_credits = MIN")) {
            const target = typeof members !== "undefined" ? members.find((item) => item.id === bindings[5]) : typeof member !== "undefined" && member.id === bindings[5] ? member : null;
            if (!target || target.daily_credit_date === bindings[2]) return { meta: { changes: 0 } };
            target.daily_credits = Math.min((target.daily_credits ?? 0) + bindings[0], bindings[1]);
            target.daily_credit_date = bindings[2];
            return { meta: { changes: 1 } };
          }
        if (query.startsWith("INSERT INTO wallet_nonces")) nonces.set(bindings[0].toLowerCase(), { nonce: bindings[1], expires_at: bindings[2] });
        if (query.startsWith("DELETE FROM wallet_nonces")) nonces.delete(bindings[0].toLowerCase());
        if (query.startsWith("INSERT INTO members")) members.push({ id: bindings[0], email: null, wallet_address: bindings[1], credits: bindings[2], daily_credits: 0, daily_credit_date: null, invite_code: bindings[3], invited_by_member_id: bindings[4] });
        if (query.startsWith("INSERT INTO payment_orders")) {
          if (orders.some((o) => o.transaction_hash === bindings[6])) throw new Error("UNIQUE constraint failed");
          orders.push({ id: bindings[0], member_id: bindings[1], package_id: bindings[2], amount_usdt: bindings[3], credits: bindings[4], network: bindings[5], transaction_hash: bindings[6], status: "pending", submitted_at: bindings[7], buyer_address: bindings[8], chain_id: bindings[9], contract_address: bindings[10], fee_wei: bindings[11], block_number: bindings[12], settlement_currency: bindings[13] });
        }
        if (query.startsWith("UPDATE payment_orders SET status = 'approved'")) {
          const order = orders.find((o) => o.id === bindings[3] && o.status === "pending");
          if (order) {
            // Mirrors the payment_order_approved_credit_once trigger.
            order.status = "approved"; order.reviewed_at = bindings[0]; order.reviewed_by = bindings[1]; order.review_note = bindings[2];
            const member = members.find((m) => m.id === order.member_id);
            member.credits += order.credits;
            ledger.push({ member_id: member.id, order_id: order.id, delta: order.credits, reason: "payment_approval" });
          }
        }
        if (query.startsWith("UPDATE members SET credits = credits +")) {
          const member = members.find((m) => m.id === bindings[2]);
          if (member) member.credits += bindings[0];
        }
        if (query.startsWith("UPDATE members SET daily_credits = 5")) {
          const member = members.find((m) => m.id === bindings[2]);
          if (member && member.daily_credit_date !== bindings[0]) {
            member.daily_credits = 5;
            member.daily_credit_date = bindings[0];
            return { meta: { changes: 1 } };
          }
          return { meta: { changes: 0 } };
        }
        if (query.startsWith("INSERT INTO credit_ledger") && String(bindings[4]).startsWith("daily_login_bonus:")) {
          ledger.push({ query, bindings, reason: String(bindings[4]) });
        } else if (query.startsWith("INSERT INTO credit_ledger") && query.includes("invitation_purchase")) {
          ledger.push({ query, bindings, reason: "invitation_purchase" });
        } else if (query.startsWith("INSERT INTO credit_ledger")) ledger.push({ query, bindings });
        return { meta: { changes: 1 } };
      },
    };
    return statement;
  }
  return {
    members, nonces, orders, ledger, batches,
    prepare: statementFor,
    async batch(statements) { batches.push(statements.length); const results = []; for (const s of statements) results.push(await s.run()); return results; },
  };
}

async function signIn(database, inviteCode) {
  const nonceResponse = await api.handleCommerceApi(
    new Request("https://preview.example/api/auth/wallet/nonce", { method: "POST", headers, body: JSON.stringify({ address: buyer.address.toLowerCase() }) }),
    { ...env, DB: database },
  );
  assert.equal(nonceResponse.status, 200);
  const { message } = await nonceResponse.json();
  const signature = await buyer.signMessage({ message });
  const verifyResponse = await api.handleCommerceApi(
    new Request("https://preview.example/api/auth/wallet/verify", { method: "POST", headers, body: JSON.stringify({ address: buyer.address, message, signature, ...(inviteCode ? { inviteCode } : {}) }) }),
    { ...env, DB: database },
  );
  return verifyResponse;
}

test("signs a wallet in with a nonce-bound EIP-191 signature and creates the member", async () => {
  const database = walletDatabase();
  const response = await signIn(database);
  assert.equal(response.status, 201);
  assert.match(response.headers.get("set-cookie") ?? "", /xuanyuan_session=/);
  const payload = await response.json();
  assert.equal(payload.member.walletAddress, buyer.address);
  assert.equal(payload.member.email, null);
  assert.equal(payload.member.balance, 5);
  assert.equal(payload.member.dailyCredits, 5);
  assert.match(payload.member.inviteCode, /^XU[A-Z0-9]{8}$/);
  assert.equal(database.nonces.size, 0, "nonce is single-use");

  const again = await signIn(database);
  assert.equal(again.status, 200);
  assert.equal(database.members.length, 1, "returning wallets reuse their account");
});

test("rejects a signature from a different wallet or a replayed message", async () => {
  const database = walletDatabase();
  const nonceResponse = await api.handleCommerceApi(
    new Request("https://preview.example/api/auth/wallet/nonce", { method: "POST", headers, body: JSON.stringify({ address: buyer.address }) }),
    { ...env, DB: database },
  );
  const { message } = await nonceResponse.json();
  const stranger = privateKeyToAccount("0x8b3a350cf5c34c9194ca85829a2df0ec3153be0318b5e2d3348e872092edffba");
  const forged = await stranger.signMessage({ message });
  const rejected = await api.handleCommerceApi(
    new Request("https://preview.example/api/auth/wallet/verify", { method: "POST", headers, body: JSON.stringify({ address: buyer.address, message, signature: forged }) }),
    { ...env, DB: database },
  );
  assert.equal(rejected.status, 401);
  assert.deepEqual(await rejected.json(), { error: "Wallet signature is invalid" });
  assert.equal(database.members.length, 0);
});

test("stores a wallet invitation on join without issuing the purchase reward", async () => {
  const database = walletDatabase();
  database.members.push({ id: "inviter-1", email: null, wallet_address: "0x2222222222222222222222222222222222222222", credits: 5, invite_code: "XUINVITE88" });
  const response = await signIn(database, "xuinvite88");
  assert.equal(response.status, 201);
  assert.equal((await response.json()).member.balance, 5);
  assert.equal(database.members.find((member) => member.id === "inviter-1").credits, 5);
  assert.equal(database.members.find((member) => member.id !== "inviter-1").invited_by_member_id, "inviter-1");
});

function purchaseLog(overrides = {}) {
  const item = policy.packageById("seed");
  const args = {
    buyer: buyer.address,
    packageId: chain.packageKey(item.id),
    usdtAmount: policy.packageUsdtWei(item.id),
    credits: item.credits,
    feeWei: policy.platformFeeWei,
    saleIndex: 7n,
    ...overrides,
  };
  const topics = encodeEventTopics({ abi: chain.creditStoreAbi, eventName: "Purchased", args: { buyer: args.buyer, packageId: args.packageId } });
  const data = encodeAbiParameters(
    [{ type: "uint256" }, { type: "uint32" }, { type: "uint256" }, { type: "uint256" }],
    [args.usdtAmount, args.credits, args.feeWei, args.saleIndex],
  );
  return { address: env.CREDIT_STORE_ADDRESS, topics, data, blockNumber: "0x64", transactionHash: txHash, transactionIndex: "0x0", blockHash: pad("0x1", { size: 32 }), logIndex: "0x0", removed: false };
}

const txHash = "0x" + "ab".repeat(32);

function mockRpc({ receipt, latestBlock = 0x70, transaction = null }) {
  return async (_url, init) => {
    const body = JSON.parse(init.body);
    const calls = Array.isArray(body) ? body : [body];
    const results = calls.map((call) => {
      let result = null;
      if (call.method === "eth_getTransactionReceipt") result = receipt;
      if (call.method === "eth_getTransactionByHash") result = transaction;
      if (call.method === "eth_blockNumber") result = numberToHex(latestBlock);
      if (call.method === "eth_chainId") result = "0x38";
      return { jsonrpc: "2.0", id: call.id, result };
    });
    return new Response(JSON.stringify(Array.isArray(body) ? results : results[0]), { status: 200, headers: { "content-type": "application/json" } });
  };
}

function receiptWith(logs, status = "0x1", to = env.CREDIT_STORE_ADDRESS) {
  return { status, to, from: buyer.address, blockNumber: "0x64", blockHash: pad("0x1", { size: 32 }), transactionHash: txHash, transactionIndex: "0x0", logs, cumulativeGasUsed: "0x1", gasUsed: "0x1", effectiveGasPrice: "0x1", logsBloom: "0x" + "0".repeat(512), type: "0x0", contractAddress: null };
}

async function purchase(database, transactionHash = txHash, extra = {}, inviteCode, envOverrides = {}) {
  const session = await signIn(database, inviteCode);
  const cookie = session.headers.get("set-cookie").split(";")[0];
  return api.handleCommerceApi(
    new Request("https://preview.example/api/orders", { method: "POST", headers: { ...headers, cookie }, body: JSON.stringify({ transactionHash, ...extra }) }),
    { ...env, ...envOverrides, DB: database },
  );
}

test("USDC checkout authenticates only its configured contract, records currency, and cannot double-credit", async () => {
  const database = walletDatabase();
  const newStore = "0x3333333333333333333333333333333333333333";
  const override = { USDC_CHECKOUT_ADDRESS: newStore, USDC_CHECKOUT_ENABLED: "true" };
  const originalFetch = globalThis.fetch;
  try {
    globalThis.fetch = mockRpc({ receipt: receiptWith([purchaseLog()]) });
    const wrongContract = await purchase(database, txHash, { checkout: "usdc", packageId: "seed" }, undefined, override);
    assert.equal((await wrongContract.json()).code, "NO_PURCHASE_EVENT");
    assert.equal(database.orders.length, 0);
    globalThis.fetch = mockRpc({ receipt: receiptWith([{ ...purchaseLog(), address: newStore }]) });
    const success = await purchase(database, txHash, { checkout: "usdc", packageId: "seed" }, undefined, override);
    assert.equal(success.status, 201);
    const result = await success.json();
    assert.equal(result.order.settlementCurrency, "USDC");
    assert.equal(result.member.balance, 25);
    const again = await purchase(database, txHash, { checkout: "usdc" }, undefined, override);
    assert.equal((await again.json()).duplicate, true);
    assert.equal(database.members[0].credits, 20);
  } finally { globalThis.fetch = originalFetch; }
});

test("USDC checkout fails closed until a distinct address is configured", async () => {
  const noConfig = await purchase(walletDatabase(), txHash, { checkout: "usdc" });
  assert.equal(noConfig.status, 503);
  const sameStore = await purchase(walletDatabase(), txHash, { checkout: "usdc" }, undefined, { USDC_CHECKOUT_ADDRESS: env.CREDIT_STORE_ADDRESS, USDC_CHECKOUT_ENABLED: "true" });
  assert.equal(sameStore.status, 503);
  const testnet = await purchase(walletDatabase(), txHash, { checkout: "usdc" }, undefined, { BSC_CHAIN_ID: "97", USDC_CHECKOUT_ADDRESS: "0x3333333333333333333333333333333333333333", USDC_CHECKOUT_ENABLED: "true" });
  assert.equal(testnet.status, 503);
});

test("USDC purchase entry is opt-in, but disabling it does not block verification of an already-paid order", async () => {
  const newStore = "0x3333333333333333333333333333333333333333";
  const configResponse = async (flags) => (await (await api.handleCommerceApi(new Request("https://preview.example/api/checkout/config"), { ...env, ...flags })).json());
  assert.equal((await configResponse({ USDC_CHECKOUT_ADDRESS: newStore })).usdcCheckoutAddress, null);
  assert.equal((await configResponse({ USDC_CHECKOUT_ADDRESS: newStore, USDC_CHECKOUT_ENABLED: "true" })).usdcCheckoutAddress, newStore);
  assert.equal((await configResponse({ USDC_CHECKOUT_ADDRESS: newStore, USDC_CHECKOUT_REPLACE_LEGACY: "true" })).usdcOnly, false);
  assert.equal((await configResponse({ USDC_CHECKOUT_ADDRESS: newStore, USDC_CHECKOUT_ENABLED: "true", USDC_CHECKOUT_REPLACE_LEGACY: "true" })).usdcOnly, true);
  const database = walletDatabase(); const originalFetch = globalThis.fetch;
  try {
    globalThis.fetch = mockRpc({ receipt: receiptWith([{ ...purchaseLog(), address: newStore }]) });
    const response = await purchase(database, txHash, { checkout: "usdc" }, undefined, { USDC_CHECKOUT_ADDRESS: newStore, USDC_CHECKOUT_ENABLED: "false" });
    assert.equal(response.status, 201); assert.equal((await response.json()).order.settlementCurrency, "USDC");
  } finally { globalThis.fetch = originalFetch; }
});

test("awards 5 credits to both sides only after an invited wallet purchase is verified", async () => {
  const database = walletDatabase();
  database.members.push({ id: "inviter-1", email: null, wallet_address: "0x2222222222222222222222222222222222222222", credits: 5, daily_credits: 0, daily_credit_date: null, invite_code: "XUINVITE88" });
  const originalFetch = globalThis.fetch;
  globalThis.fetch = mockRpc({ receipt: receiptWith([purchaseLog()]) });
  try {
    const response = await purchase(database, txHash, { packageId: "seed" }, "XUINVITE88");
    assert.equal(response.status, 201);
    const payload = await response.json();
    assert.equal(payload.member.balance, 30); // 20 purchased + 5 invitation + 5 daily bucket
    assert.equal(database.members.find((member) => member.id === "inviter-1").credits, 10);
    assert.equal(database.ledger.filter((entry) => entry.reason === "invitation_purchase").length, 2);

    const replay = await purchase(database, txHash, { packageId: "seed" }, "XUINVITE88");
    assert.equal((await replay.json()).duplicate, true);
    assert.equal(database.members.find((member) => member.id === "inviter-1").credits, 10);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("credits a member automatically from a verified on-chain purchase and blocks replays", async () => {
  const database = walletDatabase();
  const originalFetch = globalThis.fetch;
  globalThis.fetch = mockRpc({ receipt: receiptWith([purchaseLog()]) });
  try {
    const response = await purchase(database, txHash, { packageId: "seed" });
    assert.equal(response.status, 201);
    const payload = await response.json();
    assert.equal(payload.order.status, "approved");
    assert.equal(payload.order.credits, 20);
    assert.equal(payload.order.amountUsdt, "4.99");
    assert.equal(payload.order.buyerAddress, buyer.address);
    assert.equal(payload.order.feeWei, policy.platformFeeWei.toString());
    assert.equal(payload.member.balance, 25);
    assert.equal(database.batches.length, 1, "insert + approve run in one batch");
    assert.equal(database.ledger.find((entry) => entry.reason === "payment_approval")?.reason, "payment_approval");

    const replay = await purchase(database);
    assert.equal(replay.status, 200);
    assert.equal((await replay.json()).duplicate, true);
    assert.equal(database.members[0].credits, 20, "a replayed hash never credits twice");
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("refuses purchases that were not made by the signed-in wallet, reverted, or are unconfirmed", async () => {
  const originalFetch = globalThis.fetch;
  try {
    globalThis.fetch = mockRpc({ receipt: receiptWith([purchaseLog({ buyer: "0x3333333333333333333333333333333333333333" })]) });
    let response = await purchase(walletDatabase());
    assert.equal(response.status, 403);
    assert.equal((await response.json()).code, "WRONG_BUYER");

    globalThis.fetch = mockRpc({ receipt: receiptWith([purchaseLog()], "0x0") });
    response = await purchase(walletDatabase());
    assert.equal((await response.json()).code, "TX_REVERTED");

    globalThis.fetch = mockRpc({ receipt: receiptWith([purchaseLog({ feeWei: 1n })]) });
    response = await purchase(walletDatabase());
    assert.equal((await response.json()).code, "FEE_MISMATCH");

    globalThis.fetch = mockRpc({ receipt: receiptWith([purchaseLog()]), latestBlock: 0x64 });
    response = await purchase(walletDatabase());
    assert.equal(response.status, 202);
    assert.equal((await response.json()).code, "NOT_CONFIRMED");

    globalThis.fetch = mockRpc({ receipt: null, transaction: { hash: txHash } });
    response = await purchase(walletDatabase());
    assert.equal(response.status, 202);
    assert.equal((await response.json()).code, "TX_PENDING");

    globalThis.fetch = mockRpc({ receipt: receiptWith([{ ...purchaseLog(), address: "0x4444444444444444444444444444444444444444" }], "0x1", "0x4444444444444444444444444444444444444444") });
    response = await purchase(walletDatabase());
    assert.equal((await response.json()).code, "NO_PURCHASE_EVENT");
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("credits executor-routed purchases exactly once from the authenticated store event", async () => {
  const database = walletDatabase();
  const originalFetch = globalThis.fetch;
  globalThis.fetch = mockRpc({ receipt: receiptWith([purchaseLog()], "0x1", "0x4444444444444444444444444444444444444444") });
  try {
    assert.equal((await purchase(database)).status, 201);
    assert.equal(database.members[0].credits, 20);
    assert.equal((await purchase(database)).status, 200);
    assert.equal(database.members[0].credits, 20);
  } finally { globalThis.fetch = originalFetch; }
});

test("keeps checkout disabled until the owner deploys the contract", async () => {
  const response = await api.handleCommerceApi(new Request("https://preview.example/api/checkout/config"), { SESSION_SECRET: env.SESSION_SECRET });
  assert.equal(response.status, 200);
  const config = await response.json();
  assert.equal(config.enabled, false);
  assert.equal(config.chainId, 56);
  assert.equal(config.platformFeeWei, policy.platformFeeWei.toString());

  const configured = await (await api.handleCommerceApi(new Request("https://preview.example/api/checkout/config"), env)).json();
  assert.equal(configured.enabled, true);
  assert.equal(configured.contractAddress, env.CREDIT_STORE_ADDRESS);
});

test("switches the whole checkout to BSC testnet with a mock USDT via environment", async () => {
  const testnetEnv = { ...env, BSC_CHAIN_ID: "97" };
  const withoutUsdt = await (await api.handleCommerceApi(new Request("https://preview.example/api/checkout/config"), testnetEnv)).json();
  assert.equal(withoutUsdt.chainId, 97);
  assert.equal(withoutUsdt.testnet, true);
  assert.equal(withoutUsdt.usdtAddress, null);
  assert.equal(withoutUsdt.enabled, false, "testnet needs USDT_ADDRESS before checkout opens");

  const ready = await (await api.handleCommerceApi(new Request("https://preview.example/api/checkout/config"), { ...testnetEnv, USDT_ADDRESS: "0x5555555555555555555555555555555555555555" })).json();
  assert.equal(ready.enabled, true);
  assert.equal(ready.chainHexId, "0x61");
  assert.equal(ready.explorerUrl, "https://testnet.bscscan.com");
  assert.equal(ready.usdtAddress, "0x5555555555555555555555555555555555555555");

  const nonceResponse = await api.handleCommerceApi(
    new Request("https://preview.example/api/auth/wallet/nonce", { method: "POST", headers, body: JSON.stringify({ address: buyer.address }) }),
    { ...testnetEnv, DB: walletDatabase() },
  );
  assert.match((await nonceResponse.json()).message, /Chain ID: 97/);
});

test("links a wallet to a signed-in email account instead of creating a second member", async () => {
  const database = walletDatabase();
  database.members.push({ id: "email-1", email: "member@example.com", wallet_address: null, credits: 7, invite_code: "XUEMAIL001" });
  database.prepare = ((original) => (query) => {
    const statement = original(query);
    if (query.startsWith("UPDATE members SET wallet_address = ?")) {
      const run = statement.run.bind(statement);
      let bindings = [];
      statement.bind = (...values) => { bindings = values; return statement; };
      statement.run = async () => { const member = database.members.find((m) => m.id === bindings[2]); if (member && !member.wallet_address) member.wallet_address = bindings[0]; return run(); };
    }
    return statement;
  })(database.prepare);
  const token = await api.createSessionToken({ sub: "email-1", email: "member@example.com", role: "member" }, env.SESSION_SECRET);
  const cookieHeaders = { ...headers, cookie: `xuanyuan_session=${token}` };
  const nonceResponse = await api.handleCommerceApi(
    new Request("https://preview.example/api/auth/wallet/nonce", { method: "POST", headers: cookieHeaders, body: JSON.stringify({ address: buyer.address }) }),
    { ...env, DB: database },
  );
  const { message } = await nonceResponse.json();
  const signature = await buyer.signMessage({ message });
  const response = await api.handleCommerceApi(
    new Request("https://preview.example/api/auth/wallet/verify", { method: "POST", headers: cookieHeaders, body: JSON.stringify({ address: buyer.address, message, signature }) }),
    { ...env, DB: database },
  );
  assert.equal(response.status, 200);
  const payload = await response.json();
  assert.equal(payload.linked, true);
  assert.equal(payload.member.id, "email-1");
  assert.equal(payload.member.email, "member@example.com");
  assert.equal(payload.member.walletAddress, buyer.address);
  assert.equal(payload.member.balance, 12);
  assert.equal(payload.member.dailyCredits, 5);
  assert.equal(database.members.length, 1);

  // Another account cannot claim the same wallet.
  const otherToken = await api.createSessionToken({ sub: "email-2", email: "other@example.com", role: "member" }, env.SESSION_SECRET);
  database.members.push({ id: "email-2", email: "other@example.com", wallet_address: null, credits: 0, invite_code: "XUEMAIL002" });
  const nonce2 = await (await api.handleCommerceApi(new Request("https://preview.example/api/auth/wallet/nonce", { method: "POST", headers: { ...headers, cookie: `xuanyuan_session=${otherToken}` }, body: JSON.stringify({ address: buyer.address }) }), { ...env, DB: database })).json();
  const signature2 = await buyer.signMessage({ message: nonce2.message });
  const refused = await api.handleCommerceApi(
    new Request("https://preview.example/api/auth/wallet/verify", { method: "POST", headers: { ...headers, cookie: `xuanyuan_session=${otherToken}` }, body: JSON.stringify({ address: buyer.address, message: nonce2.message, signature: signature2 }) }),
    { ...env, DB: database },
  );
  assert.equal(refused.status, 409);
});

test("the chain watcher credits a purchase the browser never reported, exactly once", async () => {
  const database = walletDatabase();
  database.members.push({ id: "m-1", email: null, wallet_address: buyer.address, credits: 0, invite_code: "XUWATCH001" });
  const settings = new Map();
  const original = database.prepare;
  database.prepare = (query) => {
    const statement = original(query);
    if (query.startsWith("SELECT value FROM app_settings")) statement.first = async () => (settings.has("chain_sync_last_block") ? { value: settings.get("chain_sync_last_block") } : null);
    if (query.startsWith("INSERT INTO app_settings")) { let b = []; statement.bind = (...v) => { b = v; return statement; }; statement.run = async () => { settings.set(b[0], b[1]); return { meta: { changes: 1 } }; }; }
    return statement;
  };
  const originalFetch = globalThis.fetch;
  const log = purchaseLog();
  globalThis.fetch = async (_url, init) => {
    const body = JSON.parse(init.body); const calls = Array.isArray(body) ? body : [body];
    const results = calls.map((call) => ({ jsonrpc: "2.0", id: call.id, result: call.method === "eth_blockNumber" ? numberToHex(0x200) : call.method === "eth_getLogs" ? [log] : call.method === "eth_chainId" ? "0x38" : null }));
    return new Response(JSON.stringify(Array.isArray(body) ? results : results[0]), { status: 200, headers: { "content-type": "application/json" } });
  };
  try {
    const first = await api.syncPurchasesFromChain({ ...env, DB: database });
    assert.equal(first.scanned, true);
    assert.equal(first.credited, 1);
    assert.equal(database.members[0].credits, 20);
    assert.equal(database.orders[0].reviewed_by, "chain:watcher");
    assert.equal(settings.get("chain_sync_last_block"), String(0x200 - 3));

    const second = await api.syncPurchasesFromChain({ ...env, DB: database });
    assert.equal(second.credited, 0, "already-recorded hash is skipped");
    assert.equal(database.members[0].credits, 20);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("chain watcher retries the same block after a database write failure", async () => {
  const database = walletDatabase();
  database.members.push({ id: "m-1", email: null, wallet_address: buyer.address, credits: 0, invite_code: "XUWATCH001" });
  const settings = new Map(); const originalPrepare = database.prepare;
  database.prepare = (query) => {
    const statement = originalPrepare(query);
    if (query.startsWith("SELECT value FROM app_settings")) { let values = []; statement.bind = (...v) => { values = v; return statement; }; statement.first = async () => settings.has(values[0]) ? { value: settings.get(values[0]) } : null; }
    if (query.startsWith("INSERT INTO app_settings")) { let values = []; statement.bind = (...v) => { values = v; return statement; }; statement.run = async () => { settings.set(values[0], values[1]); return { meta: { changes: 1 } }; }; }
    return statement;
  };
  const originalBatch = database.batch; database.batch = async () => { throw Error("database temporarily unavailable"); };
  const originalFetch = globalThis.fetch; const log = purchaseLog();
  globalThis.fetch = async (_url, init) => { const body = JSON.parse(init.body); const calls = Array.isArray(body) ? body : [body]; const results = calls.map((call) => ({ jsonrpc: "2.0", id: call.id, result: call.method === "eth_blockNumber" ? numberToHex(0x200) : call.method === "eth_getLogs" ? [log] : call.method === "eth_chainId" ? "0x38" : null })); return new Response(JSON.stringify(Array.isArray(body) ? results : results[0]), { status: 200, headers: { "content-type": "application/json" } }); };
  try {
    const failed = await api.syncPurchasesFromChain({ ...env, DB: database });
    assert.equal(failed.reason, "order write failed"); assert.equal(settings.size, 0); assert.equal(database.members[0].credits, 0);
    database.batch = originalBatch;
    const recovered = await api.syncPurchasesFromChain({ ...env, DB: database });
    assert.equal(recovered.credited, 1); assert.equal(database.members[0].credits, 20); assert.equal(settings.get("chain_sync_last_block"), String(0x200 - 3));
  } finally { globalThis.fetch = originalFetch; }
});
