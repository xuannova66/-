import assert from "node:assert/strict";
import test from "node:test";

const { almanacDay, almanacMonth, goodDaysFor, rateDay, shiftIso, activityKeys } = await import("../app/almanac.ts");
const copy = await import("../app/almanac-copy.ts");
const locales = ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"];

test("a day has favourable and unfavourable lists, a clash, twelve hours and a rating", () => {
  const day = almanacDay("2026-11-03");
  assert.equal(day.lunarMonth, 9); assert.equal(day.lunarDay, 25);
  assert.equal(day.dayGanZhi, "辛巳");
  assert.ok(day.yi.includes("交易") && day.ji.includes("嫁娶"));
  assert.equal(day.clashZodiac, "猪"); assert.equal(day.clashGanZhi, "乙亥");
  assert.equal(day.hours.length, 12);
  assert.equal(day.activities.wedding, "no"); assert.equal(day.activities.contract, "yes");
  assert.equal(day.rating, "good"); // 明堂 (Yellow Path) and the 危 officer
});

test("rating rules and helpers", () => {
  assert.equal(rateDay("吉", "成", ["嫁娶"]), "good");
  assert.equal(rateDay("凶", "破", ["嫁娶"]), "care");
  assert.equal(rateDay("吉", "破", ["嫁娶"]), "care");
  assert.equal(rateDay("吉", "满", ["嫁娶"]), "ordinary");
  assert.equal(rateDay("吉", "成", ["诸事不宜"]), "care");
  assert.equal(shiftIso("2026-12-31", 1), "2027-01-01");
  assert.equal(almanacMonth(2026, 2).length, 28);
  for (const day of goodDaysFor("move", 2026, 12)) assert.equal(day.activities.move, "yes");
});

test("almanac texts exist in all seven languages", () => {
  for (const [name, value] of Object.entries(copy.almanacText)) for (const locale of locales) assert.ok(value[locale], `${name}.${locale}`);
  for (const key of activityKeys) for (const locale of locales) assert.ok(copy.activityLabels[key][locale]);
});
