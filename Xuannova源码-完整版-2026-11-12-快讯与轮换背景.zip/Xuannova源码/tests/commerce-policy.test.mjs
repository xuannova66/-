import assert from "node:assert/strict";
import test from "node:test";

const policy = await import("../worker/commerce-policy.ts");

test("publishes the four manual-transfer networks plus the BSC checkout chain without exposing credentials", () => {
  assert.deepEqual(
    policy.paymentNetworks.map(({ id, label, address, qrImage }) => ({ id, label, address, qrImage })),
    [
      {
        id: "trc20",
        label: "USDT · TRON (TRC20)",
        address: "TMkFTkWbkjnUpCTiYx87QyTTjXiS2ogGqi",
        qrImage: "/payments/usdt-trc20.svg",
      },
      {
        id: "bsc",
        label: "USDT · BNB Chain (BEP20)",
        address: "0x9E946751c432E4FCd05C463956122793ab64202e",
        qrImage: "/payments/usdt-bsc-bep20.svg",
      },
      {
        id: "erc20",
        label: "USDC / USDT · Ethereum (ERC20)",
        address: "0x84F33708ab4b7DEFd9Be5EC50911797E34009caA",
        qrImage: "/payments/ethereum-erc20.svg",
      },
      {
        id: "solana",
        label: "USDC / USDT · Solana (SPL)",
        address: "BzDaU6VKyMtN14QeVuCMva2SGmHLeeYy2GAAG9muJNq2",
        qrImage: "/payments/solana-spl.svg",
      },
    ],
  );
  assert.equal(policy.bscChain.id, 56);
  assert.equal(policy.bscChain.hexId, "0x38");
  assert.equal(policy.bscChain.usdtAddress, "0x55d398326f99059fF775485246999027B3197955");
});

test("charges a flat 0.00007 BNB platform fee on every purchase", () => {
  assert.equal(policy.platformFeeBnb, "0.00007");
  assert.equal(policy.platformFeeWei, 70_000_000_000_000n);
});

test("lists the four supported browser wallets", () => {
  assert.deepEqual(policy.walletProviders.map((item) => item.id), ["metamask", "tokenpocket", "binance", "okx"]);
});

test("keeps the owner-defined packages and interpretation credit policy immutable", () => {
  assert.deepEqual(
    policy.creditPackages.map(({ id, name, usdt, credits }) => ({ id, name, usdt, credits })),
    [
      { id: "seed", name: "入门体验包", usdt: "4.99", credits: 20 },
      { id: "path", name: "热门套餐", usdt: "9.90", credits: 50 },
      { id: "ritual", name: "大容量套餐", usdt: "19.90", credits: 120 },
      { id: "synthesis", name: "至尊旗舰套餐", usdt: "39.90", credits: 280 },
    ],
  );
  assert.equal(policy.packageById("ritual")?.credits, 120);
  assert.equal(policy.packageById("unknown"), undefined);
  assert.equal(policy.packageUsdtWei("seed"), 4_990_000_000_000_000_000n);
  assert.equal(policy.packageUsdtWei("synthesis"), 39_900_000_000_000_000_000n);
  assert.equal(policy.packageUsdtWei("unknown"), 0n);
  assert.equal(policy.interpretationCost("hecan"), 20);
  assert.equal(policy.interpretationCost("bazi"), 20);
  assert.equal(policy.interpretationCost("toolkit-tarot"), 20);
});
