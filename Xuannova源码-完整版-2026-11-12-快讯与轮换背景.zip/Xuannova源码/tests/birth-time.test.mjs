import assert from "node:assert/strict";
import test from "node:test";

const { createCompleteChart } = await import("../app/chart-model.ts");
const { createStudyResult } = await import("../app/study-engine.ts");
const { HOUR_REQUIRED_ROUTES, EXAMPLE_BIRTH, birthTimeText } = await import("../app/birth-time.ts");

const input = { birthDate: "1994-08-18", birthTime: "12:00", calendar: "solar", focus: "", name: "", companionName: "", module: "bazi", version: 1, place: "Global" };

test("unknown birth time leaves the hour pillar out of the chart", () => {
  const known = createCompleteChart(input);
  const unknown = createCompleteChart({ ...input, timeUnknown: true });
  assert.ok(unknown.sections.some((section) => section.id === "birth-time-unknown"));
  assert.ok(!known.sections.some((section) => section.id === "birth-time-unknown"));
  const json = JSON.stringify(unknown.board.cells[3]);
  assert.ok(json.includes("Hour unknown"), json);
});

test("unknown birth time never applies true solar time", () => {
  const result = createStudyResult({ ...input, timeUnknown: true, place: "Beijing" });
  assert.ok(!result.solarTiming);
});

test("hour-dependent methods and example data are declared", () => {
  for (const route of ["ziwei", "qizheng", "tieban", "heluo"]) assert.ok(HOUR_REQUIRED_ROUTES.has(route));
  assert.ok(!HOUR_REQUIRED_ROUTES.has("bazi"));
  assert.equal(EXAMPLE_BIRTH.date, "1994-08-18");
  for (const key of ["unknown", "example", "basisTitle", "hourUnknown"]) assert.equal(Object.values(birthTimeText[key]).filter(Boolean).length, 7, key);
});
