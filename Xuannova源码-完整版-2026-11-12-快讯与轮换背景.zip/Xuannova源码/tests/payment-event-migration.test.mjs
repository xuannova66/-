import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { openDatabase } from "../server/sqlite-db.ts";

test("event identity migration preserves historical orders, balances and ledger references", () => {
  const db = openDatabase(":memory:");
  const dir = new URL("../migrations/", import.meta.url);
  for (const file of readdirSync(dir).filter((name) => name.endsWith(".sql") && name < "0018").sort()) db.raw.exec(readFileSync(new URL(file, dir), "utf8"));
  const now = "2026-01-01T00:00:00Z";
  db.raw.prepare("INSERT INTO members(id,wallet_address,credits,role,created_at,updated_at) VALUES(?,?,?,?,?,?)").run("m", "0x1111111111111111111111111111111111111111", 7, "member", now, now);
  db.raw.prepare("INSERT INTO payment_orders(id,member_id,package_id,amount_usdt,credits,network,transaction_hash,status,submitted_at,reviewed_at) VALUES(?,?,?,?,?,?,?,?,?,?)").run("old", "m", "seed", "4.99", 20, "bsc", "0xold", "pending", now, now);
  db.raw.prepare("UPDATE payment_orders SET status='approved' WHERE id='old'").run();
  assert.equal(db.raw.prepare("SELECT credits FROM members WHERE id='m'").get().credits, 27);
  db.raw.exec("PRAGMA foreign_keys=OFF; BEGIN;");
  db.raw.exec(readFileSync(new URL("0018_payment_order_event_identity.sql", dir), "utf8"));
  assert.deepEqual(db.raw.prepare("PRAGMA foreign_key_check").all(), []);
  db.raw.exec("COMMIT; PRAGMA foreign_keys=ON;");
  assert.equal(db.raw.prepare("SELECT credits FROM members WHERE id='m'").get().credits, 27);
  assert.equal(db.raw.prepare("SELECT order_id FROM credit_ledger WHERE order_id='old'").get().order_id, "old");
  assert.equal(db.raw.prepare("SELECT status FROM payment_orders WHERE id='old'").get().status, "approved");
  assert.deepEqual(db.raw.prepare("PRAGMA foreign_key_check").all(), []);
  db.raw.close();
});
