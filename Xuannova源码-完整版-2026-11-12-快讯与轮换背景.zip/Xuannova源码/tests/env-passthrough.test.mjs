// The AWS (Node) server answers /api/* through app/api/[...path]/route.ts, Cloudflare through worker/index.ts.
// Both must pass the same settings to the API, or a feature works in one place and silently not in the other.
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const keys = (file) => new Set([...readFileSync(new URL(file, import.meta.url), "utf8").matchAll(/^\s+([A-Z][A-Z0-9_]+): process\.env\.\1,/gm)].map((match) => match[1]));
test("the Node API route passes every environment setting the worker passes", () => {
  const worker = keys("../worker/index.ts"), route = keys("../app/api/[...path]/route.ts");
  assert.ok(worker.size > 20);
  assert.deepEqual([...worker].filter((key) => !route.has(key)), []);
});
