import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { openDatabase } from "../server/sqlite-db.ts";
import { createSolanaDirectOrder, settleSolanaDirectOrder } from "../worker/solana-order-settlement.draft.ts";

test("Solana direct settlement binds wallet, order, final transaction and credits exactly once", async () => {
  const db = openDatabase(":memory:");
  try {
    const dir = new URL("../migrations/", import.meta.url);
    for (const file of readdirSync(dir).filter(x => x.endsWith(".sql")).sort()) db.raw.exec(readFileSync(new URL(file, dir), "utf8"));
    db.raw.exec(readFileSync(new URL("../db/drafts/multichain-orders.sql", import.meta.url), "utf8"));
    const now = "2026-01-01T00:00:00Z", buyer = "B".repeat(32), ata = "C".repeat(32), signature = "D".repeat(88);
    db.raw.prepare("INSERT INTO members(id,credits,daily_credits,role,created_at,updated_at) VALUES(?,?,?,?,?,?)").run("m",10,0,"member",now,now);
    await assert.rejects(createSolanaDirectOrder(db,{memberId:"m",buyer,packageId:"seed",now}),/WALLET_NOT_LINKED/);
    db.raw.prepare("INSERT INTO member_wallet_links_v2(chain,address,member_id,linked_at) VALUES(?,?,?,?)").run("solana",buyer,"m",1);
    const order = await createSolanaDirectOrder(db,{memberId:"m",buyer,packageId:"seed",now});
    const token = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA", memo = "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr";
    const balance = amount => ({accountIndex:1,mint:order.mint,owner:order.recipient,programId:token,uiTokenAmount:{amount,decimals:6}});
    const tx = {meta:{err:null,preTokenBalances:[balance("0")],postTokenBalances:[balance(order.amountUnits)]},transaction:{signatures:[signature],message:{accountKeys:[{pubkey:buyer,signer:true},{pubkey:ata,signer:false}],instructions:[{programId:token,parsed:{type:"transferChecked",info:{authority:buyer,mint:order.mint,destination:ata,tokenAmount:{amount:order.amountUnits,decimals:6}}}},{programId:memo,parsed:order.reference}]}}};
    const fetcher = async (_url, init) => { const method=JSON.parse(init.body).method; return Response.json({jsonrpc:"2.0",id:1,result:method==="getGenesisHash"?"5eykt4UsFv8P8NJdTREpY1vzqKqZKvdpKuc147dw2N9d":method==="getSignatureStatuses"?{value:[{confirmationStatus:"finalized",err:null}]}:tx}); };
    const input = {memberId:"m",orderId:order.id,signature,recipientTokenAccount:ata,now,fetcher};
    await assert.rejects(settleSolanaDirectOrder(db,{...input,memberId:"other"}),/ORDER_NOT_FOUND/);
    await assert.rejects(settleSolanaDirectOrder(db,{...input,recipientTokenAccount:"E".repeat(32)}),/RECIPIENT_ACCOUNT_MISSING/);
    assert.equal(db.raw.prepare("SELECT credits FROM members WHERE id='m'").get().credits,10);
    const results = await Promise.all([settleSolanaDirectOrder(db,input),settleSolanaDirectOrder(db,input)]);
    assert.equal(results.filter(r => !r.alreadyCredited).length,1);
    assert.equal(db.raw.prepare("SELECT credits FROM members WHERE id='m'").get().credits,30);
    assert.equal(db.raw.prepare("SELECT count(*) AS n FROM credit_ledger WHERE id=?").get(`multichain-draft:${order.id}`).n,1);
    await assert.rejects(settleSolanaDirectOrder(db,{...input,signature:"E".repeat(88)}),/ORDER_ALREADY_CREDITED/);
  } finally { db.raw.close(); }
});
