import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

async function render() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(
    new Request("http://localhost/", {
      headers: { accept: "text/html" },
    }),
    {
      ASSETS: {
        fetch: async () => new Response("Not found", { status: 404 }),
      },
    },
    {
      waitUntil() {},
      passThroughOnException() {},
    },
  );
}

test("server-renders Xuannova's multilingual study site", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(html, /<title>Xuannova · Eastern traditional culture study<\/title>/i);
  assert.match(html, /Xuannova/i);
  assert.match(html, /What would you like to explore\?/i);
  assert.match(html, /Create a structured chart/i);
  assert.match(html, /BaZi/i);
  assert.match(html, /Qi Men/i);
  assert.match(html, /Daily Rhythm/i);
  assert.match(html, /All study methods/i);
  assert.match(html, /data-theme="nocturne"/i);
  assert.doesNotMatch(html, /Your site is taking shape|Building your site/i);
});

test("complete study charts expose a route-aware library handoff", async () => {
  const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
  const board = await readFile(new URL("../app/complete-chart-board.tsx", import.meta.url), "utf8");
  const library = await readFile(new URL("../app/library-explorer.tsx", import.meta.url), "utf8");

  assert.match(page, /onOpenLibrary/);
  assert.match(board, /studyShelf/);
  assert.match(library, /initialCategory/);
  assert.match(page, /<LibraryExplorer\s+key=\{initialCategory\}/);
  assert.doesNotMatch(library, /useEffect\(/);
});

test("study tools declare standalone input, ritual, chart, and reading stages", async () => {
  const source = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
  for (const marker of ["data-study-stage=\"input\"", "data-study-stage=\"ritual\"", "data-study-stage=\"chart\"", "data-study-stage=\"reading\""]) {
    assert.match(source, new RegExp(marker));
  }
  assert.match(source, /onStageChange\("ritual"\)/);
  assert.match(source, /onStageChange\("chart"\)/);
  assert.match(source, /onStageChange\("reading"\)/);
  assert.match(source, /navigateTo\(route, nextStage\)/, "each stage gets its own path URL");
});

test("native date and time controls synchronize during direct input", async () => {
  const source = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");

  // The daily page keeps its own date (default today) instead of reusing the birth date.
  assert.match(source, /type="date"\s+value=\{form\.dailyDate \|\| todayIso\(\)\}[\s\S]{0,600}onInput=\{\(event\)\s*=>\s*setForm\(\{ \.\.\.form, dailyDate: event\.currentTarget\.value \}\)\s*\}/);
  assert.match(source, /type="time"\s+value=\{form\.time\}[\s\S]{0,600}onInput=\{\(event\)\s*=>\s*setForm\(\{ \.\.\.form, time: event\.currentTarget\.value \}\)\s*\}/);
  assert.match(source, /type="date"\s+value=\{fields\.date === "event" \? eventDate \|\| todayIso\(\) : toolDate\}[\s\S]{0,480}onInput=\{\(event\)\s*=>\s*\(fields\.date === "event" \? setEventDate : setToolDate\)\(event\.currentTarget\.value\)\s*\}/);
  assert.match(source, /type="time"\s+value=\{toolTime\}[\s\S]{0,480}onInput=\{\(event\)\s*=>\s*setToolTime\(event\.currentTarget\.value\)\s*\}/);
});

test("the hero brand is not repeated in its English wordmark", async () => {
  const source = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
  assert.doesNotMatch(source, /<h1 id="hero-title"><span>\{shared\.home\.heroBrand\}<\/span><small>\{shared\.brandKicker\}<\/small><\/h1>/);
});

test("mobile header keeps account and administrator actions inside the navigation menu", async () => {
  const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");
  assert.match(styles, /@media \(max-width: 650px\) \{ \.header-actions \.credit-button, \.header-actions \.member-button, \.header-actions \.admin-button \{ display: none; \}/);
});

test("phone layouts confine dense charts and long member values without page overflow", async () => {
  const baseStyles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");
  const phoneStyles = await readFile(new URL("../app/mobile-polish.css", import.meta.url), "utf8");
  const styles = `${baseStyles}\n${phoneStyles}`;
  assert.match(styles, /@media \(max-width: 650px\) \{[\s\S]*\.study-stage-screen, \.membership-screen, \.credits-screen, \.admin-screen \{ overflow-x: clip; \}/);
  // All four pillars fit the phone width instead of needing a sideways scroll.
  assert.match(phoneStyles, /\.bazi-matrix \{ grid-template-columns: 54px repeat\(4, minmax\(0, 1fr\)\); \}/);
  assert.doesNotMatch(phoneStyles, /\.bazi-professional-main, \.bazi-context-rail \{ min-width: 500px; \}/);
  assert.match(styles, /\.commerce-qr code, \.commerce-orders b, \.admin-table code \{[^}]*overflow-wrap: anywhere[^}]*white-space: normal/);
});

test("toolkit action arrows use a CSS icon instead of an emoji glyph", async () => {
  const source = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
  const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");

  assert.doesNotMatch(source, /\{copy\.toolkit\.open\} ↗/);
  assert.match(source, /<b className="toolkit-open-label">\{copy\.toolkit\.open\}<\/b>/);
  assert.match(styles, /\.toolkit-open-label::after \{[^}]*content: ""[^}]*transform: rotate\(45deg\)/);
});

test("Liuyao exposes an interactive six-stage three-coin casting control", async () => {
  const source = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
  const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");

  assert.match(source, /throwThreeCoins/);
  assert.match(source, /lineStatesFromThrows/);
  assert.match(source, /coinThrows/);
  assert.match(source, /data-testid="liuyao-three-coin-cast"/);
  assert.match(source, /aria-live="polite"/);
  assert.match(styles, /\.coin-casting-panel/);
});
