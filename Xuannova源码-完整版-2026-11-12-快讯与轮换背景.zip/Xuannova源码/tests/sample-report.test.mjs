import assert from "node:assert/strict";
import test from "node:test";
import lunar from "lunar-javascript";

const { SAMPLE_CASE, sampleReports } = await import("../app/sample-report.tsx");

test("the sample report's chart is the real BaZi of its fictional birth data", () => {
  const [y, m, d] = SAMPLE_CASE.date.split("-").map(Number);
  const [h, min] = SAMPLE_CASE.time.split(":").map(Number);
  const chart = lunar.Solar.fromYmdHms(y, m, d, h, min, 0).getLunar().getEightChar();
  assert.deepEqual([chart.getYear(), chart.getMonth(), chart.getDay(), chart.getTime()], [...SAMPLE_CASE.pillars]);
});

test("every language marks the case as fictional and has the same structure", () => {
  for (const [locale, sample] of Object.entries(sampleReports)) {
    assert.ok(sample.badge && sample.disclaimer, locale);
    assert.equal(sample.keyPoints.length, 3, locale);
    assert.equal(sample.chapters.length, 6, locale);
    assert.equal(sample.mapping.length, 5, locale);
    assert.equal(sample.followUps.length, 3, locale);
    assert.ok(sample.ui.boundary.includes("{n}") && sample.ui.followLead.includes("{n}"), locale);
  }
});
