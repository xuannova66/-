import test from "node:test";
import assert from "node:assert/strict";
import {getFunctionSelector} from "viem";
import {createEthereumCheckoutControllerDraft} from "../app/ethereum-checkout-controller.draft.ts";
const buyer="0x1111111111111111111111111111111111111111",stable="0x2222222222222222222222222222222222222222",checkout="0x3333333333333333333333333333333333333333",wrapped="0x4444444444444444444444444444444444444444",hash=`0x${"ab".repeat(32)}`;
const word=x=>`0x${x.replace(/^0x/,"").toLowerCase().padStart(64,"0")}`;
function call(data,allowance){if(data===getFunctionSelector("settlement()"))return word(stable);if(data===getFunctionSelector("treasury()"))return word("0x84F33708ab4b7DEFd9Be5EC50911797E34009caA");if(data===getFunctionSelector("decimals()"))return word("06");return word(allowance.toString(16));}
test("draft controller connects, validates server order, authorizes, submits once and reads server status",async()=>{
 let allowance=0n,sends=0,network="0x38",submitted=false;const approval=`0x${"cd".repeat(32)}`;
 const provider={request:async ({method,params})=>{if(method==="eth_requestAccounts"||method==="eth_accounts")return [buyer];if(method==="eth_chainId")return network;if(method==="wallet_switchEthereumChain"){network="0x1";return null;}if(method==="eth_getCode")return "0x6000";if(method==="eth_call")return call(params[0].data,allowance);if(method==="eth_estimateGas")return "0x186a0";if(method==="eth_sendTransaction")return sends++===0?approval:hash;if(method==="eth_getTransactionReceipt")return {transactionHash:approval,status:"0x1",to:stable};throw Error("unexpected method");}};
 const values=new Map(),storage={getItem:k=>values.get(k)??null,setItem:(k,v)=>values.set(k,v),removeItem:k=>values.delete(k)};
 const fetcher=async (url)=>{if(url==="/api/draft/multichain-orders")return Response.json({id:"order-1",reference:`0x${"aa".repeat(32)}`,recipient:"0x84F33708ab4b7DEFd9Be5EC50911797E34009caA",amountUnits:"4990000"});if(url==="/api/draft/payment-attempts"){submitted=true;return Response.json({recorded:true});}if(url.startsWith("/api/draft/multichain-orders/status"))return Response.json({id:"order-1",status:submitted?"submitted":"awaiting_payment"});throw Error("unexpected URL");};
 const controller=createEthereumCheckoutControllerDraft({provider,memberId:"member1",packageId:"seed",checkout,settlement:stable,wrappedNative:wrapped,storage,fetcher,clock:()=>1000});
 await controller.connect();assert.equal(network,"0x1");assert.equal(await controller.approve(),"submitted");
 await assert.rejects(controller.approvalStatus(),/ALLOWANCE_NOT_CONFIRMED/);allowance=4990000n;assert.equal(await controller.approvalStatus(),"confirmed");
 assert.deepEqual(await controller.pay(),{hash,recoveryRecorded:true});assert.equal(await controller.status(),"submitted");assert.equal(values.size,0);
 await assert.rejects(controller.pay(),/ACTION_PENDING/);assert.equal(sends,2);
});
test("draft controller rejects a server order with an unexpected recipient before payment",async()=>{
 const provider={request:async({method,params})=>method==="eth_chainId"?"0x1":method==="eth_getCode"?"0x6000":method==="eth_call"?call(params[0].data,0n):[buyer]},storage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
 const controller=createEthereumCheckoutControllerDraft({provider,memberId:"member1",packageId:"seed",checkout,settlement:stable,wrappedNative:wrapped,storage,fetcher:async()=>Response.json({id:"order-1",reference:`0x${"aa".repeat(32)}`,recipient:buyer,amountUnits:"4990000"}),clock:()=>1000});
 await assert.rejects(controller.connect(),/ORDER_RESPONSE_INVALID/);
});
test("draft controller retains submitted hash when browser recovery storage fails",async()=>{
 const provider={request:async({method,params})=>{if(method==="eth_chainId")return "0x1";if(method==="eth_requestAccounts"||method==="eth_accounts")return [buyer];if(method==="eth_getCode")return "0x6000";if(method==="eth_call")return call(params[0].data,4990000n);if(method==="eth_estimateGas")return "0x186a0";if(method==="eth_sendTransaction")return hash;throw Error("unexpected");}};
 const storage={getItem:()=>null,setItem:()=>{throw Error("quota");},removeItem:()=>{}};
 const fetcher=async()=>Response.json({id:"order-1",reference:`0x${"aa".repeat(32)}`,recipient:"0x84F33708ab4b7DEFd9Be5EC50911797E34009caA",amountUnits:"4990000"});
 const controller=createEthereumCheckoutControllerDraft({provider,memberId:"member1",packageId:"seed",checkout,settlement:stable,wrappedNative:wrapped,storage,fetcher,clock:()=>1000});
 await controller.connect();assert.equal(await controller.approve(),"sufficient");
 assert.deepEqual(await controller.pay(),{hash,recoveryRecorded:false});
 await assert.rejects(controller.pay(),/ACTION_PENDING/);
});
test("concurrent clicks are blocked before the first wallet operation resolves",async()=>{
 let release;const pending=new Promise(resolve=>{release=resolve;});let calls=0;
 const provider={request:async()=>{calls++;await pending;throw Error("stopped");}};
 const storage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
 const controller=createEthereumCheckoutControllerDraft({provider,memberId:"member1",packageId:"seed",checkout,settlement:stable,wrappedNative:wrapped,storage,fetcher:async()=>{throw Error("unexpected");},clock:()=>1000});
 const first=controller.connect();await assert.rejects(controller.connect(),/ACTION_PENDING/);assert.equal(calls,1);
 release();await assert.rejects(first); 
});
test("an ambiguous approval submission blocks repeat approval and payment",async()=>{
 let sends=0;
 const provider={request:async({method,params})=>{
  if(method==="eth_chainId")return "0x1";if(method==="eth_requestAccounts"||method==="eth_accounts")return [buyer];
  if(method==="eth_getCode")return "0x6000";if(method==="eth_call")return call(params[0].data,0n);
  if(method==="eth_estimateGas")return "0x186a0";if(method==="eth_sendTransaction"){sends++;throw Error("timeout");}throw Error("unexpected");
 }};
 const storage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
 const fetcher=async()=>Response.json({id:"order-1",reference:`0x${"aa".repeat(32)}`,recipient:"0x84F33708ab4b7DEFd9Be5EC50911797E34009caA",amountUnits:"4990000"});
 const controller=createEthereumCheckoutControllerDraft({provider,memberId:"member1",packageId:"seed",checkout,settlement:stable,wrappedNative:wrapped,storage,fetcher,clock:()=>1000});
 await controller.connect();await assert.rejects(controller.approve(),/APPROVAL_OUTCOME_UNKNOWN/);
 await assert.rejects(controller.approve(),/ACTION_PENDING/);await assert.rejects(controller.pay(),/ACTION_PENDING/);assert.equal(sends,1);
});
test("explicit wallet rejection can be retried without treating it as a submitted transaction",async()=>{
 let sends=0;
 const provider={request:async({method,params})=>{
  if(method==="eth_chainId")return "0x1";if(method==="eth_requestAccounts"||method==="eth_accounts")return [buyer];
  if(method==="eth_getCode")return "0x6000";if(method==="eth_call")return call(params[0].data,0n);
  if(method==="eth_estimateGas")return "0x186a0";if(method==="eth_sendTransaction"){sends++;if(sends===1)throw Object.assign(Error("declined"),{code:4001});return hash;}throw Error("unexpected");
 }};
 const storage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
 const fetcher=async()=>Response.json({id:"order-1",reference:`0x${"aa".repeat(32)}`,recipient:"0x84F33708ab4b7DEFd9Be5EC50911797E34009caA",amountUnits:"4990000"});
 const controller=createEthereumCheckoutControllerDraft({provider,memberId:"member1",packageId:"seed",checkout,settlement:stable,wrappedNative:wrapped,storage,fetcher,clock:()=>1000});
 await controller.connect();await assert.rejects(controller.approve(),/WALLET_REQUEST_REJECTED/);assert.equal(sends,1);
 assert.equal(await controller.approve(),"submitted");assert.equal(sends,2);
});
