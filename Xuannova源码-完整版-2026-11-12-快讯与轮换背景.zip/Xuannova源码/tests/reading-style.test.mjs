// 普通版 / 专业版: the chosen style reaches the AI instructions — everyday language for 普通版, full terminology for 专业版.
import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import test from "node:test";

const { openDatabase } = await import("../server/sqlite-db.ts");
const { handleCommerceApi } = await import("../worker/commerce-api.ts");
const { buildInterpretationMessages } = await import("../worker/deepseek.ts");

const reading = { title: "Reading", conclusion: "One plain sentence.", keyPoints: ["P1", "P2", "P3"], summary: "Summary text.", teaser: "More later.", sections: [1, 2, 3, 4, 5, 6].map((n) => ({ title: `S${n}`, text: `Body ${n}.` })), followUps: ["F1", "F2", "F3"] };
const prompts = [];
const realFetch = globalThis.fetch;
globalThis.fetch = async (url, init) => {
  if (String(url).startsWith("https://api.deepseek.com")) { prompts.push(JSON.parse(init.body).messages[0].content); return new Response(JSON.stringify({ choices: [{ message: { content: JSON.stringify(reading) } }] }), { status: 200 }); }
  return realFetch(url, init);
};
const chart = {
  calendar: { lunar: "一九九四年七月十二", naYin: "涧下水", solar: "1994-08-18 15:00:00" },
  pillars: ["甲戌", "壬申", "丙子", "丙申"],
  board: { kind: "pillars", label: "Four Pillars complete board", cells: [{ id: "pillar-0", title: "Year pillar", items: [{ label: "Ten God", value: "偏印" }] }] },
  sections: [{ id: "ten-gods", title: "Ten-God relationships", lead: "Local", items: [{ label: "Year pillar", value: "偏印" }] }],
  sourceFacts: ["Calculated solar/lunar conversion"],
  inputSummary: { focus: "", place: "Global", version: 1 },
};
function freshEnv() {
  const db = openDatabase(":memory:");
  for (const file of readdirSync(new URL("../migrations/", import.meta.url)).filter((name) => name.endsWith(".sql")).sort()) db.raw.exec(readFileSync(new URL(`../migrations/${file}`, import.meta.url), "utf8"));
  return { DB: db, SESSION_SECRET: "test-session-signing-key-that-is-long-enough", DEEPSEEK_API_KEY: "test-key" };
}
const preview = (env, device, body) => handleCommerceApi(new Request("https://xuannova.test/api/readings/preview", { method: "POST", headers: { origin: "https://xuannova.test", "content-type": "application/json", cookie: `xn_device=${device}` }, body: JSON.stringify(body) }), env);

test("the instructions follow the chosen style", () => {
  const base = { tool: "bazi", locale: "zh-Hans", question: "整体运势", chart };
  const plain = buildInterpretationMessages({ ...base, style: "plain" }, "structured")[0].content;
  const expert = buildInterpretationMessages({ ...base, style: "expert" }, "structured")[0].content;
  const none = buildInterpretationMessages(base, "structured")[0].content;
  assert.match(plain, /READING STYLE: EVERYDAY/); assert.doesNotMatch(plain, /READING STYLE: EXPERT/);
  assert.match(expert, /READING STYLE: EXPERT/); assert.doesNotMatch(expert, /READING STYLE: EVERYDAY/);
  assert.doesNotMatch(none, /READING STYLE/);
  // The style also applies to follow-up conversations and to each half of a deep reading.
  assert.match(buildInterpretationMessages({ ...base, style: "plain" }, "conversation")[0].content, /READING STYLE: EVERYDAY/);
  assert.match(buildInterpretationMessages({ ...base, tool: "detail", style: "plain" }, "structured", undefined, "first")[0].content, /READING STYLE: EVERYDAY/);
});

test("a reading requested from the page carries its style to the AI; unknown values are ignored", async () => {
  const env = freshEnv();
  prompts.length = 0;
  assert.equal((await preview(env, "device-style-000000000001", { tool: "bazi", locale: "zh-Hans", question: "整体运势", chart, style: "plain" })).status, 200);
  assert.match(prompts.at(-1), /READING STYLE: EVERYDAY/);
  assert.equal((await preview(env, "device-style-000000000002", { tool: "bazi", locale: "zh-Hans", question: "整体运势", chart, style: "expert" })).status, 200);
  assert.match(prompts.at(-1), /READING STYLE: EXPERT/);
  assert.equal((await preview(env, "device-style-000000000003", { tool: "bazi", locale: "zh-Hans", question: "整体运势", chart, style: "<script>" })).status, 200);
  assert.doesNotMatch(prompts.at(-1), /READING STYLE/);
});

test("the plain-language example is in the reader's own language and script", () => {
  const prompt = (locale) => buildInterpretationMessages({ tool: "bazi", locale, question: "q", chart, style: "plain" }, "structured")[0].content;
  assert.match(prompt("en"), /Seven Killings \(pressure, challenge\)/);
  assert.match(prompt("zh-Hans"), /七杀（压力、挑战）/);
  assert.match(prompt("zh-Hant"), /七殺（壓力、挑戰）/);
  assert.match(prompt("ko"), /칠살 \(압박·도전\)/);
  assert.match(prompt("vi"), /Thất sát \(áp lực, thử thách\)/);
  assert.match(prompt("th"), /แรงกดดัน ความท้าทาย/);
  for (const locale of ["en", "ko", "vi", "th"]) assert.doesNotMatch(prompt(locale).split("READING STYLE")[1].split("Return valid JSON")[0], /[\u4e00-\u9fff]/, `${locale} style rule has no Chinese characters`);
});
