import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";

const api = await import("../worker/commerce-api.ts");

const env = {
  ADMIN_EMAIL: "owner@example.com",
  SESSION_SECRET: "test-session-signing-key-that-is-long-enough",
};

test("uses a PBKDF2 work factor supported by the deployed Workers runtime", () => {
  assert.ok(api.passwordIterations <= 100_000);
  assert.ok(api.passwordIterations >= 100_000);
});

function memberDatabase(initialCredits = 100) {
  const today = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Shanghai", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
  const member = { id: "member-1", email: "member@example.com", credits: initialCredits, daily_credits: 0, daily_credit_date: today };
  const ledger = [];
  return {
    member,
    ledger,
    async batch(statements) {
      return Promise.all(statements.map((statement) => statement.run()));
    },
    prepare(query) {
      // Daily-bonus device claims (one account per device per day).
      const claims = (this.__claims ??= new Map());
      let bindings = [];
      const statement = {
        bind(...values) { bindings = values; return statement; },
        async first() { if (query.startsWith("SELECT member_id FROM daily_bonus_claims")) return { member_id: claims.get(`${bindings[0]}|${bindings[1]}`) ?? null };
          if (query.startsWith("SELECT id, email, wallet_address, credits")) return { ...member };
          return null;
        },
        async all() { return { results: [] }; },
        async run() {
          if (query.startsWith("INSERT OR IGNORE INTO daily_bonus_claims")) { const key = `${bindings[0]}|${bindings[1]}`; if (!claims.has(key)) claims.set(key, bindings[2]); return { meta: { changes: 1 } }; }
          if (query.startsWith("UPDATE members SET daily_credits = MIN")) {
            const target = typeof members !== "undefined" ? members.find((item) => item.id === bindings[5]) : typeof member !== "undefined" && member.id === bindings[5] ? member : null;
            if (!target || target.daily_credit_date === bindings[2]) return { meta: { changes: 0 } };
            target.daily_credits = Math.min((target.daily_credits ?? 0) + bindings[0], bindings[1]);
            target.daily_credit_date = bindings[2];
            return { meta: { changes: 1 } };
          }
          if (query.startsWith("UPDATE members SET daily_credits = 5")) {
            if (member.daily_credit_date === bindings[0]) return { meta: { changes: 0 } };
            member.daily_credits = 5;
            member.daily_credit_date = bindings[0];
            return { meta: { changes: 1 } };
          }
          if (query.startsWith("UPDATE members SET daily_credits = daily_credits - MIN")) {
            const [cost] = bindings;
            if (member.credits + member.daily_credits < cost) return { meta: { changes: 0 } };
            const fromDaily = Math.min(member.daily_credits, cost);
            member.daily_credits -= fromDaily;
            member.credits -= cost - fromDaily;
            return { meta: { changes: 1 } };
          }
          if (query.startsWith("INSERT INTO credit_ledger")) {
            ledger.push({ id: bindings[0], member_id: bindings[1], delta: bindings[2], reason: bindings[3], created_at: bindings[4], balance_after: member.credits + member.daily_credits });
            return { meta: { changes: 1 } };
          }
          return { meta: { changes: 1 } };
        },
      };
      return statement;
    },
  };
}

function interpretationBody() {
  return {
    tool: "bazi",
    locale: "en",
    question: "How can I approach a career transition?",
    mode: "structured",
    chart: {
      calendar: { lunar: "Sample lunar date", naYin: "Sample NaYin" },
      pillars: ["甲子", "乙丑", "丙寅", "丁卯"],
      board: { kind: "pillars", label: "Four pillars", cells: [{ id: "year", title: "Year", items: [{ label: "Stem", value: "甲" }] }] },
      sections: [{ id: "orientation", title: "Orientation", lead: "A study layer", items: [{ label: "Element", value: "Wood" }] }],
      sourceFacts: ["Local cultural-study chart"],
      inputSummary: { focus: "Career", place: "Singapore", version: 1 },
    },
  };
}

test("keeps member account data private without a signed session", async () => {
  const response = await api.handleCommerceApi(
    new Request("https://preview.example/api/member/me"),
    env,
  );

  assert.equal(response?.status, 401);
  assert.deepEqual(await response?.json(), { error: "Authentication required" });
});

test("allows every configured administrator to start an owner session", async () => {
  const administrators = ["first-owner@example.com", "second-owner@example.com"];

  for (const email of administrators) {
    const response = await api.handleCommerceApi(
      new Request("https://preview.example/api/auth/admin/login", {
        method: "POST",
        headers: { origin: "https://preview.example", "content-type": "application/json" },
        body: JSON.stringify({ email, password: "shared-admin-password" }),
      }),
      {
        ...env,
        ADMIN_EMAILS: administrators.join(","),
        ADMIN_PASSWORD: "shared-admin-password",
      },
    );

    assert.equal(response?.status, 200);
    assert.equal((await response?.json()).administrator.email, email);
    assert.match(response?.headers.get("set-cookie") ?? "", /xuanyuan_session=/);
  }
});

test("registers a member with a six-character password and returns a signed session", async () => {
  const database = {
    prepare(query) {
      // Daily-bonus device claims (one account per device per day).
      const claims = (this.__claims ??= new Map());
      const statement = {
        bind() { return statement; },
        async first() { if (query.startsWith("SELECT member_id FROM daily_bonus_claims")) return { member_id: claims.get(`${bindings[0]}|${bindings[1]}`) ?? null }; return query.startsWith("SELECT id FROM members") ? null : null; },
        async run() {
          if (query.startsWith("INSERT OR IGNORE INTO daily_bonus_claims")) { const key = `${bindings[0]}|${bindings[1]}`; if (!claims.has(key)) claims.set(key, bindings[2]); return { meta: { changes: 1 } }; }
          if (query.startsWith("UPDATE members SET daily_credits = MIN")) {
            const target = typeof members !== "undefined" ? members.find((item) => item.id === bindings[5]) : typeof member !== "undefined" && member.id === bindings[5] ? member : null;
            if (!target || target.daily_credit_date === bindings[2]) return { meta: { changes: 0 } };
            target.daily_credits = Math.min((target.daily_credits ?? 0) + bindings[0], bindings[1]);
            target.daily_credit_date = bindings[2];
            return { meta: { changes: 1 } };
          } return { meta: { changes: 1 } }; },
      };
      return statement;
    },
  };
  const response = await api.handleCommerceApi(
    new Request("https://preview.example/api/auth/register", {
      method: "POST",
      headers: { origin: "https://preview.example", "content-type": "application/json" },
      body: JSON.stringify({ email: "six@example.com", password: "sixsix" }),
    }),
    { ...env, DB: database },
  );

  assert.equal(response?.status, 201);
  assert.match(response?.headers.get("set-cookie") ?? "", /xuanyuan_session=/);
  const payload = await response?.json();
  assert.equal(payload.member.email, "six@example.com");
  assert.equal(payload.member.balance, 0);
  assert.equal(typeof payload.member.id, "string");
  assert.match(payload.member.inviteCode, /^XU[A-Z0-9]{8}$/);
});

function invitationDatabase() {
  const members = [
    { id: "inviter-1", email: "inviter@example.com", credits: 19, invite_code: "XUINVITE88" },
  ];
  const ledger = [];
  return {
    members,
    ledger,
    prepare(query) {
      // Daily-bonus device claims (one account per device per day).
      const claims = (this.__claims ??= new Map());
      let bindings = [];
      const statement = {
        bind(...values) { bindings = values; return statement; },
        async first() { if (query.startsWith("SELECT member_id FROM daily_bonus_claims")) return { member_id: claims.get(`${bindings[0]}|${bindings[1]}`) ?? null };
          if (query.startsWith("SELECT id FROM members WHERE email")) {
            return members.find((member) => member.email === bindings[0]) ?? null;
          }
          if (query.includes("WHERE invite_code = ?")) {
            return members.find((member) => member.invite_code === bindings[0]) ?? null;
          }
          if (query.startsWith("SELECT id, email, wallet_address, credits")) {
            return members.find((member) => member.id === bindings[0]) ?? null;
          }
          return null;
        },
        async all() { return { results: [] }; },
        async run() {
          if (query.startsWith("INSERT OR IGNORE INTO daily_bonus_claims")) { const key = `${bindings[0]}|${bindings[1]}`; if (!claims.has(key)) claims.set(key, bindings[2]); return { meta: { changes: 1 } }; }
          if (query.startsWith("UPDATE members SET daily_credits = MIN")) {
            const target = typeof members !== "undefined" ? members.find((item) => item.id === bindings[5]) : typeof member !== "undefined" && member.id === bindings[5] ? member : null;
            if (!target || target.daily_credit_date === bindings[2]) return { meta: { changes: 0 } };
            target.daily_credits = Math.min((target.daily_credits ?? 0) + bindings[0], bindings[1]);
            target.daily_credit_date = bindings[2];
            return { meta: { changes: 1 } };
          }
          if (query.startsWith("INSERT INTO members")) {
            members.push({
              id: bindings[0],
              email: bindings[1],
              wallet_address: bindings[2],
              credits: bindings[4],
              invite_code: bindings[5],
              invited_by_member_id: bindings[6],
            });
          }
          if (query.startsWith("UPDATE members SET credits = credits +")) {
            const member = members.find((item) => item.id === bindings[2]);
            if (member) member.credits += bindings[0];
          }
          if (query.startsWith("INSERT INTO credit_ledger")) ledger.push({ query, bindings });
          return { meta: { changes: 1 } };
        },
      };
      return statement;
    },
  };
}

test("records a valid invitation at registration without issuing purchase rewards early", async () => {
  const database = invitationDatabase();
  const response = await api.handleCommerceApi(
    new Request("https://preview.example/api/auth/register", {
      method: "POST",
      headers: { origin: "https://preview.example", "content-type": "application/json" },
      body: JSON.stringify({
        email: "new-member@example.com",
        password: "sixsix",
        inviteCode: "xuinvite88",
      }),
    }),
    { ...env, DB: database },
  );

  assert.equal(response?.status, 201);
  const payload = await response?.json();
  assert.equal(payload.member.balance, 5, "only the first daily bonus; no invitation reward before a purchase");
  assert.match(payload.member.inviteCode, /^XU[A-Z0-9]{8}$/);
  assert.equal(database.members.find((member) => member.id === "inviter-1")?.credits, 19);
  assert.equal(database.members.find((member) => member.email === "new-member@example.com")?.invited_by_member_id, "inviter-1");
  assert.equal(database.ledger.length, 1);
  assert.match(database.ledger[0].bindings[4], /^daily_login_bonus:/);
});

test("rejects a checkout package that is not in the owner-defined policy", async () => {
  const token = await api.createSessionToken(
    { sub: "member-1", email: "member@example.com", role: "member" },
    env.SESSION_SECRET,
  );
  const response = await api.handleCommerceApi(
    new Request("https://preview.example/api/orders", {
      method: "POST",
      headers: {
        origin: "https://preview.example",
        cookie: `xuanyuan_session=${token}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        packageId: "not-a-package",
        transactionHash: `0x${"ab".repeat(32)}`,
      }),
    }),
    env,
  );

  assert.equal(response?.status, 400);
  assert.deepEqual(await response?.json(), { error: "Choose a valid credit package" });
});

test("accepts a manual transfer hash for administrator review on the original route", async () => {
  const orders = [];
  const database = {
    prepare(query) {
      // Daily-bonus device claims (one account per device per day).
      const claims = (this.__claims ??= new Map());
      let bindings = [];
      const statement = {
        bind(...values) { bindings = values; return statement; },
        async first() { if (query.startsWith("SELECT member_id FROM daily_bonus_claims")) return { member_id: claims.get(`${bindings[0]}|${bindings[1]}`) ?? null };
          if (query.startsWith("SELECT id, email, wallet_address, credits")) return { id: "member-1", email: "member@example.com", wallet_address: null, credits: 0 };
          return null;
        },
        async run() {
          if (query.startsWith("INSERT OR IGNORE INTO daily_bonus_claims")) { const key = `${bindings[0]}|${bindings[1]}`; if (!claims.has(key)) claims.set(key, bindings[2]); return { meta: { changes: 1 } }; }
          if (query.startsWith("UPDATE members SET daily_credits = MIN")) {
            const target = typeof members !== "undefined" ? members.find((item) => item.id === bindings[5]) : typeof member !== "undefined" && member.id === bindings[5] ? member : null;
            if (!target || target.daily_credit_date === bindings[2]) return { meta: { changes: 0 } };
            target.daily_credits = Math.min((target.daily_credits ?? 0) + bindings[0], bindings[1]);
            target.daily_credit_date = bindings[2];
            return { meta: { changes: 1 } };
          } if (query.startsWith("INSERT INTO payment_orders")) orders.push(bindings); return { meta: { changes: 1 } }; },
      };
      return statement;
    },
  };
  const token = await api.createSessionToken({ sub: "member-1", email: "member@example.com", role: "member" }, env.SESSION_SECRET);
  const response = await api.handleCommerceApi(
    new Request("https://preview.example/api/orders/manual", {
      method: "POST",
      headers: { origin: "https://preview.example", cookie: `xuanyuan_session=${token}`, "content-type": "application/json" },
      body: JSON.stringify({ packageId: "seed", network: "trc20", transactionHash: "a".repeat(64) }),
    }),
    { ...env, DB: database },
  );
  assert.equal(response?.status, 201);
  const payload = await response?.json();
  assert.equal(payload.order.status, "pending");
  assert.equal(payload.order.network, "trc20");
  assert.equal(orders.length, 1);
});

test("does not let a member session open the order-review console", async () => {
  const token = await api.createSessionToken(
    { sub: "member-1", email: "member@example.com", role: "member" },
    env.SESSION_SECRET,
  );
  const response = await api.handleCommerceApi(
    new Request("https://preview.example/api/admin/orders", {
      headers: { cookie: `xuanyuan_session=${token}` },
    }),
    env,
  );

  assert.equal(response?.status, 403);
  assert.deepEqual(await response?.json(), { error: "Administrator access required" });
});

function adminOperationsDatabase() {
  const members = [
    { id: "inviter-1", email: "inviter@example.com", credits: 27, daily_credits: 0, invite_code: "XUINVITE88", invited_by_member_id: null, created_at: "2026-08-17T00:00:00.000Z", updated_at: "2026-08-17T00:00:00.000Z" },
    { id: "invitee-1", email: "invitee@example.com", credits: 15, daily_credits: 0, invite_code: "XUJOINER88", invited_by_member_id: "inviter-1", created_at: "2026-08-17T01:00:00.000Z", updated_at: "2026-08-17T01:00:00.000Z" },
  ];
  const ledger = [
    { id: "ledger-join", member_id: "invitee-1", order_id: null, delta: 5, balance_after: 15, reason: "invitation_purchase", created_at: "2026-08-17T01:00:00.000Z" },
    { id: "ledger-share", member_id: "inviter-1", order_id: null, delta: 5, balance_after: 27, reason: "invitation_purchase", created_at: "2026-08-17T01:00:00.000Z" },
  ];
  const audit = [];
  return {
    members,
    ledger,
    audit,
    prepare(query) {
      // Daily-bonus device claims (one account per device per day).
      const claims = (this.__claims ??= new Map());
      let bindings = [];
      const statement = {
        bind(...values) { bindings = values; return statement; },
        async first() { if (query.startsWith("SELECT member_id FROM daily_bonus_claims")) return { member_id: claims.get(`${bindings[0]}|${bindings[1]}`) ?? null };
          if (query.startsWith("SELECT id, email, wallet_address, credits") && query.includes("WHERE id = ?")) {
            return members.find((member) => member.id === bindings[0]) ?? null;
          }
          return null;
        },
        async all() {
          if (query.startsWith("SELECT COUNT(*) AS member_count")) {
            return { results: [{ member_count: members.length, outstanding_credits: members.reduce((sum, member) => sum + member.credits, 0) }] };
          }
          if (query.startsWith("SELECT COUNT(*) AS pending_order_count")) return { results: [{ pending_order_count: 0 }] };
          if (query.startsWith("SELECT COUNT(*) AS invitation_count")) return { results: [{ invitation_count: 1 }] };
          if (query.startsWith("SELECT COALESCE(SUM(delta), 0) AS invitation_credits")) return { results: [{ invitation_credits: 10 }] };
          if (query.includes("FROM invitation_purchase_rewards AS rewards")) {
            return { results: [{ inviter_id: "inviter-1", inviter_email: "inviter@example.com", invite_code: "XUINVITE88", invitee_id: "invitee-1", invitee_email: "invitee@example.com", joined_at: "2026-08-17T01:00:00.000Z", inviter_reward: 5, invitee_reward: 5 }] };
          }
          if (query.startsWith("SELECT id, email, wallet_address, credits, invite_code")) return { results: members.map((member) => ({ ...member })) };
          if (query.includes("FROM credit_ledger JOIN members")) {
            return { results: ledger.map((entry) => ({ ...entry, member_email: members.find((member) => member.id === entry.member_id)?.email ?? "" })) };
          }
          return { results: [] };
        },
        async run() {
          if (query.startsWith("INSERT OR IGNORE INTO daily_bonus_claims")) { const key = `${bindings[0]}|${bindings[1]}`; if (!claims.has(key)) claims.set(key, bindings[2]); return { meta: { changes: 1 } }; }
          if (query.startsWith("UPDATE members SET daily_credits = MIN")) {
            const target = typeof members !== "undefined" ? members.find((item) => item.id === bindings[5]) : typeof member !== "undefined" && member.id === bindings[5] ? member : null;
            if (!target || target.daily_credit_date === bindings[2]) return { meta: { changes: 0 } };
            target.daily_credits = Math.min((target.daily_credits ?? 0) + bindings[0], bindings[1]);
            target.daily_credit_date = bindings[2];
            return { meta: { changes: 1 } };
          }
          if (query.startsWith("UPDATE members SET credits = credits + ?")) {
            const [delta, , id] = bindings;
            const member = members.find((item) => item.id === id);
            if (!member || member.credits + delta < 0) return { meta: { changes: 0 } };
            member.credits += delta;
            return { meta: { changes: 1 } };
          }
          if (query.startsWith("INSERT INTO credit_ledger")) {
            ledger.unshift({ id: bindings[0], member_id: bindings[1], order_id: null, delta: bindings[2], balance_after: bindings[3], reason: "admin_adjustment", created_at: bindings[4] });
            return { meta: { changes: 1 } };
          }
          if (query.startsWith("INSERT INTO admin_audit")) {
            audit.push(bindings);
            return { meta: { changes: 1 } };
          }
          return { meta: { changes: 1 } };
        },
      };
      return statement;
    },
  };
}

test("gives an administrator a traceable invitation overview", async () => {
  const database = adminOperationsDatabase();
  const token = await api.createSessionToken(
    { sub: "owner@example.com", email: "owner@example.com", role: "admin" },
    env.SESSION_SECRET,
  );

  const [overviewResponse, invitationResponse, memberResponse, ledgerResponse] = await Promise.all([
    api.handleCommerceApi(new Request("https://preview.example/api/admin/overview", { headers: { cookie: `xuanyuan_session=${token}` } }), { ...env, DB: database }),
    api.handleCommerceApi(new Request("https://preview.example/api/admin/invitations", { headers: { cookie: `xuanyuan_session=${token}` } }), { ...env, DB: database }),
    api.handleCommerceApi(new Request("https://preview.example/api/admin/members?search=invite", { headers: { cookie: `xuanyuan_session=${token}` } }), { ...env, DB: database }),
    api.handleCommerceApi(new Request("https://preview.example/api/admin/ledger", { headers: { cookie: `xuanyuan_session=${token}` } }), { ...env, DB: database }),
  ]);

  assert.equal(overviewResponse?.status, 200);
  assert.deepEqual(await overviewResponse?.json(), { overview: { memberCount: 2, outstandingCredits: 42, pendingOrderCount: 0, invitationCount: 1, invitationCredits: 10 } });
  assert.equal(invitationResponse?.status, 200);
  assert.deepEqual((await invitationResponse?.json()).invitations[0], { inviterId: "inviter-1", inviterEmail: "inviter@example.com", inviteCode: "XUINVITE88", inviteeId: "invitee-1", inviteeEmail: "invitee@example.com", joinedAt: "2026-08-17T01:00:00.000Z", inviterReward: 5, inviteeReward: 5 });
  assert.equal(memberResponse?.status, 200);
  assert.equal((await memberResponse?.json()).members.length, 2);
  assert.equal(ledgerResponse?.status, 200);
  assert.equal((await ledgerResponse?.json()).entries.length, 2);
});

test("records an administrator credit correction without permitting a negative balance", async () => {
  const database = adminOperationsDatabase();
  const token = await api.createSessionToken(
    { sub: "owner@example.com", email: "owner@example.com", role: "admin" },
    env.SESSION_SECRET,
  );
  const headers = { origin: "https://preview.example", cookie: `xuanyuan_session=${token}`, "content-type": "application/json" };

  const adjusted = await api.handleCommerceApi(
    new Request("https://preview.example/api/admin/members/inviter-1/credits", { method: "POST", headers, body: JSON.stringify({ delta: -12, reason: "Corrected duplicate manual grant" }) }),
    { ...env, DB: database },
  );

  assert.equal(adjusted?.status, 200);
  assert.deepEqual((await adjusted?.json()).member, { id: "inviter-1", email: "inviter@example.com", walletAddress: null, balance: 15, dailyCredits: 0, inviteCode: "XUINVITE88" });
  assert.equal(database.ledger[0].reason, "admin_adjustment");
  assert.equal(database.ledger[0].delta, -12);
  assert.equal(database.audit.length, 1);

  const refused = await api.handleCommerceApi(
    new Request("https://preview.example/api/admin/members/inviter-1/credits", { method: "POST", headers, body: JSON.stringify({ delta: -21, reason: "Invalid debit" }) }),
    { ...env, DB: database },
  );
  assert.equal(refused?.status, 409);
  assert.deepEqual(await refused?.json(), { error: "Credit adjustment cannot reduce balance below zero" });
});

test("routes same-origin API calls through the commerce handler before the app renderer", async () => {
  const workerEntry = await readFile(new URL("../worker/index.ts", import.meta.url), "utf8");
  assert.match(workerEntry, /handleCommerceApi/);
  assert.match(workerEntry, /const commerceResponse = await handleCommerceApi\(request, commerceEnvironment\(env\)\)/);
  assert.match(workerEntry, /if \(commerceResponse\) return commerceResponse/);
});

test("protects the live interpretation endpoint with a signed member session", async () => {
  const response = await api.handleCommerceApi(
    new Request("https://preview.example/api/interpretations", { method: "POST" }),
    env,
  );

  assert.equal(response?.status, 401);
  assert.deepEqual(await response?.json(), { error: "Authentication required" });
});

test("returns a specific validation code before invoking AI for an empty interpretation question", async () => {
  const database = memberDatabase();
  const token = await api.createSessionToken({ sub: "member-1", email: "member@example.com", role: "member" }, env.SESSION_SECRET);
  const body = interpretationBody();
  body.question = " ";

  const response = await api.handleCommerceApi(new Request("https://preview.example/api/interpretations", {
    method: "POST",
    headers: { origin: "https://preview.example", cookie: `xuanyuan_session=${token}`, "content-type": "application/json" },
    body: JSON.stringify(body),
  }), { ...env, DB: database, DEEPSEEK_API_KEY: "test-key" });

  assert.equal(response?.status, 400);
  assert.deepEqual(await response?.json(), { error: "Enter a question before requesting an interpretation", code: "QUESTION_REQUIRED" });
  assert.equal(database.member.credits, 100);
  assert.equal(database.ledger.length, 0);
});

test("accepts a one-character interpretation question when the chart focus was left blank", async () => {
  const database = memberDatabase();
  const token = await api.createSessionToken({ sub: "member-1", email: "member@example.com", role: "member" }, env.SESSION_SECRET);
  const body = interpretationBody();
  body.question = "?";
  body.chart.inputSummary.focus = "";
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response(JSON.stringify({
    choices: [{ message: { content: JSON.stringify({ title: "Reflection", summary: "Use the chart as a reference.", sections: [{ title: "Orientation", text: "Observe before deciding." }], followUps: [] }) } }],
  }), { status: 200, headers: { "content-type": "application/json" } });
  try {
    const response = await api.handleCommerceApi(new Request("https://preview.example/api/interpretations", {
      method: "POST",
      headers: { origin: "https://preview.example", cookie: `xuanyuan_session=${token}`, "content-type": "application/json" },
      body: JSON.stringify(body),
    }), { ...env, DB: database, DEEPSEEK_API_KEY: "test-key" });

    assert.equal(response?.status, 200);
    assert.equal((await response?.json()).response.summary, "Use the chart as a reference.");
    assert.equal(database.member.credits, 80);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("charges credits only after DeepSeek returns a valid interpretation", async () => {
  const database = memberDatabase();
  const token = await api.createSessionToken({ sub: "member-1", email: "member@example.com", role: "member" }, env.SESSION_SECRET);
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response(JSON.stringify({
    choices: [{ message: { content: JSON.stringify({ title: "Reflection", summary: "Use the chart as a reference.", sections: [{ title: "Orientation", text: "Observe before deciding." }], followUps: ["What is within your control?"] }) } }],
  }), { status: 200, headers: { "content-type": "application/json" } });
  try {
    const response = await api.handleCommerceApi(new Request("https://preview.example/api/interpretations", {
      method: "POST",
      headers: { origin: "https://preview.example", cookie: `xuanyuan_session=${token}`, "content-type": "application/json" },
      body: JSON.stringify(interpretationBody()),
    }), { ...env, DB: database, DEEPSEEK_API_KEY: "test-key" });

    assert.equal(response?.status, 200);
    assert.equal((await response?.json()).member.balance, 80);
    assert.equal(database.member.credits, 80);
    assert.equal(database.ledger.length, 1);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("does not charge a member when DeepSeek is unavailable", async () => {
  const database = memberDatabase();
  const token = await api.createSessionToken({ sub: "member-1", email: "member@example.com", role: "member" }, env.SESSION_SECRET);
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response("Unavailable", { status: 503 });
  try {
    const response = await api.handleCommerceApi(new Request("https://preview.example/api/interpretations", {
      method: "POST",
      headers: { origin: "https://preview.example", cookie: `xuanyuan_session=${token}`, "content-type": "application/json" },
      body: JSON.stringify(interpretationBody()),
    }), { ...env, DB: database, DEEPSEEK_API_KEY: "test-key" });

    assert.equal(response?.status, 502);
    assert.deepEqual(await response?.json(), { error: "Interpretation service is unavailable", code: "AI_UNAVAILABLE" });
    assert.equal(database.member.credits, 100);
    assert.equal(database.ledger.length, 0);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("manual transfers reject a hash whose format cannot belong to the chosen network", async () => {
  const token = await api.createSessionToken({ sub: "member-1", email: "member@example.com", role: "member" }, env.SESSION_SECRET);
  for (const [network, hash] of [["trc20", `0x${"a".repeat(64)}`], ["bsc", "a".repeat(64)], ["trc20", "deadbeef"]]) {
    const response = await api.handleCommerceApi(
      new Request("https://preview.example/api/orders/manual", { method: "POST", headers: { origin: "https://preview.example", cookie: `xuanyuan_session=${token}`, "content-type": "application/json" }, body: JSON.stringify({ packageId: "seed", network, transactionHash: hash }) }),
      env,
    );
    assert.equal(response?.status, 400, `${network} ${hash}`);
  }
});
