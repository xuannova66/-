import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { isAddress, parseUnits, formatUnits } from "viem";

const draft = JSON.parse(readFileSync(new URL("../config/multichain-assets.draft.json", import.meta.url), "utf8"));

test("draft is disabled and identifies native coins separately from wrapped assets", () => {
  assert.equal(draft.status, "draft-not-enabled");
  for (const chain of Object.values(draft.chains)) {
    assert.equal(new Set(chain.assets.map((asset) => asset.symbol)).size, chain.assets.length);
    for (const asset of chain.assets.filter((item) => item.native)) assert.equal(asset.address, undefined);
  }
  assert.equal(draft.chains.solana.assets.find((item) => item.symbol === "JLP").mint, "27G8MtK7VtTcCHkpASjSDdkWWYfoqT6ggEuKidVJidD4");
  assert.equal(draft.chains.solana.assets.find((item) => item.symbol === "PUMP").status, "requires-token-2022-review");
  assert.equal(draft.chains.tron.settlement, "USDT");
  assert.equal(draft.chains.ethereum.assets.find((item) => item.symbol === "WETH").address, "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2");
});

test("EVM addresses have valid form and non-18-decimal amounts use token precision", () => {
  for (const chain of [draft.chains.bsc, draft.chains.ethereum]) {
    assert.ok(isAddress(chain.recipient));
    for (const asset of chain.assets) if (asset.address) assert.ok(isAddress(asset.address, { strict: false }), asset.symbol);
  }
  for (const [symbol, decimals] of [["XAUt", 6], ["DOGE", 8]]) {
    const asset = draft.chains.bsc.assets.find((item) => item.symbol === symbol);
    assert.equal(asset.decimals, decimals);
    assert.equal(formatUnits(parseUnits("1.25", asset.decimals), asset.decimals), "1.25");
  }
  assert.equal(draft.chains.bsc.assets.some((item) => item.symbol === "WLFI"), false, "WLFI was dropped by the project owner (2026-11-06)");
});
