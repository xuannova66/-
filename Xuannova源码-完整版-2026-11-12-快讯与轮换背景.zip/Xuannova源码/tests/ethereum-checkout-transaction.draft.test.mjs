import test from "node:test";
import assert from "node:assert/strict";
import {decodeFunctionData} from "viem";
import {submitEthereumDraftCheckout} from "../app/ethereum-checkout-transaction.draft.ts";
const buyer="0x1111111111111111111111111111111111111111",stable="0x2222222222222222222222222222222222222222",checkout="0x3333333333333333333333333333333333333333",wrapped="0x4444444444444444444444444444444444444444",hash=`0x${"ab".repeat(32)}`;
const session={network:"ethereum",chainId:"0x1",address:buyer},order={id:"order-1",packageId:"seed",buyer,reference:`0x${"aa".repeat(32)}`},config={checkout,settlement:stable,wrappedNative:wrapped,allowedAssets:[],intermediates:[]};
const quote={asset:stable,inputUnits:4990000n,maxInputUnits:4990000n,outputUnits:4990000n,path:[],expiresAt:1100};
function wallet({chain="0x1",allowance=4990000n,failSend=false}={}) {const calls=[];return {calls,request:async x=>{calls.push(x);if(x.method==="eth_chainId")return chain;if(x.method==="eth_accounts")return [buyer];if(x.method==="eth_call")return `0x${allowance.toString(16).padStart(64,"0")}`;if(x.method==="eth_estimateGas")return "0x186a0";if(x.method==="eth_sendTransaction"){if(failSend)throw Error("rpc timeout");return hash;}throw Error("unexpected");}};}
test("prepares a direct settlement transaction only after session, terms and allowance checks",async()=>{
 const provider=wallet(),recorded=[];
 const result=await submitEthereumDraftCheckout({provider,session,order,config,quote,clock:()=>1000,onHash:async h=>recorded.push(h)});
 assert.deepEqual(result,{hash,recoveryRecorded:true});assert.deepEqual(recorded,[hash]);
 const send=provider.calls.find(x=>x.method==="eth_sendTransaction").params[0];assert.equal(send.value,"0x0");assert.equal(send.to,checkout);
 const decoded=decodeFunctionData({abi:[{type:"function",name:"buy",stateMutability:"payable",inputs:[{type:"bytes32"},{type:"address"},{type:"uint256"},{type:"address[]"},{type:"uint256"},{type:"bytes32"}],outputs:[]}],data:send.data});assert.equal(decoded.args[5],order.reference);
});
test("refuses wrong chain, insufficient allowance, stale quote and never retries ambiguous send",async()=>{
 const base={session,order,config,quote,clock:()=>1000,onHash:async()=>{}};
 await assert.rejects(submitEthereumDraftCheckout({...base,provider:wallet({chain:"0x38"})}),/WALLET_NETWORK_CHANGED/);
 const notApproved=wallet({allowance:0n});await assert.rejects(submitEthereumDraftCheckout({...base,provider:notApproved}),/ALLOWANCE_REQUIRED/);assert.ok(!notApproved.calls.some(x=>x.method==="eth_sendTransaction"));
 await assert.rejects(submitEthereumDraftCheckout({...base,provider:wallet(),clock:()=>1100}),/INVALID_QUOTE/);
 let clockCalls=0;await assert.rejects(submitEthereumDraftCheckout({...base,provider:wallet(),clock:()=>clockCalls++?1100:1000}),/INVALID_QUOTE/);
 const failed=wallet({failSend:true});await assert.rejects(submitEthereumDraftCheckout({...base,provider:failed}),/SUBMISSION_OUTCOME_UNKNOWN/);assert.equal(failed.calls.filter(x=>x.method==="eth_sendTransaction").length,1);
 const result=await submitEthereumDraftCheckout({...base,provider:wallet(),onHash:async()=>{throw Error("offline");}});assert.deepEqual(result,{hash,recoveryRecorded:false});
});
test("never sends if the user changes network or account during gas estimation",async()=>{
 const base={session,order,config,quote,clock:()=>1000,onHash:async()=>{}};
 for(const changed of ["chain","account"]){
  const calls=[];let afterEstimate=false;
  const provider={request:async x=>{
   calls.push(x.method);
   if(x.method==="eth_chainId")return afterEstimate&&changed==="chain"?"0x38":"0x1";
   if(x.method==="eth_accounts")return afterEstimate&&changed==="account"?[checkout]:[buyer];
   if(x.method==="eth_call")return `0x${(4990000n).toString(16).padStart(64,"0")}`;
   if(x.method==="eth_estimateGas"){afterEstimate=true;return "0x186a0";}
   throw Error("must not send");
  }};
  await assert.rejects(submitEthereumDraftCheckout({...base,provider}),/WALLET_(NETWORK|ACCOUNT)_CHANGED/);
  assert.ok(!calls.includes("eth_sendTransaction"));
 }
});
test("never sends when quote expires during estimation or gas estimation fails",async()=>{
 const base={session,order,config,quote,clock:()=>1000,onHash:async()=>{}};
 let clockCalls=0;const expired=wallet();
 await assert.rejects(submitEthereumDraftCheckout({...base,provider:expired,clock:()=>clockCalls++?1100:1000}),/INVALID_QUOTE/);
 assert.ok(!expired.calls.some(x=>x.method==="eth_sendTransaction"));
 const original=wallet(),calls=original.calls;
 const provider={request:async x=>x.method==="eth_estimateGas"?(calls.push(x),"0x0"):original.request(x)};
 await assert.rejects(submitEthereumDraftCheckout({...base,provider}),/GAS_ESTIMATE_UNAVAILABLE/);
 assert.ok(!calls.some(x=>x.method==="eth_sendTransaction"));
});
