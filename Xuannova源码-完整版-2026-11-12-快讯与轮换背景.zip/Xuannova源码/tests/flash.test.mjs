// 玄诺快讯: automation ingest (token), list/detail in seven languages, real view counts, admin edits and the
// built-in news runner (RSS → model → item) with its safety filters.
import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import test from "node:test";

const { openDatabase } = await import("../server/sqlite-db.ts");
const api = await import("../worker/commerce-api.ts");
const flash = await import("../worker/flash.ts");
const ORIGIN = "https://xuannova.test";
const TOKEN = "flash-token-0123456789abcdefghij";

function freshEnv(extra = {}) {
  const db = openDatabase(":memory:");
  for (const file of readdirSync(new URL("../migrations/", import.meta.url)).filter((name) => name.endsWith(".sql")).sort()) db.raw.exec(readFileSync(new URL(`../migrations/${file}`, import.meta.url), "utf8"));
  return { DB: db, SESSION_SECRET: "test-session-signing-key-that-is-long-enough", FLASH_API_TOKEN: TOKEN, SITE_URL: "https://xuannova.test", ...extra };
}
const call = async (env, path, { method = "GET", body, headers = {} } = {}) => {
  const response = await api.handleCommerceApi(new Request(`${ORIGIN}${path}`, { method, headers: { origin: ORIGIN, "content-type": "application/json", ...headers }, body: body === undefined ? undefined : JSON.stringify(body) }), env);
  const type = response.headers.get("content-type") ?? "";
  return { status: response.status, headers: response.headers, body: type.includes("json") ? await response.json() : await response.text() };
};
const block = (title, body) => ({ title, body, quote: "上善若水", quote_source: "《道德经》" });
const sample = {
  category: "energy", cta: "bazi", source_url: "https://example.com/news/gold?utm=1", source_name: "Example News",
  translations: {
    "zh-Hans": block("金价再创新高：金气当令", "据报道，金价本周再创新高。从五行看，这是金气旺盛之象。喜金之人宜顺势而为，忌金之人宜静心守中。"),
    "zh-Hant": block("金價再創新高：金氣當令", "據報導，金價本週再創新高。"),
    en: block("Gold hits a record high: the season of Metal", "Gold reached a new record this week, according to reports."),
    ja: block("金価格が最高値", "報道によると金価格が最高値を更新。"), ko: block("금값 사상 최고", "보도에 따르면 금값이 사상 최고치."),
    vi: block("Giá vàng lập đỉnh", "Theo báo chí, giá vàng lập kỷ lục."), th: block("ราคาทองทำสถิติใหม่", "รายงานว่าราคาทองทำสถิติใหม่"),
  },
};

test("ingest needs the token, stores seven languages and makes a readable slug", async () => {
  const env = freshEnv();
  assert.equal((await call(env, "/api/flash/ingest", { method: "POST", body: sample })).status, 401);
  assert.equal((await call(env, "/api/flash/ingest", { method: "POST", body: sample, headers: { authorization: "Bearer wrong-token-0123456789abcdef" } })).status, 401);
  assert.equal((await call(freshEnv({ FLASH_API_TOKEN: "" }), "/api/flash/ingest", { method: "POST", body: sample, headers: { authorization: `Bearer ${TOKEN}` } })).status, 503);
  const made = await call(env, "/api/flash/ingest", { method: "POST", body: sample, headers: { authorization: `Bearer ${TOKEN}` } });
  assert.equal(made.status, 201);
  assert.match(made.body.slug, /^gold-hits-a-record-high-the-season-of-[0-9a-f]{4}$/);
  assert.equal(made.body.languages.length, 7);
  assert.match(made.body.urls.ja, /\/ja\/flash\//);
  // the same story twice is refused
  assert.equal((await call(env, "/api/flash/ingest", { method: "POST", body: sample, headers: { authorization: `Bearer ${TOKEN}` } })).status, 409);
  // missing both Chinese and English
  assert.equal((await call(env, "/api/flash/ingest", { method: "POST", body: { translations: { ja: block("a", "b") } }, headers: { authorization: `Bearer ${TOKEN}` } })).status, 400);
  // top-level language keys and aliases ("zh", "zh-TW") work too; HTML is stripped
  const flat = await call(env, "/api/flash/ingest", { method: "POST", body: { zh: { title: "<b>节气</b>立冬", content: "立冬收藏，养精蓄锐。" }, "zh-TW": { title: "立冬", content: "立冬收藏。" } }, headers: { authorization: `Bearer ${TOKEN}` } });
  assert.equal(flat.status, 201);
  const detail = await call(env, `/api/flash/item/${flat.body.slug}?locale=zh-Hans`);
  assert.equal(detail.body.item.text.title, "节气立冬");
  assert.equal(detail.body.item.text.summary, "立冬收藏，养精蓄锐。");
});

test("list and detail: language fallback, drafts hidden, paging", async () => {
  const env = freshEnv();
  const made = await call(env, "/api/flash/ingest", { method: "POST", body: { ...sample, translations: { "zh-Hans": sample.translations["zh-Hans"], en: sample.translations.en } }, headers: { authorization: `Bearer ${TOKEN}` } });
  await call(env, "/api/flash/ingest", { method: "POST", body: { status: "draft", source_url: "https://example.com/2", en: block("A draft story about tea", "Draft body text here.") }, headers: { authorization: `Bearer ${TOKEN}` } });
  const list = await call(env, "/api/flash?locale=ko");
  assert.equal(list.body.items.length, 1, "drafts are not listed");
  assert.equal(list.body.items[0].locale, "en", "Korean falls back to English");
  assert.ok(list.body.version);
  const zhHant = await call(env, `/api/flash/item/${made.body.slug}?locale=zh-Hant`);
  assert.equal(zhHant.body.item.locale, "zh-Hans", "Traditional falls back to Simplified");
  assert.equal((await call(env, "/api/flash/item/not-a-real-slug-0000")).status, 404);
});

test("views are real: one per device per day, nothing seeded, not editable by admin", async () => {
  const env = freshEnv();
  const { body } = await call(env, "/api/flash/ingest", { method: "POST", body: sample, headers: { authorization: `Bearer ${TOKEN}` } });
  const first = await call(env, `/api/flash/item/${body.slug}`);
  assert.equal(first.body.item.views, 0);
  const a = { cookie: "xn_device=device-flash-0000000000001" }, b = { cookie: "xn_device=device-flash-0000000000002" };
  assert.equal((await call(env, `/api/flash/item/${body.slug}/view`, { method: "POST", body: {}, headers: a })).body.views, 1);
  assert.equal((await call(env, `/api/flash/item/${body.slug}/view`, { method: "POST", body: {}, headers: a })).body.views, 1);
  assert.equal((await call(env, `/api/flash/item/${body.slug}/view`, { method: "POST", body: {}, headers: b })).body.views, 2);
  assert.equal((await call(env, `/api/flash/item/${body.slug}/view`, { method: "POST", body: {}, headers: { ...b, origin: "https://evil.test" } })).status, 403);
  const admin = { cookie: `xuanyuan_session=${await api.createSessionToken({ sub: "admin", email: "owner@example.com", role: "admin" }, env.SESSION_SECRET)}` };
  assert.equal((await call(env, `/api/admin/flash/${body.slug}`, { method: "POST", body: { views: 99999, pinned: true, featured: true }, headers: admin })).status, 200);
  const after = await call(env, `/api/flash/item/${body.slug}`);
  assert.equal(after.body.item.views, 2, "views cannot be set by hand");
  assert.equal(after.body.item.pinned, true);
  assert.equal(after.body.item.featured, true);
});

test("admin: needs an admin session; hide, edit text, delete, settings", async () => {
  const env = freshEnv();
  const { body } = await call(env, "/api/flash/ingest", { method: "POST", body: sample, headers: { authorization: `Bearer ${TOKEN}` } });
  const member = { cookie: `xuanyuan_session=${await api.createSessionToken({ sub: "m1", email: "m@example.com", role: "member" }, env.SESSION_SECRET)}` };
  assert.equal((await call(env, "/api/admin/flash", { headers: member })).status, 403);
  const admin = { cookie: `xuanyuan_session=${await api.createSessionToken({ sub: "admin", email: "owner@example.com", role: "admin" }, env.SESSION_SECRET)}` };
  const overview = await call(env, "/api/admin/flash", { headers: admin });
  assert.equal(overview.body.total, 1);
  assert.equal(overview.body.ingest, true);
  assert.equal(overview.body.settings.intervalHours, 3);
  await call(env, `/api/admin/flash/${body.slug}`, { method: "POST", body: { status: "hidden", texts: { en: { title: "Edited title", body: "Edited body." } } }, headers: admin });
  assert.equal((await call(env, `/api/flash/item/${body.slug}`)).status, 404, "hidden items are not public");
  const texts = await call(env, `/api/admin/flash/${body.slug}/texts`, { headers: admin });
  assert.equal(texts.body.texts.find((t) => t.locale === "en").title, "Edited title");
  const saved = await call(env, "/api/admin/flash/settings", { method: "POST", body: { auto: false, intervalHours: 99, perRun: 0, publish: "review", sources: ["https://feeds.example.com/rss", "javascript:alert(1)"], prompt: "short" }, headers: admin });
  assert.deepEqual([saved.body.settings.auto, saved.body.settings.intervalHours, saved.body.settings.perRun, saved.body.settings.publish, saved.body.settings.sources.length], [false, 24, 1, "review", 1]);
  assert.equal(saved.body.settings.prompt, flash.DEFAULT_FLASH_PROMPT, "a too-short prompt keeps the default");
  assert.equal((await call(env, `/api/admin/flash/${body.slug}/delete`, { method: "POST", body: {}, headers: admin })).status, 200);
  assert.equal((await call(env, "/api/admin/flash", { headers: admin })).body.total, 0);
});

const rss = `<?xml version="1.0"?><rss><channel><title>Feed</title>
<item><title>黄金价格创历史新高 - 财经日报</title><link>https://news.example.com/a</link><pubDate>${new Date(Date.now() - 3600_000).toUTCString()}</pubDate><description>&lt;a href="x"&gt;国际金价&lt;/a&gt; 本周上涨</description><source url="https://cj.example.com">财经日报</source></item>
<item><title>某地发生地震 多人遇难 - 新闻网</title><link>https://news.example.com/b</link><pubDate>${new Date(Date.now() - 7200_000).toUTCString()}</pubDate></item>
<item><title>Tech firm unveils new chip - Tech Daily</title><link>https://news.example.com/c</link><pubDate>${new Date(Date.now() - 5400_000).toUTCString()}</pubDate></item>
<item><title>Old story - Paper</title><link>https://news.example.com/d</link><pubDate>${new Date(Date.now() - 5 * 86400_000).toUTCString()}</pubDate></item>
</channel></rss>`;

test("feed parsing: titles, Google-style source suffix, entities", () => {
  const items = flash.parseFeed(rss);
  assert.equal(items.length, 4);
  assert.equal(items[0].title, "黄金价格创历史新高");
  assert.equal(items[0].source, "财经日报");
  assert.equal(items[0].summary, "国际金价 本周上涨");
  assert.equal(items[2].source, "Tech Daily");
  assert.equal(flash.avoidStory(items[1]), true, "disasters with victims are avoided before asking the model");
  assert.equal(flash.avoidStory(items[0]), false);
});

test("runner: reads feeds, skips avoided/old stories, writes seven languages, quote of the day once, no repeats", async () => {
  const env = freshEnv({ DEEPSEEK_API_KEY: "test-key" });
  const asked = [];
  const answer = (category) => JSON.stringify({ skip: false, category, cta: "bazi", translations: Object.fromEntries(["zh-Hans", "zh-Hant", "en", "ja", "ko", "vi", "th"].map((code) => [code, { title: `${code} title for the story`, summary: "One line.", body: `${code} body text of the reading.`, quote: "上善若水", quote_source: "《道德经》" }])) });
  const fetcher = async (url, init) => {
    if (String(url).includes("deepseek")) {
      const messages = JSON.parse(init.body).messages;
      asked.push(messages[1].content);
      assert.match(messages[0].content, /FIXED RULES/);
      assert.match(messages[0].content, /private life/);
      const user = JSON.parse(messages[1].content);
      if (user.headline?.startsWith("Tech")) return new Response(JSON.stringify({ choices: [{ message: { content: JSON.stringify({ skip: true, reason: "no angle" }) } }] }));
      return new Response(JSON.stringify({ choices: [{ message: { content: answer(user.task ? "wisdom" : "energy") } }] }));
    }
    return new Response(rss, { headers: { "content-type": "application/rss+xml" } });
  };
  const db = env.DB;
  await flash.writeSettings(db, flash.normalizeSettings({ sources: ["https://feeds.example.com/rss"], perRun: 2 }), new Date());
  const morning = new Date("2026-11-12T02:00:00Z"); // 10:00 in Beijing
  const report = await flash.runFlashAutomation(db, env, { now: morning, fetcher, solarTerm: () => "立冬" });
  assert.equal(report.added.length, 1, "gold story written; tech skipped by the model; disaster and old story never sent");
  assert.ok(report.wisdom, "quote of the day added");
  assert.equal(asked.filter((text) => text.includes("地震")).length, 0);
  assert.equal(asked.filter((text) => text.includes("Old story")).length, 0);
  const list = await flash.listFlash(db, { locale: "th", limit: 10, now: new Date("2026-11-12T03:00:00Z") });
  assert.equal(list.items.length, 2);
  assert.equal(list.items.find((item) => item.category === "wisdom").cta, "daily");
  assert.equal(list.items.find((item) => item.category === "energy").sourceName, "财经日报");
  assert.equal(list.items[0].locale, "th");
  // again right away: not due, no repeats, no second quote
  const again = await flash.runFlashAutomation(db, env, { now: new Date("2026-11-12T02:30:00Z"), fetcher });
  assert.equal(again.added.length + (again.wisdom ? 1 : 0), 0);
  const forced = await flash.runFlashAutomation(db, env, { now: new Date("2026-11-12T02:40:00Z"), fetcher, force: true });
  assert.equal(forced.added.length, 0, "stories already seen are not asked about again");
  // review mode keeps new items as drafts
  await flash.writeSettings(db, flash.normalizeSettings({ sources: ["https://feeds.example.com/rss"], publish: "review", dailyWisdom: false }), new Date());
  db.raw.exec("DELETE FROM flash_seen; DELETE FROM flash_items; DELETE FROM flash_translations;");
  await flash.runFlashAutomation(db, env, { now: new Date("2026-11-12T08:00:00Z"), fetcher, force: true });
  assert.equal((await flash.listFlash(db, { locale: "en", limit: 10, now: new Date("2026-11-12T09:00:00Z") })).items.length, 0);
  assert.equal((await flash.adminListFlash(db, { limit: 10, offset: 0 })).items[0].status, "draft");
});

test("sitemap lists every language with hreflang alternates", async () => {
  const env = freshEnv();
  const { body } = await call(env, "/api/flash/ingest", { method: "POST", body: sample, headers: { authorization: `Bearer ${TOKEN}` } });
  const map = await call(env, "/api/flash/sitemap.xml");
  assert.match(map.headers.get("content-type"), /xml/);
  assert.ok(map.body.includes(`https://xuannova.test/zh-hans/flash/${body.slug}`));
  assert.ok(map.body.includes(`<loc>https://xuannova.test/flash/${body.slug}</loc>`));
  assert.ok(map.body.includes('hreflang="th"'));
});

test("detail page metadata: canonical, hreflang only for existing languages, NewsArticle", async () => {
  const seo = await import("../app/flash-seo.ts");
  const item = { slug: "gold-hits-a-record-high-ab12", category: "energy", text: { title: "金价再创新高", summary: "据报道，金价创新高。", body: "正文", quote: "上善若水", quoteSource: "《道德经》" }, publishedAt: "2026-11-12T02:00:00.000Z", updatedAt: "2026-11-12T02:00:00.000Z", locale: "zh-Hans", coverUrl: null, sourceUrl: "https://news.example.com/a" };
  const meta = seo.flashMetadata({ item, locales: ["zh-Hans", "en"] }, "zh-Hans");
  assert.equal(meta.alternates.canonical, "https://xuannova.com/zh-hans/flash/gold-hits-a-record-high-ab12");
  assert.deepEqual(Object.keys(meta.alternates.languages).sort(), ["en", "x-default", "zh-Hans"]);
  assert.equal(meta.alternates.languages["x-default"], "https://xuannova.com/flash/gold-hits-a-record-high-ab12");
  assert.equal(meta.openGraph.type, "article");
  const data = seo.flashStructuredData(item, "zh-Hans");
  const article = data["@graph"].find((node) => node["@type"] === "NewsArticle");
  assert.equal(article.headline, "金价再创新高");
  assert.equal(article.datePublished, item.publishedAt);
  assert.equal(article.isBasedOn, item.sourceUrl);
});
