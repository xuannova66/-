// 手相面相: request shape, response parsing, sign-in, consent, image checks, daily limit and "photo never stored".
import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import test from "node:test";

const { openDatabase } = await import("../server/sqlite-db.ts");
const { handleCommerceApi } = await import("../worker/commerce-api.ts");
const vision = await import("../worker/vision.ts");

const ORIGIN = "https://xuannova.test";
const IMAGE = `data:image/jpeg;base64,${"A".repeat(4000)}`;
const palmReply = { valid: true, observations: vision.PALM_KEYS.map((key) => ({ key, value: `${key} description` })) };
const calls = [];
let reply = palmReply;
let status = 200;
const realFetch = globalThis.fetch;
globalThis.fetch = async (url, init) => {
  if (String(url).startsWith("https://vision.example")) {
    calls.push({ url: String(url), headers: init.headers, body: JSON.parse(init.body) });
    return new Response(JSON.stringify({ choices: [{ message: { content: "```json\n" + JSON.stringify(reply) + "\n```" } }] }), { status });
  }
  return realFetch(url, init);
};

function freshEnv(extra = {}) {
  const db = openDatabase(":memory:");
  for (const file of readdirSync(new URL("../migrations/", import.meta.url)).filter((name) => name.endsWith(".sql")).sort()) db.raw.exec(readFileSync(new URL(`../migrations/${file}`, import.meta.url), "utf8"));
  return { db, env: { DB: db, SESSION_SECRET: "test-session-signing-key-that-is-long-enough", VISION_API_URL: "https://vision.example/v1/chat/completions", VISION_API_KEY: "vk-test", VISION_MODEL: "vision-test", ...extra } };
}

function client(env, device) {
  const jar = new Map([["xn_device", device], ["xn_tz", "Asia%2FSaigon"]]);
  return async (path, body) => {
    const headers = { origin: ORIGIN, cookie: [...jar].map(([k, v]) => `${k}=${v}`).join("; ") };
    if (body !== undefined) headers["content-type"] = "application/json";
    const response = await handleCommerceApi(new Request(`${ORIGIN}${path}`, { method: body === undefined ? "GET" : "POST", headers, body: body === undefined ? undefined : JSON.stringify(body) }), env);
    for (const cookie of response.headers.getSetCookie?.() ?? []) { const [pair] = cookie.split(";"); const [name, value] = pair.split("="); if (value) jar.set(name, value); else jar.delete(name); }
    return { status: response.status, body: await response.json() };
  };
}

test("vision status follows configuration", async () => {
  assert.deepEqual((await client(freshEnv().env, "device-v-000000000001")("/api/vision/status")).body, { configured: true });
  assert.deepEqual((await client(freshEnv({ VISION_API_KEY: "" }).env, "device-v-000000000002")("/api/vision/status")).body, { configured: false });
});

test("photo reading needs configuration, sign-in, consent and a valid image", async () => {
  const off = client(freshEnv({ VISION_API_KEY: "" }).env, "device-v-000000000003");
  assert.equal((await off("/api/vision/observe", { kind: "palm", image: IMAGE, consent: true })).status, 503);
  const { env } = freshEnv();
  const browser = client(env, "device-v-000000000004");
  assert.equal((await browser("/api/vision/observe", { kind: "palm", image: IMAGE, consent: true })).status, 401);
  await browser("/api/auth/register", { email: "palm@example.com", password: "secret-pass" });
  assert.equal((await browser("/api/vision/observe", { kind: "palm", image: IMAGE })).body.code, "CONSENT_REQUIRED");
  assert.equal((await browser("/api/vision/observe", { kind: "palm", image: "data:image/svg+xml;base64,AAAA", consent: true })).body.code, "INVALID_IMAGE");
  assert.equal((await browser("/api/vision/observe", { kind: "feet", image: IMAGE, consent: true })).status, 400);
});

test("palm photo: one model call, structured observations, nothing stored", async () => {
  const { env, db } = freshEnv();
  const browser = client(env, "device-v-000000000005");
  await browser("/api/auth/register", { email: "reader@example.com", password: "secret-pass" });
  calls.length = 0;
  reply = palmReply;
  const result = await browser("/api/vision/observe", { kind: "palm", hand: "left", image: IMAGE, consent: true, locale: "zh-Hans" });
  assert.equal(result.status, 200);
  assert.equal(result.body.valid, true);
  assert.equal(result.body.observations.length, vision.PALM_KEYS.length);
  assert.equal(calls.length, 1);
  assert.equal(calls[0].headers.authorization, "Bearer vk-test");
  assert.equal(calls[0].body.model, "vision-test");
  assert.match(calls[0].body.messages[0].content, /left palm/);
  assert.match(calls[0].body.messages[0].content, /Simplified Chinese/);
  assert.equal(calls[0].body.messages[1].content[1].image_url.url, IMAGE);
  // Only a usage count is kept: no table holds the image.
  const dump = JSON.stringify(db.raw.prepare("SELECT * FROM vision_usage").all());
  assert.doesNotMatch(dump, /base64/);
  assert.match(dump, /"count":1/);
});

test("unusable photos are reported, failures do not use the allowance, and the daily limit applies", async () => {
  const { env } = freshEnv({ VISION_DAILY_LIMIT: "2" });
  const browser = client(env, "device-v-000000000006");
  await browser("/api/auth/register", { email: "face@example.com", password: "secret-pass" });
  reply = { valid: false, reason: "Several people are in the photo." };
  const invalid = await browser("/api/vision/observe", { kind: "face", image: IMAGE, consent: true, locale: "en" });
  assert.equal(invalid.body.valid, false);
  assert.match(invalid.body.reason, /Several people/);
  status = 500;
  assert.equal((await browser("/api/vision/observe", { kind: "face", image: IMAGE, consent: true })).status, 502);
  status = 200;
  reply = { valid: true, observations: vision.FACE_KEYS.map((key) => ({ key, value: "seen" })) };
  assert.equal((await browser("/api/vision/observe", { kind: "face", image: IMAGE, consent: true })).status, 200);
  const limited = await browser("/api/vision/observe", { kind: "face", image: IMAGE, consent: true });
  assert.equal(limited.status, 429);
  assert.equal(limited.body.code, "VISION_LIMIT");
});

test("response parsing keeps only known keys and rejects thin answers", () => {
  const parsed = vision.parseVisionResponse(JSON.stringify({ valid: true, observations: [{ key: "lifeLine", value: "long" }, { key: "lifeLine", value: "dup" }, { key: "secret", value: "x" }, { key: "headLine", value: "straight" }, { key: "heartLine", value: "curved" }] }), "palm");
  assert.deepEqual(parsed.observations.map((entry) => entry.key), ["lifeLine", "headLine", "heartLine"]);
  assert.throws(() => vision.parseVisionResponse("not json", "palm"));
  assert.throws(() => vision.parseVisionResponse(JSON.stringify({ valid: true, observations: [{ key: "lifeLine", value: "x" }] }), "palm"));
  assert.ok(vision.validImageDataUrl(IMAGE));
  assert.ok(!vision.validImageDataUrl(`data:image/jpeg;base64,${"A".repeat(2_900_000)}`));
  assert.match(vision.buildVisionMessages("face", "ko", IMAGE)[0].content, /Never identify the person/);
});

test("the endpoint accepts a base URL or the full chat-completions URL, with workspace defaults", async () => {
  const { visionEndpoint, visionModel, VISION_DEFAULT_URL } = await import("../worker/vision.ts");
  assert.equal(visionEndpoint({ VISION_API_URL: "https://x.example/compatible-mode/v1/" }), "https://x.example/compatible-mode/v1/chat/completions");
  assert.equal(visionEndpoint({ VISION_API_URL: "https://x.example/v1/chat/completions" }), "https://x.example/v1/chat/completions");
  assert.equal(visionEndpoint({}), `${VISION_DEFAULT_URL}/chat/completions`);
  assert.equal(visionModel({}), "qwen3-vl-plus");
  assert.equal(visionModel({ VISION_MODEL: "qwen3.7-plus" }), "qwen3.7-plus");
});

test("admin vision check reports the provider's answer without exposing the key", async () => {
  const { checkVisionService } = await import("../worker/vision.ts");
  const result = await checkVisionService({ VISION_API_KEY: "sk-secret" }, async () => new Response(JSON.stringify({ error: { code: "invalid_api_key", message: "Incorrect API key provided." } }), { status: 401 }));
  assert.deepEqual([result.ok, result.status, result.providerCode], [false, 401, "invalid_api_key"]);
  assert.ok(!JSON.stringify(result).includes("sk-secret"));
  assert.equal((await checkVisionService({})).providerCode, "VISION_API_KEY missing");
});

test("vision replies in any language are accepted: translated keys, object form, and a reply cut off mid-way", async () => {
  const { parseVisionResponse, PALM_KEYS } = await import("../worker/vision.ts");
  // Keys translated into Thai: fall back to the order of the list.
  const thai = { valid: true, observations: PALM_KEYS.map((key, index) => ({ key: `ลักษณะ ${index}`, value: `ค่า ${key}` })) };
  const fromThai = parseVisionResponse(JSON.stringify(thai), "palm");
  assert.equal(fromThai.valid, true); assert.equal(fromThai.observations.length, PALM_KEYS.length); assert.equal(fromThai.observations[0].key, "handShape");
  // Object form with slightly different spelling of the keys.
  const objectForm = parseVisionResponse(JSON.stringify({ valid: true, observations: { "Hand Shape": "Earth type", life_line: "Long", headLine: "Straight" } }), "palm");
  assert.deepEqual(objectForm.observations.map((item) => item.key), ["handShape", "lifeLine", "headLine"]);
  // A reply cut off in the middle keeps the complete pairs.
  const full = JSON.stringify({ valid: true, observations: PALM_KEYS.map((key) => ({ key, value: `Thai text for ${key}` })) });
  const cut = parseVisionResponse(full.slice(0, Math.floor(full.length * 0.7)), "palm");
  assert.ok(cut.observations.length >= 3 && cut.observations.length < PALM_KEYS.length);
});
