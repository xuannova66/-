import assert from "node:assert/strict";
import test from "node:test";

const { createCompleteChart } = await import("../app/chart-model.ts");
const { localizeBoardTerm } = await import("../app/complete-chart-board.tsx");
const { castLiuyao, hexagramName, TRIGRAMS, plumBlossomCast } = await import("../app/metaphysics/liuyao.ts");
const { ziweiPlacement } = await import("../app/metaphysics/ziwei.ts");
const { qimenChart } = await import("../app/metaphysics/qimen.ts");
const { liurenChart } = await import("../app/metaphysics/liuren.ts");
const { pillarShenSha, validatePillars, annualCycle } = await import("../app/metaphysics/bazi-extra.ts");
const { eclipticLongitudes } = await import("../app/metaphysics/qizheng.ts");
const { calculateTrueSolarTime } = await import("../app/solar-time.ts");
const { convertCalendar } = await import("../app/input-calendar.ts");
const { drawTarot, TAROT_DECK } = await import("../app/metaphysics/tarot.ts");
const { matchDreamSymbols } = await import("../app/metaphysics/dream.ts");

const MODULES = ["bazi", "detail", "compatibility", "liuyao", "ziwei", "qizheng", "qimen", "daliuren", "meihua", "jinkoujue", "heluo", "tieban", "taiyi", "zhuzhai", "zeri", "wenshi", "mirror", "toolkit-time", "toolkit-elements", "toolkit-dream", "toolkit-name", "toolkit-tarot", "toolkit-iching", "toolkit-natal", "toolkit-meihua", "toolkit-fengshui", "hecan", "daily"];
const base = { birthDate: "1994-08-18", birthTime: "15:00", calendar: "solar", focus: "snake river", name: "李明", companionName: "王芳", companionDate: "1995-03-02", companionTime: "08:00", place: "Global", gender: "yang" };
const strip = (chart) => JSON.stringify({ ...chart, inputSummary: null });

test("every module gives the same chart for the same input, whatever the submit counter", () => {
  for (const module of MODULES) {
    const first = createCompleteChart({ ...base, module, version: 1 });
    for (const version of [2, 3, 99]) assert.equal(strip(createCompleteChart({ ...base, module, version })), strip(first), `${module} must be deterministic`);
  }
});

test("Zi Wei: every main star is placed exactly once and the known sample chart matches", () => {
  for (let day = 1; day <= 30; day += 1) for (const hour of "子丑寅卯辰巳午未申酉戌亥") {
    const chart = ziweiPlacement({ yearStem: "甲", yearBranch: "戌", lunarMonth: (day % 12) + 1, lunarDay: day, hourBranch: hour, gender: "yang", currentYear: 2026 });
    const stars = chart.palaces.flatMap((palace) => palace.mainStarNames);
    assert.equal(stars.length, 14);
    assert.equal(new Set(stars).size, 14);
  }
  // 1994-08-18 申时 (lunar 七月十二, 甲戌 year, male): 命宫丙子, 水二局, 紫微破军在未, 天府在酉.
  const sample = ziweiPlacement({ yearStem: "甲", yearBranch: "戌", lunarMonth: 7, lunarDay: 12, hourBranch: "申", gender: "yang", currentYear: 2026 });
  assert.equal(sample.lifeGanzhi, "丙子");
  assert.equal(sample.bureauName, "水二局");
  assert.deepEqual(sample.palaces.find((palace) => palace.branch === "未").mainStarNames, ["紫微", "破军"]);
  assert.deepEqual(sample.palaces.find((palace) => palace.branch === "酉").mainStarNames, ["天府"]);
  assert.ok(sample.transforms.includes("廉贞化禄") && sample.transforms.includes("太阳化忌"));
});

test("Liuyao: 64 hexagrams map to 8 palaces × 8, with Na Jia and world lines by Jing Fang", () => {
  const seen = new Set();
  for (let n = 0; n < 64; n += 1) {
    const lines = Array.from({ length: 6 }, (_, i) => ((n >> i) & 1) === 1);
    const cast = castLiuyao(lines, [false, false, false, false, false, false], "甲子");
    seen.add(cast.name.full);
    assert.ok(cast.world >= 1 && cast.world <= 6);
    assert.equal(cast.changedName, undefined, "no moving line → no transformed hexagram");
  }
  assert.equal(seen.size, 64);
  const qian = castLiuyao([true, true, true, true, true, true], [false, false, false, false, false, false], "甲子");
  assert.deepEqual(qian.lines.map((line) => line.branch), ["子", "寅", "辰", "午", "申", "戌"]);
  assert.equal(qian.world, 6);
  const gou = castLiuyao([false, true, true, true, true, true], [false, false, false, false, false, false], "丙子");
  assert.equal(gou.name.full, "天风姤");
  assert.equal(gou.world, 1);
  assert.equal(gou.lines[0].spirit, "朱雀");
  assert.equal(hexagramName("乾", "坤").full, "地天泰");
  const moving = castLiuyao([true, true, true, true, true, true], [true, false, false, false, false, false], "甲子");
  assert.equal(moving.changedName.full, "天风姤");
  assert.equal(TRIGRAMS.length, 8);
  assert.equal(plumBlossomCast(1, 1, 1, 1).movingLines.filter(Boolean).length, 1);
});

test("Qi Men: 立秋下元 is Yin bureau 8 and the duty star follows the hour stem", () => {
  const chart = qimenChart({ term: "立秋", dayPillar: "甲辰", hourPillar: "壬申" });
  assert.equal(chart.bureauName, "阴遁八局");
  assert.equal(chart.dutyStar, "天任");
  assert.equal(chart.dutyGate, "生门");
  assert.equal(chart.dutyStarPalace, 4);
  assert.equal(chart.dutyGatePalace, 9);
  const deities = chart.palaces.filter((palace) => palace.palace !== 5).map((palace) => palace.deity);
  assert.equal(new Set(deities).size, 8);
  assert.ok(!deities.some((deity) => /Local/.test(deity)));
});

test("Da Liu Ren: four lessons, three transmissions and twelve generals come from the plates", () => {
  const chart = liurenChart({ qi: "大暑", dayPillar: "甲辰", hourBranch: "申", monthBranch: "申" });
  assert.equal(chart.monthGeneral, "午");
  assert.deepEqual(chart.lessons.map((lesson) => `${lesson.lower}${lesson.upper}`), ["甲子", "子戌", "辰寅", "寅子"]);
  assert.equal(chart.transmissions.length, 3);
  assert.equal(new Set(chart.positions.map((position) => position.general)).size, 12);
});

test("BaZi extras: shen-sha, start age and pillar validation follow the rules", () => {
  const marks = pillarShenSha(["甲戌", "壬申", "丙子", "甲午"]);
  assert.ok(marks[2].noble.length + marks[2].other.length >= 0);
  assert.ok(marks[0].noble.includes("天乙贵人") === false);
  assert.deepEqual(validatePillars(["甲戌", "壬申", "丙子", "甲午"]), []);
  assert.deepEqual(validatePillars(["甲戌", "甲申", "丙子", "甲午"]), ["month-stem"]);
  assert.deepEqual(validatePillars(["甲戌", "壬申", "丙子", "丙午"]), ["hour-stem"]);
  assert.equal(annualCycle("丙", 2026, 1)[0].ganzhi, "丙午");
  const chart = createCompleteChart({ ...base, module: "bazi", version: 1 });
  const start = chart.sections.find((section) => section.id === "start-luck").items.find((item) => item.label === "Start age").value;
  assert.match(start, /^\d+y \d+m \d+d$/);
  const markers = chart.board.cells.flatMap((cell) => cell.items.filter((item) => item.label === "Pillar shen-sha" || item.label === "Auxiliary star").map((item) => item.value));
  assert.ok(markers.every((value) => value === "—" || /^[一-鿿 · ]+$/.test(value)));
});

test("Celestial positions are close to known values", () => {
  const lon = eclipticLongitudes(Date.UTC(2000, 0, 1, 12));
  assert.ok(Math.abs(lon.太阳 - 280.4) < 1);
  assert.ok(Math.abs(lon.太阴 - 223.3) < 3);
});

test("True solar time in mainland China uses Beijing time as the civil reference", () => {
  const urumqi = calculateTrueSolarTime({ date: "1994-08-18", time: "15:00", longitude: 87.6, timezone: "Asia/Urumqi" });
  assert.equal(urumqi.standardOffsetMinutes, 480);
  assert.ok(urumqi.trueSolarTime.startsWith("12:"), urumqi.trueSolarTime);
});

test("Switching calendars converts the entered date instead of keeping the same numbers", () => {
  const lunar = convertCalendar("1994-08-18", "15:00", "solar", "lunar", false);
  assert.equal(lunar.date, "1994-07-12");
  const back = convertCalendar(lunar.date, "15:00", "lunar", "solar", lunar.leap);
  assert.equal(back.date, "1994-08-18");
  const leap = convertCalendar("2023-04-10", "12:00", "solar", "lunar", false); // 闰二月 2023
  assert.equal(leap.leap, true);
  const pillars = convertCalendar("1994-08-18", "15:00", "solar", "pillars", false);
  assert.equal(pillars.pillars.length, 4);
});

test("Tarot uses a real 78-card deck and dream images come from the description", () => {
  assert.equal(TAROT_DECK.length, 78);
  const a = drawTarot("question|2026-01-01");
  const b = drawTarot("question|2026-01-01");
  assert.deepEqual(a.map((entry) => entry.card.id), b.map((entry) => entry.card.id));
  assert.equal(new Set(a.map((entry) => entry.card.id)).size, 3);
  assert.deepEqual(matchDreamSymbols("I dreamed of a snake near the sea").map((symbol) => symbol.name.en), ["Snake", "Water"]);
  assert.deepEqual(matchDreamSymbols("梦见掉牙").map((symbol) => symbol.name.en), ["Teeth"]);
  assert.deepEqual(matchDreamSymbols("I was chasing a ball"), []);
});

test("chart text has no English, Han or Simplified leaks in the localized interfaces", () => {
  const SIMP = /[们这个为说时动开关门阴阳贵杀离兑龙执寻复变应财伤带临养绝湿热凉华盖鸾满处惊孙宫归机贞贪军辅钺铃马庙权顺闭计纪鹑实娄张轸毕陈罗历气节风泽讼师蛊观贲颐过晋损渐丰涣济谦盘传课间转]/;
  const strings = new Set();
  for (let d = 0; d < 12; d += 1) for (const module of MODULES) {
    const lines = [0, 1, 2, 3, 4, 5].map((i) => ((d >> i) & 1) === 1);
    const chart = createCompleteChart({ ...base, birthDate: `${1960 + d * 5}-0${1 + (d % 9)}-1${d % 9}`, birthTime: `${String((d * 2) % 24).padStart(2, "0")}:10`, module, version: 1, lines, movingLines: lines.map((_, i) => i === d % 6), gender: d % 2 ? "yang" : "yin", focus: "" });
    const values = [chart.board.label, ...chart.board.cells.flatMap((cell) => [cell.title, cell.subtitle, ...cell.items.flatMap((item) => [item.label, item.value])]), ...chart.sections.flatMap((section) => [section.title, section.lead, ...section.items.flatMap((item) => [item.label, item.value])])];
    for (const value of values) if (typeof value === "string" && value !== "李明" && value !== "李" && value !== "明") strings.add(value);
  }
  for (const locale of ["zh-Hans", "zh-Hant", "ja", "ko", "th"]) {
    const leaked = [...strings].map((value) => localizeBoardTerm(value, locale)).filter((value) => /[A-Za-z]{2,}/.test(value) && !/^(Zi Wei|BaZi)/.test(value));
    assert.deepEqual(leaked.slice(0, 5), [], `${locale} shows English chart text`);
  }
  for (const locale of ["en", "ko", "vi", "th"]) {
    const han = [...strings].map((value) => localizeBoardTerm(value, locale)).filter((value) => /[㐀-鿿]/.test(value));
    assert.deepEqual(han.slice(0, 5), [], `${locale} shows untranslated Han text`);
  }
  const traditional = [...strings].map((value) => localizeBoardTerm(value, "zh-Hant")).filter((value) => SIMP.test(value));
  assert.deepEqual(traditional.slice(0, 5), [], "zh-Hant shows simplified characters");
});

test("Feng shui: Kua numbers, Eight Mansions and annual flying stars follow the standard tables", async () => {
  const { kuaNumber, annualCenterStar, fengshuiChart } = await import("../app/metaphysics/fengshui.ts");
  assert.equal(kuaNumber(1990, "yang"), 1);
  assert.equal(kuaNumber(1990, "yin"), 8);
  assert.equal(kuaNumber(1984, "yang"), 7);
  assert.equal(kuaNumber(2000, "yang"), 9);
  assert.equal(kuaNumber(2000, "yin"), 6);
  assert.equal(kuaNumber(1986, "yang"), 2, "5 becomes 2 for men");
  assert.deepEqual([2024, 2025, 2026, 2027].map(annualCenterStar), [3, 2, 1, 9]);
  const chart = fengshuiChart({ solarYear: 1990, gender: "yang", sitting: "North", currentYear: 2026 });
  assert.equal(chart.personGroup, "东四命");
  assert.equal(chart.houseTrigram, "坎");
  assert.equal(chart.facing, "South");
  assert.equal(chart.directions.find((entry) => entry.direction === "Southeast").personal, "生气");
  assert.equal(chart.centerStar, "一白");
  assert.equal(chart.directions.find((entry) => entry.direction === "Northwest").annualStar, "二黑");
});

test("Plum blossom: body/function come from the trigram holding the moving line", () => {
  const chart = createCompleteChart({ ...base, module: "toolkit-meihua", version: 1 });
  const ti = chart.sections.find((section) => section.id === "meihua-ti-yong");
  assert.ok(["体用比和", "用生体", "体生用", "体克用", "用克体"].includes(ti.items.find((item) => item.label === "Relation").value));
  assert.equal(chart.board.cells.length, 3);
});

test("school options: early Zi moves 23:30 to the next day; luck start can be counted to the minute", async () => {
  const { createStudyResult } = await import("../app/study-engine.ts");
  const base = { birthDate: "1994-08-18", birthTime: "23:30", calendar: "solar", focus: "", name: "", companionName: "", module: "bazi", version: 1, gender: "yang" };
  const late = createStudyResult(base);
  const early = createStudyResult({ ...base, ziHour: "early" });
  assert.equal(late.pillars[2], "丙子", "late Zi keeps the same day pillar");
  assert.equal(early.pillars[2], "丁丑", "early Zi already counts as the next day");
  assert.equal(late.pillars[3], early.pillars[3], "the hour pillar is the same Zi hour either way");
  const days = createStudyResult({ ...base, birthTime: "12:00" }).astro.luck;
  const minutes = createStudyResult({ ...base, birthTime: "12:00", luckPrecision: "minutes" }).astro.luck;
  assert.equal(days.cycles[0].ganzhi, minutes.cycles[0].ganzhi, "same luck pillars");
  assert.ok(Number.isFinite(minutes.years) && Number.isFinite(minutes.months));
});

test("plum blossom number and text casting", async () => {
  const { plumBlossomNumberCast, plumBlossomTextCast, trigramOf } = await import("../app/metaphysics/liuyao.ts");
  const cast = plumBlossomNumberCast(5, 8, 1); // 5 → 巽 upper, 8 → 坤 lower, (5+8+1) % 6 = 2 → second line
  assert.equal(trigramOf(cast.lines.slice(3)), "巽");
  assert.equal(trigramOf(cast.lines.slice(0, 3)), "坤");
  assert.equal(cast.movingLines.indexOf(true), 1);
  const text = plumBlossomTextCast("今天适合出门吗", 1); // 7 characters → 3 / 4, moving (7+1) % 6 = 2
  assert.equal(text.units, 7);
  assert.equal(trigramOf(text.lines.slice(3)), "离");
  assert.equal(trigramOf(text.lines.slice(0, 3)), "震");
  assert.equal(text.movingLines.indexOf(true), 1);
  assert.equal(plumBlossomTextCast("Should I travel this week", 1).units, 5, "other languages count words");
});

test("Zi Wei school options: leap-month handling and the alternative 庚 transforms", async () => {
  const { ziweiMonth, ziweiPlacement } = await import("../app/metaphysics/ziwei.ts");
  assert.equal(ziweiMonth(4, 20, true), 5);
  assert.equal(ziweiMonth(4, 10, true), 4);
  assert.equal(ziweiMonth(4, 20, true, "current"), 4);
  assert.equal(ziweiMonth(4, 2, true, "next"), 5);
  assert.equal(ziweiMonth(4, 20, false, "next"), 4, "non-leap months are unchanged");
  const input = { yearStem: "庚", yearBranch: "午", lunarMonth: 3, lunarDay: 9, hourBranch: "辰", gender: "yang", currentYear: 2026 };
  const flat = (placement) => JSON.stringify(placement);
  assert.match(flat(ziweiPlacement(input)), /太阴[^"]*化科|化科[^"]*太阴/);
  assert.match(flat(ziweiPlacement({ ...input, transformVariant: "alt" })), /天府[^"]*化科|化科[^"]*天府/);
});

test("reading glossary marks each known term once, in the reader's language", async () => {
  const { splitTerms, glossary } = await import("../app/glossary.ts");
  const parts = splitTerms("日主为丙火，日主得令；大运转入乙亥。", "zh-Hans");
  const terms = parts.filter((part) => typeof part !== "string").map((part) => part.term);
  assert.deepEqual(terms, ["日主", "大运"]);
  assert.equal(parts.map((part) => (typeof part === "string" ? part : part.term)).join(""), "日主为丙火，日主得令；大运转入乙亥。", "text is unchanged");
  for (const entry of glossary) for (const locale of ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"]) {
    assert.ok(entry.names[locale].length > 0 && entry.tip[locale].length > 10, `${entry.names.en[0]} ${locale}`);
  }
});
