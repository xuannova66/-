import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";
import { selectFollowUps, summarizeReading, followUpHistory } from "../app/reading-followups.ts";
import { applyFollowUpSkill, methodGuide } from "../worker/skills/reading-follow-up.ts";
import { buildInterpretationMessages, requestDeepSeekInterpretation, requestDeepSeekInterpretationStream } from "../worker/deepseek.ts";

const reading = { title: "Report", summary: "A reflective overview.", conclusion: "Consider what is within your control.",
  sections: Array.from({ length: 6 }, (_, i) => ({ title: `Aspect ${i + 1}`, text: `Evidence ${i + 1}. ` + "detail ".repeat(90) })),
  followUps: ["How can I learn?", "How can I learn？", "What did I already ask?"],
};
const request = { tool: "bazi", locale: "en", question: "What did I already ask?",
  conversationHistory: [{ question: "How can I learn?", answer: "Previous answer." }],
  chart: { calendar: { lunar: "sample", naYin: "sample" }, pillars: ["甲子"], board: { kind: "pillars", label: "Four pillars", cells: [] }, sections: [], sourceFacts: [], inputSummary: { focus: "work", place: "Singapore", version: 1 } },
};

test("follow-up selection normalizes repeated/current/history questions, skips invalid entries and fills gaps", () => {
  const questions = selectFollowUps([null, " ", 42, "123", "a".repeat(221), "Ｈｏｗ can I learn？", "How can I learn?", "What did I already ask?", "What can I observe?"],
    { locale: "en", question: request.question, previousQuestions: ["How can I learn?"] });
  assert.equal(questions.length, 3);
  assert.equal(questions[0], "What can I observe?");
  assert.equal(new Set(questions).size, 3);
  assert.ok(!questions.some((question) => /learn|already ask/.test(question)));
});

test("all seven locales have distinct safe fallbacks, and exhausted suggestions are not recycled", () => {
  const locales = ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"];
  const batches = locales.map((locale) => selectFollowUps([], { locale }));
  assert.equal(new Set(batches.map((questions) => questions.join("|"))).size, 7);
  for (let i = 0; i < locales.length; i++) {
    const first = batches[i];
    const second = selectFollowUps([], { locale: locales[i], previousQuestions: first });
    assert.equal(first.length, 3); assert.equal(second.length, 3);
    assert.equal(new Set([...first, ...second]).size, 6);
    assert.deepEqual(selectFollowUps([], { locale: locales[i], previousQuestions: [...first, ...second] }), []);
  }
  assert.deepEqual(selectFollowUps([], { locale: "unknown" }), batches[0]);
});

test("same-chart unlocked reports seed a bounded outline of all sections, not just the beginning", () => {
  const draft = { chartFingerprint: "A", draftId: "draft-A", question: "Original question", unlocked: true, full: reading };
  const empty = { chartFingerprint: "", turns: [] };
  const turns = followUpHistory("A", empty, draft);
  assert.equal(turns.length, 1);
  assert.equal(turns[0].question, "Original question");
  for (let i = 1; i <= 6; i++) assert.ok(turns[0].answer.includes(`Aspect ${i}: Evidence ${i}.`));
  assert.ok(turns[0].answer.length <= 2400);
  assert.equal(summarizeReading(reading), turns[0].answer);
  assert.deepEqual(followUpHistory("B", empty, draft), []);
  assert.deepEqual(followUpHistory("A", empty, { ...draft, unlocked: false }), []);
  assert.deepEqual(followUpHistory("A", empty, { ...draft, full: undefined }), []);
});

test("switching charts/reports isolates history and continuing the same report retains at most ten turns", () => {
  const turns = Array.from({ length: 12 }, (_, i) => ({ question: `Question ${i}`, answer: `Answer ${i}` }));
  const context = { chartFingerprint: "A", draftId: "old", turns };
  const draft = { chartFingerprint: "A", draftId: "old", question: "original", unlocked: true, full: reading };
  assert.deepEqual(followUpHistory("A", context, draft), turns.slice(-10));
  const changed = followUpHistory("A", context, { ...draft, draftId: "new", question: "New report" });
  assert.equal(changed.length, 1); assert.equal(changed[0].question, "New report");
  assert.deepEqual(followUpHistory("B", context, null), []);
  assert.deepEqual(followUpHistory("A", { chartFingerprint: "A", turns }, null), turns.slice(-10));
});

test("skill routes to the current method and keeps user instructions out of its policy", () => {
  assert.notEqual(methodGuide("bazi"), methodGuide("toolkit-tarot"));
  assert.equal(methodGuide("liuyao"), methodGuide("toolkit-meihua"));
  assert.notEqual(methodGuide("compatibility"), methodGuide("toolkit-fengshui"));
  for (const mode of ["structured", "conversation"]) {
    const messages = buildInterpretationMessages({ ...request, tool: "toolkit-dream", question: "INJECT_SECRET_POLICY" }, mode);
    assert.ok(messages[0].content.includes(methodGuide("toolkit-dream")));
    assert.ok(!messages[0].content.includes("INJECT_SECRET_POLICY"));
    assert.ok(messages[1].content.includes("INJECT_SECRET_POLICY"));
  }
  const result = applyFollowUpSkill(reading, request);
  assert.equal(result.followUps.length, 3);
  assert.deepEqual({ ...result, followUps: reading.followUps }, reading);
  assert.deepEqual(reading.followUps, ["How can I learn?", "How can I learn？", "What did I already ask?"], "input reading is not mutated");
});

test("streaming and ordinary generation apply identical guidance with no extra provider call", async () => {
  let calls = 0;
  const content = JSON.stringify(reading);
  const ordinary = await requestDeepSeekInterpretation(request, "conversation", "test-key", "test-model", async () => {
    calls++;
    return new Response(JSON.stringify({ choices: [{ message: { content } }] }));
  });
  const partials = [];
  const streamed = await requestDeepSeekInterpretationStream(request, "conversation", "test-key", "test-model", (partial) => partials.push(partial), async () => {
    calls++;
    return new Response(`data: ${JSON.stringify({ choices: [{ delta: { content } }] })}\n\ndata: [DONE]\n\n`, { headers: { "content-type": "text/event-stream" } });
  });
  assert.equal(calls, 2, "one provider call for each reading, zero for follow-up selection");
  assert.deepEqual(streamed, ordinary);
  assert.equal(streamed.followUps.length, 3);
  for (const partial of partials) assert.deepEqual(partial.followUps, []);
});

test("ten-section deep readings apply guidance after joining both halves", async () => {
  const deepRequest = { ...request, tool: "detail" };
  const first = { ...reading, sections: reading.sections.slice(0, 5), followUps: [] };
  const second = { sections: Array.from({ length: 5 }, (_, i) => ({ title: `Later ${i + 1}`, text: `Details ${i + 1}` })), followUps: [request.question, "What can I observe?"] };
  let calls = 0;
  const fetchMock = async (_url, options) => {
    calls++;
    const body = JSON.parse(options.body);
    const isSecond = body.messages[0].content.includes("This is the second half");
    const content = JSON.stringify(isSecond ? second : first);
    if (body.stream) return new Response(`data: ${JSON.stringify({ choices: [{ delta: { content } }] })}\n\ndata: [DONE]\n\n`);
    return new Response(JSON.stringify({ choices: [{ message: { content } }] }));
  };
  const ordinary = await requestDeepSeekInterpretation(deepRequest, "structured", "test-key", "test-model", fetchMock);
  const streamed = await requestDeepSeekInterpretationStream(deepRequest, "structured", "test-key", "test-model", () => {}, fetchMock);
  assert.equal(calls, 4);
  assert.equal(ordinary.sections.length, 10);
  assert.equal(ordinary.followUps.length, 3);
  assert.ok(!ordinary.followUps.includes(request.question));
  assert.deepEqual(streamed, ordinary);
  assert.ok(summarizeReading(ordinary).includes("Later 5: Details 5"));
});

test("suggestion clicks remain a fill-only action and the free-preview gate remains server-side", async () => {
  const source = await readFile(new URL("../app/interpretation-panel.tsx", import.meta.url), "utf8");
  const click = source.split("const pickFollowUp = (item: string) => {")[1].split("\n  };", 1)[0];
  assert.match(click, /setMode\("conversation"\); setQuestion\(item\)/);
  assert.doesNotMatch(click, /fetch\(|interpretStudy\(|requestPreview\(|unlock\(/);
  assert.match(source, /shownDraft\.unlocked && shownDraft\.full && !response && <FollowUpBlock/);
});
