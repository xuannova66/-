import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { hexToBytes, sha256 } from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { openDatabase } from "../server/sqlite-db.ts";
import { walletLinkMessage, verifyWalletLinkSignature, consumeWalletLinkChallenge, issueDraftWalletLink, completeDraftWalletLink, tronMessageHash } from "../worker/wallet-link-auth.draft.ts";
const alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
function base58(bytes) { let n=0n;for(const b of bytes)n=n*256n+BigInt(b);let out="";while(n>0n){out=alphabet[Number(n%58n)]+out;n/=58n;}let zeros=0;while(bytes[zeros]===0)zeros++;return "1".repeat(zeros)+out; }
function tronAddress(address) {const payload=Uint8Array.from([0x41,...hexToBytes(address)]);const h=hexToBytes(sha256(hexToBytes(sha256(payload))));return base58(Uint8Array.from([...payload,...h.slice(0,4)]));}

test("Solana cryptographic proof is bound to origin, wallet, member, expiry and single-use challenge",async()=>{
 const keys=await crypto.subtle.generateKey({name:"Ed25519"},true,["sign","verify"]);
 const address=base58(new Uint8Array(await crypto.subtle.exportKey("raw",keys.publicKey)));
 const challenge={memberId:"m",chain:"solana",address,origin:"https://xuannova.com",nonce:"a".repeat(64),issuedAt:100,expiresAt:200};
 const message=walletLinkMessage(challenge,150);
 const signature=new Uint8Array(await crypto.subtle.sign("Ed25519",keys.privateKey,new TextEncoder().encode(message)));
 assert.equal(await verifyWalletLinkSignature(challenge,150,signature),true);
 assert.equal(await verifyWalletLinkSignature({...challenge,memberId:"other"},150,signature),false);
 assert.equal(await verifyWalletLinkSignature({...challenge,origin:"https://evil.example"},150,signature),false);
 assert.equal(await verifyWalletLinkSignature(challenge,200,signature),false);
 const db=openDatabase(":memory:"); try {
  const dir=new URL("../migrations/",import.meta.url); for(const file of readdirSync(dir).filter(s=>s.endsWith(".sql")).sort())db.raw.exec(readFileSync(new URL(file,dir),"utf8"));
  db.raw.exec(readFileSync(new URL("../db/drafts/wallet-link-challenges.sql",import.meta.url),"utf8"));
  db.raw.prepare("INSERT INTO members(id,credits,role,created_at,updated_at) VALUES(?,?,?,?,?)").run("m",0,"member","now","now");
  db.raw.prepare("INSERT INTO wallet_link_challenges_draft(nonce,member_id,chain,address,origin,issued_at,expires_at) VALUES(?,?,?,?,?,?,?)").run(challenge.nonce,challenge.memberId,challenge.chain,challenge.address,challenge.origin,challenge.issuedAt,challenge.expiresAt);
  const results=await Promise.all([consumeWalletLinkChallenge(db,challenge,150,signature),consumeWalletLinkChallenge(db,challenge,150,signature)]);
  assert.equal(results.filter(Boolean).length,1);
 } finally {db.raw.close();}
});

test("TRON TIP-191 signature recovers the expected address and rejects mismatches",async()=>{
 const signer=privateKeyToAccount(`0x${"11".repeat(32)}`), wrong=privateKeyToAccount(`0x${"22".repeat(32)}`);
 const challenge={memberId:"m",chain:"tron",address:tronAddress(signer.address),origin:"https://xuannova.com",nonce:"b".repeat(64),issuedAt:100,expiresAt:200};
 const hash=tronMessageHash(walletLinkMessage(challenge,150));
 const signed=await signer.sign({hash});
 assert.equal(await verifyWalletLinkSignature(challenge,150,signed),true);
 assert.equal(await verifyWalletLinkSignature({...challenge,address:tronAddress(wrong.address)},150,signed),false);
 assert.equal(await verifyWalletLinkSignature(challenge,150,`0x${"00".repeat(65)}`),false);
 const legacyV=`${signed.slice(0,-2)}${(parseInt(signed.slice(-2),16)-27).toString(16).padStart(2,"0")}`;
 assert.equal(await verifyWalletLinkSignature(challenge,150,legacyV),true);
});

test("server-issued challenge links a wallet atomically, rejects replay and cannot transfer ownership to another member",async()=>{
 const keys=await crypto.subtle.generateKey({name:"Ed25519"},true,["sign","verify"]);
 const address=base58(new Uint8Array(await crypto.subtle.exportKey("raw",keys.publicKey)));
 const db=openDatabase(":memory:"); try {
  const dir=new URL("../migrations/",import.meta.url); for(const file of readdirSync(dir).filter(s=>s.endsWith(".sql")).sort())db.raw.exec(readFileSync(new URL(file,dir),"utf8"));
  db.raw.exec(readFileSync(new URL("../db/drafts/wallet-link-challenges.sql",import.meta.url),"utf8"));
  for(const id of ["m","other"])db.raw.prepare("INSERT INTO members(id,credits,role,created_at,updated_at) VALUES(?,?,?,?,?)").run(id,0,"member","now","now");
  const sign=async(message)=>new Uint8Array(await crypto.subtle.sign("Ed25519",keys.privateKey,new TextEncoder().encode(message)));
  const first=await issueDraftWalletLink(db,{memberId:"m",chain:"solana",address,origin:"https://xuannova.com",now:100});
  const sig=await sign(first.message);
  const results=await Promise.all([completeDraftWalletLink(db,first.challenge,150,sig),completeDraftWalletLink(db,first.challenge,150,sig)]);
  assert.equal(results.filter(Boolean).length,1);
  const second=await issueDraftWalletLink(db,{memberId:"other",chain:"solana",address,origin:"https://xuannova.com",now:100});
  assert.equal(await completeDraftWalletLink(db,second.challenge,150,await sign(second.message)),false);
  assert.equal(db.raw.prepare("SELECT member_id FROM member_wallet_links_draft WHERE chain=? AND address=?").get("solana",address).member_id,"m");
 } finally {db.raw.close();}
});
