import test from "node:test";
import assert from "node:assert/strict";
import {pythReferenceDraft} from "../worker/pyth-reference.draft.ts";
const asset="0x1111111111111111111111111111111111111111",stable="0x2222222222222222222222222222222222222222",eth="a".repeat(64),usdc="b".repeat(64),key="test-secret-key";
const input={apiKey:key,chainId:1,asset,settlement:stable,outputUnits:4990000n,inputFeed:{id:eth,chainId:1,asset,decimals:18},settlementFeed:{id:usdc,chainId:1,asset:stable,decimals:6},clock:()=>1000};
const record=(id,price,conf="100",time=995,expo=-8)=>({id,price:{price,conf,expo,publish_time:time}});
test("fresh independent USD feeds derive exact-output token input and never put key in URL",async()=>{
 let calls=0;const fetcher=async(url,init)=>{calls++;assert.equal(init.headers.authorization,`Bearer ${key}`);assert.ok(!url.includes(key));return Response.json({parsed:[record(eth,"250000000000"),record(usdc,"100000000")]});};
 assert.deepEqual(await pythReferenceDraft({...input,fetcher}),{inputUnits:1996000000000000n,observedAt:995});
 await pythReferenceDraft({...input,fetcher});assert.equal(calls,2);
});
test("rejects unconfigured, stale, low-confidence, wrong mapping and unavailable feeds",async()=>{
 const respond=parsed=>async()=>Response.json({parsed});
 await assert.rejects(pythReferenceDraft({...input,apiKey:""}),/PRICE_SOURCE_NOT_CONFIGURED/);
 await assert.rejects(pythReferenceDraft({...input,inputFeed:{...input.inputFeed,chainId:56}}),/PRICE_FEED_MAPPING_MISMATCH/);
 await assert.rejects(pythReferenceDraft({...input,fetcher:respond([record(eth,"250000000000","100",900),record(usdc,"100000000")])}),/STALE_OR_INVALID_PRICE/);
 await assert.rejects(pythReferenceDraft({...input,fetcher:respond([record(eth,"250000000000","3000000000"),record(usdc,"100000000")])}),/PRICE_CONFIDENCE_TOO_WIDE/);
 await assert.rejects(pythReferenceDraft({...input,fetcher:async()=>new Response("denied",{status:401})}),/PRICE_SOURCE_UNAVAILABLE/);
 await assert.rejects(pythReferenceDraft({...input,fetcher:respond([record(eth,"250000000000"),record(eth,"250000000000"),record(usdc,"100000000")])}),/INVALID_PRICE_RESPONSE/);
});
