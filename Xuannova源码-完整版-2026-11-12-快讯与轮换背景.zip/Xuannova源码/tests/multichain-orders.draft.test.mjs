import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { openDatabase } from "../server/sqlite-db.ts";

test("draft order ledger atomically credits one time per chain event", () => {
  const db = openDatabase(":memory:");
  try {
    const dir = new URL("../migrations/", import.meta.url);
    for (const file of readdirSync(dir).filter((s) => s.endsWith(".sql")).sort()) db.raw.exec(readFileSync(new URL(file, dir), "utf8"));
    db.raw.exec(readFileSync(new URL("../db/drafts/multichain-orders.sql", import.meta.url), "utf8"));
    const now = "2026-01-01T00:00:00Z";
    db.raw.prepare("INSERT INTO members(id,wallet_address,credits,daily_credits,role,created_at,updated_at) VALUES(?,?,?,?,?,?,?)").run("m", "0x1111111111111111111111111111111111111111", 10, 3, "member", now, now);
    const insert = db.raw.prepare("INSERT INTO multichain_orders_draft(id,member_id,chain,package_id,credits,buyer,recipient,settlement_asset,amount_units,order_reference,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)");
    const add = (id, ref, chain = "ethereum", units = "4990000") => insert.run(id,"m",chain,"seed",20,"buyer","recipient","asset",units,ref.repeat(64),now);
    add("one","a"); add("two","b"); add("three","c");
    assert.throws(() => add("wrong","d","ethereum","4990001"));
    assert.throws(() => db.raw.prepare("UPDATE multichain_orders_draft SET credits=999 WHERE id='one'").run());
    const settle = db.raw.prepare("UPDATE multichain_orders_draft SET status='credited',transaction_id=?,event_index=?,credited_at=? WHERE id=?");
    const hash = "1".repeat(64);
    assert.throws(() => settle.run(hash,null,now,"one"));
    settle.run(hash,0,now,"one");
    assert.equal(db.raw.prepare("SELECT credits FROM members WHERE id='m'").get().credits,30);
    const ledger = db.raw.prepare("SELECT delta,balance_after FROM credit_ledger WHERE id='multichain-draft:one'").get();
    assert.deepEqual({ ...ledger }, { delta: 20, balance_after: 33 });
    assert.throws(() => settle.run(hash,0,now,"two"));
    assert.equal(db.raw.prepare("SELECT credits FROM members WHERE id='m'").get().credits,30);
    settle.run(hash,1,now,"two");
    assert.equal(db.raw.prepare("SELECT credits FROM members WHERE id='m'").get().credits,50);
    assert.throws(() => settle.run(hash,1,now,"two"));
    assert.throws(() => settle.run("A".repeat(64),2,now,"three"));
    assert.equal(db.raw.prepare("SELECT count(*) AS n FROM credit_ledger WHERE id LIKE 'multichain-draft:%'").get().n,2);
    assert.deepEqual(db.raw.prepare("PRAGMA foreign_key_check").all(),[]);
    add("tron-old","e","tron");
    const legacy=db.raw.prepare("INSERT INTO payment_orders(id,member_id,package_id,amount_usdt,credits,network,transaction_hash,status,submitted_at) VALUES(?,?,?,?,?,?,?,?,?)");
    legacy.run("legacy","m","seed","4.99",20,"trc20",`0X${"ab".repeat(32)}`,"pending",now);
    assert.throws(()=>settle.run("ab".repeat(32),0,now,"tron-old"),/transaction reserved by legacy order/);
    add("tron-new","f","tron");
    settle.run("cd".repeat(32),0,now,"tron-new");
    assert.throws(()=>legacy.run("duplicate","m","seed","4.99",20,"trc20",`0X${"CD".repeat(32)}`,"pending",now),/transaction reserved by multichain order/);
    assert.throws(()=>db.raw.prepare("UPDATE payment_orders SET transaction_hash=? WHERE id='legacy'").run("cd".repeat(32)),/transaction reserved by multichain order/);
    // Even if a bad operator disables foreign keys and deletes a member,
    // a payment must not be marked credited without updating an account.
    db.raw.prepare("INSERT INTO members(id,wallet_address,credits,daily_credits,role,created_at,updated_at) VALUES(?,?,?,?,?,?,?)").run("lost","0x2222222222222222222222222222222222222222",0,0,"member",now,now);
    insert.run("orphan","lost","ethereum","seed",20,"buyer","recipient","asset","4990000","9".repeat(64),now);
    db.raw.exec("PRAGMA foreign_keys=OFF");
    db.raw.prepare("DELETE FROM members WHERE id='lost'").run();
    assert.throws(()=>settle.run("ef".repeat(32),0,now,"orphan"),/credit member missing/);
    assert.equal(db.raw.prepare("SELECT status FROM multichain_orders_draft WHERE id='orphan'").get().status,"pending");
  } finally { db.raw.close(); }
});
