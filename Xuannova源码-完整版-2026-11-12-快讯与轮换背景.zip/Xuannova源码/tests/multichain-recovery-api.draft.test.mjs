import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync,readdirSync} from "node:fs";
import {openDatabase} from "../server/sqlite-db.ts";
import {handleCommerceApi,createSessionToken} from "../worker/commerce-api.ts";
import {submitRecoveryCandidate} from "../app/payment-recovery-buffer.draft.ts";

test("draft recovery API is disabled by default, same-origin, authenticated and order-owned",async()=>{
 const db=openDatabase(":memory:");try {
  const dir=new URL("../migrations/",import.meta.url);for(const f of readdirSync(dir).filter(x=>x.endsWith(".sql")).sort())db.raw.exec(readFileSync(new URL(f,dir),"utf8"));
  db.raw.exec(readFileSync(new URL("../db/drafts/multichain-orders.sql",import.meta.url),"utf8"));
  const now="2026-01-01T00:00:00Z";for(const id of ["one","two"])db.raw.prepare("INSERT INTO members(id,credits,role,created_at,updated_at) VALUES(?,?,?,?,?)").run(id,0,"member",now,now);
  db.raw.prepare("INSERT INTO multichain_orders_draft(id,member_id,chain,package_id,credits,buyer,recipient,settlement_asset,amount_units,order_reference,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)").run("order","one","tron","seed",20,"buyer","recipient","token","4990000","a".repeat(64),now);
  const secret="test-secret-that-is-longer-than-thirty-two-bytes",base={DB:db,SESSION_SECRET:secret,SITE_URL:"https://xuannova.test"},enabled={...base,MULTICHAIN_DRAFT_RECOVERY_ENABLED:"true"};
  const one=await createSessionToken({sub:"one",role:"member",email:"one@example.test"},secret),two=await createSessionToken({sub:"two",role:"member",email:"two@example.test"},secret);
  const request=(cookie,origin="https://xuannova.test",transactionId="ab".repeat(32))=>new Request("https://xuannova.test/api/draft/payment-attempts",{method:"POST",headers:{"content-type":"application/json",...(origin?{origin}:{}),...(cookie?{cookie:`xuanyuan_session=${cookie}`}:{})},body:JSON.stringify({orderId:"order",transactionId,memberId:"one"})});
  assert.equal((await handleCommerceApi(request(one),base)).status,503);
  assert.equal((await handleCommerceApi(request(null),enabled)).status,401);
  assert.equal((await handleCommerceApi(request(one,"https://evil.test"),enabled)).status,403);
  assert.equal((await handleCommerceApi(request(one,null),enabled)).status,403);
  assert.equal((await handleCommerceApi(request(two),enabled)).status,404);
  assert.equal((await handleCommerceApi(request(one,"https://xuannova.test","invalid"),enabled)).status,400);
  assert.deepEqual(await (await handleCommerceApi(request(one),enabled)).json(),{recorded:true});
  assert.deepEqual(await (await handleCommerceApi(request(one),enabled)).json(),{recorded:false});
  // Hash normalization must deduplicate 0x/case variants; only distinct
  // candidates count toward the limit and none may issue points by itself.
  assert.deepEqual(await (await handleCommerceApi(request(one,"https://xuannova.test",`0X${"AB".repeat(32)}`),enabled)).json(),{recorded:false});
  for(const byte of ["01","02","03","04"]){
   assert.deepEqual(await (await handleCommerceApi(request(one,"https://xuannova.test",byte.repeat(32)),enabled)).json(),{recorded:true});
  }
  const overLimit=await handleCommerceApi(request(one,"https://xuannova.test","05".repeat(32)),enabled);
  assert.notEqual(overLimit.status,200);
  assert.equal(db.raw.prepare("SELECT count(*) AS n FROM multichain_payment_attempts_draft WHERE order_id='order'").get().n,5);
  assert.deepEqual(await (await handleCommerceApi(request(one),enabled)).json(),{recorded:false});
  const fetcher=(path,init)=>handleCommerceApi(new Request(`https://xuannova.test${path}`,{...init,headers:{...init.headers,origin:"https://xuannova.test",cookie:`xuanyuan_session=${one}`}}),enabled);
  assert.deepEqual(await submitRecoveryCandidate({memberId:"one",orderId:"order",chain:"tron",transactionId:"ab".repeat(32),createdAt:"2026-01-01T00:00:00.000Z"},fetcher),{recorded:false});
  assert.equal(db.raw.prepare("SELECT credits FROM members WHERE id='one'").get().credits,0);
  assert.equal(db.raw.prepare("SELECT status FROM multichain_orders_draft WHERE id='order'").get().status,"pending");
 }finally{db.raw.close();}
});
