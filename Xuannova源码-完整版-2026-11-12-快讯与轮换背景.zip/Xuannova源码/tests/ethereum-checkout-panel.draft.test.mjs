import test from "node:test";
import assert from "node:assert/strict";
import React from "react";
import {renderToStaticMarkup} from "react-dom/server";
import {EthereumCheckoutPanelDraft} from "../app/ethereum-checkout-panel.draft.tsx";
test("draft panel renders all locales without initiating wallet or payment",()=>{
 let calls=0;const callbacks={connect:async()=>{calls++;},approve:async()=>"submitted",approvalStatus:async()=>"pending",pay:async()=>({hash:`0x${"ab".repeat(32)}`,recoveryRecorded:true}),status:async()=>"awaiting_payment"};
 for(const locale of ["en","zh-Hans","zh-Hant","ja","ko","vi","th"]) {
  const html=renderToStaticMarkup(React.createElement(EthereumCheckoutPanelDraft,{locale,packageId:"seed",callbacks}));
  assert.match(html,/ethereum-checkout-draft/);assert.match(html,/<button/);assert.doesNotMatch(html,/undefined/);
  assert.match(html,/4.99 USDC/);assert.match(html,/0x84F33708ab4b7DEFd9Be5EC50911797E34009caA/);
 }
 assert.equal(calls,0);
});
