import assert from "node:assert/strict";
import test from "node:test";

const { chartTermTip } = await import("../app/chart-terms.ts");
const guide = await import("../app/guide-content.ts");
const { PUBLIC_ROUTES, parseStudyPath } = await import("../app/study-navigation.ts");
const { toolkitItems } = await import("../app/study-suite.ts");
const locales = ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"];

test("every BaZi board row and Ten God has a tap-to-explain text in all seven languages", () => {
  const rows = ["Stem", "Stem element", "Branch", "Branch element", "Ten God", "Hidden stems", "Pillar role", "Day-stem relation", "Seasonal status", "NaYin", "Life stage", "Auxiliary star", "Pillar shen-sha", "Day master", "Month branch", "Element balance", "Chart time", "Ten-year study cycles", "Annual study cycle", "Luck cycles in depth", "Day-master strength"];
  const gods = ["比肩", "劫财", "食神", "伤官", "偏财", "正财", "七杀", "正官", "偏印", "正印"];
  for (const term of [...rows, ...gods]) for (const locale of locales) assert.ok(chartTermTip(term, locale)?.length > 10, `${term} ${locale}`);
  assert.equal(chartTermTip("Not a chart term", "en"), null);
});

test("guide, form help and how-to texts exist in all seven languages for every method and toolkit tool", () => {
  const routes = ["bazi", "detail", "ziwei", "qizheng", "compatibility", "hecan", "liuyao", "qimen", "daliuren", "meihua", "jinkoujue", "heluo", "tieban", "taiyi", "zhuzhai", "zeri", "wenshi", "mirror", "daily", "toolkit", ...toolkitItems.map((item) => `toolkit-${item.key}`)];
  for (const key of routes) for (const part of ["goodFor", "enter", "tip"]) for (const locale of locales) assert.ok(guide.howTo[key]?.[part]?.[locale], `${key}.${part}.${locale}`);
  for (const group of [guide.startSteps, guide.fieldHelp, guide.firstVisit, guide.howToLabels, guide.guideText]) for (const [name, value] of Object.entries(group)) for (const locale of locales) assert.ok(value[locale], `${name}.${locale}`);
  for (const item of guide.guideFaq) for (const locale of locales) assert.ok(item.q[locale] && item.a[locale]);
  assert.ok(!JSON.stringify(guide.guideText["zh-Hant"] ?? {}).includes("“"), "Traditional Chinese uses 「」 quotes");
});

test("the beginner guide is a public page in every language", () => {
  assert.ok(PUBLIC_ROUTES.includes("guide"));
  assert.equal(parseStudyPath("/ja/guide").route, "guide");
  assert.equal(parseStudyPath("/guide").route, "guide");
  assert.ok(PUBLIC_ROUTES.includes("almanac"));
  assert.equal(parseStudyPath("/th/almanac").route, "almanac");
});

test("every method and toolkit tool states the method it uses, in seven languages", async () => {
  const { methodNotes, methodNoteTitle } = await import("../app/method-notes.ts");
  const keys = ["bazi", "detail", "ziwei", "qizheng", "compatibility", "hecan", "liuyao", "qimen", "daliuren", "meihua", "jinkoujue", "heluo", "tieban", "taiyi", "zhuzhai", "zeri", "wenshi", "mirror", "daily", ...toolkitItems.map((item) => `toolkit-${item.key}`)];
  for (const locale of locales) assert.ok(methodNoteTitle[locale]);
  for (const key of keys) {
    assert.ok(methodNotes[key]?.length, key);
    for (const note of methodNotes[key]) for (const locale of locales) assert.ok(note[locale]?.length > 10, `${key} ${locale}`);
  }
});
