import test from "node:test";
import assert from "node:assert/strict";
import { keccak256, toBytes } from "viem";
import { inspectSolanaDirectFromRpc, inspectTronDirectFromRpc } from "../worker/direct-payment-rpc.draft.ts";

const token = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA", memo = "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr";
const sol = { signature: "A".repeat(88), buyer: "buyer", recipient: "owner", recipientTokenAccount: "ata", mint: "usdc", decimals: 6, amountUnits: 4990000n, orderReference: "a".repeat(64) };
const solBalance = (amount) => ({ accountIndex: 1, mint: sol.mint, owner: sol.recipient, programId: token, uiTokenAmount: { amount, decimals: 6 } });
const solTx = { meta: { err: null, preTokenBalances: [solBalance("0")], postTokenBalances: [solBalance("4990000")] }, transaction: { signatures: [sol.signature], message: { accountKeys: [{pubkey:sol.buyer,signer:true},{pubkey:sol.recipientTokenAccount,signer:false}], instructions: [{programId:token,parsed:{type:"transferChecked",info:{authority:sol.buyer,mint:sol.mint,destination:sol.recipientTokenAccount,tokenAmount:{amount:"4990000",decimals:6}}}},{programId:memo,parsed:sol.orderReference}] } } };
const solFetch = ({ genesis = "5eykt4UsFv8P8NJdTREpY1vzqKqZKvdpKuc147dw2N9d", status = "finalized", tx = solTx } = {}) => async (url, init) => {
  assert.equal(url, "https://api.mainnet-beta.solana.com");
  const body = JSON.parse(init.body);
  const result = body.method === "getGenesisHash" ? genesis : body.method === "getSignatureStatuses" ? {value:[{confirmationStatus:status,err:null}]} : tx;
  return Response.json({jsonrpc:"2.0",id:1,result});
};

test("Solana RPC inspection requires mainnet, finalized status and matching parsed transfer", async () => {
  assert.equal((await inspectSolanaDirectFromRpc(sol, solFetch())).instructionIndex, 0);
  await assert.rejects(inspectSolanaDirectFromRpc(sol, solFetch({genesis:"devnet"})), /WRONG_CHAIN/);
  await assert.rejects(inspectSolanaDirectFromRpc(sol, solFetch({status:"confirmed"})), /TRANSACTION_NOT_FINAL_SUCCESS/);
  await assert.rejects(inspectSolanaDirectFromRpc(sol, solFetch({tx:null})), /TRANSACTION_NOT_FOUND/);
  await assert.rejects(inspectSolanaDirectFromRpc(sol, async () => new Response("down",{status:503})), /CHAIN_RPC_UNAVAILABLE/);
});

const tron = { txId:"a".repeat(64), buyerHex:`41${"11".repeat(20)}`, recipientHex:`41${"22".repeat(20)}`, tokenHex:`41${"33".repeat(20)}`, amountUnits:4990000n, orderReference:"b".repeat(64) };
const topic = (hex) => `${"0".repeat(24)}${hex.slice(2)}`;
const body = {txID:tron.txId,raw_data:{data:tron.orderReference,contract:[{type:"TriggerSmartContract",parameter:{value:{owner_address:tron.buyerHex,contract_address:tron.tokenHex}}}]}};
const receipt = {id:tron.txId,receipt:{result:"SUCCESS"},log:[{address:tron.tokenHex.slice(2),topics:[keccak256(toBytes("Transfer(address,address,uint256)")).slice(2),topic(tron.buyerHex),topic(tron.recipientHex)],data:tron.amountUnits.toString(16).padStart(64,"0")}]};
test("TRON RPC inspection uses solidified endpoints and fails closed on a missing receipt", async () => {
  const calls=[];
  const mock = async (url) => { calls.push(url); return Response.json(url.endsWith("gettransactionbyid") ? body : receipt); };
  assert.equal((await inspectTronDirectFromRpc(tron,mock)).logIndex,0);
  assert.ok(calls.every((url) => url.startsWith("https://api.trongrid.io/walletsolidity/")));
  await assert.rejects(inspectTronDirectFromRpc(tron,async (url) => Response.json(url.endsWith("gettransactionbyid") ? body : {})), /TRANSACTION_NOT_FINAL_SUCCESS/);
});
