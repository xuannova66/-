import json, sys
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ref_bazi import full, G, Z
data = json.load(open(sys.argv[1]))
fields = {"ten": 0, "rel": 0, "nayin": 0, "stage": 0, "hidden": 0, "dayun_seq": 0, "dir": 0, "first": 0, "ln0": 0, "consistent_first": 0}
n = 0; examples = []
for r in data:
    if "pillars" not in r or not r["pillars"]: continue
    n += 1
    p = r["pillars"]; male = r["in"].endswith("yang"); y = int(r["in"][:4])
    e = full(p, male, None)
    ok = lambda a, b: a == b
    if r["ten"] == e["ten_god_stem"]: fields["ten"] += 1
    if r["rel"] == e["ten_god_stem"]: fields["rel"] += 1
    if r["nayin"] == e["nayin"]: fields["nayin"] += 1
    if r["stage"] == e["life_stage"]: fields["stage"] += 1
    if [sorted(h.replace(" · ", "")) for h in r["hidden"]] == [sorted(x) for x in e["hidden"]]: fields["hidden"] += 1
    if r["cycles"][:6] == e["dayun"][1][:6]: fields["dayun_seq"] += 1
    if (r["dir"] or "").startswith(e["dayun"][0]): fields["dir"] += 1
    if r["first"] == e["dayun"][1][0]: fields["first"] += 1
    if r["first"] == (r["cycles"] or [None])[0]: fields["consistent_first"] += 1
    if r["ln0"] == p[0]: fields["ln0"] += 1
    if len(examples) < 3:
        examples.append({"in": r["in"], "pillars": p, "site_nayin": r["nayin"], "ref_nayin": e["nayin"],
                         "site_ten": r["ten"], "ref_ten": e["ten_god_stem"], "site_dayun": r["cycles"][:4],
                         "ref_dayun": e["dayun"][1][:4], "site_first": r["first"], "site_ln0": r["ln0"]})
print("charts:", n)
for k, v in fields.items(): print(f"{k}: {v}/{n}")
print(json.dumps(examples, ensure_ascii=False, indent=1))
failed = [name for name, count in fields.items() if count != n]
if failed:
    print("FAILED fields:", ", ".join(failed), file=sys.stderr)
    sys.exit(1)
