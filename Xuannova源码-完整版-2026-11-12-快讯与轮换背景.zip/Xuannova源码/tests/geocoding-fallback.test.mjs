import test from "node:test";
import assert from "node:assert/strict";
const { handleGeocodingApi, normalizeNominatim } = await import(`${process.env.TS_ROOT}/worker/geocoding-api.ts`);

const london = { osm_id: 65606, osm_type: "relation", lat: "51.5074456", lon: "-0.1277653", name: "伦敦", addresstype: "city", class: "place", address: { state: "英格兰", country: "英国", country_code: "gb" } };

test("Nominatim answers are turned into the Open-Meteo shape", () => {
  const [place] = normalizeNominatim([london, { osm_id: 1, lat: "1", lon: "2", name: "Some shop", addresstype: "shop", class: "shop", address: { country: "X" } }]);
  assert.equal(place.name, "伦敦");
  assert.equal(place.country, "英国");
  assert.equal(place.country_code, "GB");
  assert.equal(place.admin1, "英格兰");
  assert.equal(place.feature_code, "PPLA");
  assert.ok(place.id > 9_000_000_000);
  assert.equal(normalizeNominatim([london, { osm_id: 1, lat: "1", lon: "2", name: "Some shop", addresstype: "shop", class: "shop", address: { country: "X" } }]).length, 1);
});

test("a Chinese name of an overseas city falls back to OpenStreetMap and is listed first", async () => {
  const calls = [];
  const fetchImpl = async (url) => {
    calls.push(String(url));
    if (String(url).includes("nominatim")) return new Response(JSON.stringify([london]), { status: 200 });
    // Open-Meteo finds only a same-named village elsewhere, plus London itself under its GeoNames id
    return new Response(JSON.stringify({ results: [
      { id: 1, name: "伦敦村", country: "中国", country_code: "CN", latitude: 30, longitude: 110 },
      { id: 2643743, name: "London", country: "United Kingdom", country_code: "GB", latitude: 51.50853, longitude: -0.12574 },
    ] }), { status: 200 });
  };
  const response = await handleGeocodingApi(new Request("https://x/api/geocode?q=%E4%BC%A6%E6%95%A6&locale=zh-Hans"), fetchImpl);
  const { results } = await response.json();
  assert.ok(calls.some((url) => url.includes("nominatim") && url.includes("accept-language=zh-CN")));
  assert.equal(results[0].name, "伦敦");
  assert.equal(results.filter((place) => place.country_code === "GB").length, 1, "London is not listed twice");
});
