import test from "node:test";
import assert from "node:assert/strict";
import { makeExactOutputQuote } from "../app/multichain-quote.ts";

const base = { outputAmount: "4.99", outputDecimals: 6, inputDecimals: 8, quotedInputUnits: 100000001n, slippageBps: 100, nowSeconds: 1000, quoteTtlSeconds: 120, transferFee: "none-verified" };

test("quotes a 6-decimal settlement from an 8-decimal input without rounding down the cap", () => {
  const result = makeExactOutputQuote(base);
  assert.equal(result.outputUnits, 4990000n);
  assert.equal(result.inputUnits, 100000001n);
  assert.equal(result.maxInputUnits, 101000002n);
  assert.equal(result.estimatedDisplay, "1.00000001");
  assert.equal(result.maximumDisplay, "1.01000002");
  assert.equal(result.expiresAt, 1120);
});

test("fails closed on unknown transfer tax, excess slippage, stale duration or invalid amounts", () => {
  for (const transferFee of ["unknown", "fee-on-transfer"]) assert.throws(() => makeExactOutputQuote({ ...base, transferFee }), /TOKEN_TRANSFER_FEE_UNSUPPORTED/);
  assert.throws(() => makeExactOutputQuote({ ...base, slippageBps: 101 }), /INVALID_SLIPPAGE/);
  assert.throws(() => makeExactOutputQuote({ ...base, quoteTtlSeconds: 121 }), /INVALID_QUOTE_EXPIRY/);
  assert.throws(() => makeExactOutputQuote({ ...base, quotedInputUnits: 0n }), /INVALID_INPUT_QUOTE/);
  assert.throws(() => makeExactOutputQuote({ ...base, outputAmount: "4.9999999" }), /ASSET_PRECISION_EXCEEDED/);
});
