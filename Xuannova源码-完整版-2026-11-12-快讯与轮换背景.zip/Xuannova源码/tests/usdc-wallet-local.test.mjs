import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { readFileSync, readdirSync } from "node:fs";
import { createPublicClient, createWalletClient, custom, parseEther, getAddress } from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { getUsdcCheckoutQuote, purchaseUsdcPackage } from "../app/wallet-connect.ts";
import { BSC_USDC_ASSETS, BSC_V2_ROUTER } from "../app/usdc-payment-quote.ts";
import { treasuryAddress, platformFeeRecipient } from "../worker/commerce-policy.ts";
import { verifyPurchaseReceipt } from "../worker/wallet-chain.ts";
import { handleCommerceApi, createSessionToken, syncPurchasesFromChain } from "../worker/commerce-api.ts";
import { openDatabase } from "../server/sqlite-db.ts";
if (!process.env.XUANNOVA_TEST_TOOLS) throw new Error("Set XUANNOVA_TEST_TOOLS to a directory containing solc and ganache");
const require = createRequire(`${process.env.XUANNOVA_TEST_TOOLS}/package.json`);
const solc = require("solc"), ganache = require("ganache");
const contract = readFileSync(new URL("../contracts/UsdcCheckoutPrototype.sol", import.meta.url), "utf8");
const mocks = `// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;
contract Token { mapping(address=>uint) public balanceOf; mapping(address=>mapping(address=>uint)) public allowance;
function mint(address a,uint v) external {balanceOf[a]+=v;}
function approve(address s,uint v) external returns(bool){allowance[msg.sender][s]=v;return true;}
function transfer(address to,uint v) external returns(bool){balanceOf[msg.sender]-=v;balanceOf[to]+=v;return true;}
function transferFrom(address f,address t,uint v) external returns(bool){allowance[f][msg.sender]-=v;balanceOf[f]-=v;balanceOf[t]+=v;return true;} }
interface T {function transfer(address,uint) external returns(bool);function transferFrom(address,address,uint) external returns(bool);}
interface IBatchToken { function approve(address,uint) external returns(bool); }
interface ICheckout { function buy(bytes32,address,uint,address[] calldata,uint) external payable; }
contract BatchBuyer {
 function run(address store,address token,bytes32 id,uint amount,uint deadline) external payable {
  require(msg.value == 140000000000000); IBatchToken(token).approve(store,amount*2);
  address[] memory path=new address[](0);
  ICheckout(store).buy{value:70000000000000}(id,token,amount,path,deadline);
  ICheckout(store).buy{value:70000000000000}(id,token,amount,path,deadline);
 }
}
contract Router {address public immutable WETH; constructor(address w){WETH=w;}
function getAmountsIn(uint out,address[] calldata p) external pure returns(uint[] memory a){a=new uint[](p.length);for(uint i;i<p.length;i++)a[i]=out;}
function swapTokensForExactTokens(uint out,uint m,address[] calldata p,address to,uint) external returns(uint[] memory a){require(m>=out);T(p[0]).transferFrom(msg.sender,address(this),out);T(p[p.length-1]).transfer(to,out);a=new uint[](p.length);for(uint i;i<p.length;i++)a[i]=out;}
function swapETHForExactTokens(uint out,address[] calldata p,address to,uint) external payable returns(uint[] memory a){require(msg.value>=out);T(p[p.length-1]).transfer(to,out);(bool ok,)=msg.sender.call{value:msg.value-out}("");require(ok);a=new uint[](p.length);for(uint i;i<p.length;i++)a[i]=out;} }
contract ReenterBuyer {
 address public immutable target; bool public attempted; bool public succeeded; bytes4 public reason;
 constructor(address t){target=t;}
 function run(bytes32 id,uint max,address[] calldata path,uint deadline) external payable {
  (bool ok,)=target.call{value:msg.value}(abi.encodeWithSignature("buy(bytes32,address,uint256,address[],uint256)",id,address(0),max,path,deadline)); require(ok);
 }
 receive() external payable {if(!attempted){attempted=true;address[] memory p=new address[](0);(bool ok,bytes memory result)=target.call(abi.encodeWithSignature("buy(bytes32,address,uint256,address[],uint256)",bytes32(0),address(0),1,p,block.timestamp));succeeded=ok;if(result.length>=4){bytes4 x;assembly{x:=mload(add(result,32))}reason=x;}}}
}`;
const compiled = JSON.parse(solc.compile(JSON.stringify({ language: "Solidity", sources: { "Checkout.sol": { content: contract }, "Mocks.sol": { content: mocks } }, settings: { optimizer: { enabled: true, runs: 200 }, outputSelection: { "*": { "*": ["abi", "evm.bytecode.object"] } } } })));
assert.deepEqual((compiled.errors ?? []).filter((item) => item.severity === "error"), []);

test("wallet quote, four payments, configured recipient and on-chain buyer through real local EVM", async () => {
 const provider = ganache.provider({ logging: { quiet: true }, chain: { chainId: 56, hardfork: "shanghai" }, miner: { instamine: "eager" } });
 const accounts = await provider.request({ method: "eth_accounts", params: [] });
 const account = privateKeyToAccount(provider.getInitialAccounts()[accounts[0].toLowerCase()].secretKey);
 const pub = createPublicClient({ transport: custom(provider), pollingInterval: 50 });
 const wallet = createWalletClient({ account, transport: custom(provider) });
 const deploy = async (file, name, args = []) => { const artifact = compiled.contracts[file][name]; const hash = await wallet.deployContract({ abi: artifact.abi, bytecode: `0x${artifact.evm.bytecode.object}`, args, chain: null }); return { address: (await pub.waitForTransactionReceipt({ hash })).contractAddress, abi: artifact.abi }; };
 const tx = async (contract, name, args = []) => { const hash = await wallet.writeContract({ address: contract.address, abi: contract.abi, functionName: name, args, chain: null }); return pub.waitForTransactionReceipt({ hash }); };
 const tokenSource = await deploy("Mocks.sol", "Token");
 const tokenCode = await pub.getCode({ address: tokenSource.address });
 for (const address of [BSC_USDC_ASSETS.USDC, BSC_USDC_ASSETS.USDT, BSC_USDC_ASSETS.ASTER]) await provider.request({ method: "evm_setAccountCode", params: [address, tokenCode] });
 const token = (address) => ({ address, abi: tokenSource.abi });
 const stable = token(BSC_USDC_ASSETS.USDC), usdt = token(BSC_USDC_ASSETS.USDT), aster = token(BSC_USDC_ASSETS.ASTER);
 const routerSource = await deploy("Mocks.sol", "Router", [BSC_USDC_ASSETS.WBNB]);
 await provider.request({ method: "evm_setAccountCode", params: [BSC_V2_ROUTER, await pub.getCode({ address: routerSource.address })] });
 const fee = 70000000000000n;
 const store = await deploy("Checkout.sol", "UsdcCheckoutPrototype", [stable.address, usdt.address, aster.address, BSC_V2_ROUTER, treasuryAddress, platformFeeRecipient, fee]);
 await tx(stable, "mint", [BSC_V2_ROUTER, parseEther("100")]);
 for (const asset of [stable, usdt, aster]) await tx(asset, "mint", [account.address, parseEther("100")]);
 const config = { chainId: 56, chainHexId: "0x38", chainName: "BNB Smart Chain", nativeSymbol: "BNB", rpcUrls: [], explorerUrl: "https://bscscan.com", testnet: false, usdtAddress: usdt.address, contractAddress: null, usdcCheckoutAddress: store.address, platformFeeWei: fee.toString(), confirmations: 1, enabled: true };
 const db = openDatabase(":memory:");
 const migrationDir = new URL("../migrations/", import.meta.url);
 for (const file of readdirSync(migrationDir).filter((item) => item.endsWith(".sql")).sort()) db.raw.exec(readFileSync(new URL(file, migrationDir), "utf8"));
 db.raw.prepare("INSERT INTO members (id,wallet_address,credits,role,created_at,updated_at) VALUES (?,?,?,?,?,?)").run("buyer", account.address, 0, "member", new Date().toISOString(), new Date().toISOString());
 const secret = "local-test-secret-that-is-at-least-thirty-two-bytes";
 const session = await createSessionToken({ sub: "buyer", wallet: account.address, role: "member" }, secret);
 const apiEnv = { DB: db, SESSION_SECRET: secret, CREDIT_STORE_ADDRESS: "0x1111111111111111111111111111111111111111", USDC_CHECKOUT_ADDRESS: store.address, BSC_RPC_URLS: "https://local.invalid" };
 const balance = () => pub.readContract({ address: stable.address, abi: stable.abi, functionName: "balanceOf", args: [treasuryAddress] });
 for (const paymentToken of ["BNB", "USDC", "USDT", "ASTER"]) {
   const quote = await getUsdcCheckoutQuote({ provider, config, packageId: "seed", token: paymentToken });
   const before = await balance(); const stages = []; let pending;
   let hash;
   try { hash = await purchaseUsdcPackage({ provider, address: account.address, packageId: "seed", config, quote, onStage: (stage, txHash) => { stages.push(stage); if (txHash) { pending = txHash; assert.match(txHash, /^0x[0-9a-f]{64}$/i); } } }); }
   catch (error) { if (pending) { const receipt = await pub.getTransactionReceipt({ hash: pending }); const trace = await provider.request({ method: "debug_traceTransaction", params: [pending, {}] }); console.error("failed", paymentToken, "gas", receipt.gasUsed.toString(), "trace", trace.returnValue, "last", trace.structLogs.slice(-3).map((step) => step.op)); } throw error; }
   const receipt = await pub.getTransactionReceipt({ hash });
   assert.equal(receipt.status, "success"); assert.equal((await balance()) - before, parseEther("4.99"));
   const log = receipt.logs.find((item) => getAddress(item.address) === getAddress(store.address));
   assert.equal(`0x${log.topics[1].slice(-40)}`.toLowerCase(), account.address.toLowerCase());
   assert.ok(stages.includes("paying") && stages.includes("confirming"));
   await provider.request({ method: "evm_mine", params: [] }); await provider.request({ method: "evm_mine", params: [] });
   const priorFetch = globalThis.fetch;
   try {
     globalThis.fetch = async (_url, init) => {
       const input = JSON.parse(init.body); const calls = Array.isArray(input) ? input : [input];
       const results = await Promise.all(calls.map(async (call) => ({ jsonrpc: "2.0", id: call.id, result: await provider.request({ method: call.method, params: call.params ?? [] }) })));
       return new Response(JSON.stringify(Array.isArray(input) ? results : results[0]), { headers: { "content-type": "application/json" } });
     };
     const checked = await verifyPurchaseReceipt({ transactionHash: hash, expectedBuyer: account.address, contractAddress: getAddress(store.address), rpcUrls: ["https://local.invalid"], minimumConfirmations: 1 });
     assert.equal(checked.ok, true, `backend verifies the ${paymentToken} payment`);
     assert.equal(checked.purchase.credits, 20);
     const wrongBuyer = await verifyPurchaseReceipt({ transactionHash: hash, expectedBuyer: getAddress(accounts[1]), contractAddress: getAddress(store.address), rpcUrls: ["https://local.invalid"], minimumConfirmations: 1 });
     assert.equal(wrongBuyer.ok, false); assert.equal(wrongBuyer.reason, "WRONG_BUYER");
     const makeRequest = () => new Request("https://xuannova.test/api/orders", { method: "POST", headers: { origin: "https://xuannova.test", cookie: `xuanyuan_session=${session}`, "content-type": "application/json" }, body: JSON.stringify({ transactionHash: hash, packageId: "seed", checkout: "usdc" }) });
     const saved = await handleCommerceApi(makeRequest(), apiEnv); assert.equal(saved.status, 201); assert.equal((await saved.json()).order.settlementCurrency, "USDC");
     const replay = await handleCommerceApi(makeRequest(), apiEnv); assert.equal(replay.status, 200); assert.equal((await replay.json()).duplicate, true);
   } finally { globalThis.fetch = priorFetch; }
 }
 const attacker = await deploy("Mocks.sol", "ReenterBuyer", [store.address]);
 const saleCount = await pub.readContract({ address: store.address, abi: store.abi, functionName: "totalSales" });
 const attackHash = await wallet.writeContract({ address: attacker.address, abi: attacker.abi, functionName: "run", args: [(await import("viem")).keccak256((await import("viem")).toBytes("seed")), parseEther("6"), [BSC_USDC_ASSETS.WBNB, stable.address], BigInt(Math.floor(Date.now()/1000)+120)], value: parseEther("6") + fee, gas: 2000000n, chain: null });
 assert.equal((await pub.waitForTransactionReceipt({hash: attackHash})).status, "success");
 assert.equal(await pub.readContract({address: attacker.address, abi: attacker.abi, functionName: "attempted"}), true);
 assert.equal(await pub.readContract({address: attacker.address, abi: attacker.abi, functionName: "succeeded"}), false);
 assert.equal(await pub.readContract({address: attacker.address, abi: attacker.abi, functionName: "reason"}), "0xed3ba6a6", "reentrancy guard explicitly rejected the callback");
 assert.equal(await pub.readContract({address: store.address, abi: store.abi, functionName: "totalSales"}), saleCount + 1n);
 // Simulate a customer closing the browser after payment, without POSTing an order.
 const offlineQuote = await getUsdcCheckoutQuote({ provider, config, packageId: "seed", token: "USDC" });
 await purchaseUsdcPackage({ provider, address: account.address, packageId: "seed", config, quote: offlineQuote });
 await provider.request({ method: "evm_mine", params: [] }); await provider.request({ method: "evm_mine", params: [] }); await provider.request({ method: "evm_mine", params: [] });
 const fetchBeforeSync = globalThis.fetch;
 try {
   globalThis.fetch = async (_url, init) => {
     const input = JSON.parse(init.body); const calls = Array.isArray(input) ? input : [input];
     const results = await Promise.all(calls.map(async (call) => ({ jsonrpc: "2.0", id: call.id, result: await provider.request({ method: call.method, params: call.params ?? [] }) })));
     return new Response(JSON.stringify(Array.isArray(input) ? results : results[0]), { headers: { "content-type": "application/json" } });
   };
   const first = await syncPurchasesFromChain(apiEnv, "usdc"); assert.equal(first.credited, 1, "watcher credits the unreported purchase");
   const again = await syncPurchasesFromChain(apiEnv, "usdc"); assert.equal(again.credited, 0, "watcher cannot duplicate credits");
   assert.ok(db.raw.prepare("SELECT value FROM app_settings WHERE key = ?").get(`chain_sync_usdc_${store.address.toLowerCase()}`));
   assert.equal(db.raw.prepare("SELECT value FROM app_settings WHERE key = ?").get("chain_sync_last_block"), undefined, "new store keeps an independent cursor");
 } finally { globalThis.fetch = fetchBeforeSync; }
 // A confirmed purchase must remain retryable if its wallet is not linked yet.
 const unlinkedAccount = privateKeyToAccount(provider.getInitialAccounts()[accounts[1].toLowerCase()].secretKey);
 const unlinkedWallet = createWalletClient({ account: unlinkedAccount, transport: custom(provider) });
 await tx(stable, "mint", [unlinkedAccount.address, parseEther("10")]);
 await unlinkedWallet.writeContract({ address: stable.address, abi: stable.abi, functionName: "approve", args: [store.address, parseEther("4.99")], chain: null });
 const unlinkedHash = await unlinkedWallet.writeContract({ address: store.address, abi: store.abi, functionName: "buy", args: [(await import("viem")).keccak256((await import("viem")).toBytes("seed")), stable.address, parseEther("4.99"), [], BigInt(Math.floor(Date.now()/1000)+120)], value: fee, gas: 1000000n, chain: null });
 await pub.waitForTransactionReceipt({ hash: unlinkedHash });
 for (let i = 0; i < 3; i++) await provider.request({ method: "evm_mine", params: [] });
 const fetchBeforeUnlinked = globalThis.fetch;
 try {
   globalThis.fetch = async (_url, init) => { const input = JSON.parse(init.body); const calls = Array.isArray(input) ? input : [input]; const results = await Promise.all(calls.map(async (call) => ({ jsonrpc: "2.0", id: call.id, result: await provider.request({ method: call.method, params: call.params ?? [] }) }))); return new Response(JSON.stringify(Array.isArray(input) ? results : results[0]), { headers: { "content-type": "application/json" } }); };
   await syncPurchasesFromChain(apiEnv, "usdc");
   assert.equal(db.raw.prepare("SELECT count(*) AS count FROM unmatched_chain_purchases WHERE transaction_hash = ?").get(unlinkedHash).count, 1);
   db.raw.prepare("INSERT INTO members (id,wallet_address,credits,role,created_at,updated_at) VALUES (?,?,?,?,?,?)").run("late-buyer", unlinkedAccount.address, 0, "member", new Date().toISOString(), new Date().toISOString());
   await syncPurchasesFromChain(apiEnv, "usdc");
   await syncPurchasesFromChain(apiEnv, "usdc");
   assert.equal(db.raw.prepare("SELECT credits FROM members WHERE id = ?").get("late-buyer").credits, 20);
   assert.equal(db.raw.prepare("SELECT count(*) AS count FROM unmatched_chain_purchases WHERE transaction_hash = ?").get(unlinkedHash).count, 0);
 } finally { globalThis.fetch = fetchBeforeUnlinked; }
 // A smart wallet may make two purchases in one transaction; both events
 // must issue points exactly once despite sharing the same transaction hash.
 const batchBuyer = await deploy("Mocks.sol", "BatchBuyer");
 await tx(stable, "mint", [batchBuyer.address, parseEther("10")]);
 db.raw.prepare("INSERT INTO members (id,wallet_address,credits,role,created_at,updated_at) VALUES (?,?,?,?,?,?)").run("batch-buyer", getAddress(batchBuyer.address), 0, "member", new Date().toISOString(), new Date().toISOString());
 const batchHash = await wallet.writeContract({ address: batchBuyer.address, abi: batchBuyer.abi, functionName: "run", args: [store.address, stable.address, (await import("viem")).keccak256((await import("viem")).toBytes("seed")), parseEther("4.99"), BigInt(Math.floor(Date.now()/1000)+120)], value: fee * 2n, gas: 2000000n, chain: null });
 assert.equal((await pub.waitForTransactionReceipt({hash: batchHash})).status, "success");
 for (let i = 0; i < 3; i++) await provider.request({ method: "evm_mine", params: [] });
 const fetchBeforeBatch = globalThis.fetch;
 try {
   globalThis.fetch = async (_url, init) => { const input = JSON.parse(init.body); const calls = Array.isArray(input) ? input : [input]; const results = await Promise.all(calls.map(async (call) => ({ jsonrpc: "2.0", id: call.id, result: await provider.request({ method: call.method, params: call.params ?? [] }) }))); return new Response(JSON.stringify(Array.isArray(input) ? results : results[0]), { headers: { "content-type": "application/json" } }); };
   await syncPurchasesFromChain(apiEnv, "usdc");
   await syncPurchasesFromChain(apiEnv, "usdc");
   assert.equal(db.raw.prepare("SELECT credits FROM members WHERE id = ?").get("batch-buyer").credits, 40);
   assert.equal(db.raw.prepare("SELECT count(*) AS count FROM payment_orders WHERE transaction_hash = ?").get(batchHash).count, 2);
 } finally { globalThis.fetch = fetchBeforeBatch; }
 const usdcQuote = await getUsdcCheckoutQuote({ provider, config, packageId: "seed", token: "USDC" });
 const beforePause = await balance();
 await tx(store, "setPaused", [true]);
 await assert.rejects(purchaseUsdcPackage({ provider, address: account.address, packageId: "seed", config, quote: usdcQuote }));
 assert.equal(await balance(), beforePause, "paused checkout never transfers money");
 await assert.rejects(pub.simulateContract({ account: accounts[1], address: store.address, abi: store.abi, functionName: "setPaused", args: [false] }), "only owner can unpause");
 await tx(store, "setPaused", [false]);
 const invalidConfig = { ...config, platformFeeWei: "1" };
 await assert.rejects(purchaseUsdcPackage({ provider, address: account.address, packageId: "seed", config: invalidConfig, quote: usdcQuote }), /configuration mismatch/);
 assert.equal(await balance(), beforePause);
 assert.equal(db.raw.prepare("SELECT credits FROM members WHERE id = ?").get("buyer").credits, 100, "five purchases each credit exactly once");
 assert.equal(db.raw.prepare("SELECT count(*) AS count FROM payment_orders WHERE settlement_currency = 'USDC'").get().count, 8);
 db.raw.close();
 await provider.disconnect();
});
