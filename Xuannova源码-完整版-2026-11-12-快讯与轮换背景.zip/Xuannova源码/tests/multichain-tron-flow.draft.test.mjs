import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync,readdirSync} from "node:fs";
import {keccak256,toBytes} from "viem";
import {openDatabase} from "../server/sqlite-db.ts";
import {handleCommerceApi,createSessionToken} from "../worker/commerce-api.ts";
import {tronAddressHex} from "../worker/wallet-link-auth.draft.ts";
import {runMultichainRecoveryDraft} from "../worker/multichain-recovery-runner.draft.ts";
import {saveRecoveryCandidate,flushRecoveryCandidates,submitRecoveryCandidate} from "../app/payment-recovery-buffer.draft.ts";

test("TRON draft API to recovery verifies receipt before crediting, once, after an outage",async()=>{
 const db=openDatabase(":memory:");try {
  const dir=new URL("../migrations/",import.meta.url);for(const f of readdirSync(dir).filter(x=>x.endsWith(".sql")).sort())db.raw.exec(readFileSync(new URL(f,dir),"utf8"));
  db.raw.exec(readFileSync(new URL("../db/drafts/multichain-orders.sql",import.meta.url),"utf8"));
  const now="2026-01-01T00:00:00.000Z",buyer="TNUC9Qb1rRpS5CbWLmNMxXBjyFoydXjWFR",txId="ab".repeat(32),secret="test-secret-that-is-longer-than-thirty-two-bytes";
  db.raw.prepare("INSERT INTO members(id,credits,role,created_at,updated_at) VALUES(?,?,?,?,?)").run("member1",0,"member",now,now);
  db.raw.prepare("INSERT INTO member_wallet_links_v2(chain,address,member_id,linked_at) VALUES(?,?,?,?)").run("tron",buyer,"member1",1);
  const env={DB:db,SESSION_SECRET:secret,SITE_URL:"https://xuannova.test",MULTICHAIN_DRAFT_ORDERS_ENABLED:"true",MULTICHAIN_DRAFT_RECOVERY_ENABLED:"true"};
  const session=await createSessionToken({sub:"member1",role:"member",email:"member1@example.test"},secret);
  const api=async(path,init={})=>handleCommerceApi(new Request(`https://xuannova.test${path}`,{...init,headers:{...init.headers,origin:"https://xuannova.test",cookie:`xuanyuan_session=${session}`}}),env);
  const response=await api("/api/draft/multichain-orders",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({chain:"tron",buyer,packageId:"seed"})});
  assert.equal(response.status,200);const order=await response.json();
  const values=new Map(),storage={getItem:k=>values.get(k)??null,setItem:(k,v)=>values.set(k,v),removeItem:k=>values.delete(k)};
  saveRecoveryCandidate(storage,{memberId:"member1",orderId:order.id,chain:"tron",transactionId:txId,createdAt:now});
  assert.deepEqual(await flushRecoveryCandidates(storage,"member1",entry=>submitRecoveryCandidate(entry,async()=>{throw Error("offline");})),{sent:0,pending:1});
  assert.deepEqual(await flushRecoveryCandidates(storage,"member1",entry=>submitRecoveryCandidate(entry,api)),{sent:1,pending:0});
  const status=async()=>await (await api(`/api/draft/multichain-orders/status?id=${order.id}`)).json();
  assert.equal((await status()).status,"submitted");
  const owner=tronAddressHex(buyer),recipient=tronAddressHex(order.recipient),token=tronAddressHex(order.token),topic=hex=>`${"0".repeat(24)}${hex.slice(2)}`;
  const body={txID:txId,raw_data:{data:order.reference,contract:[{type:"TriggerSmartContract",parameter:{value:{owner_address:owner,contract_address:token}}}]}};
  const receipt={id:txId,receipt:{result:"SUCCESS"},log:[{address:token.slice(2),topics:[keccak256(toBytes("Transfer(address,address,uint256)")).slice(2),topic(owner),topic(recipient)],data:BigInt(order.amountUnits).toString(16).padStart(64,"0")}]};
  const first=await runMultichainRecoveryDraft(db,{now,limit:10,tron:{fetcher:async()=>new Response("down",{status:503})}});
  assert.equal(first.pending,1);assert.equal(db.raw.prepare("SELECT credits FROM members WHERE id='member1'").get().credits,0);
  const fetcher=async url=>Response.json(url.endsWith("gettransactionbyid")?body:receipt);
  const recovered=await runMultichainRecoveryDraft(db,{now:"2026-01-01T00:00:31.000Z",limit:10,tron:{fetcher}});
  assert.equal(recovered.credited,1);assert.equal((await status()).status,"credited");
  assert.equal(db.raw.prepare("SELECT credits FROM members WHERE id='member1'").get().credits,20);
  assert.equal(db.raw.prepare("SELECT count(*) AS n FROM credit_ledger WHERE id=?").get(`multichain-draft:${order.id}`).n,1);
  assert.equal((await runMultichainRecoveryDraft(db,{now:"2026-01-01T00:01:02.000Z",limit:10,tron:{fetcher}})).checked,0);
 } finally {db.raw.close();}
});
