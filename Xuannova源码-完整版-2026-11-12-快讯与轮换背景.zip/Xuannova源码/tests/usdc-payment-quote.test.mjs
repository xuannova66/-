import test from "node:test";
import assert from "node:assert/strict";
import { quoteUsdcPayment, BSC_USDC_ASSETS } from "../app/usdc-payment-quote.ts";
import { isAddress } from "viem";

const base = { amountOut: 499n, chainId: 56, nowSeconds: 1000, slippageBps: 100 };
test("selects the lowest valid route and rounds max input upward", async () => {
  const quote = await quoteUsdcPayment({ ...base, token: "ASTER", getAmountsIn: async (amount, path) => path.length === 2 ? [1001n, amount] : path[1] === BSC_USDC_ASSETS.WBNB ? [900n, 800n, amount] : [1100n, 800n, amount] });
  assert.equal(quote.estimatedInput, 900n); assert.equal(quote.maxInput, 909n); assert.equal(quote.deadline, 1120n); assert.equal(quote.path.length, 3);
  assert.ok(quote.path.every((address) => isAddress(address)), "every path address uses a valid standard checksum");
});
test("USDC exact payment never calls a swap quote", async () => {
  const quote = await quoteUsdcPayment({ ...base, token: "USDC", getAmountsIn: async () => { throw Error("must not call"); } });
  assert.equal(quote.maxInput, 499n); assert.deepEqual(quote.path, []);
});
test("fails closed for no route, invalid output, wrong network and excessive slippage", async () => {
  await assert.rejects(quoteUsdcPayment({ ...base, token: "BNB", getAmountsIn: async () => { throw Error("no pool"); } }), /NO_USDC_ROUTE/);
  await assert.rejects(quoteUsdcPayment({ ...base, token: "USDT", getAmountsIn: async () => [1n, 0n] }), /NO_USDC_ROUTE/);
  await assert.rejects(quoteUsdcPayment({ ...base, token: "USDT", chainId: 97, getAmountsIn: async () => [] }), /INVALID_QUOTE_PARAMETERS/);
  await assert.rejects(quoteUsdcPayment({ ...base, token: "USDT", slippageBps: 101, getAmountsIn: async () => [] }), /INVALID_QUOTE_PARAMETERS/);
});
test("extra coins: a thin pool (big price impact) is refused, a deep one is quoted with its impact", async () => {
  const amountOut = 39_900_000_000_000_000_000n;
  // Deep pool: the full amount costs the same per USDC as a 1/50 trade.
  const deep = await quoteUsdcPayment({ ...base, amountOut, token: "DOGE", getAmountsIn: async (out, path) => path.map((_, i) => (i === path.length - 1 ? out : out * 14n)) });
  assert.equal(deep.impactBps, 0);
  // Thin pool: the full amount costs 8% more per USDC.
  const thin = async (out, path) => path.map((_, i) => (i === path.length - 1 ? out : out === amountOut ? (out * 108n) / 100n : out));
  await assert.rejects(quoteUsdcPayment({ ...base, amountOut, token: "AAVE", getAmountsIn: thin }), /PRICE_IMPACT_TOO_HIGH/);
  await assert.rejects(quoteUsdcPayment({ ...base, amountOut, token: "AAVE", getAmountsIn: async (out, path) => { if(out !== amountOut) throw Error("offline"); return path.map((_,i)=>i===path.length-1?out:out); } }), /PRICE_IMPACT_UNAVAILABLE/);
  // The original four coins are not subject to the check.
  const aster = await quoteUsdcPayment({ ...base, amountOut, token: "ASTER", getAmountsIn: thin });
  assert.equal(aster.impactBps, undefined);
  await assert.rejects(quoteUsdcPayment({ ...base, token: "WBNB", getAmountsIn: async () => [] }), /UNSUPPORTED_TOKEN/);
});
