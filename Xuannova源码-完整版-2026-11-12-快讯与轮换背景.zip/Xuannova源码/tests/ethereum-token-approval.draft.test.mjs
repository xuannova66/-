import test from "node:test";
import assert from "node:assert/strict";
import {decodeFunctionData,parseAbi} from "viem";
import {requestEthereumDraftApproval} from "../app/ethereum-token-approval.draft.ts";
const buyer="0x1111111111111111111111111111111111111111",token="0x2222222222222222222222222222222222222222",checkout="0x3333333333333333333333333333333333333333",hash=`0x${"ab".repeat(32)}`;
function wallet(allowance=0n){const calls=[];return {calls,request:async x=>{calls.push(x);if(x.method==="eth_accounts")return [buyer];if(x.method==="eth_chainId")return "0x1";if(x.method==="eth_call")return `0x${allowance.toString(16).padStart(64,"0")}`;if(x.method==="eth_estimateGas")return "0xc350";if(x.method==="eth_sendTransaction")return hash;throw Error("unexpected");}};}
const base={session:{network:"ethereum",chainId:"0x1",address:buyer},token,checkout,allowedTokens:[token],amount:4990000n,onHash:async()=>{}};
test("requests only the exact authorized amount and records the submitted hash",async()=>{
 const provider=wallet(),result=await requestEthereumDraftApproval({...base,provider});assert.equal(result.status,"submitted");assert.equal(result.hash,hash);
 const sent=provider.calls.find(x=>x.method==="eth_sendTransaction").params[0];
 const decoded=decodeFunctionData({abi:parseAbi(["function approve(address spender,uint256 amount) returns(bool)"]),data:sent.data});assert.deepEqual(decoded.args,[checkout,4990000n]);
});
test("does not submit if allowance is enough, nonzero but insufficient, or asset unapproved",async()=>{
 const sufficient=wallet(4990000n);assert.equal((await requestEthereumDraftApproval({...base,provider:sufficient})).status,"already_sufficient");assert.ok(!sufficient.calls.some(x=>x.method==="eth_sendTransaction"));
 const nonzero=wallet(1n);await assert.rejects(requestEthereumDraftApproval({...base,provider:nonzero}),/NONZERO_ALLOWANCE_REQUIRES_REVIEW/);assert.ok(!nonzero.calls.some(x=>x.method==="eth_sendTransaction"));
 await assert.rejects(requestEthereumDraftApproval({...base,provider:wallet(),allowedTokens:[]}),/INVALID_APPROVAL_REQUEST/);
});
test("does not accept an old account's allowance after wallet or network changes",async()=>{
 for(const changed of ["account","chain"]){
  let read=false;const calls=[];
  const provider={request:async x=>{calls.push(x.method);
   if(x.method==="eth_chainId")return read&&changed==="chain"?"0x38":"0x1";
   if(x.method==="eth_accounts")return read&&changed==="account"?[checkout]:[buyer];
   if(x.method==="eth_call"){read=true;return `0x${(4990000n).toString(16).padStart(64,"0")}`;}
   throw Error("unexpected transaction");
  }};
  await assert.rejects(requestEthereumDraftApproval({...base,provider}),/WALLET_(NETWORK|ACCOUNT)_CHANGED/);
  assert.ok(!calls.includes("eth_sendTransaction"));
 }
});
