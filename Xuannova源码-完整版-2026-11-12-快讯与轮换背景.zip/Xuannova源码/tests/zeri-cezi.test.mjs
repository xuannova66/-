// 专业择日 rules and 测字 character analysis (cache, limit, parsing).
import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import test from "node:test";

const root = process.env.TS_ROOT ?? process.cwd();
const { selectDays, favourableElements } = await import(`${root}/app/metaphysics/zeri.ts`);
const { createCompleteChart } = await import(`${root}/app/chart-model.ts`);
const { openDatabase } = await import(`${root}/server/sqlite-db.ts`);
const { handleCommerceApi } = await import(`${root}/worker/commerce-api.ts`);
const cezi = await import(`${root}/worker/cezi.ts`);

test("date selection leaves out clashing and taboo days and ranks the rest", () => {
  const pillars = ["庚午", "辛巳", "丙申", "己亥"];
  const result = selectDays({ purpose: "wedding", pillars, start: "2026-11-07", days: 90 });
  assert.equal(result.checked, 90);
  assert.ok(result.chosen.length > 0);
  for (const day of result.chosen) {
    assert.notEqual(day.dayGanZhi.charAt(1), "子", "子 days clash a 午 year branch");
    assert.notEqual(day.dayGanZhi.charAt(1), "寅", "寅 days clash a 申 day branch");
    assert.notEqual(day.officer, "破");
    assert.ok(![3, 7, 13, 18, 22, 27].includes(day.lunarDay), "San Niang days are left out for weddings");
    assert.deepEqual(day.excluded, []);
  }
  for (let i = 1; i < result.top.length; i += 1) assert.ok(result.top[i - 1].score >= result.top[i].score);
  assert.ok(result.counts["personal-year"] > 0);
  assert.deepEqual(favourableElements(pillars).elements, ["火", "木"]);
});

test("date selection chart builds for every purpose", () => {
  for (const purpose of ["wedding", "engagement", "move", "opening", "contract", "travel", "renovation", "prayer"]) {
    const chart = createCompleteChart({ birthDate: "1990-05-20", birthTime: "21:40", calendar: "solar", focus: "", name: "", companionName: "", module: "zeri", version: 1, zeriPurpose: purpose, zeriStart: "2026-11-07", zeriDays: 60 });
    assert.ok(chart.board.cells.length >= 1, purpose);
    assert.equal(chart.sections.find((section) => section.id === "zeri-frame").items[0].value.length > 0, true);
  }
});

const ORIGIN = "https://xuannova.test";
let calls = 0;
const realFetch = globalThis.fetch;
globalThis.fetch = async (url, init) => {
  if (String(url).startsWith("https://api.deepseek.com")) {
    calls += 1;
    const body = JSON.parse(init.body);
    assert.match(body.messages[0].content, /Kangxi/);
    return new Response(JSON.stringify({ choices: [{ message: { content: JSON.stringify({ character: "好", traditional: "好", strokes: 6, structure: "left-right", parts: [{ text: "女", strokes: 3 }, { text: "子", strokes: 3 }], radical: "女", radicalElement: "土", components: ["女", "子"], meaning: "good" }) } }] }), { status: 200 });
  }
  return realFetch(url, init);
};
function freshEnv() {
  const db = openDatabase(":memory:");
  for (const file of readdirSync(new URL("../migrations/", import.meta.url)).filter((name) => name.endsWith(".sql")).sort()) db.raw.exec(readFileSync(new URL(`../migrations/${file}`, import.meta.url), "utf8"));
  return { DB: db, SESSION_SECRET: "test-session-signing-key-that-is-long-enough", DEEPSEEK_API_KEY: "test-key" };
}
const post = (env, body, device = "device-cezi-0000000001") => handleCommerceApi(new Request(`${ORIGIN}/api/cezi/analyse`, { method: "POST", headers: { origin: ORIGIN, "content-type": "application/json", cookie: `xn_device=${device}` }, body: JSON.stringify(body) }), env);

test("character analysis is validated, cached per character and language, and limited for visitors", async () => {
  const env = freshEnv();
  calls = 0;
  assert.equal((await post(env, { character: "ab" })).status, 400);
  assert.equal((await post(env, { character: "好好" })).status, 400);
  const first = await (await post(env, { character: "好", locale: "en" })).json();
  assert.equal(first.analysis.strokes, 6);
  assert.equal(first.cached, false);
  const second = await (await post(env, { character: "好", locale: "en" })).json();
  assert.equal(second.cached, true);
  assert.equal(calls, 1, "the cached analysis is reused");
  const chars = "一二三四五六七八九";
  for (const char of chars) await post(env, { character: char, locale: "en" });
  const limited = await post(env, { character: "十", locale: "en" });
  assert.equal(limited.status, 429);
});

test("character analysis parsing keeps sane values only", () => {
  assert.throws(() => cezi.parseCeziResponse(JSON.stringify({ strokes: 0 }), "好"));
  const parsed = cezi.parseCeziResponse(JSON.stringify({ strokes: 12, structure: "weird", parts: [{ text: "氵", strokes: 4 }, { text: "x", strokes: 99 }], radicalElement: "风", components: ["氵", "每"] }), "海");
  assert.equal(parsed.structure, "other");
  assert.deepEqual(parsed.parts, [{ text: "氵", strokes: 4 }]);
  assert.equal(parsed.radicalElement, "");
  assert.equal(cezi.singleHanCharacter(" 福 "), "福");
  assert.equal(cezi.singleHanCharacter("A"), null);
});
