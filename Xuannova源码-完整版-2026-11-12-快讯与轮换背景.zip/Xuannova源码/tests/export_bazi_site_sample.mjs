import { readFile, writeFile } from "node:fs/promises";
import { createCompleteChart } from "../app/chart-model.ts";
import { createStudyResult } from "../app/study-engine.ts";

const inputPath = process.argv[2] ?? new URL("./bazi15_site_sample.json", import.meta.url);
const outputPath = process.argv[3] ?? new URL("./bazi15_site_sample.fixed.json", import.meta.url);
const source = JSON.parse(await readFile(inputPath, "utf8"));

function itemValue(chart, label, index) {
  const value = chart.board.cells[index]?.items.find((item) => item.label === label)?.value;
  if (typeof value !== "string") throw new Error(`Site BaZi board is missing ${label} for pillar ${index + 1}.`);
  return value;
}

const exported = source.map((row) => {
  const [birthDate, birthTime, sex] = row.in.split(" ");
  const gender = sex === "yin" ? "yin" : "yang";
  const study = createStudyResult({ birthDate, birthTime, calendar: "solar", gender, focus: "", name: "", companionName: "", module: "bazi", version: 0 });
  const chart = createCompleteChart({ birthDate, birthTime, calendar: "pillars", manualPillars: study.pillars, gender, focus: "", name: "", companionName: "", module: "bazi", version: 0 });
  const cycles = chart.sections.find((section) => section.id === "luck-cycles")?.items.map((item) => item.value.split(" · ")[0]);
  const orientation = chart.sections.find((section) => section.id === "start-luck")?.items.find((item) => item.label === "Orientation")?.value;
  if (!cycles?.length || !orientation) throw new Error(`Site BaZi board is missing luck-cycle data for ${row.in}.`);

  return {
    in: row.in,
    pillars: study.pillars,
    ten: study.pillars.map((_, index) => itemValue(chart, "Ten God", index)),
    rel: study.pillars.map((_, index) => itemValue(chart, "Day-stem relation", index)),
    nayin: study.pillars.map((_, index) => itemValue(chart, "NaYin", index)),
    stage: study.pillars.map((_, index) => itemValue(chart, "Life stage", index)),
    hidden: study.pillars.map((_, index) => itemValue(chart, "Hidden stems", index)),
    cycles,
    dir: orientation === "Forward" ? "顺行" : "逆行",
    first: cycles[0],
    ln0: study.pillars[0],
  };
});

await writeFile(outputPath, `${JSON.stringify(exported, null, 2)}\n`);
console.log(`Exported ${exported.length} site BaZi charts to ${outputPath instanceof URL ? outputPath.pathname : outputPath}`);
