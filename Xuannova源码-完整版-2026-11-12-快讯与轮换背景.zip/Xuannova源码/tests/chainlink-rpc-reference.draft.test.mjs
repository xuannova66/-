import test from "node:test";
import assert from "node:assert/strict";
import {chainlinkRpcReferenceDraft} from "../worker/chainlink-rpc-reference.draft.ts";
const asset="0x1111111111111111111111111111111111111111",stable="0x2222222222222222222222222222222222222222",baseProxy="0x3333333333333333333333333333333333333333",stableProxy="0x4444444444444444444444444444444444444444";
const inputFeed={chainId:1,asset,assetDecimals:18,proxy:baseProxy,description:"ETH / USD"},settlementFeed={chainId:1,asset:stable,assetDecimals:6,proxy:stableProxy,description:"USDC / USD"};
function reader({updated=995n,wrongDescription=false,blockTime=998n,chain=1}={}){const calls=[];return {calls,getChainId:async()=>chain,getBlockNumber:async()=>123n,getBlock:async()=>({timestamp:blockTime}),readContract:async({address,functionName,blockNumber})=>{calls.push(blockNumber);const base=address.toLowerCase()===baseProxy.toLowerCase();if(functionName==="description")return base?(wrongDescription?"WRONG":"ETH / USD"):"USDC / USD";if(functionName==="decimals")return 8;if(functionName==="latestRoundData")return [1n,base?250000000000n:100000000n,990n,updated,1n];throw Error("unexpected");}};}
const base={chainId:1,asset,settlement:stable,outputUnits:4990000n,inputFeed,settlementFeed,clock:()=>1000};
test("reads both independent feeds at one block for each reference request",async()=>{
 const r=reader();assert.deepEqual(await chainlinkRpcReferenceDraft({...base,reader:r}),{inputUnits:1996000000000000n,observedAt:995,blockNumber:123n});
 await chainlinkRpcReferenceDraft({...base,reader:r});assert.equal(r.calls.length,12);assert.ok(r.calls.every(x=>x===123n));
});
test("fails closed on stale feeds, stale blocks, wrong chain or mismatched mapping",async()=>{
 await assert.rejects(chainlinkRpcReferenceDraft({...base,reader:reader({updated:900n})}),/STALE_OR_INVALID_PRICE/);
 await assert.rejects(chainlinkRpcReferenceDraft({...base,reader:reader({blockTime:900n})}),/STALE_OR_INVALID_BLOCK/);
 await assert.rejects(chainlinkRpcReferenceDraft({...base,reader:reader({chain:56})}),/WRONG_CHAIN/);
 await assert.rejects(chainlinkRpcReferenceDraft({...base,reader:reader({wrongDescription:true})}),/INVALID_PRICE_FEED_RESPONSE/);
 await assert.rejects(chainlinkRpcReferenceDraft({...base,reader:reader(),inputFeed:{...inputFeed,asset:stable}}),/PRICE_FEED_MAPPING_MISMATCH/);
});
