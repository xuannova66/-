import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { bytesToHex, hexToBytes, sha256 } from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { openDatabase } from "../server/sqlite-db.ts";
import { handleCommerceApi, createSessionToken } from "../worker/commerce-api.ts";
import { linkSolanaWallet, linkTronWallet } from "../app/wallet-link-client.ts";
import { tronMessageHash } from "../worker/wallet-link-auth.draft.ts";
const alphabet="123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
function base58(bytes){let n=0n;for(const b of bytes)n=n*256n+BigInt(b);let out="";while(n>0n){out=alphabet[Number(n%58n)]+out;n/=58n;}let zeros=0;while(bytes[zeros]===0)zeros++;return "1".repeat(zeros)+out;}
test("feature-gated wallet link API authenticates, enforces origin, verifies signatures and blocks replay/takeover",async()=>{
 const db=openDatabase(":memory:"); try {
  const dir=new URL("../migrations/",import.meta.url);for(const file of readdirSync(dir).filter(s=>s.endsWith(".sql")).sort())db.raw.exec(readFileSync(new URL(file,dir),"utf8"));
  for(const id of ["member1","member2"])db.raw.prepare("INSERT INTO members(id,credits,role,created_at,updated_at) VALUES(?,?,?,?,?)").run(id,0,"member","now","now");
  const secret="test-secret-that-is-longer-than-thirty-two-bytes", base={DB:db,SESSION_SECRET:secret,SITE_URL:"https://xuannova.test"}, enabled={...base,MULTICHAIN_WALLET_LINK_ENABLED:"true"};
  const session=async(id)=>createSessionToken({sub:id,role:"member",email:`${id}@example.test`},secret);
  const request=(path,payload,cookie,origin="https://xuannova.test")=>new Request(`https://xuannova.test/api/member/wallet-links/${path}`,{method:"POST",headers:{"content-type":"application/json",...(origin?{origin}:{}),...(cookie?{cookie:`xuanyuan_session=${cookie}`}:{})},body:JSON.stringify(payload)});
  const keys=await crypto.subtle.generateKey({name:"Ed25519"},true,["sign","verify"]), address=base58(new Uint8Array(await crypto.subtle.exportKey("raw",keys.publicKey)));
  const c1=await session("member1"),c2=await session("member2");
  assert.equal((await handleCommerceApi(request("challenge",{chain:"solana",address},c1),base)).status,503);
  assert.equal((await handleCommerceApi(request("challenge",{chain:"solana",address},null),enabled)).status,401);
  assert.equal((await handleCommerceApi(request("challenge",{chain:"solana",address},c1,"https://evil.test"),enabled)).status,403);
  assert.equal((await handleCommerceApi(request("challenge",{chain:"solana",address},c1,null),enabled)).status,403);
  const issue=async(cookie)=>{const response=await handleCommerceApi(request("challenge",{chain:"solana",address},cookie),enabled);assert.equal(response.status,200);return response.json();};
  const sign=async(message)=>bytesToHex(new Uint8Array(await crypto.subtle.sign("Ed25519",keys.privateKey,new TextEncoder().encode(message))));
  const first=await issue(c1), sig=await sign(first.message);
  assert.equal((await handleCommerceApi(request("verify",{nonce:first.nonce,signature:sig},c2),enabled)).status,409);
  assert.equal((await handleCommerceApi(request("verify",{nonce:first.nonce,signature:sig},c1),enabled)).status,200);
  assert.equal((await handleCommerceApi(request("verify",{nonce:first.nonce,signature:sig},c1),enabled)).status,409);
  const second=await issue(c2);
  assert.equal((await handleCommerceApi(request("verify",{nonce:second.nonce,signature:await sign(second.message)},c2),enabled)).status,409);
  assert.equal(db.raw.prepare("SELECT member_id FROM member_wallet_links_v2 WHERE chain=? AND address=?").get("solana",address).member_id,"member1");
  const keys2=await crypto.subtle.generateKey({name:"Ed25519"},true,["sign","verify"]),address2=base58(new Uint8Array(await crypto.subtle.exportKey("raw",keys2.publicKey))),publicKey={toString:()=>address2};
  const wallet={publicKey,isConnected:true,connect:async()=>({publicKey}),signMessage:async(message)=>({signature:new Uint8Array(await crypto.subtle.sign("Ed25519",keys2.privateKey,message))})};
  const localFetch=async(path,init)=>handleCommerceApi(new Request(`https://xuannova.test${path}`,{...init,headers:{...init.headers,origin:"https://xuannova.test",cookie:`xuanyuan_session=${c2}`}}),enabled);
  assert.equal(await linkSolanaWallet(wallet,localFetch),address2);
  assert.equal(db.raw.prepare("SELECT member_id FROM member_wallet_links_v2 WHERE chain=? AND address=?").get("solana",address2).member_id,"member2");
  const tronSigner=privateKeyToAccount(`0x${"33".repeat(32)}`), tronPayload=Uint8Array.from([0x41,...hexToBytes(tronSigner.address)]),tronHash=hexToBytes(sha256(hexToBytes(sha256(tronPayload)))),tronAddress=base58(Uint8Array.from([...tronPayload,...tronHash.slice(0,4)]));
  const tronWallet={request:async()=>[tronAddress],tronWeb:{ready:true,defaultAddress:{base58:tronAddress},trx:{signMessageV2:async(message)=>tronSigner.sign({hash:tronMessageHash(message)})}}};
  assert.equal(await linkTronWallet(tronWallet,localFetch),tronAddress);
  assert.equal(db.raw.prepare("SELECT member_id FROM member_wallet_links_v2 WHERE chain=? AND address=?").get("tron",tronAddress).member_id,"member2");
 } finally {db.raw.close();}
});
