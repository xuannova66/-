import test from "node:test";
import assert from "node:assert/strict";
const root = process.env.TS_ROOT ?? process.cwd();
const { lifeKLine, movingAverage, elementLeaning } = await import(`${root}/app/metaphysics/life-kline.ts`);
const { createStudyResult } = await import(`${root}/app/study-engine.ts`);

const chart = (date, time, gender) => { const r = createStudyResult({ birthDate: date, birthTime: time, calendar: "solar", focus: "", name: "", companionName: "", module: "bazi", version: 1, gender }); return { pillars: r.pillars, birthYear: Number(r.calendar.solar.slice(0, 4)), luck: r.astro.luck }; };

test("one candle per year for 100 years; open is last year's close; wicks cover the body", () => {
  const k = lifeKLine(chart("1990-05-20", "21:40", "yang"));
  assert.equal(k.candles.length, 100);
  assert.equal(k.candles[0].year, 1990);
  assert.equal(k.candles[0].age, 1);
  for (let i = 1; i < k.candles.length; i++) assert.equal(k.candles[i].open, k.candles[i - 1].close);
  for (const c of k.candles) {
    assert.ok(c.low <= Math.min(c.open, c.close) && c.high >= Math.max(c.open, c.close));
    assert.ok(c.close >= 5 && c.close <= 95);
    assert.ok(c.reasons.length >= 1);
  }
});

test("year pillars and luck cycles follow the calendar and the chart", () => {
  const input = chart("1990-05-20", "21:40", "yang");
  const k = lifeKLine(input);
  assert.equal(k.candles.find((c) => c.year === 2026).ganzhi, "丙午");
  assert.equal(k.candles.find((c) => c.year === 1984 + 60)?.ganzhi, "甲子");
  const first = input.luck.cycles[0];
  assert.equal(k.candles.find((c) => c.year === first.startYear).luck, first.ganzhi);
  assert.equal(k.candles.find((c) => c.year === first.startYear - 1)?.luck ?? null, null, "childhood before the first cycle");
  assert.equal(k.lucks[0].ganzhi, first.ganzhi);
});

test("rules: a clash with the day branch lowers the year; helpful elements raise it", () => {
  const k = lifeKLine(chart("1990-05-20", "21:40", "yang"));
  const dayBranch = "酉";
  const clash = k.candles.filter((c) => c.ganzhi.charAt(1) === "卯");
  assert.ok(clash.every((c) => c.reasons.some((r) => r.key === "clashDay")), `卯 clashes the ${dayBranch} day branch`);
  const lean = elementLeaning(["庚午", "辛巳", "乙酉", "丁亥"]);
  assert.deepEqual([...lean.favourable].sort(), ["木", "水"].sort());
  assert.equal(lifeKLine(chart("1990-05-20", "21:40", "yang")).average, k.average, "deterministic");
});

test("peaks and troughs are five years apart; the moving average starts after ten years", () => {
  const k = lifeKLine(chart("1985-11-02", "08:10", "yin"));
  for (const list of [k.peaks, k.troughs]) for (let i = 0; i < list.length; i++) for (let j = i + 1; j < list.length; j++) assert.ok(Math.abs(list[i].year - list[j].year) >= 5);
  const ma = movingAverage(k.candles);
  assert.equal(ma[8], null);
  assert.equal(typeof ma[9], "number");
});
