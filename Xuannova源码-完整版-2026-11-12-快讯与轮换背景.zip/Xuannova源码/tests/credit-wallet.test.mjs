import assert from "node:assert/strict";
import test from "node:test";

const {
  creditPackages,
  createCreditWallet,
  interpretationCost,
  spendCredits,
} = await import("../app/credit-wallet.ts");
const { hasConfiguredPaymentChannel, paymentConfig } = await import("../app/payment-config.ts");
const { creditCopy } = await import("../app/credit-copy.ts");

test("charges 20 credits for every interpretation", () => {
  assert.equal(interpretationCost("hecan"), 20);
  assert.equal(interpretationCost("bazi"), 20);
  assert.equal(interpretationCost("toolkit-tarot"), 20);
});

test("debits only when the wallet has enough credits", () => {
  const wallet = createCreditWallet(30);
  assert.deepEqual(spendCredits(wallet, "hecan"), {
    cost: 20,
    wallet: { balance: 10 },
  });
  assert.deepEqual(wallet, { balance: 30 });
  assert.equal(spendCredits(createCreditWallet(19), "bazi"), null);
});

test("publishes the four owner-defined USDT credit packages", () => {
  assert.deepEqual(creditPackages.map(({ name, usdt, credits }) => [name, usdt, credits]), [
    ["入门体验包", "4.99", 20],
    ["热门套餐", "9.90", 50],
    ["大容量套餐", "19.90", 120],
    ["至尊旗舰套餐", "39.90", 280],
  ]);
});

test("keeps payment disabled until the owner supplies a real USDT channel", () => {
  assert.equal(paymentConfig.checkoutUrl, "");
  assert.equal(paymentConfig.qrImageUrl, "");
  assert.equal(paymentConfig.recipientAddress, "");
  assert.equal(hasConfiguredPaymentChannel, false);
});

test("has wallet copy for every published interface language", () => {
  for (const locale of ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"]) {
    const copy = creditCopy(locale);
    assert.ok(copy.wallet.length > 0);
    assert.ok(copy.insufficient.length > 0);
    assert.ok(copy.paymentPending.length > 0);
  }
});
