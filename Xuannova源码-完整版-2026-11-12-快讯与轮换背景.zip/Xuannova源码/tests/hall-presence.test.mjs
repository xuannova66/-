// 同殿共修: heartbeat ids come from the device cookie, names are random or chosen (and filtered), stale rows vanish.
import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import test from "node:test";

const { openDatabase } = await import("../server/sqlite-db.ts");
const { handleCommerceApi } = await import("../worker/commerce-api.ts");
const { cleanDaoName, randomDaoName, heartbeat } = await import("../worker/hall-presence.ts");
const ORIGIN = "https://xuannova.test";

function freshEnv() {
  const db = openDatabase(":memory:");
  for (const file of readdirSync(new URL("../migrations/", import.meta.url)).filter((name) => name.endsWith(".sql")).sort()) db.raw.exec(readFileSync(new URL(`../migrations/${file}`, import.meta.url), "utf8"));
  return { DB: db, SESSION_SECRET: "test-session-signing-key-that-is-long-enough" };
}
const beat = (env, device, body = {}, origin = ORIGIN) => handleCommerceApi(new Request(`${ORIGIN}/api/hall/heartbeat`, { method: "POST", headers: { origin, "content-type": "application/json", cookie: `xn_device=${device}` }, body: JSON.stringify(body) }), env).then(async (r) => ({ status: r.status, body: await r.json() }));

test("random names are natural, stable per visitor, varied, and come with pinyin", () => {
  const a = randomDaoName("abc123"), b = randomDaoName("abc123");
  assert.deepEqual(a, b);
  const names = new Set();
  for (let i = 0; i < 400; i += 1) {
    const item = randomDaoName(`v${i}`);
    assert.ok(/^[A-Z]/.test(item.name) ? item.name.length <= 10 : [...item.name].length >= 2 && [...item.name].length <= 4, item.name);
    assert.match(item.latin, /^[A-Z][A-Za-z' ]+$/);
    assert.ok(cleanDaoName(item.name), item.name);
    names.add(item.name);
  }
  assert.ok(names.size > 170, `only ${names.size} different names`);
});

test("chosen names: 1–10 letters or CJK; no links, contacts or abuse", () => {
  assert.equal(cleanDaoName("  清 风  "), "清 风");
  assert.equal(cleanDaoName("Moonlight"), "Moonlight");
  for (const bad of ["", "一二三四五六七八九十一", "加我微信", "www.x.com", "a@b", "VX123", "13800138000", "<b>x</b>", "fuck"]) assert.equal(cleanDaoName(bad), null, bad);
});

test("visitors see each other, the caller first; names persist; refused names keep the old one", async () => {
  const env = freshEnv();
  const one = await beat(env, "device-hall-0000000000001", { route: "bazi" });
  assert.equal(one.status, 200);
  assert.equal(one.body.online, undefined); // the head count is never sent to visitors
  assert.equal(one.body.self.custom, false);
  assert.equal(one.body.self.route, "bazi");
  const two = await beat(env, "device-hall-0000000000002", { route: "home", name: "松风" });
  assert.equal(two.body.self.name, "松风");
  assert.equal(two.body.self.custom, true);
  assert.deepEqual(two.body.others.map((v) => v.id), [one.body.self.id]);
  assert.equal(two.body.others[0].route, "bazi");
  const refused = await beat(env, "device-hall-0000000000002", { name: "加我微信" });
  assert.equal(refused.body.rejected, true);
  assert.equal(refused.body.self.name, "松风");
  const reset = await beat(env, "device-hall-0000000000002", { name: "" });
  assert.equal(reset.body.self.custom, false);
  assert.notEqual(reset.body.self.name, "松风");
  // Ids are derived on the server: a body id is ignored.
  const spoof = await beat(env, "device-hall-0000000000003", { id: one.body.self.id, name: "冒名" });
  assert.notEqual(spoof.body.self.id, one.body.self.id);
  assert.equal((await beat(env, "device-hall-0000000000003", {}, "https://evil.test")).status, 403);
});

test("visitors silent for more than 75 seconds are no longer online", async () => {
  const env = freshEnv();
  const t0 = new Date("2026-11-07T10:00:00Z");
  await heartbeat(env.DB, { id: "aaaa", now: t0 });
  const later = await heartbeat(env.DB, { id: "bbbb", now: new Date(t0.getTime() + 80_000) });
  assert.equal(later.online, 1);
  assert.equal(later.others.length, 0);
});
