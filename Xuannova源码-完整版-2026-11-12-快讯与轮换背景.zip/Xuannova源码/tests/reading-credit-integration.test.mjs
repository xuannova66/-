// End-to-end API tests against a real SQLite database with every migration applied.
import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import test from "node:test";

const { openDatabase } = await import("../server/sqlite-db.ts");
const { handleCommerceApi } = await import("../worker/commerce-api.ts");

const ORIGIN = "https://xuannova.test";
const reading = {
  title: "Reading", summary: "Summary text.",
  sections: [1, 2, 3, 4].map((n) => ({ title: `Section ${n}`, text: `Body of section ${n}.` })),
  followUps: ["Follow-up one", "Follow-up two", "Follow-up three"],
};
let providerCalls = 0;
const realFetch = globalThis.fetch;
globalThis.fetch = async (url, init) => {
  if (String(url).startsWith("https://api.deepseek.com")) {
    providerCalls += 1;
    return new Response(JSON.stringify({ choices: [{ message: { content: JSON.stringify(reading) } }] }), { status: 200, headers: { "content-type": "application/json" } });
  }
  if (String(url).startsWith("https://oauth2.googleapis.com/tokeninfo")) {
    const token = new URL(String(url)).searchParams.get("id_token");
    if (token === "good-token") return new Response(JSON.stringify({ aud: "google-client", iss: "https://accounts.google.com", email: "g-user@example.com", email_verified: "true", exp: String(Math.floor(Date.now() / 1000) + 600) }), { status: 200 });
    if (token === "other-audience") return new Response(JSON.stringify({ aud: "someone-else", iss: "accounts.google.com", email: "g-user@example.com", email_verified: "true", exp: String(Math.floor(Date.now() / 1000) + 600) }), { status: 200 });
    return new Response("{}", { status: 400 });
  }
  if (String(url).startsWith("https://test.dodopayments.com/checkouts")) {
    const body = JSON.parse(init.body);
    dodoCheckouts.push(body);
    return new Response(JSON.stringify({ session_id: "cks_1", checkout_url: "https://test.checkout.dodopayments.com/cks_1" }), { status: 200 });
  }
  if (String(url).startsWith("https://test.dodopayments.com/payments/")) {
    const id = decodeURIComponent(String(url).split("/payments/")[1]);
    const payment = dodoPayments[id];
    return payment ? new Response(JSON.stringify(payment), { status: 200 }) : new Response("{}", { status: 404 });
  }
  if (String(url).startsWith("https://api.resend.com")) { sentMail.push(JSON.parse(init.body)); return new Response("{}", { status: 200 }); }
  return realFetch(url, init);
};
const sentMail = [];
const dodoCheckouts = [];
const dodoPayments = {};

function freshEnv(adminEmails = "owner@example.com") {
  const db = openDatabase(":memory:");
  for (const file of readdirSync(new URL("../migrations/", import.meta.url)).filter((name) => name.endsWith(".sql")).sort()) {
    db.raw.exec(readFileSync(new URL(`../migrations/${file}`, import.meta.url), "utf8"));
  }
  return { db, env: { DB: db, ADMIN_EMAILS: adminEmails, ADMIN_PASSWORD: "admin-password-123", SESSION_SECRET: "test-session-signing-key-that-is-long-enough", DEEPSEEK_API_KEY: "test-key" } };
}

/** A tiny browser: keeps cookies per "device". */
function client(env, deviceCookie = "") {
  const jar = new Map();
  if (deviceCookie) jar.set("xn_device", deviceCookie);
  jar.set("xn_tz", "Asia%2FSaigon");
  return async (path, body, method = body === undefined ? "GET" : "POST") => {
    const headers = { origin: ORIGIN, cookie: [...jar].map(([k, v]) => `${k}=${v}`).join("; ") };
    if (body !== undefined) headers["content-type"] = "application/json";
    const response = await handleCommerceApi(new Request(`${ORIGIN}${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) }), env);
    for (const cookie of response.headers.getSetCookie?.() ?? []) {
      const [pair] = cookie.split(";");
      const [name, value] = pair.split("=");
      if (value) jar.set(name, value); else jar.delete(name);
    }
    return { status: response.status, body: await response.json() };
  };
}

const chart = {
  calendar: { lunar: "一九九四年七月十二", naYin: "涧下水", solar: "1994-08-18 15:00:00" },
  pillars: ["甲戌", "壬申", "丙子", "丙申"],
  board: { kind: "pillars", label: "Four Pillars complete board", cells: [{ id: "pillar-0", title: "Year pillar", items: [{ label: "Ten God", value: "偏印" }] }] },
  sections: [{ id: "ten-gods", title: "Ten-God relationships", lead: "Local", items: [{ label: "Year pillar", value: "偏印" }] }],
  sourceFacts: ["Calculated solar/lunar conversion"],
  inputSummary: { focus: "", place: "Global", version: 1 },
};
const previewBody = { tool: "bazi", locale: "en", question: "What should I study next?", chart };

test("anonymous visitors get only the first half; the full reading never reaches the browser before unlock", async () => {
  const { env } = freshEnv();
  const browser = client(env, "device-aaaaaaaaaaaaaaaa");
  const preview = await browser("/api/readings/preview", previewBody);
  assert.equal(preview.status, 200);
  assert.equal(preview.body.preview.sections.length, 1);
  assert.deepEqual(preview.body.lockedSections, ["Section 2", "Section 3", "Section 4"]);
  assert.ok(!JSON.stringify(preview.body).includes("Body of section 2"), "locked text must stay on the server");
  assert.deepEqual(preview.body.preview.followUps, []);
  const unlockAnonymous = await browser("/api/readings/unlock", { draftId: preview.body.draftId });
  assert.equal(unlockAnonymous.status, 401);
});

test("after registering, the same reading unlocks once for its cost and is not regenerated", async () => {
  const { env, db } = freshEnv();
  const browser = client(env, "device-bbbbbbbbbbbbbbbb");
  const before = providerCalls;
  const preview = await browser("/api/readings/preview", previewBody);
  const registered = await browser("/api/auth/register", { email: "new@example.com", password: "secret-pass" });
  assert.equal(registered.status, 201);
  assert.equal(registered.body.member.balance, 5, "first daily bonus is 5");
  const short = await browser("/api/readings/unlock", { draftId: preview.body.draftId });
  assert.equal(short.status, 402, "20 credits needed, 5 available");
  db.prepare("UPDATE members SET credits = 30 WHERE email = ?").bind("new@example.com").run();
  const unlocked = await browser("/api/readings/unlock", { draftId: preview.body.draftId });
  assert.equal(unlocked.status, 200);
  assert.equal(unlocked.body.response.sections.length, 4);
  assert.equal(unlocked.body.member.balance, 15, "daily credits are spent first: 35 - 20");
  const again = await browser("/api/readings/unlock", { draftId: preview.body.draftId });
  assert.equal(again.status, 200);
  assert.equal(again.body.cost, 0, "a second unlock does not charge again");
  assert.equal(providerCalls - before, 1, "the reading is generated only once");
  const history = await browser("/api/member/interpretations");
  assert.equal(history.body.interpretations.length, 1);
  const stranger = client(env, "device-cccccccccccccccc");
  await stranger("/api/auth/register", { email: "other@example.com", password: "secret-pass" });
  assert.equal((await stranger("/api/readings/unlock", { draftId: preview.body.draftId })).status, 404, "another account cannot open someone else's reading");
});

test("the free first half is offered every time; the second half is never free; a daily safety limit stops scripts", async () => {
  const { env, db } = freshEnv();
  const browser = client(env, "device-dddddddddddddddd");
  const soft = await browser("/api/member/me?soft=1");
  assert.equal(soft.status, 200, "signed-out check does not log a failed request");
  assert.equal(soft.body.member, null);
  for (let round = 1; round <= 3; round += 1) {
    const preview = await browser("/api/readings/preview", previewBody);
    assert.equal(preview.status, 200, `free first half, round ${round}`);
    assert.equal(preview.body.preview.sections.length, 1);
    assert.ok(!JSON.stringify(preview.body).includes("Body of section 2"), "the second half is never sent free");
  }
  assert.equal((await browser("/api/readings/free-status")).body.free, true);
  // Signed in: still a free first half every time; the full reading costs credits.
  await browser("/api/auth/register", { email: "once@example.com", password: "secret-pass" });
  assert.equal((await browser("/api/readings/preview", previewBody)).status, 200, "members also get the free first half");
  const before = providerCalls;
  const broke = await browser("/api/readings/preview", { ...previewBody, pay: true });
  assert.equal(broke.body.code, "INSUFFICIENT_CREDITS");
  assert.equal(providerCalls, before, "no reading is generated without enough credits");
  db.prepare("UPDATE members SET credits = 100 WHERE email = ?").bind("once@example.com").run();
  const paid = await browser("/api/readings/preview", { ...previewBody, pay: true });
  assert.equal(paid.status, 200);
  assert.equal(paid.body.unlocked, true);
  assert.ok(paid.body.response.sections.length > 1, "a paid reading arrives complete");
  assert.equal(paid.body.member.balance, 100 + 5 - paid.body.cost);
  // Safety limit: 30 free halves per device per day.
  const capped = client(env, "device-cappedcapped0001");
  const since = new Date().toISOString();
  for (let n = 0; n < 30; n += 1) await db.prepare("INSERT INTO reading_drafts (id, device_id, member_id, tool, locale, mode, question, response_json, cost, created_at, is_free) VALUES (?, 'd:device-cappedcapped0001', NULL, 'bazi', 'en', 'structured', 'q', '{}', 20, ?, 1)").bind(`cap-${n}`, since).run();
  const limited = await capped("/api/readings/preview", previewBody);
  assert.equal(limited.status, 429);
  assert.equal(limited.body.code, "PREVIEW_LIMIT");
  assert.equal((await capped("/api/readings/free-status")).body.free, false);
});

test("daily bonus: +5 per local day, accumulates to 20, one account per device per day", async () => {
  const { env, db } = freshEnv();
  const browser = client(env, "device-eeeeeeeeeeeeeeee");
  const first = await browser("/api/auth/register", { email: "daily@example.com", password: "secret-pass" });
  assert.equal(first.body.member.balance, 5);
  assert.equal((await browser("/api/member/me")).body.member.balance, 5, "same day: no second bonus");
  for (let day = 1; day <= 5; day += 1) {
    // Move the last claim back one day and 13 hours, as if the member returns tomorrow.
    db.prepare("UPDATE members SET daily_credit_date = '2000-01-01', daily_claimed_at = ? WHERE email = ?").bind(new Date(Date.now() - 37 * 3600 * 1000).toISOString(), "daily@example.com").run();
    db.prepare("DELETE FROM daily_bonus_claims").run();
    await browser("/api/member/me");
  }
  assert.equal((await browser("/api/member/me")).body.member.balance, 20, "capped at 20");
  // Second account on the same device the same day gets nothing.
  const sameDevice = client(env, "device-ffffffffffffffff");
  await sameDevice("/api/auth/register", { email: "first-on-device@example.com", password: "secret-pass" });
  await sameDevice("/api/auth/logout", {});
  const second = await sameDevice("/api/auth/register", { email: "second-on-device@example.com", password: "secret-pass" });
  assert.equal(second.body.member.balance, 0, "one daily bonus per device per day");
  // Switching time zones right after a claim does not give another bonus (12-hour spacing).
  db.prepare("UPDATE members SET daily_credit_date = '2000-01-01' WHERE email = ?").bind("first-on-device@example.com").run();
  await sameDevice("/api/auth/login", { email: "first-on-device@example.com", password: "secret-pass" });
  assert.equal((await sameDevice("/api/member/me")).body.member.balance, 5);
});

test("admin: exclusive package for a group, manual order with it, and credit grants approved by one administrator", async () => {
  const { env } = freshEnv("owner@example.com,finance@example.com");
  const member = client(env, "device-gggggggggggggggg");
  await member("/api/auth/register", { email: "vip@example.com", password: "secret-pass" });
  const owner = client(env, "device-hhhhhhhhhhhhhhhh");
  const finance = client(env, "device-iiiiiiiiiiiiiiii");
  assert.equal((await owner("/api/auth/admin/login", { email: "owner@example.com", password: "admin-password-123" })).status, 200);
  assert.equal((await finance("/api/auth/admin/login", { email: "finance@example.com", password: "admin-password-123" })).status, 200);

  const group = await owner("/api/admin/groups", { name: "VIP clients", add: ["vip@example.com", "missing@example.com"] });
  assert.deepEqual(group.body.missing, ["missing@example.com"]);
  const pkg = await owner("/api/admin/packages", { name: "VIP 500", credits: 500, priceUsdt: "45", groupId: group.body.groupId });
  assert.equal(pkg.status, 201);
  const offered = await member("/api/member/packages");
  assert.deepEqual(offered.body.packages.map((item) => item.credits), [500]);
  const order = await member("/api/orders/manual", { packageId: pkg.body.id, network: "bsc", transactionHash: `0x${"a".repeat(64)}` });
  assert.equal(order.status, 201);
  assert.equal(order.body.order.credits, 500);
  const outsider = client(env, "device-jjjjjjjjjjjjjjjj");
  await outsider("/api/auth/register", { email: "outsider@example.com", password: "secret-pass" });
  assert.equal((await outsider("/api/orders/manual", { packageId: pkg.body.id, network: "bsc", transactionHash: `0x${"b".repeat(64)}` })).status, 400, "package is only for its group");

  const grant = await owner("/api/admin/grants", { member: "vip@example.com", credits: 100, reason: "Consultation compensation" });
  assert.equal(grant.status, 201);
  const approved = await owner(`/api/admin/grants/${grant.body.id}/decision`, { decision: "approve" });
  assert.equal(approved.body.membersCredited, 1);
  assert.equal((await finance(`/api/admin/grants/${grant.body.id}/decision`, { decision: "approve" })).status, 409, "decided once");
  assert.equal((await member("/api/member/me")).body.member.balance, 105);
  assert.equal((await member("/api/admin/grants")).status, 403, "members cannot use admin routes");
});

test("email-first sign-in creates a new account with the entered password; Google sign-in verifies the token audience", async () => {
  const { env } = freshEnv();
  const browser = client(env, "device-kkkkkkkkkkkkkkkk");
  const created = await browser("/api/auth/login", { email: "fresh@example.com", password: "secret-pass", autoRegister: true });
  assert.equal(created.status, 201);
  await browser("/api/auth/logout", {});
  assert.equal((await browser("/api/auth/login", { email: "fresh@example.com", password: "secret-pass", autoRegister: true })).status, 200);
  assert.equal((await browser("/api/auth/login", { email: "fresh@example.com", password: "wrong-pass", autoRegister: true })).status, 401, "existing email still needs its password");
  assert.equal((await browser("/api/auth/login", { email: "nobody@example.com", password: "secret-pass" })).status, 401, "without autoRegister unknown emails are rejected");

  const googleEnv = { ...env, GOOGLE_CLIENT_ID: "google-client" };
  const google = client(googleEnv, "device-llllllllllllllll");
  assert.deepEqual((await google("/api/auth/providers")).body, { google: { clientId: "google-client" }, dodo: null });
  assert.equal((await google("/api/auth/google", { credential: "other-audience" })).status, 401);
  const signedIn = await google("/api/auth/google", { credential: "good-token" });
  assert.equal(signedIn.status, 201);
  assert.equal((await google("/api/member/me")).body.member.email, "g-user@example.com");
  assert.equal((await client(env)("/api/auth/google", { credential: "good-token" })).status, 503, "hidden when not configured");
});

test("lectures: administrators publish links; everyone can list published lectures without signing in", async () => {
  const { env } = freshEnv();
  const owner = client(env, "device-mmmmmmmmmmmmmmmm");
  await owner("/api/auth/admin/login", { email: "owner@example.com", password: "admin-password-123" });
  assert.equal((await owner("/api/admin/lectures", { title: { en: "Intro" }, videoUrl: "http://insecure.example/v.mp4" })).status, 400, "https only");
  const draft = await owner("/api/admin/lectures", { title: { en: "Draft lesson" }, videoUrl: "https://youtu.be/abcdefg1234", published: false });
  const live = await owner("/api/admin/lectures", { title: { en: "Five Elements", "zh-Hans": "五行入门" }, videoUrl: "https://youtu.be/abcdefg5678", durationMinutes: 12, published: true });
  assert.equal(live.status, 201);
  const visitor = client(env, "device-nnnnnnnnnnnnnnnn");
  const listed = await visitor("/api/lectures");
  assert.deepEqual(listed.body.lectures.map((item) => item.title["zh-Hans"]), ["五行入门"]);
  assert.equal(listed.body.lectures[0].locked, true, "members-only by default");
  assert.equal(listed.body.lectures[0].videoUrl, null, "visitors do not receive the members-only video address");
  const watcher = client(env, "device-lecturewatcher00");
  await watcher("/api/auth/register", { email: "watcher@example.com", password: "secret-pass" });
  const seen = (await watcher("/api/lectures")).body.lectures[0];
  assert.equal(seen.locked, false);
  assert.equal(seen.videoUrl, "https://youtu.be/abcdefg5678", "members watch for free");
  const open = await owner("/api/admin/lectures", { title: { en: "Open lesson" }, videoUrl: "https://youtu.be/abcdefg9999", membersOnly: false, published: true });
  assert.equal((await visitor("/api/lectures")).body.lectures.find((item) => item.id === open.body.id).videoUrl, "https://youtu.be/abcdefg9999", "open lessons play for everyone");
  await owner("/api/admin/lectures", { id: open.body.id, title: { en: "Open lesson" }, videoUrl: "https://youtu.be/abcdefg9999", membersOnly: false, published: false });
  await owner("/api/admin/lectures", { id: draft.body.id, title: { en: "Draft lesson" }, videoUrl: "https://youtu.be/abcdefg1234", published: true });
  assert.equal((await visitor("/api/lectures")).body.lectures.length, 2);
  assert.equal((await visitor("/api/admin/lectures")).status, 401);
});

test("Workshop: products, stock reservation, duplicate hashes, and administrator fulfilment", async () => {
  const { env } = freshEnv();
  const owner = client(env, "device-oooooooooooooooo");
  await owner("/api/auth/admin/login", { email: "owner@example.com", password: "admin-password-123" });
  const product = await owner("/api/admin/shop/products", { name: { en: "Bronze compass", "zh-Hans": "铜罗盘" }, priceUsdt: "39.50", stock: 2 });
  assert.equal(product.status, 201);
  const buyer = client(env, "device-pppppppppppppppp");
  assert.equal((await buyer("/api/shop/orders", { items: [{ productId: product.body.id, quantity: 1 }] })).status, 401, "sign in first");
  await buyer("/api/auth/login", { email: "buyer@example.com", password: "secret-pass", autoRegister: true });
  const shipping = { name: "A Buyer", phone: "123", country: "VN", address: "1 Street" };
  assert.equal((await buyer("/api/shop/orders", { items: [{ productId: product.body.id, quantity: 3 }], network: "bsc", transactionHash: `0x${"c".repeat(64)}`, shipping })).status, 409, "cannot exceed stock");
  const order = await buyer("/api/shop/orders", { items: [{ productId: product.body.id, quantity: 2 }], network: "bsc", transactionHash: `0x${"d".repeat(64)}`, shipping });
  assert.equal(order.status, 201);
  assert.equal(order.body.order.totalUsdt, "79.00");
  assert.equal((await buyer("/api/shop/products")).body.products[0].stock, 0, "stock reserved");
  assert.equal((await buyer("/api/shop/orders", { items: [{ productId: product.body.id, quantity: 1 }], network: "bsc", transactionHash: `0x${"d".repeat(64)}`, shipping })).status, 409);
  assert.equal((await owner(`/api/admin/shop/orders/${order.body.order.id}`, { status: "shipped" })).status, 409, "must be paid before shipping");
  assert.equal((await owner(`/api/admin/shop/orders/${order.body.order.id}`, { status: "paid" })).status, 200);
  assert.equal((await owner(`/api/admin/shop/orders/${order.body.order.id}`, { status: "shipped", tracking: "SF123" })).status, 200);
  assert.deepEqual((await buyer("/api/shop/orders")).body.orders.map((item) => [item.status, item.tracking]), [["shipped", "SF123"]]);
  const second = await owner("/api/admin/shop/products", { name: { en: "Incense" }, priceUsdt: "5", stock: 1 });
  const rejected = await buyer("/api/shop/orders", { items: [{ productId: second.body.id, quantity: 1 }], network: "trc20", transactionHash: "e".repeat(64), shipping });
  await owner(`/api/admin/shop/orders/${rejected.body.order.id}`, { status: "rejected" });
  assert.equal((await buyer("/api/shop/products")).body.products.find((item) => item.id === second.body.id).stock, 1, "rejection returns stock");
});

test("forgot password: email link resets once; no account enumeration; admin can create a link", async () => {
  const { env } = freshEnv();
  const mailEnv = { ...env, RESEND_API_KEY: "re_test", MAIL_FROM: "Xuannova <no-reply@xuannova.test>", SITE_URL: "https://xuannova.test" };
  const user = client(mailEnv, "device-rrrrrrrrrrrrrrrr");
  await user("/api/auth/register", { email: "forgot@example.com", password: "old-password" });
  const unknown = await user("/api/auth/forgot", { email: "nobody@example.com", locale: "en" });
  const known = await user("/api/auth/forgot", { email: "forgot@example.com", locale: "ja" });
  assert.deepEqual(unknown.body, known.body, "same answer whether or not the email has an account");
  assert.equal(sentMail.length, 1);
  assert.match(sentMail[0].subject, /パスワード/);
  const token = sentMail[0].text.match(/reset=([A-Za-z0-9_-]+)/)[1];
  assert.match(sentMail[0].text, /https:\/\/xuannova\.test\/ja\/membership\?reset=/);
  assert.equal((await user("/api/auth/reset", { token, password: "new-password" })).status, 200);
  assert.equal((await user("/api/auth/reset", { token, password: "another-one" })).status, 400, "a link works once");
  assert.equal((await user("/api/auth/login", { email: "forgot@example.com", password: "old-password" })).status, 401);
  assert.equal((await user("/api/auth/login", { email: "forgot@example.com", password: "new-password" })).status, 200);
  const owner = client(env, "device-ssssssssssssssss");
  await owner("/api/auth/admin/login", { email: "owner@example.com", password: "admin-password-123" });
  const made = await owner("/api/admin/reset-link", { member: "forgot@example.com", locale: "en" });
  assert.equal(made.status, 200);
  const adminToken = made.body.link.match(/reset=([A-Za-z0-9_-]+)/)[1];
  assert.equal((await user("/api/auth/reset", { token: adminToken, password: "third-password" })).status, 200);
  assert.equal((await user("/api/admin/reset-link", { member: "forgot@example.com" })).status, 403, "members cannot create links");
});

test("Dodo card payments: checkout, signed webhook adds credits once, forged or replayed deliveries do nothing, refund removes credits", async () => {
  const { signDodoWebhook } = await import("../worker/dodo.ts");
  const secret = "whsec_" + Buffer.from("test-dodo-signing-secret-0123456789").toString("base64");
  const { env, db } = freshEnv();
  const dodoEnv = { ...env, DODO_API_KEY: "dodo_test_key", DODO_WEBHOOK_SECRET: secret, DODO_ENVIRONMENT: "test", DODO_PRODUCTS: JSON.stringify({ path: "pdt_path" }), SITE_URL: "https://xuannova.test" };
  const inviter = client(dodoEnv, "device-dodoinviter00000");
  const invite = await inviter("/api/auth/register", { email: "inviter@example.com", password: "secret-pass" });
  const buyer = client(dodoEnv, "device-dodobuyer0000000");
  await buyer("/api/auth/register", { email: "card@example.com", password: "secret-pass", inviteCode: invite.body.member.inviteCode });
  assert.deepEqual((await buyer("/api/auth/providers")).body.dodo, { packages: ["path"] });
  assert.equal((await buyer("/api/payments/dodo/checkout", { packageId: "seed" })).status, 400, "packages without a Dodo product cannot be paid by card");
  const checkout = await buyer("/api/payments/dodo/checkout", { packageId: "path", locale: "ja" });
  assert.equal(checkout.status, 200);
  assert.match(checkout.body.url, /^https:\/\/test\.checkout\.dodopayments\.com/);
  const sent = dodoCheckouts.at(-1);
  assert.deepEqual(sent.product_cart, [{ product_id: "pdt_path", quantity: 1 }]);
  assert.equal(sent.customer.email, "card@example.com");
  assert.equal(sent.metadata.order_id, checkout.body.orderId);
  assert.equal(sent.return_url, `https://xuannova.test/ja/credits?dodo_order=${checkout.body.orderId}`);
  const balance = async () => (await buyer("/api/member/me")).body.member.balance;
  const before = await balance();
  const deliver = async (id, payload, { sign = true, timestamp = String(Math.floor(Date.now() / 1000)) } = {}) => {
    const raw = JSON.stringify(payload);
    const headers = { "content-type": "application/json", "webhook-id": id, "webhook-timestamp": timestamp, "webhook-signature": sign ? await signDodoWebhook(secret, id, timestamp, raw) : "v1,AAAA" };
    const response = await handleCommerceApi(new Request(`${ORIGIN}/api/payments/dodo/webhook`, { method: "POST", headers, body: raw }), dodoEnv);
    return response.status;
  };
  const succeeded = { business_id: "bus_1", type: "payment.succeeded", timestamp: new Date().toISOString(), data: { payment_id: "pay_1", metadata: { order_id: checkout.body.orderId }, total_amount: 990, currency: "USD" } };
  assert.equal(await deliver("msg_forged", succeeded, { sign: false }), 400, "unsigned deliveries are rejected");
  assert.equal(await deliver("msg_old", succeeded, { timestamp: String(Math.floor(Date.now() / 1000) - 3600) }), 400, "stale deliveries are rejected");
  assert.equal(await deliver("msg_unpaid", succeeded), 409, "a payment Dodo does not confirm adds nothing");
  dodoPayments.pay_1 = { payment_id: "pay_1", status: "succeeded", metadata: { order_id: checkout.body.orderId }, total_amount: 990, currency: "USD" };
  assert.equal(await deliver("msg_1", succeeded), 200);
  assert.equal(await balance(), before + 50 + 5 + 20, "50 credits, the first-purchase invitation reward and the first-purchase bonus");
  assert.equal(await deliver("msg_1", succeeded), 200);
  assert.equal(await deliver("msg_2", succeeded), 200);
  assert.equal(await balance(), before + 75, "retries and duplicates do not add credits twice");
  assert.equal((await inviter("/api/member/me")).body.member.balance, invite.body.member.balance + 5, "inviter rewarded once");
  assert.equal((await buyer(`/api/payments/dodo/order?id=${checkout.body.orderId}`)).body.order.status, "paid");
  assert.equal((await inviter(`/api/payments/dodo/order?id=${checkout.body.orderId}`)).status, 404, "orders are private");
  assert.equal(await deliver("msg_refund", { type: "refund.succeeded", data: { payment_id: "pay_1", refund_id: "ref_1", amount: 990 } }), 200);
  assert.equal(await balance(), before + 5, "a full refund removes the purchased credits and the first-purchase bonus");
  const ledger = (await db.prepare("SELECT reason FROM credit_ledger WHERE reason LIKE 'dodo_%' ORDER BY created_at").all()).results.map((row) => row.reason);
  assert.deepEqual(ledger, ["dodo_payment", "dodo_refund"]);
});

test("airdrop to all members or a list (one administrator requests and approves) and invitation team totals", async () => {
  const { env, db } = freshEnv("owner@example.com,finance@example.com");
  const leader = client(env, "device-teamleader000000");
  const reg = await leader("/api/auth/register", { email: "leader@example.com", password: "secret-pass" });
  const a = client(env, "device-teamaaaaaaaaaaaa");
  await a("/api/auth/register", { email: "a@example.com", password: "secret-pass", inviteCode: reg.body.member.inviteCode });
  const b = client(env, "device-teambbbbbbbbbbbb");
  await b("/api/auth/register", { email: "b@example.com", password: "secret-pass", inviteCode: reg.body.member.inviteCode });
  const owner = client(env, "device-teamowner0000000");
  const finance = client(env, "device-teamfinance00000");
  await owner("/api/auth/admin/login", { email: "owner@example.com", password: "admin-password-123" });
  await finance("/api/auth/admin/login", { email: "finance@example.com", password: "admin-password-123" });
  const balanceOf = async (browser) => (await browser("/api/member/me")).body.member.balance;
  const [l0, a0, b0] = [await balanceOf(leader), await balanceOf(a), await balanceOf(b)];
  const all = await owner("/api/admin/grants", { target: "all", credits: 10, reason: "Launch airdrop" });
  assert.equal(all.status, 201);
  assert.equal((await owner(`/api/admin/grants/${all.body.id}/decision`, { decision: "approve" })).body.membersCredited, 3, "one administrator can request and approve");
  assert.deepEqual([await balanceOf(leader), await balanceOf(a), await balanceOf(b)], [l0 + 10, a0 + 10, b0 + 10]);
  const list = await owner("/api/admin/grants", { members: ["a@example.com", "missing@example.com"], credits: 7, reason: "Event winners" });
  assert.equal(list.body.members, 1);
  assert.deepEqual(list.body.missing, ["missing@example.com"], "addresses that match no member are reported back");
  await finance(`/api/admin/grants/${list.body.id}/decision`, { decision: "approve" });
  assert.equal(await balanceOf(a), a0 + 17);
  // Team totals: one approved USDT order by an invited member.
  db.prepare("INSERT INTO payment_orders (id, member_id, package_id, amount_usdt, credits, network, transaction_hash, status, submitted_at) SELECT 'order-team-1', id, 'path', '9.90', 50, 'bsc', ?, 'pending', ? FROM members WHERE email = 'a@example.com'").bind(`0x${"f".repeat(64)}`, new Date().toISOString()).run();
  db.prepare("UPDATE payment_orders SET status = 'approved', reviewed_at = ?, reviewed_by = 'test' WHERE id = 'order-team-1'").bind(new Date().toISOString()).run();
  const team = (await leader("/api/member/team")).body;
  assert.equal(team.invited, 2);
  assert.equal(team.purchasers, 1);
  assert.equal(team.totalUsd, "9.90");
  assert.equal(team.totalCredits, 50);
  assert.match(team.members[0].name, /^[ab]\*+@example\.com$/, "invitee emails are masked");
  const teams = (await owner("/api/admin/teams")).body.teams;
  assert.deepEqual(teams[0], { memberId: teams[0].memberId, email: "leader@example.com", invited: 2, purchasers: 1, totalUsd: "9.90", totalCredits: 50 });
  assert.equal((await leader("/api/admin/teams")).status, 403);
});

test("manual transfers on Ethereum and Solana are accepted with their own hash formats and credited on approval", async () => {
  const { env } = freshEnv();
  const member = client(env, "device-ethsol000000000001");
  await member("/api/auth/register", { email: "chains@example.com", password: "secret-pass" });
  const owner = client(env, "device-ethsol000000000002");
  assert.equal((await owner("/api/auth/admin/login", { email: "owner@example.com", password: "admin-password-123" })).status, 200);
  assert.equal((await member("/api/orders/manual", { packageId: "seed", network: "erc20", transactionHash: "a".repeat(64) })).status, 400, "Ethereum hashes need 0x");
  const eth = await member("/api/orders/manual", { packageId: "seed", network: "erc20", transactionHash: `0x${"c".repeat(64)}` });
  assert.equal(eth.status, 201);
  assert.equal(eth.body.order.network, "erc20");
  assert.equal((await member("/api/orders/manual", { packageId: "seed", network: "solana", transactionHash: `0x${"d".repeat(64)}` })).status, 400, "Solana signatures are base58");
  const sol = await member("/api/orders/manual", { packageId: "path", network: "solana", transactionHash: "5".repeat(40) + "Kj8Hq2x".repeat(6) + "abc" });
  assert.equal(sol.status, 201);
  assert.equal((await member("/api/orders/manual", { packageId: "seed", network: "polygon", transactionHash: `0x${"e".repeat(64)}` })).status, 400);
  const before = (await member("/api/member/me")).body.member.balance;
  assert.equal((await owner(`/api/admin/orders/${sol.body.order.id}/decision`, { decision: "approve" })).status, 200);
  assert.ok((await member("/api/member/me")).body.member.balance >= before + 50);
});
