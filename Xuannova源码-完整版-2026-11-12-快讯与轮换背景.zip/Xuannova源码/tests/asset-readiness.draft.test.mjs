import test from "node:test";
import assert from "node:assert/strict";
import {requireReadyAsset} from "../worker/asset-readiness.draft.ts";
const base={chain:"bsc",symbol:"TEST",address:"0x1111111111111111111111111111111111111111",decimals:18,evidence:{identityVerified:true,decimalsVerified:true,transferBehavior:"standard",routeVerified:true,enabled:true}};
test("allows only an explicitly reviewed and enabled asset",()=>{
 assert.deepEqual(requireReadyAsset(base),base);
 for(const patch of [{identityVerified:false},{decimalsVerified:false},{routeVerified:false},{enabled:false},{transferBehavior:"unknown"},{transferBehavior:"taxed"}])assert.throws(()=>requireReadyAsset({...base,evidence:{...base.evidence,...patch}}),/ASSET_NOT_APPROVED/);
 assert.throws(()=>requireReadyAsset({...base,address:null}),/ASSET_CONFIGURATION_INCOMPLETE/);
 assert.throws(()=>requireReadyAsset({...base,address:"0x0000000000000000000000000000000000000000"}),/INVALID_ASSET_ADDRESS/);
});
