import assert from "node:assert/strict";
import test from "node:test";
import { classicalWorks, coversAllStudyMethods } from "../app/library-catalogue.ts";

test("catalogue covers every institute study method with public sources", () => {
  assert.equal(classicalWorks.length, 23, "the shelf keeps 23 Eastern classics, all readable on site");
  assert.equal(coversAllStudyMethods(), true, "every chart and toolkit method needs a reading path");
  assert.ok(classicalWorks.every((work) => work.sourceUrl.startsWith("https://")), "each record needs a safe public source link");
});

test("catalogue records contain display and reading details", () => {
  assert.ok(classicalWorks.every((work) => work.originalTitle && work.title && work.description && work.cover && work.tags.length));
});
