import assert from "node:assert/strict";
import test from "node:test";

const { dailyColor, shades, elementQuotes, elementNames, reasonText, solarBirthIso } = await import("../app/daily-color.ts");
const { actionGuide } = await import("../app/almanac-actions.ts");
const { almanacDay, shiftIso } = await import("../app/almanac.ts");
const locales = ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"];
const generates = { wood: "fire", fire: "earth", earth: "metal", metal: "water", water: "wood" };
const controls = { wood: "earth", fire: "metal", earth: "water", metal: "wood", water: "fire" };

test("daily colour follows the five-element rule for every relation", () => {
  let iso = "2026-11-01";
  const seen = new Set();
  for (let i = 0; i < 30; i += 1, iso = shiftIso(iso, 1)) {
    const c = dailyColor("1990-05-17", iso);
    const parent = Object.keys(generates).find((e) => generates[e] === c.dayMaster);
    let expected;
    if (generates[c.today] === c.dayMaster) expected = c.dayMaster;
    else if (c.today === c.dayMaster) expected = generates[c.dayMaster];
    else if (generates[c.dayMaster] === c.today) expected = parent;
    else if (controls[c.dayMaster] === c.today) expected = c.dayMaster;
    else expected = parent;
    assert.equal(c.lucky, expected, iso);
    assert.ok(shades[c.lucky].includes(c.shade));
    // The second shade comes from the supporting element (the day master itself, or its resource).
    const secondEl = c.lucky === c.dayMaster ? parent : c.dayMaster;
    assert.ok(shades[secondEl].includes(c.second));
    assert.equal(controls[c.avoid], c.dayMaster);
    seen.add(c.reason);
  }
  assert.equal(seen.size, 3);
});

test("the same birth date and day always give the same colour", () => {
  assert.deepEqual(dailyColor("1988-02-29", "2026-11-08"), dailyColor("1988-02-29", "2026-11-08"));
});

test("every colour, quote and reason is written in all seven languages", () => {
  for (const element of Object.keys(shades)) {
    for (const shade of shades[element]) { assert.match(shade.hex, /^#[0-9A-F]{6}$/i); for (const l of locales) assert.ok(shade.name[l]); }
    for (const l of locales) { assert.ok(elementQuotes[element].reading[l]); assert.ok(elementNames[element][l]); }
  }
  for (const key of Object.keys(reasonText)) for (const l of locales) assert.ok(reasonText[key][l].includes("{color}"));
});

test("action guide turns almanac terms into modern actions, without funeral entries", () => {
  const guide = actionGuide({ yi: ["安葬", "交易", "立券", "开市", "出行"], ji: ["嫁娶", "词讼"] }, "en");
  assert.deepEqual(guide.suitable, ["Business talks & contracts", "Launches & openings", "Travel & new posts"]);
  assert.deepEqual(guide.avoid, ["Big commitments", "Arguments & lawsuits"]);
  const empty = actionGuide({ yi: ["诸事不宜"], ji: ["安葬"] }, "zh-Hans");
  assert.deepEqual(empty, { suitable: ["休养生息、按部就班"], avoid: ["冲动决定"] });
});

test("a year of real days always yields at least one action each side in every language", () => {
  let iso = "2026-01-01";
  for (let i = 0; i < 365; i += 1, iso = shiftIso(iso, 1)) {
    const day = almanacDay(iso);
    for (const l of locales) { const g = actionGuide(day, l); assert.ok(g.suitable.length >= 1 && g.suitable.length <= 3 && g.avoid.length >= 1, iso); }
  }
});

test("the shared profile birth date works for solar and lunar dates", () => {
  assert.equal(solarBirthIso("1990-05-17", "solar"), "1990-05-17");
  assert.equal(solarBirthIso("1990-04-23", "lunar"), "1990-05-17");
  assert.equal(solarBirthIso("2020-04-01", "lunar", true), "2020-05-23");
  assert.equal(solarBirthIso("bad", "solar"), null);
});
