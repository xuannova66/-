// 普通版 / 专业版 term notes: every term has a plain gloss and an explanation in all 7 languages; terms are found in
// reading text; Chinese chart values (Ten Gods) map to their gloss; country-level places don't count as a city.
import assert from "node:assert/strict";
import test from "node:test";

const { glossary, splitTerms, shortGloss } = await import("../app/glossary.ts");
const { normalizeGeocodingResults } = await import("../app/geocoding.ts");
const locales = ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"];

test("every term has names, a plain gloss and an explanation in all seven languages", () => {
  assert.ok(glossary.length >= 40, `only ${glossary.length} terms`);
  for (const entry of glossary) {
    for (const locale of locales) {
      assert.ok(entry.names[locale]?.length, `${entry.names.en[0]} has no ${locale} name`);
      assert.ok(entry.tip[locale]?.trim(), `${entry.names.en[0]} has no ${locale} tip`);
      assert.ok(entry.short?.[locale]?.trim(), `${entry.names.en[0]} has no ${locale} gloss`);
      // One-character names would match inside unrelated words.
      for (const name of entry.names[locale]) assert.ok([...name].length >= 2, `${locale} name "${name}" is too short`);
    }
  }
});

test("terms in a reading are found once each, with their gloss", () => {
  const parts = splitTerms("日主丙火，月令见七杀，又逢正官；七杀再现。", "zh-Hans");
  const terms = parts.filter((part) => typeof part !== "string");
  assert.deepEqual(terms.map((part) => part.term), ["日主", "七杀", "正官"]);
  assert.equal(terms[1].short, "压力、挑战");
  assert.equal(parts.map((part) => (typeof part === "string" ? part : part.term)).join(""), "日主丙火，月令见七杀，又逢正官；七杀再现。");
  const en = splitTerms("Your Day Master meets the Direct Officer and a Peach Blossom star.", "en").filter((part) => typeof part !== "string");
  assert.deepEqual(en.map((part) => part.term), ["Day Master", "Direct Officer", "Peach Blossom"]);
});

test("chart values written in Chinese get their gloss in each language", () => {
  assert.equal(shortGloss("正官", "zh-Hans"), "规矩、责任、名誉");
  assert.equal(shortGloss("七殺", "zh-Hant"), "壓力、挑戰");
  assert.equal(shortGloss("偏印", "en"), "intuition, unusual learning");
  assert.equal(shortGloss("not a term", "en"), null);
});

test("geocoding keeps the place type so a country is not taken for a city", () => {
  const [city, country] = normalizeGeocodingResults({ results: [
    { id: 1, name: "Guangzhou", country: "China", latitude: 23.1, longitude: 113.3, timezone: "Asia/Shanghai", feature_code: "PPLA" },
    { id: 2, name: "Malaysia", country: "Malaysia", latitude: 4.5, longitude: 102, timezone: "Asia/Kuala_Lumpur", feature_code: "PCLI" },
  ] });
  assert.equal(city.featureCode, "PPLA");
  assert.equal(country.featureCode, "PCLI");
});

test("everyday words that look like terms get no note", () => {
  const terms = (text, locale) => splitTerms(text, locale).filter((part) => typeof part !== "string").map((part) => part.term);
  assert.deepEqual(terms("상관없이 지지해 주는 친구가 있어요.", "ko"), []);
  assert.deepEqual(terms("월주에 상관이 있고 지지에 화가 많습니다.", "ko"), ["상관", "지지"]);
  assert.deepEqual(terms("做事格局要大，可以比肩前辈。", "zh-Hans"), []);
  assert.deepEqual(terms("这张盘的格局是正官格，年柱见比肩。", "zh-Hans"), ["格局", "正官", "比肩"]);
  assert.deepEqual(terms("Companionship matters; the Companion star sits in the year pillar.", "en"), ["Companion"]);
});
