import test from "node:test";
import assert from "node:assert/strict";
import { keccak256, toBytes } from "viem";
import { inspectTronDirectPayment } from "../worker/tron-direct-payment.draft.ts";

const expected = { txId: "a".repeat(64), buyerHex: `41${"11".repeat(20)}`, recipientHex: `41${"22".repeat(20)}`, tokenHex: `41${"33".repeat(20)}`, amountUnits: 4990000n, orderReference: "b".repeat(64) };
const topic = (hex) => `${"0".repeat(24)}${hex.slice(2)}`;
const body = { txID: expected.txId, raw_data: { data: expected.orderReference, contract: [{ type: "TriggerSmartContract", parameter: { value: { owner_address: expected.buyerHex, contract_address: expected.tokenHex } } }] } };
const event = { address: expected.tokenHex.slice(2), topics: [keccak256(toBytes("Transfer(address,address,uint256)")).slice(2), topic(expected.buyerHex), topic(expected.recipientHex)], data: expected.amountUnits.toString(16).padStart(64, "0") };
const receipt = { id: expected.txId, receipt: { result: "SUCCESS" }, log: [event] };

test("requires a solidified, successful, unique direct TRC20 payment bound to the order reference", () => {
  assert.equal(inspectTronDirectPayment(body, receipt, true, expected).logIndex, 0);
  assert.throws(() => inspectTronDirectPayment(body, receipt, false, expected));
  assert.throws(() => inspectTronDirectPayment(body, { ...receipt, receipt: { result: "REVERT" } }, true, expected));
  for (const override of [{ buyerHex: `41${"44".repeat(20)}` }, { recipientHex: `41${"44".repeat(20)}` }, { tokenHex: `41${"44".repeat(20)}` }, { amountUnits: 1n }, { orderReference: "c".repeat(64) }]) assert.throws(() => inspectTronDirectPayment(body, receipt, true, { ...expected, ...override }));
  assert.throws(() => inspectTronDirectPayment(body, { ...receipt, log: [event, event] }, true, expected));
  assert.throws(() => inspectTronDirectPayment({ ...body, raw_data: { ...body.raw_data, contract: [] } }, receipt, true, expected));
});
