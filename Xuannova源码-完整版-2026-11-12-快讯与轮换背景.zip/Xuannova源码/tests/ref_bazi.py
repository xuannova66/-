"""Reference BaZi derivations from four pillars (table lookups only)."""
G = "甲乙丙丁戊己庚辛壬癸"
Z = "子丑寅卯辰巳午未申酉戌亥"
G_EL = dict(zip(G, "木木火火土土金金水水"))
G_YANG = {g: i % 2 == 0 for i, g in enumerate(G)}
Z_EL = dict(zip(Z, "水土木木土火火土金金土水"))
HIDDEN = {"子": "癸", "丑": "己癸辛", "寅": "甲丙戊", "卯": "乙", "辰": "戊乙癸", "巳": "丙庚戊",
          "午": "丁己", "未": "己丁乙", "申": "庚壬戊", "酉": "辛", "戌": "戊辛丁", "亥": "壬甲"}
GEN = {"木": "火", "火": "土", "土": "金", "金": "水", "水": "木"}
CTRL = {"木": "土", "土": "水", "水": "火", "火": "金", "金": "木"}

def ten_god(day, other):
    a, b = G_EL[day], G_EL[other]
    same = G_YANG[day] == G_YANG[other]
    if a == b: return "比肩" if same else "劫财"
    if GEN[a] == b: return "食神" if same else "伤官"
    if CTRL[a] == b: return "偏财" if same else "正财"
    if CTRL[b] == a: return "七杀" if same else "正官"
    if GEN[b] == a: return "偏印" if same else "正印"

NAYIN_LIST = ["海中金","炉中火","大林木","路旁土","剑锋金","山头火","涧下水","城头土","白蜡金","杨柳木",
              "泉中水","屋上土","霹雳火","松柏木","长流水","沙中金","山下火","平地木","壁上土","金箔金",
              "覆灯火","天河水","大驿土","钗钏金","桑柘木","大溪水","沙中土","天上火","石榴木","大海水"]
def jiazi_index(gz):
    g, z = G.index(gz[0]), Z.index(gz[1])
    for i in range(60):
        if i % 10 == g and i % 12 == z: return i
def nayin(gz): return NAYIN_LIST[jiazi_index(gz) // 2]
def gz_of(i): return G[i % 10] + Z[i % 12]

STAGES = "长生 沐浴 冠带 临官 帝旺 衰 病 死 墓 绝 胎 养".split()
CS = {"甲": "亥", "丙": "寅", "戊": "寅", "庚": "巳", "壬": "申", "乙": "午", "丁": "酉", "己": "酉", "辛": "子", "癸": "卯"}
def life_stage(day, branch):
    s = Z.index(CS[day]); b = Z.index(branch)
    off = (b - s) % 12 if G_YANG[day] else (s - b) % 12
    return STAGES[off]

def dayun(year_gz, month_gz, male, n=8):
    forward = (G_YANG[year_gz[0]] and male) or (not G_YANG[year_gz[0]] and not male)
    i = jiazi_index(month_gz); step = 1 if forward else -1
    return ("顺" if forward else "逆"), [gz_of(i + step * k) for k in range(1, n + 1)]

def year_gz(y):  # ganzhi of a Gregorian year (after Lichun)
    return gz_of((y - 4) % 60)

def palace_stem_yin(year_stem):  # 五虎遁: stem of 寅 palace
    return {"甲": "丙", "己": "丙", "乙": "戊", "庚": "戊", "丙": "庚", "辛": "庚", "丁": "壬", "壬": "壬", "戊": "甲", "癸": "甲"}[year_stem]

TRIG = {"111": "乾", "011": "兑", "101": "离", "001": "震", "110": "巽", "010": "坎", "100": "艮", "000": "坤"}
def trigram(l1, l2, l3):  # bottom->top, 1 = yang ; key read top->bottom
    return TRIG[f"{l3}{l2}{l1}"]

def full(p, male=True, birth_year=None):
    y, m, d, h = p
    out = {"ten_god_stem": [ten_god(d[0], s[0]) if i != 2 else "日主" for i, s in enumerate(p)],
           "nayin": [nayin(x) for x in p],
           "life_stage": [life_stage(d[0], x[1]) for x in p],
           "hidden": [HIDDEN[x[1]] for x in p],
           "dayun": dayun(y, m, male)}
    if birth_year: out["liunian0"] = year_gz(birth_year)
    return out

if __name__ == "__main__":
    print(full(["甲戌", "壬申", "丙子", "甲午"], True, 1994))
    print(trigram(1, 0, 0), trigram(1, 0, 0))
