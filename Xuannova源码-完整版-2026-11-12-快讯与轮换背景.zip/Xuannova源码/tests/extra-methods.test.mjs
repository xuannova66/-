import test from "node:test";
import assert from "node:assert/strict";

const root = process.env.TS_ROOT ?? process.cwd();
const { jinKouJue, heLuo, taiYiYear, tieBan } = await import(`${root}/app/metaphysics/extra-methods.ts`);
const { liurenChart } = await import(`${root}/app/metaphysics/liuren.ts`);
const { createCompleteChart } = await import(`${root}/app/chart-model.ts`);
const { methodCategories, STUDY_METHOD_COUNT, TOOLKIT_COUNT } = await import(`${root}/app/method-categories.ts`);
const { toolkitItems, routeDefinitions } = await import(`${root}/app/study-suite.ts`);

test("金口诀: four positions follow the Liu Ren plate and the Five Rats rule", () => {
  const params = { qi: "霜降", dayPillar: "丙申", hourBranch: "亥", monthBranch: "戌", difen: "卯" };
  const lesson = jinKouJue(params);
  const plate = liurenChart(params);
  const seat = plate.positions.find((position) => position.earth === "卯");
  assert.deepEqual(lesson.positions.map((position) => position.role), ["人元", "贵神", "将神", "地分"]);
  assert.equal(lesson.positions[0].value, "辛", "丙 day: 戊子 starts the count, 卯 is the fourth branch → 辛");
  assert.equal(lesson.positions[1].value, seat.general);
  assert.equal(lesson.positions[2].value, seat.sky);
  assert.equal(lesson.positions[3].value, "卯");
  assert.ok(["人元", "贵神", "将神", "地分"].includes(lesson.use));
  // Without a chosen direction the hour branch is the earth position.
  assert.equal(jinKouJue({ ...params, difen: undefined }).difen, "亥");
});

test("河洛理数: heaven and earth numbers, hexagrams and life periods", () => {
  const chart = heLuo({ pillars: ["庚午", "辛巳", "丙申", "己亥"], gender: "yang", hourBranch: "亥", birthYear: 1990, currentYear: 2026 });
  const odd = chart.numbers.filter((value) => value % 2 === 1).reduce((a, b) => a + b, 0);
  const even = chart.numbers.filter((value) => value % 2 === 0).reduce((a, b) => a + b, 0);
  assert.equal(chart.heavenTotal, odd);
  assert.equal(chart.earthTotal, even);
  assert.ok(chart.heavenNumber >= 1 && chart.heavenNumber <= 9);
  assert.ok(chart.earthNumber >= 1 && chart.earthNumber <= 9);
  assert.equal(chart.periods.length, 12);
  for (const period of chart.periods) assert.equal(period.to - period.from + 1, period.yang ? 9 : 6);
  assert.equal(chart.currentAge, 37);
  assert.ok(chart.current && chart.currentAge >= chart.current.from && chart.currentAge <= chart.current.to);
});

test("太乙神数: three years per palace, never the centre", () => {
  const year = taiYiYear(2026);
  assert.equal(year.accumulated, 10155943);
  assert.equal(year.palace, 3);
  assert.equal(year.yearInPalace, 1);
  const palaces = Array.from({ length: 24 }, (_, index) => taiYiYear(2000 + index).palace);
  assert.ok(!palaces.includes(5));
  assert.equal(new Set(palaces).size, 8);
  assert.equal(taiYiYear(2024).palace, taiYiYear(2048).palace, "24-year round");
});

test("铁板神数: Tai Xuan totals and the birth quarter", () => {
  const chart = tieBan({ pillars: ["庚午", "辛巳", "丙申", "己亥"], birthTime: "21:40" });
  assert.equal(chart.stemTotal, 8 + 7 + 7 + 9);
  assert.equal(chart.branchTotal, 9 + 4 + 7 + 4);
  assert.equal(chart.hourBranch, "亥");
  assert.equal(chart.quarter, 3);
  assert.equal(tieBan({ pillars: ["庚午", "辛巳", "丙申", "甲子"], birthTime: "23:05" }).quarter, 1);
  assert.equal(tieBan({ pillars: ["庚午", "辛巳", "丙申", "甲子"], birthTime: "00:59" }).quarter, 8);
});

test("new study methods build complete charts", () => {
  for (const module of ["meihua", "jinkoujue", "heluo", "tieban", "taiyi", "zhuzhai"]) {
    const chart = createCompleteChart({ birthDate: "1990-05-20", birthTime: "21:40", calendar: "solar", focus: "Career", name: "", companionName: "", module, version: 1, place: "Global", difen: "卯", houseSitting: "South" });
    assert.ok(chart.board.cells.length >= 2, module);
    assert.ok(chart.sections.length >= 3, module);
  }
  const taiyi = createCompleteChart({ birthDate: "2026-11-05", birthTime: "12:00", calendar: "solar", focus: "", name: "", companionName: "", module: "taiyi", version: 1 });
  assert.equal(taiyi.board.cells.find((cell) => cell.active).id, "palace-3");
  const january = createCompleteChart({ birthDate: "2027-01-20", birthTime: "12:00", calendar: "solar", focus: "", name: "", companionName: "", module: "taiyi", version: 1 });
  assert.equal(january.board.cells.find((cell) => cell.active).id, "palace-3", "before Start of Spring the year is still 2026");
});

test("method categories cover every study method and toolkit reference once", () => {
  const routes = methodCategories.flatMap((category) => category.routes);
  const tools = methodCategories.flatMap((category) => category.tools);
  assert.equal(STUDY_METHOD_COUNT, 22);
  assert.equal(TOOLKIT_COUNT, 7);
  assert.equal(new Set(routes).size, routes.length);
  for (const definition of routeDefinitions) assert.ok(routes.includes(definition.route), definition.route);
  assert.deepEqual([...tools].sort(), toolkitItems.map((item) => item.key).sort());
});
