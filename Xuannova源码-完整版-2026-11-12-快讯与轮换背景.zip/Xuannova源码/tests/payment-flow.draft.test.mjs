import test from "node:test";
import assert from "node:assert/strict";
import { PaymentFlowDraft } from "../app/payment-flow.draft.ts";
const selection={network:"bsc",asset:"BNB",member:"member1",wallet:"wallet1"};
test("invalidates delayed quotes after selection, chain or wallet changes",()=>{
 const flow=new PaymentFlowDraft(); const old=flow.select(selection); const next=flow.select({...selection,asset:"USDT"});
 assert.throws(()=>flow.setQuote({selectionVersion:old,expiresAt:200,id:"q"},100),/STALE_SELECTION/);
 flow.setQuote({selectionVersion:next,expiresAt:200,id:"q"},100); flow.invalidateWallet();
 assert.throws(()=>flow.begin(101),/QUOTE_REQUIRED/);
 assert.throws(()=>flow.setQuote({selectionVersion:flow.snapshot().version,expiresAt:200,id:"q3"},101),/STALE_SELECTION/);
});
test("wallet change during a prompt requires a new selection after cancellation",()=>{
 const flow=new PaymentFlowDraft();const v=flow.select(selection);flow.setQuote({selectionVersion:v,expiresAt:200,id:"q"},100);
 flow.begin(101);flow.invalidateWallet();flow.cancelBeforeBroadcast();
 assert.throws(()=>flow.setQuote({selectionVersion:flow.snapshot().version,expiresAt:200,id:"q2"},102),/STALE_SELECTION/);
 const fresh=flow.select({...selection,wallet:"wallet2"});flow.setQuote({selectionVersion:fresh,expiresAt:200,id:"q3"},102);
 assert.equal(flow.begin(103).selection.wallet,"wallet2");
});
test("blocks duplicate payments, retains pending hash, and only resolves confirmed outcomes",()=>{
 const flow=new PaymentFlowDraft(); const v=flow.select(selection); flow.setQuote({selectionVersion:v,expiresAt:200,id:"q"},100);
 flow.begin(101); assert.throws(()=>flow.begin(101),/QUOTE_REQUIRED/); flow.invalidateWallet();
 assert.throws(()=>flow.select(selection),/PAYMENT_PENDING/); flow.submitted("hash"); flow.invalidateWallet();
 assert.equal(flow.snapshot().transactionId,"hash"); assert.throws(()=>flow.cancelBeforeBroadcast(),/PAYMENT_NOT_CANCELABLE/);
 assert.throws(()=>flow.resolveSubmitted("pending"),/INVALID_PAYMENT_OUTCOME/); flow.resolveSubmitted("credited"); assert.equal(flow.snapshot().phase,"completed");
});
test("rejects expired quotes and requests a new quote after a definite pre-broadcast cancellation",()=>{
 const flow=new PaymentFlowDraft(); const v=flow.select(selection); flow.setQuote({selectionVersion:v,expiresAt:200,id:"q"},100);
 assert.throws(()=>flow.begin(200),/QUOTE_EXPIRED/); const next=flow.snapshot().version;
 flow.setQuote({selectionVersion:next,expiresAt:300,id:"q2"},200); flow.begin(201); flow.cancelBeforeBroadcast();
 assert.throws(()=>flow.begin(202),/QUOTE_REQUIRED/);
});
