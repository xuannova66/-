// 我的静室: create, invite, join by link, members by 道号 only, consent-gated chart sharing, owner controls.
import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import test from "node:test";

const { openDatabase } = await import("../server/sqlite-db.ts");
const { handleCommerceApi } = await import("../worker/commerce-api.ts");
const ORIGIN = "https://xuannova.test";

function freshEnv() {
  const db = openDatabase(":memory:");
  for (const file of readdirSync(new URL("../migrations/", import.meta.url)).filter((name) => name.endsWith(".sql")).sort()) db.raw.exec(readFileSync(new URL(`../migrations/${file}`, import.meta.url), "utf8"));
  return { DB: db, SESSION_SECRET: "test-session-signing-key-that-is-long-enough" };
}
function client(env, device) {
  const jar = new Map([["xn_device", device]]);
  return async (path, body, method = body === undefined ? "GET" : "POST") => {
    const headers = { origin: ORIGIN, cookie: [...jar].map(([k, v]) => `${k}=${v}`).join("; "), "content-type": "application/json" };
    const response = await handleCommerceApi(new Request(`${ORIGIN}${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) }), env);
    for (const cookie of response.headers.getSetCookie?.() ?? []) { const [pair] = cookie.split(";"); const [name, value] = pair.split("="); if (value) jar.set(name, value); else jar.delete(name); }
    return { status: response.status, body: await response.json() };
  };
}

test("owner creates a room, a friend joins by link, a consented chart is shared, owner controls the room", async () => {
  const env = freshEnv();
  const owner = client(env, "device-room-00000000000001");
  const friend = client(env, "device-room-00000000000002");
  const stranger = client(env, "device-room-00000000000003");
  for (const [c, email] of [[owner, "owner@example.com"], [friend, "friend@example.com"], [stranger, "stranger@example.com"]]) assert.equal((await c("/api/auth/register", { email, password: "secret-pass" })).status, 201);

  assert.equal((await client(env, "device-room-anon-000000001")("/api/rooms")).status, 401);
  const created = await owner("/api/rooms/create", {});
  assert.equal(created.status, 200);
  const room = created.body.room;
  assert.match(room.name, /的静室$/);
  assert.match(room.inviteToken, /^[0-9a-f]{24}$/);
  assert.equal((await owner("/api/rooms/create", {})).body.room.id, room.id, "one room per owner");

  const preview = await client(env, "device-room-anon-000000002")(`/api/rooms/invite/${room.inviteToken}`);
  assert.equal(preview.body.room.name, room.name);
  assert.equal(preview.body.room.members, 1);

  assert.equal((await stranger(`/api/rooms/${room.id}`)).status, 404, "not a member");
  const joined = await friend("/api/rooms/join", { token: room.inviteToken });
  assert.equal(joined.status, 200);
  assert.equal(joined.body.room.members.length, 2);
  assert.equal(joined.body.room.inviteToken, null, "only the owner sees the link");
  assert.ok(joined.body.room.members.every((m) => !("email" in m)));
  assert.ok(!JSON.stringify(joined.body).includes("owner@example.com"), "emails never reach the room");

  // Share a saved profile: consent required, only own profiles.
  const saved = await friend("/api/member/profiles", { label: "妈妈", relation: "parent", name: "妈妈", gender: "yin", calendar: "solar", date: "1965-03-08", time: "06:30", place: "Hanoi", consent: true });
  assert.equal(saved.status, 200, JSON.stringify(saved.body));
  const profileId = saved.body.profiles.find((p) => p.label === "妈妈").id;
  assert.equal((await friend(`/api/rooms/${room.id}/share`, { profileId })).status, 400, "consent");
  assert.equal((await owner(`/api/rooms/${room.id}/share`, { profileId, consent: true })).status, 404, "someone else's profile");
  const shared = await friend(`/api/rooms/${room.id}/share`, { profileId, consent: true });
  assert.equal(shared.status, 200);
  assert.equal(shared.body.room.shares[0].chart.date, "1965-03-08");
  assert.equal(shared.body.room.shares[0].mine, true);
  const seen = await owner(`/api/rooms/${room.id}`);
  assert.equal(seen.body.room.shares.length, 1);
  assert.equal(seen.body.room.shares[0].mine, false);

  // Names: chosen 道号 filtered; owner rename; heartbeat marks online.
  assert.equal((await friend(`/api/rooms/${room.id}/me`, { daoName: "加我微信" })).status, 400);
  assert.equal((await friend(`/api/rooms/${room.id}/me`, { daoName: "竹溪" })).body.room.members.find((m) => m.self).daoName, "竹溪");
  assert.equal((await friend(`/api/rooms/${room.id}/rename`, { name: "x" })).status, 403);
  assert.equal((await owner(`/api/rooms/${room.id}/rename`, { name: "一家人" })).body.room.name, "一家人");
  assert.equal((await owner(`/api/rooms/${room.id}/heartbeat`, {})).body.room.members.find((m) => m.self).online, true);

  // Reset link: the old link stops working.
  const old = room.inviteToken;
  await owner(`/api/rooms/${room.id}/reset-link`, {});
  assert.equal((await stranger("/api/rooms/join", { token: old })).status, 404);

  // Owner removes the friend: their shares go too.
  const friendId = seen.body.room.members.find((m) => !m.self).id;
  const removed = await owner(`/api/rooms/${room.id}/remove`, { memberId: friendId });
  assert.equal(removed.body.room.members.length, 1);
  assert.equal(removed.body.room.shares.length, 0);
  assert.equal((await friend(`/api/rooms/${room.id}`)).status, 404);

  // Cross-site requests are refused; closing the room deletes it.
  assert.equal((await owner(`/api/rooms/${room.id}/leave`, {})).body.rooms.length, 0);
  assert.equal((await owner(`/api/rooms/${room.id}`)).status, 404);
});
