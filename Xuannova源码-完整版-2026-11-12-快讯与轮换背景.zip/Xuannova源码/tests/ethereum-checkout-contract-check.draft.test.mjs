import test from "node:test";
import assert from "node:assert/strict";
import {getFunctionSelector} from "viem";
import {verifyEthereumCheckoutDraft} from "../app/ethereum-checkout-contract-check.draft.ts";
const buyer="0x1111111111111111111111111111111111111111",stable="0x2222222222222222222222222222222222222222",checkout="0x3333333333333333333333333333333333333333",recipient="0x84F33708ab4b7DEFd9Be5EC50911797E34009caA",word=x=>`0x${x.replace(/^0x/,"").toLowerCase().padStart(64,"0")}`;
function provider({token=stable,treasury=recipient,decimals="06",code="0x6000"}={}){return{request:async({method,params})=>{if(method==="eth_chainId")return "0x1";if(method==="eth_accounts")return [buyer];if(method==="eth_getCode")return code;if(method==="eth_call"){const data=params[0].data;if(data===getFunctionSelector("settlement()"))return word(token);if(data===getFunctionSelector("treasury()"))return word(treasury);if(data===getFunctionSelector("decimals()"))return word(decimals);}throw Error("unexpected");}};}
const session={address:buyer,network:"ethereum",chainId:"0x1"};
test("preflight checks configured token, recipient, decimals and deployed code",async()=>{
 await verifyEthereumCheckoutDraft({provider:provider(),session,checkout,settlement:stable});
 for(const override of [{token:buyer},{treasury:buyer},{decimals:"12"}])await assert.rejects(verifyEthereumCheckoutDraft({provider:provider(override),session,checkout,settlement:stable}),/CHECKOUT_CONFIGURATION_MISMATCH/);
 await assert.rejects(verifyEthereumCheckoutDraft({provider:provider({code:"0x"}),session,checkout,settlement:stable}),/CONTRACT_CODE_MISSING/);
});
