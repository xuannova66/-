// Growth features against a real SQLite database: streamed readings (free part only for previews),
// the teaser line, first-purchase bonus, daily-bonus notice, reminder e-mails and hiding history items.
import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import test from "node:test";

const { openDatabase } = await import("../server/sqlite-db.ts");
const { handleCommerceApi, sendDailyReminders } = await import("../worker/commerce-api.ts");

const ORIGIN = "https://xuannova.test";
const reading = {
  title: "Reading", conclusion: "One plain sentence.", keyPoints: ["P1", "P2", "P3"], summary: "Summary text.", teaser: "Section 4 looks at the year 2027.",
  sections: [1, 2, 3, 4, 5, 6].map((n) => ({ title: `Section ${n}`, text: `Body of section ${n}.\n\nSecond paragraph ${n}.` })),
  followUps: ["F1", "F2", "F3"],
};
const sentMail = [];
const realFetch = globalThis.fetch;
globalThis.fetch = async (url, init) => {
  if (String(url).startsWith("https://api.deepseek.com")) {
    const body = JSON.parse(init.body);
    const system = body.messages[0].content;
    // BaZi deep reading: two halves requested at the same time.
    const deepFirst = { title: "Deep", conclusion: "Deep conclusion.", keyPoints: ["D1", "D2", "D3"], summary: "Deep summary.", teaser: "Section 9 covers the current cycle.", sections: [1, 2, 3, 4, 5].map((n) => ({ title: `Deep ${n}`, text: `Deep body ${n}.\n\nMore ${n}.` })) };
    const deepSecond = { sections: [6, 7, 8, 9, 10].map((n) => ({ title: `Deep ${n}`, text: `Deep body ${n}.\n\nMore ${n}.` })), followUps: ["G1", "G2", "G3"] };
    const content = system.includes("This is the second half") ? JSON.stringify(deepSecond) : system.includes("Write exactly 5 sections") ? JSON.stringify(deepFirst) : JSON.stringify(reading);
    if (body.stream) {
      // Server-sent events in small pieces, like the provider's streaming reply.
      const encoder = new TextEncoder();
      const stream = new ReadableStream({ async start(controller) {
        for (let i = 0; i < content.length; i += 25) { controller.enqueue(encoder.encode(`data: ${JSON.stringify({ choices: [{ delta: { content: content.slice(i, i + 25) } }] })}\n\n`)); await new Promise((r) => setTimeout(r, 45)); }
        controller.enqueue(encoder.encode("data: [DONE]\n\n")); controller.close();
      } });
      return new Response(stream, { status: 200, headers: { "content-type": "text/event-stream" } });
    }
    return new Response(JSON.stringify({ choices: [{ message: { content } }] }), { status: 200 });
  }
  if (String(url).startsWith("https://api.resend.com")) { sentMail.push(JSON.parse(init.body)); return new Response("{}", { status: 200 }); }
  return realFetch(url, init);
};

function freshEnv() {
  const db = openDatabase(":memory:");
  for (const file of readdirSync(new URL("../migrations/", import.meta.url)).filter((name) => name.endsWith(".sql")).sort()) db.raw.exec(readFileSync(new URL(`../migrations/${file}`, import.meta.url), "utf8"));
  return { db, env: { DB: db, ADMIN_EMAILS: "owner@example.com", ADMIN_PASSWORD: "admin-password-123", SESSION_SECRET: "test-session-signing-key-that-is-long-enough", DEEPSEEK_API_KEY: "test-key", RESEND_API_KEY: "re_test", MAIL_FROM: "Xuannova <hello@xuannova.test>", SITE_URL: "https://xuannova.test" } };
}

function client(env, device) {
  const jar = new Map([["xn_device", device], ["xn_tz", "Asia%2FSaigon"]]);
  const raw = async (path, body, method = body === undefined ? "GET" : "POST") => {
    const headers = { origin: ORIGIN, cookie: [...jar].map(([k, v]) => `${k}=${v}`).join("; ") };
    if (body !== undefined) headers["content-type"] = "application/json";
    const response = await handleCommerceApi(new Request(`${ORIGIN}${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) }), env);
    for (const cookie of response.headers.getSetCookie?.() ?? []) { const [pair] = cookie.split(";"); const [name, value] = pair.split("="); if (value) jar.set(name, value); else jar.delete(name); }
    return response;
  };
  const call = async (path, body, method) => { const response = await raw(path, body, method); return { status: response.status, body: await response.json() }; };
  call.raw = raw;
  return call;
}

async function readEvents(response) {
  const text = await response.text();
  return text.split("\n\n").map((block) => block.split("\n").filter((line) => line.startsWith("data:")).map((line) => line.slice(5).trim()).join("")).filter(Boolean).map((data) => JSON.parse(data));
}

const chart = {
  calendar: { lunar: "一九九四年七月十二", naYin: "涧下水", solar: "1994-08-18 15:00:00" },
  pillars: ["甲戌", "壬申", "丙子", "丙申"],
  board: { kind: "pillars", label: "Four Pillars complete board", cells: [{ id: "pillar-0", title: "Year pillar", items: [{ label: "Ten God", value: "偏印" }] }] },
  sections: [{ id: "ten-gods", title: "Ten-God relationships", lead: "Local", items: [{ label: "Year pillar", value: "偏印" }] }],
  sourceFacts: ["Calculated solar/lunar conversion"],
  inputSummary: { focus: "", place: "Global", version: 1 },
};
const previewBody = { tool: "bazi", locale: "en", question: "What should I study next?", chart };

test("streamed free preview: parts appear while written, but only the free half ever leaves the server", async () => {
  const { env } = freshEnv();
  const browser = client(env, "device-stream0000000001");
  const response = await browser.raw("/api/readings/preview", { ...previewBody, stream: true });
  assert.match(response.headers.get("content-type"), /text\/event-stream/);
  const events = await readEvents(response);
  const partials = events.filter((event) => event.type === "partial");
  assert.ok(partials.length >= 2, `several partial updates (${partials.length})`);
  assert.ok(partials.some((event) => event.reading.conclusion === reading.conclusion), "the conclusion arrives before the end");
  const everything = JSON.stringify(events);
  assert.ok(!everything.includes("Body of section 2"), "locked sections never stream to a free preview");
  assert.ok(partials.every((event) => event.reading.sections.length <= 1));
  const done = events.at(-1);
  assert.equal(done.type, "done");
  assert.equal(done.status, 200);
  assert.equal(done.body.preview.teaser, reading.teaser, "the teaser is part of the free preview");
  assert.equal(done.body.preview.sections.length, 1);
  assert.deepEqual(done.body.lockedSections, ["Section 2", "Section 3", "Section 4", "Section 5", "Section 6"]);
});

test("streamed paid reading: the whole reading streams and credits are taken once at the end", async () => {
  const { env, db } = freshEnv();
  const browser = client(env, "device-stream0000000002");
  await browser("/api/auth/register", { email: "reader@example.com", password: "secret-pass" });
  await db.prepare("UPDATE members SET credits = 100 WHERE email = 'reader@example.com'").run();
  await browser("/api/readings/preview", previewBody); // uses the free preview
  const before = (await browser("/api/member/me")).body.member.balance;
  const events = await readEvents(await browser.raw("/api/readings/preview", { ...previewBody, pay: true, stream: true }));
  assert.ok(events.some((event) => event.type === "partial" && event.reading.sections.length > 1), "paid readings stream every section");
  const done = events.at(-1);
  assert.equal(done.status, 200);
  assert.equal(done.body.unlocked, true);
  assert.equal(done.body.response.sections.length, 6);
  assert.equal((await browser("/api/member/me")).body.member.balance, before - 20);
});

test("first-purchase bonus: +20 once after the first completed purchase, shown as a notice; offer flag clears", async () => {
  const { env, db } = freshEnv();
  const browser = client(env, "device-firstbuy00000001");
  await browser("/api/auth/register", { email: "buyer@example.com", password: "secret-pass" });
  const me0 = await browser("/api/member/me");
  assert.equal(me0.body.member.firstPurchaseOffer, true);
  const start = me0.body.member.balance;
  db.prepare("INSERT INTO payment_orders (id, member_id, package_id, amount_usdt, credits, network, transaction_hash, status, submitted_at) SELECT 'order-1', id, 'seed', '4.99', 20, 'bsc', ?, 'pending', ? FROM members WHERE email = 'buyer@example.com'").bind(`0x${"a".repeat(64)}`, new Date().toISOString()).run();
  db.prepare("UPDATE payment_orders SET status = 'approved', reviewed_at = ?, reviewed_by = 'test' WHERE id = 'order-1'").bind(new Date().toISOString()).run();
  const me1 = await browser("/api/member/me");
  assert.equal(me1.body.firstPurchaseBonus, 20);
  assert.equal(me1.body.member.balance, start + 20 + 20, "package credits plus the bonus");
  assert.equal(me1.body.member.firstPurchaseOffer, false);
  const me2 = await browser("/api/member/me");
  assert.equal(me2.body.firstPurchaseBonus, undefined, "only once");
  assert.equal(me2.body.member.balance, start + 40);
  const ledger = (await browser("/api/member/ledger")).body.entries.map((entry) => entry.reason);
  assert.ok(ledger.includes("first_purchase_bonus"));
});

test("daily bonus notice is reported on the request that adds it", async () => {
  const { env } = freshEnv();
  const browser = client(env, "device-dailynote0000001");
  const reg = await browser("/api/auth/register", { email: "daily@example.com", password: "secret-pass" });
  assert.equal(reg.status, 201);
  const me = await browser("/api/member/me");
  const again = await browser("/api/member/me");
  assert.ok(me.body.dailyBonusAdded === 5 || again.body.dailyBonusAdded === undefined, "added at most once per day");
  assert.equal(again.body.dailyBonusAdded, undefined);
});

test("daily reminder e-mails: opt in, one per local day from 08:00, unsubscribe link turns it off", async () => {
  const { env, db } = freshEnv();
  const browser = client(env, "device-reminder00000001");
  await browser("/api/auth/register", { email: "remind@example.com", password: "secret-pass" });
  assert.deepEqual((await browser("/api/member/reminders")).body, { enabled: false, solarTerms: false, hasEmail: true, mailConfigured: true });
  assert.equal((await browser("/api/member/reminders", { enabled: true, timezone: "Asia/Saigon", locale: "zh-Hans" })).body.enabled, true);
  sentMail.length = 0;
  // 06:00 in Saigon (23:00 UTC the day before): too early.
  assert.equal((await sendDailyReminders(env, { at: new Date("2026-11-02T23:00:00Z") })).sent, 0);
  // 09:00 in Saigon.
  assert.equal((await sendDailyReminders(env, { at: new Date("2026-11-03T02:00:00Z"), almanac: () => "2026-11-03 · 宜：出行" })).sent, 1);
  assert.equal(sentMail[0].to[0], "remind@example.com");
  assert.match(sentMail[0].subject, /5 积分/);
  assert.match(sentMail[0].text, /宜：出行/);
  assert.equal((await sendDailyReminders(env, { at: new Date("2026-11-03T05:00:00Z") })).sent, 0, "once per day");
  const token = (await db.prepare("SELECT token FROM daily_reminders").first()).token;
  assert.match(sentMail[0].text, new RegExp(token));
  const page = await handleCommerceApi(new Request(`${ORIGIN}/api/reminders/unsubscribe?token=${token}`), env);
  assert.equal(page.status, 200);
  assert.equal((await browser("/api/member/reminders")).body.enabled, false);
  assert.equal((await sendDailyReminders(env, { at: new Date("2026-11-04T02:00:00Z") })).sent, 0, "no mail after unsubscribing");
});

test("question history: members can remove one reading or clear the list; other members cannot", async () => {
  const { env, db } = freshEnv();
  const browser = client(env, "device-history000000001");
  await browser("/api/auth/register", { email: "hist@example.com", password: "secret-pass" });
  await db.prepare("UPDATE members SET credits = 100 WHERE email = 'hist@example.com'").run();
  await browser("/api/readings/preview", previewBody); // the day's free full BaZi reading is saved too
  await browser("/api/readings/preview", { ...previewBody, pay: true });
  await browser("/api/readings/preview", { ...previewBody, pay: true, question: "Second question?" });
  const list = (await browser("/api/member/interpretations")).body.interpretations;
  assert.equal(list.length, 3);
  const other = client(env, "device-history000000002");
  await other("/api/auth/register", { email: "other@example.com", password: "secret-pass" });
  assert.equal((await other(`/api/member/interpretations/${list[0].id}/hide`, {})).body.hidden, 0, "cannot hide someone else's reading");
  assert.equal((await browser(`/api/member/interpretations/${list[0].id}/hide`, {})).body.hidden, 1);
  assert.equal((await browser("/api/member/interpretations")).body.interpretations.length, 2);
  assert.equal((await browser("/api/member/interpretations/hide-all", {})).body.hidden, 2);
  assert.equal((await browser("/api/member/interpretations")).body.interpretations.length, 0);
});

test("BaZi deep reading: ten sections from two halves, first two free, 40 credits; follow-ups stay at 20", async () => {
  const { env, db } = freshEnv();
  const browser = client(env, "device-deepreading00001");
  const deepBody = { ...previewBody, tool: "detail" };
  const free = await browser("/api/readings/preview", deepBody);
  assert.equal(free.status, 200);
  assert.equal(free.body.cost, 40);
  assert.deepEqual(free.body.preview.sections.map((s) => s.title), ["Deep 1", "Deep 2"], "first two sections are free");
  assert.equal(free.body.lockedSections.length, 8);
  assert.ok(!JSON.stringify(free.body).includes("Deep body 3"), "the rest stays on the server");
  // Streamed free preview never carries second-half text either.
  const events = await readEvents(await browser.raw("/api/readings/preview", { ...deepBody, stream: true }));
  assert.ok(!JSON.stringify(events).includes("Deep body 6") && !JSON.stringify(events).includes("Deep body 3"));
  await browser("/api/auth/register", { email: "deep@example.com", password: "secret-pass" });
  await db.prepare("UPDATE members SET credits = 100 WHERE email = 'deep@example.com'").run();
  const before = (await browser("/api/member/me")).body.member.balance;
  const paid = await browser("/api/readings/preview", { ...deepBody, pay: true });
  assert.equal(paid.status, 200);
  assert.equal(paid.body.response.sections.length, 10);
  assert.deepEqual(paid.body.response.followUps, ["G1", "G2", "G3"]);
  assert.equal((await browser("/api/member/me")).body.member.balance, before - 40);
  // Unlocking a free deep preview also costs 40.
  const preview = await browser("/api/readings/preview", deepBody);
  const unlocked = await browser("/api/readings/unlock", { draftId: preview.body.draftId });
  assert.equal(unlocked.body.response.sections.length, 10);
  assert.equal((await browser("/api/member/me")).body.member.balance, before - 80);
  // A follow-up question on the deep chart costs the standard 20.
  const follow = await browser("/api/interpretations", { ...deepBody, mode: "conversation", question: "And next year?" });
  assert.equal(follow.status, 200);
  assert.equal((await browser("/api/member/me")).body.member.balance, before - 100);
});

test("library shelf: members favourite books and the last reading position is kept per member", async () => {
  const { env } = freshEnv();
  const guest = client(env, "device-libraryshelf0001");
  assert.equal((await guest("/api/member/library")).status, 401, "guests keep their place in the browser only");
  await guest("/api/auth/register", { email: "reader@example.com", password: "secret-pass" });
  assert.deepEqual((await guest("/api/member/library")).body.items, []);
  const fav = await guest("/api/member/library/ditiansui", { favorite: true });
  assert.equal(fav.status, 200);
  assert.equal(fav.body.item.favorite, true);
  const read = await guest("/api/member/library/ditiansui", { chapter: 4, chapterCount: 20, paragraph: 7, chapterTitle: "论天干" });
  assert.equal(read.body.item.favorite, true, "saving a position keeps the favourite");
  assert.equal(read.body.item.paragraph, 7);
  await guest("/api/member/library/zhouyi", { chapter: 1, chapterCount: 64, paragraph: 0, chapterTitle: "坤" });
  const unfav = await guest("/api/member/library/ditiansui", { favorite: false });
  assert.equal(unfav.body.item.chapter, 4, "removing the favourite keeps the reading position");
  const items = (await guest("/api/member/library")).body.items;
  assert.equal(items.length, 2);
  assert.deepEqual(items.find((item) => item.workId === "ditiansui"), { workId: "ditiansui", favorite: false, chapter: 4, chapterCount: 20, paragraph: 7, chapterTitle: "论天干", favoritedAt: null, readAt: items.find((item) => item.workId === "ditiansui").readAt });
  assert.equal((await guest("/api/member/library/..%2Fetc", { favorite: true })).status, 400);
  // Another member does not see this shelf.
  const other = client(env, "device-libraryshelf0002");
  await other("/api/auth/register", { email: "other@example.com", password: "secret-pass" });
  assert.deepEqual((await other("/api/member/library")).body.items, []);
});

test("solar-term reminder: subscribers get one e-mail on the day a solar term begins, and nothing on other days", async () => {
  const { env } = freshEnv();
  const browser = client(env, "device-solarterm0000001");
  await browser("/api/auth/register", { email: "terms@example.com", password: "secret-pass" });
  const saved = (await browser("/api/member/reminders", { solarTerms: true, timezone: "Asia/Saigon", locale: "zh-Hans" })).body;
  assert.deepEqual(saved, { enabled: false, solarTerms: true });
  const solarTerm = (date) => (date === "2026-11-07" ? "立冬" : null);
  sentMail.length = 0;
  assert.equal((await sendDailyReminders(env, { at: new Date("2026-11-06T02:00:00Z"), solarTerm })).sent, 0, "not a solar-term day");
  assert.equal((await sendDailyReminders(env, { at: new Date("2026-11-07T02:00:00Z"), solarTerm })).sent, 1);
  assert.match(sentMail[0].subject, /今日节气：立冬/);
  assert.doesNotMatch(sentMail[0].text, /5 个免费积分/, "only the solar-term line when the daily reminder is off");
  // Turning on the daily reminder keeps the solar-term choice.
  assert.deepEqual((await browser("/api/member/reminders", { enabled: true })).body, { enabled: true, solarTerms: true });
});

test("member library: profiles need consent for other people, reports keep their chart, notes and data deletion", async () => {
  const { env, db } = freshEnv();
  const member = client(env, "device-memberlib0000001");
  await member("/api/auth/register", { email: "lib@example.com", password: "secret-pass" });
  const self = await member("/api/member/profiles", { label: "Me", relation: "self", name: "An", gender: "yang", calendar: "solar", date: "1990-05-01", time: "08:30", place: "Hanoi" });
  assert.equal(self.status, 200);
  assert.equal(self.body.profiles.length, 1);
  const noConsent = await member("/api/member/profiles", { label: "Mum", relation: "parent", date: "1965-02-03" });
  assert.equal(noConsent.body.code, "CONSENT_REQUIRED");
  const mum = await member("/api/member/profiles", { label: "Mum", relation: "parent", date: "1965-02-03", consent: true });
  assert.equal(mum.body.profiles.length, 2);
  assert.ok(mum.body.profiles.find((profile) => profile.label === "Mum").consentAt);
  const id = mum.body.profiles.find((profile) => profile.label === "Mum").id;
  assert.equal((await member(`/api/member/profiles/${id}`, { label: "Mother", relation: "parent", date: "1965-02-03", consent: true })).body.profiles.find((profile) => profile.id === id).label, "Mother");
  assert.equal((await member(`/api/member/profiles/${id}/delete`, {})).body.profiles.length, 1);
  // A paid report keeps its chart and subject, so it can be reopened for follow-ups.
  await db.prepare("UPDATE members SET credits = 100 WHERE email = 'lib@example.com'").run();
  const paid = await member("/api/readings/preview", { ...previewBody, pay: true });
  assert.equal(paid.status, 200);
  const list = (await member("/api/member/interpretations")).body.interpretations;
  assert.equal(list[0].hasChart, true);
  const detail = (await member(`/api/member/interpretations/${list[0].id}`)).body.interpretation;
  assert.ok(detail.chart?.calendar, "the stored chart comes back with the report");
  const follow = await member("/api/interpretations", { tool: detail.tool, locale: detail.locale, question: "And next month?", mode: "conversation", chart: detail.chart, conversationHistory: [{ question: detail.question, answer: detail.response.summary }] });
  assert.equal(follow.status, 200, "a follow-up works from the stored chart");
  // Notes on a report.
  assert.equal((await member("/api/member/notes", { ref: `report:${list[0].id}`, body: "Check again in spring." })).status, 200);
  assert.equal((await member("/api/member/notes")).body.notes[0].body, "Check again in spring.");
  // Export and delete.
  const exported = await member.raw("/api/member/export");
  assert.match(exported.headers.get("content-disposition") ?? "", /xuannova-my-data/);
  const data = await exported.json();
  assert.equal(data.profiles.length, 1);
  assert.ok(data.reports.length >= 1);
  assert.deepEqual((await member("/api/member/privacy/delete", { scopes: ["reports", "profiles"] })).body.deleted, ["reports", "profiles"]);
  assert.equal((await member("/api/member/interpretations")).body.interpretations.length, 0);
  assert.equal((await member("/api/member/profiles")).body.profiles.length, 0);
  assert.equal((await member("/api/member/notes")).body.notes.length, 0, "report notes go with the reports");
  // Another member cannot read this member's report.
  const other = client(env, "device-memberlib0000002");
  await other("/api/auth/register", { email: "other2@example.com", password: "secret-pass" });
  assert.equal((await other(`/api/member/interpretations/${list[0].id}`)).status, 404);
});

test("free full BaZi reading: each account (and device) gets one full reading free, once; guests keep the free half", async () => {
  const { env } = freshEnv();
  const guest = client(env, "device-freefull00000001");
  const half = await guest("/api/readings/preview", previewBody);
  assert.equal(half.body.unlocked, false, "guests still get the free first half");
  assert.equal((await guest("/api/readings/free-status")).body.freeFull.available, false);
  await guest("/api/auth/register", { email: "free@example.com", password: "secret-pass" });
  assert.deepEqual((await guest("/api/readings/free-status")).body.freeFull, { tools: ["bazi"], available: true });
  const before = (await guest("/api/member/me")).body.member.balance;
  const full = await guest("/api/readings/preview", previewBody);
  assert.equal(full.status, 200);
  assert.equal(full.body.freeFull, true);
  assert.equal(full.body.unlocked, true);
  assert.equal(full.body.cost, 0);
  assert.ok(full.body.response.sections.length >= 3, "the whole reading");
  assert.equal((await guest("/api/member/me")).body.member.balance, before, "no credits taken");
  assert.equal((await guest("/api/member/interpretations")).body.interpretations[0].cost, 0);
  assert.equal((await guest("/api/readings/free-status")).body.freeFull.available, false);
  assert.equal((await guest("/api/readings/preview", previewBody)).body.unlocked, false, "the next BaZi reading is the free half again");
  assert.equal((await guest("/api/readings/preview", { ...previewBody, tool: "liuyao" })).body.unlocked, false, "other methods are not free");
  // A new account on the same device does not get another one.
  await guest("/api/auth/logout", {});
  await guest("/api/auth/register", { email: "free2@example.com", password: "secret-pass" });
  assert.equal((await guest("/api/readings/preview", previewBody)).body.unlocked, false);
  // The same account on another device does not get another one either, not even on another day.
  const otherDevice = client(env, "device-freefull00000002");
  await otherDevice("/api/auth/login", { email: "free@example.com", password: "secret-pass" });
  assert.equal((await otherDevice("/api/readings/preview", previewBody)).body.unlocked, false);
  // A new account on a new device does, and it streams in full.
  const fresh = client(env, "device-freefull00000004");
  await fresh("/api/auth/register", { email: "free3@example.com", password: "secret-pass" });
  const events = await readEvents(await fresh.raw("/api/readings/preview", { ...previewBody, stream: true }));
  assert.equal(events.find((event) => event.type === "done").body.freeFull, true);
  // Turned off by configuration.
  const { env: offEnv } = freshEnv();
  offEnv.FREE_FULL_TOOLS = "none";
  const member = client(offEnv, "device-freefull00000003");
  await member("/api/auth/register", { email: "off@example.com", password: "secret-pass" });
  assert.equal((await member("/api/readings/preview", previewBody)).body.unlocked, false);
});
