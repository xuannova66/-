// Wallet payments on Solana and TRON against a real SQLite database with every migration applied and mocked chain RPCs.
import assert from "node:assert/strict";
import { createHash, randomBytes } from "node:crypto";
import { readdirSync, readFileSync } from "node:fs";
import test from "node:test";

const { openDatabase } = await import("../server/sqlite-db.ts");
const { handleCommerceApi } = await import("../worker/commerce-api.ts");
const { base58Encode, base58Decode, solanaTransferMessage, tronToHex, SPL_TOKEN_PROGRAM, MEMO_PROGRAM } = await import("../app/chain-lite.ts");

const ORIGIN = "https://xuannova.test";
const SOL_RPC = "https://sol.test/rpc";
const TRON_API = "https://tron.test";
const ETH_RPC = "https://eth.test/rpc";
const ETH_RECIPIENT = "0x84f33708ab4b7defd9be5ec50911797e34009caa";
const ETH_USDT = "0xdac17f958d2ee523a2206206994597c13d831ec7";
const USDC = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";
const SOL_RECIPIENT = "BzDaU6VKyMtN14QeVuCMva2SGmHLeeYy2GAAG9muJNq2";
const TRON_RECIPIENT = "TMkFTkWbkjnUpCTiYx87QyTTjXiS2ogGqi";
const TRON_USDT = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t";
const TRANSFER_TOPIC = "ddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";

const key = () => base58Encode(randomBytes(32));
const signature = () => base58Encode(randomBytes(64));
function tronAddress() {
  const body = Buffer.concat([Buffer.from([0x41]), randomBytes(20)]);
  const check = createHash("sha256").update(createHash("sha256").update(body).digest()).digest().subarray(0, 4);
  return base58Encode(Buffer.concat([body, check]));
}

// ---- mocked chains -------------------------------------------------------------------------------------------
const chain = { solana: { accounts: {}, lamports: {}, status: "finalized", tx: {} }, tron: { tx: {}, accounts: {} }, eth: { head: 1000, balances: {}, ether: {}, tx: {} } };
const realFetch = globalThis.fetch;
globalThis.fetch = async (url, init) => {
  const href = String(url);
  if (href === SOL_RPC) {
    const { method, params } = JSON.parse(init.body);
    const reply = (result) => new Response(JSON.stringify({ jsonrpc: "2.0", id: 1, result }), { status: 200 });
    if (method === "getTokenAccountsByOwner") {
      const [owner, { mint }] = params;
      const list = (chain.solana.accounts[`${owner}:${mint}`] ?? []).map(([pubkey, amount]) => ({ pubkey, account: { owner: SPL_TOKEN_PROGRAM, data: { parsed: { info: { owner, mint, tokenAmount: { amount, decimals: 6 } } } } } }));
      return reply({ value: list });
    }
    if (method === "getBalance") return reply({ value: chain.solana.lamports[params[0]] ?? 5_000_000 });
    if (method === "getLatestBlockhash") return reply({ value: { blockhash: key(), lastValidBlockHeight: 1 } });
    if (method === "getGenesisHash") return reply("5eykt4UsFv8P8NJdTREpY1vzqKqZKvdpKuc147dw2N9d");
    if (method === "getSignatureStatuses") return reply({ value: [chain.solana.tx[params[0][0]] ? { confirmationStatus: chain.solana.status, err: null } : null] });
    if (method === "getTransaction") return reply(chain.solana.tx[params[0]] ?? null);
  }
  if (href === ETH_RPC) {
    const { method, params } = JSON.parse(init.body);
    const reply = (result) => new Response(JSON.stringify({ jsonrpc: "2.0", id: 1, result }), { status: 200 });
    if (method === "eth_chainId") return reply("0x1");
    if (method === "eth_getBalance") return reply(`0x${(chain.eth.ether[params[0]] ?? 10n ** 17n).toString(16)}`);
    if (method === "eth_gasPrice") return reply(`0x${(20n * 10n ** 9n).toString(16)}`);
    if (method === "eth_blockNumber") return reply(`0x${chain.eth.head.toString(16)}`);
    if (method === "eth_call") return reply(`0x${(chain.eth.balances[`0x${params[0].data.slice(-40)}`] ?? 0n).toString(16).padStart(64, "0")}`);
    if (method === "eth_getTransactionByHash") return reply(chain.eth.tx[params[0]]?.tx ?? null);
    if (method === "eth_getTransactionReceipt") return reply(chain.eth.tx[params[0]]?.receipt ?? null);
  }
  if (href.startsWith(`${TRON_API}/v1/accounts/`)) {
    const account = chain.tron.accounts[href.split("/").pop()];
    return new Response(JSON.stringify({ success: true, data: account ? [account] : [] }), { status: 200 });
  }
  if (href.startsWith(TRON_API)) {
    const { value } = JSON.parse(init.body);
    const entry = chain.tron.tx[value];
    if (!entry) return new Response("{}", { status: 200 });
    return new Response(JSON.stringify(href.endsWith("gettransactionbyid") ? entry.body : entry.receipt), { status: 200 });
  }
  return realFetch(url, init);
};

function solanaTx({ sig, buyer, source, destination, reference, amount, mint = USDC, memo = reference }) {
  return {
    meta: { err: null,
      preTokenBalances: [{ accountIndex: 2, mint, owner: SOL_RECIPIENT, programId: SPL_TOKEN_PROGRAM, uiTokenAmount: { amount: "1000000", decimals: 6 } }],
      postTokenBalances: [{ accountIndex: 2, mint, owner: SOL_RECIPIENT, programId: SPL_TOKEN_PROGRAM, uiTokenAmount: { amount: String(1000000n + BigInt(amount)), decimals: 6 } }] },
    transaction: { signatures: [sig], message: {
      accountKeys: [{ pubkey: buyer, signer: true }, { pubkey: source, signer: false }, { pubkey: destination, signer: false }, { pubkey: mint, signer: false }, { pubkey: SPL_TOKEN_PROGRAM, signer: false }, { pubkey: MEMO_PROGRAM, signer: false }],
      instructions: [
        { programId: SPL_TOKEN_PROGRAM, parsed: { type: "transferChecked", info: { authority: buyer, source, mint, destination, tokenAmount: { amount: String(amount), decimals: 6 } } } },
        { programId: MEMO_PROGRAM, parsed: memo },
      ] } },
  };
}

async function tronTx({ id, buyer, reference, amount }) {
  const pad = (hex) => hex.padStart(64, "0");
  const buyerHex = await tronToHex(buyer), tokenHex = await tronToHex(TRON_USDT), recipientHex = await tronToHex(TRON_RECIPIENT);
  return {
    body: { txID: id, raw_data: { data: reference, contract: [{ type: "TriggerSmartContract", parameter: { value: { owner_address: buyerHex, contract_address: tokenHex } } }] } },
    receipt: { id, receipt: { result: "SUCCESS" }, log: [{ address: tokenHex.slice(2), topics: [TRANSFER_TOPIC, pad(buyerHex.slice(2)), pad(recipientHex.slice(2))], data: pad(BigInt(amount).toString(16)) }] },
  };
}

function freshEnv() {
  const db = openDatabase(":memory:");
  for (const file of readdirSync(new URL("../migrations/", import.meta.url)).filter((name) => name.endsWith(".sql")).sort()) db.raw.exec(readFileSync(new URL(`../migrations/${file}`, import.meta.url), "utf8"));
  return { db, env: { DB: db, ADMIN_EMAILS: "owner@example.com", SESSION_SECRET: "test-session-signing-key-that-is-long-enough", SOLANA_RPC_URL: SOL_RPC, TRON_API_URL: TRON_API, ETHEREUM_RPC_URL: ETH_RPC } };
}
function client(env, device) {
  const jar = new Map([["xn_device", device]]);
  return async (path, body) => {
    const headers = { origin: ORIGIN, cookie: [...jar].map(([k, v]) => `${k}=${v}`).join("; "), "content-type": "application/json" };
    const response = await handleCommerceApi(new Request(`${ORIGIN}${path}`, { method: body === undefined ? "GET" : "POST", headers, body: body === undefined ? undefined : JSON.stringify(body) }), env);
    for (const cookie of response.headers.getSetCookie?.() ?? []) { const [pair] = cookie.split(";"); const [name, value] = pair.split("="); if (value) jar.set(name, value); else jar.delete(name); }
    return { status: response.status, body: await response.json() };
  };
}
const balance = async (member) => (await member("/api/member/me")).body.member.balance;

test("the Solana message is a legacy transfer-checked plus memo that the wallet can sign as is", () => {
  const [buyer, source, destination, blockhash] = [key(), key(), key(), key()];
  const reference = "ab".repeat(32);
  const bytes = solanaTransferMessage({ buyer, source, destination, mint: USDC, amount: 4_990_000n, decimals: 6, memo: reference, recentBlockhash: blockhash });
  assert.deepEqual([...bytes.subarray(0, 4)], [1, 0, 3, 6]);
  const keys = Array.from({ length: 6 }, (_, index) => base58Encode(bytes.subarray(4 + index * 32, 36 + index * 32)));
  assert.deepEqual(keys, [buyer, source, destination, USDC, SPL_TOKEN_PROGRAM, MEMO_PROGRAM]);
  assert.equal(base58Encode(bytes.subarray(196, 228)), blockhash);
  let at = 228;
  assert.equal(bytes[at++], 2, "two instructions");
  assert.deepEqual([...bytes.subarray(at, at + 6)], [4, 4, 1, 3, 2, 0], "token program; source, mint, destination, owner");
  at += 6;
  assert.equal(bytes[at++], 10);
  assert.equal(bytes[at], 12, "TransferChecked");
  assert.equal(Buffer.from(bytes.subarray(at + 1, at + 9)).readBigUInt64LE(), 4_990_000n);
  assert.equal(bytes[at + 9], 6);
  at += 10;
  assert.deepEqual([...bytes.subarray(at, at + 3)], [5, 0, 64], "memo program, no accounts, 64 bytes");
  assert.equal(Buffer.from(bytes.subarray(at + 3)).toString("utf8"), reference);
  assert.equal(base58Decode(base58Encode(bytes)).length, bytes.length);
  assert.throws(() => solanaTransferMessage({ buyer, source: buyer, destination, mint: USDC, amount: 1n, decimals: 6, memo: reference, recentBlockhash: blockhash }));
});

test("Solana wallet payment: order, pending until finalized, credited once, signature cannot be reused", async () => {
  const { env } = freshEnv();
  const member = client(env, "device-walletpay-sol-0001");
  assert.equal((await member("/api/auth/register", { email: "sol@example.com", password: "secret-pass" })).status, 201);
  const buyer = key(), source = key(), destination = key();
  chain.solana.accounts[`${buyer}:${USDC}`] = [[source, "50000000"]];
  assert.equal((await member("/api/pay/solana/order", { packageId: "seed", asset: "USDC", buyer })).status, 409, "recipient token account missing → not ready");
  chain.solana.accounts[`${SOL_RECIPIENT}:${USDC}`] = [[destination, "1000000"]];
  assert.equal((await member("/api/pay/solana/order", { packageId: "seed", asset: "DOGE", buyer })).status, 400);
  assert.equal((await member("/api/pay/solana/order", { packageId: "seed", asset: "USDC", buyer: "not-a-wallet" })).status, 400);
  const poor = key();
  chain.solana.accounts[`${poor}:${USDC}`] = [[key(), "100"]];
  const lacking = await member("/api/pay/solana/order", { packageId: "seed", asset: "USDC", buyer: poor });
  assert.equal(lacking.status, 409, "insufficient balance");
  assert.equal(lacking.body.code, "INSUFFICIENT_BALANCE");
  assert.deepEqual([lacking.body.detail.have, lacking.body.detail.need, lacking.body.detail.other.asset], ["0.0001", "4.99", "USDT"]);
  const noSol = key();
  chain.solana.accounts[`${noSol}:${USDC}`] = [[key(), "50000000"]];
  chain.solana.lamports[noSol] = 0;
  const gas = await member("/api/pay/solana/order", { packageId: "seed", asset: "USDC", buyer: noSol });
  assert.equal(gas.body.code, "INSUFFICIENT_GAS");
  assert.equal(gas.body.detail.gas, "SOL");

  const created = await member("/api/pay/solana/order", { packageId: "seed", asset: "USDC", buyer });
  assert.equal(created.status, 201);
  const order = created.body.order;
  assert.equal(order.amountUnits, "4990000");
  assert.equal(order.source, source);
  assert.equal(order.destination, destination);
  assert.match(order.reference, /^[0-9a-f]{64}$/);

  const before = await balance(member);
  const sig = signature();
  chain.solana.tx[sig] = solanaTx({ sig, buyer, source, destination, reference: order.reference, amount: 4_990_000 });
  chain.solana.status = "confirmed";
  assert.equal((await member("/api/pay/solana/confirm", { orderId: order.orderId, transactionId: sig })).status, 202);
  chain.solana.status = "finalized";
  const done = await member("/api/pay/solana/confirm", { orderId: order.orderId, transactionId: sig });
  assert.equal(done.status, 200);
  assert.equal(done.body.status, "credited");
  const after = await balance(member);
  assert.ok(after >= before + 20, `${before} → ${after}`);
  const again = await member("/api/pay/solana/confirm", { orderId: order.orderId, transactionId: sig });
  assert.equal(again.body.status, "credited");
  assert.equal(await balance(member), after, "no double credit");

  // The same signature cannot pay a second order.
  const second = (await member("/api/pay/solana/order", { packageId: "seed", asset: "USDC", buyer })).body.order;
  assert.equal((await member("/api/pay/solana/confirm", { orderId: second.orderId, transactionId: sig })).status, 409);
  assert.equal(await balance(member), after);

  // A transfer of the wrong amount is refused and the order stays open for a correct one.
  const short = signature();
  chain.solana.tx[short] = solanaTx({ sig: short, buyer, source, destination, reference: second.reference, amount: 1_000_000 });
  assert.equal((await member("/api/pay/solana/confirm", { orderId: second.orderId, transactionId: short })).status, 409);
  const wrongMemo = signature();
  chain.solana.tx[wrongMemo] = solanaTx({ sig: wrongMemo, buyer, source, destination, reference: second.reference, memo: "0".repeat(64), amount: 4_990_000 });
  assert.equal((await member("/api/pay/solana/confirm", { orderId: second.orderId, transactionId: wrongMemo })).status, 409);
  const good = signature();
  chain.solana.tx[good] = solanaTx({ sig: good, buyer, source, destination, reference: second.reference, amount: 4_990_000 });
  assert.equal((await member("/api/pay/solana/confirm", { orderId: second.orderId, transactionId: good })).body.status, "credited");

  // Another member cannot confirm someone else's order.
  const stranger = client(env, "device-walletpay-sol-0002");
  await stranger("/api/auth/register", { email: "other@example.com", password: "secret-pass" });
  assert.equal((await stranger("/api/pay/solana/confirm", { orderId: second.orderId, transactionId: good })).status, 404);
});

test("TRON wallet payment: USDT transfer tagged with the order reference is credited once", async () => {
  const { env } = freshEnv();
  const member = client(env, "device-walletpay-trx-0001");
  await member("/api/auth/register", { email: "trx@example.com", password: "secret-pass" });
  const buyer = tronAddress();
  assert.equal((await member("/api/pay/tron/order", { packageId: "path", asset: "USDC", buyer })).status, 400, "TRON settles in USDT only");
  const empty = tronAddress();
  chain.tron.accounts[empty] = { balance: 50_000_000, trc20: [{ [TRON_USDT]: "1000000" }] };
  const short = await member("/api/pay/tron/order", { packageId: "path", asset: "USDT", buyer: empty });
  assert.deepEqual([short.status, short.body.code, short.body.detail.have, short.body.detail.need], [409, "INSUFFICIENT_BALANCE", "1", "9.9"]);
  const noTrx = tronAddress();
  chain.tron.accounts[noTrx] = { balance: 0, trc20: [{ [TRON_USDT]: "99000000" }] };
  assert.equal((await member("/api/pay/tron/order", { packageId: "path", asset: "USDT", buyer: noTrx })).body.code, "INSUFFICIENT_GAS");
  chain.tron.accounts[buyer] = { balance: 40_000_000, trc20: [{ [TRON_USDT]: "99000000" }] };
  assert.equal((await member("/api/pay/tron/order", { packageId: "path", asset: "USDT", buyer: buyer.slice(0, -1) + (buyer.endsWith("a") ? "b" : "a") })).status, 400, "checksum");
  const created = await member("/api/pay/tron/order", { packageId: "path", asset: "USDT", buyer });
  assert.equal(created.status, 201);
  const order = created.body.order;
  assert.equal(order.recipient, TRON_RECIPIENT);
  assert.equal(order.token, TRON_USDT);
  assert.equal(order.amountUnits, "9900000");

  const id = randomBytes(32).toString("hex");
  assert.equal((await member("/api/pay/tron/confirm", { orderId: order.orderId, transactionId: id })).status, 202, "not solidified yet");
  chain.tron.tx[id] = await tronTx({ id, buyer, reference: order.reference, amount: 9_900_000 });
  const before = await balance(member);
  const done = await member("/api/pay/tron/confirm", { orderId: order.orderId, transactionId: id });
  assert.equal(done.status, 200);
  assert.equal(done.body.status, "credited");
  assert.ok(await balance(member) >= before + 50);

  const next = (await member("/api/pay/tron/order", { packageId: "path", asset: "USDT", buyer })).body.order;
  const other = randomBytes(32).toString("hex");
  chain.tron.tx[other] = await tronTx({ id: other, buyer, reference: order.reference, amount: 9_900_000 });
  assert.equal((await member("/api/pay/tron/confirm", { orderId: next.orderId, transactionId: other })).status, 409, "reference of another order");
});

function ethTx({ hash, buyer, data, amount, block = 990, token = ETH_USDT, to = ETH_RECIPIENT }) {
  const pad = (hex) => hex.replace(/^0x/, "").padStart(64, "0");
  return {
    tx: { hash, from: buyer, to: token, input: data },
    receipt: { status: "0x1", blockNumber: `0x${block.toString(16)}`, logs: [{ address: token, topics: ["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", `0x${pad(buyer)}`, `0x${pad(to)}`], data: `0x${pad(BigInt(amount).toString(16))}` }] },
  };
}

test("Ethereum wallet payment: ERC-20 transfer with the reference appended, credited after 12 confirmations", async () => {
  const { env } = freshEnv();
  const member = client(env, "device-walletpay-eth-0001");
  await member("/api/auth/register", { email: "eth@example.com", password: "secret-pass" });
  const buyer = `0x${randomBytes(20).toString("hex")}`;
  assert.equal((await member("/api/pay/ethereum/order", { packageId: "seed", asset: "USDT", buyer })).status, 409, "no USDT balance");
  chain.eth.balances[buyer] = 100_000_000n;
  assert.equal((await member("/api/pay/ethereum/order", { packageId: "seed", asset: "DAI", buyer })).status, 400);
  assert.equal((await member("/api/pay/ethereum/order", { packageId: "seed", asset: "USDT", buyer: "0x123" })).status, 400);
  const created = await member("/api/pay/ethereum/order", { packageId: "seed", asset: "USDT", buyer });
  assert.equal(created.status, 201);
  const order = created.body.order;
  assert.equal(order.token, ETH_USDT);
  assert.equal(order.chainId, "0x1");
  assert.equal(order.data, `0xa9059cbb${ETH_RECIPIENT.slice(2).padStart(64, "0")}${(4_990_000).toString(16).padStart(64, "0")}${order.reference}`);

  const hash = `0x${randomBytes(32).toString("hex")}`;
  assert.equal((await member("/api/pay/ethereum/confirm", { orderId: order.orderId, transactionId: hash })).status, 202, "not mined yet");
  chain.eth.tx[hash] = ethTx({ hash, buyer, data: order.data, amount: 4_990_000, block: 995 });
  assert.equal((await member("/api/pay/ethereum/confirm", { orderId: order.orderId, transactionId: hash })).status, 202, "6 confirmations");
  chain.eth.head = 1010;
  const before = await balance(member);
  const done = await member("/api/pay/ethereum/confirm", { orderId: order.orderId, transactionId: hash });
  assert.equal(done.status, 200);
  assert.equal(done.body.status, "credited");
  assert.ok(await balance(member) >= before + 20);

  // Same transfer without the reference (plain transfer) or to another address is refused.
  const next = (await member("/api/pay/ethereum/order", { packageId: "seed", asset: "USDT", buyer })).body.order;
  const plain = `0x${randomBytes(32).toString("hex")}`;
  chain.eth.tx[plain] = ethTx({ hash: plain, buyer, data: next.data.slice(0, -64), amount: 4_990_000 });
  assert.equal((await member("/api/pay/ethereum/confirm", { orderId: next.orderId, transactionId: plain })).status, 409);
  const elsewhere = `0x${randomBytes(32).toString("hex")}`;
  chain.eth.tx[elsewhere] = ethTx({ hash: elsewhere, buyer, data: next.data, amount: 4_990_000, to: `0x${"1".repeat(40)}` });
  assert.equal((await member("/api/pay/ethereum/confirm", { orderId: next.orderId, transactionId: elsewhere })).status, 409);
});

test("the unsigned Solana wire transaction is one empty signature slot followed by the message", async () => {
  const { unsignedSolanaTransaction } = await import("../app/direct-wallets.ts");
  const message = solanaTransferMessage({ buyer: key(), source: key(), destination: key(), mint: USDC, amount: 1n, decimals: 6, memo: "ab".repeat(32), recentBlockhash: key() });
  const wire = unsignedSolanaTransaction(message);
  assert.equal(wire[0], 1);
  assert.ok(wire.subarray(1, 65).every((byte) => byte === 0));
  assert.deepEqual([...wire.subarray(65)], [...message]);
});
