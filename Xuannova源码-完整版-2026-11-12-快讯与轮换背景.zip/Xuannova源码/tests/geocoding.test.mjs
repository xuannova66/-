import assert from "node:assert/strict";
import test from "node:test";

const {
  buildGeocodingUrl,
  buildGeocodingUrls,
  buildGlobalLocationSearchUrl,
  buildTimezoneUrl,
  countrySearchName,
  formatGlobalLocation,
  normalizeGeocodingResults,
} = await import("../app/geocoding.ts");
const { handleGeocodingApi } = await import("../worker/geocoding-api.ts");

test("worldwide city searches use the same-origin fallback endpoint and retain the active language", () => {
  const url = new URL(buildGlobalLocationSearchUrl("東京, 日本", "ja"), "https://xuanyuan.example");
  assert.equal(url.pathname, "/api/geocode");
  assert.equal(url.searchParams.get("q"), "東京, 日本");
  assert.equal(url.searchParams.get("locale"), "ja");
});

test("city-plus-country searches constrain worldwide results with the matching ISO country code", () => {
  const urls = buildGeocodingUrls("東京, 日本", "ja").map((value) => new URL(value));
  assert.ok(urls.some((url) => url.searchParams.get("name") === "東京" && url.searchParams.get("countryCode") === "JP"));
  assert.ok(urls.some((url) => url.searchParams.get("name") === "Tokyo" && url.searchParams.get("countryCode") === "JP"));
});

test("same-origin worldwide geocoding merges upstream city matches before returning them to the browser", async () => {
  const requested = [];
  const response = await handleGeocodingApi(
    new Request("https://preview.example/api/geocode?q=%E6%9D%B1%E4%BA%AC%2C%20%E6%97%A5%E6%9C%AC&locale=ja"),
    async (url) => {
      requested.push(new URL(String(url)));
      return new Response(JSON.stringify({ results: [{ id: 1850147, name: "東京", country: "日本", country_code: "JP", latitude: 35.6895, longitude: 139.6917, timezone: "Asia/Tokyo" }] }));
    },
  );
  assert.equal(response?.status, 200);
  assert.equal((await response?.json()).results[0].timezone, "Asia/Tokyo");
  assert.ok(requested.some((url) => url.searchParams.get("countryCode") === "JP"));
});

test("same-origin worldwide geocoding rejects malformed location queries before contacting an upstream service", async () => {
  let calls = 0;
  const response = await handleGeocodingApi(
    new Request("https://preview.example/api/geocode?q=x&locale=en"),
    async () => {
      calls += 1;
      return new Response();
    },
  );
  assert.equal(response?.status, 400);
  assert.equal(calls, 0);
});

test("global geocoding builds a bounded public query and preserves worldwide result metadata", () => {
  const url = buildGeocodingUrl("Ho Chi Minh City", "vi");
  assert.match(url, /geocoding-api\.open-meteo\.com\/v1\/search/);
  assert.equal(new URL(url).searchParams.get("name"), "Ho Chi Minh City");
  assert.match(url, /language=vi/);
  assert.match(url, /count=8/);

  const results = normalizeGeocodingResults({
    results: [{ id: 1566083, name: "Ho Chi Minh City", country: "Vietnam", admin1: "Ho Chi Minh", latitude: 10.8231, longitude: 106.6297, timezone: "Asia/Ho_Chi_Minh" }],
  });
  assert.deepEqual(results, [{ id: 1566083, name: "Ho Chi Minh City", country: "Vietnam", admin1: "Ho Chi Minh", latitude: 10.8231, longitude: 106.6297, timezone: "Asia/Ho_Chi_Minh", label: "Ho Chi Minh City, Ho Chi Minh, Vietnam" }]);
});

test("global geocoding safely ignores incomplete and malformed results", () => {
  const results = normalizeGeocodingResults({ results: [{ name: "No coordinates" }, { id: 1, name: "Tokyo", country: "Japan", latitude: 35.6762, longitude: 139.6503, timezone: "Asia/Tokyo" }] });
  assert.equal(results.length, 1);
  assert.equal(results[0].label, "Tokyo, Japan");
});

test("selected global locations render their country in the active interface language", () => {
  const location = { id: 5128581, name: "New York", admin1: "New York", country: "United States", countryCode: "US", latitude: 40.71427, longitude: -74.00597, timezone: "America/New_York", label: "New York, New York, United States" };
  assert.match(formatGlobalLocation(location, "zh-Hans"), /美国/);
  assert.match(formatGlobalLocation(location, "ja"), /アメリカ/);
});

test("worldwide search preserves country-level matches and retries localized country names in English", () => {
  const chineseCountry = countrySearchName("中国", "zh-Hans");
  const thaiCountry = countrySearchName("ประเทศไทย", "th");
  assert.equal(chineseCountry, "China");
  assert.equal(thaiCountry, "Thailand");

  const urls = buildGeocodingUrls("ประเทศไทย", "th").map((value) => new URL(value));
  assert.ok(urls.some((url) => url.searchParams.get("name") === "ประเทศไทย" && url.searchParams.get("language") === "th"));
  assert.ok(urls.some((url) => url.searchParams.get("name") === "Thailand" && url.searchParams.get("language") === "en"));

  const countries = normalizeGeocodingResults({
    results: [{ id: 1814991, name: "China", country: "China", country_code: "CN", latitude: 35, longitude: 105 }],
  });
  assert.equal(countries.length, 1);
  assert.equal(countries[0].timezone, "");

  const timezoneUrl = new URL(buildTimezoneUrl(35, 105));
  assert.equal(timezoneUrl.hostname, "api.open-meteo.com");
  assert.equal(timezoneUrl.searchParams.get("timezone"), "auto");
});
