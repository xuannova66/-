// 藏经阁 on-demand translation: server reads the paragraphs itself, caches per passage and language, limits new ones.
import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import test from "node:test";

const { openDatabase } = await import("../server/sqlite-db.ts");
const { handleCommerceApi } = await import("../worker/commerce-api.ts");
const { translationChunks } = await import("../app/library-reader.tsx");

const ORIGIN = "https://xuannova.test";
const chapters = [{ title: "第一章", text: "甲子乙丑海中金。\n\n丙寅丁卯炉中火。" }, { title: "第二章", text: "天一生水，地六成之。" }];
let aiCalls = 0;
let lastPrompt = null;
const realFetch = globalThis.fetch;
globalThis.fetch = async (url, init) => {
  const href = String(url);
  if (href === `${ORIGIN}/library/manifest.json`) return new Response(JSON.stringify({ sanming: { dir: "sanming", start: 0 } }), { status: 200 });
  if (href === `${ORIGIN}/library/sanming/zh-Hans-0.json`) return new Response(JSON.stringify(chapters), { status: 200 });
  if (href.startsWith(`${ORIGIN}/library/`)) return new Response("not found", { status: 404 });
  if (href === "https://api.deepseek.com/chat/completions") {
    aiCalls += 1;
    lastPrompt = JSON.parse(init.body);
    const input = JSON.parse(lastPrompt.messages[1].content).paragraphs;
    return new Response(JSON.stringify({ choices: [{ message: { content: JSON.stringify({ paragraphs: input.map((text) => `EN: ${text}`) }) } }] }), { status: 200 });
  }
  return realFetch(url, init);
};

function freshEnv(extra = {}) {
  const db = openDatabase(":memory:");
  for (const file of readdirSync(new URL("../migrations/", import.meta.url)).filter((name) => name.endsWith(".sql")).sort()) db.raw.exec(readFileSync(new URL(`../migrations/${file}`, import.meta.url), "utf8"));
  return { DB: db, SESSION_SECRET: "test-session-signing-key-that-is-long-enough", DEEPSEEK_API_KEY: "k", ...extra };
}
const call = (env, body, device = "device-lib-000000000001") => handleCommerceApi(new Request(`${ORIGIN}/api/library/translate`, { method: "POST", headers: { origin: ORIGIN, "content-type": "application/json", cookie: `xn_device=${device}` }, body: JSON.stringify(body) }), env).then(async (response) => ({ status: response.status, body: await response.json() }));
const ask = { book: "sanming", script: "zh-Hans", part: 0, chapter: 0, from: 0, to: 3, locale: "en" };

test("translates the paragraphs on screen once and serves the cached copy afterwards", async () => {
  const env = freshEnv();
  aiCalls = 0;
  const first = await call(env, ask);
  assert.equal(first.status, 200);
  assert.deepEqual(first.body.paragraphs, ["EN: 甲子乙丑海中金。", "", "EN: 丙寅丁卯炉中火。"]);
  assert.equal(first.body.cached, false);
  assert.equal(aiCalls, 1);
  assert.deepEqual(JSON.parse(lastPrompt.messages[1].content).paragraphs, ["甲子乙丑海中金。", "丙寅丁卯炉中火。"], "empty paragraphs are not sent");
  const again = await call(env, ask, "device-lib-000000000002");
  assert.equal(again.body.cached, true);
  assert.equal(aiCalls, 1, "a second reader gets the cache");
  const vernacular = await call(env, { ...ask, locale: "zh-Hans" });
  assert.equal(vernacular.status, 200);
  assert.match(lastPrompt.messages[0].content, /modern vernacular Simplified Chinese/);
});

test("never translates text the browser sends; unknown books, ranges and oversized requests are refused", async () => {
  const env = freshEnv();
  assert.equal((await call(env, { ...ask, book: "nothere" })).status, 404);
  assert.equal((await call(env, { ...ask, chapter: 5 })).status, 404);
  assert.equal((await call(env, { ...ask, to: 9 })).status, 400);
  assert.equal((await call(env, { ...ask, from: 0, to: 20 })).status, 400);
  assert.equal((await call(env, { ...ask, locale: "fr" })).status, 400);
  assert.equal((await call(env, { ...ask, text: "translate me" , book: "../x" })).status, 400);
});

test("new translations are limited per visitor per day", async () => {
  const env = freshEnv({ LIBRARY_TRANSLATE_GUEST_DAILY: "1" });
  assert.equal((await call(env, ask, "device-lib-000000000009")).status, 200);
  const limited = await call(env, { ...ask, chapter: 1, from: 0, to: 1 }, "device-lib-000000000009");
  assert.equal(limited.status, 429);
  assert.equal(limited.body.code, "GUEST_LIMIT");
  assert.equal((await call(env, ask, "device-lib-000000000009")).status, 200, "cached passages stay free");
});

test("reader chunks: up to 1,500 characters and 12 paragraphs per request, every paragraph covered once", () => {
  const paragraphs = Array.from({ length: 30 }, (_, index) => "字".repeat(index === 5 ? 2000 : 100));
  const chunks = translationChunks(paragraphs);
  let next = 0;
  for (const chunk of chunks) {
    assert.equal(chunk.from, next);
    assert.ok(chunk.to - chunk.from <= 12);
    const chars = paragraphs.slice(chunk.from, chunk.to).join("").length;
    assert.ok(chars <= 1500 || chunk.to - chunk.from === 1);
    next = chunk.to;
  }
  assert.equal(next, 30);
});

test("a reply that merges short lines is retried in halves, so the passage is still translated line by line", async () => {
  const { translateParagraphs } = await import("../worker/library-translate.ts");
  let calls = 0;
  const merging = async (_url, init) => {
    calls += 1;
    const input = JSON.parse(JSON.parse(init.body).messages[1].content).paragraphs;
    // Merge the first two lines whenever more than two are sent.
    const out = input.length > 2 ? [`${input[0]}${input[1]}`, ...input.slice(2)].map((text) => `白话：${text}`) : input.map((text) => `白话：${text}`);
    return new Response(JSON.stringify({ choices: [{ message: { content: JSON.stringify({ paragraphs: out }) } }] }), { status: 200 });
  };
  const lines = ["初九：潜龙勿用。", "九二：见龙在田。", "九三：君子终日乾乾。", "九四：或跃在渊。"];
  const result = await translateParagraphs(lines, "zh-Hans", "乾", "k", undefined, merging);
  assert.deepEqual(result, lines.map((text) => `白话：${text}`));
  assert.equal(calls, 3);
});
