import vinext from "vinext";
import { defineConfig } from "vite";
import hostingConfig from "./.openai/hosting.json";
import { sites } from "./build/sites-vite-plugin";

const SITE_CREATOR_PLACEHOLDER_DATABASE_ID =
  "00000000-0000-4000-8000-000000000000";

const { d1, d1DatabaseName, d1DatabaseId, r2 } = hostingConfig as typeof hostingConfig & { d1DatabaseName?: string; d1DatabaseId?: string; r2?: string };

// macOS Seatbelt blocks FSEvents, so Codex previews need polling for HMR.
const isCodexSeatbeltSandbox = process.env.CODEX_SANDBOX === "seatbelt";

// DEPLOY_TARGET=node builds a plain Node server (`vinext start`) for self-hosting
// on AWS EC2 or any VM. The API is then served by app/api/[...path]/route.ts with
// SQLite instead of the Cloudflare worker + D1.
const isNodeTarget = process.env.DEPLOY_TARGET === "node";

const localBindingConfig = {
  main: "./worker/index.ts",
  compatibility_flags: ["nodejs_compat"],
  d1_databases: d1
    ? [
        {
          binding: d1,
          database_name: d1DatabaseName ?? "site-creator-d1",
          database_id: d1DatabaseId ?? SITE_CREATOR_PLACEHOLDER_DATABASE_ID,
          migrations_dir: "../../migrations",
        },
      ]
    : [],
  r2_buckets: r2
    ? [
        {
          binding: r2,
          bucket_name: "site-creator-r2",
        },
      ]
    : [],
};

export default defineConfig(async () => {
  // Keep Wrangler and Miniflare state project-local. These are non-secret tool
  // settings; application environment belongs in ignored `.env*` files.
  process.env.WRANGLER_WRITE_LOGS ??= "false";
  process.env.WRANGLER_LOG_PATH ??= ".wrangler/logs";
  process.env.MINIFLARE_REGISTRY_PATH ??= ".wrangler/registry";

  if (isNodeTarget) {
    return {
      plugins: [vinext(), sites()],
      ssr: { external: ["node:sqlite"] },
    };
  }

  // Wrangler snapshots its log path while the Cloudflare plugin is imported.
  const { cloudflare } = await import("@cloudflare/vite-plugin");

  return {
    server: isCodexSeatbeltSandbox
      ? { watch: { useFsEvents: false, usePolling: true } }
      : undefined,
    plugins: [
      vinext(),
      sites(),
      cloudflare({
        viteEnvironment: { name: "rsc", childEnvironments: ["ssr"] },
        config: localBindingConfig,
      }),
    ],
  };
});
