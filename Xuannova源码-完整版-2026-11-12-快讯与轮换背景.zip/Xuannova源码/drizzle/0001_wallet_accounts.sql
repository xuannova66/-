PRAGMA defer_foreign_keys = ON;
--> statement-breakpoint
DROP TRIGGER IF EXISTS payment_order_approved_credit_once;
--> statement-breakpoint
CREATE TABLE members_backup AS
SELECT id, email, password_salt, password_hash, credits, role, invite_code, invited_by_member_id, created_at, updated_at FROM members;
--> statement-breakpoint
DROP TABLE members;
--> statement-breakpoint
CREATE TABLE members (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE COLLATE NOCASE,
  wallet_address TEXT UNIQUE COLLATE NOCASE,
  password_salt TEXT,
  password_hash TEXT,
  credits INTEGER NOT NULL DEFAULT 0 CHECK (credits >= 0),
  role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('member', 'admin')),
  invite_code TEXT,
  invited_by_member_id TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
--> statement-breakpoint
INSERT INTO members (id, email, wallet_address, password_salt, password_hash, credits, role, invite_code, invited_by_member_id, created_at, updated_at)
SELECT id, email, NULL, password_salt, password_hash, credits, role, invite_code, invited_by_member_id, created_at, updated_at FROM members_backup;
--> statement-breakpoint
DROP TABLE members_backup;
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS members_invite_code_idx
  ON members(invite_code COLLATE NOCASE);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS members_invited_by_member_idx
  ON members(invited_by_member_id);
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS members_wallet_address_idx
  ON members(wallet_address COLLATE NOCASE);
--> statement-breakpoint
ALTER TABLE payment_orders ADD COLUMN buyer_address TEXT;
--> statement-breakpoint
ALTER TABLE payment_orders ADD COLUMN chain_id INTEGER;
--> statement-breakpoint
ALTER TABLE payment_orders ADD COLUMN contract_address TEXT;
--> statement-breakpoint
ALTER TABLE payment_orders ADD COLUMN fee_wei TEXT;
--> statement-breakpoint
ALTER TABLE payment_orders ADD COLUMN block_number INTEGER;
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS payment_orders_buyer_idx
  ON payment_orders(buyer_address COLLATE NOCASE);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS wallet_nonces (
  wallet_address TEXT PRIMARY KEY COLLATE NOCASE,
  nonce TEXT NOT NULL,
  expires_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE TRIGGER IF NOT EXISTS payment_order_approved_credit_once
AFTER UPDATE OF status ON payment_orders
WHEN OLD.status = 'pending' AND NEW.status = 'approved'
BEGIN
  UPDATE members
  SET credits = credits + NEW.credits,
      updated_at = NEW.reviewed_at
  WHERE id = NEW.member_id;
--> statement-breakpoint
INSERT INTO credit_ledger (
    id, member_id, order_id, delta, balance_after, reason, created_at
  )
  SELECT
    lower(hex(randomblob(16))),
    NEW.member_id,
    NEW.id,
    NEW.credits,
    credits,
    'payment_approval',
    NEW.reviewed_at
  FROM members
  WHERE id = NEW.member_id;
END;
