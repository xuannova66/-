/** Pure validation only: caller MUST obtain these fields from a trusted,
 * chain-specific finalized transaction parser, not from a client request.
 * No ledger mutation or chain integration is performed by this module.
 */
export type SettlementProof = {
  chain: string;
  transactionId: string;
  eventIndex: number;
  asset: string;
  recipient: string;
  buyer: string;
  amount: bigint;
  successful: boolean;
  finalized: boolean;
};

export type SettlementExpectation = {
  chain: string;
  asset: string;
  recipient: string;
  buyer: string;
  amount: bigint;
};

export function validateSettlement(proof: SettlementProof, expected: SettlementExpectation): void {
  if (!proof.successful || !proof.finalized) throw new Error("SETTLEMENT_NOT_FINAL");
  if (!proof.chain || !proof.transactionId || !Number.isSafeInteger(proof.eventIndex) || proof.eventIndex < 0) throw new Error("INVALID_SETTLEMENT_ID");
  if (proof.chain !== expected.chain || !expected.chain) throw new Error("WRONG_CHAIN");
  // Address normalization is chain-specific and must happen in the parser:
  // Solana and TRON addresses are case-sensitive. Never lowercase them here.
  if (!expected.asset || proof.asset !== expected.asset) throw new Error("WRONG_ASSET");
  if (!expected.recipient || proof.recipient !== expected.recipient) throw new Error("WRONG_RECIPIENT");
  if (!expected.buyer || proof.buyer !== expected.buyer) throw new Error("WRONG_BUYER");
  if (expected.amount <= 0n || proof.amount !== expected.amount) throw new Error("WRONG_AMOUNT");
}
