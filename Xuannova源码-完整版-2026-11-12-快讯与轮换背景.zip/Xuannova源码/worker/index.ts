/** Cloudflare Worker entry point for the vinext-starter template. */
import { handleImageOptimization, DEFAULT_DEVICE_SIZES, DEFAULT_IMAGE_SIZES } from "vinext/server/image-optimization";
import handler from "vinext/server/app-router-entry";
import { handleCommerceApi, syncPurchasesFromChain, type CommerceEnv } from "./commerce-api";
import { handleGeocodingApi } from "./geocoding-api";
import { sharedDatabase } from "../server/sqlite-db";

interface Env extends CommerceEnv {
  ASSETS: { fetch(request: Request): Promise<Response> };
  IMAGES: {
    input(stream: ReadableStream): {
      transform(options: Record<string, unknown>): {
        output(options: { format: string; quality: number }): Promise<{ response(): Response }>;
      };
    };
  };
}

interface ExecutionContext {
  waitUntil(promise: Promise<unknown>): void;
  passThroughOnException(): void;
}

/**
 * Cloudflare provides bindings as `env`; the self-hosted Node runtime invokes
 * this entry without them. Recreate the commerce bindings from process.env so
 * checkout, sessions and SQLite use the same configuration in both runtimes.
 */
function commerceEnvironment(env: CommerceEnv | undefined): CommerceEnv {
  if (env) return env;
  return {
    DB: sharedDatabase(),
    ADMIN_EMAIL: process.env.ADMIN_EMAIL,
    ADMIN_EMAILS: process.env.ADMIN_EMAILS,
    ADMIN_PASSWORD: process.env.ADMIN_PASSWORD,
    SESSION_SECRET: process.env.SESSION_SECRET,
    DEEPSEEK_API_KEY: process.env.DEEPSEEK_API_KEY,
    DEEPSEEK_MODEL: process.env.DEEPSEEK_MODEL,
    FREE_FULL_TOOLS: process.env.FREE_FULL_TOOLS,
    HALL_LAMP_COST: process.env.HALL_LAMP_COST,
    FLASH_API_TOKEN: process.env.FLASH_API_TOKEN,
    VISION_API_URL: process.env.VISION_API_URL,
    VISION_API_KEY: process.env.VISION_API_KEY,
    VISION_MODEL: process.env.VISION_MODEL,
    VISION_DAILY_LIMIT: process.env.VISION_DAILY_LIMIT,
    CREDIT_STORE_ADDRESS: process.env.CREDIT_STORE_ADDRESS,
    USDC_CHECKOUT_ADDRESS: process.env.USDC_CHECKOUT_ADDRESS,
    USDC_CHECKOUT_ENABLED: process.env.USDC_CHECKOUT_ENABLED,
    USDC_CHECKOUT_REPLACE_LEGACY: process.env.USDC_CHECKOUT_REPLACE_LEGACY,
    USDC_CHECKOUT_TOKENS: process.env.USDC_CHECKOUT_TOKENS,
    MULTICHAIN_WALLET_LINK_ENABLED: process.env.MULTICHAIN_WALLET_LINK_ENABLED,
    MULTICHAIN_DRAFT_RECOVERY_ENABLED: process.env.MULTICHAIN_DRAFT_RECOVERY_ENABLED,
    MULTICHAIN_DRAFT_ORDERS_ENABLED: process.env.MULTICHAIN_DRAFT_ORDERS_ENABLED,
    ETHEREUM_DRAFT_USDC_ADDRESS: process.env.ETHEREUM_DRAFT_USDC_ADDRESS,
    BSC_RPC_URLS: process.env.BSC_RPC_URLS,
    BSC_CHAIN_ID: process.env.BSC_CHAIN_ID,
    USDT_ADDRESS: process.env.USDT_ADDRESS,
    GOOGLE_CLIENT_ID: process.env.GOOGLE_CLIENT_ID,
    RESEND_API_KEY: process.env.RESEND_API_KEY,
    MAIL_FROM: process.env.MAIL_FROM,
    SITE_URL: process.env.SITE_URL,
    DODO_API_KEY: process.env.DODO_API_KEY,
    DODO_WEBHOOK_SECRET: process.env.DODO_WEBHOOK_SECRET,
    DODO_ENVIRONMENT: process.env.DODO_ENVIRONMENT,
    DODO_PRODUCTS: process.env.DODO_PRODUCTS,
    COOKIE_DOMAIN: process.env.COOKIE_DOMAIN,
    ETHEREUM_RPC_URL: process.env.ETHEREUM_RPC_URL,
    ETHEREUM_CONFIRMATIONS: process.env.ETHEREUM_CONFIRMATIONS,
    SOLANA_RPC_URL: process.env.SOLANA_RPC_URL,
    TRON_API_URL: process.env.TRON_API_URL,
    TRON_API_KEY: process.env.TRON_API_KEY,
    WALLET_PAY_ENABLED: process.env.WALLET_PAY_ENABLED,
    LIBRARY_TRANSLATE_MEMBER_DAILY: process.env.LIBRARY_TRANSLATE_MEMBER_DAILY,
    LIBRARY_TRANSLATE_GUEST_DAILY: process.env.LIBRARY_TRANSLATE_GUEST_DAILY,
    LIBRARY_TRANSLATE_SITE_DAILY: process.env.LIBRARY_TRANSLATE_SITE_DAILY,
    LIBRARY_BASE_URL: process.env.LIBRARY_BASE_URL,
  };
}

// Image security config. SVG sources with .svg extension auto-skip the
// optimization endpoint on the client side (served directly, no proxy).
// To route SVGs through the optimizer (with security headers), set
// dangerouslyAllowSVG: true in next.config.js and uncomment below:
// const imageConfig: ImageConfig = { dangerouslyAllowSVG: true };

const worker = {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(request.url);

    const geocodingResponse = await handleGeocodingApi(request);
    if (geocodingResponse) return geocodingResponse;

    const commerceResponse = await handleCommerceApi(request, commerceEnvironment(env));
    if (commerceResponse) return commerceResponse;

    if (url.pathname === "/_vinext/image") {
      const allowedWidths = [...DEFAULT_DEVICE_SIZES, ...DEFAULT_IMAGE_SIZES];
      return handleImageOptimization(request, {
        fetchAsset: (path) => env.ASSETS.fetch(new Request(new URL(path, request.url))),
        transformImage: async (body, { width, format, quality }) => {
          const result = await env.IMAGES.input(body).transform(width > 0 ? { width } : {}).output({ format, quality });
          return result.response();
        },
      }, allowedWidths);
    }

    return handler.fetch(request, env, ctx);
  },
  /** Cron trigger (add `triggers.crons` in the Cloudflare config, e.g. every minute) to credit missed on-chain purchases. */
  async scheduled(_event: unknown, env: Env, ctx: ExecutionContext): Promise<void> {
    ctx.waitUntil(syncPurchasesFromChain(env));
    if (env.USDC_CHECKOUT_ADDRESS) ctx.waitUntil(syncPurchasesFromChain(env, "usdc"));
  },
};

export default worker;
