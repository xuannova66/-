// 研习殿 · 同殿共修: who is in the hall right now. Each browser sends a heartbeat every ~30 s; the hall shows the
// other visitors as little disciples with a 道号 (a random auspicious one, or one the visitor chose). Only the name,
// a seed for the avatar and the page being studied are kept, never birth data, and rows vanish ~90 s after the
// last heartbeat. The presence id is derived from the device cookie on the server, so nobody can speak for another.

type Statement = { bind(...values: unknown[]): Statement; first<T>(): Promise<T | null>; all<T>(): Promise<{ results?: T[] }>; run(): Promise<unknown> };
type Database = { prepare(sql: string): Statement };

// Natural names for the hall: Taoist names (often with 子 / 居士 / 道人 / 散人) and everyday nicknames, with pinyin.
const DAO_NAMES: Array<[string, string]> = [["清风", "Qingfeng"], ["明月", "Mingyue"], ["静远", "Jingyuan"], ["若水", "Ruoshui"], ["守一", "Shouyi"], ["抱朴", "Baopu"], ["致虚", "Zhixu"], ["玄素", "Xuansu"], ["云鹤", "Yunhe"], ["松风", "Songfeng"], ["竹溪", "Zhuxi"], ["悟真", "Wuzhen"], ["归真", "Guizhen"], ["养浩", "Yanghao"], ["怀素", "Huaisu"], ["知白", "Zhibai"], ["守拙", "Shouzhuo"], ["清和", "Qinghe"], ["澄心", "Chengxin"], ["观澜", "Guanlan"], ["听雨", "Tingyu"], ["望舒", "Wangshu"], ["青崖", "Qingya"], ["远山", "Yuanshan"], ["晴川", "Qingchuan"], ["南山", "Nanshan"], ["秋水", "Qiushui"], ["晓风", "Xiaofeng"], ["云舒", "Yunshu"], ["素心", "Suxin"], ["安然", "Anran"], ["宁远", "Ningyuan"], ["明心", "Mingxin"], ["修远", "Xiuyuan"], ["了凡", "Liaofan"], ["一如", "Yiru"], ["无尘", "Wuchen"], ["云起", "Yunqi"], ["霁月", "Jiyue"], ["松涛", "Songtao"], ["石泉", "Shiquan"], ["鹤鸣", "Heming"], ["采薇", "Caiwei"], ["怀瑾", "Huaijin"], ["长庚", "Changgeng"], ["太和", "Taihe"], ["冲和", "Chonghe"], ["守静", "Shoujing"], ["存真", "Cunzhen"], ["含光", "Hanguang"], ["抱一", "Baoyi"], ["清虚", "Qingxu"], ["玄同", "Xuantong"], ["知止", "Zhizhi"], ["自在", "Zizai"], ["青松", "Qingsong"], ["白云", "Baiyun"], ["紫霞", "Zixia"], ["若谷", "Ruogu"], ["听松", "Tingsong"], ["观云", "Guanyun"], ["寻真", "Xunzhen"], ["守中", "Shouzhong"], ["致远", "Zhiyuan"], ["澹然", "Danran"], ["林泉", "Linquan"], ["云水", "Yunshui"], ["逍遥", "Xiaoyao"], ["静观", "Jingguan"], ["问渠", "Wenqu"], ["月溪", "Yuexi"], ["清源", "Qingyuan"], ["妙真", "Miaozhen"], ["灵均", "Lingjun"], ["慧明", "Huiming"], ["道宁", "Daoning"]];
const NICKNAMES: Array<[string, string]> = [["林溪", "Lin Xi"], ["陈默", "Chen Mo"], ["周周", "Zhouzhou"], ["阿禾", "A He"], ["小满", "Xiaoman"], ["若初", "Ruochu"], ["知夏", "Zhixia"], ["安安", "An'an"], ["苏木", "Sumu"], ["南乔", "Nanqiao"], ["一一", "Yiyi"], ["青禾", "Qinghe"], ["晚晴", "Wanqing"], ["小鹿", "Xiaolu"], ["木子", "Muzi"], ["星河", "Xinghe"], ["予安", "Yu'an"], ["阿远", "A Yuan"], ["小舟", "Xiaozhou"], ["沐沐", "Mumu"], ["老许", "Lao Xu"], ["阿杰", "A Jie"], ["小雨", "Xiaoyu"], ["知秋", "Zhiqiu"], ["半夏", "Banxia"], ["云朵", "Yunduo"], ["橙子", "Chengzi"], ["拾光", "Shiguang"], ["北辰", "Beichen"], ["初晴", "Chuqing"]];
// More everyday nicknames, so the hall never feels like one name generator.
const MORE_NICKNAMES: Array<[string, string]> = [["阿宁", "A Ning"], ["小白", "Xiaobai"], ["大鱼", "Dayu"], ["七七", "Qiqi"], ["鹿鸣", "Luming"], ["夏至", "Xiazhi"], ["清欢", "Qinghuan"], ["小橘", "Xiaoju"], ["子衿", "Zijin"], ["默默", "Momo"], ["阿梅", "A Mei"], ["老周", "Lao Zhou"], ["小陈", "Xiao Chen"], ["叶子", "Yezi"], ["花卷", "Huajuan"], ["山月", "Shanyue"], ["听风", "Tingfeng"], ["朝暮", "Zhaomu"], ["慢慢", "Manman"], ["阿泽", "A Ze"], ["一禾", "Yihe"], ["向晚", "Xiangwan"], ["时雨", "Shiyu"], ["温言", "Wenyan"], ["小林", "Xiao Lin"], ["阿森", "A Sen"], ["米粒", "Mili"], ["思远", "Siyuan"], ["长安", "Chang'an"], ["十一", "Shiyi"]];
// International members (shown the same in every language).
const WORLD_NAMES = ["Mia", "Daniel", "Sophie", "Lucas", "Emma", "Noah", "Hana", "Yuki", "Kenji", "Aiko", "Jiwoo", "Minho", "Seoyeon", "Minh Anh", "Linh", "Quang", "Ploy", "Nok", "Arthit", "Mali", "Chloe", "Ethan", "Grace", "Leo", "Olivia", "Ryan", "Sakura", "Haruto", "Dao", "Ben", "Isabel", "Marco", "Nina", "Tom", "Aria", "Kai", "Lena", "Sam", "Wei", "Jun"];
const SUFFIXES: Array<[string, string]> = [["子", "zi"], ["居士", "Jushi"], ["道人", "Daoren"], ["散人", "Sanren"]];

export const ONLINE_SECONDS = 75;
export const MAX_VISIBLE = 40;

/** A stable, natural-sounding name for an id: mostly Taoist names (some with 子 / 居士 / 道人 / 散人), some everyday nicknames. */
export function randomDaoName(id: string) {
  let hash = 2166136261;
  for (const char of id) { hash ^= char.charCodeAt(0); hash = Math.imul(hash, 16777619); }
  hash >>>= 0;
  const kind = hash % 100;
  if (kind < 14) { const name = WORLD_NAMES[Math.floor(hash / 100) % WORLD_NAMES.length]; return { name, latin: name }; }
  if (kind < 38) { const pool = [...NICKNAMES, ...MORE_NICKNAMES]; const [name, latin] = pool[Math.floor(hash / 100) % pool.length]; return { name, latin }; }
  const [base, baseLatin] = DAO_NAMES[Math.floor(hash / 100) % DAO_NAMES.length];
  if (kind < 75) return { name: base, latin: baseLatin };
  const [suffix, suffixLatin] = SUFFIXES[Math.floor(hash / 7919) % SUFFIXES.length];
  return { name: `${base}${suffix}`, latin: suffix === "子" ? `${baseLatin}zi` : `${baseLatin} ${suffixLatin}` };
}

const BLOCKED = /(https?:|www\.|\.com|\.net|\.cn|\.io|t\.me|@|微信|威信|vx|wx|qq|扣扣|telegram|whats\s*app|line\s*id|加我|私聊|代理|返利|赌|博彩|色情|约炮|fuck|shit|sex|porn)/i;
/** A visitor's own 道号: 1–10 characters of letters, digits or CJK, no links, contacts or abuse. */
export function cleanDaoName(value: unknown): string | null { return cleanText(value, 10); }
/** Short display text (names): letters, digits or CJK, no links, contacts or abuse. */
export function cleanText(value: unknown, max: number): string | null {
  if (typeof value !== "string") return null;
  const text = value.normalize("NFKC").replace(/[\u0000-\u001f\u007f\u200b-\u200f\u2028-\u202e]/g, "").replace(/\s+/g, " ").trim();
  const length = [...text].length;
  if (length < 1 || length > max) return null;
  if (!/^[\p{L}\p{N} ·・'-]+$/u.test(text)) return null;
  if (BLOCKED.test(text.replace(/\s/g, "")) || /\d{5,}/.test(text)) return null;
  return text;
}

const ROUTE = /^[a-z][a-z0-9-]{1,30}$/;

export async function presenceId(deviceId: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`hall|${deviceId}`));
  return [...new Uint8Array(digest)].slice(0, 8).map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

export type HallVisitor = { id: string; name: string; latin: string; custom: boolean; route: string | null };

/** Record a heartbeat and return the visitors online now (the caller first). */
export async function heartbeat(db: Database, input: { id: string; name?: unknown; route?: unknown; now: Date }) {
  const nowIso = input.now.toISOString();
  const previous = await db.prepare("SELECT name, custom FROM hall_presence WHERE id = ?").bind(input.id).first<{ name: string; custom: number }>();
  let custom = Boolean(previous?.custom);
  let name = previous?.name ?? "";
  let rejected = false;
  if (input.name === "") { custom = false; name = ""; }
  else if (input.name !== undefined && input.name !== null) {
    const clean = cleanDaoName(input.name);
    if (clean) { name = clean; custom = true; } else rejected = true;
  }
  if (!custom || !name) { name = randomDaoName(input.id).name; custom = false; }
  const route = typeof input.route === "string" && ROUTE.test(input.route) ? input.route : null;
  await db.prepare("INSERT INTO hall_presence (id, name, custom, route, last_seen) VALUES (?, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET name = excluded.name, custom = excluded.custom, route = excluded.route, last_seen = excluded.last_seen")
    .bind(input.id, name, custom ? 1 : 0, route, nowIso).run();
  // Forget anyone silent for a while (cheap: indexed by last_seen).
  await db.prepare("DELETE FROM hall_presence WHERE last_seen < ?").bind(new Date(input.now.getTime() - 10 * 60_000).toISOString()).run();
  const since = new Date(input.now.getTime() - ONLINE_SECONDS * 1000).toISOString();
  const count = await db.prepare("SELECT COUNT(*) AS n FROM hall_presence WHERE last_seen >= ?").bind(since).first<{ n: number }>();
  const rows = (await db.prepare("SELECT id, name, custom, route FROM hall_presence WHERE last_seen >= ? AND id <> ? ORDER BY last_seen DESC LIMIT ?").bind(since, input.id, MAX_VISIBLE).all<{ id: string; name: string; custom: number; route: string | null }>()).results ?? [];
  const visitor = (row: { id: string; name: string; custom: number; route: string | null }): HallVisitor => ({ id: row.id, name: row.name, latin: row.custom ? "" : randomDaoName(row.id).latin, custom: Boolean(row.custom), route: row.route });
  return { self: visitor({ id: input.id, name, custom: custom ? 1 : 0, route }), others: rows.map(visitor), online: Number(count?.n ?? 1), rejected };
}

export async function leave(db: Database, id: string) {
  await db.prepare("UPDATE hall_presence SET last_seen = ? WHERE id = ?").bind(new Date(0).toISOString(), id).run();
}
