/** Isolated wallet-link primitives: NOT connected to sessions or checkout.
 * Challenges must be issued server-side, bound to an authenticated member,
 * stored durably and consumed atomically before linking any wallet.
 */
import { bytesToHex, concat, hexToBytes, keccak256, recoverAddress, sha256, toBytes, type Hex } from "viem";
const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
function decode58(text: string): Uint8Array {
  if (!text || text.length > 90) throw new Error("INVALID_BASE58");
  let n = 0n; for (const c of text) { const d = ALPHABET.indexOf(c); if (d < 0) throw new Error("INVALID_BASE58"); n = n * 58n + BigInt(d); }
  const out: number[] = []; while (n > 0n) { out.unshift(Number(n & 255n)); n >>= 8n; }
  let zeros = 0; while (text[zeros] === "1") zeros++;
  return Uint8Array.from([...new Array<number>(zeros).fill(0), ...out]);
}
function tronPayload(address: string): Uint8Array {
  const bytes = decode58(address);
  if (bytes.length !== 25 || bytes[0] !== 0x41) throw new Error("INVALID_TRON_ADDRESS");
  const digest = hexToBytes(sha256(hexToBytes(sha256(bytes.slice(0, 21)))));
  if (!bytes.slice(21).every((b, i) => b === digest[i])) throw new Error("INVALID_TRON_ADDRESS");
  return bytes.slice(1, 21);
}
/** Base58Check validation is mandatory before using a TRON address in RPC proofs. */
export function tronAddressHex(address: string): string {
  return `41${bytesToHex(tronPayload(address)).slice(2)}`;
}
export type WalletLinkChallenge = { memberId: string; chain: "solana" | "tron"; address: string; origin: string; nonce: string; issuedAt: number; expiresAt: number };
export function walletLinkMessage(challenge: WalletLinkChallenge, now: number): string {
  const { memberId, chain, address, origin, nonce, issuedAt, expiresAt } = challenge;
  if (!/^[a-zA-Z0-9_-]{1,128}$/.test(memberId) || !/^[a-f0-9]{64}$/.test(nonce) || !["solana", "tron"].includes(chain)) throw new Error("INVALID_CHALLENGE");
  const parsed = new URL(origin);
  if (parsed.protocol !== "https:" || parsed.origin !== origin || parsed.username || parsed.password) throw new Error("INVALID_ORIGIN");
  if (!Number.isSafeInteger(now) || !Number.isSafeInteger(issuedAt) || !Number.isSafeInteger(expiresAt) || issuedAt > now || expiresAt <= now || expiresAt <= issuedAt || expiresAt - issuedAt > 300) throw new Error("CHALLENGE_EXPIRED");
  if (chain === "solana") { if (decode58(address).length !== 32) throw new Error("INVALID_SOLANA_ADDRESS"); }
  else tronPayload(address);
  return `Xuannova wallet link\nOrigin: ${origin}\nMember: ${memberId}\nChain: ${chain}\nAddress: ${address}\nNonce: ${nonce}\nIssued: ${issuedAt}\nExpires: ${expiresAt}\nThis signature does not authorize a transaction.`;
}
export function tronMessageHash(message: string): Hex {
  const encoded = toBytes(message);
  return keccak256(concat([toBytes(`\x19TRON Signed Message:\n${encoded.length}`), encoded]));
}
export async function verifyWalletLinkSignature(challenge: WalletLinkChallenge, now: number, signature: Uint8Array | Hex): Promise<boolean> {
  try {
    const message = walletLinkMessage(challenge, now);
    if (challenge.chain === "solana") {
      if (!(signature instanceof Uint8Array) || signature.length !== 64) return false;
      const key = await crypto.subtle.importKey("raw", decode58(challenge.address) as BufferSource, { name: "Ed25519" }, false, ["verify"]);
      return await crypto.subtle.verify("Ed25519", key, signature as BufferSource, toBytes(message) as BufferSource);
    }
    if (typeof signature !== "string" || !/^0x[0-9a-fA-F]{130}$/.test(signature)) return false;
    // Wallets may return v=0/1 or 27/28. Reject all other recovery values.
    const bytes = hexToBytes(signature); const v = bytes[64];
    if (v === 0 || v === 1) bytes[64] += 27;
    else if (v !== 27 && v !== 28) return false;
    const recovered = await recoverAddress({ hash: tronMessageHash(message), signature: bytesToHex(bytes) });
    return recovered.toLowerCase() === bytesToHex(tronPayload(challenge.address)).toLowerCase();
  } catch { return false; }
}

/** Caller must first authenticate memberId, trust the server-selected origin,
 * then create the nonce with secure randomness and persist it in the draft
 * table. Atomic conditional consumption prevents concurrent signature replay.
 * Consuming a challenge alone does not attach a wallet or start a session.
 */
export async function consumeWalletLinkChallenge(db: { prepare(sql: string): { bind(...values: unknown[]): { run(): Promise<{ meta?: { changes?: number } }> } } }, challenge: WalletLinkChallenge, now: number, signature: Uint8Array | Hex): Promise<boolean> {
  if (!await verifyWalletLinkSignature(challenge, now, signature)) return false;
  const result = await db.prepare("UPDATE wallet_link_challenges_draft SET consumed_at = ? WHERE nonce = ? AND member_id = ? AND chain = ? AND address = ? AND origin = ? AND issued_at = ? AND expires_at = ? AND consumed_at IS NULL AND issued_at <= ? AND expires_at > ?")
    .bind(now, challenge.nonce, challenge.memberId, challenge.chain, challenge.address, challenge.origin, challenge.issuedAt, challenge.expiresAt, now, now).run();
  return result.meta?.changes === 1;
}

type DraftStatement = { bind(...values: unknown[]): DraftStatement; run(): Promise<{ meta?: { changes?: number } }> };
type DraftDatabase = { prepare(sql: string): DraftStatement; batch(statements: DraftStatement[]): Promise<Array<{ meta?: { changes?: number } }>> };

/** Only call with member and origin taken from an already authenticated,
 * same-origin request; never use client-supplied memberId/origin as authority.
 */
export async function issueDraftWalletLink(db: DraftDatabase, input: { memberId: string; chain: "solana" | "tron"; address: string; origin: string; now: number }) {
  const nonce = bytesToHex(crypto.getRandomValues(new Uint8Array(32))).slice(2);
  const challenge: WalletLinkChallenge = { memberId: input.memberId, chain: input.chain, address: input.address, origin: input.origin, nonce, issuedAt: input.now, expiresAt: input.now + 300 };
  const message = walletLinkMessage(challenge, input.now);
  await db.prepare("INSERT INTO wallet_link_challenges_draft(nonce, member_id, chain, address, origin, issued_at, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?)")
    .bind(challenge.nonce, challenge.memberId, challenge.chain, challenge.address, challenge.origin, challenge.issuedAt, challenge.expiresAt).run();
  return { challenge, message };
}

/** Signature check followed by one atomic challenge-consume + link operation.
 * A wallet already linked to another member is never reassigned.
 */
export async function completeDraftWalletLink(db: DraftDatabase, challenge: WalletLinkChallenge, now: number, signature: Uint8Array | Hex): Promise<boolean> {
  if (!await verifyWalletLinkSignature(challenge, now, signature)) return false;
  const consume = db.prepare("UPDATE wallet_link_challenges_draft SET consumed_at = ? WHERE nonce = ? AND member_id = ? AND chain = ? AND address = ? AND origin = ? AND issued_at = ? AND expires_at = ? AND consumed_at IS NULL AND issued_at <= ? AND expires_at > ?")
    .bind(now, challenge.nonce, challenge.memberId, challenge.chain, challenge.address, challenge.origin, challenge.issuedAt, challenge.expiresAt, now, now);
  const link = db.prepare("INSERT INTO member_wallet_links_draft(chain,address,member_id,linked_at) SELECT ?,?,?,? WHERE changes() = 1 ON CONFLICT(chain,address) DO UPDATE SET linked_at = member_wallet_links_draft.linked_at WHERE member_wallet_links_draft.member_id = excluded.member_id")
    .bind(challenge.chain, challenge.address, challenge.memberId, now);
  const results = await db.batch([consume, link]);
  return results[0]?.meta?.changes === 1 && results[1]?.meta?.changes === 1;
}
