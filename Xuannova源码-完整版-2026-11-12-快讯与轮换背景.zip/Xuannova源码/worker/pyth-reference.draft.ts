/** Server-side research adapter; NOT enabled or wired to live checkout.
 * Fetches Pyth over authenticated HTTPS; does not verify signed payloads on
 * chain. Feed mappings must be independently verified per wrapped asset.
 * Never expose the API key to browser clients or logs.
 */
import {getAddress,type Address} from "viem";
type Fetcher=(url:string,init:RequestInit)=>Promise<Response>;
type Feed={id:string;chainId:number;asset:Address;decimals:number};
type Price={price:string;conf:string;expo:number;publish_time:number};
const ENDPOINT="https://pyth.dourolabs.app/hermes/v2/updates/price/latest";
function feedId(value:string){const id=value.replace(/^0x/i,"").toLowerCase();if(!/^[a-f0-9]{64}$/.test(id))throw new Error("INVALID_PRICE_FEED");return id;}
function validatedFeed(feed:Feed,chainId:number,asset:Address){if(feed.chainId!==chainId||getAddress(feed.asset)!==getAddress(asset)||!Number.isInteger(feed.decimals)||feed.decimals<0||feed.decimals>18)throw new Error("PRICE_FEED_MAPPING_MISMATCH");return feedId(feed.id);}
function unpack(parsed:unknown,id:string,now:number):Price {
 if(!Array.isArray(parsed))throw new Error("INVALID_PRICE_RESPONSE");
 const records=parsed.filter(x=>x&&typeof x==="object"&&typeof x.id==="string"&&x.id.toLowerCase().replace(/^0x/,"")===id);
 if(records.length!==1)throw new Error("INVALID_PRICE_RESPONSE");
 const p=records[0].price as Partial<Price>|undefined;
 if(!p||typeof p.price!=="string"||!/^\d{1,30}$/.test(p.price)||typeof p.conf!=="string"||!/^\d{1,30}$/.test(p.conf)||!Number.isInteger(p.expo)||p.expo!< -18||p.expo!>18||!Number.isSafeInteger(p.publish_time)||p.publish_time!>now||now-p.publish_time!>30)throw new Error("STALE_OR_INVALID_PRICE");
 const price=BigInt(p.price),confidence=BigInt(p.conf);
 if(price<=0n||confidence*100n>price)throw new Error("PRICE_CONFIDENCE_TOO_WIDE");
 return p as Price;
}
/** Returns input-token base units for the target output using midpoint prices,
 * rounded upward. The quote gate separately bounds max input to 102%.
 * No assumption that USDC is exactly one dollar is made. */
export async function pythReferenceDraft(input:{apiKey:string;chainId:number;asset:Address;settlement:Address;outputUnits:bigint;inputFeed:Feed;settlementFeed:Feed;clock:()=>number;fetcher?:Fetcher}) {
 if(typeof input.apiKey!=="string"||input.apiKey.length<8||input.apiKey.length>512)throw new Error("PRICE_SOURCE_NOT_CONFIGURED");
 if(typeof input.outputUnits!=="bigint"||input.outputUnits<=0n)throw new Error("INVALID_OUTPUT_AMOUNT");
 const inId=validatedFeed(input.inputFeed,input.chainId,input.asset),outId=validatedFeed(input.settlementFeed,input.chainId,input.settlement);
 if(inId===outId)throw new Error("INVALID_PRICE_FEED");
 const url=new URL(ENDPOINT);url.searchParams.append("ids[]",`0x${inId}`);url.searchParams.append("ids[]",`0x${outId}`);
 let response:Response;try{response=await (input.fetcher??fetch)(url.toString(),{method:"GET",headers:{authorization:`Bearer ${input.apiKey}`},signal:AbortSignal.timeout(8000)});}catch{throw new Error("PRICE_SOURCE_UNAVAILABLE");}
 if(!response.ok)throw new Error("PRICE_SOURCE_UNAVAILABLE");
 let body:unknown;try{body=await response.json();}catch{throw new Error("INVALID_PRICE_RESPONSE");}
 const now=input.clock();if(!Number.isSafeInteger(now)||now<=0)throw new Error("INVALID_TIME");
 const parsed=(body as {parsed?:unknown})?.parsed,base=unpack(parsed,inId,now),settled=unpack(parsed,outId,now);
 const exponent=input.inputFeed.decimals-input.settlementFeed.decimals+settled.expo-base.expo;
 const numerator=input.outputUnits*BigInt(settled.price)*(exponent>=0?10n**BigInt(exponent):1n);
 const denominator=BigInt(base.price)*(exponent<0?10n**BigInt(-exponent):1n);
 const inputUnits=(numerator+denominator-1n)/denominator;
 if(inputUnits<=0n || inputUnits>=(1n<<256n))throw new Error("INVALID_REFERENCE_PRICE");
 return {inputUnits,observedAt:Math.min(base.publish_time,settled.publish_time)};
}
