// 藏经阁 on-demand translation: the reader asks for the paragraphs on screen, the server reads those paragraphs
// from the site's own library files (it never translates text sent by the browser), translates them once with the
// text model and caches the result, so each passage is paid for once per language.
// Chinese readers get a modern vernacular rendering (白话); other languages get a translation.
type Fetcher = (input: string, init?: RequestInit) => Promise<Response>;

export class LibraryTranslateError extends Error {
  constructor(public readonly code: "INVALID_REQUEST" | "NOT_FOUND" | "AI_NOT_CONFIGURED" | "AI_UNAVAILABLE" | "AI_INVALID_RESPONSE", public readonly status = 400) { super(code); }
}

export type TranslateRequest = { book: string; script: "zh-Hans" | "zh-Hant"; part: number; chapter: number; from: number; to: number; locale: string };
export const LOCALES = new Set(["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"]);
export const MAX_PARAGRAPHS = 12;
export const MAX_CHARS = 6000;

export function parseTranslateRequest(value: unknown): TranslateRequest | null {
  const record = value && typeof value === "object" ? value as Record<string, unknown> : null;
  if (!record) return null;
  const int = (key: string) => (Number.isInteger(record[key]) && (record[key] as number) >= 0 && (record[key] as number) < 100_000 ? record[key] as number : -1);
  const book = typeof record.book === "string" && /^[a-z0-9-]{2,40}$/.test(record.book) ? record.book : "";
  const script = record.script === "zh-Hant" ? "zh-Hant" : record.script === "zh-Hans" ? "zh-Hans" : null;
  const locale = typeof record.locale === "string" && LOCALES.has(record.locale) ? record.locale : "";
  const [part, chapter, from, to] = [int("part"), int("chapter"), int("from"), int("to")];
  if (!book || !script || !locale || part < 0 || chapter < 0 || from < 0 || to <= from || to - from > MAX_PARAGRAPHS) return null;
  return { book, script, part, chapter, from, to, locale };
}

type Manifest = Record<string, { dir: string }>;
type Chapter = { title: string; text: string };
const fileCache = new Map<string, Promise<unknown>>();
function cachedJson(url: string, fetcher: Fetcher) {
  let entry = fileCache.get(url);
  if (!entry) {
    entry = fetcher(url, { signal: AbortSignal.timeout(10_000) }).then((response) => (response.ok ? response.json() : null)).catch(() => null);
    entry.then((value) => { if (value === null) fileCache.delete(url); });
    fileCache.set(url, entry);
    if (fileCache.size > 60) fileCache.delete(fileCache.keys().next().value as string);
  }
  return entry;
}

/** The original paragraphs, read from the published library files. */
export async function sourceParagraphs(base: string, input: TranslateRequest, fetcher: Fetcher = fetch) {
  const manifest = await cachedJson(`${base}/library/manifest.json`, fetcher) as Manifest | null;
  const dir = manifest?.[input.book]?.dir;
  if (!dir || !/^[a-z0-9-]+$/.test(dir)) throw new LibraryTranslateError("NOT_FOUND", 404);
  const chapters = await cachedJson(`${base}/library/${dir}/${input.script}-${input.part}.json`, fetcher) as Chapter[] | null;
  const chapter = Array.isArray(chapters) ? chapters[input.chapter] : undefined;
  if (!chapter || typeof chapter.text !== "string") throw new LibraryTranslateError("NOT_FOUND", 404);
  const paragraphs = chapter.text.split("\n");
  if (input.to > paragraphs.length) throw new LibraryTranslateError("INVALID_REQUEST");
  const selected = paragraphs.slice(input.from, input.to);
  if (selected.join("").length > MAX_CHARS && selected.length > 1) throw new LibraryTranslateError("INVALID_REQUEST");
  return { dir, title: chapter.title, paragraphs: selected };
}

const languageName: Record<string, string> = { en: "English", ja: "Japanese", ko: "Korean", vi: "Vietnamese", th: "Thai", "zh-Hans": "modern vernacular Simplified Chinese (白话文)", "zh-Hant": "modern vernacular Traditional Chinese (白話文)" };

export function buildTranslateMessages(paragraphs: string[], locale: string, title: string) {
  return [
    { role: "system", content: `You translate classical Chinese texts on Chinese metaphysics (Yijing, BaZi, Liu Ren, Qi Men, Feng Shui and related classics) into ${languageName[locale] ?? "English"}. Translate faithfully and clearly for a modern reader; do not add commentary, do not summarise, do not skip anything. Keep technical terms recognisable: on first use give the term in pinyin or the reader's usual rendering followed by the Chinese characters in parentheses (for Chinese output, just explain the term in plain modern words). Keep names of people, books and stars. Return JSON only: {"paragraphs": [string, ...]} with exactly one entry per input paragraph, in the same order; an empty input paragraph stays an empty string.` },
    { role: "user", content: JSON.stringify({ chapter: title, paragraphs }) },
  ];
}

export function parseTranslation(content: string, count: number) {
  let value: unknown;
  try { value = JSON.parse(content.replace(/^```(?:json)?\s*|\s*```$/g, "")); } catch { throw new LibraryTranslateError("AI_INVALID_RESPONSE", 502); }
  const list = (value as { paragraphs?: unknown })?.paragraphs;
  if (!Array.isArray(list) || list.length !== count || !list.every((item) => typeof item === "string")) throw new LibraryTranslateError("AI_INVALID_RESPONSE", 502);
  return (list as string[]).map((item) => item.trim().slice(0, 20_000));
}

export async function translateParagraphs(paragraphs: string[], locale: string, title: string, apiKey: string | undefined, model: string | undefined, fetcher: Fetcher = fetch) {
  if (!apiKey?.trim()) throw new LibraryTranslateError("AI_NOT_CONFIGURED", 503);
  const filled = paragraphs.map((text, index) => ({ text, index })).filter((item) => item.text.trim());
  if (!filled.length) return paragraphs.map(() => "");
  const translated = await translateList(filled.map((item) => item.text), locale, title, apiKey.trim(), model, fetcher, 0);
  const result = paragraphs.map(() => "");
  filled.forEach((item, position) => { result[item.index] = translated[position]; });
  return result;
}

/**
 * One model call for a list of paragraphs. Models sometimes merge very short lines (e.g. the Yijing's line texts) and
 * return fewer entries; then the list is split in halves and each half is translated on its own (at most twice), and
 * a single line that comes back in pieces is joined, so a passage is never refused for the count alone.
 */
async function translateList(texts: string[], locale: string, title: string, apiKey: string, model: string | undefined, fetcher: Fetcher, depth: number): Promise<string[]> {
  const chars = texts.reduce((sum, text) => sum + text.length, 0);
  let response: Response;
  try {
    response = await fetcher("https://api.deepseek.com/chat/completions", {
      method: "POST",
      headers: { authorization: `Bearer ${apiKey}`, "content-type": "application/json" },
      signal: AbortSignal.timeout(90_000),
      body: JSON.stringify({ model: model?.trim() || "deepseek-chat", messages: buildTranslateMessages(texts, locale, title), response_format: { type: "json_object" }, temperature: 0.2, max_tokens: Math.min(8000, 600 + chars * 3) }),
    });
  } catch { throw new LibraryTranslateError("AI_UNAVAILABLE", 502); }
  if (!response.ok) throw new LibraryTranslateError("AI_UNAVAILABLE", 502);
  const payload = await response.json().catch(() => null) as { choices?: Array<{ message?: { content?: unknown } }> } | null;
  const content = payload?.choices?.[0]?.message?.content;
  if (typeof content !== "string") throw new LibraryTranslateError("AI_INVALID_RESPONSE", 502);
  try { return parseTranslation(content, texts.length); }
  catch (cause) {
    if (!(cause instanceof LibraryTranslateError)) throw cause;
    if (texts.length === 1) {
      // One line answered in several pieces: keep them together.
      try { const value = JSON.parse(content.replace(/^```(?:json)?\s*|\s*```$/g, "")) as { paragraphs?: unknown }; if (Array.isArray(value.paragraphs) && value.paragraphs.length && value.paragraphs.every((item) => typeof item === "string")) return [(value.paragraphs as string[]).join("").trim().slice(0, 20_000)]; } catch { /* fall through */ }
      throw cause;
    }
    if (depth >= 2) throw cause;
    const middle = Math.ceil(texts.length / 2);
    const [first, second] = await Promise.all([translateList(texts.slice(0, middle), locale, title, apiKey, model, fetcher, depth + 1), translateList(texts.slice(middle), locale, title, apiKey, model, fetcher, depth + 1)]);
    return [...first, ...second];
  }
}

export async function textHash(paragraphs: string[]) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(paragraphs.join("\n")));
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("").slice(0, 32);
}
