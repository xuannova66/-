// Dodo Payments (card payments, merchant of record) for credit packages.
// Docs: https://docs.dodopayments.com — checkout sessions (POST /checkouts) and Standard Webhooks signatures.
// Configuration (all optional; the card button only appears when DODO_API_KEY and a product map are set):
//   DODO_API_KEY          secret API key (test-mode key with DODO_ENVIRONMENT=test)
//   DODO_WEBHOOK_SECRET   webhook signing secret from the Dodo dashboard (whsec_…)
//   DODO_ENVIRONMENT      "live" (default) or "test"
//   DODO_PRODUCTS         JSON map of credit package id → Dodo product id, e.g. {"seed":"pdt_…","path":"pdt_…"}

export type DodoEnv = { DODO_API_KEY?: string; DODO_WEBHOOK_SECRET?: string; DODO_ENVIRONMENT?: string; DODO_PRODUCTS?: string };

export function dodoBaseUrl(env: DodoEnv) {
  return env.DODO_ENVIRONMENT === "test" ? "https://test.dodopayments.com" : "https://live.dodopayments.com";
}

export function dodoProducts(env: DodoEnv): Record<string, string> {
  try {
    const parsed = JSON.parse(env.DODO_PRODUCTS ?? "{}") as Record<string, unknown>;
    return Object.fromEntries(Object.entries(parsed).filter(([, value]) => typeof value === "string" && /^[A-Za-z0-9_-]{3,80}$/.test(value)) as Array<[string, string]>);
  } catch { return {}; }
}

export const dodoEnabled = (env: DodoEnv) => Boolean(env.DODO_API_KEY && Object.keys(dodoProducts(env)).length);

export async function createDodoCheckout(env: DodoEnv, input: { productId: string; email?: string | null; returnUrl: string; metadata: Record<string, string> }, fetchImpl: typeof fetch = fetch) {
  const response = await fetchImpl(`${dodoBaseUrl(env)}/checkouts`, {
    method: "POST",
    headers: { authorization: `Bearer ${env.DODO_API_KEY}`, "content-type": "application/json" },
    body: JSON.stringify({
      product_cart: [{ product_id: input.productId, quantity: 1 }],
      ...(input.email ? { customer: { email: input.email } } : {}),
      return_url: input.returnUrl,
      metadata: input.metadata,
    }),
  });
  if (!response.ok) throw new Error(`Dodo checkout failed (${response.status})`);
  const body = await response.json() as { session_id?: string; checkout_url?: string | null };
  if (!body.checkout_url) throw new Error("Dodo checkout returned no URL");
  return { sessionId: body.session_id ?? null, url: body.checkout_url };
}

/** Read a payment back from Dodo so a webhook is never trusted on its own. */
export async function fetchDodoPayment(env: DodoEnv, paymentId: string, fetchImpl: typeof fetch = fetch) {
  const response = await fetchImpl(`${dodoBaseUrl(env)}/payments/${encodeURIComponent(paymentId)}`, { headers: { authorization: `Bearer ${env.DODO_API_KEY}` } });
  if (!response.ok) return null;
  return await response.json() as { payment_id?: string; status?: string; metadata?: Record<string, string>; total_amount?: number; currency?: string };
}

function base64ToBytes(value: string): Uint8Array<ArrayBuffer> {
  const binary = atob(value);
  return Uint8Array.from(binary, (character) => character.charCodeAt(0)) as Uint8Array<ArrayBuffer>;
}
function bytesToBase64(bytes: ArrayBuffer) {
  let binary = "";
  for (const byte of new Uint8Array(bytes)) binary += String.fromCharCode(byte);
  return btoa(binary);
}

/**
 * Standard Webhooks verification: HMAC-SHA256 over "<webhook-id>.<webhook-timestamp>.<raw body>" with the
 * base64 secret after "whsec_"; the header holds one or more "v1,<base64 signature>" entries separated by spaces.
 * Deliveries older or newer than five minutes are rejected (replay protection).
 */
export async function verifyDodoWebhook(secret: string, headers: Headers, rawBody: string, nowMs = Date.now()) {
  const id = headers.get("webhook-id") ?? "";
  const timestamp = headers.get("webhook-timestamp") ?? "";
  const signatures = (headers.get("webhook-signature") ?? "").split(" ").map((entry) => entry.split(",")).filter(([version, value]) => version === "v1" && value).map(([, value]) => value);
  if (!id || !/^\d{9,11}$/.test(timestamp) || !signatures.length || !secret) return false;
  if (Math.abs(nowMs / 1000 - Number(timestamp)) > 300) return false;
  let keyBytes: Uint8Array<ArrayBuffer>;
  try { keyBytes = base64ToBytes(secret.startsWith("whsec_") ? secret.slice(6) : secret); } catch { keyBytes = new TextEncoder().encode(secret) as Uint8Array<ArrayBuffer>; }
  const key = await crypto.subtle.importKey("raw", keyBytes, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const expected = bytesToBase64(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(`${id}.${timestamp}.${rawBody}`)));
  return signatures.some((signature) => signature.length === expected.length && timingSafeEqual(signature, expected));
}

function timingSafeEqual(a: string, b: string) {
  let difference = 0;
  for (let index = 0; index < a.length; index += 1) difference |= a.charCodeAt(index) ^ b.charCodeAt(index);
  return difference === 0;
}

/** Sign a payload the same way (used by tests and for local webhook replays). */
export async function signDodoWebhook(secret: string, id: string, timestamp: string, rawBody: string) {
  const key = await crypto.subtle.importKey("raw", base64ToBytes(secret.replace(/^whsec_/, "")), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return `v1,${bytesToBase64(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(`${id}.${timestamp}.${rawBody}`)))}`;
}
