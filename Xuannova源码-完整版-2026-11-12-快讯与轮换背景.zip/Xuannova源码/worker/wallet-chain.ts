/**
 * Chain helpers shared by the worker and the browser:
 *  - XuanyuanCreditStore ABI (matches contracts/XuanyuanCreditStore.sol)
 *  - wallet sign-in message format
 *  - receipt verification for automatic credit issuance
 */
import {
  createPublicClient,
  fallback,
  getAddress,
  http,
  isAddress,
  keccak256,
  parseEventLogs,
  stringToHex,
  verifyMessage,
  type Address,
  type Hex,
} from "viem";
import { bscChain, creditPackages, packageUsdtWei, platformFeeWei } from "./commerce-policy";

export const creditStoreAbi = [
  {
    type: "function", name: "buy", stateMutability: "payable",
    inputs: [{ name: "packageId", type: "bytes32" }],
    outputs: [{ name: "saleIndex", type: "uint256" }],
  },
  { type: "function", name: "feeWei", stateMutability: "view", inputs: [], outputs: [{ name: "", type: "uint256" }] },
  { type: "function", name: "paused", stateMutability: "view", inputs: [], outputs: [{ name: "", type: "bool" }] },
  {
    type: "function", name: "packageById", stateMutability: "view",
    inputs: [{ name: "id", type: "string" }],
    outputs: [{ name: "usdtAmount", type: "uint256" }, { name: "credits", type: "uint32" }, { name: "active", type: "bool" }],
  },
  {
    type: "event", name: "Purchased",
    inputs: [
      { name: "buyer", type: "address", indexed: true },
      { name: "packageId", type: "bytes32", indexed: true },
      { name: "usdtAmount", type: "uint256", indexed: false },
      { name: "credits", type: "uint32", indexed: false },
      { name: "feeWei", type: "uint256", indexed: false },
      { name: "saleIndex", type: "uint256", indexed: false },
    ],
  },
] as const;

export const erc20Abi = [
  {
    type: "function", name: "allowance", stateMutability: "view",
    inputs: [{ name: "owner", type: "address" }, { name: "spender", type: "address" }],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    type: "function", name: "approve", stateMutability: "nonpayable",
    inputs: [{ name: "spender", type: "address" }, { name: "value", type: "uint256" }],
    outputs: [{ name: "", type: "bool" }],
  },
  {
    type: "function", name: "balanceOf", stateMutability: "view",
    inputs: [{ name: "account", type: "address" }],
    outputs: [{ name: "", type: "uint256" }],
  },
] as const;

/** keccak256 of the package id string — the bytes32 key used by the contract. */
export function packageKey(id: string): Hex {
  return keccak256(stringToHex(id));
}

export function normalizeAddress(value: unknown): Address | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  if (!isAddress(trimmed, { strict: false })) return null;
  try {
    return getAddress(trimmed);
  } catch {
    return null;
  }
}

export function normalizeTxHash(value: unknown): Hex | null {
  if (typeof value !== "string") return null;
  const hash = value.trim().toLowerCase();
  return /^0x[0-9a-f]{64}$/.test(hash) ? (hash as Hex) : null;
}

export const signInStatement = "Sign in to Xuanyuan Institute with your wallet.";

/** Human-readable EIP-191 message the wallet signs to prove ownership. */
export function buildSignInMessage(input: { domain: string; address: Address; nonce: string; issuedAt: string; chainId?: number }) {
  return [
    `${input.domain} wants you to sign in with your wallet:`,
    input.address,
    "",
    signInStatement,
    "",
    `Chain ID: ${input.chainId ?? bscChain.id}`,
    `Nonce: ${input.nonce}`,
    `Issued At: ${input.issuedAt}`,
    "",
    "This request will not trigger a blockchain transaction or cost any gas.",
  ].join("\n");
}

export async function verifyWalletSignature(address: Address, message: string, signature: unknown) {
  if (typeof signature !== "string" || !/^0x[0-9a-fA-F]{130}$/.test(signature)) return false;
  try {
    return await verifyMessage({ address, message, signature: signature as Hex });
  } catch {
    return false;
  }
}

export type VerifiedPurchase = {
  transactionHash: Hex;
  buyer: Address;
  contractAddress: Address;
  packageId: string;
  usdtAmount: bigint;
  credits: number;
  feeWei: bigint;
  saleIndex: bigint;
  blockNumber: bigint;
  confirmations: bigint;
};

export type PurchaseVerificationFailure =
  | "TX_NOT_FOUND"
  | "TX_PENDING"
  | "TX_REVERTED"
  | "WRONG_CONTRACT"
  | "NO_PURCHASE_EVENT"
  | "WRONG_BUYER"
  | "UNKNOWN_PACKAGE"
  | "AMOUNT_MISMATCH"
  | "FEE_MISMATCH"
  | "NOT_CONFIRMED"
  | "RPC_UNAVAILABLE";

export type PurchaseVerification = { ok: true; purchase: VerifiedPurchase } | { ok: false; reason: PurchaseVerificationFailure };

export function chainClient(rpcUrls: readonly string[] = bscChain.rpcUrls) {
  return createPublicClient({
    transport: fallback(rpcUrls.map((url) => http(url, { timeout: 12_000, retryCount: 1 }))),
  });
}

/**
 * Verify that `transactionHash` is a successful, confirmed purchase on the
 * XuanyuanCreditStore contract made by `expectedBuyer`, and return the package
 * details recorded in the `Purchased` event.
 */
export async function verifyPurchaseReceipt(input: {
  transactionHash: Hex;
  expectedBuyer: Address;
  contractAddress: Address;
  rpcUrls?: readonly string[];
  minimumConfirmations?: number;
}): Promise<PurchaseVerification> {
  const client = chainClient(input.rpcUrls);
  let receipt;
  let latestBlock: bigint;
  try {
    receipt = await client.getTransactionReceipt({ hash: input.transactionHash }).catch(() => null);
    if (!receipt) {
      const pending = await client.getTransaction({ hash: input.transactionHash }).catch(() => null);
      return { ok: false, reason: pending ? "TX_PENDING" : "TX_NOT_FOUND" };
    }
    latestBlock = await client.getBlockNumber({ cacheTime: 0 });
  } catch {
    return { ok: false, reason: "RPC_UNAVAILABLE" };
  }
  if (receipt.status !== "success") return { ok: false, reason: "TX_REVERTED" };
  // Wallet batch/relayer transactions can target an executor. Authenticate the
  // purchase by the emitting store address below, not the outer transaction.to.

  const purchases = parseEventLogs({ abi: creditStoreAbi, eventName: "Purchased", logs: receipt.logs })
    .filter((log) => getAddress(log.address) === input.contractAddress);
  if (purchases.length === 0) return { ok: false, reason: "NO_PURCHASE_EVENT" };
  const event = purchases.find((item) => getAddress(item.args.buyer) === input.expectedBuyer);
  if (!event) return { ok: false, reason: "WRONG_BUYER" };
  const buyer = getAddress(event.args.buyer);
  if (buyer !== input.expectedBuyer) return { ok: false, reason: "WRONG_BUYER" };

  const matched = creditPackages.find((item) => packageKey(item.id) === event.args.packageId);
  if (!matched) return { ok: false, reason: "UNKNOWN_PACKAGE" };
  if (event.args.usdtAmount !== packageUsdtWei(matched.id) || Number(event.args.credits) !== matched.credits) {
    return { ok: false, reason: "AMOUNT_MISMATCH" };
  }
  if (event.args.feeWei !== platformFeeWei) return { ok: false, reason: "FEE_MISMATCH" };

  const confirmations = latestBlock - receipt.blockNumber + 1n;
  const required = BigInt(input.minimumConfirmations ?? bscChain.confirmations);
  if (confirmations < required) return { ok: false, reason: "NOT_CONFIRMED" };

  return {
    ok: true,
    purchase: {
      transactionHash: input.transactionHash,
      buyer,
      contractAddress: input.contractAddress,
      packageId: matched.id,
      usdtAmount: event.args.usdtAmount,
      credits: matched.credits,
      feeWei: event.args.feeWei,
      saleIndex: event.args.saleIndex,
      blockNumber: receipt.blockNumber,
      confirmations,
    },
  };
}

export type PurchaseLog = {
  transactionHash: Hex;
  blockNumber: bigint;
  buyer: Address;
  packageId: string | null;
  usdtAmount: bigint;
  credits: number;
  feeWei: bigint;
  saleIndex: bigint;
};

/**
 * Read `Purchased` events emitted by the store contract in a block range.
 * Used by the background watcher to credit purchases whose buyer never
 * submitted the transaction hash (closed the tab, lost connectivity, …).
 */
export async function fetchPurchaseLogs(input: {
  contractAddress: Address;
  rpcUrls?: readonly string[];
  fromBlock: bigint;
  toBlock: bigint;
}): Promise<PurchaseLog[]> {
  const client = chainClient(input.rpcUrls);
  const event = creditStoreAbi.find((item) => item.type === "event" && item.name === "Purchased");
  if (!event) return [];
  const logs = await client.getLogs({ address: input.contractAddress, event, fromBlock: input.fromBlock, toBlock: input.toBlock });
  return logs.flatMap((log) => {
    if (getAddress(log.address) !== getAddress(input.contractAddress) || log.removed || log.blockNumber === null || log.transactionHash === null || log.blockNumber < input.fromBlock || log.blockNumber > input.toBlock) return [];
    if (!log.args.buyer || !log.args.packageId || log.args.usdtAmount === undefined || log.args.credits === undefined || log.args.feeWei === undefined || log.args.saleIndex === undefined) return [];
    const matched = creditPackages.find((item) => packageKey(item.id) === log.args.packageId);
    return [{
      transactionHash: log.transactionHash,
      blockNumber: log.blockNumber,
      buyer: getAddress(log.args.buyer),
      packageId: matched?.id ?? null,
      usdtAmount: log.args.usdtAmount,
      credits: Number(log.args.credits),
      feeWei: log.args.feeWei,
      saleIndex: log.args.saleIndex,
    }];
  });
}

export async function latestBlockNumber(rpcUrls?: readonly string[]) {
  return chainClient(rpcUrls).getBlockNumber({ cacheTime: 0 });
}
