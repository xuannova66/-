/** Local-only finalized-event recovery. Caller supplies trusted configured
 * contract/RPC and persists returned cursor only after successful completion.
 * This has no scheduler and never sends transactions. */
import {decodeEventLog,getAddress,parseAbi,type Address,type Hex} from "viem";
import {settleEthereumDraftOrder,type EthereumDraftRpc} from "./ethereum-order-settlement.draft";
const abi=parseAbi(["event Purchased(address indexed buyer, bytes32 indexed packageId, address indexed inputAsset, uint256 settlementAmount, uint32 credits, uint256 saleIndex, bytes32 orderReference)"]);
type Log={address:Address;data:Hex;topics:readonly Hex[];transactionHash:Hex|null;blockNumber:bigint|null;removed?:boolean};
type Statement={bind(...values:unknown[]):Statement;first<T>():Promise<T|null>;run():Promise<{meta?:{changes?:number}}>};
type Database={prepare(sql:string):Statement};
type Rpc=EthereumDraftRpc&{getLogs(input:{address:Address;fromBlock:bigint;toBlock:bigint}):Promise<readonly Log[]>};

export async function scanEthereumDraftEvents(db:Database,input:{rpc:Rpc;checkout:Address;settlementToken:Address;confirmations:number;fromBlock:bigint;toBlock:bigint;now:string}) {
 if(input.fromBlock<0n||input.toBlock<input.fromBlock||input.toBlock-input.fromBlock>499n)throw new Error("INVALID_BLOCK_RANGE");
 if(await input.rpc.getChainId()!==1)throw new Error("WRONG_CHAIN");
 const finalized=await input.rpc.getBlock({blockTag:"finalized"});
 if(finalized.number===null||input.toBlock>finalized.number)throw new Error("BLOCK_NOT_FINALIZED");
 const checkout=getAddress(input.checkout),logs=await input.rpc.getLogs({address:checkout,fromBlock:input.fromBlock,toBlock:input.toBlock});
 let matched=0,credited=0;
 for(const log of logs) {
  // A faulty RPC must not move the cursor past events while returning logs
  // from another range or pending logs without an assigned block.
  if(log.removed || getAddress(log.address)!==checkout || typeof log.blockNumber!=="bigint" || log.blockNumber<input.fromBlock || log.blockNumber>input.toBlock)throw new Error("INVALID_CHAIN_LOG");
  let reference:Hex;
  try {reference=decodeEventLog({abi,eventName:"Purchased",data:log.data,topics:log.topics as [Hex,...Hex[]]}).args.orderReference;}
  catch {continue;}
  if(!log.transactionHash || !/^0x[0-9a-fA-F]{64}$/.test(log.transactionHash))throw new Error("INVALID_CHAIN_LOG");
  const order=await db.prepare("SELECT id,member_id,status FROM multichain_orders_draft WHERE chain='ethereum' AND order_reference=?").bind(reference.slice(2).toLowerCase()).first<{id:string;member_id:string;status:string}>();
  if(!order||order.status!=="pending")continue;
  matched++;
  // Any failure aborts this range: never advance past an unverified purchase.
  const result=await settleEthereumDraftOrder(db,{memberId:order.member_id,orderId:order.id,txHash:log.transactionHash,checkout,settlementToken:input.settlementToken,confirmations:input.confirmations,rpc:input.rpc,now:input.now});
  if(!result.alreadyCredited)credited++;
 }
 return {matched,credited,nextBlock:input.toBlock+1n};
}

/** Caller may schedule this opt-in function after initializing from a known
 * deployment block. Compare-and-swap avoids moving a concurrent cursor back.
 * Never use without checking archive RPC retention and monitoring lag. */
export async function runEthereumEventRecoveryDraft(db:Database,input:{rpc:Rpc;checkout:Address;settlementToken:Address;confirmations:number;startBlock:bigint;now:string}) {
 if(input.startBlock<0n)throw new Error("INVALID_BLOCK_RANGE");
 const checkout=getAddress(input.checkout).toLowerCase();
 await db.prepare("INSERT OR IGNORE INTO ethereum_event_cursor_draft(checkout,next_block) VALUES(?,?)").bind(checkout,input.startBlock.toString()).run();
 const row=await db.prepare("SELECT next_block FROM ethereum_event_cursor_draft WHERE checkout=?").bind(checkout).first<{next_block:string}>();
 if(!row || !/^\d+$/.test(row.next_block))throw new Error("INVALID_CURSOR");
 const from=BigInt(row.next_block), finalized=await input.rpc.getBlock({blockTag:"finalized"});
 if(finalized.number===null)throw new Error("BLOCK_NOT_FINALIZED");
 if(from>finalized.number)return {matched:0,credited:0,nextBlock:from};
 const to=from+499n<finalized.number?from+499n:finalized.number;
 const result=await scanEthereumDraftEvents(db,{...input,fromBlock:from,toBlock:to});
 const update=await db.prepare("UPDATE ethereum_event_cursor_draft SET next_block=? WHERE checkout=? AND next_block=?").bind(result.nextBlock.toString(),checkout,row.next_block).run();
 if(update.meta?.changes!==1)throw new Error("CURSOR_CONFLICT_RETRY");
 return result;
}
