import { analyseCharacter, CeziServiceError, singleHanCharacter } from "./cezi";
import { createRoom, invitePreview, joinRoom, leaveRoom, listRooms, removeMember, renameRoom, resetInvite, roomDetail, RoomError, setDaoName, shareProfile, unshare } from "./rooms";
import { heartbeat as hallHeartbeat, leave as hallLeave, presenceId } from "./hall-presence";
import { Solar } from "lunar-javascript";
import { LampError, lampCost, lightLamp, listLamps } from "./hall-lamps";
import { adminListFlash, createFlash, deleteFlash, FLASH_CATEGORIES, FlashError, flashLocale, flashSitemap, flashTexts, flashVersion, getFlash, listFlash, normalizeSettings, parseFlashInput, parseFlashPatch, readSettings, readState, recordShare, recordView, runFlashAutomation, sourceKey as flashSourceKey, updateFlash, writeSettings, type FlashCategory } from "./flash";
import { countShare, recordSignupSource, shareReport, SOURCE_COOKIE, validAction, validSource } from "./share-stats";
import { LibraryTranslateError, parseTranslateRequest, sourceParagraphs, textHash, translateParagraphs } from "./library-translate";
import { checkVisionService, observeImage, validImageDataUrl, visionConfigured, VisionServiceError } from "./vision";
import {
  bscChain,
  firstPurchaseBonusCredits,
  chainById,
  creditStoreAddress as policyCreditStoreAddress,
  interpretationCost,
  packageById,
  packageUsdtWei,
  paymentNetworks,
  platformFeeWei,
  type PaymentNetworkId,
} from "./commerce-policy";
import {
  buildSignInMessage,
  fetchPurchaseLogs,
  latestBlockNumber,
  normalizeAddress,
  normalizeTxHash,
  verifyPurchaseReceipt,
  verifyWalletSignature,
  type PurchaseVerificationFailure,
} from "./wallet-chain";
import {
  DeepSeekServiceError,
  requestDeepSeekInterpretation,
  type InterpretationPayload,
  type ReadingMode,
  requestDeepSeekInterpretationStream,
} from "./deepseek";
import { createDodoCheckout, dodoEnabled, dodoProducts, fetchDodoPayment, verifyDodoWebhook, type DodoEnv } from "./dodo";
import { issueWalletLink, completeWalletLink, type LinkDatabase } from "./wallet-link-service";
import { recordPaymentAttempt } from "./multichain-recovery.draft";
import { createEthereumDraftOrder } from "./ethereum-order-settlement.draft";
import { createSolanaDirectOrder } from "./solana-order-settlement.draft";
import { createTronDirectOrder } from "./tron-order-settlement.draft";
import { createWalletPayOrder, verifyWalletPayment, walletPayEnabled, WalletPayError, type WalletPayChain, type WalletPayEnv, type WalletPayOrder } from "./wallet-pay";
import { getAddress, type Address } from "viem";

type StatementResult = { success?: boolean; meta?: { changes?: number } };

type PreparedStatement = {
  bind(...values: unknown[]): PreparedStatement;
  first<T = Record<string, unknown>>(): Promise<T | null>;
  all<T = Record<string, unknown>>(): Promise<{ results: T[] }>;
  run(): Promise<StatementResult>;
};

type CommerceDatabase = {
  prepare(query: string): PreparedStatement;
  batch?(statements: PreparedStatement[]): Promise<StatementResult[]>;
};

export type CommerceEnv = DodoEnv & WalletPayEnv & {
  DB?: CommerceDatabase;
  /** Tools whose full reading signed-in members get free once a day (comma separated; default "bazi"; "none" turns it off). */
  FREE_FULL_TOOLS?: string;
  HALL_LAMP_COST?: string;
  /** Shared secret for POST /api/flash/ingest (Make.com / n8n send it as "Authorization: Bearer …"). Unset = ingest off. */
  FLASH_API_TOKEN?: string;
  ADMIN_EMAIL?: string;
  ADMIN_EMAILS?: string;
  ADMIN_PASSWORD?: string;
  SESSION_SECRET?: string;
  DEEPSEEK_API_KEY?: string;
  DEEPSEEK_MODEL?: string;
  /** 手相面相: OpenAI-compatible chat-completions endpoint, key and model of a vision model. The feature is hidden when unset. */
  VISION_API_URL?: string;
  VISION_API_KEY?: string;
  VISION_MODEL?: string;
  /** Photo analyses per member per day (default 10). */
  VISION_DAILY_LIMIT?: string;
  /** Deployed XuanyuanCreditStore contract on BSC. Overrides commerce-policy.ts. */
  CREDIT_STORE_ADDRESS?: string;
  /** Optional new USDC checkout, configured independently of the legacy store. */
  USDC_CHECKOUT_ADDRESS?: string;
  USDC_CHECKOUT_ENABLED?: string;
  USDC_CHECKOUT_REPLACE_LEGACY?: string;
  USDC_CHECKOUT_TOKENS?: string;
  MULTICHAIN_WALLET_LINK_ENABLED?: string;
  MULTICHAIN_DRAFT_RECOVERY_ENABLED?: string;
  MULTICHAIN_DRAFT_ORDERS_ENABLED?: string;
  ETHEREUM_DRAFT_USDC_ADDRESS?: string;
  /** Comma-separated JSON-RPC endpoints for BSC. Defaults to public dataseeds. */
  BSC_RPC_URLS?: string;
  /** 56 (mainnet, default) or 97 (testnet). */
  BSC_CHAIN_ID?: string;
  /** USDT token override — required on testnet (deploy contracts/TestUSDT.sol). */
  USDT_ADDRESS?: string;
  /** OAuth client ID for "Sign in with Google" (the button is hidden when unset). */
  GOOGLE_CLIENT_ID?: string;
  /** Optional: send password-reset emails through Resend (https://resend.com). */
  RESEND_API_KEY?: string;
  MAIL_FROM?: string;
  SITE_URL?: string;
  /** 藏经阁 translation: new passages per day for a member / a visitor / the whole site (defaults 200 / 40 / 4000). */
  LIBRARY_TRANSLATE_MEMBER_DAILY?: string;
  LIBRARY_TRANSLATE_GUEST_DAILY?: string;
  LIBRARY_TRANSLATE_SITE_DAILY?: string;
  /** Where the server reads the published library files from (default SITE_URL, then the request origin). */
  LIBRARY_BASE_URL?: string;
  /** e.g. ".xuannova.com" so the 器物坊 subdomain shares the sign-in cookie. */
  COOKIE_DOMAIN?: string;
};

type SessionRole = "member" | "admin";
type Session = {
  sub: string;
  email?: string;
  wallet?: string;
  /** How this session was opened; the member UI labels the account accordingly. */
  via?: "email" | "wallet";
  role: SessionRole;
  exp?: number;
};

type MemberRecord = {
  id: string;
  email: string | null;
  wallet_address?: string | null;
  credits: number;
  daily_credits?: number;
  daily_credit_date?: string | null;
  daily_claimed_at?: string | null;
  invite_code?: string | null;
  invited_by_member_id?: string | null;
  password_salt?: string | null;
  password_hash?: string | null;
};

type OrderRecord = {
  id: string;
  package_id: string;
  amount_usdt: string;
  settlement_currency?: "USDT" | "USDC";
  credits: number;
  network: PaymentNetworkId;
  transaction_hash: string;
  status: "pending" | "approved" | "rejected";
  submitted_at: string;
  reviewed_at: string | null;
  reviewed_by: string | null;
  review_note: string | null;
  member_id?: string;
  member_email?: string | null;
  member_wallet?: string | null;
  buyer_address?: string | null;
  chain_id?: number | null;
  contract_address?: string | null;
  fee_wei?: string | null;
  block_number?: number | null;
};

type AdminMemberRecord = MemberRecord & {
  created_at: string;
  updated_at: string;
};

type AdminOverviewRecord = {
  member_count?: number | string;
  outstanding_credits?: number | string;
  pending_order_count?: number | string;
  invitation_count?: number | string;
  invitation_credits?: number | string;
};

type InvitationRecord = {
  inviter_id: string;
  inviter_email: string | null;
  inviter_wallet?: string | null;
  invite_code: string | null;
  invitee_id: string;
  invitee_email: string | null;
  invitee_wallet?: string | null;
  joined_at: string;
  inviter_reward: number | string;
  invitee_reward: number | string;
};

type LedgerRecord = {
  id: string;
  member_id: string;
  member_email: string | null;
  member_wallet?: string | null;
  order_id: string | null;
  delta: number | string;
  balance_after: number | string;
  reason: string;
  created_at: string;
};

type InterpretationHistoryRecord = {
  id: string; tool: string; locale: string; mode: ReadingMode; question: string; response_json: string; cost: number | string; created_at: string;
};

const encoder = new TextEncoder();
const decoder = new TextDecoder();
const sessionCookieName = "xuanyuan_session";
const sessionLifetimeSeconds = 60 * 60 * 24 * 7;
const invitationPurchaseCreditAward = 5;
const walletNonceLifetimeSeconds = 60 * 5;

function now() {
  return new Date().toISOString();
}

function base64UrlEncode(bytes: Uint8Array) {
  let binary = "";
  for (const value of bytes) binary += String.fromCharCode(value);
  return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
}

function base64UrlDecode(value: string) {
  const padded = value.replaceAll("-", "+").replaceAll("_", "/").padEnd(Math.ceil(value.length / 4) * 4, "=");
  const binary = atob(padded);
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

async function hmac(message: string, secret: string) {
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  return new Uint8Array(await crypto.subtle.sign("HMAC", key, encoder.encode(message)));
}

function fixedTimeEqual(first: Uint8Array, second: Uint8Array) {
  let different = first.length ^ second.length;
  const length = Math.max(first.length, second.length);
  for (let index = 0; index < length; index += 1) {
    different |= (first[index % first.length] ?? 0) ^ (second[index % second.length] ?? 0);
  }
  return different === 0;
}

async function securelyMatches(first: string, second: string) {
  const [firstHash, secondHash] = await Promise.all([
    crypto.subtle.digest("SHA-256", encoder.encode(first)),
    crypto.subtle.digest("SHA-256", encoder.encode(second)),
  ]);
  return fixedTimeEqual(new Uint8Array(firstHash), new Uint8Array(secondHash));
}

// Cloudflare Workers currently supports PBKDF2 iteration counts up to 100,000.
// Keep this at the supported upper bound so account creation works in production.
export const passwordIterations = 100_000;

async function derivePassword(password: string, salt: Uint8Array) {
  const source = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt: asArrayBuffer(salt), iterations: passwordIterations },
    source,
    256,
  );
  return new Uint8Array(bits);
}

function asArrayBuffer(bytes: Uint8Array) {
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
}

function validatePassword(value: unknown) {
  return typeof value === "string" && value.length >= 6 && value.length <= 128 ? value : null;
}

function validateTransactionHash(value: unknown) {
  if (typeof value !== "string") return null;
  const hash = value.trim();
  return /^[A-Za-z0-9]{20,160}$/.test(hash) ? hash : null;
}

/**
 * Manual transfers are reviewed by staff; this only rejects hashes whose format cannot belong to the chosen
 * network (TRC20 = 64 hex characters, BSC = 0x + 64 hex). It does not look anything up on-chain.
 */
function hashFormatError(networkId: string, hash: string): string | null {
  if (networkId === "trc20" && !/^[0-9a-fA-F]{64}$/.test(hash)) return "TRC20 transaction hashes are 64 hexadecimal characters without 0x";
  if (networkId === "bsc" && !/^0x[0-9a-fA-F]{64}$/.test(hash)) return "BSC transaction hashes start with 0x followed by 64 hexadecimal characters";
  if (networkId === "erc20" && !/^0x[0-9a-fA-F]{64}$/.test(hash)) return "Ethereum transaction hashes start with 0x followed by 64 hexadecimal characters";
  if (networkId === "solana" && !/^[1-9A-HJ-NP-Za-km-z]{64,88}$/.test(hash)) return "Solana transaction signatures are 64 to 88 base58 characters";
  return null;
}

function randomBytes(length: number) {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return bytes;
}

function json(body: unknown, init: ResponseInit = {}) {
  const headers = new Headers(init.headers);
  headers.set("content-type", "application/json; charset=utf-8");
  headers.set("cache-control", "no-store");
  return new Response(JSON.stringify(body), { ...init, headers });
}

function error(message: string, status = 400) {
  return json({ error: message }, { status });
}

function currentOrigin(request: Request) {
  return new URL(request.url).origin;
}

function sameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  return !origin || origin === currentOrigin(request);
}

function validateEmail(value: unknown) {
  if (typeof value !== "string") return null;
  const email = value.trim().toLowerCase();
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254 ? email : null;
}

function configuredAdministratorEmails(env: CommerceEnv) {
  const configured = env.ADMIN_EMAILS?.trim() || env.ADMIN_EMAIL?.trim() || "";
  return [...new Set(
    configured
      .split(",")
      .map((entry) => validateEmail(entry))
      .filter((entry): entry is string => entry !== null),
  )];
}

function configuredCreditStoreAddress(env: CommerceEnv) {
  return normalizeAddress(env.CREDIT_STORE_ADDRESS?.trim() || policyCreditStoreAddress);
}

function configuredUsdcCheckoutAddress(env: CommerceEnv) {
  // The new token/router addresses are mainnet-only; never accept a testnet or
  // unknown network's event as a BSC-mainnet USDC payment.
  if (env.BSC_CHAIN_ID?.trim() && env.BSC_CHAIN_ID.trim() !== "56") return null;
  const address = normalizeAddress(env.USDC_CHECKOUT_ADDRESS?.trim());
  return address && address !== configuredCreditStoreAddress(env) ? address : null;
}

function configuredChain(env: CommerceEnv) {
  const base = chainById(env.BSC_CHAIN_ID?.trim()) ?? bscChain;
  const usdtOverride = normalizeAddress(env.USDT_ADDRESS?.trim());
  return usdtOverride ? { ...base, usdtAddress: usdtOverride } : base;
}

function configuredRpcUrls(env: CommerceEnv): readonly string[] {
  const configured = (env.BSC_RPC_URLS ?? "").split(",").map((entry) => entry.trim()).filter((entry) => /^https:\/\//.test(entry));
  return configured.length > 0 ? configured : configuredChain(env).rpcUrls;
}

function validateInviteCode(value: unknown) {
  if (typeof value !== "string") return null;
  const inviteCode = value.trim().toUpperCase();
  return /^XU[A-Z0-9]{8}$/.test(inviteCode) ? inviteCode : null;
}

function generateInviteCode() {
  return `XU${crypto.randomUUID().replaceAll("-", "").slice(0, 8).toUpperCase()}`;
}

function record(value: unknown) {
  return value !== null && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : null;
}

function compactText(value: unknown, maximum = 900) {
  return typeof value === "string" ? value.trim().slice(0, maximum) : "";
}

function compactItems(value: unknown, limit: number) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, limit).flatMap((entry) => {
    const item = record(entry);
    const label = compactText(item?.label, 120);
    const itemValue = compactText(item?.value, 420);
    return label && itemValue ? [{ label, value: itemValue }] : [];
  });
}

function compactStrings(value: unknown, limit: number, maximum = 900) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, limit).flatMap((entry) => {
    const item = compactText(entry, maximum);
    return item ? [item] : [];
  });
}

function fallbackInterpretationFocus(locale: string) {
  return locale.startsWith("zh") ? "未填写观察主题" : "General chart reflection";
}

function interpretationInput(payload: Record<string, unknown> | null): { request: InterpretationPayload; mode: ReadingMode } | null {
  const tool = compactText(payload?.tool, 80);
  const locale = compactText(payload?.locale, 20);
  const question = compactText(payload?.question, 1_000);
  const mode = payload?.mode === "conversation" ? "conversation" : payload?.mode === "structured" ? "structured" : null;
  const style = payload?.style === "plain" ? "plain" : payload?.style === "expert" ? "expert" : undefined;
  const chart = record(payload?.chart);
  const calendar = record(chart?.calendar);
  const board = record(chart?.board);
  const inputSummary = record(chart?.inputSummary);
  if (!tool || !locale || !question || !mode || !chart || !calendar || !board || !inputSummary) return null;
  const lunar = compactText(calendar.lunar, 180);
  const naYin = compactText(calendar.naYin, 180);
  const solar = compactText(calendar.solar, 180);
  const zodiac = compactText(calendar.zodiac, 120);
  const civilDate = compactText(calendar.civilDate, 40);
  const civilTime = compactText(calendar.civilTime, 40);
  const trueSolarDate = compactText(calendar.trueSolarDate, 40);
  const trueSolarTime = compactText(calendar.trueSolarTime, 40);
  const timeBasis = calendar.timeBasis === "true-solar" ? "true-solar" : calendar.timeBasis === "civil" ? "civil" : undefined;
  const elements = Array.isArray(calendar.elements) ? calendar.elements.slice(0, 5).flatMap((entry) => {
    const element = record(entry);
    const name = compactText(element?.name, 80);
    const count = typeof element?.count === "number" && Number.isFinite(element.count) ? Math.max(0, Math.min(99, Math.trunc(element.count))) : null;
    return name && count !== null ? [{ name, count }] : [];
  }) : [];
  const yi = compactStrings(calendar.yi, 12, 120);
  const ji = compactStrings(calendar.ji, 12, 120);
  const kind = compactText(board.kind, 80);
  const label = compactText(board.label, 180);
  // A generated chart remains valid when its optional form focus was left
  // blank. Use an explicit neutral label so the AI can still interpret the
  // calculated board and the user's reading question.
  const focus = compactText(inputSummary.focus, 360) || fallbackInterpretationFocus(locale);
  const place = compactText(inputSummary.place, 180);
  if (!lunar || !naYin || !kind || !label || !place) return null;
  const cells = Array.isArray(board.cells) ? board.cells.slice(0, 16).flatMap((entry) => {
    const cell = record(entry);
    const id = compactText(cell?.id, 100);
    const title = compactText(cell?.title, 180);
    const items = compactItems(cell?.items, 18);
    return id && title ? [{ id, title, ...(compactText(cell?.subtitle, 180) ? { subtitle: compactText(cell?.subtitle, 180) } : {}), items }] : [];
  }) : [];
  const sections = Array.isArray(chart.sections) ? chart.sections.slice(0, 28).flatMap((entry) => {
    const section = record(entry);
    const id = compactText(section?.id, 100);
    const title = compactText(section?.title, 180);
    const lead = compactText(section?.lead, 360);
    const items = compactItems(section?.items, 20);
    return id && title && lead ? [{ id, title, lead, items }] : [];
  }) : [];
  if (cells.length === 0 && sections.length === 0) return null;
  const version = typeof inputSummary.version === "number" && Number.isFinite(inputSummary.version) ? inputSummary.version : 1;
  const conversationHistory = Array.isArray(payload?.conversationHistory) ? payload.conversationHistory.slice(-10).flatMap((entry) => {
    const turn = record(entry);
    const priorQuestion = compactText(turn?.question, 1_000);
    const answer = compactText(turn?.answer, 2_400);
    return priorQuestion && answer ? [{ question: priorQuestion, answer }] : [];
  }) : [];
  return {
    mode,
    request: {
      tool,
      locale,
      question,
      ...(style ? { style } : {}),
      ...(conversationHistory.length ? { conversationHistory } : {}),
      chart: {
        calendar: {
          lunar,
          naYin,
          ...(solar ? { solar } : {}),
          ...(zodiac ? { zodiac } : {}),
          ...(civilDate ? { civilDate } : {}),
          ...(civilTime ? { civilTime } : {}),
          ...(trueSolarDate ? { trueSolarDate } : {}),
          ...(trueSolarTime ? { trueSolarTime } : {}),
          ...(timeBasis ? { timeBasis } : {}),
          ...(elements.length ? { elements } : {}),
          ...(yi.length ? { yi } : {}),
          ...(ji.length ? { ji } : {}),
        },
        pillars: compactStrings(chart.pillars, 8, 80),
        board: { kind, label, cells },
        sections,
        sourceFacts: compactStrings(chart.sourceFacts, 32, 360),
        inputSummary: {
          focus,
          place,
          version,
          ...(compactText(inputSummary.name, 180) ? { name: compactText(inputSummary.name, 180) } : {}),
          ...(compactText(inputSummary.companionName, 180) ? { companionName: compactText(inputSummary.companionName, 180) } : {}),
        },
      },
    },
  };
}

// Set COOKIE_DOMAIN=.xuannova.com so shop.xuannova.com shares the main-site sign-in.
let cookieDomainAttribute = "";
function createSessionCookie(token: string, lifetime = sessionLifetimeSeconds) {
  return `${sessionCookieName}=${token}; Path=/; Max-Age=${lifetime}; HttpOnly; Secure; SameSite=Lax${cookieDomainAttribute}`;
}

function clearSessionCookie() {
  return `${sessionCookieName}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax${cookieDomainAttribute}`;
}

function cookieValue(request: Request, name: string) {
  const header = request.headers.get("cookie") ?? "";
  const prefix = `${name}=`;
  for (const part of header.split(";")) {
    const trimmed = part.trim();
    if (trimmed.startsWith(prefix)) return trimmed.slice(prefix.length);
  }
  return null;
}

export async function createSessionToken(session: Session, secret: string) {
  const payload = base64UrlEncode(
    encoder.encode(JSON.stringify({ ...session, exp: Math.floor(Date.now() / 1000) + sessionLifetimeSeconds })),
  );
  const signature = base64UrlEncode(await hmac(payload, secret));
  return `${payload}.${signature}`;
}

async function readSession(request: Request, secret: string | undefined): Promise<Session | null> {
  const token = cookieValue(request, sessionCookieName);
  if (!token || !secret) return null;
  const [payload, suppliedSignature, ...rest] = token.split(".");
  if (!payload || !suppliedSignature || rest.length > 0) return null;
  const expectedSignature = base64UrlEncode(await hmac(payload, secret));
  if (!fixedTimeEqual(encoder.encode(suppliedSignature), encoder.encode(expectedSignature))) return null;
  try {
    const session = JSON.parse(decoder.decode(base64UrlDecode(payload))) as Session;
    if (
      typeof session.sub !== "string" ||
      (typeof session.email !== "string" && typeof session.wallet !== "string") ||
      (session.role !== "member" && session.role !== "admin") ||
      typeof session.exp !== "number" ||
      session.exp < Math.floor(Date.now() / 1000)
    ) {
      return null;
    }
    return session;
  } catch {
    return null;
  }
}

async function requestJson(request: Request) {
  try {
    return await request.json() as Record<string, unknown>;
  } catch {
    return null;
  }
}

function database(env: CommerceEnv) {
  return env.DB ?? null;
}

function needsDatabase(env: CommerceEnv) {
  const db = database(env);
  return db ?? error("Service setup is incomplete", 503);
}

async function requireSession(request: Request, env: CommerceEnv, role?: SessionRole): Promise<{ session: Session } | { response: Response }> {
  const session = await readSession(request, env.SESSION_SECRET);
  if (!session) return { response: error("Authentication required", 401) } as const;
  if (role && session.role !== role) return { response: error("Administrator access required", 403) } as const;
  return { session } as const;
}

function memberLabel(member: { email?: string | null; wallet_address?: string | null }) {
  return member.wallet_address ?? member.email ?? "";
}

function serializeMember(member: Pick<MemberRecord, "id" | "email" | "wallet_address" | "credits" | "invite_code">) {
  const dailyCredits = numericValue((member as MemberRecord).daily_credits);
  return {
    id: member.id,
    email: member.email ?? null,
    walletAddress: member.wallet_address ?? null,
    balance: member.credits + dailyCredits,
    dailyCredits,
    inviteCode: member.invite_code ?? null,
  };
}

function serializeOrder(order: OrderRecord) {
  return {
    id: order.id,
    packageId: order.package_id,
    amountUsdt: order.amount_usdt,
    settlementCurrency: order.settlement_currency ?? "USDT",
    credits: order.credits,
    network: order.network,
    transactionHash: order.transaction_hash,
    status: order.status,
    submittedAt: order.submitted_at,
    reviewedAt: order.reviewed_at,
    reviewNote: order.review_note,
    buyerAddress: order.buyer_address ?? null,
    chainId: order.chain_id ?? null,
    feeWei: order.fee_wei ?? null,
    blockNumber: order.block_number ?? null,
    ...(order.member_email || order.member_wallet ? { memberEmail: memberLabel({ email: order.member_email, wallet_address: order.member_wallet }) } : {}),
  };
}

function numericValue(value: number | string | null | undefined) {
  const parsed = typeof value === "number" ? value : Number(value ?? 0);
  return Number.isFinite(parsed) ? parsed : 0;
}

function serializeAdminMember(member: AdminMemberRecord) {
  return {
    ...serializeMember(member),
    invitedByMemberId: member.invited_by_member_id ?? null,
    createdAt: member.created_at,
    updatedAt: member.updated_at,
  };
}

function serializeInvitation(invitation: InvitationRecord) {
  return {
    inviterId: invitation.inviter_id,
    inviterEmail: memberLabel({ email: invitation.inviter_email, wallet_address: invitation.inviter_wallet }),
    inviteCode: invitation.invite_code,
    inviteeId: invitation.invitee_id,
    inviteeEmail: memberLabel({ email: invitation.invitee_email, wallet_address: invitation.invitee_wallet }),
    joinedAt: invitation.joined_at,
    inviterReward: numericValue(invitation.inviter_reward),
    inviteeReward: numericValue(invitation.invitee_reward),
  };
}

function serializeLedgerEntry(entry: LedgerRecord) {
  return {
    id: entry.id,
    memberId: entry.member_id,
    memberEmail: memberLabel({ email: entry.member_email, wallet_address: entry.member_wallet }),
    orderId: entry.order_id,
    delta: numericValue(entry.delta),
    balanceAfter: numericValue(entry.balance_after),
    reason: entry.reason,
    createdAt: entry.created_at,
  };
}

async function memberForSession(env: CommerceEnv, session: Session) {
  const db = database(env);
  if (!db) return null;
  return db.prepare("SELECT id, email, wallet_address, credits, daily_credits, daily_credit_date, invite_code FROM members WHERE id = ?").bind(session.sub).first<MemberRecord>();
}

const dailyBonusAmount = 5;
const dailyBonusCap = 20;
const dailyBonusMinimumSpacingMs = 12 * 60 * 60 * 1000;
const deviceCookieName = "xn_device";
const timezoneCookieName = "xn_tz";
type BonusContext = { deviceId: string; timezone: string };
const bonusContexts = new WeakMap<Request, BonusContext>();

/** Calendar date in the member's own time zone (falls back to Asia/Shanghai for unknown zones). */
function localDate(timezone: string) {
  const format = (zone: string) => {
    const parts = new Intl.DateTimeFormat("en-CA", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date());
    const part = (type: Intl.DateTimeFormatPartTypes) => parts.find((item) => item.type === type)?.value ?? "";
    return `${part("year")}-${part("month")}-${part("day")}`;
  };
  try { return format(timezone || "Asia/Shanghai"); } catch { return format("Asia/Shanghai"); }
}

async function sha256Hex(value: string) {
  const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", encoder.encode(value)));
  return Array.from(digest.slice(0, 12), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

/** Device identity for the daily-bonus and free-preview limits: a long-lived cookie, else the client address. */
async function bonusContextFor(request: Request): Promise<{ context: BonusContext; setCookie?: string }> {
  const existing = cookieValue(request, deviceCookieName);
  const timezone = decodeURIComponent(cookieValue(request, timezoneCookieName) ?? "").slice(0, 64);
  if (existing && /^[A-Za-z0-9_-]{16,64}$/.test(existing)) return { context: { deviceId: `d:${existing}`, timezone } };
  const address = request.headers.get("cf-connecting-ip") ?? request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? request.headers.get("x-real-ip") ?? "unknown";
  const issued = base64UrlEncode(randomBytes(18));
  return {
    context: { deviceId: `ip:${await sha256Hex(address)}`, timezone },
    setCookie: `${deviceCookieName}=${issued}; Path=/; Max-Age=${60 * 60 * 24 * 400}; HttpOnly; Secure; SameSite=Lax`,
  };
}

/**
 * Daily bonus: +5 once per local calendar day, accumulating up to 20, for at most one account per
 * device per day. A 12-hour minimum spacing stops repeated claims by switching time zones.
 */
/** Credits added by the daily bonus during this request (for the "+5 today" notice). */
const dailyBonusAdded = new WeakMap<object, number>();

async function refreshDailyCredits(db: CommerceDatabase, memberId: string, request?: Request) {
  const select = () => db.prepare("SELECT id, email, wallet_address, credits, daily_credits, daily_credit_date, daily_claimed_at, invite_code FROM members WHERE id = ?").bind(memberId).first<MemberRecord>();
  const member = await select();
  if (!member) return null;
  const context = request ? bonusContexts.get(request) : undefined;
  if (!context) return member;
  const date = localDate(context.timezone);
  if (member.daily_credit_date === date) return member;
  if (member.daily_claimed_at && Date.now() - Date.parse(member.daily_claimed_at) < dailyBonusMinimumSpacingMs) return member;
  const timestamp = now();
  await db.prepare("INSERT OR IGNORE INTO daily_bonus_claims (device_id, claim_date, member_id, created_at) VALUES (?, ?, ?, ?)").bind(context.deviceId, date, member.id, timestamp).run();
  const claim = await db.prepare("SELECT member_id FROM daily_bonus_claims WHERE device_id = ? AND claim_date = ?").bind(context.deviceId, date).first<{ member_id: string }>();
  if (claim?.member_id !== member.id) return member;
  const current = numericValue(member.daily_credits);
  const added = Math.max(0, Math.min(dailyBonusAmount, dailyBonusCap - current));
  const updated = await db.prepare("UPDATE members SET daily_credits = MIN(daily_credits + ?, ?), daily_credit_date = ?, daily_claimed_at = ?, updated_at = ? WHERE id = ? AND (daily_credit_date IS NULL OR daily_credit_date <> ?)")
    .bind(dailyBonusAmount, dailyBonusCap, date, timestamp, timestamp, member.id, date).run();
  const refreshed = await select();
  if (refreshed && added > 0 && (updated.meta?.changes ?? 0) === 1) {
    await db.prepare("INSERT INTO credit_ledger (id, member_id, order_id, delta, balance_after, reason, created_at) VALUES (?, ?, NULL, ?, ?, ?, ?)")
      .bind(crypto.randomUUID(), member.id, added, refreshed.credits + numericValue(refreshed.daily_credits), `daily_login_bonus:${date}`, timestamp).run();
    dailyBonusAdded.set(refreshed, added);
  }
  return refreshed;
}

async function withInviteCode(db: CommerceDatabase, member: MemberRecord) {
  if (member.invite_code) return member;
  const inviteCode = generateInviteCode();
  try {
    await db
      .prepare("UPDATE members SET invite_code = ?, updated_at = ? WHERE id = ? AND invite_code IS NULL")
      .bind(inviteCode, now(), member.id)
      .run();
    return { ...member, invite_code: inviteCode };
  } catch {
    return member;
  }
}

async function register(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  if (!env.SESSION_SECRET) return error("Service setup is incomplete", 503);
  const payload = await requestJson(request);
  const email = validateEmail(payload?.email);
  const password = validatePassword(payload?.password);
  const suppliedInviteCode = validateInviteCode(payload?.inviteCode);
  if (!email) return error("Enter a valid email address");
  if (!password) return error("Use a password with 6 to 128 characters");
  if (payload?.inviteCode !== undefined && !suppliedInviteCode) return error("Invitation code is invalid");
  return createEmailAccount(request, env, db, email, password, suppliedInviteCode);
}

/** Shared by register and "sign in with a new email" (accounts are created on first sign-in). */
async function createEmailAccount(request: Request, env: CommerceEnv, db: CommerceDatabase, email: string, password: string, suppliedInviteCode: string | null) {
  if (!env.SESSION_SECRET) return error("Service setup is incomplete", 503);
  const existing = await db.prepare("SELECT id FROM members WHERE email = ?").bind(email).first<{ id: string }>();
  if (existing) return error("An account already exists for this email", 409);

  const inviter = suppliedInviteCode
    ? await db
        .prepare("SELECT id, email, wallet_address, credits, invite_code FROM members WHERE invite_code = ?")
        .bind(suppliedInviteCode)
        .first<MemberRecord>()
    : null;
  if (suppliedInviteCode && !inviter) return error("Invitation code is invalid");

  const salt = randomBytes(16);
  const passwordHash = await derivePassword(password, salt);
  const id = crypto.randomUUID();
  const timestamp = now();
  const inviteCode = generateInviteCode();
  const initialCredits = 0;
  try {
    await db
      .prepare("INSERT INTO members (id, email, wallet_address, password_salt, password_hash, credits, role, invite_code, invited_by_member_id, created_at, updated_at) VALUES (?, ?, NULL, ?, ?, ?, 'member', ?, ?, ?, ?)")
      .bind(id, email, base64UrlEncode(salt), base64UrlEncode(passwordHash), initialCredits, inviteCode, inviter?.id ?? null, timestamp, timestamp)
      .run();
  } catch {
    return error("An account already exists for this email", 409);
  }
  await recordSignupSource(db, id, validSource(cookieValue(request, SOURCE_COOKIE)));

  const token = await createSessionToken({ sub: id, email, via: "email", role: "member" }, env.SESSION_SECRET);
  const member = await refreshDailyCredits(db, id, request);
  return json({ member: { ...serializeMember(member ?? { id, email, wallet_address: null, credits: initialCredits, invite_code: inviteCode }), signedInWith: "email" } }, { status: 201, headers: { "set-cookie": createSessionCookie(token) } });
}

async function memberLogin(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  if (!env.SESSION_SECRET) return error("Service setup is incomplete", 503);
  const payload = await requestJson(request);
  const email = validateEmail(payload?.email);
  const password = typeof payload?.password === "string" ? payload.password : null;
  if (!email || !password) return error("Enter your email and password");

  const member = await db
    .prepare("SELECT id, email, wallet_address, credits, invite_code, password_salt, password_hash FROM members WHERE email = ?")
    .bind(email)
    .first<MemberRecord>();
  if (!member && payload?.autoRegister === true) {
    // Email-first sign-in: a new email creates the account with the password just entered.
    const validPassword = validatePassword(password);
    if (!validPassword) return error("Use a password with 6 to 128 characters");
    const inviteCode = validateInviteCode(payload?.inviteCode);
    if (payload?.inviteCode && !inviteCode) return error("Invitation code is invalid");
    return createEmailAccount(request, env, db, email, validPassword, inviteCode);
  }
  if (!member?.password_salt || !member.password_hash) return error("Invalid email or password", 401);
  const suppliedHash = await derivePassword(password, base64UrlDecode(member.password_salt));
  if (!fixedTimeEqual(suppliedHash, base64UrlDecode(member.password_hash))) return error("Invalid email or password", 401);

  const memberWithInviteCode = await withInviteCode(db, await refreshDailyCredits(db, member.id, request) ?? member);
  const token = await createSessionToken({ sub: member.id, email: member.email ?? undefined, ...(member.wallet_address ? { wallet: member.wallet_address } : {}), via: "email", role: "member" }, env.SESSION_SECRET);
  return json({ member: { ...serializeMember(memberWithInviteCode), signedInWith: "email" } }, { headers: { "set-cookie": createSessionCookie(token) } });
}

// ---------------------------------------------------------------------------------------------
// Forgot password. The answer never reveals whether an email has an account. A link is emailed when
// RESEND_API_KEY and MAIL_FROM are set; otherwise support can create a link from the admin console.
// ---------------------------------------------------------------------------------------------
const resetLifetimeMs = 30 * 60 * 1000;
const resetMailCopy: Record<string, { subject: string; body: (link: string) => string }> = {
  en: { subject: "Reset your Xuannova password", body: (link) => `Open this link within 30 minutes to set a new password:\n\n${link}\n\nIf you did not ask for this, ignore this email.` },
  "zh-Hans": { subject: "重置你的 Xuannova 密码", body: (link) => `请在 30 分钟内打开下面的链接设置新密码：\n\n${link}\n\n如果不是你本人操作，请忽略本邮件。` },
  "zh-Hant": { subject: "重設你的 Xuannova 密碼", body: (link) => `請在 30 分鐘內開啟下面的連結設定新密碼：\n\n${link}\n\n如果不是你本人操作，請忽略本郵件。` },
  ja: { subject: "Xuannova のパスワード再設定", body: (link) => `30 分以内に次のリンクを開いて新しいパスワードを設定してください：\n\n${link}\n\nお心当たりがない場合は、このメールを無視してください。` },
  ko: { subject: "Xuannova 비밀번호 재설정", body: (link) => `30분 안에 아래 링크를 열어 새 비밀번호를 설정하세요:\n\n${link}\n\n요청하지 않으셨다면 이 메일을 무시하세요.` },
  vi: { subject: "Đặt lại mật khẩu Xuannova", body: (link) => `Mở liên kết sau trong vòng 30 phút để đặt mật khẩu mới:\n\n${link}\n\nNếu bạn không yêu cầu, hãy bỏ qua email này.` },
  th: { subject: "รีเซ็ตรหัสผ่าน Xuannova", body: (link) => `เปิดลิงก์นี้ภายใน 30 นาทีเพื่อตั้งรหัสผ่านใหม่:\n\n${link}\n\nหากคุณไม่ได้ขอ โปรดเพิกเฉยอีเมลนี้` },
};

async function createResetLink(db: CommerceDatabase, env: CommerceEnv, request: Request, memberId: string, createdBy: string, locale: string) {
  const token = base64UrlEncode(randomBytes(32));
  const timestamp = now();
  await db.prepare("INSERT INTO password_resets (token_hash, member_id, expires_at, created_by, created_at) VALUES (?, ?, ?, ?, ?)")
    .bind(await sha256Hex(token), memberId, new Date(Date.now() + resetLifetimeMs).toISOString(), createdBy, timestamp).run();
  const origin = (env.SITE_URL ?? new URL(request.url).origin).replace(/\/$/, "");
  const prefix = locale === "en" ? "" : `/${locale.toLowerCase()}`;
  return `${origin}${prefix}/membership?reset=${token}`;
}

async function forgotPassword(request: Request, env: CommerceEnv, fetchImpl: typeof fetch = fetch) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const payload = await requestJson(request);
  const email = validateEmail(payload?.email);
  if (!email) return error("Enter a valid email address");
  const locale = typeof payload?.locale === "string" && resetMailCopy[payload.locale] ? payload.locale : "en";
  const emailEnabled = Boolean(env.RESEND_API_KEY && env.MAIL_FROM);
  if (emailEnabled) {
    const member = await db.prepare("SELECT id FROM members WHERE email = ?").bind(email).first<{ id: string }>();
    // At most three links per account per hour.
    const recent = member ? await db.prepare("SELECT COUNT(*) AS total FROM password_resets WHERE member_id = ? AND created_at >= ?").bind(member.id, new Date(Date.now() - 3600_000).toISOString()).first<{ total: number | string }>() : null;
    if (member && numericValue(recent?.total) < 3) {
      const link = await createResetLink(db, env, request, member.id, "self", locale);
      const mail = resetMailCopy[locale];
      try {
        await fetchImpl("https://api.resend.com/emails", { method: "POST", headers: { authorization: `Bearer ${env.RESEND_API_KEY}`, "content-type": "application/json" }, body: JSON.stringify({ from: env.MAIL_FROM, to: [email], subject: mail.subject, text: mail.body(link) }) });
      } catch { /* The answer stays the same so it cannot be used to probe accounts. */ }
    }
  }
  return json({ ok: true, emailEnabled });
}

async function resetPassword(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const payload = await requestJson(request);
  const token = typeof payload?.token === "string" && /^[A-Za-z0-9_-]{20,100}$/.test(payload.token) ? payload.token : "";
  const password = validatePassword(typeof payload?.password === "string" ? payload.password : "");
  if (!password) return error("Use a password with 6 to 128 characters");
  if (!token) return error("This reset link is invalid or has expired");
  const tokenHash = await sha256Hex(token);
  const row = await db.prepare("SELECT member_id, expires_at, used_at FROM password_resets WHERE token_hash = ?").bind(tokenHash).first<{ member_id: string; expires_at: string; used_at: string | null }>();
  if (!row || row.used_at || Date.parse(row.expires_at) < Date.now()) return error("This reset link is invalid or has expired");
  const salt = randomBytes(16);
  const hash = await derivePassword(password, salt);
  const timestamp = now();
  const [claim] = await db.batch!([
    db.prepare("UPDATE password_resets SET used_at = ? WHERE token_hash = ? AND used_at IS NULL").bind(timestamp, tokenHash),
    db.prepare("UPDATE members SET password_salt = ?, password_hash = ?, updated_at = ? WHERE id = ? AND changes() = 1").bind(base64UrlEncode(salt), base64UrlEncode(hash), timestamp, row.member_id),
  ]);
  if ((claim.meta?.changes ?? 0) !== 1) return error("This reset link is invalid or has expired");
  return json({ ok: true });
}

async function adminCreateResetLink(request: Request, env: CommerceEnv) {
  const access = await adminAccess(request, env, true);
  if ("response" in access) return access.response;
  const payload = await requestJson(request);
  const memberId = await memberIdFromReference(access.db, payload?.member);
  if (!memberId) return error("Member not found", 404);
  const locale = typeof payload?.locale === "string" && resetMailCopy[payload.locale] ? payload.locale : "en";
  const link = await createResetLink(access.db, env, request, memberId, access.session.email ?? "admin", locale);
  await audit(access.db, access.session.email, "password_reset_link", memberId, {});
  return json({ link, expiresInMinutes: 30 });
}

/**
 * Sign in with Google: the browser sends the Google ID token; we verify it with Google, check that it
 * was issued for our client ID and that the email is verified, then sign in (or create) that member.
 */
async function googleSignIn(request: Request, env: CommerceEnv, fetchImpl: typeof fetch = fetch) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  if (!env.GOOGLE_CLIENT_ID) return error("Google sign-in is not configured", 503);
  if (!env.SESSION_SECRET) return error("Service setup is incomplete", 503);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const payload = await requestJson(request);
  const credential = typeof payload?.credential === "string" && payload.credential.length < 4096 ? payload.credential : "";
  if (!credential) return error("Google sign-in failed", 400);
  let claims: { aud?: string; email?: string; email_verified?: string | boolean; exp?: string; iss?: string };
  try {
    const verified = await fetchImpl(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(credential)}`, { signal: AbortSignal.timeout(8_000) });
    if (!verified.ok) return error("Google sign-in failed", 401);
    claims = await verified.json();
  } catch { return error("Google sign-in is temporarily unavailable", 502); }
  const issuerOk = claims.iss === "accounts.google.com" || claims.iss === "https://accounts.google.com";
  const emailVerified = claims.email_verified === true || claims.email_verified === "true";
  const email = validateEmail(claims.email);
  if (claims.aud !== env.GOOGLE_CLIENT_ID || !issuerOk || !emailVerified || !email || Number(claims.exp ?? 0) * 1000 < Date.now()) return error("Google sign-in failed", 401);
  let member = await db.prepare("SELECT id, email, wallet_address, credits, invite_code FROM members WHERE email = ?").bind(email).first<MemberRecord>();
  let created = false;
  if (!member) {
    const id = crypto.randomUUID();
    const timestamp = now();
    const inviteCode = validateInviteCode(payload?.inviteCode);
    const inviter = inviteCode ? await db.prepare("SELECT id FROM members WHERE invite_code = ?").bind(inviteCode).first<{ id: string }>() : null;
    await db.prepare("INSERT INTO members (id, email, wallet_address, password_salt, password_hash, credits, role, invite_code, invited_by_member_id, created_at, updated_at) VALUES (?, ?, NULL, NULL, NULL, 0, 'member', ?, ?, ?, ?)")
      .bind(id, email, generateInviteCode(), inviter?.id ?? null, timestamp, timestamp).run();
    await recordSignupSource(db, id, validSource(cookieValue(request, SOURCE_COOKIE)));
    member = await db.prepare("SELECT id, email, wallet_address, credits, invite_code FROM members WHERE id = ?").bind(id).first<MemberRecord>();
    created = true;
  }
  if (!member) return error("Google sign-in failed", 500);
  const refreshed = await withInviteCode(db, await refreshDailyCredits(db, member.id, request) ?? member);
  const token = await createSessionToken({ sub: member.id, email, ...(member.wallet_address ? { wallet: member.wallet_address } : {}), via: "email", role: "member" }, env.SESSION_SECRET);
  return json({ member: { ...serializeMember(refreshed), signedInWith: "email" }, created }, { status: created ? 201 : 200, headers: { "set-cookie": createSessionCookie(token) } });
}

async function walletNonce(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  if (!env.SESSION_SECRET) return error("Service setup is incomplete", 503);
  const payload = await requestJson(request);
  const address = normalizeAddress(payload?.address);
  if (!address) return error("Connect a wallet before signing in");
  const nonce = base64UrlEncode(randomBytes(18));
  const issuedAt = now();
  const expiresAt = new Date(Date.now() + walletNonceLifetimeSeconds * 1000).toISOString();
  await db
    .prepare("INSERT INTO wallet_nonces (wallet_address, nonce, expires_at) VALUES (?, ?, ?) ON CONFLICT(wallet_address) DO UPDATE SET nonce = excluded.nonce, expires_at = excluded.expires_at")
    .bind(address, nonce, expiresAt)
    .run();
  const message = buildSignInMessage({ domain: new URL(request.url).host, address, nonce, issuedAt, chainId: configuredChain(env).id });
  return json({ address, nonce, issuedAt, expiresAt, message });
}

async function walletVerify(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  if (!env.SESSION_SECRET) return error("Service setup is incomplete", 503);
  const payload = await requestJson(request);
  const address = normalizeAddress(payload?.address);
  const message = typeof payload?.message === "string" ? payload.message : "";
  const suppliedInviteCode = validateInviteCode(payload?.inviteCode);
  if (!address || !message) return error("Connect a wallet before signing in");
  if (payload?.inviteCode !== undefined && payload?.inviteCode !== "" && !suppliedInviteCode) return error("Invitation code is invalid");

  const stored = await db
    .prepare("SELECT nonce, expires_at FROM wallet_nonces WHERE wallet_address = ?")
    .bind(address)
    .first<{ nonce: string; expires_at: string }>();
  if (!stored || stored.expires_at < now()) return error("Sign-in request expired. Please try again", 401);
  const nonceLine = message.split("\n").find((line) => line.startsWith("Nonce: "));
  const issuedAtLine = message.split("\n").find((line) => line.startsWith("Issued At: "));
  const expectedMessage = buildSignInMessage({
    domain: new URL(request.url).host,
    address,
    chainId: configuredChain(env).id,
    nonce: nonceLine?.slice("Nonce: ".length) ?? "",
    issuedAt: issuedAtLine?.slice("Issued At: ".length) ?? "",
  });
  if (message !== expectedMessage || !nonceLine || nonceLine.slice("Nonce: ".length) !== stored.nonce) return error("Wallet signature is invalid", 401);
  if (!(await verifyWalletSignature(address, message, payload?.signature))) return error("Wallet signature is invalid", 401);
  await db.prepare("DELETE FROM wallet_nonces WHERE wallet_address = ?").bind(address).run();

  let member = await db
    .prepare("SELECT id, email, wallet_address, credits, invite_code FROM members WHERE wallet_address = ?")
    .bind(address)
    .first<MemberRecord>();
  let created = false;
  let linked = false;
  // A signed-in email account connecting a wallet for the first time: bind the
  // wallet to that account instead of creating a second one.
  const currentSession = await readSession(request, env.SESSION_SECRET);
  if (!member && currentSession?.role === "member" && payload?.link !== false) {
    const current = await memberForSession(env, currentSession);
    if (current && !current.wallet_address) {
      await db
        .prepare("UPDATE members SET wallet_address = ?, updated_at = ? WHERE id = ? AND wallet_address IS NULL")
        .bind(address, now(), current.id)
        .run();
      member = { ...current, wallet_address: address };
      linked = true;
    } else if (current?.wallet_address && current.wallet_address.toLowerCase() !== address.toLowerCase()) {
      // Signed-in account already has a different wallet: never silently switch accounts.
      return error("This account is already linked to a different wallet", 409);
    }
  }
  if (member && currentSession?.role === "member" && currentSession.sub !== member.id && !linked) {
    return error("This wallet is already linked to another account", 409);
  }
  if (!member) {
    const inviter = suppliedInviteCode
      ? await db
          .prepare("SELECT id, email, wallet_address, credits, invite_code FROM members WHERE invite_code = ?")
          .bind(suppliedInviteCode)
          .first<MemberRecord>()
      : null;
    if (suppliedInviteCode && !inviter) return error("Invitation code is invalid");
    const id = crypto.randomUUID();
    const timestamp = now();
    const inviteCode = generateInviteCode();
    const initialCredits = 0;
    try {
      await db
        .prepare("INSERT INTO members (id, email, wallet_address, password_salt, password_hash, credits, role, invite_code, invited_by_member_id, created_at, updated_at) VALUES (?, NULL, ?, NULL, NULL, ?, 'member', ?, ?, ?, ?)")
        .bind(id, address, initialCredits, inviteCode, inviter?.id ?? null, timestamp, timestamp)
        .run();
      await recordSignupSource(db, id, validSource(cookieValue(request, SOURCE_COOKIE)));
    } catch {
      return error("Unable to create the wallet account", 409);
    }
    member = { id, email: null, wallet_address: address, credits: initialCredits, invite_code: inviteCode };
    created = true;
  }

  const memberWithInviteCode = await withInviteCode(db, await refreshDailyCredits(db, member.id, request) ?? member);
  const via = linked && currentSession?.via === "email" ? "email" : "wallet";
  const token = await createSessionToken({ sub: member.id, wallet: address, ...(member.email ? { email: member.email } : {}), via, role: "member" }, env.SESSION_SECRET);
  return json({ member: { ...serializeMember(memberWithInviteCode), signedInWith: via }, created, linked }, { status: created ? 201 : 200, headers: { "set-cookie": createSessionCookie(token) } });
}

async function adminLogin(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const administratorEmails = configuredAdministratorEmails(env);
  if (!env.SESSION_SECRET || administratorEmails.length === 0 || !env.ADMIN_PASSWORD) return error("Service setup is incomplete", 503);
  const payload = await requestJson(request);
  const email = validateEmail(payload?.email);
  const password = typeof payload?.password === "string" ? payload.password : "";
  const [emailMatches, validPassword] = await Promise.all([
    email
      ? Promise.all(administratorEmails.map((administratorEmail) => securelyMatches(email, administratorEmail)))
      : Promise.resolve([]),
    securelyMatches(password, env.ADMIN_PASSWORD),
  ]);
  const validEmail = emailMatches.some(Boolean);
  if (!validEmail || !validPassword) return error("Invalid administrator credentials", 401);

  const normalizedEmail = email!;
  const token = await createSessionToken({ sub: normalizedEmail, email: normalizedEmail, role: "admin" }, env.SESSION_SECRET);
  return json({ administrator: { email: normalizedEmail } }, { headers: { "set-cookie": createSessionCookie(token) } });
}

async function memberMe(request: Request, env: CommerceEnv) {
  // ?soft=1: a signed-out visitor gets 200 { member: null } instead of 401, so pages that only check
  // whether someone is signed in do not log a failed request on every load.
  if (new URL(request.url).searchParams.get("soft") === "1") {
    const session = await readSession(request, env.SESSION_SECRET);
    if (!session || session.role !== "member") return json({ member: null });
  }
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  let member = await refreshDailyCredits(db, access.session.sub, request);
  if (!member) return error("Authentication required", 401);
  const added = dailyBonusAdded.get(member) ?? 0;
  const firstPurchaseBonus = await settleFirstPurchaseBonus(db, member.id);
  if (firstPurchaseBonus) member = (await db.prepare("SELECT id, email, wallet_address, credits, daily_credits, daily_credit_date, invite_code FROM members WHERE id = ?").bind(member.id).first<MemberRecord>()) ?? member;
  const signedInWith = access.session.via ?? (access.session.wallet && !access.session.email ? "wallet" : "email");
  const firstPurchaseOffer = !firstPurchaseBonus && !(await db.prepare("SELECT 1 AS yes FROM first_purchase_bonus WHERE member_id = ?").bind(member.id).first<{ yes: number }>());
  return json({ member: { ...serializeMember(await withInviteCode(db, member)), signedInWith, firstPurchaseOffer }, ...(added ? { dailyBonusAdded: added } : {}), ...(firstPurchaseBonus ? { firstPurchaseBonus } : {}) });
}

// ---------------------------------------------------------------------------------------------
// First-purchase bonus: the first time a member has a completed purchase (USDT order approved,
// on-chain purchase recorded as an approved order, or paid card order), they receive extra credits
// once. Settled when the member's account is loaded, so the payment code itself is unchanged.
// ---------------------------------------------------------------------------------------------
async function settleFirstPurchaseBonus(db: CommerceDatabase, memberId: string): Promise<number> {
  const settled = await db.prepare("SELECT credits FROM first_purchase_bonus WHERE member_id = ?").bind(memberId).first<{ credits: number }>();
  if (settled) return 0;
  const bought = await db.prepare("SELECT 1 AS yes FROM payment_orders WHERE member_id = ? AND status = 'approved' UNION ALL SELECT 1 FROM dodo_orders WHERE member_id = ? AND status = 'paid' LIMIT 1").bind(memberId, memberId).first<{ yes: number }>();
  if (!bought) return 0;
  const timestamp = now();
  const claimed = await db.prepare("INSERT OR IGNORE INTO first_purchase_bonus (member_id, credits, created_at) VALUES (?, ?, ?)").bind(memberId, firstPurchaseBonusCredits, timestamp).run();
  if ((claimed.meta?.changes ?? 0) !== 1) return 0;
  await db.batch!([
    db.prepare("UPDATE members SET credits = credits + ?, updated_at = ? WHERE id = ?").bind(firstPurchaseBonusCredits, timestamp, memberId),
    db.prepare("INSERT INTO credit_ledger (id, member_id, order_id, delta, balance_after, reason, created_at) SELECT ?, id, NULL, ?, credits + daily_credits, 'first_purchase_bonus', ? FROM members WHERE id = ?").bind(crypto.randomUUID(), firstPurchaseBonusCredits, timestamp, memberId),
  ]);
  return firstPurchaseBonusCredits;
}

// ---------------------------------------------------------------------------------------------
// Daily reminder e-mails (opt-in). The Node server sends them (server/reminder-mailer.ts).
// ---------------------------------------------------------------------------------------------
const reminderLocales = new Set(["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"]);

// ---------------------------------------------------------------------------------------------
// 测字: character structure, cached per character and language. Open to visitors (device-limited).
// ---------------------------------------------------------------------------------------------
async function ceziAnalyse(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const payload = await requestJson(request);
  const character = singleHanCharacter(payload?.character);
  if (!character) return json({ error: "Enter one Chinese character", code: "INVALID_CHARACTER" }, { status: 400 });
  const locale = typeof payload?.locale === "string" && reminderLocales.has(payload.locale) ? payload.locale : "en";
  const cached = await db.prepare("SELECT analysis_json FROM cezi_cache WHERE character = ? AND locale = ?").bind(character, locale).first<{ analysis_json: string }>();
  if (cached) return json({ analysis: JSON.parse(cached.analysis_json), cached: true });
  const session = await readSession(request, env.SESSION_SECRET);
  const { context, setCookie } = await bonusContextFor(request);
  const usageKey = session?.role === "member" ? `m:${session.sub}` : context.deviceId;
  const date = now().slice(0, 10);
  const used = await db.prepare("SELECT count FROM cezi_usage WHERE usage_key = ? AND usage_date = ?").bind(usageKey, date).first<{ count: number }>();
  const limit = session?.role === "member" ? 30 : 10;
  if ((used?.count ?? 0) >= limit) return json({ error: "Daily limit reached", code: "CEZI_LIMIT" }, { status: 429 });
  try {
    const analysis = await analyseCharacter(character, locale, env.DEEPSEEK_API_KEY, env.DEEPSEEK_MODEL);
    await db.prepare("INSERT INTO cezi_usage (usage_key, usage_date, count) VALUES (?, ?, 1) ON CONFLICT(usage_key, usage_date) DO UPDATE SET count = count + 1").bind(usageKey, date).run();
    await db.prepare("INSERT OR REPLACE INTO cezi_cache (character, locale, analysis_json, created_at) VALUES (?, ?, ?, ?)").bind(character, locale, JSON.stringify(analysis), now()).run();
    return json({ analysis, cached: false }, setCookie ? { headers: { "set-cookie": setCookie } } : {});
  } catch (caught) {
    const code = caught instanceof CeziServiceError ? caught.code : "AI_UNAVAILABLE";
    return json({ error: "Character analysis is temporarily unavailable", code }, { status: code === "AI_NOT_CONFIGURED" ? 503 : 502 });
  }
}

// ---------------------------------------------------------------------------------------------
// 我的静室: member rooms (create, invite link, members by 道号, shared charts). No chat.
// ---------------------------------------------------------------------------------------------
const roomMessages: Record<string, string> = { NOT_A_MEMBER: "Room not found", INVITE_INVALID: "This invitation link is no longer valid", ROOM_FULL: "This room is full", TOO_MANY_ROOMS: "You have joined the maximum number of rooms", OWNER_ONLY: "Only the room owner can do this", NAME_REFUSED: "That name can't be used", CONSENT_REQUIRED: "Please confirm consent before sharing", PROFILE_NOT_FOUND: "Profile not found", TOO_MANY_SHARES: "This room already has the maximum number of shared charts", INVALID_REQUEST: "Invalid request" };
async function roomsRoute(request: Request, env: CommerceEnv, path: string) {
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  // Invitation preview works without signing in (room name and size only).
  const invite = path.match(/^invite\/([0-9a-f]{24})$/);
  try {
    if (invite && request.method === "GET") return json({ room: await invitePreview(db, invite[1]) });
    const access = await requireSession(request, env, "member");
    if ("response" in access) return access.response;
    const member = access.session.sub;
    const stamp = now();
    if (path === "" && request.method === "GET") return json({ rooms: await listRooms(db, member) });
    if (request.method !== "GET" && !sameOrigin(request)) return error("Invalid request origin", 403);
    const payload = request.method === "POST" ? await requestJson(request) : null;
    if (path === "create" && request.method === "POST") { const id = await createRoom(db, member, payload?.name, stamp); return json({ room: await roomDetail(db, id, member, new Date()) }); }
    if (path === "join" && request.method === "POST") { const id = await joinRoom(db, member, String(payload?.token ?? ""), stamp); return json({ room: await roomDetail(db, id, member, new Date()) }); }
    const match = path.match(/^([0-9a-f-]{36})(?:\/([a-z-]+))?$/);
    if (!match) return error("API route not found", 404);
    const [, roomId, action] = match;
    if (!action && request.method === "GET") return json({ room: await roomDetail(db, roomId, member, new Date()) });
    if (request.method !== "POST") return error("API route not found", 404);
    if (action === "heartbeat") return json({ room: await roomDetail(db, roomId, member, new Date(), true) });
    if (action === "rename") await renameRoom(db, roomId, member, payload?.name);
    else if (action === "reset-link") await resetInvite(db, roomId, member);
    else if (action === "me") await setDaoName(db, roomId, member, payload?.daoName);
    else if (action === "remove") await removeMember(db, roomId, member, payload?.memberId);
    else if (action === "share") await shareProfile(db, roomId, member, { profileId: payload?.profileId, consent: payload?.consent }, stamp);
    else if (action === "unshare") await unshare(db, roomId, member, payload?.shareId);
    else if (action === "leave") { await leaveRoom(db, roomId, member); return json({ rooms: await listRooms(db, member) }); }
    else return error("API route not found", 404);
    return json({ room: await roomDetail(db, roomId, member, new Date()) });
  } catch (cause) {
    if (cause instanceof RoomError) return json({ error: roomMessages[cause.code] ?? "Request failed", code: cause.code }, { status: cause.status });
    throw cause;
  }
}

// ---------------------------------------------------------------------------------------------
// 研习殿 · 同殿共修: heartbeat (who is online) and leave. The id comes from the device cookie.
// ---------------------------------------------------------------------------------------------
async function hallPresenceId(request: Request) {
  const { context, setCookie } = await bonusContextFor(request);
  // A first visit gets its device cookie in this response: use that id straight away so the visitor is not counted twice.
  const issued = setCookie?.match(/^[^=]+=([^;]+)/)?.[1];
  return { id: await presenceId(issued ? `d:${issued}` : context.deviceId), setCookie };
}
const hallLastBeat = new Map<string, number>();
async function hallHeartbeatRoute(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const payload = await requestJson(request);
  const { id, setCookie } = await hallPresenceId(request);
  // At most one write every 5 s per visitor (a renamed 道号 is always accepted).
  const nowMs = Date.now();
  const last = hallLastBeat.get(id) ?? 0;
  if (nowMs - last < 5000 && payload?.name === undefined) return json({ throttled: true }, { status: 429 });
  hallLastBeat.set(id, nowMs);
  if (hallLastBeat.size > 5000) for (const [key, value] of hallLastBeat) if (nowMs - value > 120_000) hallLastBeat.delete(key);
  // The head count is not sent: the hall always looks lively and members are not told how many are online.
  const { online: _online, ...result } = await hallHeartbeat(db, { id, name: payload?.name, route: payload?.route, now: new Date(nowMs) });
  return json(result, setCookie ? { headers: { "set-cookie": setCookie } } : {});
}
async function hallLeaveRoute(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const { id } = await hallPresenceId(request);
  await hallLeave(db, id);
  return json({ ok: true });
}

// 研习殿 · 点亮祈福灯: anyone may see the glowing lamps; lighting one needs a member session (free unless HALL_LAMP_COST is set).
const lampMessages: Record<string, [string, number]> = { INVALID_WISH: ["That wish can't be used", 400], INVALID_NAME: ["That name can't be used", 400], DAILY_LIMIT: ["Daily lamp limit reached", 429], INSUFFICIENT_CREDITS: ["Insufficient credits", 402] };
async function hallLampsRoute(request: Request, env: CommerceEnv) {
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  if (request.method === "GET") {
    const session = await readSession(request, env.SESSION_SECRET);
    const memberId = session?.role === "member" ? session.sub : null;
    return json({ lamps: await listLamps(db, memberId, new Date()), cost: lampCost(env.HALL_LAMP_COST) }, { headers: { "cache-control": "no-store" } });
  }
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const payload = await requestJson(request);
  const member = await refreshDailyCredits(db, access.session.sub, request);
  if (!member) return error("Authentication required", 401);
  try {
    const cost = lampCost(env.HALL_LAMP_COST);
    const lamp = await lightLamp(db, { memberId: access.session.sub, cost, name: payload?.name, wish: payload?.wish, kind: payload?.kind, public: payload?.public, now: new Date() });
    const updated = await memberForSession(env, access.session);
    return json({ lamp, cost, member: updated ? serializeMember(updated) : null }, { status: 201 });
  } catch (cause) {
    if (cause instanceof LampError) { const [message, status] = lampMessages[cause.code]; return json({ error: message, code: cause.code }, { status }); }
    throw cause;
  }
}

// ---------------------------------------------------------------------------------------------
// 玄诺快讯 (worker/flash.ts): public list / detail / real view counts, the automation ingest endpoint, admin tools.
// ---------------------------------------------------------------------------------------------
const flashErrors: Record<string, [string, number]> = { INVALID: ["Invalid flash item", 400], NOT_FOUND: ["Not found", 404], DUPLICATE: ["This story was already added", 409], AI_NOT_CONFIGURED: ["DEEPSEEK_API_KEY is not set", 503], AI_FAILED: ["The writer model failed", 502] };
function flashFailure(cause: unknown) {
  if (cause instanceof FlashError) { const [message, status] = flashErrors[cause.code]; return json({ error: message, code: cause.code, detail: cause.message !== cause.code ? cause.message : undefined }, { status }); }
  throw cause;
}
function publicJson(body: unknown, seconds: number) {
  return json(body, { headers: { "cache-control": `public, max-age=${seconds}, s-maxage=${seconds}` } });
}
async function constantTimeEqual(a: string, b: string) {
  const [x, y] = await Promise.all([sha256Hex(a), sha256Hex(b)]);
  let diff = 0;
  for (let i = 0; i < x.length; i += 1) diff |= x.charCodeAt(i) ^ y.charCodeAt(i);
  return diff === 0 && a.length === b.length;
}

/** The solar term in force on a date (for the quote of the day), e.g. 立冬. */
function flashSolarTerm(date: string) {
  try { const [year, month, day] = date.split("-").map(Number); return (Solar.fromYmd(year, month, day).getLunar().getPrevJieQi(true) as { getName(): string }).getName(); } catch { return null; }
}

async function flashRoute(request: Request, env: CommerceEnv, url: URL): Promise<Response | null> {
  const path = url.pathname;
  if (!path.startsWith("/api/flash") && !path.startsWith("/api/admin/flash")) return null;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const now = new Date();
  const locale = flashLocale(url.searchParams.get("locale")) ?? "en";
  try {
    if (path === "/api/flash" && request.method === "GET") {
      const category = (FLASH_CATEGORIES as readonly string[]).includes(url.searchParams.get("category") ?? "") ? url.searchParams.get("category") as FlashCategory : null;
      const page = await listFlash(db, { locale, limit: Number(url.searchParams.get("limit")) || 12, before: url.searchParams.get("before"), category, now });
      return publicJson({ ...page, version: await flashVersion(db, now) }, 10);
    }
    if (path === "/api/flash/version" && request.method === "GET") return publicJson({ version: await flashVersion(db, now) }, 5);
    if (path === "/api/flash/sitemap.xml" && request.method === "GET") {
      const site = (env.SITE_URL ?? "https://xuannova.com").replace(/\/+$/, "");
      return new Response(await flashSitemap(db, site, now), { headers: { "content-type": "application/xml; charset=utf-8", "cache-control": "public, max-age=900" } });
    }
    const item = path.match(/^\/api\/flash\/item\/([a-z0-9-]{4,91})(\/view|\/share)?$/);
    if (item && !item[2] && request.method === "GET") {
      const found = await getFlash(db, item[1], locale, { now });
      if (!found) return error("Not found", 404);
      return publicJson({ item: found }, 15);
    }
    if (item && item[2] === "/view" && request.method === "POST") {
      if (!sameOrigin(request)) return error("Invalid request origin", 403);
      const { context, setCookie } = await bonusContextFor(request);
      const views = await recordView(db, item[1], context.deviceId, now);
      if (views === null) return error("Not found", 404);
      return json({ views }, setCookie ? { headers: { "set-cookie": setCookie } } : {});
    }
    if (item && item[2] === "/share" && request.method === "POST") {
      if (!sameOrigin(request)) return error("Invalid request origin", 403);
      const payload = await requestJson(request);
      await recordShare(db, item[1], payload?.kind === "poster" ? "poster" : "share");
      return json({ ok: true });
    }
    // Automation: Make.com / n8n / Zapier send one item with all its languages.
    if (path === "/api/flash/ingest" && request.method === "POST") {
      const token = env.FLASH_API_TOKEN?.trim();
      if (!token || token.length < 24) return error("Flash ingest is not enabled (set FLASH_API_TOKEN, at least 24 characters)", 503);
      const given = (request.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "").trim() || request.headers.get("x-flash-token")?.trim() || "";
      if (!given || !(await constantTimeEqual(given, token))) return error("Invalid token", 401);
      const payload = await requestJson(request);
      const input = parseFlashInput(payload);
      const key = input.sourceUrl ? await flashSourceKey(input.sourceUrl, "") : null;
      const made = await createFlash(db, input, { origin: "api", now, sourceKey: key });
      const site = (env.SITE_URL ?? "https://xuannova.com").replace(/\/+$/, "");
      return json({ ok: true, slug: made.slug, url: `${site}/zh-hans/flash/${made.slug}`, urls: Object.fromEntries(Object.keys(input.texts).map((code) => [code, `${site}${code === "en" ? "" : `/${code.toLowerCase()}`}/flash/${made.slug}`])), languages: Object.keys(input.texts) }, { status: 201 });
    }
    // ---- admin
    if (path.startsWith("/api/admin/flash")) {
      const access = await requireSession(request, env, "admin");
      if ("response" in access) return access.response;
      if (request.method === "POST" && !sameOrigin(request)) return error("Invalid request origin", 403);
      if (path === "/api/admin/flash" && request.method === "GET") {
        const list = await adminListFlash(db, { limit: Number(url.searchParams.get("limit")) || 30, offset: Number(url.searchParams.get("offset")) || 0 });
        return json({ ...list, settings: await readSettings(db), state: await readState(db), ingest: Boolean(env.FLASH_API_TOKEN?.trim() && env.FLASH_API_TOKEN.trim().length >= 24), ai: Boolean(env.DEEPSEEK_API_KEY?.trim()) });
      }
      if (path === "/api/admin/flash" && request.method === "POST") {
        const made = await createFlash(db, parseFlashInput(await requestJson(request)), { origin: "admin", now });
        return json({ ok: true, slug: made.slug }, { status: 201 });
      }
      if (path === "/api/admin/flash/settings" && request.method === "POST") {
        const settings = normalizeSettings(await requestJson(request));
        await writeSettings(db, settings, now);
        return json({ ok: true, settings });
      }
      if (path === "/api/admin/flash/run" && request.method === "POST") {
        const report = await runFlashAutomation(db, env, { now, force: true, solarTerm: flashSolarTerm });
        return json({ ok: true, report, state: await readState(db) });
      }
      const one = path.match(/^\/api\/admin\/flash\/([a-z0-9-]{4,91})(\/delete|\/texts)?$/);
      if (one && one[2] === "/texts" && request.method === "GET") {
        const found = await getFlash(db, one[1], "zh-Hans", { includeHidden: true });
        if (!found) return error("Not found", 404);
        return json({ item: found, texts: await flashTexts(db, found.id) });
      }
      if (one && one[2] === "/delete" && request.method === "POST") { await deleteFlash(db, one[1]); return json({ ok: true }); }
      if (one && !one[2] && request.method === "POST") { await updateFlash(db, one[1], parseFlashPatch(await requestJson(request)), now); return json({ ok: true }); }
    }
    return error("API route not found", 404);
  } catch (cause) {
    return flashFailure(cause);
  }
}

// 分享来源统计: the browser reports posters made / saved / shared and visits that came from a shared link.
const shareBeat = new Map<string, number>();
async function shareStatRoute(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const payload = await requestJson(request);
  const source = validSource(payload?.source), action = validAction(payload?.action);
  if (!source || !action) return error("Invalid request");
  // At most one count per device, source and action every 10 s (keeps accidental repeats out).
  const { context } = await bonusContextFor(request);
  const key = `${context.deviceId}|${source}|${action}`, nowMs = Date.now();
  if (nowMs - (shareBeat.get(key) ?? 0) < 10_000) return json({ ok: true, throttled: true });
  shareBeat.set(key, nowMs);
  if (shareBeat.size > 20000) for (const [k, v] of shareBeat) if (nowMs - v > 60_000) shareBeat.delete(k);
  await countShare(db, source, action, new Date(nowMs));
  return json({ ok: true });
}
async function adminShareReport(request: Request, env: CommerceEnv) {
  const access = await adminAccess(request, env);
  if ("response" in access) return access.response;
  const days = Math.min(365, Math.max(1, Number(new URL(request.url).searchParams.get("days")) || 30));
  return json(await shareReport(access.db, new Date(), days, purchasesByMember), { headers: { "cache-control": "no-store" } });
}

// ---------------------------------------------------------------------------------------------
// 藏经阁: translate the paragraphs a reader is looking at (cached once per passage and language).
// ---------------------------------------------------------------------------------------------
async function libraryTranslate(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const input = parseTranslateRequest(await requestJson(request));
  if (!input) return json({ error: "Invalid translation request", code: "INVALID_REQUEST" }, { status: 400 });
  const base = (env.LIBRARY_BASE_URL ?? env.SITE_URL ?? new URL(request.url).origin).replace(/\/$/, "");
  try {
    const source = await sourceParagraphs(base, input);
    const hash = await textHash(source.paragraphs);
    const key = `${source.dir}|${input.script}|${input.part}|${input.chapter}|${input.from}-${input.to}|${input.locale}`;
    const cached = await db.prepare("SELECT paragraphs_json, text_hash FROM library_translations WHERE cache_key = ?").bind(key).first<{ paragraphs_json: string; text_hash: string }>();
    // A cached result with gaps (a non-empty passage left untranslated) is not reused: translate again.
    const hasGap = (list: string[]) => source.paragraphs.some((text, index) => text.trim() && !String(list[index] ?? "").trim());
    if (cached && cached.text_hash === hash) { const list = JSON.parse(cached.paragraphs_json) as string[]; if (!hasGap(list)) return json({ paragraphs: list, cached: true }); }
    const session = await readSession(request, env.SESSION_SECRET);
    const { context, setCookie } = await bonusContextFor(request);
    const member = session?.role === "member";
    const usageKey = member ? `m:${session!.sub}` : context.deviceId;
    const date = now().slice(0, 10);
    const limit = (value: string | undefined, fallback: number) => { const parsed = Number(value); return Number.isFinite(parsed) && parsed >= 0 ? parsed : fallback; };
    const [mine, site] = await Promise.all([
      db.prepare("SELECT count FROM library_translation_usage WHERE usage_key = ? AND usage_date = ?").bind(usageKey, date).first<{ count: number }>(),
      db.prepare("SELECT count FROM library_translation_usage WHERE usage_key = 'site' AND usage_date = ?").bind(date).first<{ count: number }>(),
    ]);
    if ((site?.count ?? 0) >= limit(env.LIBRARY_TRANSLATE_SITE_DAILY, 4000)) return json({ error: "Translation is busy today", code: "SITE_LIMIT" }, { status: 429 });
    if ((mine?.count ?? 0) >= (member ? limit(env.LIBRARY_TRANSLATE_MEMBER_DAILY, 200) : limit(env.LIBRARY_TRANSLATE_GUEST_DAILY, 40))) return json({ error: "Daily translation limit reached", code: member ? "MEMBER_LIMIT" : "GUEST_LIMIT" }, { status: 429 });
    const paragraphs = await translateParagraphs(source.paragraphs, input.locale, source.title, env.DEEPSEEK_API_KEY, env.DEEPSEEK_MODEL);
    // Fill any passage the model skipped with a second, smaller request.
    const missing = source.paragraphs.flatMap((text, index) => (text.trim() && !String(paragraphs[index] ?? "").trim() ? [index] : []));
    if (missing.length) {
      try {
        const filled = await translateParagraphs(missing.map((index) => source.paragraphs[index]), input.locale, source.title, env.DEEPSEEK_API_KEY, env.DEEPSEEK_MODEL);
        missing.forEach((index, at) => { if (String(filled[at] ?? "").trim()) paragraphs[index] = filled[at]; });
      } catch { /* keep what we have */ }
    }
    const count = "INSERT INTO library_translation_usage (usage_key, usage_date, count) VALUES (?, ?, 1) ON CONFLICT(usage_key, usage_date) DO UPDATE SET count = count + 1";
    await db.prepare(count).bind(usageKey, date).run();
    await db.prepare(count).bind("site", date).run();
    await db.prepare("INSERT OR REPLACE INTO library_translations (cache_key, locale, text_hash, paragraphs_json, created_at) VALUES (?, ?, ?, ?, ?)").bind(key, input.locale, hash, JSON.stringify(paragraphs), now()).run();
    return json({ paragraphs, cached: false }, setCookie ? { headers: { "set-cookie": setCookie } } : {});
  } catch (caught) {
    if (caught instanceof LibraryTranslateError) return json({ error: "Translation is temporarily unavailable", code: caught.code }, { status: caught.status });
    return json({ error: "Translation is temporarily unavailable", code: "AI_UNAVAILABLE" }, { status: 502 });
  }
}

// ---------------------------------------------------------------------------------------------
// 手相面相: photo → visible features (vision model). The photo is passed through once and never stored.
// ---------------------------------------------------------------------------------------------
function visionStatus(env: CommerceEnv) {
  return json({ configured: visionConfigured(env) });
}

async function visionObserve(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  if (!visionConfigured(env)) return json({ error: "Photo reading is not available", code: "VISION_NOT_CONFIGURED" }, { status: 503 });
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const payload = await requestJson(request);
  const kind = payload?.kind === "palm" || payload?.kind === "face" ? payload.kind : null;
  if (!kind) return error("Choose palm or face");
  if (payload?.consent !== true) return json({ error: "Please agree to the photo notice first", code: "CONSENT_REQUIRED" }, { status: 400 });
  const image = payload?.image;
  if (!validImageDataUrl(image)) return json({ error: "Please upload a JPEG, PNG or WebP photo under 2 MB", code: "INVALID_IMAGE" }, { status: 400 });
  const locale = typeof payload?.locale === "string" && reminderLocales.has(payload.locale) ? payload.locale : "en";
  const hand = payload?.hand === "left" ? "left" : "right";
  const limit = Math.max(1, Math.min(100, Number(env.VISION_DAILY_LIMIT) || 10));
  const date = now().slice(0, 10);
  const used = await db.prepare("SELECT count FROM vision_usage WHERE member_id = ? AND usage_date = ?").bind(access.session.sub, date).first<{ count: number }>();
  if ((used?.count ?? 0) >= limit) return json({ error: "Daily photo limit reached", code: "VISION_LIMIT", limit }, { status: 429 });
  await db.prepare("INSERT INTO vision_usage (member_id, usage_date, count, updated_at) VALUES (?, ?, 1, ?) ON CONFLICT(member_id, usage_date) DO UPDATE SET count = count + 1, updated_at = excluded.updated_at").bind(access.session.sub, date, now()).run();
  try {
    const result = await observeImage({ kind, locale, image, hand }, env);
    return json({ kind, hand: kind === "palm" ? hand : undefined, ...result, remaining: Math.max(0, limit - (used?.count ?? 0) - 1) });
  } catch (caught) {
    // A failed call does not use up the member's daily allowance.
    await db.prepare("UPDATE vision_usage SET count = MAX(0, count - 1) WHERE member_id = ? AND usage_date = ?").bind(access.session.sub, date).run();
    const code = caught instanceof VisionServiceError ? caught.code : "VISION_UNAVAILABLE";
    const detail = caught instanceof VisionServiceError ? caught.detail : "";
    return json({ error: "Photo reading is temporarily unavailable", code, ...(detail ? { detail } : {}) }, { status: code === "VISION_NOT_CONFIGURED" ? 503 : 502 });
  }
}
async function memberReminder(request: Request, env: CommerceEnv) {
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const member = await db.prepare("SELECT email FROM members WHERE id = ?").bind(access.session.sub).first<{ email: string | null }>();
  const row = await db.prepare("SELECT enabled, timezone, locale, solar_terms FROM daily_reminders WHERE member_id = ?").bind(access.session.sub).first<{ enabled: number; timezone: string; locale: string; solar_terms: number }>();
  if (request.method === "GET") return json({ enabled: Boolean(row?.enabled), solarTerms: Boolean(row?.solar_terms), hasEmail: Boolean(member?.email), mailConfigured: Boolean(env.RESEND_API_KEY && env.MAIL_FROM) });
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const payload = await requestJson(request);
  // Each switch is optional, so the daily reminder and the solar-term reminder can be changed separately.
  const enabled = typeof payload?.enabled === "boolean" ? payload.enabled : Boolean(row?.enabled);
  const solarTerms = typeof payload?.solarTerms === "boolean" ? payload.solarTerms : Boolean(row?.solar_terms);
  if ((enabled || solarTerms) && !member?.email) return json({ error: "Add an email address to receive reminders", code: "EMAIL_REQUIRED" }, { status: 400 });
  const timezone = typeof payload?.timezone === "string" && /^[A-Za-z_]+(?:\/[A-Za-z0-9_+-]+){0,2}$/.test(payload.timezone) ? payload.timezone : row?.timezone ?? "UTC";
  const locale = typeof payload?.locale === "string" && reminderLocales.has(payload.locale) ? payload.locale : row?.locale ?? "en";
  const timestamp = now();
  await db.prepare("INSERT INTO daily_reminders (member_id, enabled, solar_terms, timezone, locale, token, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(member_id) DO UPDATE SET enabled = excluded.enabled, solar_terms = excluded.solar_terms, timezone = excluded.timezone, locale = excluded.locale, updated_at = excluded.updated_at")
    .bind(access.session.sub, enabled ? 1 : 0, solarTerms ? 1 : 0, timezone, locale, crypto.randomUUID().replace(/-/g, "") + crypto.randomUUID().replace(/-/g, ""), timestamp, timestamp).run();
  return json({ enabled, solarTerms });
}

// ---------------------------------------------------------------------------------------------
// Library shelf: favourite classics and the last reading position (chapter and paragraph) per book.
// ---------------------------------------------------------------------------------------------
type ShelfRow = { work_id: string; favorite: number; chapter: number | null; chapter_count: number | null; paragraph: number | null; chapter_title: string | null; favorited_at: string | null; read_at: string | null; updated_at: string };
const shelfItem = (row: ShelfRow) => ({ workId: row.work_id, favorite: Boolean(row.favorite), chapter: row.chapter, chapterCount: row.chapter_count, paragraph: row.paragraph, chapterTitle: row.chapter_title, favoritedAt: row.favorited_at, readAt: row.read_at });
const smallInt = (value: unknown, max: number) => (typeof value === "number" && Number.isInteger(value) && value >= 0 && value <= max ? value : null);

async function memberLibrary(request: Request, env: CommerceEnv, workId: string | null) {
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const member = access.session.sub;
  if (request.method === "GET") {
    const { results } = await db.prepare("SELECT work_id, favorite, chapter, chapter_count, paragraph, chapter_title, favorited_at, read_at, updated_at FROM library_shelf WHERE member_id = ? ORDER BY updated_at DESC LIMIT 200").bind(member).all<ShelfRow>();
    return json({ items: results.map(shelfItem) });
  }
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  if (!workId || !/^[a-z0-9][a-z0-9-]{0,59}$/.test(workId)) return error("Unknown book", 400);
  const payload = await requestJson(request);
  const existing = await db.prepare("SELECT work_id, favorite, chapter, chapter_count, paragraph, chapter_title, favorited_at, read_at, updated_at FROM library_shelf WHERE member_id = ? AND work_id = ?").bind(member, workId).first<ShelfRow>();
  const timestamp = now();
  const favorite = typeof payload?.favorite === "boolean" ? payload.favorite : Boolean(existing?.favorite);
  const chapter = smallInt(payload?.chapter, 100_000);
  const reading = chapter !== null;
  const next: ShelfRow = {
    work_id: workId,
    favorite: favorite ? 1 : 0,
    chapter: reading ? chapter : existing?.chapter ?? null,
    chapter_count: reading ? smallInt(payload?.chapterCount, 100_000) : existing?.chapter_count ?? null,
    paragraph: reading ? smallInt(payload?.paragraph, 1_000_000) ?? 0 : existing?.paragraph ?? null,
    chapter_title: reading ? (typeof payload?.chapterTitle === "string" ? payload.chapterTitle.slice(0, 120) : null) : existing?.chapter_title ?? null,
    favorited_at: favorite ? existing?.favorited_at ?? timestamp : null,
    read_at: reading ? timestamp : existing?.read_at ?? null,
    updated_at: timestamp,
  };
  await db.prepare("INSERT INTO library_shelf (member_id, work_id, favorite, chapter, chapter_count, paragraph, chapter_title, favorited_at, read_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(member_id, work_id) DO UPDATE SET favorite = excluded.favorite, chapter = excluded.chapter, chapter_count = excluded.chapter_count, paragraph = excluded.paragraph, chapter_title = excluded.chapter_title, favorited_at = excluded.favorited_at, read_at = excluded.read_at, updated_at = excluded.updated_at")
    .bind(member, workId, next.favorite, next.chapter, next.chapter_count, next.paragraph, next.chapter_title, next.favorited_at, next.read_at, next.updated_at).run();
  return json({ item: shelfItem(next) });
}

async function reminderUnsubscribe(request: Request, env: CommerceEnv) {
  const token = new URL(request.url).searchParams.get("token") ?? "";
  const db = database(env);
  if (db && /^[a-f0-9]{64}$/.test(token)) await db.prepare("UPDATE daily_reminders SET enabled = 0, solar_terms = 0, updated_at = ? WHERE token = ?").bind(now(), token).run();
  const page = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Xuannova</title></head><body style="font-family:system-ui,sans-serif;background:#0d0e11;color:#eee;display:grid;place-items:center;min-height:90vh;text-align:center"><div><h1 style="font-weight:500">Xuannova</h1><p>已取消每日提醒。Daily reminders are turned off.</p><p><a style="color:#d6b26a" href="/">xuannova.com</a></p></div></body></html>`;
  return new Response(page, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" } });
}

async function hideInterpretation(request: Request, env: CommerceEnv, id: string | null) {
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const timestamp = now();
  const result = id
    ? await db.prepare("UPDATE interpretation_history SET hidden_at = ? WHERE id = ? AND member_id = ? AND hidden_at IS NULL").bind(timestamp, id, access.session.sub).run()
    : await db.prepare("UPDATE interpretation_history SET hidden_at = ? WHERE member_id = ? AND hidden_at IS NULL").bind(timestamp, access.session.sub).run();
  return json({ hidden: result.meta?.changes ?? 0 });
}

/**
 * Manual transfer (original flow): the member pastes a TRC20 / BSC transfer hash
 * and an administrator approves it in the console before credits are issued.
 */
async function createManualOrder(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const payload = await requestJson(request);
  let selectedPackage: { id: string; usdt: string; credits: number } | undefined = typeof payload?.packageId === "string" ? packageById(payload.packageId) : undefined;
  if (!selectedPackage && typeof payload?.packageId === "string" && payload.packageId.startsWith("x-") && env.DB) {
    // Exclusive package offered to this member (directly or through a group); still reviewed by an administrator.
    const exclusive = (await exclusivePackagesFor(env.DB, access.session.sub)).find((item) => item.id === payload.packageId);
    if (exclusive) selectedPackage = { id: exclusive.id, usdt: exclusive.price_usdt, credits: numericValue(exclusive.credits) };
  }
  if (!selectedPackage) return error("Choose a valid credit package");
  const network = typeof payload?.network === "string" ? paymentNetworks.find((item) => item.id === payload.network) : undefined;
  if (!network) return error("Choose a payment network");
  const transactionHash = validateTransactionHash(payload?.transactionHash);
  if (!transactionHash) return error("Enter a valid transaction hash");
  const formatProblem = hashFormatError(network.id, transactionHash);
  if (formatProblem) return error(formatProblem);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const member = await refreshDailyCredits(db, access.session.sub, request);
  if (!member) return error("Authentication required", 401);

  const existing = await db.prepare("SELECT id FROM payment_orders WHERE transaction_hash = ?").bind(transactionHash).first<{ id: string }>();
  if (existing) return error("This transaction hash has already been submitted", 409);
  const order: OrderRecord = {
    id: crypto.randomUUID(),
    member_id: member.id,
    package_id: selectedPackage.id,
    amount_usdt: selectedPackage.usdt,
    credits: selectedPackage.credits,
    network: network.id,
    transaction_hash: transactionHash,
    status: "pending",
    submitted_at: now(),
    reviewed_at: null,
    reviewed_by: null,
    review_note: null,
  };
  try {
    await db
      .prepare("INSERT INTO payment_orders (id, member_id, package_id, amount_usdt, credits, network, transaction_hash, status, submitted_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?)")
      .bind(order.id, order.member_id, order.package_id, order.amount_usdt, order.credits, order.network, order.transaction_hash, order.submitted_at)
      .run();
  } catch {
    return error("This transaction hash has already been submitted", 409);
  }
  return json({ order: serializeOrder(order) }, { status: 201 });
}

const walletPayMessages: Record<string, string> = {
  INVALID_WALLET: "This wallet address is not valid on the selected chain",
  UNSUPPORTED_ASSET: "This coin is not available on the selected chain",
  RECIPIENT_NOT_READY: "The receiving account for this coin is not ready yet. Choose another coin or use a manual transfer",
  INSUFFICIENT_BALANCE: "Your wallet does not hold enough of this coin for the package",
  INSUFFICIENT_GAS: "Your wallet does not hold enough of the network coin to pay the transfer fee",
  TOO_MANY_PENDING_ORDERS: "Too many unfinished payments today. Please try again later",
  CHAIN_RPC_UNAVAILABLE: "The chain could not be reached. Please try again shortly",
  WRONG_CHAIN: "The chain could not be reached. Please try again shortly",
  INVALID_TRANSACTION: "This transaction id is not valid",
  TRANSACTION_FAILED: "The transaction failed on chain. No credits were added",
  PAYMENT_MISMATCH: "This transaction does not match the order",
  ORDER_TERMS_MISMATCH: "This order can no longer be paid. Please start again",
};
const walletPayError = (cause: unknown) => {
  if (cause instanceof WalletPayError) return json({ error: walletPayMessages[cause.code] ?? "Wallet payment failed", code: cause.code, ...(cause.detail ? { detail: cause.detail } : {}) }, { status: cause.status });
  if (cause instanceof Error && cause.message === "UNKNOWN_CREDIT_PACKAGE") return error("Choose a valid credit package");
  return error("Wallet payment failed", 500);
};

/** POST /api/pay/{ethereum|solana|tron}/order — { packageId, asset, buyer } → order with reference and transfer details. */
async function walletPayOrder(request: Request, env: CommerceEnv, chain: WalletPayChain) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  if (!walletPayEnabled(env)) return error("Wallet payment is not available", 503);
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const payload = await requestJson(request);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const member = await refreshDailyCredits(db, access.session.sub, request);
  if (!member) return error("Authentication required", 401);
  try {
    const order = await createWalletPayOrder(db, env, { memberId: member.id, chain, asset: String(payload?.asset ?? ""), packageId: String(payload?.packageId ?? ""), buyer: String(payload?.buyer ?? "").trim(), now: now() });
    return json({ order }, { status: 201 });
  } catch (cause) { return walletPayError(cause); }
}

/** POST /api/pay/{chain}/confirm — { orderId, transactionId }. Credits once the transfer is final; otherwise { status: "pending" }. */
async function walletPayConfirm(request: Request, env: CommerceEnv, chain: WalletPayChain) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const payload = await requestJson(request);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const orderId = String(payload?.orderId ?? "");
  const rawTransactionId = String(payload?.transactionId ?? "").trim();
  // Hex ids (Ethereum, TRON) are case-insensitive: store one spelling so a transaction can only be claimed once.
  const transactionId = chain === "solana" ? rawTransactionId : rawTransactionId.toLowerCase();
  const order = await db.prepare("SELECT * FROM wallet_pay_orders WHERE id = ? AND member_id = ? AND chain = ?").bind(orderId, access.session.sub, chain).first<WalletPayOrder & { credits: number | string }>();
  if (!order) return error("Order not found", 404);
  order.credits = Number(order.credits);
  if (order.status === "credited") return json({ status: "credited", credits: order.credits, paymentOrderId: order.payment_order_id });
  if (order.signature && order.signature !== transactionId) return error("This order is already linked to another transaction", 409);
  if (!order.signature) {
    try {
      const claimed = await db.prepare("UPDATE wallet_pay_orders SET signature = ? WHERE id = ? AND signature IS NULL").bind(transactionId, order.id).run();
      if (!claimed.meta?.changes) return error("This order is already linked to another transaction", 409);
    } catch { return error("This transaction has already been used for another order", 409); }
  }
  let result: "verified" | "pending";
  try { result = await verifyWalletPayment(env, order, transactionId); }
  catch (cause) {
    // A transaction that does not match can never become valid: free the order so the member can retry with another.
    if (cause instanceof WalletPayError && ["INVALID_TRANSACTION", "TRANSACTION_FAILED", "PAYMENT_MISMATCH"].includes(cause.code)) await db.prepare("UPDATE wallet_pay_orders SET signature = NULL WHERE id = ? AND status = 'pending'").bind(order.id).run();
    return walletPayError(cause);
  }
  if (result === "pending") return json({ status: "pending" }, { status: 202 });
  const selectedPackage = packageById(order.package_id);
  if (!selectedPackage) return error("Choose a valid credit package");
  const timestamp = now();
  const paymentId = crypto.randomUUID();
  const network = chain === "solana" ? "solana" : chain === "ethereum" ? "erc20" : "trc20";
  const note = `Wallet payment verified on ${chain === "solana" ? "Solana" : chain === "ethereum" ? "Ethereum" : "TRON"} · ${order.asset} · order ${order.id}`;
  const statements = [
    db.prepare("INSERT INTO payment_orders (id, member_id, package_id, amount_usdt, credits, network, transaction_hash, status, submitted_at, buyer_address, settlement_currency) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?)")
      .bind(paymentId, order.member_id, selectedPackage.id, selectedPackage.usdt, order.credits, network, transactionId, timestamp, order.buyer, order.asset),
    db.prepare("UPDATE payment_orders SET status = 'approved', reviewed_at = ?, reviewed_by = ?, review_note = ? WHERE id = ? AND status = 'pending'").bind(timestamp, `chain:${chain}-wallet`, note, paymentId),
    db.prepare("UPDATE wallet_pay_orders SET status = 'credited', credited_at = ?, payment_order_id = ? WHERE id = ? AND status = 'pending'").bind(timestamp, paymentId, order.id),
  ];
  try {
    if (db.batch) await db.batch(statements);
    else for (const statement of statements) await statement.run();
  } catch (cause) {
    const message = cause instanceof Error ? cause.message : String(cause);
    if (/UNIQUE constraint failed/i.test(message)) {
      const done = await db.prepare("SELECT status, payment_order_id FROM wallet_pay_orders WHERE id = ?").bind(order.id).first<{ status: string; payment_order_id: string | null }>();
      if (done?.status === "credited") return json({ status: "credited", credits: order.credits, paymentOrderId: done.payment_order_id });
      return error("This transaction has already been used for another order", 409);
    }
    return error("Unable to record this payment. Keep the transaction id and contact support", 500);
  }
  await rewardInvitationPurchase(db, order.member_id, paymentId, timestamp);
  return json({ status: "credited", credits: order.credits, paymentOrderId: paymentId });
}

type ChainConfigLike = { id: number; name: string; confirmations: number; rpcUrls: readonly string[] };

/** A successful purchase by an invited member grants one 5-credit reward to each side. */
async function rewardInvitationPurchase(db: CommerceDatabase, inviteeId: string, orderId: string, timestamp: string) {
  if (!db.batch) return;
  const invitee = await db.prepare("SELECT id, invited_by_member_id, credits FROM members WHERE id = ?").bind(inviteeId).first<MemberRecord>();
  if (!invitee?.invited_by_member_id) return;
  const inviter = await db.prepare("SELECT id, credits FROM members WHERE id = ?").bind(invitee.invited_by_member_id).first<MemberRecord>();
  if (!inviter) return;
  try {
    await db.batch([
      db.prepare("INSERT INTO invitation_purchase_rewards (invitee_member_id, inviter_member_id, order_id, awarded_at) VALUES (?, ?, ?, ?)").bind(inviteeId, inviter.id, orderId, timestamp),
      db.prepare("UPDATE members SET credits = credits + ?, updated_at = ? WHERE id = ?").bind(invitationPurchaseCreditAward, timestamp, invitee.id),
      db.prepare("UPDATE members SET credits = credits + ?, updated_at = ? WHERE id = ?").bind(invitationPurchaseCreditAward, timestamp, inviter.id),
      db.prepare("INSERT INTO credit_ledger (id, member_id, order_id, delta, balance_after, reason, created_at) VALUES (?, ?, NULL, ?, ?, 'invitation_purchase', ?)").bind(crypto.randomUUID(), invitee.id, invitationPurchaseCreditAward, invitee.credits + invitationPurchaseCreditAward, timestamp),
      db.prepare("INSERT INTO credit_ledger (id, member_id, order_id, delta, balance_after, reason, created_at) VALUES (?, ?, NULL, ?, ?, 'invitation_purchase', ?)").bind(crypto.randomUUID(), inviter.id, invitationPurchaseCreditAward, inviter.credits + invitationPurchaseCreditAward, timestamp),
    ]);
  } catch {
    // A duplicate purchase reward violates the unique reward claim and safely does nothing.
  }
}

/**
 * Insert an on-chain purchase as an approved order. The pending → approved
 * transition fires the payment_order_approved_credit_once trigger, which
 * credits the member and writes the ledger row in the same statement batch.
 */
export async function recordVerifiedPurchase(
  db: CommerceDatabase,
  memberId: string,
  purchase: { transactionHash: string; buyer: string; contractAddress: string; packageId: string; feeWei: bigint; saleIndex: bigint; blockNumber: bigint },
  chain: ChainConfigLike,
  reviewer = "chain:bsc",
): Promise<{ order: OrderRecord } | { error: Response }> {
  const selectedPackage = packageById(purchase.packageId);
  if (!selectedPackage) return { error: error("Choose a valid credit package") };
  const timestamp = now();
  const order: OrderRecord = {
    id: crypto.randomUUID(),
    member_id: memberId,
    package_id: selectedPackage.id,
    amount_usdt: selectedPackage.usdt,
    settlement_currency: reviewer.startsWith("chain:usdc") ? "USDC" : "USDT",
    credits: selectedPackage.credits,
    network: "bsc",
    transaction_hash: purchase.transactionHash,
    status: "approved",
    submitted_at: timestamp,
    reviewed_at: timestamp,
    reviewed_by: reviewer,
    review_note: `Verified on ${chain.name} · block ${purchase.blockNumber} · sale #${purchase.saleIndex}`,
    buyer_address: purchase.buyer,
    chain_id: chain.id,
    contract_address: purchase.contractAddress,
    fee_wei: purchase.feeWei.toString(),
    block_number: Number(purchase.blockNumber),
  };
  const insert = db
    .prepare("INSERT INTO payment_orders (id, member_id, package_id, amount_usdt, credits, network, transaction_hash, status, submitted_at, buyer_address, chain_id, contract_address, fee_wei, block_number, settlement_currency, sale_index) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?, ?, ?, ?)")
    .bind(order.id, order.member_id, order.package_id, order.amount_usdt, order.credits, order.network, order.transaction_hash, order.submitted_at, order.buyer_address, order.chain_id, order.contract_address, order.fee_wei, order.block_number, order.settlement_currency, purchase.saleIndex.toString());
  const approve = db
    .prepare("UPDATE payment_orders SET status = 'approved', reviewed_at = ?, reviewed_by = ?, review_note = ? WHERE id = ? AND status = 'pending'")
    .bind(order.reviewed_at, order.reviewed_by, order.review_note, order.id);
  try {
    if (db.batch) await db.batch([insert, approve]);
    else { await insert.run(); await approve.run(); }
  } catch (cause) {
    const message = cause instanceof Error ? cause.message : String(cause);
    if (/UNIQUE constraint failed/i.test(message)) return { error: error("This transaction hash has already been submitted", 409) };
    return { error: error("Unable to record this purchase. Keep the transaction hash and retry", 500) };
  }
  await rewardInvitationPurchase(db, memberId, order.id, timestamp);
  return { order };
}

const syncSettingKey = "chain_sync_last_block";
const syncChunk = 2000n;
const syncBootstrapLookback = 5000n;

/**
 * Background reconciliation: read Purchased events from the store contract and
 * credit any purchase whose buyer wallet belongs to a member but which was
 * never submitted through /api/orders. Safe to call repeatedly; progress is
 * kept in app_settings so each block range is scanned once.
 */
export async function syncPurchasesFromChain(env: CommerceEnv, checkout: "legacy" | "usdc" = "legacy"): Promise<{ scanned: boolean; from?: string; to?: string; credited: number; skipped: number; reason?: string }> {
  const db = database(env);
  const contractAddress = checkout === "usdc" ? configuredUsdcCheckoutAddress(env) : configuredCreditStoreAddress(env);
  const cursorKey = checkout === "usdc" && contractAddress ? `chain_sync_usdc_${contractAddress.toLowerCase()}` : syncSettingKey;
  if (!db || !contractAddress) return { scanned: false, credited: 0, skipped: 0, reason: contractAddress ? "no database" : "no contract" };
  const chain = configuredChain(env);
  const rpcUrls = configuredRpcUrls(env);
  // Retry previously confirmed events once their buyer wallet is associated
  // with a member. Keep unresolved rows rather than losing them at the cursor.
  const awaiting = await db.prepare("SELECT u.transaction_hash, u.buyer_address, u.package_id, u.fee_wei, u.sale_index, u.block_number, m.id AS member_id FROM unmatched_chain_purchases u JOIN members m ON m.wallet_address = u.buyer_address WHERE u.chain_id = ? AND u.contract_address = ? AND u.checkout = ? ORDER BY u.block_number LIMIT 100")
    .bind(chain.id, contractAddress, checkout).all<{ transaction_hash: string; buyer_address: string; package_id: string; fee_wei: string; sale_index: string; block_number: number; member_id: string }>();
  for (const item of awaiting.results) {
    const existing = await db.prepare("SELECT id, buyer_address, review_note FROM payment_orders WHERE transaction_hash = ? AND ((sale_index = ? AND chain_id = ? AND contract_address = ?) OR (sale_index IS NULL AND (review_note IS NULL OR review_note NOT LIKE '%sale #%' OR review_note LIKE ?)))").bind(item.transaction_hash, item.sale_index, chain.id, contractAddress, `%sale #${item.sale_index}`).first<{ id: string; buyer_address: string | null; review_note: string | null }>();
    // A hash can contain multiple events. Never discard an unmatched event
    // merely because a different sale from the same transaction was saved.
    if (existing && (existing.buyer_address?.toLowerCase() !== item.buyer_address.toLowerCase() || !existing.review_note?.endsWith(`sale #${item.sale_index}`))) continue;
    if (!existing) {
      const result = await recordVerifiedPurchase(db, item.member_id, { transactionHash: item.transaction_hash, buyer: item.buyer_address, contractAddress, packageId: item.package_id, feeWei: BigInt(item.fee_wei), saleIndex: BigInt(item.sale_index), blockNumber: BigInt(item.block_number) }, chain, checkout === "usdc" ? "chain:usdc-watcher" : "chain:watcher");
      if ("error" in result) continue;
    }
    await db.prepare("DELETE FROM unmatched_chain_purchases WHERE chain_id = ? AND contract_address = ? AND transaction_hash = ? AND sale_index = ?")
      .bind(chain.id, contractAddress, item.transaction_hash, item.sale_index).run();
  }
  let latest: bigint;
  try {
    latest = await latestBlockNumber(rpcUrls);
  } catch {
    return { scanned: false, credited: 0, skipped: 0, reason: "rpc unavailable" };
  }
  const safeHead = latest - BigInt(chain.confirmations);
  let stored: { value: string } | null;
  try { stored = await db.prepare("SELECT value FROM app_settings WHERE key = ?").bind(cursorKey).first<{ value: string }>(); }
  catch { return { scanned: false, credited: 0, skipped: 0, reason: "cursor unavailable" }; }
  const from = stored?.value ? BigInt(stored.value) + 1n : (safeHead > syncBootstrapLookback ? safeHead - syncBootstrapLookback : 0n);
  if (from > safeHead) return { scanned: true, from: from.toString(), to: safeHead.toString(), credited: 0, skipped: 0 };
  const to = from + syncChunk - 1n < safeHead ? from + syncChunk - 1n : safeHead;
  let logs;
  try {
    logs = await fetchPurchaseLogs({ contractAddress, rpcUrls, fromBlock: from, toBlock: to });
  } catch {
    return { scanned: false, credited: 0, skipped: 0, reason: "log query failed" };
  }
  let credited = 0;
  let skipped = 0;
  for (const log of logs) {
    if (!log.packageId || log.feeWei !== platformFeeWei || log.usdtAmount !== packageUsdtWei(log.packageId) || log.credits !== packageById(log.packageId)?.credits) { skipped += 1; continue; }
    const existing = await db.prepare("SELECT id FROM payment_orders WHERE transaction_hash = ? AND ((sale_index = ? AND chain_id = ? AND contract_address = ?) OR (sale_index IS NULL AND (review_note IS NULL OR review_note NOT LIKE '%sale #%' OR review_note LIKE ?)))").bind(log.transactionHash, log.saleIndex.toString(), chain.id, contractAddress, `%sale #${log.saleIndex}`).first<{ id: string }>();
    if (existing) { skipped += 1; continue; }
    const member = await db
      .prepare("SELECT id, email, wallet_address, credits, invite_code FROM members WHERE wallet_address = ?")
      .bind(log.buyer)
      .first<MemberRecord>();
    if (!member) {
      await db.prepare("INSERT OR IGNORE INTO unmatched_chain_purchases (chain_id, contract_address, transaction_hash, buyer_address, package_id, fee_wei, sale_index, block_number, checkout, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
        .bind(chain.id, contractAddress, log.transactionHash, log.buyer, log.packageId, log.feeWei.toString(), log.saleIndex.toString(), Number(log.blockNumber), checkout, now()).run();
      skipped += 1; continue;
    }
    const recorded = await recordVerifiedPurchase(db, member.id, { ...log, packageId: log.packageId, contractAddress }, chain, checkout === "usdc" ? "chain:usdc-watcher" : "chain:watcher");
    if ("error" in recorded) {
      // A concurrent request may have recorded the same hash; otherwise never
      // advance the cursor past a failed database write, so it can be retried.
      const saved = await db.prepare("SELECT id FROM payment_orders WHERE transaction_hash = ? AND sale_index = ? AND chain_id = ? AND contract_address = ?").bind(log.transactionHash, log.saleIndex.toString(), chain.id, contractAddress).first<{ id: string }>();
      if (saved) skipped += 1;
      else return { scanned: false, from: from.toString(), to: to.toString(), credited, skipped, reason: "order write failed" };
    } else credited += 1;
  }
  await db
    .prepare("INSERT INTO app_settings (key, value, updated_at) VALUES (?, ?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at")
    .bind(cursorKey, to.toString(), now())
    .run();
  return { scanned: true, from: from.toString(), to: to.toString(), credited, skipped };
}

async function adminChainSync(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const access = await requireSession(request, env, "admin");
  if ("response" in access) return access.response;
  return json(await syncPurchasesFromChain(env));
}

const verificationMessages: Record<PurchaseVerificationFailure, { message: string; status: number }> = {
  TX_NOT_FOUND: { message: "Transaction not found on BSC yet", status: 404 },
  TX_PENDING: { message: "Transaction is still pending", status: 202 },
  TX_REVERTED: { message: "Transaction reverted on chain", status: 400 },
  WRONG_CONTRACT: { message: "Transaction did not call the Xuanyuan credit store", status: 400 },
  NO_PURCHASE_EVENT: { message: "Transaction contains no purchase", status: 400 },
  WRONG_BUYER: { message: "Transaction was sent from a different wallet", status: 403 },
  UNKNOWN_PACKAGE: { message: "Choose a valid credit package", status: 400 },
  AMOUNT_MISMATCH: { message: "Purchase amount does not match the package", status: 400 },
  FEE_MISMATCH: { message: "Platform fee does not match", status: 400 },
  NOT_CONFIRMED: { message: "Waiting for block confirmations", status: 202 },
  RPC_UNAVAILABLE: { message: "Chain verification is temporarily unavailable", status: 503 },
};

/**
 * Confirm a wallet purchase: the browser sends the transaction hash after the
 * XuanyuanCreditStore `buy` call is mined. The worker reads the receipt from BSC,
 * checks the Purchased event against the owner policy and credits the account.
 */
async function createOrder(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const payload = await requestJson(request);
  const transactionHash = normalizeTxHash(payload?.transactionHash);
  if (!transactionHash) return error("Enter a valid transaction hash");
  if (payload?.packageId !== undefined && (typeof payload.packageId !== "string" || !packageById(payload.packageId))) {
    return error("Choose a valid credit package");
  }
  if (payload?.checkout !== undefined && payload.checkout !== "legacy" && payload.checkout !== "usdc") return error("Unsupported checkout", 400);
  const isUsdc = payload?.checkout === "usdc";
  const contractAddress = isUsdc ? configuredUsdcCheckoutAddress(env) : configuredCreditStoreAddress(env);
  if (!contractAddress) return error("Checkout is not configured yet", 503);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const member = await memberForSession(env, access.session);
  if (!member) return error("Authentication required", 401);
  const buyer = normalizeAddress(member.wallet_address);
  if (!buyer) return error("Sign in with your wallet to purchase credits", 403);

  const chain = configuredChain(env);
  const verification = await verifyPurchaseReceipt({
    transactionHash,
    expectedBuyer: buyer,
    contractAddress,
    rpcUrls: configuredRpcUrls(env),
    minimumConfirmations: chain.confirmations,
  });
  if (!verification.ok) {
    const detail = verificationMessages[verification.reason];
    return json({ error: detail.message, code: verification.reason }, { status: detail.status });
  }
  const purchase = verification.purchase;
  const existing = await db
    .prepare("SELECT id, member_id, package_id, amount_usdt, settlement_currency, credits, network, transaction_hash, status, submitted_at, reviewed_at, reviewed_by, review_note, buyer_address, chain_id, fee_wei, block_number FROM payment_orders WHERE transaction_hash = ? AND ((sale_index = ? AND chain_id = ? AND contract_address = ?) OR (sale_index IS NULL AND (review_note IS NULL OR review_note NOT LIKE '%sale #%' OR review_note LIKE ?)))")
    .bind(transactionHash, purchase.saleIndex.toString(), chain.id, contractAddress, `%sale #${purchase.saleIndex}`)
    .first<OrderRecord & { member_id: string }>();
  if (existing) {
    if (existing.member_id && existing.member_id !== member.id) return error("This transaction hash has already been submitted", 409);
    return json({ order: serializeOrder(existing), member: serializeMember(member), duplicate: true });
  }
  if (typeof payload?.packageId === "string" && payload.packageId !== purchase.packageId) {
    return json({ error: "Purchase amount does not match the package", code: "AMOUNT_MISMATCH" }, { status: 400 });
  }
  const selectedPackage = packageById(purchase.packageId);
  if (!selectedPackage) return error("Choose a valid credit package");

  const recorded = await recordVerifiedPurchase(db, member.id, purchase, chain, isUsdc ? "chain:usdc" : "chain:bsc");
  if ("error" in recorded) return recorded.error;
  const updatedMember = await memberForSession(env, access.session);
  return json({ order: serializeOrder(recorded.order), member: serializeMember(updatedMember ?? member) }, { status: 201 });
}

function maskIdentity(email: string | null | undefined, wallet: string | null | undefined) {
  if (wallet) return `${wallet.slice(0, 6)}…${wallet.slice(-4)}`;
  if (email) {
    const [name, domain] = email.split("@");
    return `${name.slice(0, 2)}***@${domain ?? ""}`;
  }
  return "—";
}

/** People who joined with this member's invitation code (identities masked). */
async function memberInvitations(request: Request, env: CommerceEnv) {
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const result = await db
    .prepare("SELECT members.id, members.email, members.wallet_address, invitation_purchase_rewards.awarded_at AS created_at FROM invitation_purchase_rewards JOIN members ON members.id = invitation_purchase_rewards.invitee_member_id WHERE invitation_purchase_rewards.inviter_member_id = ? ORDER BY invitation_purchase_rewards.awarded_at DESC LIMIT 100")
    .bind(access.session.sub)
    .all<{ id: string; email: string | null; wallet_address: string | null; created_at: string }>();
  return json({
    invitations: result.results.map((row) => ({
      id: row.id,
      label: maskIdentity(row.email, row.wallet_address),
      via: row.wallet_address ? "wallet" : "email",
      joinedAt: row.created_at,
      reward: invitationPurchaseCreditAward,
    })),
    total: result.results.length,
    rewardPerInvite: invitationPurchaseCreditAward,
  });
}

async function memberOrders(request: Request, env: CommerceEnv) {
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const result = await db
    .prepare("SELECT id, package_id, amount_usdt, settlement_currency, credits, network, transaction_hash, status, submitted_at, reviewed_at, reviewed_by, review_note, buyer_address, chain_id, fee_wei, block_number FROM payment_orders WHERE member_id = ? ORDER BY submitted_at DESC LIMIT 30")
    .bind(access.session.sub)
    .all<OrderRecord>();
  return json({ orders: result.results.map(serializeOrder) });
}

async function memberLedger(request: Request, env: CommerceEnv) {
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  // Paged newest first: ?before=<createdAt of the last entry shown> returns the next 50.
  const url = new URL(request.url);
  const beforeParam = url.searchParams.get("before") ?? "";
  const before = /^\d{4}-\d{2}-\d{2}T[\d:.]+Z$/.test(beforeParam) ? beforeParam : "9999-12-31T00:00:00.000Z";
  const pageSize = 50;
  const result = await db
    .prepare("SELECT credit_ledger.id, credit_ledger.member_id, members.email AS member_email, members.wallet_address AS member_wallet, credit_ledger.order_id, credit_ledger.delta, credit_ledger.balance_after, credit_ledger.reason, credit_ledger.created_at FROM credit_ledger JOIN members ON members.id = credit_ledger.member_id WHERE credit_ledger.member_id = ? AND credit_ledger.created_at < ? ORDER BY credit_ledger.created_at DESC LIMIT ?")
    .bind(access.session.sub, before, pageSize + 1)
    .all<LedgerRecord>();
  const rows = result.results.slice(0, pageSize);
  const nextBefore = result.results.length > pageSize ? rows[rows.length - 1].created_at : null;
  return json({ entries: rows.map(serializeLedgerEntry), nextBefore });
}

async function memberInterpretationHistory(request: Request, env: CommerceEnv) {
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  // Paid reports stay readable without a time limit; the list shows the newest 300.
  const result = await db.prepare("SELECT id, tool, locale, mode, question, response_json, cost, created_at, subject, chart_json IS NOT NULL AS has_chart FROM interpretation_history WHERE member_id = ? AND hidden_at IS NULL ORDER BY created_at DESC LIMIT 300").bind(access.session.sub).all<InterpretationHistoryRecord & { subject: string | null; has_chart: number }>();
  return json({ interpretations: result.results.flatMap((item) => {
    try { return [{ id: item.id, tool: item.tool, locale: item.locale, mode: item.mode, question: item.question, response: JSON.parse(item.response_json), cost: numericValue(item.cost), createdAt: item.created_at, subject: item.subject ?? null, hasChart: Boolean(item.has_chart) }]; }
    catch { return []; }
  }) });
}

/** One saved report with its chart, so the member can ask a follow-up in the same context. */
async function memberInterpretationDetail(request: Request, env: CommerceEnv, id: string) {
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const item = await db.prepare("SELECT id, tool, locale, mode, question, response_json, cost, created_at, subject, chart_json FROM interpretation_history WHERE id = ? AND member_id = ? AND hidden_at IS NULL").bind(id, access.session.sub).first<InterpretationHistoryRecord & { subject: string | null; chart_json: string | null }>();
  if (!item) return error("Reading not found", 404);
  let chart: unknown = null; let response: unknown = null;
  try { response = JSON.parse(item.response_json); chart = item.chart_json ? JSON.parse(item.chart_json) : null; } catch { /* keep what parsed */ }
  return json({ interpretation: { id: item.id, tool: item.tool, locale: item.locale, mode: item.mode, question: item.question, response, cost: numericValue(item.cost), createdAt: item.created_at, subject: item.subject ?? null, chart } });
}

// ---------------------------------------------------------------------------------------------
// Member library: saved birth profiles (self and family with consent), notes on reports,
// data export and deletion.
// ---------------------------------------------------------------------------------------------
type ProfileRow = { id: string; label: string; relation: string; name: string; gender: string; calendar: string; birth_date: string; birth_time: string; leap_month: number; place: string; location_json: string | null; consent_at: string | null; created_at: string; updated_at: string };
const profileRelations = new Set(["self", "partner", "child", "parent", "sibling", "friend", "other"]);
const serializeProfile = (row: ProfileRow) => {
  let location: unknown = null;
  try { location = row.location_json ? JSON.parse(row.location_json) : null; } catch { location = null; }
  return { id: row.id, label: row.label, relation: row.relation, name: row.name, gender: row.gender, calendar: row.calendar, date: row.birth_date, time: row.birth_time, leapMonth: Boolean(row.leap_month), place: row.place, location, consentAt: row.consent_at, updatedAt: row.updated_at };
};
function profileFromPayload(payload: Record<string, unknown> | null) {
  const label = compactText(payload?.label, 40);
  const relation = typeof payload?.relation === "string" && profileRelations.has(payload.relation) ? payload.relation : "self";
  const date = typeof payload?.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(payload.date) ? payload.date : null;
  const time = typeof payload?.time === "string" && /^(\d{2}:\d{2})?$/.test(payload.time) ? payload.time : "";
  const gender = payload?.gender === "yin" ? "yin" : "yang";
  const calendar = payload?.calendar === "lunar" ? "lunar" : "solar";
  const location = record(payload?.location);
  const safeLocation = location && typeof location.latitude === "number" && typeof location.longitude === "number" ? JSON.stringify({ label: compactText(location.label, 120) ?? "", latitude: location.latitude, longitude: location.longitude, timezone: compactText(location.timezone, 60) ?? "" }) : null;
  if (!label || !date) return null;
  return { label, relation, name: compactText(payload?.name, 60) ?? "", gender, calendar, date, time, leapMonth: payload?.leapMonth === true ? 1 : 0, place: compactText(payload?.place, 120) ?? "", location: safeLocation, consent: payload?.consent === true };
}

async function memberProfiles(request: Request, env: CommerceEnv, id: string | null, action: "save" | "delete" | null) {
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const member = access.session.sub;
  const list = async () => (await db.prepare("SELECT * FROM member_profiles WHERE member_id = ? ORDER BY relation = 'self' DESC, updated_at DESC LIMIT 50").bind(member).all<ProfileRow>()).results.map(serializeProfile);
  if (request.method === "GET") return json({ profiles: await list() });
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  if (action === "delete" && id) {
    await db.prepare("DELETE FROM member_profiles WHERE id = ? AND member_id = ?").bind(id, member).run();
    return json({ profiles: await list() });
  }
  const profile = profileFromPayload(await requestJson(request));
  if (!profile) return json({ error: "Name the profile and enter a birth date", code: "PROFILE_INVALID" }, { status: 400 });
  // Someone else's birth details are only kept with the member's confirmation that they agreed.
  if (profile.relation !== "self" && !profile.consent) return json({ error: "Confirm that this person agreed", code: "CONSENT_REQUIRED" }, { status: 400 });
  const timestamp = now();
  if (id) {
    const updated = await db.prepare("UPDATE member_profiles SET label = ?, relation = ?, name = ?, gender = ?, calendar = ?, birth_date = ?, birth_time = ?, leap_month = ?, place = ?, location_json = ?, consent_at = COALESCE(consent_at, ?), updated_at = ? WHERE id = ? AND member_id = ?")
      .bind(profile.label, profile.relation, profile.name, profile.gender, profile.calendar, profile.date, profile.time, profile.leapMonth, profile.place, profile.location, profile.relation === "self" ? null : timestamp, timestamp, id, member).run();
    if ((updated.meta?.changes ?? 0) !== 1) return error("Profile not found", 404);
  } else {
    const count = await db.prepare("SELECT COUNT(*) AS total FROM member_profiles WHERE member_id = ?").bind(member).first<{ total: number }>();
    if (numericValue(count?.total) >= 30) return json({ error: "Up to 30 profiles", code: "PROFILE_LIMIT" }, { status: 400 });
    await db.prepare("INSERT INTO member_profiles (id, member_id, label, relation, name, gender, calendar, birth_date, birth_time, leap_month, place, location_json, consent_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
      .bind(crypto.randomUUID(), member, profile.label, profile.relation, profile.name, profile.gender, profile.calendar, profile.date, profile.time, profile.leapMonth, profile.place, profile.location, profile.relation === "self" ? null : timestamp, timestamp, timestamp).run();
  }
  return json({ profiles: await list() });
}

async function memberNotes(request: Request, env: CommerceEnv) {
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const member = access.session.sub;
  if (request.method === "GET") {
    const { results } = await db.prepare("SELECT ref, body, updated_at FROM member_notes WHERE member_id = ? ORDER BY updated_at DESC LIMIT 500").bind(member).all<{ ref: string; body: string; updated_at: string }>();
    return json({ notes: results.map((row) => ({ ref: row.ref, body: row.body, updatedAt: row.updated_at })) });
  }
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const payload = await requestJson(request);
  const ref = typeof payload?.ref === "string" && /^(report|book|general):[A-Za-z0-9-]{1,64}$/.test(payload.ref) ? payload.ref : null;
  if (!ref) return error("Unknown note", 400);
  const body = typeof payload?.body === "string" ? payload.body.slice(0, 5_000) : "";
  const timestamp = now();
  if (!body.trim()) await db.prepare("DELETE FROM member_notes WHERE member_id = ? AND ref = ?").bind(member, ref).run();
  else await db.prepare("INSERT INTO member_notes (member_id, ref, body, created_at, updated_at) VALUES (?, ?, ?, ?, ?) ON CONFLICT(member_id, ref) DO UPDATE SET body = excluded.body, updated_at = excluded.updated_at").bind(member, ref, body, timestamp, timestamp).run();
  return json({ ref, body: body.trim() ? body : "", updatedAt: timestamp });
}

/** Everything stored about the member, as one JSON file. */
async function memberExport(request: Request, env: CommerceEnv) {
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const member = access.session.sub;
  const all = async (sql: string) => (await db.prepare(sql).bind(member).all<Record<string, unknown>>()).results;
  const account = await db.prepare("SELECT id, email, wallet_address, credits, daily_credits, invite_code, created_at FROM members WHERE id = ?").bind(member).first<Record<string, unknown>>();
  const data = {
    exportedAt: now(),
    account,
    profiles: await all("SELECT label, relation, name, gender, calendar, birth_date, birth_time, leap_month, place, location_json, consent_at, created_at, updated_at FROM member_profiles WHERE member_id = ?"),
    reports: (await all("SELECT id, tool, locale, mode, question, response_json, cost, subject, created_at FROM interpretation_history WHERE member_id = ? AND hidden_at IS NULL ORDER BY created_at DESC")).map((row) => { try { return { ...row, response: JSON.parse(String(row.response_json)), response_json: undefined }; } catch { return row; } }),
    notes: await all("SELECT ref, body, updated_at FROM member_notes WHERE member_id = ?"),
    bookshelf: await all("SELECT work_id, favorite, chapter, chapter_title, read_at FROM library_shelf WHERE member_id = ?"),
    credits: await all("SELECT delta, balance_after, reason, created_at FROM credit_ledger WHERE member_id = ? ORDER BY created_at DESC"),
  };
  return new Response(JSON.stringify(data, null, 2), { headers: { "content-type": "application/json; charset=utf-8", "content-disposition": `attachment; filename="xuannova-my-data.json"`, "cache-control": "no-store" } });
}

/** Delete stored personal data by category. Credit and order records are kept (they are needed for accounting and refunds). */
async function memberDeleteData(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const member = access.session.sub;
  const payload = await requestJson(request);
  const scopes = Array.isArray(payload?.scopes) ? payload.scopes.filter((item): item is string => typeof item === "string") : [];
  const statements: string[] = [];
  if (scopes.includes("reports")) statements.push("DELETE FROM interpretation_history WHERE member_id = ?", "DELETE FROM member_notes WHERE member_id = ? AND ref LIKE 'report:%'");
  if (scopes.includes("profiles")) statements.push("DELETE FROM member_profiles WHERE member_id = ?", "DELETE FROM room_shares WHERE member_id = ?");
  if (scopes.includes("notes")) statements.push("DELETE FROM member_notes WHERE member_id = ?");
  if (scopes.includes("bookshelf")) statements.push("DELETE FROM library_shelf WHERE member_id = ?");
  if (!statements.length) return error("Choose what to delete", 400);
  for (const sql of statements) await db.prepare(sql).bind(member).run();
  if (scopes.includes("reports")) await db.prepare("UPDATE reading_drafts SET chart_json = NULL WHERE member_id = ? OR unlocked_by = ?").bind(member, member).run();
  return json({ deleted: scopes });
}


async function createInterpretation(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const payload = await requestJson(request);
  if (!compactText(payload?.question, 1_000)) {
    return json({ error: "Enter a question before requesting an interpretation", code: "QUESTION_REQUIRED" }, { status: 400 });
  }
  const input = interpretationInput(payload);
  if (!input) return json({ error: "Generate a complete chart before requesting an interpretation", code: "CHART_INCOMPLETE" }, { status: 400 });
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const member = await refreshDailyCredits(db, access.session.sub, request);
  if (!member) return error("Authentication required", 401);
  // Follow-up answers cost the standard 20; the higher price is only for a full deep-reading report.
  const cost = input.mode === "conversation" ? interpretationCost("") : interpretationCost(input.request.tool);
  if (member.credits + numericValue(member.daily_credits) < cost) return error("Insufficient credits", 402);

  let reading;
  try {
    reading = await requestDeepSeekInterpretation(input.request, input.mode, env.DEEPSEEK_API_KEY, env.DEEPSEEK_MODEL);
  } catch (cause) {
    if (cause instanceof DeepSeekServiceError) {
      const status = ["AI_NOT_CONFIGURED", "AI_AUTH_FAILED", "AI_REQUEST_REJECTED"].includes(cause.code) ? 503 : 502;
      return json({ error: "Interpretation service is unavailable", code: cause.code }, { status });
    }
    return json({ error: "Interpretation service is unavailable", code: "AI_UNAVAILABLE" }, { status: 502 });
  }

  const timestamp = now();
  // The balance change and its audit entry must commit together.  In
  // particular, never deduct a balance and then lose the corresponding ledger
  // record if the second write fails. `changes() = 1` prevents an entry when a
  // concurrent request consumed the remaining balance first.
  const ledgerId = crypto.randomUUID();
  const historyId = crypto.randomUUID();
  const [debit] = await db.batch!([
    db
      .prepare("UPDATE members SET daily_credits = daily_credits - MIN(daily_credits, ?), credits = credits - MAX(0, ? - daily_credits), updated_at = ? WHERE id = ? AND credits + daily_credits >= ?")
      .bind(cost, cost, timestamp, member.id, cost),
    db
      .prepare("INSERT INTO credit_ledger (id, member_id, order_id, delta, balance_after, reason, created_at) SELECT ?, id, NULL, ?, credits + daily_credits, ?, ? FROM members WHERE id = ? AND changes() = 1")
      .bind(ledgerId, -cost, `interpretation:${input.request.tool}`, timestamp, member.id),
    db
      .prepare("INSERT INTO interpretation_history (id, member_id, tool, locale, mode, question, response_json, cost, created_at, chart_json, subject) SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? WHERE EXISTS (SELECT 1 FROM credit_ledger WHERE id = ?)")
      .bind(historyId, member.id, input.request.tool, input.request.locale, input.mode, input.request.question, JSON.stringify(reading), cost, timestamp, chartJson(input.request.chart), chartSubject(input.request.chart), ledgerId),
  ]);
  if ((debit.meta?.changes ?? 0) !== 1) return error("Insufficient credits", 402);
  const updatedMember = await memberForSession(env, access.session);
  if (!updatedMember) return error("Authentication required", 401);
  // The balance fetch follows the committed ledger write, so clients only see
  // a new balance once the complete credit event is durable.
  return json({ response: reading, cost, member: serializeMember(updatedMember), interpretation: { id: historyId, tool: input.request.tool, locale: input.request.locale, mode: input.mode, question: input.request.question, response: reading, cost, createdAt: timestamp } });
}


// ---------------------------------------------------------------------------------------------
// Card payments through Dodo Payments. The webhook is verified (Standard Webhooks signature) and the
// payment is read back from Dodo before credits are added; every delivery is processed at most once.
// ---------------------------------------------------------------------------------------------
type DodoOrderRow = { id: string; member_id: string; package_id: string; credits: number; amount_usd: string; payment_id: string | null; status: string; refunded_credits: number };

async function dodoCheckout(request: Request, env: CommerceEnv, fetchImpl: typeof fetch = fetch) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  if (!dodoEnabled(env)) return error("Card payment is not available yet", 503);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const payload = await requestJson(request);
  const packageId = typeof payload?.packageId === "string" ? payload.packageId : "";
  let selected: { id: string; usdt: string; credits: number } | undefined = packageById(packageId);
  if (!selected && packageId.startsWith("x-")) {
    const exclusive = (await exclusivePackagesFor(db, access.session.sub)).find((item) => item.id === packageId);
    if (exclusive) selected = { id: exclusive.id, usdt: exclusive.price_usdt, credits: numericValue(exclusive.credits) };
  }
  const productId = selected ? dodoProducts(env)[selected.id] : undefined;
  if (!selected || !productId) return error("This package cannot be paid by card yet");
  const member = await db.prepare("SELECT id, email FROM members WHERE id = ?").bind(access.session.sub).first<{ id: string; email: string | null }>();
  if (!member) return error("Authentication required", 401);
  const orderId = crypto.randomUUID();
  const timestamp = now();
  await db.prepare("INSERT INTO dodo_orders (id, member_id, package_id, credits, amount_usd, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 'created', ?, ?)")
    .bind(orderId, member.id, selected.id, selected.credits, selected.usdt, timestamp, timestamp).run();
  const locale = typeof payload?.locale === "string" && /^(en|zh-Hans|zh-Hant|ja|ko|vi|th)$/.test(payload.locale) ? payload.locale : "en";
  const origin = (env.SITE_URL ?? new URL(request.url).origin).replace(/\/$/, "");
  const returnUrl = `${origin}${locale === "en" ? "" : `/${locale.toLowerCase()}`}/credits?dodo_order=${orderId}`;
  try {
    const checkout = await createDodoCheckout(env, { productId, email: member.email, returnUrl, metadata: { order_id: orderId, member_id: member.id, package_id: selected.id } }, fetchImpl);
    await db.prepare("UPDATE dodo_orders SET checkout_session_id = ?, updated_at = ? WHERE id = ?").bind(checkout.sessionId, now(), orderId).run();
    return json({ url: checkout.url, orderId });
  } catch {
    await db.prepare("UPDATE dodo_orders SET status = 'failed', updated_at = ? WHERE id = ?").bind(now(), orderId).run();
    return error("Card payment is temporarily unavailable", 502);
  }
}

async function dodoOrderStatus(request: Request, env: CommerceEnv) {
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const id = new URL(request.url).searchParams.get("id") ?? "";
  const order = await db.prepare("SELECT id, package_id, credits, status, paid_at FROM dodo_orders WHERE id = ? AND member_id = ?").bind(id, access.session.sub).first<{ id: string; package_id: string; credits: number; status: string; paid_at: string | null }>();
  if (!order) return error("Order not found", 404);
  return json({ order: { id: order.id, packageId: order.package_id, credits: numericValue(order.credits), status: order.status, paidAt: order.paid_at } });
}

async function creditDodoOrder(db: CommerceDatabase, order: DodoOrderRow, paymentId: string) {
  const timestamp = now();
  const [claim] = await db.batch!([
    db.prepare("UPDATE dodo_orders SET status = 'paid', payment_id = ?, paid_at = ?, updated_at = ? WHERE id = ? AND status = 'created'").bind(paymentId, timestamp, timestamp, order.id),
    db.prepare("UPDATE members SET credits = credits + ?, updated_at = ? WHERE id = ? AND changes() = 1").bind(numericValue(order.credits), timestamp, order.member_id),
    db.prepare("INSERT INTO credit_ledger (id, member_id, order_id, delta, balance_after, reason, created_at) SELECT ?, id, NULL, ?, credits + daily_credits, 'dodo_payment', ? FROM members WHERE id = ? AND changes() = 1")
      .bind(crypto.randomUUID(), numericValue(order.credits), timestamp, order.member_id),
  ]);
  if ((claim.meta?.changes ?? 0) !== 1) return false;
  // First purchase by an invited member: 5 credits each, once per member across USDT and card purchases.
  const invitee = await db.prepare("SELECT id, invited_by_member_id, credits, daily_credits FROM members WHERE id = ?").bind(order.member_id).first<MemberRecord & { invited_by_member_id?: string | null }>();
  if (invitee?.invited_by_member_id) {
    const already = await db.prepare("SELECT 1 AS found FROM invitation_purchase_rewards WHERE invitee_member_id = ? UNION SELECT 1 FROM dodo_invitation_rewards WHERE invitee_member_id = ?").bind(invitee.id, invitee.id).first();
    const inviter = await db.prepare("SELECT id, credits, daily_credits FROM members WHERE id = ?").bind(invitee.invited_by_member_id).first<MemberRecord>();
    if (!already && inviter) {
      try {
        await db.batch!([
          db.prepare("INSERT INTO dodo_invitation_rewards (invitee_member_id, inviter_member_id, dodo_order_id, awarded_at) VALUES (?, ?, ?, ?)").bind(invitee.id, inviter.id, order.id, timestamp),
          db.prepare("UPDATE members SET credits = credits + ?, updated_at = ? WHERE id IN (?, ?)").bind(invitationPurchaseCreditAward, timestamp, invitee.id, inviter.id),
          db.prepare("INSERT INTO credit_ledger (id, member_id, order_id, delta, balance_after, reason, created_at) SELECT ?, id, NULL, ?, credits + daily_credits, 'invitation_purchase', ? FROM members WHERE id = ?").bind(crypto.randomUUID(), invitationPurchaseCreditAward, timestamp, invitee.id),
          db.prepare("INSERT INTO credit_ledger (id, member_id, order_id, delta, balance_after, reason, created_at) SELECT ?, id, NULL, ?, credits + daily_credits, 'invitation_purchase', ? FROM members WHERE id = ?").bind(crypto.randomUUID(), invitationPurchaseCreditAward, timestamp, inviter.id),
        ]);
      } catch { /* the reward was already given */ }
    }
  }
  return true;
}

async function refundDodoOrder(db: CommerceDatabase, order: DodoOrderRow, refundedCents: number | null) {
  if (order.status !== "paid" && order.status !== "partially_refunded") return;
  const orderCents = Math.round(Number(order.amount_usd) * 100);
  const credits = numericValue(order.credits);
  const target = refundedCents && orderCents > 0 && refundedCents < orderCents ? Math.round((credits * refundedCents) / orderCents) : credits;
  const toRemove = Math.max(0, Math.min(credits, target) - numericValue(order.refunded_credits));
  const member = await db.prepare("SELECT id, credits FROM members WHERE id = ?").bind(order.member_id).first<{ id: string; credits: number }>();
  if (!member) return;
  const removable = Math.min(toRemove, numericValue(member.credits));
  const timestamp = now();
  const status = target >= credits ? "refunded" : "partially_refunded";
  await db.batch!([
    db.prepare("UPDATE dodo_orders SET status = ?, refunded_credits = refunded_credits + ?, updated_at = ? WHERE id = ?").bind(status, toRemove, timestamp, order.id),
    db.prepare("UPDATE members SET credits = credits - ?, updated_at = ? WHERE id = ? AND credits >= ?").bind(removable, timestamp, member.id, removable),
    db.prepare("INSERT INTO credit_ledger (id, member_id, order_id, delta, balance_after, reason, created_at) SELECT ?, id, NULL, ?, credits + daily_credits, 'dodo_refund', ? FROM members WHERE id = ?").bind(crypto.randomUUID(), -removable, timestamp, member.id),
  ]);
  // A full refund of the member's only purchase also takes back the first-purchase bonus (never below zero).
  if (status !== "refunded") return;
  const otherPurchase = await db.prepare("SELECT 1 AS yes FROM payment_orders WHERE member_id = ? AND status = 'approved' UNION ALL SELECT 1 FROM dodo_orders WHERE member_id = ? AND status = 'paid' AND id <> ? LIMIT 1").bind(member.id, member.id, order.id).first<{ yes: number }>();
  const bonus = await db.prepare("SELECT credits FROM first_purchase_bonus WHERE member_id = ?").bind(member.id).first<{ credits: number }>();
  if (otherPurchase || !bonus || numericValue(bonus.credits) <= 0) return;
  const current = await db.prepare("SELECT credits FROM members WHERE id = ?").bind(member.id).first<{ credits: number }>();
  const takeBack = Math.min(numericValue(bonus.credits), numericValue(current?.credits));
  await db.batch!([
    db.prepare("UPDATE first_purchase_bonus SET credits = 0 WHERE member_id = ?").bind(member.id),
    db.prepare("UPDATE members SET credits = credits - ?, updated_at = ? WHERE id = ? AND credits >= ?").bind(takeBack, timestamp, member.id, takeBack),
    db.prepare("INSERT INTO credit_ledger (id, member_id, order_id, delta, balance_after, reason, created_at) SELECT ?, id, NULL, ?, credits + daily_credits, 'first_purchase_bonus_reversed', ? FROM members WHERE id = ?").bind(crypto.randomUUID(), -takeBack, timestamp, member.id),
  ]);
}

async function dodoWebhook(request: Request, env: CommerceEnv, fetchImpl: typeof fetch = fetch) {
  const raw = await request.text();
  if (!env.DODO_WEBHOOK_SECRET || !(await verifyDodoWebhook(env.DODO_WEBHOOK_SECRET, request.headers, raw))) return error("Invalid signature", 400);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const webhookId = request.headers.get("webhook-id") ?? "";
  if (await db.prepare("SELECT webhook_id FROM dodo_webhook_events WHERE webhook_id = ?").bind(webhookId).first()) return json({ ok: true, duplicate: true });
  let event: { type?: string; data?: Record<string, unknown> };
  try { event = JSON.parse(raw); } catch { return error("Invalid payload", 400); }
  const data = record(event.data) ?? {};
  const metadata = record(data.metadata) ?? {};
  const paymentId = typeof data.payment_id === "string" ? data.payment_id : "";
  const type = event.type ?? "";
  const orderById = (id: unknown) => typeof id === "string" ? db.prepare("SELECT * FROM dodo_orders WHERE id = ?").bind(id).first<DodoOrderRow>() : Promise.resolve(null);
  if (type === "payment.succeeded" && paymentId) {
    // Read the payment back from Dodo; only a succeeded payment carrying our order id adds credits.
    const confirmed = await fetchDodoPayment(env, paymentId, fetchImpl);
    if (!confirmed || confirmed.status !== "succeeded") return error("Payment not confirmed", 409);
    const order = await orderById(confirmed.metadata?.order_id ?? metadata.order_id);
    if (!order) return error("Order not found", 404);
    await creditDodoOrder(db, order, paymentId);
  } else if ((type === "payment.failed" || type === "payment.cancelled") && metadata.order_id) {
    await db.prepare("UPDATE dodo_orders SET status = 'failed', updated_at = ? WHERE id = ? AND status = 'created'").bind(now(), String(metadata.order_id)).run();
  } else if (type === "refund.succeeded" && paymentId) {
    const order = await db.prepare("SELECT * FROM dodo_orders WHERE payment_id = ?").bind(paymentId).first<DodoOrderRow>();
    if (order) await refundDodoOrder(db, order, typeof data.amount === "number" ? data.amount : null);
  }
  await db.prepare("INSERT OR IGNORE INTO dodo_webhook_events (webhook_id, type, received_at) VALUES (?, ?, ?)").bind(webhookId, type || "unknown", now()).run();
  return json({ ok: true });
}


// ---------------------------------------------------------------------------------------------
// Invitation teams: how many people a member invited and their total purchases (approved USDT orders
// plus paid card orders, refunds excluded). Members see their own team; administrators see everyone.
// ---------------------------------------------------------------------------------------------
const purchasesByMember = "SELECT member_id, SUM(amount) AS total, SUM(credits) AS credits FROM (SELECT member_id, CAST(amount_usdt AS REAL) AS amount, credits FROM payment_orders WHERE status = 'approved' UNION ALL SELECT member_id, CAST(amount_usd AS REAL) AS amount, credits FROM dodo_orders WHERE status = 'paid') GROUP BY member_id";
const maskEmail = (email: string | null) => {
  if (!email) return "—";
  const [name, domain] = email.split("@");
  return `${name.slice(0, 2)}${"*".repeat(Math.max(1, name.length - 2))}@${domain ?? ""}`;
};

async function memberTeam(request: Request, env: CommerceEnv) {
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const { results } = await db.prepare(`SELECT m.email, m.wallet_address, m.created_at, COALESCE(p.total, 0) AS total, COALESCE(p.credits, 0) AS credits FROM members m LEFT JOIN (${purchasesByMember}) p ON p.member_id = m.id WHERE m.invited_by_member_id = ? ORDER BY m.created_at DESC LIMIT 500`).bind(access.session.sub).all<{ email: string | null; wallet_address: string | null; created_at: string; total: number; credits: number }>();
  const totalUsd = results.reduce((sum, row) => sum + numericValue(row.total), 0);
  const totalCredits = results.reduce((sum, row) => sum + numericValue(row.credits), 0);
  // Which of my posters or links brought them in.
  const bySource = await db.prepare("SELECT COALESCE(signup_source, 'other') AS source, COUNT(*) AS n FROM members WHERE invited_by_member_id = ? GROUP BY COALESCE(signup_source, 'other') ORDER BY n DESC").bind(access.session.sub).all<{ source: string; n: number }>();
  return json({
    sources: (bySource.results ?? []).map((row) => ({ source: row.source, invited: numericValue(row.n) })),
    invited: results.length,
    purchasers: results.filter((row) => numericValue(row.total) > 0).length,
    totalUsd: totalUsd.toFixed(2),
    totalCredits,
    members: results.slice(0, 100).map((row) => ({ name: row.email ? maskEmail(row.email) : `${(row.wallet_address ?? "").slice(0, 6)}…`, joinedAt: row.created_at, purchasedUsd: numericValue(row.total).toFixed(2) })),
  });
}

async function adminTeams(request: Request, env: CommerceEnv) {
  const access = await adminAccess(request, env);
  if ("response" in access) return access.response;
  const { results } = await access.db.prepare(`SELECT i.id, i.email, i.wallet_address, COUNT(m.id) AS invited, SUM(CASE WHEN COALESCE(p.total, 0) > 0 THEN 1 ELSE 0 END) AS purchasers, COALESCE(SUM(p.total), 0) AS total, COALESCE(SUM(p.credits), 0) AS credits FROM members i JOIN members m ON m.invited_by_member_id = i.id LEFT JOIN (${purchasesByMember}) p ON p.member_id = m.id GROUP BY i.id ORDER BY total DESC, invited DESC LIMIT 300`).all<{ id: string; email: string | null; wallet_address: string | null; invited: number; purchasers: number; total: number; credits: number }>();
  return json({ teams: results.map((row) => ({ memberId: row.id, email: row.email ?? row.wallet_address, invited: numericValue(row.invited), purchasers: numericValue(row.purchasers), totalUsd: numericValue(row.total).toFixed(2), totalCredits: numericValue(row.credits) })) });
}

// ---------------------------------------------------------------------------------------------
// Free half reading → sign in → unlock the same reading with credits.
// The full reading is stored server-side; only the first half reaches the browser before unlock.
// ---------------------------------------------------------------------------------------------
// Free half reading: once per device and once per account. A device that has used its free preview
// (signed in or not) does not get another one by creating a new account, and an account does not get
// another one by switching devices. After that, signed-in members can generate a full reading for credits.

type DraftRecord = { id: string; device_id: string; member_id: string | null; tool: string; locale: string; mode: ReadingMode; question: string; response_json: string; cost: number; unlocked_by: string | null; history_id: string | null; created_at: string; is_free?: number; chart_json?: string | null };

/** Who a reading is about (the name on the chart, and the second person for pair readings). */
function chartSubject(chart: unknown) {
  const summary = record(record(chart)?.inputSummary);
  const names = [compactText(summary?.name, 60), compactText(summary?.companionName, 60)].filter(Boolean);
  return names.length ? names.join(" & ") : null;
}
const chartJson = (chart: unknown) => { const text = JSON.stringify(chart ?? null); return text.length <= 200_000 ? text : null; };

/** Sections included in the free part: the first one, or the first two for the (twice as long) BaZi deep reading. */
const freeSectionCount = (tool: string) => (tool === "detail" ? 2 : 1);

function previewOf(reading: { title: string; summary: string; conclusion?: string; keyPoints?: string[]; teaser?: string; sections: Array<{ title: string; text: string }>; followUps: string[] }, tool = "") {
  const visible = reading.sections.slice(0, freeSectionCount(tool));
  return {
    // The free part: conclusion, key points, summary and the first section. The rest stays on the server.
    preview: { title: reading.title, summary: reading.summary, ...(reading.conclusion ? { conclusion: reading.conclusion } : {}), ...(reading.keyPoints ? { keyPoints: reading.keyPoints } : {}), ...(reading.teaser ? { teaser: reading.teaser } : {}), sections: visible, followUps: [] as string[] },
    lockedSections: reading.sections.slice(visible.length).map((section) => section.title),
  };
}

/**
 * Free half reading: available every time, for everyone. Only an invisible safety limit applies, so an
 * automated script cannot run up the reading-service bill: at most `freePreviewsPerDeviceDay` free halves
 * per device in 24 hours (and the same per signed-in account).
 */
const freePreviewsPerDeviceDay = 30;
async function freePreviewUsed(db: CommerceDatabase, deviceId: string, memberId: string | null) {
  const since = new Date(Date.now() - 86_400_000).toISOString();
  const row = await db.prepare("SELECT COUNT(*) AS total FROM reading_drafts WHERE is_free = 1 AND created_at >= ? AND (device_id = ? OR (? IS NOT NULL AND member_id = ?))")
    .bind(since, deviceId, memberId, memberId).first<{ total: number | string }>();
  return numericValue(row?.total) >= freePreviewsPerDeviceDay;
}

/** Whether the current visitor (or signed-in member) still has the free half reading. */
async function freePreviewStatus(request: Request, env: CommerceEnv) {
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const session = await readSession(request, env.SESSION_SECRET);
  const memberId = session?.role === "member" ? session.sub : null;
  const context = bonusContexts.get(request);
  const deviceId = context?.deviceId ?? "unknown";
  const tools = freeFullTools(env);
  const fullAvailable = memberId && tools.length ? await freeFullAvailable(db, memberId, deviceId, FREE_FULL_ONCE) : false;
  return json({ free: !(await freePreviewUsed(db, deviceId, memberId)), signedIn: Boolean(memberId), freeFull: { tools, available: Boolean(fullAvailable) } }, { headers: { "cache-control": "no-store" } });
}

// ---------------------------------------------------------------------------------------------
// Free full reading: one full reading per account (and per device) on the listed tools (default 八字排盘).
// The claim is stored with claim_date = "once", so the table's keys allow one per member and one per device.
// ---------------------------------------------------------------------------------------------
const FREE_FULL_ONCE = "once";
function freeFullTools(env: CommerceEnv) {
  const value = (env.FREE_FULL_TOOLS ?? "bazi").trim();
  return value === "" || value === "none" ? [] : value.split(",").map((item) => item.trim()).filter(Boolean);
}
async function freeFullAvailable(db: CommerceDatabase, memberId: string, deviceId: string, date: string) {
  const used = await db.prepare("SELECT 1 AS used FROM free_full_readings WHERE claim_date = ? AND (member_id = ? OR device_id = ?) LIMIT 1").bind(date, memberId, deviceId).first<{ used: number }>();
  return !used;
}
/** Claim today's free full reading before generating it (so parallel requests cannot both get one). */
async function claimFreeFull(db: CommerceDatabase, memberId: string, deviceId: string, date: string, tool: string) {
  if (!(await freeFullAvailable(db, memberId, deviceId, date))) return false;
  try {
    await db.prepare("INSERT INTO free_full_readings (member_id, claim_date, device_id, tool, created_at) VALUES (?, ?, ?, ?, ?)").bind(memberId, date, deviceId, tool, now()).run();
    return true;
  } catch { return false; }
}

async function generateReading(input: NonNullable<ReturnType<typeof interpretationInput>>, env: CommerceEnv): Promise<{ reading: Awaited<ReturnType<typeof requestDeepSeekInterpretation>> } | { response: Response }> {
  try {
    return { reading: await requestDeepSeekInterpretation(input.request, "structured", env.DEEPSEEK_API_KEY, env.DEEPSEEK_MODEL) };
  } catch (cause) {
    if (cause instanceof DeepSeekServiceError) {
      const status = ["AI_NOT_CONFIGURED", "AI_AUTH_FAILED", "AI_REQUEST_REJECTED"].includes(cause.code) ? 503 : 502;
      return { response: json({ error: "Interpretation service is unavailable", code: cause.code }, { status }) };
    }
    return { response: json({ error: "Interpretation service is unavailable", code: "AI_UNAVAILABLE" }, { status: 502 }) };
  }
}

async function createReadingPreview(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const payload = await requestJson(request);
  if (!compactText(payload?.question, 1_000)) return json({ error: "Enter a question before requesting an interpretation", code: "QUESTION_REQUIRED" }, { status: 400 });
  const input = interpretationInput({ ...(payload ?? {}), mode: "structured" });
  if (!input) return json({ error: "Generate a complete chart before requesting an interpretation", code: "CHART_INCOMPLETE" }, { status: 400 });
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const session = await readSession(request, env.SESSION_SECRET);
  const memberId = session?.role === "member" ? session.sub : null;
  const context = bonusContexts.get(request);
  const deviceId = context?.deviceId ?? "unknown";
  const cost = interpretationCost(input.request.tool);
  // Every request gets the free first half, unless a signed-in member asks for the full reading directly
  // (pay: true) or the daily safety limit is reached.
  const wantsPaid = payload?.pay === true && Boolean(memberId);
  // A signed-in member's first reading on a free tool (default 八字排盘) is the full reading, at no cost (once per account and device).
  const claimDate = FREE_FULL_ONCE;
  const fullFree = !wantsPaid && Boolean(memberId) && freeFullTools(env).includes(input.request.tool) && await claimFreeFull(db, memberId!, deviceId, claimDate, input.request.tool);
  const releaseFullFree = async () => { if (fullFree) await db.prepare("DELETE FROM free_full_readings WHERE member_id = ? AND claim_date = ? AND history_id IS NULL").bind(memberId, claimDate).run(); };
  const free = !fullFree && !wantsPaid && !(await freePreviewUsed(db, deviceId, memberId));
  if (!free && !wantsPaid && !fullFree) return json({ error: "Too many free readings today. Please try again tomorrow, or sign in and use credits.", code: "PREVIEW_LIMIT", cost, signedIn: Boolean(memberId) }, { status: 429 });
  if (!free && !fullFree) {
    const member = await refreshDailyCredits(db, memberId!, request);
    if (!member) return error("Authentication required", 401);
    if (member.credits + numericValue(member.daily_credits) < cost) return json({ error: "Insufficient credits", code: "INSUFFICIENT_CREDITS", cost }, { status: 402 });
  }
  // Store the finished reading, then return the free part or (paid) debit and return the whole reading.
  const finish = async (reading: Awaited<ReturnType<typeof requestDeepSeekInterpretation>>): Promise<{ status: number; body: Record<string, unknown> }> => {
    const id = crypto.randomUUID();
    await db.prepare("INSERT INTO reading_drafts (id, device_id, member_id, tool, locale, mode, question, response_json, cost, created_at, is_free, chart_json) VALUES (?, ?, ?, ?, ?, 'structured', ?, ?, ?, ?, ?, ?)")
      .bind(id, deviceId, memberId, input.request.tool, input.request.locale, input.request.question, JSON.stringify(reading), cost, now(), free ? 1 : 0, chartJson(input.request.chart)).run();
    if (free) return { status: 200, body: { draftId: id, cost, unlocked: false, free: true, ...previewOf(reading, input.request.tool) } };
    if (fullFree) {
      const historyId = crypto.randomUUID();
      const timestamp = now();
      await db.batch!([
        db.prepare("INSERT INTO interpretation_history (id, member_id, tool, locale, mode, question, response_json, cost, created_at, chart_json, subject) VALUES (?, ?, ?, ?, 'structured', ?, ?, 0, ?, ?, ?)")
          .bind(historyId, memberId, input.request.tool, input.request.locale, input.request.question, JSON.stringify(reading), timestamp, chartJson(input.request.chart), chartSubject(input.request.chart)),
        db.prepare("UPDATE reading_drafts SET unlocked_by = ?, unlocked_at = ?, history_id = ?, cost = 0 WHERE id = ?").bind(memberId, timestamp, historyId, id),
        db.prepare("UPDATE free_full_readings SET history_id = ? WHERE member_id = ? AND claim_date = ?").bind(historyId, memberId, claimDate),
      ]);
      const current = await memberForSession(env, session!);
      return { status: 200, body: { draftId: id, unlocked: true, free: false, freeFull: true, response: reading, cost: 0, member: current ? serializeMember(current) : undefined, interpretation: { id: historyId, tool: input.request.tool, locale: input.request.locale, mode: "structured", question: input.request.question, response: reading, cost: 0, createdAt: timestamp } } };
    }
    // Paid path: debit and open the reading in one atomic batch (same statements as unlocking a draft).
    const result = await debitAndUnlock(db, memberId!, id, "structured", input.request.tool, input.request.locale, input.request.question, JSON.stringify(reading), cost, chartJson(input.request.chart), chartSubject(input.request.chart));
    if (!result.ok) return { status: 402, body: { error: "Insufficient credits", code: "INSUFFICIENT_CREDITS", cost, draftId: id, ...previewOf(reading, input.request.tool) } };
    const updated = await memberForSession(env, session!);
    return { status: 200, body: { draftId: id, unlocked: true, free: false, response: reading, cost, member: updated ? serializeMember(updated) : undefined, interpretation: { id: result.historyId, tool: input.request.tool, locale: input.request.locale, mode: "structured", question: input.request.question, response: reading, cost, createdAt: result.timestamp } } };
  };
  if (payload?.stream === true) return streamReading(input, env, free, finish, releaseFullFree);
  const generated = await generateReading(input, env);
  if ("response" in generated) { await releaseFullFree(); return generated.response; }
  const finished = await finish(generated.reading);
  return json(finished.body, { status: finished.status });
}

/**
 * Server-sent events: `partial` events while the reading is written, then one `done` event carrying the
 * same status and body the non-streaming request returns. A free preview only ever streams the free part
 * (title, conclusion, key points, summary and the first section); the rest stays on the server.
 */
function streamReading(
  input: NonNullable<ReturnType<typeof interpretationInput>>,
  env: CommerceEnv,
  free: boolean,
  finish: (reading: Awaited<ReturnType<typeof requestDeepSeekInterpretation>>) => Promise<{ status: number; body: Record<string, unknown> }>,
  onFailure?: () => Promise<void>,
) {
  const encoder = new TextEncoder();
  const body = new ReadableStream<Uint8Array>({
    async start(controller) {
      const send = (event: unknown) => { try { controller.enqueue(encoder.encode(`data: ${JSON.stringify(event)}\n\n`)); } catch { /* client went away */ } };
      // Comments keep proxies from closing a quiet connection while the reply starts.
      const keepAlive = setInterval(() => { try { controller.enqueue(encoder.encode(": keep-alive\n\n")); } catch { /* closed */ } }, 15_000);
      try {
        const reading = await requestDeepSeekInterpretationStream(input.request, "structured", env.DEEPSEEK_API_KEY, env.DEEPSEEK_MODEL, (partial) => {
          const sections = partial.sections ?? [];
          send({ type: "partial", reading: free ? { title: partial.title, conclusion: partial.conclusion, keyPoints: partial.keyPoints, summary: partial.summary, sections: sections.slice(0, freeSectionCount(input.request.tool)), followUps: [] } : partial, more: free && sections.length > freeSectionCount(input.request.tool) });
        });
        const result = await finish(reading);
        send({ type: "done", status: result.status, body: result.body });
      } catch (cause) {
        const code = cause instanceof DeepSeekServiceError ? cause.code : "AI_UNAVAILABLE";
        try { await onFailure?.(); } catch { /* the claim stays; the member can retry tomorrow */ }
        const status = ["AI_NOT_CONFIGURED", "AI_AUTH_FAILED", "AI_REQUEST_REJECTED"].includes(code) ? 503 : 502;
        send({ type: "done", status, body: { error: "Interpretation service is unavailable", code } });
      } finally {
        clearInterval(keepAlive);
        try { controller.close(); } catch { /* already closed */ }
      }
    },
  });
  return new Response(body, { headers: { "content-type": "text/event-stream; charset=utf-8", "cache-control": "no-store, no-transform", "x-accel-buffering": "no" } });
}

async function debitAndUnlock(db: CommerceDatabase, memberId: string, draftId: string, mode: string, tool: string, locale: string, question: string, responseJson: string, cost: number, chart: string | null = null, subject: string | null = null) {
  const timestamp = now();
  const ledgerId = crypto.randomUUID();
  const historyId = crypto.randomUUID();
  const [debit] = await db.batch!([
    db.prepare("UPDATE members SET daily_credits = daily_credits - MIN(daily_credits, ?), credits = credits - MAX(0, ? - daily_credits), updated_at = ? WHERE id = ? AND credits + daily_credits >= ? AND NOT EXISTS (SELECT 1 FROM reading_drafts WHERE id = ? AND unlocked_by IS NOT NULL)")
      .bind(cost, cost, timestamp, memberId, cost, draftId),
    db.prepare("INSERT INTO credit_ledger (id, member_id, order_id, delta, balance_after, reason, created_at) SELECT ?, id, NULL, ?, credits + daily_credits, ?, ? FROM members WHERE id = ? AND changes() = 1")
      .bind(ledgerId, -cost, `interpretation:${tool}`, timestamp, memberId),
    db.prepare("INSERT INTO interpretation_history (id, member_id, tool, locale, mode, question, response_json, cost, created_at, chart_json, subject) SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? WHERE EXISTS (SELECT 1 FROM credit_ledger WHERE id = ?)")
      .bind(historyId, memberId, tool, locale, mode, question, responseJson, cost, timestamp, chart, subject, ledgerId),
    db.prepare("UPDATE reading_drafts SET unlocked_by = ?, unlocked_at = ?, history_id = ? WHERE id = ? AND unlocked_by IS NULL AND EXISTS (SELECT 1 FROM credit_ledger WHERE id = ?)")
      .bind(memberId, timestamp, historyId, draftId, ledgerId),
  ]);
  return { ok: (debit.meta?.changes ?? 0) === 1, historyId, timestamp };
}

async function unlockReading(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const payload = await requestJson(request);
  const draftId = typeof payload?.draftId === "string" && /^[a-zA-Z0-9-]{8,80}$/.test(payload.draftId) ? payload.draftId : "";
  if (!draftId) return error("Reading not found", 404);
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const draft = await db.prepare("SELECT * FROM reading_drafts WHERE id = ?").bind(draftId).first<DraftRecord>();
  if (!draft) return error("Reading not found", 404);
  const reading = JSON.parse(draft.response_json);
  if (draft.unlocked_by) {
    if (draft.unlocked_by !== access.session.sub) return error("Reading not found", 404);
    const member = await memberForSession(env, access.session);
    return json({ draftId, unlocked: true, response: reading, cost: 0, member: member ? serializeMember(member) : undefined });
  }
  const member = await refreshDailyCredits(db, access.session.sub, request);
  if (!member) return error("Authentication required", 401);
  const cost = numericValue(draft.cost);
  if (member.credits + numericValue(member.daily_credits) < cost) return json({ error: "Insufficient credits", code: "INSUFFICIENT_CREDITS", cost }, { status: 402 });
  let draftChart: unknown = null;
  try { draftChart = draft.chart_json ? JSON.parse(draft.chart_json) : null; } catch { draftChart = null; }
  const result = await debitAndUnlock(db, member.id, draftId, draft.mode, draft.tool, draft.locale, draft.question, draft.response_json, cost, draft.chart_json ?? null, chartSubject(draftChart));
  const { historyId, timestamp } = result;
  if (!result.ok) {
    const again = await db.prepare("SELECT unlocked_by FROM reading_drafts WHERE id = ?").bind(draftId).first<{ unlocked_by: string | null }>();
    if (again?.unlocked_by === member.id) return json({ draftId, unlocked: true, response: reading, cost: 0 });
    return json({ error: "Insufficient credits", code: "INSUFFICIENT_CREDITS", cost }, { status: 402 });
  }
  const updated = await memberForSession(env, access.session);
  return json({ draftId, unlocked: true, response: reading, cost, member: updated ? serializeMember(updated) : undefined, interpretation: { id: historyId, tool: draft.tool, locale: draft.locale, mode: draft.mode, question: draft.question, response: reading, cost, createdAt: timestamp } });
}

// ---------------------------------------------------------------------------------------------
// Administration: member groups, exclusive packages, credit grants and airdrops (request, then approve).
// ---------------------------------------------------------------------------------------------
async function adminAccess(request: Request, env: CommerceEnv, mutate = false): Promise<{ response: Response } | { session: Session; db: CommerceDatabase }> {
  if (mutate && !sameOrigin(request)) return { response: error("Invalid request origin", 403) };
  const access = await requireSession(request, env, "admin");
  if ("response" in access) return { response: access.response };
  const db = needsDatabase(env);
  if (db instanceof Response) return { response: db };
  return { session: access.session, db };
}

async function audit(db: CommerceDatabase, adminEmail: string | undefined, eventType: string, subjectId: string | null, detail: unknown) {
  await db.prepare("INSERT INTO admin_audit (id, admin_email, event_type, subject_id, detail, created_at) VALUES (?, ?, ?, ?, ?, ?)")
    .bind(crypto.randomUUID(), adminEmail ?? "", eventType, subjectId, JSON.stringify(detail), now()).run();
}

async function memberIdFromReference(db: CommerceDatabase, reference: unknown) {
  const value = typeof reference === "string" ? reference.trim() : "";
  if (!value) return null;
  const row = await db.prepare("SELECT id FROM members WHERE id = ? OR email = ? OR lower(wallet_address) = lower(?)").bind(value, value, value).first<{ id: string }>();
  return row?.id ?? null;
}

async function adminListGroups(request: Request, env: CommerceEnv) {
  const access = await adminAccess(request, env);
  if ("response" in access) return access.response;
  const { results } = await access.db.prepare("SELECT g.id, g.name, g.note, g.created_at, COUNT(m.member_id) AS member_count FROM member_groups g LEFT JOIN member_group_members m ON m.group_id = g.id GROUP BY g.id ORDER BY g.created_at DESC").all<Record<string, unknown>>();
  return json({ groups: results.map((row) => ({ id: row.id, name: row.name, note: row.note, createdAt: row.created_at, memberCount: numericValue(row.member_count as number) })) });
}

/** Create a group, or add/remove members: { name, note } | { groupId, add: [ref], remove: [ref] }. */
async function adminSaveGroup(request: Request, env: CommerceEnv) {
  const access = await adminAccess(request, env, true);
  if ("response" in access) return access.response;
  const { db, session } = access;
  const payload = await requestJson(request);
  const timestamp = now();
  let groupId = typeof payload?.groupId === "string" ? payload.groupId : "";
  if (!groupId) {
    const name = compactText(payload?.name, 60);
    if (name.length < 2) return error("Enter a group name of at least 2 characters");
    groupId = crypto.randomUUID();
    try {
      await db.prepare("INSERT INTO member_groups (id, name, note, created_at) VALUES (?, ?, ?, ?)").bind(groupId, name, compactText(payload?.note, 240) || null, timestamp).run();
    } catch { return error("A group with this name already exists", 409); }
  } else if (!await db.prepare("SELECT id FROM member_groups WHERE id = ?").bind(groupId).first()) return error("Group not found", 404);
  const missing: string[] = [];
  for (const reference of Array.isArray(payload?.add) ? payload.add.slice(0, 500) : []) {
    const memberId = await memberIdFromReference(db, reference);
    if (!memberId) { missing.push(String(reference)); continue; }
    await db.prepare("INSERT OR IGNORE INTO member_group_members (group_id, member_id, created_at) VALUES (?, ?, ?)").bind(groupId, memberId, timestamp).run();
  }
  for (const reference of Array.isArray(payload?.remove) ? payload.remove.slice(0, 500) : []) {
    const memberId = await memberIdFromReference(db, reference);
    if (memberId) await db.prepare("DELETE FROM member_group_members WHERE group_id = ? AND member_id = ?").bind(groupId, memberId).run();
  }
  await audit(db, session.email, "group_update", groupId, { add: payload?.add ?? [], remove: payload?.remove ?? [] });
  return json({ groupId, missing });
}

async function adminListPackages(request: Request, env: CommerceEnv) {
  const access = await adminAccess(request, env);
  if ("response" in access) return access.response;
  const { results } = await access.db.prepare("SELECT p.*, m.email AS member_email, g.name AS group_name FROM exclusive_packages p LEFT JOIN members m ON m.id = p.member_id LEFT JOIN member_groups g ON g.id = p.group_id ORDER BY p.created_at DESC").all<Record<string, unknown>>();
  return json({ packages: results.map((row) => ({ id: row.id, name: row.name, credits: numericValue(row.credits as number), priceUsdt: row.price_usdt, memberId: row.member_id, memberEmail: row.member_email, groupId: row.group_id, groupName: row.group_name, active: Boolean(row.active), note: row.note, createdAt: row.created_at })) });
}

/** Create or toggle an exclusive package: { name, credits, priceUsdt, member | groupId, note } | { id, active }. */
async function adminSavePackage(request: Request, env: CommerceEnv) {
  const access = await adminAccess(request, env, true);
  if ("response" in access) return access.response;
  const { db, session } = access;
  const payload = await requestJson(request);
  if (typeof payload?.id === "string") {
    await db.prepare("UPDATE exclusive_packages SET active = ? WHERE id = ?").bind(payload.active ? 1 : 0, payload.id).run();
    await audit(db, session.email, "package_toggle", payload.id, { active: Boolean(payload.active) });
    return json({ ok: true });
  }
  const name = compactText(payload?.name, 80);
  const credits = typeof payload?.credits === "number" && Number.isInteger(payload.credits) ? payload.credits : 0;
  const price = typeof payload?.priceUsdt === "string" && /^\d{1,6}(\.\d{1,2})?$/.test(payload.priceUsdt) ? payload.priceUsdt : "";
  if (name.length < 2 || credits <= 0 || credits > 1_000_000 || !price) return error("Enter a name, whole-number credits and a USDT price");
  const memberId = payload?.member ? await memberIdFromReference(db, payload.member) : null;
  const groupId = typeof payload?.groupId === "string" && payload.groupId ? payload.groupId : null;
  if (!memberId && !groupId) return error("Choose a member or a group for this package");
  if (payload?.member && !memberId) return error("Member not found", 404);
  const id = `x-${crypto.randomUUID()}`;
  await db.prepare("INSERT INTO exclusive_packages (id, name, credits, price_usdt, member_id, group_id, active, note, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?)")
    .bind(id, name, credits, price, memberId, groupId, compactText(payload?.note, 240) || null, session.email ?? "", now()).run();
  await audit(db, session.email, "package_create", id, { name, credits, price, memberId, groupId });
  return json({ id }, { status: 201 });
}

async function exclusivePackagesFor(db: CommerceDatabase, memberId: string) {
  const { results } = await db.prepare("SELECT id, name, credits, price_usdt FROM exclusive_packages WHERE active = 1 AND (member_id = ? OR group_id IN (SELECT group_id FROM member_group_members WHERE member_id = ?)) ORDER BY created_at DESC")
    .bind(memberId, memberId).all<{ id: string; name: string; credits: number; price_usdt: string }>();
  return results;
}

async function memberExclusivePackages(request: Request, env: CommerceEnv) {
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const packages = await exclusivePackagesFor(db, access.session.sub);
  return json({ packages: packages.map((item) => ({ id: item.id, name: item.name, credits: numericValue(item.credits), usdt: item.price_usdt })) });
}

async function adminListGrants(request: Request, env: CommerceEnv) {
  const access = await adminAccess(request, env);
  if ("response" in access) return access.response;
  const { results } = await access.db.prepare("SELECT r.*, m.email AS member_email, g.name AS group_name FROM credit_grant_requests r LEFT JOIN members m ON m.id = r.member_id LEFT JOIN member_groups g ON g.id = r.group_id ORDER BY r.created_at DESC LIMIT 200").all<Record<string, unknown>>();
  return json({ grants: results.map((row) => ({ id: row.id, target: row.target ?? "single", listSize: typeof row.member_list === "string" ? (JSON.parse(row.member_list) as string[]).length : null, memberId: row.member_id, memberEmail: row.member_email, groupId: row.group_id, groupName: row.group_name, credits: numericValue(row.credits as number), reason: row.reason, status: row.status, requestedBy: row.requested_by, reviewedBy: row.reviewed_by, reviewNote: row.review_note, createdAt: row.created_at, reviewedAt: row.reviewed_at })) });
}

async function adminRequestGrant(request: Request, env: CommerceEnv) {
  const access = await adminAccess(request, env, true);
  if ("response" in access) return access.response;
  const { db, session } = access;
  const payload = await requestJson(request);
  const credits = typeof payload?.credits === "number" && Number.isInteger(payload.credits) ? payload.credits : 0;
  const reason = compactText(payload?.reason, 240);
  if (credits <= 0 || credits > 100_000) return error("Enter a whole number of credits between 1 and 100000");
  if (reason.length < 3) return error("Enter a reason of at least 3 characters");
  // Airdrop: target "all" members, or a list of member emails / ids (up to 2,000) in one request.
  const target = payload?.target === "all" ? "all" : Array.isArray(payload?.members) ? "list" : "single";
  let memberList: string[] | null = null;
  let missing: string[] = [];
  if (target === "list") {
    const references = (payload!.members as unknown[]).filter((item): item is string => typeof item === "string" && item.trim().length > 0).slice(0, 2000);
    const lookups = await Promise.all(references.map((reference) => memberIdFromReference(db, reference)));
    missing = references.filter((_, index) => !lookups[index]).slice(0, 50);
    memberList = [...new Set(lookups.filter((id): id is string => Boolean(id)))];
    if (!memberList.length) return error("Member not found", 404);
  }
  const memberId = target === "single" && payload?.member ? await memberIdFromReference(db, payload.member) : null;
  const groupId = target === "single" && typeof payload?.groupId === "string" && payload.groupId ? payload.groupId : null;
  if (target === "single" && !memberId && !groupId) return error("Choose a member or a group");
  if (target === "single" && payload?.member && !memberId) return error("Member not found", 404);
  const id = crypto.randomUUID();
  await db.prepare("INSERT INTO credit_grant_requests (id, member_id, group_id, credits, reason, status, requested_by, created_at, target, member_list) VALUES (?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?)")
    .bind(id, memberId, groupId, credits, reason, session.email ?? "", now(), target, memberList ? JSON.stringify(memberList) : null).run();
  await audit(db, session.email, "grant_request", id, { memberId, groupId, target, members: memberList?.length ?? null, credits, reason });
  return json({ id, status: "pending", members: target === "all" ? "all" : memberList?.length ?? 1, ...(missing.length ? { missing } : {}) }, { status: 201 });
}

async function adminDecideGrant(request: Request, env: CommerceEnv, grantId: string) {
  const access = await adminAccess(request, env, true);
  if ("response" in access) return access.response;
  const { db, session } = access;
  const payload = await requestJson(request);
  const decision = payload?.decision === "approve" ? "approved" : payload?.decision === "reject" ? "rejected" : null;
  if (!decision) return error("Choose approve or reject");
  const grant = await db.prepare("SELECT * FROM credit_grant_requests WHERE id = ?").bind(grantId).first<{ id: string; member_id: string | null; group_id: string | null; credits: number; reason: string; status: string; requested_by: string; target?: string; member_list?: string | null }>();
  if (!grant) return error("Grant request not found", 404);
  if (grant.status !== "pending") return error("This request has already been decided", 409);
  // With more than one configured administrator, the approver must differ from the requester.
  // One administrator can request and approve a grant or airdrop; both steps are kept in the audit log.
  const timestamp = now();
  const note = compactText(payload?.note, 240) || null;
  const claimed = await db.prepare("UPDATE credit_grant_requests SET status = ?, reviewed_by = ?, review_note = ?, reviewed_at = ? WHERE id = ? AND status = 'pending'")
    .bind(decision, session.email ?? "", note, timestamp, grant.id).run();
  if ((claimed.meta?.changes ?? 0) !== 1) return error("This request has already been decided", 409);
  let credited = 0;
  if (decision === "approved") {
    const memberIds = grant.target === "all"
      ? (await db.prepare("SELECT id AS member_id FROM members WHERE role = 'member'").all<{ member_id: string }>()).results.map((row) => row.member_id)
      : grant.target === "list" && grant.member_list
        ? (JSON.parse(grant.member_list) as string[])
        : grant.member_id ? [grant.member_id] : (await db.prepare("SELECT member_id FROM member_group_members WHERE group_id = ?").bind(grant.group_id).all<{ member_id: string }>()).results.map((row) => row.member_id);
    for (const memberId of memberIds) {
      const ledgerId = crypto.randomUUID();
      await db.batch!([
        db.prepare("UPDATE members SET credits = credits + ?, updated_at = ? WHERE id = ?").bind(grant.credits, timestamp, memberId),
        db.prepare("INSERT INTO credit_ledger (id, member_id, order_id, delta, balance_after, reason, created_at) SELECT ?, id, NULL, ?, credits + daily_credits, ?, ? FROM members WHERE id = ? AND changes() = 1")
          .bind(ledgerId, grant.credits, `admin_grant:${grant.id}`, timestamp, memberId),
      ]);
      credited += 1;
    }
  }
  await audit(db, session.email, `grant_${decision}`, grant.id, { credits: grant.credits, members: credited, note });
  return json({ id: grant.id, status: decision, membersCredited: credited });
}

// ---------------------------------------------------------------------------------------------
// Free lecture videos: public list, administrator management. Video files are hosted externally
// (YouTube / Vimeo / any https MP4 or HLS URL); the site only stores the link.
// ---------------------------------------------------------------------------------------------
const lectureLocales = ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"];
type LectureRow = { id: string; title_json: string; summary_json: string; video_url: string; duration_minutes: number | null; category: string; sort_order: number; published: number; created_at: string; media_file?: string | null; members_only?: number };
const mediaFilePattern = /^[a-f0-9-]{36}\.(mp4|webm|m4v|mov)$/;
function localizedMap(value: unknown, maximum: number) {
  const source = record(value) ?? {};
  return Object.fromEntries(lectureLocales.flatMap((locale) => { const text = compactText(source[locale], maximum); return text ? [[locale, text]] : []; }));
}
function serializeLecture(row: LectureRow) {
  return { id: row.id, title: JSON.parse(row.title_json), summary: JSON.parse(row.summary_json || "{}"), videoUrl: row.video_url || null, mediaFile: row.media_file ?? null, mediaUrl: row.media_file ? `/api/media/${row.media_file}` : null, membersOnly: row.members_only === undefined ? true : Boolean(row.members_only), durationMinutes: row.duration_minutes, category: row.category, sortOrder: row.sort_order, published: Boolean(row.published), createdAt: row.created_at };
}
/** Published lectures. Members-only lectures are listed for everyone, but their video addresses go only to signed-in members. */
async function publicLectures(request: Request, env: CommerceEnv) {
  const db = database(env);
  if (!db) return json({ lectures: [] });
  const { results } = await db.prepare("SELECT * FROM lectures WHERE published = 1 ORDER BY sort_order ASC, created_at DESC LIMIT 200").all<LectureRow>();
  const session = await readSession(request, env.SESSION_SECRET);
  const viewer = session?.role === "member" || session?.role === "admin";
  const lectures = results.map((row) => {
    const lecture = serializeLecture(row);
    const locked = lecture.membersOnly && !viewer;
    return locked ? { ...lecture, videoUrl: null, mediaUrl: null, mediaFile: null, locked: true } : { ...lecture, locked: false };
  });
  return json({ lectures, signedIn: viewer }, { headers: { "cache-control": "private, no-store" } });
}
async function adminListLectures(request: Request, env: CommerceEnv) {
  const access = await adminAccess(request, env);
  if ("response" in access) return access.response;
  const { results } = await access.db.prepare("SELECT * FROM lectures ORDER BY sort_order ASC, created_at DESC").all<LectureRow>();
  return json({ lectures: results.map(serializeLecture) });
}
/** Create or update: { id?, title: {locale: text}, summary, videoUrl, durationMinutes, category, sortOrder, published }. */
async function adminSaveLecture(request: Request, env: CommerceEnv) {
  const access = await adminAccess(request, env, true);
  if ("response" in access) return access.response;
  const { db, session } = access;
  const payload = await requestJson(request);
  const title = localizedMap(payload?.title, 160);
  const summary = localizedMap(payload?.summary, 600);
  const videoUrl = typeof payload?.videoUrl === "string" && /^https:\/\/[^\s]{6,500}$/.test(payload.videoUrl.trim()) ? payload.videoUrl.trim() : "";
  const mediaFile = typeof payload?.mediaFile === "string" && mediaFilePattern.test(payload.mediaFile) ? payload.mediaFile : null;
  const membersOnly = payload?.membersOnly === false ? 0 : 1;
  if (!title.en && !title["zh-Hans"]) return error("Enter at least an English or Simplified Chinese title");
  if (!videoUrl && !mediaFile) return error("Upload a video or enter an https video link");
  const duration = typeof payload?.durationMinutes === "number" && payload.durationMinutes > 0 && payload.durationMinutes < 1000 ? Math.round(payload.durationMinutes) : null;
  const category = compactText(payload?.category, 40) || "foundation";
  const sortOrder = typeof payload?.sortOrder === "number" ? Math.round(payload.sortOrder) : 0;
  const published = payload?.published ? 1 : 0;
  const timestamp = now();
  const existingId = typeof payload?.id === "string" && /^[a-zA-Z0-9-]{8,80}$/.test(payload.id) ? payload.id : "";
  if (existingId) {
    const updated = await db.prepare("UPDATE lectures SET title_json = ?, summary_json = ?, video_url = ?, media_file = ?, members_only = ?, duration_minutes = ?, category = ?, sort_order = ?, published = ?, updated_at = ? WHERE id = ?")
      .bind(JSON.stringify(title), JSON.stringify(summary), videoUrl, mediaFile, membersOnly, duration, category, sortOrder, published, timestamp, existingId).run();
    if ((updated.meta?.changes ?? 0) !== 1) return error("Lecture not found", 404);
    await audit(db, session.email, "lecture_update", existingId, { published });
    return json({ id: existingId });
  }
  const id = crypto.randomUUID();
  await db.prepare("INSERT INTO lectures (id, title_json, summary_json, video_url, media_file, members_only, duration_minutes, category, sort_order, published, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
    .bind(id, JSON.stringify(title), JSON.stringify(summary), videoUrl, mediaFile, membersOnly, duration, category, sortOrder, published, timestamp, timestamp).run();
  await audit(db, session.email, "lecture_create", id, { published });
  return json({ id }, { status: 201 });
}

// ---------------------------------------------------------------------------------------------
// 器物坊 (Workshop): catalogue, orders paid by reviewed USDT transfer, administrator fulfilment.
// ---------------------------------------------------------------------------------------------
type ProductRow = { id: string; name_json: string; description_json: string; price_usdt: string; image_url: string | null; stock: number; active: number; sort_order: number; created_at: string };
type ShopOrderRow = { id: string; member_id: string; member_email?: string | null; items_json: string; total_usdt: string; network: string; transaction_hash: string; shipping_json: string; status: string; tracking: string | null; admin_note: string | null; created_at: string; updated_at: string };
const usdtCents = (value: string) => Math.round(Number(value) * 100);
const centsToUsdt = (cents: number) => (cents / 100).toFixed(2);
function serializeProduct(row: ProductRow) {
  return { id: row.id, name: JSON.parse(row.name_json), description: JSON.parse(row.description_json || "{}"), priceUsdt: row.price_usdt, imageUrl: row.image_url, stock: numericValue(row.stock), active: Boolean(row.active), sortOrder: numericValue(row.sort_order) };
}
function serializeShopOrder(row: ShopOrderRow) {
  return { id: row.id, memberEmail: row.member_email ?? undefined, items: JSON.parse(row.items_json), totalUsdt: row.total_usdt, network: row.network, transactionHash: row.transaction_hash, shipping: JSON.parse(row.shipping_json), status: row.status, tracking: row.tracking, adminNote: row.admin_note, createdAt: row.created_at, updatedAt: row.updated_at };
}
async function shopProducts(env: CommerceEnv) {
  const db = database(env);
  if (!db) return json({ products: [] });
  const { results } = await db.prepare("SELECT * FROM shop_products WHERE active = 1 ORDER BY sort_order ASC, created_at DESC").all<ProductRow>();
  return json({ products: results.map(serializeProduct), networks: paymentNetworks.map((network) => ({ id: network.id, label: network.label, address: network.address, qrImage: network.qrImage })) });
}
async function shopMemberOrders(request: Request, env: CommerceEnv) {
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const { results } = await db.prepare("SELECT * FROM shop_orders WHERE member_id = ? ORDER BY created_at DESC LIMIT 100").bind(access.session.sub).all<ShopOrderRow>();
  return json({ orders: results.map(serializeShopOrder) });
}
async function shopCreateOrder(request: Request, env: CommerceEnv) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const payload = await requestJson(request);
  const requested = Array.isArray(payload?.items) ? payload.items.slice(0, 20) : [];
  const network = typeof payload?.network === "string" ? paymentNetworks.find((item) => item.id === payload.network) : undefined;
  const transactionHash = validateTransactionHash(payload?.transactionHash);
  const shippingInput = record(payload?.shipping);
  const shipping = { name: compactText(shippingInput?.name, 80), phone: compactText(shippingInput?.phone, 40), country: compactText(shippingInput?.country, 60), address: compactText(shippingInput?.address, 300), postcode: compactText(shippingInput?.postcode, 20), note: compactText(shippingInput?.note, 300) };
  if (!requested.length) return error("Your cart is empty");
  if (!network) return error("Choose a payment network");
  if (!transactionHash) return error("Enter a valid transaction hash");
  const hashProblem = hashFormatError(network.id, transactionHash);
  if (hashProblem) return error(hashProblem);
  if (!shipping.name || !shipping.phone || !shipping.country || !shipping.address) return error("Enter the recipient name, phone, country and address");
  const items: Array<{ productId: string; name: unknown; quantity: number; priceUsdt: string }> = [];
  let totalCents = 0;
  for (const entry of requested) {
    const item = record(entry);
    const productId = typeof item?.productId === "string" ? item.productId : "";
    const quantity = typeof item?.quantity === "number" && Number.isInteger(item.quantity) ? item.quantity : 0;
    if (!productId || quantity < 1 || quantity > 20) return error("Invalid cart item");
    const product = await db.prepare("SELECT * FROM shop_products WHERE id = ? AND active = 1").bind(productId).first<ProductRow>();
    if (!product) return error("A product in your cart is no longer available", 409);
    if (numericValue(product.stock) < quantity) return error("Not enough stock for a product in your cart", 409);
    items.push({ productId, name: JSON.parse(product.name_json), quantity, priceUsdt: product.price_usdt });
    totalCents += usdtCents(product.price_usdt) * quantity;
  }
  if (await db.prepare("SELECT id FROM shop_orders WHERE transaction_hash = ?").bind(transactionHash).first()) return error("This transaction hash has already been submitted", 409);
  if (await db.prepare("SELECT id FROM payment_orders WHERE transaction_hash = ?").bind(transactionHash).first()) return error("This transaction hash has already been submitted", 409);
  const id = crypto.randomUUID();
  const timestamp = now();
  // Reserve stock together with the order so two buyers cannot take the last item.
  const statements = items.map((item) => db.prepare("UPDATE shop_products SET stock = stock - ?, updated_at = ? WHERE id = ? AND stock >= ?").bind(item.quantity, timestamp, item.productId, item.quantity));
  try {
    const results = await db.batch!([...statements, db.prepare("INSERT INTO shop_orders (id, member_id, items_json, total_usdt, network, transaction_hash, shipping_json, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)")
      .bind(id, access.session.sub, JSON.stringify(items), centsToUsdt(totalCents), network.id, transactionHash, JSON.stringify(shipping), timestamp, timestamp)]);
    if (results.slice(0, statements.length).some((result) => (result.meta?.changes ?? 0) !== 1)) {
      // Roll back any partial reservation and the order row.
      for (const item of items) await db.prepare("UPDATE shop_products SET stock = stock + ? WHERE id = ?").bind(item.quantity, item.productId).run();
      await db.prepare("DELETE FROM shop_orders WHERE id = ?").bind(id).run();
      return error("Not enough stock for a product in your cart", 409);
    }
  } catch { return error("This transaction hash has already been submitted", 409); }
  const order = await db.prepare("SELECT * FROM shop_orders WHERE id = ?").bind(id).first<ShopOrderRow>();
  return json({ order: order ? serializeShopOrder(order) : { id } }, { status: 201 });
}
async function adminShopProducts(request: Request, env: CommerceEnv) {
  const access = await adminAccess(request, env);
  if ("response" in access) return access.response;
  const { results } = await access.db.prepare("SELECT * FROM shop_products ORDER BY sort_order ASC, created_at DESC").all<ProductRow>();
  return json({ products: results.map(serializeProduct) });
}
async function adminSaveShopProduct(request: Request, env: CommerceEnv) {
  const access = await adminAccess(request, env, true);
  if ("response" in access) return access.response;
  const { db, session } = access;
  const payload = await requestJson(request);
  const name = localizedMap(payload?.name, 120);
  const description = localizedMap(payload?.description, 1200);
  const price = typeof payload?.priceUsdt === "string" && /^\d{1,6}(\.\d{1,2})?$/.test(payload.priceUsdt) ? payload.priceUsdt : "";
  const imageUrl = typeof payload?.imageUrl === "string" && /^(https:\/\/|\/)[^\s]{1,500}$/.test(payload.imageUrl) ? payload.imageUrl : null;
  const stock = typeof payload?.stock === "number" && Number.isInteger(payload.stock) && payload.stock >= 0 ? payload.stock : 0;
  const sortOrder = typeof payload?.sortOrder === "number" ? Math.round(payload.sortOrder) : 0;
  const active = payload?.active === false ? 0 : 1;
  if (!name.en && !name["zh-Hans"]) return error("Enter at least an English or Simplified Chinese name");
  if (!price) return error("Enter a USDT price");
  const timestamp = now();
  const id = typeof payload?.id === "string" && /^[a-zA-Z0-9-]{8,80}$/.test(payload.id) ? payload.id : "";
  if (id) {
    const updated = await db.prepare("UPDATE shop_products SET name_json = ?, description_json = ?, price_usdt = ?, image_url = ?, stock = ?, active = ?, sort_order = ?, updated_at = ? WHERE id = ?")
      .bind(JSON.stringify(name), JSON.stringify(description), price, imageUrl, stock, active, sortOrder, timestamp, id).run();
    if ((updated.meta?.changes ?? 0) !== 1) return error("Product not found", 404);
    await audit(db, session.email, "shop_product_update", id, { price, stock, active });
    return json({ id });
  }
  const newId = crypto.randomUUID();
  await db.prepare("INSERT INTO shop_products (id, name_json, description_json, price_usdt, image_url, stock, active, sort_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
    .bind(newId, JSON.stringify(name), JSON.stringify(description), price, imageUrl, stock, active, sortOrder, timestamp, timestamp).run();
  await audit(db, session.email, "shop_product_create", newId, { price, stock });
  return json({ id: newId }, { status: 201 });
}
async function adminShopOrders(request: Request, env: CommerceEnv) {
  const access = await adminAccess(request, env);
  if ("response" in access) return access.response;
  const { results } = await access.db.prepare("SELECT o.*, m.email AS member_email FROM shop_orders o LEFT JOIN members m ON m.id = o.member_id ORDER BY o.created_at DESC LIMIT 300").all<ShopOrderRow>();
  return json({ orders: results.map(serializeShopOrder) });
}
/** { status: paid | shipped | rejected, tracking?, note? } — rejecting a pending order returns its stock. */
async function adminUpdateShopOrder(request: Request, env: CommerceEnv, orderId: string) {
  const access = await adminAccess(request, env, true);
  if ("response" in access) return access.response;
  const { db, session } = access;
  const payload = await requestJson(request);
  const status = ["paid", "shipped", "rejected"].includes(String(payload?.status)) ? String(payload?.status) : "";
  if (!status) return error("Choose paid, shipped or rejected");
  const order = await db.prepare("SELECT * FROM shop_orders WHERE id = ?").bind(orderId).first<ShopOrderRow>();
  if (!order) return error("Order not found", 404);
  const allowed: Record<string, string[]> = { pending: ["paid", "rejected"], paid: ["shipped", "rejected"], shipped: [], rejected: [] };
  if (!allowed[order.status]?.includes(status)) return error("This status change is not allowed", 409);
  const timestamp = now();
  const updated = await db.prepare("UPDATE shop_orders SET status = ?, tracking = COALESCE(?, tracking), admin_note = COALESCE(?, admin_note), updated_at = ? WHERE id = ? AND status = ?")
    .bind(status, compactText(payload?.tracking, 120) || null, compactText(payload?.note, 300) || null, timestamp, order.id, order.status).run();
  if ((updated.meta?.changes ?? 0) !== 1) return error("This order was changed by someone else", 409);
  if (status === "rejected") for (const item of JSON.parse(order.items_json) as Array<{ productId: string; quantity: number }>) await db.prepare("UPDATE shop_products SET stock = stock + ? WHERE id = ?").bind(item.quantity, item.productId).run();
  await audit(db, session.email, `shop_order_${status}`, order.id, { tracking: payload?.tracking ?? null });
  return json({ id: order.id, status });
}

async function adminOrders(request: Request, env: CommerceEnv) {
  const access = await requireSession(request, env, "admin");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const result = await db
    .prepare("SELECT payment_orders.id, payment_orders.package_id, payment_orders.amount_usdt, payment_orders.settlement_currency, payment_orders.credits, payment_orders.network, payment_orders.transaction_hash, payment_orders.status, payment_orders.submitted_at, payment_orders.reviewed_at, payment_orders.reviewed_by, payment_orders.review_note, payment_orders.buyer_address, payment_orders.chain_id, payment_orders.fee_wei, payment_orders.block_number, payment_orders.member_id, members.email AS member_email, members.wallet_address AS member_wallet FROM payment_orders JOIN members ON members.id = payment_orders.member_id ORDER BY CASE payment_orders.status WHEN 'pending' THEN 0 ELSE 1 END, payment_orders.submitted_at DESC LIMIT 100")
    .all<OrderRecord>();
  return json({ orders: result.results.map(serializeOrder) });
}

async function adminOverview(request: Request, env: CommerceEnv) {
  const access = await requireSession(request, env, "admin");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const [memberTotals, pendingOrders, invitationTotals, invitationCredits] = await Promise.all([
    db.prepare("SELECT COUNT(*) AS member_count, COALESCE(SUM(credits), 0) AS outstanding_credits FROM members").all<AdminOverviewRecord>(),
    db.prepare("SELECT COUNT(*) AS pending_order_count FROM payment_orders WHERE status = 'pending'").all<AdminOverviewRecord>(),
    db.prepare("SELECT COUNT(*) AS invitation_count FROM invitation_purchase_rewards").all<AdminOverviewRecord>(),
    db.prepare("SELECT COALESCE(SUM(delta), 0) AS invitation_credits FROM credit_ledger WHERE reason = 'invitation_purchase'").all<AdminOverviewRecord>(),
  ]);
  const members = memberTotals.results[0] ?? {};
  const orders = pendingOrders.results[0] ?? {};
  const invitations = invitationTotals.results[0] ?? {};
  const rewards = invitationCredits.results[0] ?? {};
  return json({
    overview: {
      memberCount: numericValue(members.member_count),
      outstandingCredits: numericValue(members.outstanding_credits),
      pendingOrderCount: numericValue(orders.pending_order_count),
      invitationCount: numericValue(invitations.invitation_count),
      invitationCredits: numericValue(rewards.invitation_credits),
    },
  });
}

async function adminInterpretations(request: Request, env: CommerceEnv) {
  const access = await requireSession(request, env, "admin");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const result = await db.prepare("SELECT interpretation_history.id, interpretation_history.tool, interpretation_history.locale, interpretation_history.mode, interpretation_history.question, interpretation_history.response_json, interpretation_history.cost, interpretation_history.created_at, members.email AS member_email, members.wallet_address AS member_wallet FROM interpretation_history JOIN members ON members.id = interpretation_history.member_id ORDER BY interpretation_history.created_at DESC LIMIT 100").all<InterpretationHistoryRecord & { member_email: string | null; member_wallet: string | null }>();
  return json({ interpretations: result.results.flatMap((item) => {
    try { return [{ id: item.id, member: maskIdentity(item.member_email, item.member_wallet), tool: item.tool, locale: item.locale, mode: item.mode, question: item.question, response: JSON.parse(item.response_json), cost: numericValue(item.cost), createdAt: item.created_at }]; }
    catch { return []; }
  }) });
}

async function adminMembers(request: Request, env: CommerceEnv) {
  const access = await requireSession(request, env, "admin");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const search = new URL(request.url).searchParams.get("search")?.trim().slice(0, 120) ?? "";
  const result = await db
    .prepare("SELECT id, email, wallet_address, credits, invite_code, invited_by_member_id, created_at, updated_at FROM members WHERE email LIKE ? OR wallet_address LIKE ? ORDER BY created_at DESC LIMIT 100")
    .bind(`%${search}%`, `%${search}%`)
    .all<AdminMemberRecord>();
  return json({ members: result.results.map(serializeAdminMember) });
}

async function adminInvitations(request: Request, env: CommerceEnv) {
  const access = await requireSession(request, env, "admin");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const result = await db
    .prepare("SELECT inviter.id AS inviter_id, inviter.email AS inviter_email, inviter.wallet_address AS inviter_wallet, inviter.invite_code AS invite_code, invitee.id AS invitee_id, invitee.email AS invitee_email, invitee.wallet_address AS invitee_wallet, rewards.awarded_at AS joined_at, 5 AS inviter_reward, 5 AS invitee_reward FROM invitation_purchase_rewards AS rewards JOIN members AS invitee ON invitee.id = rewards.invitee_member_id JOIN members AS inviter ON inviter.id = rewards.inviter_member_id ORDER BY rewards.awarded_at DESC LIMIT 100")
    .all<InvitationRecord>();
  return json({ invitations: result.results.map(serializeInvitation) });
}

async function adminLedger(request: Request, env: CommerceEnv) {
  const access = await requireSession(request, env, "admin");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  const result = await db
    .prepare("SELECT credit_ledger.id, credit_ledger.member_id, members.email AS member_email, members.wallet_address AS member_wallet, credit_ledger.order_id, credit_ledger.delta, credit_ledger.balance_after, credit_ledger.reason, credit_ledger.created_at FROM credit_ledger JOIN members ON members.id = credit_ledger.member_id ORDER BY credit_ledger.created_at DESC LIMIT 150")
    .all<LedgerRecord>();
  return json({ entries: result.results.map(serializeLedgerEntry) });
}

async function adjustMemberCredits(request: Request, env: CommerceEnv, memberId: string) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const access = await requireSession(request, env, "admin");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  if (!/^[a-zA-Z0-9-]{3,80}$/.test(memberId)) return error("Invalid member reference");
  const payload = await requestJson(request);
  const delta = typeof payload?.delta === "number" && Number.isInteger(payload.delta) ? payload.delta : 0;
  const reason = typeof payload?.reason === "string" ? payload.reason.trim().slice(0, 240) : "";
  if (!delta || Math.abs(delta) > 10_000) return error("Enter a whole-number credit adjustment between -10000 and 10000");
  if (reason.length < 3) return error("Enter an adjustment note of at least 3 characters");
  const member = await db
    .prepare("SELECT id, email, wallet_address, credits, invite_code FROM members WHERE id = ?")
    .bind(memberId)
    .first<MemberRecord>();
  if (!member) return error("Member not found", 404);
  const timestamp = now();
  const update = await db
    .prepare("UPDATE members SET credits = credits + ?, updated_at = ? WHERE id = ? AND credits + ? >= 0")
    .bind(delta, timestamp, member.id, delta)
    .run();
  if ((update.meta?.changes ?? 0) !== 1) return error("Credit adjustment cannot reduce balance below zero", 409);
  const updatedMember = await db
    .prepare("SELECT id, email, wallet_address, credits, invite_code FROM members WHERE id = ?")
    .bind(member.id)
    .first<MemberRecord>();
  if (!updatedMember) return error("Member not found", 404);
  await db
    .prepare("INSERT INTO credit_ledger (id, member_id, order_id, delta, balance_after, reason, created_at) VALUES (?, ?, NULL, ?, ?, 'admin_adjustment', ?)")
    .bind(crypto.randomUUID(), updatedMember.id, delta, updatedMember.credits, timestamp)
    .run();
  await db
    .prepare("INSERT INTO admin_audit (id, admin_email, event_type, subject_id, detail, created_at) VALUES (?, ?, 'credit_adjustment', ?, ?, ?)")
    .bind(crypto.randomUUID(), access.session.email, updatedMember.id, JSON.stringify({ delta, reason }), timestamp)
    .run();
  return json({ member: serializeMember(updatedMember) });
}

async function reviewOrder(request: Request, env: CommerceEnv, orderId: string) {
  if (!sameOrigin(request)) return error("Invalid request origin", 403);
  const access = await requireSession(request, env, "admin");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  if (!/^[a-zA-Z0-9-]{8,80}$/.test(orderId)) return error("Invalid order reference");
  const payload = await requestJson(request);
  const decision = payload?.decision;
  if (decision !== "approve" && decision !== "reject") return error("Choose approve or reject");
  const note = typeof payload?.note === "string" ? payload.note.trim().slice(0, 400) : null;
  const timestamp = now();
  const status = decision === "approve" ? "approved" : "rejected";
  const update = await db
    .prepare("UPDATE payment_orders SET status = ?, reviewed_at = ?, reviewed_by = ?, review_note = ? WHERE id = ? AND status = 'pending'")
    .bind(status, timestamp, access.session.email, note, orderId)
    .run();
  if ((update.meta?.changes ?? 0) !== 1) return error("This order is no longer pending", 409);
  if (decision === "approve") {
    const order = await db.prepare("SELECT member_id FROM payment_orders WHERE id = ?").bind(orderId).first<{ member_id: string }>();
    if (order) await rewardInvitationPurchase(db, order.member_id, orderId, timestamp);
  }
  await db
    .prepare("INSERT INTO admin_audit (id, admin_email, event_type, subject_id, detail, created_at) VALUES (?, ?, ?, ?, ?, ?)")
    .bind(crypto.randomUUID(), access.session.email, `payment_${status}`, orderId, note, timestamp)
    .run();
  return json({ ok: true, status });
}

const EXTRA_COINS = ["CAKE", "BTCB", "WETH", "USD1", "XRP", "SOL", "DOGE", "LINK", "UNI", "AAVE", "XAUt", "SHIB"];
function checkoutTokenList(env: CommerceEnv) {
  const wanted = (env.USDC_CHECKOUT_TOKENS ?? "").split(",").map((item) => item.trim().toUpperCase()).filter(Boolean);
  return EXTRA_COINS.filter((coin) => wanted.includes(coin.toUpperCase()));
}
function checkoutConfig(env: CommerceEnv) {
  const contractAddress = configuredCreditStoreAddress(env);
  const chain = configuredChain(env);
  const usdtAddress = normalizeAddress(chain.usdtAddress);
  const usdcCheckoutAddress = chain.id === 56 && env.USDC_CHECKOUT_ENABLED === "true" ? configuredUsdcCheckoutAddress(env) : null;
  return json({
    chainId: chain.id,
    chainHexId: chain.hexId,
    chainName: chain.name,
    nativeSymbol: chain.nativeSymbol,
    rpcUrls: chain.rpcUrls,
    explorerUrl: chain.explorerUrl,
    testnet: chain.testnet,
    usdtAddress,
    contractAddress,
    platformFeeWei: platformFeeWei.toString(),
    confirmations: chain.confirmations,
    enabled: contractAddress !== null && usdtAddress !== null,
    usdcCheckoutAddress,
    usdcOnly: usdcCheckoutAddress !== null && env.USDC_CHECKOUT_REPLACE_LEGACY === "true",
    // More coins on BNB Chain: only after MultiCoinCheckout is deployed and each coin is allowed there (setToken).
    checkoutTokens: usdcCheckoutAddress ? checkoutTokenList(env) : [],
    multichainWalletLinkEnabled: env.MULTICHAIN_WALLET_LINK_ENABLED === "true" && Boolean(env.SITE_URL),
  });
}

async function multichainWalletLink(request: Request, env: CommerceEnv, action: "challenge" | "verify") {
  if (env.MULTICHAIN_WALLET_LINK_ENABLED !== "true") return error("Wallet linking is not available", 503);
  let origin: string;
  try { origin = new URL(env.SITE_URL ?? "").origin; } catch { return error("Wallet linking is not configured", 503); }
  if (!request.headers.get("origin") || request.headers.get("origin") !== origin || currentOrigin(request) !== origin) return error("Invalid request origin", 403);
  const access = await requireSession(request, env, "member");
  if ("response" in access) return access.response;
  const db = needsDatabase(env);
  if (db instanceof Response) return db;
  if (!db.batch) return error("Wallet linking is not configured", 503);
  const member = await memberForSession(env, access.session);
  if (!member) return error("Authentication required", 401);
  const payload = await requestJson(request);
  const nowSeconds = Math.floor(Date.now() / 1000);
  if (action === "challenge") {
    if ((payload?.chain !== "solana" && payload?.chain !== "tron") || typeof payload.address !== "string") return error("Invalid wallet or network", 400);
    try {
      const result = await issueWalletLink(db as LinkDatabase, { memberId:member.id, chain:payload.chain, address:payload.address, origin, now:nowSeconds });
      return json(result);
    } catch (cause) {
      if (cause instanceof Error && cause.message === "TOO_MANY_CHALLENGES") return error("Too many pending requests; try again later", 429);
      return error("Invalid wallet or network", 400);
    }
  }
  if (typeof payload?.nonce !== "string" || typeof payload.signature !== "string") return error("Invalid wallet signature", 400);
  const linked = await completeWalletLink(db as LinkDatabase, { memberId:member.id, origin, nonce:payload.nonce, signature:payload.signature, now:nowSeconds });
  return linked ? json({ linked:true }) : error("Wallet signature is invalid, expired, already used, or linked to another member", 409);
}

/** Development-only submission: records a hash, does not verify or credit it. */
async function recordDraftRecovery(request:Request,env:CommerceEnv) {
  if (env.MULTICHAIN_DRAFT_RECOVERY_ENABLED!=="true") return error("Payment recovery is not available",503);
  let origin:string;
  try {origin=new URL(env.SITE_URL??"").origin;} catch {return error("Payment recovery is not configured",503);}
  if (!request.headers.get("origin") || request.headers.get("origin")!==origin || currentOrigin(request)!==origin) return error("Invalid request origin",403);
  const access=await requireSession(request,env,"member");
  if ("response" in access) return access.response;
  const db=needsDatabase(env); if(db instanceof Response) return db;
  const member=await memberForSession(env,access.session); if(!member) return error("Authentication required",401);
  const payload=await requestJson(request);
  if(typeof payload?.orderId!=="string" || !/^[a-zA-Z0-9_-]{1,128}$/.test(payload.orderId) || typeof payload.transactionId!=="string" || payload.transactionId.length>90) return error("Invalid transaction",400);
  try {
    const result=await recordPaymentAttempt(db,{memberId:member.id,orderId:payload.orderId,transactionId:payload.transactionId,now:new Date().toISOString()});
    return json(result);
  } catch(cause) {
    if(cause instanceof Error && cause.message==="ORDER_NOT_FOUND") return error("Order not found",404);
    if(cause instanceof Error && cause.message==="INVALID_TRANSACTION_ID") return error("Invalid transaction",400);
    if(cause instanceof Error && ["ORDER_NOT_PENDING","ATTEMPT_LIMIT_OR_ORDER_CHANGED"].includes(cause.message)) return error("Order cannot accept this transaction",409);
    return error("Payment recovery is temporarily unavailable",503);
  }
}

/** Development-only order creation. No transaction is constructed or sent. */
async function createDraftMultichainOrder(request:Request,env:CommerceEnv) {
  if(env.MULTICHAIN_DRAFT_ORDERS_ENABLED!=="true") return error("Multichain checkout is not available",503);
  let origin:string;try {origin=new URL(env.SITE_URL??"").origin;} catch{return error("Multichain checkout is not configured",503);}
  if(!request.headers.get("origin") || request.headers.get("origin")!==origin || currentOrigin(request)!==origin) return error("Invalid request origin",403);
  const access=await requireSession(request,env,"member");if("response" in access)return access.response;
  const db=needsDatabase(env);if(db instanceof Response)return db;
  const member=await memberForSession(env,access.session);if(!member)return error("Authentication required",401);
  const payload=await requestJson(request);
  if(!payload || !["ethereum","solana","tron"].includes(String(payload.chain)) || typeof payload.buyer!=="string" || payload.buyer.length>64 || typeof payload.packageId!=="string" || !["seed","path","ritual","synthesis"].includes(payload.packageId)) return error("Invalid order request",400);
  try {
    const pending=await db.prepare("SELECT COUNT(*) AS count FROM multichain_orders_draft WHERE member_id=? AND status='pending'").bind(member.id).first<{count:number}>();
    if((pending?.count??0)>=20)return error("Too many pending orders",429);
    const common={memberId:member.id,buyer:payload.buyer,packageId:payload.packageId,now:new Date().toISOString()};
    if(payload.chain==="solana") return json(await createSolanaDirectOrder(db,common));
    if(payload.chain==="tron") return json(await createTronDirectOrder(db,common));
    if(!env.ETHEREUM_DRAFT_USDC_ADDRESS)return error("Ethereum settlement is not configured",503);
    let buyer:Address,settlementToken:Address;
    try {buyer=getAddress(payload.buyer);settlementToken=getAddress(env.ETHEREUM_DRAFT_USDC_ADDRESS);} catch{return error("Invalid address or configuration",400);}
    return json(await createEthereumDraftOrder(db,{...common,buyer,settlementToken}));
  } catch(cause) {
    if(cause instanceof Error && cause.message.includes("too many pending orders")) return error("Too many pending orders",429);
    if(cause instanceof Error && cause.message==="WALLET_NOT_LINKED") return error("Wallet not linked to this account",403);
    if(cause instanceof Error && ["INVALID_TRON_ADDRESS","INVALID_BASE58","UNKNOWN_CREDIT_PACKAGE"].includes(cause.message)) return error("Invalid order request",400);
    return error("Multichain checkout is temporarily unavailable",503);
  }
}

/** The existence of a submitted candidate is not proof of payment. */
async function draftMultichainOrderStatus(request:Request,env:CommerceEnv,url:URL) {
  if(env.MULTICHAIN_DRAFT_ORDERS_ENABLED!=="true")return error("Multichain checkout is not available",503);
  const access=await requireSession(request,env,"member");if("response" in access)return access.response;
  const db=needsDatabase(env);if(db instanceof Response)return db;
  const member=await memberForSession(env,access.session);if(!member)return error("Authentication required",401);
  const id=url.searchParams.get("id");
  if(!id || !/^[a-zA-Z0-9_-]{1,128}$/.test(id))return error("Invalid order",400);
  try {
    const row=await db.prepare("SELECT o.id,o.chain,o.package_id,o.credits,o.status,o.created_at,o.credited_at,EXISTS(SELECT 1 FROM multichain_payment_attempts_draft a WHERE a.order_id=o.id) AS has_attempt FROM multichain_orders_draft o WHERE o.id=? AND o.member_id=?").bind(id,member.id).first<{id:string;chain:string;package_id:string;credits:number;status:string;created_at:string;credited_at:string|null;has_attempt:number}>();
    if(!row)return error("Order not found",404);
    return json({id:row.id,chain:row.chain,packageId:row.package_id,credits:row.credits,status:row.status==="credited"?"credited":row.has_attempt?"submitted":"awaiting_payment",createdAt:row.created_at,creditedAt:row.credited_at},{headers:{"cache-control":"no-store"}});
  }catch{return error("Order status is temporarily unavailable",503);}
}

export async function handleCommerceApi(request: Request, env: CommerceEnv): Promise<Response | null> {
  const url = new URL(request.url);
  if (!url.pathname.startsWith("/api/")) return null;
  cookieDomainAttribute = env.COOKIE_DOMAIN && /^\.?[a-z0-9.-]+$/i.test(env.COOKIE_DOMAIN) ? `; Domain=${env.COOKIE_DOMAIN}` : "";
  const { context, setCookie } = await bonusContextFor(request);
  bonusContexts.set(request, context);
  const response = await routeCommerceApi(request, env, url);
  if (setCookie && response) {
    try { response.headers.append("set-cookie", setCookie); } catch { /* immutable headers: the cookie is issued on the next response */ }
  }
  return response;
}

async function routeCommerceApi(request: Request, env: CommerceEnv, url: URL): Promise<Response | null> {
  try {
    if (url.pathname === "/api/draft/multichain-orders" && request.method === "POST") return createDraftMultichainOrder(request, env);
    if (url.pathname === "/api/draft/multichain-orders/status" && request.method === "GET") return draftMultichainOrderStatus(request, env, url);
    if (url.pathname === "/api/draft/payment-attempts" && request.method === "POST") return recordDraftRecovery(request, env);
    if (url.pathname === "/api/member/wallet-links/challenge" && request.method === "POST") return multichainWalletLink(request, env, "challenge");
    if (url.pathname === "/api/member/wallet-links/verify" && request.method === "POST") return multichainWalletLink(request, env, "verify");
    if (url.pathname === "/api/auth/google" && request.method === "POST") return googleSignIn(request, env);
    if (url.pathname === "/api/auth/forgot" && request.method === "POST") return forgotPassword(request, env);
    if (url.pathname === "/api/auth/reset" && request.method === "POST") return resetPassword(request, env);
    if (url.pathname === "/api/admin/reset-link" && request.method === "POST") return adminCreateResetLink(request, env);
    if (url.pathname === "/api/auth/providers" && request.method === "GET") return json({ google: env.GOOGLE_CLIENT_ID ? { clientId: env.GOOGLE_CLIENT_ID } : null, dodo: dodoEnabled(env) ? { packages: Object.keys(dodoProducts(env)) } : null });
    if (url.pathname === "/api/payments/dodo/checkout" && request.method === "POST") return dodoCheckout(request, env);
    if (url.pathname === "/api/payments/dodo/webhook" && request.method === "POST") return dodoWebhook(request, env);
    if (url.pathname === "/api/payments/dodo/order" && request.method === "GET") return dodoOrderStatus(request, env);
    if (url.pathname === "/api/member/team" && request.method === "GET") return memberTeam(request, env);
    if (url.pathname === "/api/admin/teams" && request.method === "GET") return adminTeams(request, env);
    if (url.pathname === "/api/lectures" && request.method === "GET") return publicLectures(request, env);
    if (url.pathname === "/api/shop/products" && request.method === "GET") return shopProducts(env);
    if (url.pathname === "/api/shop/orders" && request.method === "GET") return shopMemberOrders(request, env);
    if (url.pathname === "/api/shop/orders" && request.method === "POST") return shopCreateOrder(request, env);
    if (url.pathname === "/api/admin/shop/products" && request.method === "GET") return adminShopProducts(request, env);
    if (url.pathname === "/api/admin/shop/products" && request.method === "POST") return adminSaveShopProduct(request, env);
    if (url.pathname === "/api/admin/shop/orders" && request.method === "GET") return adminShopOrders(request, env);
    const shopOrderMatch = url.pathname.match(/^\/api\/admin\/shop\/orders\/([a-zA-Z0-9-]+)$/);
    if (shopOrderMatch && request.method === "POST") return adminUpdateShopOrder(request, env, shopOrderMatch[1]);
    if (url.pathname === "/api/admin/lectures" && request.method === "GET") return adminListLectures(request, env);
    if (url.pathname === "/api/admin/lectures" && request.method === "POST") return adminSaveLecture(request, env);
    if (url.pathname === "/api/readings/preview" && request.method === "POST") return createReadingPreview(request, env);
    if (url.pathname === "/api/readings/unlock" && request.method === "POST") return unlockReading(request, env);
    if (url.pathname === "/api/member/packages" && request.method === "GET") return memberExclusivePackages(request, env);
    if (url.pathname === "/api/admin/groups" && request.method === "GET") return adminListGroups(request, env);
    if (url.pathname === "/api/admin/groups" && request.method === "POST") return adminSaveGroup(request, env);
    if (url.pathname === "/api/admin/packages" && request.method === "GET") return adminListPackages(request, env);
    if (url.pathname === "/api/admin/packages" && request.method === "POST") return adminSavePackage(request, env);
    if (url.pathname === "/api/admin/grants" && request.method === "GET") return adminListGrants(request, env);
    if (url.pathname === "/api/admin/grants" && request.method === "POST") return adminRequestGrant(request, env);
    const grantMatch = url.pathname.match(/^\/api\/admin\/grants\/([a-zA-Z0-9-]+)\/decision$/);
    if (grantMatch && request.method === "POST") return adminDecideGrant(request, env, grantMatch[1]);
    if (url.pathname === "/api/auth/register" && request.method === "POST") return register(request, env);
    if (url.pathname === "/api/auth/login" && request.method === "POST") return memberLogin(request, env);
    if (url.pathname === "/api/auth/wallet/nonce" && request.method === "POST") return walletNonce(request, env);
    if (url.pathname === "/api/auth/wallet/verify" && request.method === "POST") return walletVerify(request, env);
    if (url.pathname === "/api/checkout/config" && request.method === "GET") return checkoutConfig(env);
    if (url.pathname === "/api/auth/admin/login" && request.method === "POST") return adminLogin(request, env);
    if (url.pathname === "/api/auth/logout" && request.method === "POST") {
      if (!sameOrigin(request)) return error("Invalid request origin", 403);
      return json({ ok: true }, { headers: { "set-cookie": clearSessionCookie() } });
    }
    if (url.pathname === "/api/member/me" && request.method === "GET") return memberMe(request, env);
    if (url.pathname === "/api/member/orders" && request.method === "GET") return memberOrders(request, env);
    if (url.pathname === "/api/member/ledger" && request.method === "GET") return memberLedger(request, env);
    if (url.pathname === "/api/member/invitations" && request.method === "GET") return memberInvitations(request, env);
    if (url.pathname === "/api/member/interpretations" && request.method === "GET") return memberInterpretationHistory(request, env);
    { const match = url.pathname.match(/^\/api\/member\/interpretations\/([0-9a-f-]{36})$/); if (match && request.method === "GET") return memberInterpretationDetail(request, env, match[1]); }
    if (url.pathname === "/api/member/profiles" && (request.method === "GET" || request.method === "POST")) return memberProfiles(request, env, null, request.method === "POST" ? "save" : null);
    { const match = url.pathname.match(/^\/api\/member\/profiles\/([0-9a-f-]{36})(\/delete)?$/); if (match && request.method === "POST") return memberProfiles(request, env, match[1], match[2] ? "delete" : "save"); }
    if (url.pathname === "/api/member/notes" && (request.method === "GET" || request.method === "POST")) return memberNotes(request, env);
    if (url.pathname === "/api/vision/status" && request.method === "GET") return visionStatus(env);
    // Admin only: test the photo-reading key, endpoint and model (open in the browser while signed in as admin).
    if (url.pathname === "/api/admin/vision-check" && request.method === "GET") { const access = await requireSession(request, env, "admin"); if ("response" in access) return access.response; return json(await checkVisionService(env), { headers: { "cache-control": "no-store" } }); }
    if (url.pathname === "/api/cezi/analyse" && request.method === "POST") return ceziAnalyse(request, env);
    if (url.pathname === "/api/library/translate" && request.method === "POST") return libraryTranslate(request, env);
    if (url.pathname === "/api/hall/heartbeat" && request.method === "POST") return hallHeartbeatRoute(request, env);
    if (url.pathname === "/api/rooms" || url.pathname.startsWith("/api/rooms/")) return roomsRoute(request, env, url.pathname.slice("/api/rooms".length).replace(/^\//, ""));
    if (url.pathname === "/api/hall/leave" && request.method === "POST") return hallLeaveRoute(request, env);
    if (url.pathname === "/api/hall/lamps" && (request.method === "GET" || request.method === "POST")) return hallLampsRoute(request, env);
    { const flash = await flashRoute(request, env, url); if (flash) return flash; }
    if (url.pathname === "/api/stats/share" && request.method === "POST") return shareStatRoute(request, env);
    if (url.pathname === "/api/admin/share-report" && request.method === "GET") return adminShareReport(request, env);
    if (url.pathname === "/api/vision/observe" && request.method === "POST") return visionObserve(request, env);
    if (url.pathname === "/api/member/export" && request.method === "GET") return memberExport(request, env);
    if (url.pathname === "/api/member/privacy/delete" && request.method === "POST") return memberDeleteData(request, env);
    if (url.pathname === "/api/readings/free-status" && request.method === "GET") return freePreviewStatus(request, env);
    if (url.pathname === "/api/member/interpretations/hide-all" && request.method === "POST") return hideInterpretation(request, env, null);
    const hideMatch = url.pathname.match(/^\/api\/member\/interpretations\/([a-zA-Z0-9-]{8,64})\/hide$/);
    if (hideMatch && request.method === "POST") return hideInterpretation(request, env, hideMatch[1]);
    if (url.pathname === "/api/member/reminders" && (request.method === "GET" || request.method === "POST")) return memberReminder(request, env);
    if (url.pathname === "/api/member/library" && request.method === "GET") return memberLibrary(request, env, null);
    if (url.pathname.startsWith("/api/member/library/") && request.method === "POST") return memberLibrary(request, env, decodeURIComponent(url.pathname.slice("/api/member/library/".length)));
    if (url.pathname === "/api/reminders/unsubscribe" && request.method === "GET") return reminderUnsubscribe(request, env);
    if (url.pathname === "/api/interpretations" && request.method === "POST") return createInterpretation(request, env);
    if (url.pathname === "/api/orders" && request.method === "POST") return createOrder(request, env);
    if (url.pathname === "/api/orders/manual" && request.method === "POST") return createManualOrder(request, env);
    { const match = url.pathname.match(/^\/api\/pay\/(solana|tron|ethereum)\/(order|confirm)$/); if (match && request.method === "POST") return match[2] === "order" ? walletPayOrder(request, env, match[1] as WalletPayChain) : walletPayConfirm(request, env, match[1] as WalletPayChain); }
    if (url.pathname === "/api/admin/overview" && request.method === "GET") return adminOverview(request, env);
    if (url.pathname === "/api/admin/orders" && request.method === "GET") return adminOrders(request, env);
    if (url.pathname === "/api/admin/members" && request.method === "GET") return adminMembers(request, env);
    if (url.pathname === "/api/admin/invitations" && request.method === "GET") return adminInvitations(request, env);
    if (url.pathname === "/api/admin/ledger" && request.method === "GET") return adminLedger(request, env);
    if (url.pathname === "/api/admin/interpretations" && request.method === "GET") return adminInterpretations(request, env);
    if (url.pathname === "/api/admin/chain-sync" && request.method === "POST") return adminChainSync(request, env);
    const adjustmentMatch = url.pathname.match(/^\/api\/admin\/members\/([a-zA-Z0-9-]+)\/credits$/);
    if (adjustmentMatch && request.method === "POST") return adjustMemberCredits(request, env, adjustmentMatch[1]);
    const reviewMatch = url.pathname.match(/^\/api\/admin\/orders\/([a-zA-Z0-9-]+)\/decision$/);
    if (reviewMatch && request.method === "POST") return reviewOrder(request, env, reviewMatch[1]);
    return error("API route not found", 404);
  } catch (cause) {
    console.error("[commerce-api] request failed", cause);
    return error("Unable to complete this request", 500);
  }
}

/**
 * Used by the Node media route: may this request play an uploaded lecture file?
 * Published lectures marked members-only need a signed-in member (or an administrator).
 */
export async function lectureMediaAccess(request: Request, env: CommerceEnv, file: string): Promise<"ok" | "signin" | "missing"> {
  if (!mediaFilePattern.test(file)) return "missing";
  const db = database(env);
  if (!db) return "missing";
  const lecture = await db.prepare("SELECT published, members_only FROM lectures WHERE media_file = ?").bind(file).first<{ published: number; members_only: number }>();
  const session = await readSession(request, env.SESSION_SECRET);
  if (session?.role === "admin") return "ok";
  if (!lecture || !lecture.published) return "missing";
  if (lecture.members_only && session?.role !== "member") return "signin";
  return "ok";
}

/** Used by the Node upload route: is this an administrator session? */
export async function isAdministratorRequest(request: Request, env: CommerceEnv) {
  const session = await readSession(request, env.SESSION_SECRET);
  return session?.role === "admin" && sameOrigin(request);
}

// ---------------------------------------------------------------------------------------------
// Daily reminder sender: once per member per local day, from 08:00 in their time zone.
// Called every few minutes by server/reminder-mailer.ts; needs RESEND_API_KEY and MAIL_FROM.
// ---------------------------------------------------------------------------------------------
const solarTermMail: Record<string, { subject: (term: string) => string; line: (term: string, link: string) => string }> = {
  en: { subject: (term) => `Today's solar term: ${term} · Xuannova`, line: (term, link) => `Today is ${term}, one of the 24 solar terms. See today's almanac and how the season turns: ${link}` },
  "zh-Hans": { subject: (term) => `今日节气：${term} · Xuannova`, line: (term, link) => `今天是二十四节气中的“${term}”。查看今日黄历与节气变化：${link}` },
  "zh-Hant": { subject: (term) => `今日節氣：${term} · Xuannova`, line: (term, link) => `今天是二十四節氣中的「${term}」。查看今日黃曆與節氣變化：${link}` },
  ja: { subject: (term) => `今日の節気：${term} · Xuannova`, line: (term, link) => `今日は二十四節気の「${term}」です。今日の暦と季節の移ろいはこちら：${link}` },
  ko: { subject: (term) => `오늘의 절기: ${term} · Xuannova`, line: (term, link) => `오늘은 24절기 중 '${term}'입니다. 오늘의 황력과 절기 변화 보기: ${link}` },
  vi: { subject: (term) => `Tiết khí hôm nay: ${term} · Xuannova`, line: (term, link) => `Hôm nay là ${term}, một trong 24 tiết khí. Xem lịch hôm nay và sự chuyển mùa: ${link}` },
  th: { subject: (term) => `สารทวันนี้: ${term} · Xuannova`, line: (term, link) => `วันนี้คือ${term} หนึ่งในยี่สิบสี่สารท ดูปฏิทินวันนี้และการเปลี่ยนฤดู: ${link}` },
};
const reminderMail: Record<string, { subject: string; lines: (link: string) => string[]; stop: string }> = {
  en: { subject: "Your 5 daily credits are ready · Xuannova", lines: (link) => ["Sign in today to collect your 5 free credits (they add up to 20).", `Today's almanac and hours: ${link}`], stop: "Stop these reminders" },
  "zh-Hans": { subject: "今日 5 积分可领取 · Xuannova", lines: (link) => ["今天登录即可领取 5 个免费积分（最多累积 20）。", `今日黄历与时辰：${link}`], stop: "取消每日提醒" },
  "zh-Hant": { subject: "今日 5 積分可領取 · Xuannova", lines: (link) => ["今天登入即可領取 5 個免費積分（最多累積 20）。", `今日黃曆與時辰：${link}`], stop: "取消每日提醒" },
  ja: { subject: "今日の5クレジットを受け取れます · Xuannova", lines: (link) => ["今日ログインすると無料クレジット5を受け取れます（最大20まで貯まります）。", `今日の暦と時刻：${link}`], stop: "毎日のお知らせを停止" },
  ko: { subject: "오늘의 5크레딧을 받을 수 있습니다 · Xuannova", lines: (link) => ["오늘 로그인하면 무료 크레딧 5를 받을 수 있습니다(최대 20까지 적립).", `오늘의 역과 시진: ${link}`], stop: "매일 알림 끄기" },
  vi: { subject: "5 điểm hôm nay đã sẵn sàng · Xuannova", lines: (link) => ["Đăng nhập hôm nay để nhận 5 điểm miễn phí (tích lũy tối đa 20).", `Lịch và giờ hôm nay: ${link}`], stop: "Tắt nhắc nhở hằng ngày" },
  th: { subject: "รับ 5 เครดิตของวันนี้ได้แล้ว · Xuannova", lines: (link) => ["เข้าสู่ระบบวันนี้เพื่อรับ 5 เครดิตฟรี (สะสมได้สูงสุด 20)", `ปฏิทินและยามของวันนี้: ${link}`], stop: "ปิดการแจ้งเตือนรายวัน" },
};

function localClock(timezone: string, at: Date) {
  try {
    const parts = Object.fromEntries(new Intl.DateTimeFormat("en-CA", { timeZone: timezone, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", hourCycle: "h23" }).formatToParts(at).map((part) => [part.type, part.value]));
    return { date: `${parts.year}-${parts.month}-${parts.day}`, hour: Number(parts.hour) };
  } catch { return null; }
}

export async function sendDailyReminders(env: CommerceEnv, options: { at?: Date; fetchImpl?: typeof fetch; almanac?: (date: string) => string | null; solarTerm?: (date: string, locale: string) => string | null } = {}) {
  const db = database(env);
  if (!db || !env.RESEND_API_KEY || !env.MAIL_FROM) return { sent: 0 };
  const at = options.at ?? new Date();
  const fetchImpl = options.fetchImpl ?? fetch;
  const site = (env.SITE_URL || "https://xuannova.com").replace(/\/$/, "");
  const { results } = await db.prepare("SELECT r.member_id, r.enabled, r.solar_terms, r.timezone, r.locale, r.token, r.last_sent_date, m.email FROM daily_reminders r JOIN members m ON m.id = r.member_id WHERE (r.enabled = 1 OR r.solar_terms = 1) AND m.email IS NOT NULL LIMIT 2000").all<{ member_id: string; enabled: number; solar_terms: number; timezone: string; locale: string; token: string; last_sent_date: string | null; email: string }>();
  let sent = 0;
  for (const row of results) {
    const clock = localClock(row.timezone, at);
    if (!clock || clock.hour < 8 || row.last_sent_date === clock.date) continue;
    // Solar-term subscribers get one e-mail on the day a solar term begins; daily subscribers get it every day.
    const term = row.solar_terms ? options.solarTerm?.(clock.date, row.locale) ?? null : null;
    if (!row.enabled && !term) continue;
    // Claim the day first so two servers (or a retry) never send twice.
    const claimed = await db.prepare("UPDATE daily_reminders SET last_sent_date = ?, updated_at = ? WHERE member_id = ? AND (last_sent_date IS NULL OR last_sent_date <> ?)").bind(clock.date, now(), row.member_id, clock.date).run();
    if ((claimed.meta?.changes ?? 0) !== 1) continue;
    const mail = reminderMail[row.locale] ?? reminderMail.en;
    const prefix = row.locale === "en" ? "" : `/${row.locale.toLowerCase()}`;
    const almanac = row.locale.startsWith("zh") ? options.almanac?.(clock.date) ?? null : null;
    const termMail = solarTermMail[row.locale] ?? solarTermMail.en;
    const termLines = term ? [termMail.line(term, `${site}${prefix}/almanac`)] : [];
    const text = [...termLines, ...(termLines.length && row.enabled ? [""] : []), ...(row.enabled ? mail.lines(`${site}${prefix}/almanac`) : []), ...(almanac ? ["", almanac] : []), "", `${mail.stop}: ${site}/api/reminders/unsubscribe?token=${row.token}`].join("\n");
    const subject = term ? termMail.subject(term) : mail.subject;
    try {
      const response = await fetchImpl("https://api.resend.com/emails", { method: "POST", headers: { authorization: `Bearer ${env.RESEND_API_KEY}`, "content-type": "application/json" }, body: JSON.stringify({ from: env.MAIL_FROM, to: [row.email], subject, text, headers: { "List-Unsubscribe": `<${site}/api/reminders/unsubscribe?token=${row.token}>` } }) });
      if (response.ok) sent += 1;
    } catch { /* the day is claimed; a failed send is not retried to avoid duplicates */ }
  }
  return { sent };
}
