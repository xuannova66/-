/** Local-only direct TRC20 USDT order prototype; NOT wired to live API.
 * No exchange, TRX payment, Token taxes, or real-funds use is supported.
 * Member identity and RPC fetch must be trusted server-side dependencies.
 */
import { bytesToHex } from "viem";
import { packageSettlement } from "./multichain-policy";
import { inspectTronDirectFromRpc } from "./direct-payment-rpc.draft";
import { tronAddressHex } from "./wallet-link-auth.draft";

type Statement = { bind(...values: unknown[]): Statement; first<T>(): Promise<T | null>; run(): Promise<{meta?:{changes?:number}}> };
type Database = { prepare(sql: string): Statement };
type Fetcher = (input: string, init: RequestInit) => Promise<Response>;
type Order = { id:string; member_id:string; chain:string; package_id:string; credits:number; buyer:string; recipient:string; settlement_asset:string; amount_units:string; order_reference:string; status:string; transaction_id:string|null };
const TRON_USDT = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t";

export async function createTronDirectOrder(db:Database, input:{memberId:string; buyer:string; packageId:string; now:string}) {
  tronAddressHex(input.buyer);
  const linked = await db.prepare("SELECT address FROM member_wallet_links_v2 WHERE chain='tron' AND address=? AND member_id=?").bind(input.buyer,input.memberId).first<{address:string}>();
  if (!linked) throw new Error("WALLET_NOT_LINKED");
  const terms = packageSettlement("tron",input.packageId);
  const id = crypto.randomUUID(), reference = bytesToHex(crypto.getRandomValues(new Uint8Array(32))).slice(2);
  await db.prepare("INSERT INTO multichain_orders_draft(id,member_id,chain,package_id,credits,buyer,recipient,settlement_asset,amount_units,order_reference,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)")
    .bind(id,input.memberId,"tron",terms.packageId,terms.credits,input.buyer,terms.recipient,TRON_USDT,terms.amountUnits.toString(),reference,input.now).run();
  return {id,reference,recipient:terms.recipient,token:TRON_USDT,amountUnits:terms.amountUnits.toString()};
}

export async function settleTronDirectOrder(db:Database, input:{memberId:string; orderId:string; txId:string; now:string; fetcher?:Fetcher}) {
  const order = await db.prepare("SELECT id,member_id,chain,package_id,credits,buyer,recipient,settlement_asset,amount_units,order_reference,status,transaction_id FROM multichain_orders_draft WHERE id=? AND member_id=?").bind(input.orderId,input.memberId).first<Order>();
  if (!order || order.chain !== "tron") throw new Error("ORDER_NOT_FOUND");
  if (!/^[a-fA-F0-9]{64}$/.test(input.txId)) throw new Error("INVALID_TRANSACTION_ID");
  const id = input.txId.toLowerCase();
  if (order.status === "credited") {
    if (order.transaction_id !== id) throw new Error("ORDER_ALREADY_CREDITED");
    return {status:"credited" as const,alreadyCredited:true};
  }
  const terms = packageSettlement("tron",order.package_id);
  if (order.recipient !== terms.recipient || order.settlement_asset !== TRON_USDT || order.amount_units !== terms.amountUnits.toString() || order.credits !== terms.credits) throw new Error("ORDER_TERMS_MISMATCH");
  const proof = await inspectTronDirectFromRpc({txId:id,buyerHex:tronAddressHex(order.buyer),recipientHex:tronAddressHex(terms.recipient),tokenHex:tronAddressHex(TRON_USDT),amountUnits:terms.amountUnits,orderReference:order.order_reference},input.fetcher);
  const result = await db.prepare("UPDATE multichain_orders_draft SET status='credited',transaction_id=?,event_index=?,credited_at=? WHERE id=? AND member_id=? AND status='pending'")
    .bind(proof.transactionId,proof.logIndex,input.now,order.id,input.memberId).run();
  if (result.meta?.changes === 1) return {status:"credited" as const,alreadyCredited:false};
  const current = await db.prepare("SELECT status,transaction_id FROM multichain_orders_draft WHERE id=? AND member_id=?").bind(order.id,input.memberId).first<Pick<Order,"status"|"transaction_id">>();
  if (current?.status === "credited" && current.transaction_id === id) return {status:"credited" as const,alreadyCredited:true};
  throw new Error("ORDER_SETTLEMENT_CONFLICT");
}
