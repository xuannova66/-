/** Isolated research implementation: direct SPL transferChecked only.
 * NOT connected to the website, RPC, wallet login, database or point ledger.
 * Does not support swaps, Token-2022, transfer taxes or batched orders.
 * Inputs must come from a trusted RPC getTransaction(jsonParsed, finalized),
 * and the reference must be generated and bound to the member server-side.
 */
const SPL_TOKEN = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA";
const MEMO_PROGRAM = "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr";
type Key = { pubkey: string; signer: boolean };
type TokenBalance = { accountIndex: number; mint: string; owner?: string; programId?: string; uiTokenAmount: { amount: string; decimals: number } };
type Instruction = { programId?: string; parsed?: unknown };
export type SolanaParsedTx = {
  meta: { err: unknown; preTokenBalances: TokenBalance[]; postTokenBalances: TokenBalance[] } | null;
  transaction: { signatures: string[]; message: { accountKeys: Key[]; instructions: Instruction[] } };
};
export type SolanaDirectExpected = {
  signature: string; buyer: string; recipient: string; recipientTokenAccount: string;
  mint: string; decimals: number; amountUnits: bigint; orderReference: string;
};

export function inspectSolanaDirectPayment(tx: SolanaParsedTx, finalized: boolean, expected: SolanaDirectExpected) {
  if (!finalized || !tx?.meta || tx.meta.err !== null) throw new Error("TRANSACTION_NOT_FINAL_SUCCESS");
  if (!/^[1-9A-HJ-NP-Za-km-z]{64,88}$/.test(expected.signature) || tx.transaction.signatures[0] !== expected.signature) throw new Error("SIGNATURE_MISMATCH");
  if (!/^[a-f0-9]{64}$/.test(expected.orderReference)) throw new Error("INVALID_ORDER_REFERENCE");
  if (!Number.isInteger(expected.decimals) || expected.decimals < 0 || expected.decimals > 18 || expected.amountUnits <= 0n) throw new Error("INVALID_EXPECTATION");
  const keys = tx.transaction.message.accountKeys;
  if (!keys.some((key) => key.pubkey === expected.buyer && key.signer === true)) throw new Error("BUYER_NOT_SIGNER");
  const recipientIndex = keys.findIndex((key) => key.pubkey === expected.recipientTokenAccount);
  if (recipientIndex < 0) throw new Error("RECIPIENT_ACCOUNT_MISSING");
  const post = tx.meta.postTokenBalances.find((entry) => entry.accountIndex === recipientIndex);
  const pre = tx.meta.preTokenBalances.find((entry) => entry.accountIndex === recipientIndex);
  if (!post || !pre || post.owner !== expected.recipient || pre.owner !== expected.recipient || post.mint !== expected.mint || pre.mint !== expected.mint || post.programId !== SPL_TOKEN || pre.programId !== SPL_TOKEN || post.uiTokenAmount.decimals !== expected.decimals || pre.uiTokenAmount.decimals !== expected.decimals) throw new Error("WRONG_RECIPIENT_TOKEN_ACCOUNT");
  if (!/^\d+$/.test(pre.uiTokenAmount.amount) || !/^\d+$/.test(post.uiTokenAmount.amount) || BigInt(post.uiTokenAmount.amount) - BigInt(pre.uiTokenAmount.amount) !== expected.amountUnits) throw new Error("WRONG_RECEIVED_AMOUNT");
  const instructions = tx.transaction.message.instructions;
  if (instructions.filter((item) => item.programId === MEMO_PROGRAM && item.parsed === expected.orderReference).length !== 1) throw new Error("ORDER_REFERENCE_MISMATCH");
  const matches = instructions.flatMap((item, index) => {
    if (item.programId !== SPL_TOKEN || !item.parsed || typeof item.parsed !== "object") return [];
    const parsed = item.parsed as { type?: string; info?: { authority?: string; mint?: string; destination?: string; tokenAmount?: { amount?: string; decimals?: number } } };
    const info = parsed.info;
    return parsed.type === "transferChecked" && info?.authority === expected.buyer && info.mint === expected.mint && info.destination === expected.recipientTokenAccount && info.tokenAmount?.amount === expected.amountUnits.toString() && info.tokenAmount.decimals === expected.decimals ? [index] : [];
  });
  if (matches.length !== 1) throw new Error("TRANSFER_NOT_UNIQUE_OR_NOT_DIRECT");
  return { signature: expected.signature, instructionIndex: matches[0], amountUnits: expected.amountUnits };
}
