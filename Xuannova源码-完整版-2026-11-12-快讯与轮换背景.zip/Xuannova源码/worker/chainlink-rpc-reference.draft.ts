/** Local-only RPC reference adapter; no live enablement. Feed addresses must
 * be operator-verified against the issuer, chain and exact token representation.
 * A market feed for native ETH is not automatically proof for a bridged token.
 * On-chain feeds update by heartbeat/deviation, not necessarily every block.
 */
import {getAddress,parseAbi,type Address} from "viem";
type Feed={chainId:number;asset:Address;assetDecimals:number;proxy:Address;description:string};
type Reader={getChainId():Promise<number>;getBlockNumber():Promise<bigint>;getBlock(input:{blockNumber:bigint}):Promise<{timestamp:bigint}>;readContract(input:{address:Address;abi:typeof abi;functionName:"description"|"decimals"|"latestRoundData";blockNumber:bigint}):Promise<unknown>};
const abi=parseAbi(["function description() view returns(string)","function decimals() view returns(uint8)","function latestRoundData() view returns(uint80,int256,uint256,uint256,uint80)"]);
const ZERO="0x0000000000000000000000000000000000000000";
function validateFeed(feed:Feed,chainId:number,asset:Address) {
 if(feed.chainId!==chainId||getAddress(feed.asset)!==getAddress(asset)||getAddress(feed.proxy)===ZERO||!Number.isInteger(feed.assetDecimals)||feed.assetDecimals<0||feed.assetDecimals>18||typeof feed.description!=="string"||!feed.description.trim())throw new Error("PRICE_FEED_MAPPING_MISMATCH");
}
async function readFeed(reader:Reader,feed:Feed,blockNumber:bigint,now:number) {
 const [description,decimals,round]=await Promise.all((["description","decimals","latestRoundData"] as const).map(functionName=>reader.readContract({address:getAddress(feed.proxy),abi,functionName,blockNumber})));
 if(description!==feed.description || !Number.isInteger(decimals) || (decimals as number)<0 || (decimals as number)>18 || !Array.isArray(round) || round.length!==5)throw new Error("INVALID_PRICE_FEED_RESPONSE");
 const [id,answer,,updated]=round;
 if(typeof id!=="bigint"||id<=0n||typeof answer!=="bigint"||answer<=0n||typeof updated!=="bigint"||updated<=0n||updated>BigInt(now)||BigInt(now)-updated>30n)throw new Error("STALE_OR_INVALID_PRICE");
 return {price:answer,decimals:decimals as number,updatedAt:Number(updated)};
}
/** Each call reads a new block and both USD feeds; math uses integer rounding
 * upwards and uses the older of the two feed timestamps for the quote gate. */
export async function chainlinkRpcReferenceDraft(input:{reader:Reader;chainId:number;asset:Address;settlement:Address;outputUnits:bigint;inputFeed:Feed;settlementFeed:Feed;clock:()=>number}) {
 if(typeof input.outputUnits!=="bigint"||input.outputUnits<=0n)throw new Error("INVALID_OUTPUT_AMOUNT");
 validateFeed(input.inputFeed,input.chainId,input.asset);validateFeed(input.settlementFeed,input.chainId,input.settlement);
 if(getAddress(input.inputFeed.proxy)===getAddress(input.settlementFeed.proxy))throw new Error("INVALID_PRICE_FEED");
 if(await input.reader.getChainId()!==input.chainId)throw new Error("WRONG_CHAIN");
 const blockNumber=await input.reader.getBlockNumber(),block=await input.reader.getBlock({blockNumber}),now=input.clock();
 if(!Number.isSafeInteger(now)||now<=0||typeof block.timestamp!=="bigint"||block.timestamp>BigInt(now)||BigInt(now)-block.timestamp>60n)throw new Error("STALE_OR_INVALID_BLOCK");
 const [base,quote]=await Promise.all([readFeed(input.reader,input.inputFeed,blockNumber,now),readFeed(input.reader,input.settlementFeed,blockNumber,now)]);
 const exponent=input.inputFeed.assetDecimals-input.settlementFeed.assetDecimals+base.decimals-quote.decimals;
 const numerator=input.outputUnits*quote.price*(exponent>=0?10n**BigInt(exponent):1n), denominator=base.price*(exponent<0?10n**BigInt(-exponent):1n);
 const inputUnits=(numerator+denominator-1n)/denominator;
 if(inputUnits<=0n||inputUnits>=(1n<<256n))throw new Error("INVALID_REFERENCE_PRICE");
 return {inputUnits,observedAt:Math.min(base.updatedAt,quote.updatedAt),blockNumber};
}
