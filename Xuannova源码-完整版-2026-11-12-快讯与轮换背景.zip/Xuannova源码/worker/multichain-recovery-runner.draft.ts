/** Local dispatch prototype, never automatically scheduled or exposed as API.
 * Each enabled chain requires trusted server-side verifier configuration.
 * A reported exception is sanitized to a category and never contains secrets.
 */
import type { Hex } from "viem";
import { retryPaymentAttempts, type RecoveryDatabase } from "./multichain-recovery.draft";
import { settleEthereumDraftOrder } from "./ethereum-order-settlement.draft";
import { settleSolanaDirectOrder } from "./solana-order-settlement.draft";
import { settleTronDirectOrder } from "./tron-order-settlement.draft";

type EthereumConfig=Pick<Parameters<typeof settleEthereumDraftOrder>[1],"checkout"|"settlementToken"|"confirmations"|"rpc">;
type Fetcher=(input:string,init:RequestInit)=>Promise<Response>;
type Options={now:string;limit:number;ethereum?:EthereumConfig;solana?:{recipientTokenAccount:string;fetcher?:Fetcher};tron?:{fetcher?:Fetcher};onFailure?:(chain:string,category:"not_configured"|"verification_failed")=>void};

export async function runMultichainRecoveryDraft(db:RecoveryDatabase,options:Options) {
  return retryPaymentAttempts(db,{now:options.now,limit:options.limit,verify:async attempt=>{
    const base={memberId:attempt.member_id,orderId:attempt.order_id,now:options.now};
    try {
      if(attempt.chain==="ethereum" && options.ethereum) {
        await settleEthereumDraftOrder(db,{...base,...options.ethereum,txHash:`0x${attempt.transaction_id}` as Hex}); return;
      }
      if(attempt.chain==="solana" && options.solana) {
        await settleSolanaDirectOrder(db,{...base,...options.solana,signature:attempt.transaction_id}); return;
      }
      if(attempt.chain==="tron" && options.tron) {
        await settleTronDirectOrder(db,{...base,...options.tron,txId:attempt.transaction_id}); return;
      }
      options.onFailure?.(attempt.chain,"not_configured");
    } catch {
      options.onFailure?.(attempt.chain,"verification_failed");
    }
  }});
}
