// 玄诺快讯 · XuanNova Flash: short news items read through Eastern culture (五行, 易经, 节气, 道德经), in seven languages.
//
// Where items come from
//   1. POST /api/flash/ingest  — an automation tool (Make.com, n8n, Zapier…) sends JSON with all seven languages.
//      Protected by FLASH_API_TOKEN (Authorization: Bearer …).
//   2. The built-in runner (server/flash-runner.ts) — reads news headlines from RSS feeds set in the admin page,
//      asks the text model (DeepSeek) for a short reading in seven languages, and stores it.
//   3. The admin page — edit, hide, pin, feature or delete; run the news runner now.
//
// Honest numbers: views are real (one per device per item per day). The page shows a "new" / "trending" label
// instead of a small number; nothing is seeded or inflated.
//
// Content rules for the model (fixed in code, the editable prompt cannot remove them): no claims about real people's
// private lives, health, relationships or unproven wrongdoing, no face reading of real people, nothing about deaths,
// disasters with victims, war, crime or partisan politics, no investment advice, nothing beyond what the headline says.

type Statement = { bind(...values: unknown[]): Statement; first<T>(): Promise<T | null>; all<T>(): Promise<{ results?: T[] }>; run(): Promise<unknown> };
export type FlashDatabase = { prepare(sql: string): Statement; batch?(statements: Statement[]): Promise<unknown> };
type Fetcher = (input: string, init?: RequestInit) => Promise<Response>;

export const FLASH_LOCALES = ["zh-Hans", "zh-Hant", "en", "ja", "ko", "vi", "th"] as const;
export type FlashLocale = (typeof FLASH_LOCALES)[number];
export const FLASH_CATEGORIES = ["focus", "energy", "wisdom"] as const;
export type FlashCategory = (typeof FLASH_CATEGORIES)[number];
/** Where the item's button leads (a free tool that fits the story). */
export const FLASH_CTAS = ["bazi", "daily", "almanac", "compatibility", "ziwei", "liuyao", "meihua", "qimen", "zeri", "toolkit"] as const;
export type FlashCta = (typeof FLASH_CTAS)[number];
export type FlashStatus = "published" | "draft" | "hidden";

export type FlashText = { title: string; summary: string; body: string; quote: string | null; quoteSource: string | null };
export type FlashItem = {
  id: string; slug: string; category: FlashCategory; status: FlashStatus; pinned: boolean; featured: boolean; cta: FlashCta;
  sourceUrl: string | null; sourceName: string | null; coverUrl: string | null; origin: string;
  views: number; shares: number; posters: number; publishedAt: string; updatedAt: string;
  locale: FlashLocale; text: FlashText; locales: FlashLocale[];
};

export class FlashError extends Error {
  constructor(public readonly code: "INVALID" | "NOT_FOUND" | "DUPLICATE" | "AI_NOT_CONFIGURED" | "AI_FAILED", message?: string) { super(message ?? code); }
}

// ------------------------------------------------------------------ validation of incoming items
const LOCALE_ALIASES: Record<string, FlashLocale> = {
  "zh-hans": "zh-Hans", zh: "zh-Hans", "zh-cn": "zh-Hans", zh_cn: "zh-Hans", cn: "zh-Hans", chinese: "zh-Hans", "zh-sg": "zh-Hans",
  "zh-hant": "zh-Hant", "zh-tw": "zh-Hant", zh_tw: "zh-Hant", "zh-hk": "zh-Hant", tw: "zh-Hant", traditional: "zh-Hant",
  en: "en", english: "en", ja: "ja", jp: "ja", japanese: "ja", ko: "ko", kr: "ko", korean: "ko", vi: "vi", vn: "vi", vietnamese: "vi", th: "th", thai: "th",
};
export const flashLocale = (value: unknown): FlashLocale | null => (typeof value === "string" ? LOCALE_ALIASES[value.trim().toLowerCase()] ?? null : null);

const clean = (value: unknown, max: number) => {
  if (typeof value !== "string") return "";
  return value.normalize("NFC").replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f​-‏‪-‮]/g, "").replace(/<[^>]*>/g, "").replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim().slice(0, max);
};
const httpUrl = (value: unknown) => {
  if (typeof value !== "string" || !value.trim()) return null;
  try { const url = new URL(value.trim()); return url.protocol === "https:" || url.protocol === "http:" ? url.toString().slice(0, 1000) : null; } catch { return null; }
};
const firstSentence = (text: string) => {
  const match = text.match(/^(.{12,160}?[。！？!?．.](?=\s|$|[^\d]))/s);
  return (match ? match[1] : text.slice(0, 120)).trim();
};

/** One language block. Accepts {title, summary?, body|content, quote?, quote_source?}. */
export function parseFlashText(value: unknown): FlashText | null {
  const record = value && typeof value === "object" ? value as Record<string, unknown> : null;
  if (!record) return null;
  const title = clean(record.title ?? record.headline, 140);
  const body = clean(record.body ?? record.content ?? record.text, 2400);
  if (!title || !body) return null;
  const summary = clean(record.summary ?? record.excerpt, 260) || firstSentence(body);
  const quote = clean(record.quote, 200) || null;
  const quoteSource = clean(record.quote_source ?? record.quoteSource ?? record.source_book, 60) || null;
  return { title, summary, body, quote, quoteSource };
}

export type FlashInput = {
  category: FlashCategory; cta: FlashCta; status: FlashStatus; sourceUrl: string | null; sourceName: string | null; coverUrl: string | null;
  pinned: boolean; featured: boolean; publishedAt: string | null; texts: Partial<Record<FlashLocale, FlashText>>;
};

/**
 * The automation payload. Language blocks may sit under "translations" / "languages" / "i18n", or at the top level
 * keyed by language ("zh-Hans": {...}, "en": {...}). Chinese (Simplified) or English must be present.
 */
export function parseFlashInput(value: unknown, defaults: { status?: FlashStatus } = {}): FlashInput {
  const record = value && typeof value === "object" ? value as Record<string, unknown> : null;
  if (!record) throw new FlashError("INVALID", "Body must be a JSON object");
  const container = [record.translations, record.languages, record.i18n, record].find((item) => item && typeof item === "object") as Record<string, unknown>;
  const texts: Partial<Record<FlashLocale, FlashText>> = {};
  for (const [key, block] of Object.entries(container)) {
    const locale = flashLocale(key);
    if (!locale || texts[locale]) continue;
    const text = parseFlashText(block);
    if (text) texts[locale] = text;
  }
  if (!texts["zh-Hans"] && !texts.en) throw new FlashError("INVALID", "Need at least zh-Hans or en (title + body)");
  const category = (FLASH_CATEGORIES as readonly string[]).includes(String(record.category)) ? record.category as FlashCategory : "focus";
  const cta = (FLASH_CTAS as readonly string[]).includes(String(record.cta)) ? record.cta as FlashCta : category === "wisdom" ? "daily" : category === "energy" ? "bazi" : "bazi";
  const status = record.status === "draft" || record.status === "hidden" || record.status === "published" ? record.status : defaults.status ?? "published";
  const published = typeof record.published_at === "string" && !Number.isNaN(Date.parse(record.published_at)) ? new Date(record.published_at).toISOString() : null;
  return {
    category, cta, status,
    sourceUrl: httpUrl(record.source_url ?? record.sourceUrl ?? record.url),
    sourceName: clean(record.source_name ?? record.sourceName ?? record.source, 80) || null,
    coverUrl: httpUrl(record.cover_url ?? record.coverUrl ?? record.image),
    pinned: record.pinned === true, featured: record.featured === true,
    publishedAt: published, texts,
  };
}

// ------------------------------------------------------------------ slugs
/** "gold-hits-a-record-high-3f9a": from the English (or any Latin) title; otherwise the date. Always unique. */
export function makeSlug(input: FlashInput, now: Date, random = () => Math.random()) {
  const latin = input.texts.en?.title ?? input.texts.vi?.title ?? "";
  const words = latin.normalize("NFD").replace(/\p{Diacritic}/gu, "").replace(/đ/gi, "d").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").split("-").filter(Boolean).slice(0, 8).join("-");
  const tail = Math.floor(random() * 0xffff).toString(16).padStart(4, "0");
  const date = now.toISOString().slice(0, 10);
  return words.length >= 3 ? `${words.slice(0, 70).replace(/-+$/, "")}-${tail}` : `${date}-${tail}`;
}
export const validSlug = (value: string) => /^[a-z0-9][a-z0-9-]{3,90}$/.test(value);

export async function sourceKey(url: string | null, title: string) {
  const basis = (url ?? "").replace(/[?#].*$/, "") || title.toLowerCase();
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(basis));
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("").slice(0, 32);
}

// ------------------------------------------------------------------ storage
const uuid = () => crypto.randomUUID();
type Row = { id: string; slug: string; category: string; status: string; pinned: number; featured: number; cta: string; source_url: string | null; source_name: string | null; cover_url: string | null; origin: string; views: number; shares: number; posters: number; published_at: string; updated_at: string };
type TextRow = { flash_id: string; locale: string; title: string; summary: string; body: string; quote: string | null; quote_source: string | null };

export async function createFlash(db: FlashDatabase, input: FlashInput, options: { origin: string; now: Date; sourceKey?: string | null }) {
  const now = options.now.toISOString();
  if (options.sourceKey) {
    const existing = await db.prepare("SELECT slug FROM flash_items WHERE source_key = ?").bind(options.sourceKey).first<{ slug: string }>();
    if (existing) throw new FlashError("DUPLICATE", existing.slug);
  }
  let slug = makeSlug(input, options.now);
  for (let tries = 0; tries < 4 && await db.prepare("SELECT 1 AS hit FROM flash_items WHERE slug = ?").bind(slug).first(); tries += 1) slug = makeSlug(input, options.now);
  const id = uuid();
  const statements = [
    db.prepare("INSERT INTO flash_items (id, slug, category, status, pinned, featured, cta, source_url, source_name, source_key, cover_url, origin, views, shares, posters, published_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, ?, ?, ?)")
      .bind(id, slug, input.category, input.status, input.pinned ? 1 : 0, input.featured ? 1 : 0, input.cta, input.sourceUrl, input.sourceName, options.sourceKey ?? null, input.coverUrl, options.origin, input.publishedAt ?? now, now, now),
    ...Object.entries(input.texts).map(([locale, text]) => db.prepare("INSERT INTO flash_translations (flash_id, locale, title, summary, body, quote, quote_source) VALUES (?, ?, ?, ?, ?, ?, ?)")
      .bind(id, locale, text!.title, text!.summary, text!.body, text!.quote, text!.quoteSource)),
  ];
  if (db.batch) await db.batch(statements); else for (const statement of statements) await statement.run();
  return { id, slug };
}

const fallbackOrder = (locale: FlashLocale): FlashLocale[] => {
  const chinese = locale === "zh-Hant" ? ["zh-Hant", "zh-Hans"] : locale === "zh-Hans" ? ["zh-Hans", "zh-Hant"] : [locale];
  return [...new Set([...chinese, "en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"])] as FlashLocale[];
};

function toItem(row: Row, texts: TextRow[], locale: FlashLocale): FlashItem | null {
  const byLocale = new Map(texts.map((text) => [text.locale, text]));
  const chosen = fallbackOrder(locale).map((code) => byLocale.get(code)).find(Boolean);
  if (!chosen) return null;
  return {
    id: row.id, slug: row.slug,
    category: (FLASH_CATEGORIES as readonly string[]).includes(row.category) ? row.category as FlashCategory : "focus",
    status: row.status as FlashStatus, pinned: Boolean(row.pinned), featured: Boolean(row.featured),
    cta: (FLASH_CTAS as readonly string[]).includes(row.cta) ? row.cta as FlashCta : "bazi",
    sourceUrl: row.source_url, sourceName: row.source_name, coverUrl: row.cover_url, origin: row.origin,
    views: row.views, shares: row.shares, posters: row.posters, publishedAt: row.published_at, updatedAt: row.updated_at,
    locale: chosen.locale as FlashLocale,
    text: { title: chosen.title, summary: chosen.summary, body: chosen.body, quote: chosen.quote, quoteSource: chosen.quote_source },
    locales: texts.map((text) => text.locale as FlashLocale),
  };
}

async function textsFor(db: FlashDatabase, ids: string[]) {
  if (!ids.length) return new Map<string, TextRow[]>();
  const rows = (await db.prepare(`SELECT * FROM flash_translations WHERE flash_id IN (${ids.map(() => "?").join(",")})`).bind(...ids).all<TextRow>()).results ?? [];
  const map = new Map<string, TextRow[]>();
  for (const row of rows) map.set(row.flash_id, [...(map.get(row.flash_id) ?? []), row]);
  return map;
}

const COLUMNS = "id, slug, category, status, pinned, featured, cta, source_url, source_name, cover_url, origin, views, shares, posters, published_at, updated_at";

/** Published items, newest first (pinned ones on top of the first page). `before` pages back by publish time. */
export async function listFlash(db: FlashDatabase, options: { locale: FlashLocale; limit: number; before?: string | null; category?: FlashCategory | null; now: Date }) {
  const limit = Math.max(1, Math.min(50, options.limit));
  const where = ["status = 'published'", "published_at <= ?"];
  const binds: unknown[] = [options.now.toISOString()];
  if (options.before) { where.push("published_at < ?"); binds.push(options.before); }
  if (options.category) { where.push("category = ?"); binds.push(options.category); }
  const order = options.before ? "published_at DESC" : "pinned DESC, published_at DESC";
  const rows = (await db.prepare(`SELECT ${COLUMNS} FROM flash_items WHERE ${where.join(" AND ")} ORDER BY ${order} LIMIT ?`).bind(...binds, limit + 1).all<Row>()).results ?? [];
  const page = rows.slice(0, limit);
  const texts = await textsFor(db, page.map((row) => row.id));
  const items = page.map((row) => toItem(row, texts.get(row.id) ?? [], options.locale)).filter(Boolean) as FlashItem[];
  // the next page continues from the oldest item shown that is not pinned
  const oldest = [...page].sort((a, b) => a.published_at.localeCompare(b.published_at))[0];
  return { items, next: rows.length > limit && oldest ? oldest.published_at : null };
}

export async function getFlash(db: FlashDatabase, slug: string, locale: FlashLocale, options: { includeHidden?: boolean; now?: Date } = {}) {
  if (!validSlug(slug)) return null;
  const row = await db.prepare(`SELECT ${COLUMNS} FROM flash_items WHERE slug = ?`).bind(slug).first<Row>();
  if (!row) return null;
  if (!options.includeHidden && (row.status !== "published" || row.published_at > (options.now ?? new Date()).toISOString())) return null;
  const texts = await textsFor(db, [row.id]);
  return toItem(row, texts.get(row.id) ?? [], locale);
}

/** All languages of one item (detail page hreflang, admin editing). */
export async function flashTexts(db: FlashDatabase, id: string) {
  return ((await textsFor(db, [id])).get(id) ?? []).map((row) => ({ locale: row.locale as FlashLocale, title: row.title, summary: row.summary, body: row.body, quote: row.quote, quoteSource: row.quote_source }));
}

/** Count a real view: once per device per item per UTC day. Returns the current count. */
export async function recordView(db: FlashDatabase, slug: string, visitor: string, now: Date) {
  const row = await db.prepare("SELECT id, views FROM flash_items WHERE slug = ? AND status = 'published'").bind(slug).first<{ id: string; views: number }>();
  if (!row) return null;
  const day = now.toISOString().slice(0, 10);
  const seen = await db.prepare("SELECT 1 AS hit FROM flash_views WHERE flash_id = ? AND visitor = ? AND day = ?").bind(row.id, visitor, day).first();
  if (seen) return row.views;
  await db.prepare("INSERT OR IGNORE INTO flash_views (flash_id, visitor, day) VALUES (?, ?, ?)").bind(row.id, visitor, day).run();
  await db.prepare("UPDATE flash_items SET views = views + 1 WHERE id = ?").bind(row.id).run();
  if (Math.random() < 0.02) {
    const cutoff = new Date(now.getTime() - 3 * 86_400_000).toISOString().slice(0, 10);
    await db.prepare("DELETE FROM flash_views WHERE day < ?").bind(cutoff).run();
  }
  return row.views + 1;
}

export async function recordShare(db: FlashDatabase, slug: string, kind: "share" | "poster") {
  const column = kind === "poster" ? "posters" : "shares";
  await db.prepare(`UPDATE flash_items SET ${column} = ${column} + 1 WHERE slug = ? AND status = 'published'`).bind(slug).run();
}

/** Newest publish time and count: lets open pages notice a new item with a tiny request. */
export async function flashVersion(db: FlashDatabase, now: Date) {
  const row = await db.prepare("SELECT MAX(updated_at) AS updated, COUNT(*) AS total FROM flash_items WHERE status = 'published' AND published_at <= ?").bind(now.toISOString()).first<{ updated: string | null; total: number }>();
  return `${row?.total ?? 0}:${row?.updated ?? ""}`;
}

// ------------------------------------------------------------------ admin
export async function adminListFlash(db: FlashDatabase, options: { limit: number; offset: number }) {
  const rows = (await db.prepare(`SELECT ${COLUMNS} FROM flash_items ORDER BY published_at DESC LIMIT ? OFFSET ?`).bind(Math.min(100, options.limit), Math.max(0, options.offset)).all<Row>()).results ?? [];
  const texts = await textsFor(db, rows.map((row) => row.id));
  const total = (await db.prepare("SELECT COUNT(*) AS n FROM flash_items").first<{ n: number }>())?.n ?? 0;
  return { total, items: rows.map((row) => toItem(row, texts.get(row.id) ?? [], "zh-Hans")).filter(Boolean) as FlashItem[] };
}

export type FlashPatch = { status?: FlashStatus; pinned?: boolean; featured?: boolean; category?: FlashCategory; cta?: FlashCta; sourceUrl?: string | null; coverUrl?: string | null; texts?: Partial<Record<FlashLocale, FlashText>> };

export function parseFlashPatch(value: unknown): FlashPatch {
  const record = value && typeof value === "object" ? value as Record<string, unknown> : {};
  const patch: FlashPatch = {};
  if (record.status === "published" || record.status === "draft" || record.status === "hidden") patch.status = record.status;
  if (typeof record.pinned === "boolean") patch.pinned = record.pinned;
  if (typeof record.featured === "boolean") patch.featured = record.featured;
  if ((FLASH_CATEGORIES as readonly string[]).includes(String(record.category))) patch.category = record.category as FlashCategory;
  if ((FLASH_CTAS as readonly string[]).includes(String(record.cta))) patch.cta = record.cta as FlashCta;
  if ("source_url" in record) patch.sourceUrl = httpUrl(record.source_url);
  if ("cover_url" in record) patch.coverUrl = httpUrl(record.cover_url);
  if (record.texts && typeof record.texts === "object") {
    patch.texts = {};
    for (const [key, block] of Object.entries(record.texts as Record<string, unknown>)) { const locale = flashLocale(key); const text = parseFlashText(block); if (locale && text) patch.texts[locale] = text; }
  }
  return patch;
}

/** Edit an item. Note: views are not editable — they are the real count. */
export async function updateFlash(db: FlashDatabase, slug: string, patch: FlashPatch, now: Date) {
  const row = await db.prepare("SELECT id FROM flash_items WHERE slug = ?").bind(slug).first<{ id: string }>();
  if (!row) throw new FlashError("NOT_FOUND");
  const sets: string[] = [], binds: unknown[] = [];
  const set = (column: string, value: unknown) => { sets.push(`${column} = ?`); binds.push(value); };
  if (patch.status) set("status", patch.status);
  if (patch.pinned !== undefined) set("pinned", patch.pinned ? 1 : 0);
  if (patch.featured !== undefined) set("featured", patch.featured ? 1 : 0);
  if (patch.category) set("category", patch.category);
  if (patch.cta) set("cta", patch.cta);
  if (patch.sourceUrl !== undefined) set("source_url", patch.sourceUrl);
  if (patch.coverUrl !== undefined) set("cover_url", patch.coverUrl);
  set("updated_at", now.toISOString());
  await db.prepare(`UPDATE flash_items SET ${sets.join(", ")} WHERE id = ?`).bind(...binds, row.id).run();
  for (const [locale, text] of Object.entries(patch.texts ?? {})) {
    await db.prepare("INSERT INTO flash_translations (flash_id, locale, title, summary, body, quote, quote_source) VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(flash_id, locale) DO UPDATE SET title = excluded.title, summary = excluded.summary, body = excluded.body, quote = excluded.quote, quote_source = excluded.quote_source")
      .bind(row.id, locale, text!.title, text!.summary, text!.body, text!.quote, text!.quoteSource).run();
  }
}

export async function deleteFlash(db: FlashDatabase, slug: string) {
  const row = await db.prepare("SELECT id FROM flash_items WHERE slug = ?").bind(slug).first<{ id: string }>();
  if (!row) throw new FlashError("NOT_FOUND");
  await db.prepare("DELETE FROM flash_translations WHERE flash_id = ?").bind(row.id).run();
  await db.prepare("DELETE FROM flash_views WHERE flash_id = ?").bind(row.id).run();
  await db.prepare("DELETE FROM flash_items WHERE id = ?").bind(row.id).run();
}

// ------------------------------------------------------------------ settings (admin-editable)
export const DEFAULT_FLASH_PROMPT = "你是一位精通东方五行、八字、易经和风水文化的专栏作者。请阅读下面这条新闻的标题和摘要，用东方传统文化的视角（五行属性、节气时令、易经卦象、阴阳消长、天时地利人和）写一条 150 字以内的快讯解读。风格：高端、沉静、略带神秘，但客观克制，不夸张、不制造恐慌。最后用一句《道德经》或《易经》（或《论语》《庄子》等经典）的原文作总结，并注明出处。然后把内容同样精炼地写成英语、日语、韩语、越南语、泰语和繁体中文。";

export const DEFAULT_FLASH_SOURCES = [
  "https://news.google.com/rss?hl=zh-CN&gl=CN&ceid=CN:zh-Hans",
  "https://news.google.com/rss/headlines/section/topic/BUSINESS?hl=zh-CN&gl=CN&ceid=CN:zh-Hans",
  "https://news.google.com/rss/headlines/section/topic/SCIENCE?hl=en-US&gl=US&ceid=US:en",
  "https://news.google.com/rss/headlines/section/topic/TECHNOLOGY?hl=en-US&gl=US&ceid=US:en",
];

export type FlashSettings = {
  auto: boolean;            // built-in news runner on/off
  publish: "auto" | "review"; // publish at once, or keep as draft for the admin to check
  intervalHours: number;    // how often the runner looks for news
  perRun: number;           // items to add per run
  dailyWisdom: boolean;     // one 国学微言 (quote of the day) item each morning
  sources: string[];        // RSS / Atom feeds
  prompt: string;           // the writing brief (the safety and JSON rules are added by the code)
};
export const DEFAULT_FLASH_SETTINGS: FlashSettings = { auto: true, publish: "auto", intervalHours: 3, perRun: 2, dailyWisdom: true, sources: DEFAULT_FLASH_SOURCES, prompt: DEFAULT_FLASH_PROMPT };

export function normalizeSettings(value: unknown): FlashSettings {
  const record = value && typeof value === "object" ? value as Record<string, unknown> : {};
  const n = (key: string, min: number, max: number, fallback: number) => { const v = Number(record[key]); return Number.isFinite(v) ? Math.min(max, Math.max(min, Math.round(v))) : fallback; };
  const sources = Array.isArray(record.sources) ? record.sources.map(httpUrl).filter(Boolean).slice(0, 12) as string[] : DEFAULT_FLASH_SOURCES;
  const prompt = typeof record.prompt === "string" && record.prompt.trim().length >= 20 ? record.prompt.trim().slice(0, 4000) : DEFAULT_FLASH_PROMPT;
  return {
    auto: typeof record.auto === "boolean" ? record.auto : DEFAULT_FLASH_SETTINGS.auto,
    publish: record.publish === "review" ? "review" : "auto",
    intervalHours: n("intervalHours", 1, 24, DEFAULT_FLASH_SETTINGS.intervalHours),
    perRun: n("perRun", 1, 5, DEFAULT_FLASH_SETTINGS.perRun),
    dailyWisdom: typeof record.dailyWisdom === "boolean" ? record.dailyWisdom : true,
    sources: sources.length ? sources : DEFAULT_FLASH_SOURCES,
    prompt,
  };
}

export async function readSettings(db: FlashDatabase) {
  const row = await db.prepare("SELECT value FROM app_settings WHERE key = 'flash.settings'").first<{ value: string }>();
  try { return normalizeSettings(row ? JSON.parse(row.value) : {}); } catch { return normalizeSettings({}); }
}
export async function writeSettings(db: FlashDatabase, settings: FlashSettings, now: Date) {
  await db.prepare("INSERT INTO app_settings (key, value, updated_at) VALUES ('flash.settings', ?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at").bind(JSON.stringify(settings), now.toISOString()).run();
}
export async function readState(db: FlashDatabase) {
  const row = await db.prepare("SELECT value FROM app_settings WHERE key = 'flash.state'").first<{ value: string }>();
  try { return (row ? JSON.parse(row.value) : {}) as { lastRun?: string; lastWisdom?: string; lastResult?: string }; } catch { return {}; }
}
export async function writeState(db: FlashDatabase, state: { lastRun?: string; lastWisdom?: string; lastResult?: string }, now: Date) {
  await db.prepare("INSERT INTO app_settings (key, value, updated_at) VALUES ('flash.state', ?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at").bind(JSON.stringify(state), now.toISOString()).run();
}

// ------------------------------------------------------------------ news feeds
export type NewsCandidate = { title: string; link: string; source: string; summary: string; published: string | null };

const decodeEntities = (text: string) => text
  .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
  .replace(/&#(\d+);/g, (_, code) => String.fromCodePoint(Number(code)))
  .replace(/&#x([0-9a-f]+);/gi, (_, code) => String.fromCodePoint(parseInt(code, 16)))
  .replace(/&quot;/g, "\"").replace(/&apos;|&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&");
const tag = (block: string, name: string) => { const match = block.match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`, "i")); return match ? decodeEntities(match[1]).replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim() : ""; };

/** RSS 2.0 <item> and Atom <entry>. Google News titles end in " - Source"; that part becomes the source name. */
export function parseFeed(xml: string, fallbackSource = ""): NewsCandidate[] {
  const blocks = xml.match(/<item[\s>][\s\S]*?<\/item>|<entry[\s>][\s\S]*?<\/entry>/gi) ?? [];
  const channel = tag(xml.replace(/<item[\s\S]*$/i, ""), "title") || fallbackSource;
  return blocks.slice(0, 40).flatMap((block) => {
    let title = tag(block, "title");
    let link = tag(block, "link");
    if (!link) link = block.match(/<link[^>]*href="([^"]+)"/i)?.[1] ?? "";
    let source = tag(block, "source");
    if (!source) { const dash = title.match(/^(.*\S)\s+[-–—]\s+([^-–—]{2,40})$/); if (dash) { title = dash[1]; source = dash[2]; } }
    else title = title.replace(new RegExp(`\\s+[-–—]\\s+${source.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`), "");
    const summary = (tag(block, "description") || tag(block, "summary")).slice(0, 400);
    const date = tag(block, "pubDate") || tag(block, "published") || tag(block, "updated");
    if (!title || !/^https?:\/\//.test(link)) return [];
    return [{ title: title.slice(0, 200), link: link.slice(0, 1000), source: (source || channel).slice(0, 80), summary: summary === title ? "" : summary, published: date && !Number.isNaN(Date.parse(date)) ? new Date(date).toISOString() : null }];
  });
}

/** Stories the brand stays away from, before even asking the model. */
const AVOID = /(死亡|身亡|遇难|丧生|罹难|命案|凶杀|谋杀|枪击|爆炸|袭击|恐袭|战争|空袭|导弹|轰炸|地震|海啸|洪灾|坠机|车祸|火灾|自杀|性侵|强奸|绑架|贩毒|选举|大选|竞选|总统候选|政党|出轨|婚外情|离婚|绯闻|去世|病逝|癌|killed|dead|death|dies|died|shooting|murder|bomb|attack|war\b|missile|airstrike|earthquake|tsunami|flood|crash|suicide|rape|assault|kidnap|election|campaign|candidate|affair|divorce|cancer)/i;
export const avoidStory = (candidate: NewsCandidate) => AVOID.test(`${candidate.title} ${candidate.summary}`);

// ------------------------------------------------------------------ the model
const RULES = `
FIXED RULES (always apply, whatever the brief above says):
- Base the piece only on the headline and summary given. Do not invent facts, numbers, quotes or names. Refer to the event as reported ("据报道…", "According to reports…").
- Never write about a real, named person's private life, relationships, marriage, affairs, sexuality, health, death, appearance or face reading, and never predict misfortune for a real person. Do not accuse anyone of wrongdoing.
- If the story is about deaths, injuries, disasters with victims, war, terrorism, crime, suicide, elections or party politics, celebrity gossip or anyone's private life: do not write it — answer {"skip": true, "reason": "..."}.
- Speak of Eastern metaphysics as a traditional cultural lens, not as fact or prediction. No guarantees, no fear, no medical, legal or investment advice (never say to buy or sell anything).
- Each language: title up to 32 characters (CJK) or 70 characters (other scripts); body 60–150 characters (CJK) or 40–110 words; written natively, not word-for-word.
- The closing quote must be a real line from a classic, quoted accurately, with the book name; give it in the original classical Chinese for zh-Hans / zh-Hant and in a faithful translation for the other languages.
OUTPUT: JSON only, no markdown:
{"skip": false, "category": "focus" | "energy", "cta": "bazi" | "daily" | "almanac" | "compatibility" | "ziwei" | "liuyao" | "meihua" | "qimen" | "zeri",
 "translations": {"zh-Hans": {"title": "", "summary": "one short sentence", "body": "", "quote": "", "quote_source": ""}, "zh-Hant": {...}, "en": {...}, "ja": {...}, "ko": {...}, "vi": {...}, "th": {...}}}
"focus" = a notable event read through the five elements / the I Ching; "energy" = markets, seasons, weather patterns, collective mood read as the energy of the time.`;

const WISDOM_BRIEF = `今天是 {date}（{term}）。请为“国学微言 · 今日金句”写一条：选一句《道德经》《易经》《论语》《庄子》《孙子兵法》或《菜根谭》中的原文，结合今日节气时令，写 80–120 字的解读，告诉读者今天可以怎样安顿身心、待人处事。语气温和、有画面感，不说教。`;

export function buildFlashMessages(brief: string, candidate: NewsCandidate | null, extra: { date: string; term?: string } = { date: "" }) {
  if (!candidate) {
    const wisdom = WISDOM_BRIEF.replace("{date}", extra.date).replace("{term}", extra.term ?? "");
    return [
      { role: "system", content: `${wisdom}\n${RULES.replace('"category": "focus" | "energy"', '"category": "wisdom"')}` },
      { role: "user", content: JSON.stringify({ task: "quote of the day", date: extra.date, solar_term: extra.term ?? null }) },
    ];
  }
  return [
    { role: "system", content: `${brief}\n${RULES}` },
    { role: "user", content: JSON.stringify({ headline: candidate.title, summary: candidate.summary, source: candidate.source, published: candidate.published }) },
  ];
}

export type ModelAnswer = { skip: true; reason: string } | { skip: false; input: FlashInput };

export function parseModelAnswer(content: string, candidate: NewsCandidate | null, status: FlashStatus): ModelAnswer {
  let value: Record<string, unknown>;
  try { value = JSON.parse(content.replace(/^```(?:json)?\s*|\s*```$/g, "")); } catch { throw new FlashError("AI_FAILED", "Model reply was not JSON"); }
  if (value.skip === true) return { skip: true, reason: clean(value.reason, 200) || "skipped" };
  const input = parseFlashInput({ ...value, status, source_url: candidate?.link, source_name: candidate?.source, category: candidate ? (value.category === "energy" ? "energy" : "focus") : "wisdom" });
  const missing = FLASH_LOCALES.filter((locale) => !input.texts[locale]);
  if (missing.length > 2) throw new FlashError("AI_FAILED", `Missing languages: ${missing.join(", ")}`);
  return { skip: false, input };
}

export async function askModel(messages: Array<{ role: string; content: string }>, apiKey: string | undefined, model: string | undefined, fetcher: Fetcher) {
  if (!apiKey?.trim()) throw new FlashError("AI_NOT_CONFIGURED");
  let response: Response;
  try {
    response = await fetcher("https://api.deepseek.com/chat/completions", {
      method: "POST",
      headers: { authorization: `Bearer ${apiKey.trim()}`, "content-type": "application/json" },
      signal: AbortSignal.timeout(120_000),
      body: JSON.stringify({ model: model?.trim() || "deepseek-chat", messages, response_format: { type: "json_object" }, temperature: 0.7, max_tokens: 4000 }),
    });
  } catch { throw new FlashError("AI_FAILED", "Model unreachable"); }
  if (!response.ok) throw new FlashError("AI_FAILED", `Model returned ${response.status}`);
  const payload = await response.json().catch(() => null) as { choices?: Array<{ message?: { content?: unknown } }> } | null;
  const content = payload?.choices?.[0]?.message?.content;
  if (typeof content !== "string") throw new FlashError("AI_FAILED", "Empty model reply");
  return content;
}

// ------------------------------------------------------------------ one run of the automatic writer
export type RunReport = { added: string[]; skipped: number; errors: string[]; wisdom: string | null; checked: number };

export async function runFlashAutomation(db: FlashDatabase, env: { DEEPSEEK_API_KEY?: string; DEEPSEEK_MODEL?: string }, options: { now: Date; fetcher?: Fetcher; force?: boolean; solarTerm?: (iso: string) => string | null }): Promise<RunReport> {
  const fetcher = options.fetcher ?? fetch;
  const settings = await readSettings(db);
  const state = await readState(db);
  const report: RunReport = { added: [], skipped: 0, errors: [], wisdom: null, checked: 0 };
  const status: FlashStatus = settings.publish === "review" ? "draft" : "published";
  const now = options.now;
  if (!options.force && !settings.auto) return report;

  // quote of the day, once a day after 06:00 Beijing time
  const beijing = new Date(now.getTime() + 8 * 3_600_000);
  const today = beijing.toISOString().slice(0, 10);
  if (settings.dailyWisdom && state.lastWisdom !== today && beijing.getUTCHours() >= 6) {
    try {
      const answer = parseModelAnswer(await askModel(buildFlashMessages(settings.prompt, null, { date: today, term: options.solarTerm?.(today) ?? undefined }), env.DEEPSEEK_API_KEY, env.DEEPSEEK_MODEL, fetcher), null, status);
      if (!answer.skip) { const made = await createFlash(db, { ...answer.input, cta: "daily", category: "wisdom" }, { origin: "auto", now, sourceKey: `wisdom-${today}` }); report.wisdom = made.slug; }
      state.lastWisdom = today;
    } catch (cause) { if (cause instanceof FlashError && cause.code === "DUPLICATE") state.lastWisdom = today; else report.errors.push(`wisdom: ${cause instanceof Error ? cause.message : String(cause)}`); }
  }

  const due = options.force || !state.lastRun || now.getTime() - Date.parse(state.lastRun) >= settings.intervalHours * 3_600_000 - 60_000;
  if (due) {
    const candidates: NewsCandidate[] = [];
    for (const url of settings.sources) {
      try {
        const response = await fetcher(url, { headers: { accept: "application/rss+xml, application/atom+xml, application/xml, text/xml", "user-agent": "Xuannova/1.0 (+https://xuannova.com)" }, signal: AbortSignal.timeout(15_000) });
        if (response.ok) candidates.push(...parseFeed(await response.text(), new URL(url).hostname));
        else report.errors.push(`${new URL(url).hostname}: ${response.status}`);
      } catch { report.errors.push(`${url.slice(0, 60)}: unreachable`); }
    }
    // newest first, recent only (36 h), one per source key, not seen before
    const fresh = candidates
      .filter((item) => !item.published || now.getTime() - Date.parse(item.published) < 36 * 3_600_000)
      .sort((a, b) => (b.published ?? "").localeCompare(a.published ?? ""));
    const unique: Array<NewsCandidate & { key: string }> = [];
    const keys = new Set<string>();
    for (const item of fresh) {
      const key = await sourceKey(item.link, item.title);
      if (keys.has(key)) continue;
      keys.add(key);
      const seen = await db.prepare("SELECT 1 AS hit FROM flash_seen WHERE source_key = ?").bind(key).first();
      if (!seen) unique.push({ ...item, key });
    }
    report.checked = unique.length;
    const mark = (key: string, decision: string) => db.prepare("INSERT OR REPLACE INTO flash_seen (source_key, decision, seen_at) VALUES (?, ?, ?)").bind(key, decision, now.toISOString()).run();
    let calls = 0;
    for (const item of unique) {
      if (report.added.length >= settings.perRun || calls >= settings.perRun + 4) break;
      if (avoidStory(item)) { await mark(item.key, "avoided"); report.skipped += 1; continue; }
      calls += 1;
      try {
        const answer = parseModelAnswer(await askModel(buildFlashMessages(settings.prompt, item), env.DEEPSEEK_API_KEY, env.DEEPSEEK_MODEL, fetcher), item, status);
        if (answer.skip) { await mark(item.key, "skipped"); report.skipped += 1; continue; }
        const made = await createFlash(db, answer.input, { origin: "auto", now, sourceKey: item.key });
        await mark(item.key, "used");
        report.added.push(made.slug);
      } catch (cause) {
        if (cause instanceof FlashError && cause.code === "AI_NOT_CONFIGURED") { report.errors.push("DEEPSEEK_API_KEY not set"); break; }
        if (cause instanceof FlashError && cause.code === "DUPLICATE") { await mark(item.key, "used"); continue; }
        report.errors.push(`${item.title.slice(0, 40)}: ${cause instanceof Error ? cause.message : String(cause)}`);
      }
    }
    state.lastRun = now.toISOString();
    // the seen-list only needs to remember a few days
    await db.prepare("DELETE FROM flash_seen WHERE seen_at < ?").bind(new Date(now.getTime() - 10 * 86_400_000).toISOString()).run();
  }
  state.lastResult = `${now.toISOString()} · +${report.added.length}${report.wisdom ? " +1 quote" : ""} · skipped ${report.skipped}${report.errors.length ? ` · ${report.errors.length} error(s)` : ""}`;
  await writeState(db, state, now);
  return report;
}

// ------------------------------------------------------------------ sitemap
export async function flashSitemap(db: FlashDatabase, site: string, now: Date) {
  const rows = (await db.prepare("SELECT id, slug, updated_at FROM flash_items WHERE status = 'published' AND published_at <= ? ORDER BY published_at DESC LIMIT 2000").bind(now.toISOString()).all<{ id: string; slug: string; updated_at: string }>()).results ?? [];
  const texts = await textsFor(db, rows.map((row) => row.id));
  const prefix = (locale: FlashLocale) => (locale === "en" ? "" : `/${locale.toLowerCase()}`);
  const hreflang = (locale: FlashLocale) => locale;
  const escape = (text: string) => text.replace(/&/g, "&amp;").replace(/</g, "&lt;");
  const urls = rows.flatMap((row) => {
    const locales = (texts.get(row.id) ?? []).map((text) => text.locale as FlashLocale);
    return locales.map((locale) => `<url><loc>${escape(`${site}${prefix(locale)}/flash/${row.slug}`)}</loc><lastmod>${row.updated_at.slice(0, 10)}</lastmod>${locales.map((other) => `<xhtml:link rel="alternate" hreflang="${hreflang(other)}" href="${escape(`${site}${prefix(other)}/flash/${row.slug}`)}"/>`).join("")}</url>`);
  });
  const timelines = FLASH_LOCALES.map((locale) => `<url><loc>${site}${prefix(locale)}/flash</loc><changefreq>hourly</changefreq></url>`);
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">${[...timelines, ...urls].join("")}</urlset>`;
}
