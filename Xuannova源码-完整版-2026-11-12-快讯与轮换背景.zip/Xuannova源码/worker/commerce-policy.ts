/**
 * Owner-defined commerce policy shared by the worker and the browser.
 *
 * Payments are made on BNB Smart Chain (BSC) through the XuanyuanCreditStore
 * contract (see contracts/XuanyuanCreditStore.sol). The buyer pays the package
 * price in USDT (BEP20) plus a flat platform fee in BNB.
 */
export type ChainConfig = {
  id: number;
  hexId: string;
  name: string;
  nativeSymbol: string;
  rpcUrls: readonly string[];
  explorerUrl: string;
  /** USDT (BEP20) token contract. 18 decimals on both BSC networks. */
  usdtAddress: string;
  usdtDecimals: number;
  /** Minimum confirmations before a purchase is credited. */
  confirmations: number;
  testnet: boolean;
};

export const bscMainnet: ChainConfig = {
  id: 56,
  hexId: "0x38",
  name: "BNB Smart Chain",
  nativeSymbol: "BNB",
  rpcUrls: ["https://bsc-dataseed.binance.org", "https://bsc-dataseed1.bnbchain.org", "https://rpc.ankr.com/bsc"],
  explorerUrl: "https://bscscan.com",
  usdtAddress: "0x55d398326f99059fF775485246999027B3197955",
  usdtDecimals: 18,
  confirmations: 3,
  testnet: false,
};

/**
 * BSC testnet for rehearsals. There is no official Tether there: deploy
 * contracts/TestUSDT.sol and set USDT_ADDRESS to its address (BSC_CHAIN_ID=97).
 * Free tBNB: https://www.bnbchain.org/en/testnet-faucet
 */
export const bscTestnet: ChainConfig = {
  id: 97,
  hexId: "0x61",
  name: "BNB Smart Chain Testnet",
  nativeSymbol: "tBNB",
  rpcUrls: ["https://data-seed-prebsc-1-s1.bnbchain.org:8545", "https://bsc-testnet-rpc.publicnode.com", "https://bsc-testnet.public.blastapi.io"],
  explorerUrl: "https://testnet.bscscan.com",
  usdtAddress: "",
  usdtDecimals: 18,
  confirmations: 2,
  testnet: true,
};

export const bscChains: Record<number, ChainConfig> = { 56: bscMainnet, 97: bscTestnet };

/** Default chain (mainnet). The worker may select another via BSC_CHAIN_ID. */
export const bscChain = bscMainnet;

export function chainById(id: number | string | undefined | null): ChainConfig | null {
  const parsed = typeof id === "string" ? Number.parseInt(id, 10) : id;
  return parsed && bscChains[parsed] ? bscChains[parsed] : null;
}

/**
 * Deployed XuanyuanCreditStore contract. Leave empty until the owner deploys
 * the contract; the checkout stays disabled while it is empty.
 * Can be overridden at runtime with the CREDIT_STORE_ADDRESS environment
 * variable on the worker and NEXT_PUBLIC_CREDIT_STORE_ADDRESS in the browser.
 */
export const creditStoreAddress = "";

/** Flat platform fee attached to every purchase: 0.00007 BNB. */
export const platformFeeBnb = "0.00007";
export const platformFeeWei = 70_000_000_000_000n;

/** Owner wallets used as XuanyuanCreditStore constructor arguments. */
export const treasuryAddress = "0x9E946751c432E4FCd05C463956122793ab64202e";
export const platformFeeRecipient = "0xf749AcaB0be460667Bd15922b48c821E4Fb3c13d";

/** Manual-transfer channels (original flow, reviewed by an administrator). */
export const paymentNetworks = [
  {
    id: "trc20",
    label: "USDT · TRON (TRC20)",
    address: "TMkFTkWbkjnUpCTiYx87QyTTjXiS2ogGqi",
    qrImage: "/payments/usdt-trc20.svg",
  },
  {
    id: "bsc",
    label: "USDT · BNB Chain (BEP20)",
    address: "0x9E946751c432E4FCd05C463956122793ab64202e",
    qrImage: "/payments/usdt-bsc-bep20.svg",
  },
  {
    id: "erc20",
    label: "USDC / USDT · Ethereum (ERC20)",
    address: "0x84F33708ab4b7DEFd9Be5EC50911797E34009caA",
    qrImage: "/payments/ethereum-erc20.svg",
  },
  {
    id: "solana",
    label: "USDC / USDT · Solana (SPL)",
    address: "BzDaU6VKyMtN14QeVuCMva2SGmHLeeYy2GAAG9muJNq2",
    qrImage: "/payments/solana-spl.svg",
  },
] as const;

export const creditPackages = [
  { id: "seed", name: "入门体验包", usdt: "4.99", credits: 20 },
  { id: "path", name: "热门套餐", usdt: "9.90", credits: 50 },
  { id: "ritual", name: "大容量套餐", usdt: "19.90", credits: 120 },
  { id: "synthesis", name: "至尊旗舰套餐", usdt: "39.90", credits: 280 },
] as const;

/** Extra credits on a member's first completed purchase (settled once, server-side; on-chain prices unchanged). */
export const firstPurchaseBonusCredits = 20;

export const walletProviders = [
  { id: "metamask", label: "MetaMask" },
  { id: "tokenpocket", label: "TokenPocket" },
  { id: "binance", label: "Binance Web3 Wallet" },
  { id: "okx", label: "OKX Wallet" },
] as const;

export type WalletProviderId = (typeof walletProviders)[number]["id"];
export type PaymentNetworkId = (typeof paymentNetworks)[number]["id"];
export type CreditPackageId = (typeof creditPackages)[number]["id"];

export function packageById(id: string) {
  return creditPackages.find((item) => item.id === id);
}

/** USDT amount of a package expressed in token base units (18 decimals). */
export function packageUsdtWei(id: CreditPackageId | string) {
  const item = packageById(id);
  if (!item) return 0n;
  const [whole, fraction = ""] = item.usdt.split(".");
  const padded = (fraction + "0".repeat(bscChain.usdtDecimals)).slice(0, bscChain.usdtDecimals);
  return BigInt(whole) * 10n ** BigInt(bscChain.usdtDecimals) + BigInt(padded);
}

/** Credits per full reading: the BaZi deep reading (twice the length) costs 40, everything else 20. */
export function interpretationCost(tool: string) {
  return tool === "detail" ? 40 : 20;
}
