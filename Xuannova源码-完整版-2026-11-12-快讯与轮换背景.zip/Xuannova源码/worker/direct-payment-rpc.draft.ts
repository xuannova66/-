/** Read-only draft. Not connected to checkout, credits, wallets or jobs.
 * RPC calls and parser output are NOT proof that a user is authenticated;
 * expectations must be obtained from a server-created, authenticated order.
 * The RPC provider is a trusted operational dependency.
 */
import { inspectSolanaDirectPayment, type SolanaDirectExpected, type SolanaParsedTx } from "./solana-direct-payment.draft";
import { inspectTronDirectPayment, type TronBody, type TronReceipt, type TronDirectExpected } from "./tron-direct-payment.draft";

const SOLANA_MAINNET_GENESIS = "5eykt4UsFv8P8NJdTREpY1vzqKqZKvdpKuc147dw2N9d";
const SOLANA_RPC = "https://api.mainnet-beta.solana.com";
const TRON_RPC = "https://api.trongrid.io";
type Fetcher = (input: string, init: RequestInit) => Promise<Response>;

async function post(url: string, payload: unknown, fetcher: Fetcher): Promise<unknown> {
  const response = await fetcher(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload), signal: AbortSignal.timeout(12_000) });
  if (!response.ok) throw new Error("CHAIN_RPC_UNAVAILABLE");
  try { return await response.json(); } catch { throw new Error("INVALID_CHAIN_RESPONSE"); }
}

async function solanaCall(method: string, params: unknown[], fetcher: Fetcher): Promise<unknown> {
  const response = await post(SOLANA_RPC, { jsonrpc: "2.0", id: 1, method, params }, fetcher) as { jsonrpc?: string; id?: number; error?: unknown; result?: unknown };
  if (!response || response.jsonrpc !== "2.0" || response.id !== 1 || response.error || !("result" in response)) throw new Error("INVALID_CHAIN_RESPONSE");
  return response.result;
}

export async function inspectSolanaDirectFromRpc(expected: SolanaDirectExpected, fetcher: Fetcher = fetch) {
  if (!/^[1-9A-HJ-NP-Za-km-z]{64,88}$/.test(expected.signature)) throw new Error("INVALID_SIGNATURE");
  if (await solanaCall("getGenesisHash", [], fetcher) !== SOLANA_MAINNET_GENESIS) throw new Error("WRONG_CHAIN");
  const statuses = await solanaCall("getSignatureStatuses", [[expected.signature], { searchTransactionHistory: true }], fetcher) as { value?: Array<{ confirmationStatus?: string; err?: unknown } | null> };
  const status = statuses?.value?.[0];
  if (!status || status.confirmationStatus !== "finalized" || status.err !== null) throw new Error("TRANSACTION_NOT_FINAL_SUCCESS");
  const tx = await solanaCall("getTransaction", [expected.signature, { encoding: "jsonParsed", commitment: "finalized", maxSupportedTransactionVersion: 0 }], fetcher) as SolanaParsedTx | null;
  if (!tx) throw new Error("TRANSACTION_NOT_FOUND");
  return inspectSolanaDirectPayment(tx, true, expected);
}

export async function inspectTronDirectFromRpc(expected: TronDirectExpected, fetcher: Fetcher = fetch) {
  if (!/^[a-fA-F0-9]{64}$/.test(expected.txId)) throw new Error("INVALID_TRANSACTION_ID");
  const payload = { value: expected.txId.toLowerCase() };
  const [body, receipt] = await Promise.all([
    post(`${TRON_RPC}/walletsolidity/gettransactionbyid`, payload, fetcher),
    post(`${TRON_RPC}/walletsolidity/gettransactioninfobyid`, payload, fetcher),
  ]);
  if (!body || !receipt || typeof body !== "object" || typeof receipt !== "object") throw new Error("INVALID_CHAIN_RESPONSE");
  return inspectTronDirectPayment(body as TronBody, receipt as TronReceipt, true, expected);
}
