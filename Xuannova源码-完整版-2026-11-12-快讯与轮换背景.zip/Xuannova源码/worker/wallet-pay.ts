// Wallet payments on Ethereum (USDC, USDT), Solana (USDC, USDT) and TRON (USDT): the server creates an order with a
// random reference, the member's wallet sends a direct transfer that carries the reference (Ethereum: appended to the
// ERC-20 transfer call data, which the token ignores; Solana: memo; TRON: transaction data),
// and the server credits the package only after the transfer is final on chain and matches the order exactly.
import { packageSettlement } from "./multichain-policy";
import { inspectSolanaDirectPayment, type SolanaParsedTx } from "./solana-direct-payment.draft";
import { inspectTronDirectPayment, type TronBody, type TronReceipt } from "./tron-direct-payment.draft";
import { isSolanaAddress, isSolanaSignature, tronToHex } from "../app/chain-lite";

export type WalletPayChain = "solana" | "tron" | "ethereum";
export type WalletPayEnv = { ETHEREUM_RPC_URL?: string; ETHEREUM_CONFIRMATIONS?: string; SOLANA_RPC_URL?: string; TRON_API_URL?: string; TRON_API_KEY?: string; WALLET_PAY_ENABLED?: string };
type Fetcher = (input: string, init: RequestInit) => Promise<Response>;

export const SOLANA_ASSETS = {
  USDC: { mint: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", decimals: 6 },
  USDT: { mint: "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB", decimals: 6 },
} as const;
export const TRON_USDT = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t";
export const ETHEREUM_ASSETS = {
  USDC: { token: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48", decimals: 6 },
  USDT: { token: "0xdac17f958d2ee523a2206206994597c13d831ec7", decimals: 6 },
} as const;
const TRANSFER_TOPIC = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";
const pad32 = (hex: string) => hex.replace(/^0x/i, "").toLowerCase().padStart(64, "0");
/** ERC-20 transfer(recipient, amount) with the 32-byte order reference appended. */
export const ethereumTransferData = (recipient: string, amountUnits: bigint, reference: string) => `0xa9059cbb${pad32(recipient)}${pad32(amountUnits.toString(16))}${reference.toLowerCase()}`;
const SOLANA_MAINNET_GENESIS = "5eykt4UsFv8P8NJdTREpY1vzqKqZKvdpKuc147dw2N9d";

/** Extra facts for the member when a payment cannot start: what the wallet holds on this chain and what is needed. */
export type WalletPayDetail = { chain: WalletPayChain; buyer: string; asset: string; have: string; need: string; decimals: number; other?: { asset: string; have: string }; gas?: string; gasHave?: string; gasNeed?: string };
export class WalletPayError extends Error {
  constructor(public readonly code: string, public readonly status = 400, public readonly detail?: WalletPayDetail) { super(code); }
}
/** Base units to a short decimal string (e.g. 4990000, 6 → "4.99"). */
export function unitsToText(units: bigint, decimals: number, places = 4) {
  const negative = units < 0n; const value = negative ? -units : units;
  const scale = 10n ** BigInt(decimals);
  const whole = value / scale;
  const fraction = (value % scale).toString().padStart(decimals, "0").slice(0, places).replace(/0+$/, "");
  return `${negative ? "-" : ""}${whole}${fraction ? `.${fraction}` : ""}`;
}

export const walletPayEnabled = (env: WalletPayEnv) => env.WALLET_PAY_ENABLED !== "false";

async function postJson(url: string, payload: unknown, fetcher: Fetcher, headers: Record<string, string> = {}) {
  let response: Response;
  try { response = await fetcher(url, { method: "POST", headers: { "content-type": "application/json", ...headers }, body: JSON.stringify(payload), signal: AbortSignal.timeout(12_000) }); }
  catch { throw new WalletPayError("CHAIN_RPC_UNAVAILABLE", 503); }
  if (!response.ok) throw new WalletPayError("CHAIN_RPC_UNAVAILABLE", 503);
  try { return await response.json() as unknown; } catch { throw new WalletPayError("CHAIN_RPC_UNAVAILABLE", 503); }
}

export async function solanaRpc<T>(env: WalletPayEnv, method: string, params: unknown[], fetcher: Fetcher = fetch): Promise<T> {
  const url = env.SOLANA_RPC_URL?.trim() || "https://api.mainnet-beta.solana.com";
  const body = await postJson(url, { jsonrpc: "2.0", id: 1, method, params }, fetcher) as { result?: T; error?: unknown };
  if (!body || body.error || !("result" in body)) throw new WalletPayError("CHAIN_RPC_UNAVAILABLE", 503);
  return body.result as T;
}

export async function ethereumRpc<T>(env: WalletPayEnv, method: string, params: unknown[], fetcher: Fetcher = fetch): Promise<T> {
  const url = env.ETHEREUM_RPC_URL?.trim() || "https://ethereum-rpc.publicnode.com";
  const body = await postJson(url, { jsonrpc: "2.0", id: 1, method, params }, fetcher) as { result?: T; error?: unknown };
  if (!body || body.error || !("result" in body)) throw new WalletPayError("CHAIN_RPC_UNAVAILABLE", 503);
  return body.result as T;
}

type TokenAccount = { pubkey: string; account: { data: { parsed: { info: { owner: string; mint: string; tokenAmount: { amount: string; decimals: number } } } }; owner: string } };

/** Token accounts of `owner` for `mint` (classic SPL program only), largest balance first. */
async function solanaTokenAccounts(env: WalletPayEnv, owner: string, mint: string, fetcher?: Fetcher) {
  const result = await solanaRpc<{ value: TokenAccount[] }>(env, "getTokenAccountsByOwner", [owner, { mint }, { encoding: "jsonParsed", commitment: "confirmed" }], fetcher);
  return (result?.value ?? [])
    .filter((item) => item.account?.owner === "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA" && item.account.data?.parsed?.info?.mint === mint && item.account.data.parsed.info.owner === owner)
    .map((item) => ({ address: item.pubkey, amount: BigInt(item.account.data.parsed.info.tokenAmount.amount) }))
    .sort((a, b) => (b.amount > a.amount ? 1 : b.amount < a.amount ? -1 : 0));
}

type Statement = { bind(...values: unknown[]): Statement; first<T>(): Promise<T | null>; run(): Promise<{ meta?: { changes?: number } }> };
type Database = { prepare(sql: string): Statement };
export type WalletPayOrder = { id: string; member_id: string; chain: WalletPayChain; package_id: string; credits: number; asset: string; buyer: string; recipient: string; recipient_account: string | null; amount_units: string; reference: string; status: "pending" | "credited"; signature: string | null; payment_order_id: string | null };

function randomReference() {
  return [...crypto.getRandomValues(new Uint8Array(32))].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

/** Create an order. Solana also returns the token accounts and a recent blockhash for building the transaction. */
export async function createWalletPayOrder(db: Database, env: WalletPayEnv, input: { memberId: string; chain: WalletPayChain; asset: string; packageId: string; buyer: string; now: string }, fetcher: Fetcher = fetch) {
  const terms = packageSettlement(input.chain, input.packageId);
  const pending = await db.prepare("SELECT COUNT(*) AS count FROM wallet_pay_orders WHERE member_id = ? AND status = 'pending' AND created_at > ?").bind(input.memberId, new Date(Date.parse(input.now) - 86_400_000).toISOString()).first<{ count: number }>();
  if ((pending?.count ?? 0) >= 30) throw new WalletPayError("TOO_MANY_PENDING_ORDERS", 429);
  const id = crypto.randomUUID();
  const reference = randomReference();
  if (input.chain === "solana") {
    const asset = SOLANA_ASSETS[input.asset as keyof typeof SOLANA_ASSETS];
    if (!asset) throw new WalletPayError("UNSUPPORTED_ASSET");
    if (!isSolanaAddress(input.buyer)) throw new WalletPayError("INVALID_WALLET");
    const otherAsset = input.asset === "USDC" ? "USDT" : "USDC";
    const [recipientAccounts, buyerAccounts, blockhash, otherAccounts, lamports] = await Promise.all([
      solanaTokenAccounts(env, terms.recipient, asset.mint, fetcher),
      solanaTokenAccounts(env, input.buyer, asset.mint, fetcher),
      solanaRpc<{ value: { blockhash: string } }>(env, "getLatestBlockhash", [{ commitment: "finalized" }], fetcher),
      solanaTokenAccounts(env, input.buyer, SOLANA_ASSETS[otherAsset].mint, fetcher).catch(() => []),
      solanaRpc<{ value: number }>(env, "getBalance", [input.buyer, { commitment: "confirmed" }], fetcher).then((result) => BigInt(result?.value ?? 0)).catch(() => null),
    ]);
    if (!recipientAccounts.length) throw new WalletPayError("RECIPIENT_NOT_READY", 409);
    const source = buyerAccounts[0];
    const detail: WalletPayDetail = { chain: "solana", buyer: input.buyer, asset: input.asset, have: unitsToText(source?.amount ?? 0n, asset.decimals), need: unitsToText(terms.amountUnits, asset.decimals), decimals: asset.decimals, other: { asset: otherAsset, have: unitsToText(otherAccounts[0]?.amount ?? 0n, 6) } };
    if (!source || source.amount < terms.amountUnits) throw new WalletPayError("INSUFFICIENT_BALANCE", 409, detail);
    // The transfer fee (about 0.000005 SOL) is paid in SOL; an empty SOL balance makes the wallet fail.
    const minLamports = 10_000n;
    if (lamports !== null && lamports < minLamports) throw new WalletPayError("INSUFFICIENT_GAS", 409, { ...detail, gas: "SOL", gasHave: unitsToText(lamports, 9, 6), gasNeed: unitsToText(minLamports, 9, 6) });
    await db.prepare("INSERT INTO wallet_pay_orders (id, member_id, chain, package_id, credits, asset, buyer, recipient, recipient_account, amount_units, reference, created_at) VALUES (?, ?, 'solana', ?, ?, ?, ?, ?, ?, ?, ?, ?)")
      .bind(id, input.memberId, terms.packageId, terms.credits, input.asset, input.buyer, terms.recipient, recipientAccounts[0].address, terms.amountUnits.toString(), reference, input.now).run();
    return { orderId: id, chain: "solana" as const, reference, asset: input.asset, mint: asset.mint, decimals: asset.decimals, amountUnits: terms.amountUnits.toString(), recipient: terms.recipient, source: source.address, destination: recipientAccounts[0].address, recentBlockhash: blockhash.value.blockhash };
  }
  if (input.chain === "ethereum") {
    const asset = ETHEREUM_ASSETS[input.asset as keyof typeof ETHEREUM_ASSETS];
    if (!asset) throw new WalletPayError("UNSUPPORTED_ASSET");
    if (!/^0x[0-9a-fA-F]{40}$/.test(input.buyer)) throw new WalletPayError("INVALID_WALLET");
    const buyer = input.buyer.toLowerCase();
    const otherAsset = input.asset === "USDC" ? "USDT" : "USDC";
    const hexValue = (value: string | null | undefined) => (/^0x[0-9a-fA-F]+$/.test(value ?? "") ? BigInt(value as string) : 0n);
    const [chainId, balance, otherBalance, ether, gasPrice] = await Promise.all([
      ethereumRpc<string>(env, "eth_chainId", [], fetcher),
      ethereumRpc<string>(env, "eth_call", [{ to: asset.token, data: `0x70a08231${pad32(buyer)}` }, "latest"], fetcher),
      ethereumRpc<string>(env, "eth_call", [{ to: ETHEREUM_ASSETS[otherAsset].token, data: `0x70a08231${pad32(buyer)}` }, "latest"], fetcher).catch(() => "0x0"),
      ethereumRpc<string>(env, "eth_getBalance", [buyer, "latest"], fetcher).catch(() => null),
      ethereumRpc<string>(env, "eth_gasPrice", [], fetcher).catch(() => null),
    ]);
    if (Number.parseInt(chainId, 16) !== 1) throw new WalletPayError("WRONG_CHAIN", 503);
    if (!/^0x[0-9a-fA-F]*$/.test(balance ?? "")) throw new WalletPayError("CHAIN_RPC_UNAVAILABLE", 503);
    const have = hexValue(balance);
    const detail: WalletPayDetail = { chain: "ethereum", buyer, asset: input.asset, have: unitsToText(have, asset.decimals), need: unitsToText(terms.amountUnits, asset.decimals), decimals: asset.decimals, other: { asset: otherAsset, have: unitsToText(hexValue(otherBalance), 6) } };
    if (have < terms.amountUnits) throw new WalletPayError("INSUFFICIENT_BALANCE", 409, detail);
    // A token transfer with the reference costs about 70,000 gas, paid in ETH.
    if (ether !== null && gasPrice !== null) {
      const gasNeed = hexValue(gasPrice) * 70_000n;
      if (hexValue(ether) < gasNeed) throw new WalletPayError("INSUFFICIENT_GAS", 409, { ...detail, gas: "ETH", gasHave: unitsToText(hexValue(ether), 18, 6), gasNeed: unitsToText(gasNeed, 18, 6) });
    }
    await db.prepare("INSERT INTO wallet_pay_orders (id, member_id, chain, package_id, credits, asset, buyer, recipient, recipient_account, amount_units, reference, created_at) VALUES (?, ?, 'ethereum', ?, ?, ?, ?, ?, NULL, ?, ?, ?)")
      .bind(id, input.memberId, terms.packageId, terms.credits, input.asset, buyer, terms.recipient, terms.amountUnits.toString(), reference, input.now).run();
    return { orderId: id, chain: "ethereum" as const, reference, asset: input.asset, token: asset.token, decimals: asset.decimals, amountUnits: terms.amountUnits.toString(), recipient: terms.recipient, chainId: "0x1", data: ethereumTransferData(terms.recipient, terms.amountUnits, reference) };
  }
  if (input.asset !== "USDT") throw new WalletPayError("UNSUPPORTED_ASSET");
  try { await tronToHex(input.buyer); } catch { throw new WalletPayError("INVALID_WALLET"); }
  const tron = await tronBalances(env, input.buyer, fetcher);
  if (tron) {
    const detail: WalletPayDetail = { chain: "tron", buyer: input.buyer, asset: "USDT", have: unitsToText(tron.usdt, 6), need: unitsToText(terms.amountUnits, 6), decimals: 6 };
    if (tron.usdt < terms.amountUnits) throw new WalletPayError("INSUFFICIENT_BALANCE", 409, detail);
    // A USDT transfer burns TRX for energy when the account has none staked (typically 7–30 TRX). Below 1 TRX it cannot go through.
    if (tron.trx < 1_000_000n) throw new WalletPayError("INSUFFICIENT_GAS", 409, { ...detail, gas: "TRX", gasHave: unitsToText(tron.trx, 6, 2), gasNeed: "15" });
  }
  await db.prepare("INSERT INTO wallet_pay_orders (id, member_id, chain, package_id, credits, asset, buyer, recipient, recipient_account, amount_units, reference, created_at) VALUES (?, ?, 'tron', ?, ?, 'USDT', ?, ?, NULL, ?, ?, ?)")
    .bind(id, input.memberId, terms.packageId, terms.credits, input.buyer, terms.recipient, terms.amountUnits.toString(), reference, input.now).run();
  return { orderId: id, chain: "tron" as const, reference, asset: "USDT", token: TRON_USDT, decimals: 6, amountUnits: terms.amountUnits.toString(), recipient: terms.recipient };
}

/** USDT and TRX balances of a TRON account (base units). Null when TronGrid cannot be reached: the payment then goes ahead unchecked. */
async function tronBalances(env: WalletPayEnv, address: string, fetcher: Fetcher = fetch): Promise<{ usdt: bigint; trx: bigint } | null> {
  const base = (env.TRON_API_URL?.trim() || "https://api.trongrid.io").replace(/\/$/, "");
  const headers: Record<string, string> = env.TRON_API_KEY?.trim() ? { "TRON-PRO-API-KEY": env.TRON_API_KEY.trim() } : {};
  try {
    const response = await fetcher(`${base}/v1/accounts/${address}`, { method: "GET", headers, signal: AbortSignal.timeout(8_000) });
    if (!response.ok) return null;
    const body = await response.json() as { success?: boolean; data?: Array<{ balance?: number; trc20?: Array<Record<string, string>> }> };
    if (!body || !Array.isArray(body.data)) return null;
    const account = body.data[0];
    if (!account) return { usdt: 0n, trx: 0n }; // never activated: holds nothing
    const usdt = (account.trc20 ?? []).map((item) => item[TRON_USDT]).find((value) => typeof value === "string" && /^\d+$/.test(value));
    return { usdt: BigInt(usdt ?? "0"), trx: BigInt(Math.max(0, Math.floor(account.balance ?? 0))) };
  } catch { return null; }
}

/** Check the transaction for an order. Returns "pending" while the chain has not finalised it yet. */
export async function verifyWalletPayment(env: WalletPayEnv, order: WalletPayOrder, transactionId: string, fetcher: Fetcher = fetch): Promise<"verified" | "pending"> {
  // The order's own terms are checked against the chain: they were fixed from the price list when the order was
  // created, so a later price or address change never strands a payment that was already sent.
  if (!/^\d+$/.test(order.amount_units) || BigInt(order.amount_units) <= 0n || !(order.credits > 0)) throw new WalletPayError("ORDER_TERMS_MISMATCH", 409);
  try {
    if (order.chain === "solana") {
      if (!isSolanaSignature(transactionId)) throw new WalletPayError("INVALID_TRANSACTION");
      const asset = SOLANA_ASSETS[order.asset as keyof typeof SOLANA_ASSETS];
      if (!asset || !order.recipient_account) throw new WalletPayError("ORDER_TERMS_MISMATCH", 409);
      if (await solanaRpc<string>(env, "getGenesisHash", [], fetcher) !== SOLANA_MAINNET_GENESIS) throw new WalletPayError("WRONG_CHAIN", 503);
      const statuses = await solanaRpc<{ value: Array<{ confirmationStatus?: string; err?: unknown } | null> }>(env, "getSignatureStatuses", [[transactionId], { searchTransactionHistory: true }], fetcher);
      const status = statuses?.value?.[0];
      if (!status) return "pending";
      if (status.err) throw new WalletPayError("TRANSACTION_FAILED");
      if (status.confirmationStatus !== "finalized") return "pending";
      const tx = await solanaRpc<SolanaParsedTx | null>(env, "getTransaction", [transactionId, { encoding: "jsonParsed", commitment: "finalized", maxSupportedTransactionVersion: 0 }], fetcher);
      if (!tx) return "pending";
      inspectSolanaDirectPayment(tx, true, { signature: transactionId, buyer: order.buyer, recipient: order.recipient, recipientTokenAccount: order.recipient_account, mint: asset.mint, decimals: asset.decimals, amountUnits: BigInt(order.amount_units), orderReference: order.reference });
      return "verified";
    }
    if (order.chain === "ethereum") {
      if (!/^0x[0-9a-fA-F]{64}$/.test(transactionId)) throw new WalletPayError("INVALID_TRANSACTION");
      const asset = ETHEREUM_ASSETS[order.asset as keyof typeof ETHEREUM_ASSETS];
      if (!asset) throw new WalletPayError("ORDER_TERMS_MISMATCH", 409);
      const hash = transactionId.toLowerCase();
      const [chainId, tx, receipt, head] = await Promise.all([
        ethereumRpc<string>(env, "eth_chainId", [], fetcher),
        ethereumRpc<{ from: string; to: string | null; input: string; hash: string } | null>(env, "eth_getTransactionByHash", [hash], fetcher),
        ethereumRpc<{ status: string; blockNumber: string; logs: Array<{ address: string; topics: string[]; data: string; removed?: boolean }> } | null>(env, "eth_getTransactionReceipt", [hash], fetcher),
        ethereumRpc<string>(env, "eth_blockNumber", [], fetcher),
      ]);
      if (Number.parseInt(chainId, 16) !== 1) throw new WalletPayError("WRONG_CHAIN", 503);
      if (!tx || !receipt) return "pending";
      if (receipt.status !== "0x1") throw new WalletPayError("TRANSACTION_FAILED");
      const needed = Math.max(1, Number(env.ETHEREUM_CONFIRMATIONS ?? 12) || 12);
      if (BigInt(head) - BigInt(receipt.blockNumber) + 1n < BigInt(needed)) return "pending";
      const amount = BigInt(order.amount_units);
      if (tx.hash?.toLowerCase() !== hash || tx.from?.toLowerCase() !== order.buyer.toLowerCase() || tx.to?.toLowerCase() !== asset.token) throw new WalletPayError("PAYMENT_MISMATCH", 409);
      if (tx.input?.toLowerCase() !== ethereumTransferData(order.recipient, amount, order.reference)) throw new WalletPayError("PAYMENT_MISMATCH", 409);
      const transfers = receipt.logs.filter((log) => !log.removed && log.address?.toLowerCase() === asset.token && log.topics?.length === 3 && log.topics[0]?.toLowerCase() === TRANSFER_TOPIC
        && log.topics[1]?.toLowerCase() === `0x${pad32(order.buyer)}` && log.topics[2]?.toLowerCase() === `0x${pad32(order.recipient)}` && /^0x[0-9a-fA-F]{1,64}$/.test(log.data) && BigInt(log.data) === amount);
      if (transfers.length !== 1) throw new WalletPayError("PAYMENT_MISMATCH", 409);
      return "verified";
    }
    if (!/^[a-fA-F0-9]{64}$/.test(transactionId)) throw new WalletPayError("INVALID_TRANSACTION");
    const base = (env.TRON_API_URL?.trim() || "https://api.trongrid.io").replace(/\/$/, "");
    const headers: Record<string, string> = env.TRON_API_KEY?.trim() ? { "TRON-PRO-API-KEY": env.TRON_API_KEY.trim() } : {};
    const payload = { value: transactionId.toLowerCase() };
    const [body, receipt] = await Promise.all([postJson(`${base}/walletsolidity/gettransactionbyid`, payload, fetcher, headers), postJson(`${base}/walletsolidity/gettransactioninfobyid`, payload, fetcher, headers)]) as [TronBody | Record<string, never>, TronReceipt | Record<string, never>];
    if (!body || !("txID" in body) || !receipt || !("id" in receipt)) return "pending";
    inspectTronDirectPayment(body as TronBody, receipt as TronReceipt, true, { txId: transactionId, buyerHex: await tronToHex(order.buyer), recipientHex: await tronToHex(order.recipient), tokenHex: await tronToHex(TRON_USDT), amountUnits: BigInt(order.amount_units), orderReference: order.reference });
    return "verified";
  } catch (cause) {
    if (cause instanceof WalletPayError) throw cause;
    const message = cause instanceof Error ? cause.message : "VERIFICATION_FAILED";
    if (message === "TRANSACTION_NOT_FINAL_SUCCESS") throw new WalletPayError("TRANSACTION_FAILED");
    throw new WalletPayError(message === "CHAIN_RPC_UNAVAILABLE" ? message : "PAYMENT_MISMATCH", message === "CHAIN_RPC_UNAVAILABLE" ? 503 : 409);
  }
}
