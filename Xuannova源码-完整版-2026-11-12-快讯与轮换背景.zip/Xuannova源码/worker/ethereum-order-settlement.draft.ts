/** Local research only. The caller must authenticate memberId and supply a
 * server-configured, independently verified checkout, token and RPC client.
 * This is not enabled for the production checkout or existing BSC contracts.
 */
import { bytesToHex, getAddress, type Address, type Hex } from "viem";
import { packageSettlement } from "./multichain-policy";
import { inspectEvmCheckoutReceipt } from "./evm-checkout-proof.draft";

type Statement = { bind(...values:unknown[]):Statement; first<T>():Promise<T|null>; run():Promise<{meta?:{changes?:number}}> };
type Database = { prepare(sql:string):Statement };
type Receipt = {status:"success"|"reverted"; transactionHash:Hex; blockNumber:bigint; blockHash:Hex; logs: readonly {address:Address; data:Hex; topics:readonly Hex[]; logIndex:number}[]};
export type EthereumDraftRpc = {getChainId():Promise<number>; getBlockNumber():Promise<bigint>; getBlock(input:{blockTag:"finalized"}|{blockNumber:bigint}):Promise<{number:bigint|null; hash:Hex|null}>; getTransactionReceipt(input:{hash:Hex}):Promise<Receipt>};
type Order = {id:string; member_id:string; chain:string; package_id:string; credits:number; buyer:string; recipient:string; settlement_asset:string; amount_units:string; order_reference:string; status:string; transaction_id:string|null};

export async function createEthereumDraftOrder(db:Database,input:{memberId:string; buyer:Address; packageId:string; settlementToken:Address; now:string}) {
  const buyer=getAddress(input.buyer), token=getAddress(input.settlementToken);
  const linked=await db.prepare("SELECT id FROM members WHERE id=? AND wallet_address=? COLLATE NOCASE").bind(input.memberId,buyer).first<{id:string}>();
  if (!linked) throw new Error("WALLET_NOT_LINKED");
  const terms=packageSettlement("ethereum",input.packageId), id=crypto.randomUUID(), reference=bytesToHex(crypto.getRandomValues(new Uint8Array(32))).slice(2);
  await db.prepare("INSERT INTO multichain_orders_draft(id,member_id,chain,package_id,credits,buyer,recipient,settlement_asset,amount_units,order_reference,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)")
    .bind(id,input.memberId,"ethereum",terms.packageId,terms.credits,buyer,terms.recipient,token,terms.amountUnits.toString(),reference,input.now).run();
  return {id,reference:`0x${reference}` as Hex,recipient:terms.recipient,amountUnits:terms.amountUnits.toString()};
}

export async function settleEthereumDraftOrder(db:Database,input:{memberId:string; orderId:string; txHash:Hex; checkout:Address; settlementToken:Address; confirmations:number; rpc:EthereumDraftRpc; now:string}) {
  if (!/^0x[0-9a-fA-F]{64}$/.test(input.txHash)) throw new Error("INVALID_TRANSACTION_ID");
  if (!Number.isSafeInteger(input.confirmations) || input.confirmations<1 || input.confirmations>10000) throw new Error("INVALID_CONFIRMATIONS");
  const order=await db.prepare("SELECT id,member_id,chain,package_id,credits,buyer,recipient,settlement_asset,amount_units,order_reference,status,transaction_id FROM multichain_orders_draft WHERE id=? AND member_id=?").bind(input.orderId,input.memberId).first<Order>();
  if (!order || order.chain!=="ethereum") throw new Error("ORDER_NOT_FOUND");
  const normalized=input.txHash.slice(2).toLowerCase();
  if (order.status==="credited") {
    if (order.transaction_id!==normalized) throw new Error("ORDER_ALREADY_CREDITED");
    return {status:"credited" as const,alreadyCredited:true};
  }
  const terms=packageSettlement("ethereum",order.package_id);
  if (getAddress(order.recipient)!==getAddress(terms.recipient) || getAddress(order.settlement_asset)!==getAddress(input.settlementToken) || order.amount_units!==terms.amountUnits.toString() || order.credits!==terms.credits) throw new Error("ORDER_TERMS_MISMATCH");
  const chain=await input.rpc.getChainId();
  if (chain!==1) throw new Error("WRONG_CHAIN");
  const receipt=await input.rpc.getTransactionReceipt({hash:input.txHash});
  const head=await input.rpc.getBlockNumber();
  if (head<receipt.blockNumber || head-receipt.blockNumber+1n<BigInt(input.confirmations)) throw new Error("TRANSACTION_NOT_FINAL_SUCCESS");
  // Confirmation count alone does not establish Ethereum proof-of-stake
  // finality; fail closed when finalized/canonical block data is unavailable.
  const [finalized,canonical]=await Promise.all([input.rpc.getBlock({blockTag:"finalized"}),input.rpc.getBlock({blockNumber:receipt.blockNumber})]);
  if (finalized.number===null || finalized.number<receipt.blockNumber || !canonical.hash || canonical.hash.toLowerCase()!==receipt.blockHash.toLowerCase()) throw new Error("TRANSACTION_NOT_FINAL_SUCCESS");
  const proof=inspectEvmCheckoutReceipt(receipt,{network:"ethereum",chainId:chain,expectedChainId:1,final:true,txHash:input.txHash,checkout:input.checkout,settlementToken:input.settlementToken,buyer:getAddress(order.buyer),recipient:getAddress(order.recipient),packageId:order.package_id,reference:`0x${order.order_reference}`});
  const result=await db.prepare("UPDATE multichain_orders_draft SET status='credited',transaction_id=?,event_index=?,credited_at=? WHERE id=? AND member_id=? AND status='pending'")
    .bind(proof.transactionId,proof.eventIndex,input.now,order.id,input.memberId).run();
  if (result.meta?.changes===1) return {status:"credited" as const,alreadyCredited:false};
  const current=await db.prepare("SELECT status,transaction_id FROM multichain_orders_draft WHERE id=? AND member_id=?").bind(order.id,input.memberId).first<Pick<Order,"status"|"transaction_id">>();
  if (current?.status==="credited" && current.transaction_id===normalized) return {status:"credited" as const,alreadyCredited:true};
  throw new Error("ORDER_SETTLEMENT_CONFLICT");
}
