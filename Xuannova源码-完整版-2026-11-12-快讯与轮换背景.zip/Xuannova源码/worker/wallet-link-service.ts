/** Feature-gated account-link service. Caller MUST enforce authenticated
 * member session, strict origin and configured public origin. This service
 * does not enable payments or create authentication sessions.
 */
import { bytesToHex, hexToBytes, type Hex } from "viem";
import { walletLinkMessage, verifyWalletLinkSignature, type WalletLinkChallenge } from "./wallet-link-auth.draft";
type Statement = { bind(...values: unknown[]): Statement; first<T>(): Promise<T | null>; run(): Promise<{meta?:{changes?:number}}> };
export type LinkDatabase = { prepare(sql: string): Statement; batch(statements: Statement[]): Promise<Array<{meta?:{changes?:number}}>> };
type Stored = {nonce:string; member_id:string; chain:"solana"|"tron"; address:string; origin:string; issued_at:number; expires_at:number; consumed_at:number|null};

export async function issueWalletLink(db: LinkDatabase, input: {memberId:string; chain:"solana"|"tron"; address:string; origin:string; now:number}) {
  const active = await db.prepare("SELECT COUNT(*) AS count FROM wallet_link_challenges_v2 WHERE member_id = ? AND consumed_at IS NULL AND expires_at > ?").bind(input.memberId,input.now).first<{count:number}>();
  if ((active?.count ?? 0) >= 5) throw new Error("TOO_MANY_CHALLENGES");
  const challenge: WalletLinkChallenge = {memberId:input.memberId,chain:input.chain,address:input.address,origin:input.origin,nonce:bytesToHex(crypto.getRandomValues(new Uint8Array(32))).slice(2),issuedAt:input.now,expiresAt:input.now+300};
  const message = walletLinkMessage(challenge,input.now);
  await db.prepare("INSERT INTO wallet_link_challenges_v2(nonce,member_id,chain,address,origin,issued_at,expires_at) VALUES(?,?,?,?,?,?,?)").bind(challenge.nonce,challenge.memberId,challenge.chain,challenge.address,challenge.origin,challenge.issuedAt,challenge.expiresAt).run();
  return {nonce:challenge.nonce,chain:challenge.chain,address:challenge.address,message,expiresAt:challenge.expiresAt};
}

export async function completeWalletLink(db: LinkDatabase, input: {memberId:string; origin:string; nonce:string; signature:string; now:number}): Promise<boolean> {
  if (!/^[a-f0-9]{64}$/.test(input.nonce) || !/^0x[0-9a-fA-F]+$/.test(input.signature)) return false;
  const row = await db.prepare("SELECT nonce,member_id,chain,address,origin,issued_at,expires_at,consumed_at FROM wallet_link_challenges_v2 WHERE nonce=? AND member_id=?").bind(input.nonce,input.memberId).first<Stored>();
  if (!row || row.origin !== input.origin || row.consumed_at !== null) return false;
  const challenge: WalletLinkChallenge = {nonce:row.nonce,memberId:row.member_id,chain:row.chain,address:row.address,origin:row.origin,issuedAt:row.issued_at,expiresAt:row.expires_at};
  let signature: Uint8Array | Hex;
  if (row.chain === "solana") { if (!/^0x[0-9a-fA-F]{128}$/.test(input.signature)) return false; signature=hexToBytes(input.signature as Hex); }
  else { if (!/^0x[0-9a-fA-F]{130}$/.test(input.signature)) return false; signature=input.signature as Hex; }
  if (!await verifyWalletLinkSignature(challenge,input.now,signature)) return false;
  const consume=db.prepare("UPDATE wallet_link_challenges_v2 SET consumed_at=? WHERE nonce=? AND member_id=? AND chain=? AND address=? AND origin=? AND issued_at=? AND expires_at=? AND consumed_at IS NULL AND issued_at<=? AND expires_at>?")
    .bind(input.now,row.nonce,row.member_id,row.chain,row.address,row.origin,row.issued_at,row.expires_at,input.now,input.now);
  const link=db.prepare("INSERT INTO member_wallet_links_v2(chain,address,member_id,linked_at) SELECT ?,?,?,? WHERE changes()=1 ON CONFLICT(chain,address) DO UPDATE SET linked_at=member_wallet_links_v2.linked_at WHERE member_wallet_links_v2.member_id=excluded.member_id")
    .bind(row.chain,row.address,row.member_id,input.now);
  const results=await db.batch([consume,link]);
  return results[0]?.meta?.changes===1 && results[1]?.meta?.changes===1;
}
