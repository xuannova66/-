/** LOCAL ONLY. A candidate transaction hash is not proof of a payment.
 * No API, scheduler or broadcaster is connected. Callers must authenticate
 * the member and configure trusted chain-verifier callbacks server-side.
 */
type Statement={bind(...values:unknown[]):Statement; first<T>():Promise<T|null>; all<T>():Promise<{results:T[]}>; run():Promise<{meta?:{changes?:number}}>};
export type RecoveryDatabase={prepare(sql:string):Statement};
type Chain="ethereum"|"solana"|"tron";
export type Attempt={order_id:string;member_id:string;chain:Chain;transaction_id:string};
function normalize(chain:Chain,id:string):string {
  if(chain==="solana") {if(!/^[1-9A-HJ-NP-Za-km-z]{64,88}$/.test(id)) throw new Error("INVALID_TRANSACTION_ID");return id;}
  const raw=id.replace(/^0x/i,"").toLowerCase();
  if(!/^[a-f0-9]{64}$/.test(raw)) throw new Error("INVALID_TRANSACTION_ID");
  return raw;
}

export async function recordPaymentAttempt(db:RecoveryDatabase,input:{memberId:string;orderId:string;transactionId:string;now:string}) {
  const order=await db.prepare("SELECT chain,status FROM multichain_orders_draft WHERE id=? AND member_id=?").bind(input.orderId,input.memberId).first<{chain:string;status:string}>();
  if(!order || !["ethereum","solana","tron"].includes(order.chain)) throw new Error("ORDER_NOT_FOUND");
  if(order.status!=="pending") throw new Error("ORDER_NOT_PENDING");
  const id=normalize(order.chain as Chain,input.transactionId);
  // Enforce the cap inside the INSERT to prevent concurrent requests from
  // bypassing a separate count query. Duplicates remain safely retryable.
  const result=await db.prepare("INSERT OR IGNORE INTO multichain_payment_attempts_draft(order_id,transaction_id,created_at) SELECT ?,?,? WHERE (SELECT count(*) FROM multichain_payment_attempts_draft WHERE order_id=?)<5 AND EXISTS(SELECT 1 FROM multichain_orders_draft WHERE id=? AND member_id=? AND status='pending')")
    .bind(input.orderId,id,input.now,input.orderId,input.orderId,input.memberId).run();
  if(result.meta?.changes===1) return {recorded:true};
  const existing=await db.prepare("SELECT transaction_id FROM multichain_payment_attempts_draft WHERE order_id=? AND transaction_id=?").bind(input.orderId,id).first<{transaction_id:string}>();
  if(existing) return {recorded:false};
  throw new Error("ATTEMPT_LIMIT_OR_ORDER_CHANGED");
}

export async function retryPaymentAttempts(db:RecoveryDatabase,input:{now:string;limit:number; verify:(attempt:Attempt)=>Promise<void>}) {
  if(!Number.isInteger(input.limit)||input.limit<1||input.limit>100) throw new Error("INVALID_LIMIT");
  const instant=Date.parse(input.now);
  if (!Number.isFinite(instant) || new Date(instant).toISOString()!==input.now) throw new Error("INVALID_TIME");
  const cutoff=new Date(instant-30_000).toISOString();
  const rows=await db.prepare("SELECT a.order_id,o.member_id,o.chain,a.transaction_id FROM multichain_payment_attempts_draft a JOIN multichain_orders_draft o ON o.id=a.order_id WHERE o.status='pending' AND o.chain IN ('ethereum','solana','tron') AND (a.last_checked_at IS NULL OR a.last_checked_at<=?) ORDER BY COALESCE(a.last_checked_at,a.created_at),a.created_at LIMIT ?").bind(cutoff,input.limit).all<Attempt>();
  let credited=0, pending=0;
  for(const attempt of rows.results) {
    try {await input.verify(attempt);} catch { /* Retain candidate; no automatic rejection or extra payment. */ }
    const current=await db.prepare("SELECT status,transaction_id FROM multichain_orders_draft WHERE id=? AND member_id=?").bind(attempt.order_id,attempt.member_id).first<{status:string;transaction_id:string|null}>();
    if(current?.status==="credited" && current.transaction_id===attempt.transaction_id) credited++; else pending++;
    await db.prepare("UPDATE multichain_payment_attempts_draft SET last_checked_at=?,check_count=check_count+1 WHERE order_id=? AND transaction_id=?").bind(input.now,attempt.order_id,attempt.transaction_id).run();
  }
  return {checked:rows.results.length,credited,pending};
}
