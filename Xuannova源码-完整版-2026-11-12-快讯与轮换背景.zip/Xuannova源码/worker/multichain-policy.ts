/** Draft policy for isolated multi-chain development; not a live checkout.
 * Prices and credit counts are sourced from the existing commerce policy so
 * the new chain adapters cannot silently introduce a second price table.
 */
import { creditPackages } from "./commerce-policy";
import { parseAssetAmount } from "../app/asset-amounts";

export const settlementNetworks = {
  bsc: { chainId: 56, symbol: "USDC", decimals: 18, recipient: "0x9E946751c432E4FCd05C463956122793ab64202e" },
  ethereum: { chainId: 1, symbol: "USDC", decimals: 6, recipient: "0x84F33708ab4b7DEFd9Be5EC50911797E34009caA" },
  solana: { chainId: "solana-mainnet", symbol: "USDC", decimals: 6, recipient: "BzDaU6VKyMtN14QeVuCMva2SGmHLeeYy2GAAG9muJNq2" },
  tron: { chainId: "tron-mainnet", symbol: "USDT", decimals: 6, recipient: "TMkFTkWbkjnUpCTiYx87QyTTjXiS2ogGqi" },
} as const;

export type SettlementNetwork = keyof typeof settlementNetworks;

export function packageSettlement(network: SettlementNetwork, packageId: string) {
  if (!Object.hasOwn(settlementNetworks, network)) throw new Error("UNSUPPORTED_SETTLEMENT_NETWORK");
  const selected = creditPackages.find((item) => item.id === packageId);
  if (!selected) throw new Error("UNKNOWN_CREDIT_PACKAGE");
  const target = settlementNetworks[network];
  return {
    network,
    chainId: target.chainId,
    symbol: target.symbol,
    decimals: target.decimals,
    recipient: target.recipient,
    packageId: selected.id,
    price: selected.usdt,
    credits: selected.credits,
    amountUnits: parseAssetAmount(selected.usdt, target.decimals),
  };
}
