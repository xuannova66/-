// 我的静室: a member's own quiet room. The owner invites family and friends with a link; members appear by their
// 道号 (never by email); anyone in the room can share one of their saved birth profiles (with the person's consent)
// so everyone in the room can look at that chart and its life K-line together. No chat.
import { cleanDaoName, cleanText, randomDaoName } from "./hall-presence";

type Statement = { bind(...values: unknown[]): Statement; first<T>(): Promise<T | null>; all<T>(): Promise<{ results?: T[] }>; run(): Promise<unknown> };
type Database = { prepare(sql: string): Statement };

export const ROOM_LIMITS = { members: 12, joined: 10, shares: 20 };
export class RoomError extends Error { constructor(public readonly code: string, public readonly status = 400) { super(code); } }

const token = () => [...crypto.getRandomValues(new Uint8Array(12))].map((byte) => byte.toString(16).padStart(2, "0")).join("");
const cleanRoomName = (value: unknown) => cleanText(value, 16);

type RoomRow = { id: string; owner_id: string; name: string; invite_token: string; created_at: string };
type MemberRow = { member_id: string; dao_name: string; role: "owner" | "member"; joined_at: string; last_seen: string | null };
type ShareRow = { id: string; member_id: string; label: string; chart_json: string; created_at: string };

async function membership(db: Database, roomId: string, memberId: string) {
  return db.prepare("SELECT role FROM room_members WHERE room_id = ? AND member_id = ?").bind(roomId, memberId).first<{ role: "owner" | "member" }>();
}

export async function listRooms(db: Database, memberId: string) {
  const rows = (await db.prepare("SELECT r.id, r.name, m.role, (SELECT COUNT(*) FROM room_members x WHERE x.room_id = r.id) AS members FROM room_members m JOIN rooms r ON r.id = m.room_id WHERE m.member_id = ? ORDER BY m.role = 'owner' DESC, m.joined_at DESC").bind(memberId).all<{ id: string; name: string; role: string; members: number }>()).results ?? [];
  return rows.map((row) => ({ id: row.id, name: row.name, role: row.role, members: Number(row.members) }));
}

export async function createRoom(db: Database, memberId: string, name: unknown, now: string) {
  const owned = await db.prepare("SELECT id FROM rooms WHERE owner_id = ?").bind(memberId).first<{ id: string }>();
  if (owned) return owned.id;
  const id = crypto.randomUUID();
  const dao = randomDaoName(`m:${memberId}`).name;
  await db.prepare("INSERT INTO rooms (id, owner_id, name, invite_token, created_at) VALUES (?, ?, ?, ?, ?)").bind(id, memberId, cleanRoomName(name) ?? `${dao}的静室`, token(), now).run();
  await db.prepare("INSERT INTO room_members (room_id, member_id, dao_name, role, joined_at, last_seen) VALUES (?, ?, ?, 'owner', ?, ?)").bind(id, memberId, dao, now, now).run();
  return id;
}

export async function roomDetail(db: Database, roomId: string, memberId: string, now: Date, touch = false) {
  const role = await membership(db, roomId, memberId);
  if (!role) throw new RoomError("NOT_A_MEMBER", 404);
  if (touch) await db.prepare("UPDATE room_members SET last_seen = ? WHERE room_id = ? AND member_id = ?").bind(now.toISOString(), roomId, memberId).run();
  const room = await db.prepare("SELECT * FROM rooms WHERE id = ?").bind(roomId).first<RoomRow>();
  if (!room) throw new RoomError("NOT_A_MEMBER", 404);
  const members = (await db.prepare("SELECT member_id, dao_name, role, joined_at, last_seen FROM room_members WHERE room_id = ? ORDER BY role = 'owner' DESC, joined_at").bind(roomId).all<MemberRow>()).results ?? [];
  const shares = (await db.prepare("SELECT id, member_id, label, chart_json, created_at FROM room_shares WHERE room_id = ? ORDER BY created_at DESC").bind(roomId).all<ShareRow>()).results ?? [];
  const onlineSince = now.getTime() - 60_000;
  const daoOf = new Map(members.map((member) => [member.member_id, member.dao_name]));
  return {
    id: room.id, name: room.name, role: role.role,
    // Only the owner sees the invite token.
    inviteToken: role.role === "owner" ? room.invite_token : null,
    limits: ROOM_LIMITS,
    members: members.map((member) => ({ id: member.member_id, daoName: member.dao_name, role: member.role, self: member.member_id === memberId, online: Boolean(member.last_seen && Date.parse(member.last_seen) >= onlineSince) })),
    shares: shares.map((share) => ({ id: share.id, label: share.label, by: daoOf.get(share.member_id) ?? "", mine: share.member_id === memberId, chart: JSON.parse(share.chart_json), createdAt: share.created_at })),
  };
}

export async function invitePreview(db: Database, inviteToken: string) {
  if (!/^[0-9a-f]{24}$/.test(inviteToken)) throw new RoomError("INVITE_INVALID", 404);
  const room = await db.prepare("SELECT id, name FROM rooms WHERE invite_token = ?").bind(inviteToken).first<{ id: string; name: string }>();
  if (!room) throw new RoomError("INVITE_INVALID", 404);
  const count = await db.prepare("SELECT COUNT(*) AS n FROM room_members WHERE room_id = ?").bind(room.id).first<{ n: number }>();
  return { id: room.id, name: room.name, members: Number(count?.n ?? 0), full: Number(count?.n ?? 0) >= ROOM_LIMITS.members };
}

export async function joinRoom(db: Database, memberId: string, inviteToken: string, now: string) {
  const preview = await invitePreview(db, inviteToken);
  if (await membership(db, preview.id, memberId)) return preview.id;
  if (preview.full) throw new RoomError("ROOM_FULL", 409);
  const joined = await db.prepare("SELECT COUNT(*) AS n FROM room_members WHERE member_id = ?").bind(memberId).first<{ n: number }>();
  if (Number(joined?.n ?? 0) >= ROOM_LIMITS.joined) throw new RoomError("TOO_MANY_ROOMS", 409);
  await db.prepare("INSERT INTO room_members (room_id, member_id, dao_name, role, joined_at, last_seen) VALUES (?, ?, ?, 'member', ?, ?)").bind(preview.id, memberId, randomDaoName(`m:${memberId}`).name, now, now).run();
  return preview.id;
}

async function requireOwner(db: Database, roomId: string, memberId: string) {
  if ((await membership(db, roomId, memberId))?.role !== "owner") throw new RoomError("OWNER_ONLY", 403);
}

export async function renameRoom(db: Database, roomId: string, memberId: string, name: unknown) {
  await requireOwner(db, roomId, memberId);
  const clean = cleanRoomName(name);
  if (!clean) throw new RoomError("NAME_REFUSED");
  await db.prepare("UPDATE rooms SET name = ? WHERE id = ?").bind(clean, roomId).run();
}
export async function resetInvite(db: Database, roomId: string, memberId: string) {
  await requireOwner(db, roomId, memberId);
  await db.prepare("UPDATE rooms SET invite_token = ? WHERE id = ?").bind(token(), roomId).run();
}
export async function setDaoName(db: Database, roomId: string, memberId: string, name: unknown) {
  if (!(await membership(db, roomId, memberId))) throw new RoomError("NOT_A_MEMBER", 404);
  const clean = name === "" ? randomDaoName(`m:${memberId}`).name : cleanDaoName(name);
  if (!clean) throw new RoomError("NAME_REFUSED");
  await db.prepare("UPDATE room_members SET dao_name = ? WHERE room_id = ? AND member_id = ?").bind(clean, roomId, memberId).run();
}
export async function removeMember(db: Database, roomId: string, memberId: string, target: unknown) {
  await requireOwner(db, roomId, memberId);
  if (typeof target !== "string" || target === memberId) throw new RoomError("INVALID_REQUEST");
  await db.prepare("DELETE FROM room_shares WHERE room_id = ? AND member_id = ?").bind(roomId, target).run();
  await db.prepare("DELETE FROM room_members WHERE room_id = ? AND member_id = ? AND role = 'member'").bind(roomId, target).run();
}
/** Leave a room (members) or close it (owner: everything in it is deleted). */
export async function leaveRoom(db: Database, roomId: string, memberId: string) {
  const role = await membership(db, roomId, memberId);
  if (!role) return;
  if (role.role === "owner") {
    await db.prepare("DELETE FROM room_shares WHERE room_id = ?").bind(roomId).run();
    await db.prepare("DELETE FROM room_members WHERE room_id = ?").bind(roomId).run();
    await db.prepare("DELETE FROM rooms WHERE id = ?").bind(roomId).run();
    return;
  }
  await db.prepare("DELETE FROM room_shares WHERE room_id = ? AND member_id = ?").bind(roomId, memberId).run();
  await db.prepare("DELETE FROM room_members WHERE room_id = ? AND member_id = ?").bind(roomId, memberId).run();
}

/** Share one of the member's saved profiles (a snapshot of its birth data) into the room. Needs explicit consent. */
export async function shareProfile(db: Database, roomId: string, memberId: string, input: { profileId?: unknown; consent?: unknown }, now: string) {
  if (!(await membership(db, roomId, memberId))) throw new RoomError("NOT_A_MEMBER", 404);
  if (input.consent !== true) throw new RoomError("CONSENT_REQUIRED");
  if (typeof input.profileId !== "string") throw new RoomError("INVALID_REQUEST");
  const profile = await db.prepare("SELECT label, name, gender, calendar, birth_date, birth_time, leap_month FROM member_profiles WHERE id = ? AND member_id = ?").bind(input.profileId, memberId)
    .first<{ label: string; name: string; gender: string; calendar: string; birth_date: string; birth_time: string; leap_month: number }>();
  if (!profile) throw new RoomError("PROFILE_NOT_FOUND", 404);
  const count = await db.prepare("SELECT COUNT(*) AS n FROM room_shares WHERE room_id = ?").bind(roomId).first<{ n: number }>();
  if (Number(count?.n ?? 0) >= ROOM_LIMITS.shares) throw new RoomError("TOO_MANY_SHARES", 409);
  const chart = { date: profile.birth_date, time: profile.birth_time || "12:00", calendar: profile.calendar === "lunar" ? "lunar" : "solar", gender: profile.gender === "yin" ? "yin" : "yang", leapMonth: Boolean(profile.leap_month), timeKnown: Boolean(profile.birth_time) };
  const id = crypto.randomUUID();
  await db.prepare("INSERT INTO room_shares (id, room_id, member_id, label, chart_json, created_at) VALUES (?, ?, ?, ?, ?, ?)").bind(id, roomId, memberId, (profile.name || profile.label).slice(0, 40), JSON.stringify(chart), now).run();
  return id;
}
export async function unshare(db: Database, roomId: string, memberId: string, shareId: unknown) {
  const role = await membership(db, roomId, memberId);
  if (!role) throw new RoomError("NOT_A_MEMBER", 404);
  if (typeof shareId !== "string") throw new RoomError("INVALID_REQUEST");
  if (role.role === "owner") await db.prepare("DELETE FROM room_shares WHERE id = ? AND room_id = ?").bind(shareId, roomId).run();
  else await db.prepare("DELETE FROM room_shares WHERE id = ? AND room_id = ? AND member_id = ?").bind(shareId, roomId, memberId).run();
}
