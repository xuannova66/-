// 分享来源统计: daily totals of posters made, saved and shared, and of visits that arrived from a shared poster,
// plus the first share source of each new account (members.signup_source). No personal data is stored.

type Statement = { bind(...values: unknown[]): Statement; first<T>(): Promise<T | null>; all<T>(): Promise<{ results?: T[] }>; run(): Promise<unknown> };
type Database = { prepare(sql: string): Statement };

export const SHARE_SOURCES = ["daily-card", "action-card", "almanac-card", "lamp-card", "chart-card", "invite-link", "flash-card"] as const;
export const SHARE_ACTIONS = ["made", "saved", "shared", "visit"] as const;
export type ShareSource = (typeof SHARE_SOURCES)[number];
export const SOURCE_COOKIE = "xn_src";

export const validSource = (value: unknown): ShareSource | null => (typeof value === "string" && (SHARE_SOURCES as readonly string[]).includes(value) ? value as ShareSource : null);
export const validAction = (value: unknown) => (typeof value === "string" && (SHARE_ACTIONS as readonly string[]).includes(value) ? value as (typeof SHARE_ACTIONS)[number] : null);

export async function countShare(db: Database, source: ShareSource, action: (typeof SHARE_ACTIONS)[number], now: Date) {
  const day = now.toISOString().slice(0, 10);
  await db.prepare("INSERT INTO share_stats (day, source, action, count) VALUES (?, ?, ?, 1) ON CONFLICT(day, source, action) DO UPDATE SET count = count + 1").bind(day, source, action).run();
}

/** Keep the device's first share source on a new account (only if the account has none yet). */
export async function recordSignupSource(db: Database, memberId: string, source: ShareSource | null) {
  if (!source) return;
  await db.prepare("UPDATE members SET signup_source = ? WHERE id = ? AND signup_source IS NULL").bind(source, memberId).run();
}

/** Admin report: per source, posters made / saved / shared, visits, sign-ups, buyers (last `days` days and all time). */
export async function shareReport(db: Database, now: Date, days = 30, purchasesByMember: string) {
  const since = new Date(now.getTime() - days * 86400_000).toISOString().slice(0, 10);
  const stats = await db.prepare("SELECT source, action, SUM(count) AS n FROM share_stats WHERE day >= ? GROUP BY source, action").bind(since).all<{ source: string; action: string; n: number }>();
  const signups = await db.prepare(`SELECT m.signup_source AS source, COUNT(*) AS n, SUM(CASE WHEN m.invited_by_member_id IS NOT NULL THEN 1 ELSE 0 END) AS invited, SUM(CASE WHEN COALESCE(p.total, 0) > 0 THEN 1 ELSE 0 END) AS buyers FROM members m LEFT JOIN (${purchasesByMember}) p ON p.member_id = m.id WHERE m.signup_source IS NOT NULL AND m.created_at >= ? GROUP BY m.signup_source`).bind(since).all<{ source: string; n: number; invited: number; buyers: number }>();
  const rows = SHARE_SOURCES.map((source) => {
    const pick = (action: string) => Number((stats.results ?? []).find((row) => row.source === source && row.action === action)?.n ?? 0);
    const signup = (signups.results ?? []).find((row) => row.source === source);
    return { source, made: pick("made"), saved: pick("saved"), shared: pick("shared"), visits: pick("visit"), signups: Number(signup?.n ?? 0), invitedSignups: Number(signup?.invited ?? 0), buyers: Number(signup?.buyers ?? 0) };
  });
  return { days, rows: rows.sort((a, b) => b.signups - a.signups || b.visits - a.visits) };
}
