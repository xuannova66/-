import { buildGeocodingUrls } from "../app/geocoding";

type GeocodingPayload = { results?: unknown[] };

function json(body: unknown, init: ResponseInit = {}) {
  const headers = new Headers(init.headers);
  headers.set("content-type", "application/json; charset=utf-8");
  headers.set("cache-control", "public, max-age=300, s-maxage=900");
  return new Response(JSON.stringify(body), { ...init, headers });
}

function error(message: string, status: number) {
  return json({ error: message, results: [] }, { status });
}

function isSupportedLocale(value: string) {
  return ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"].includes(value);
}

function mergeResults(payloads: GeocodingPayload[]) {
  const results = new Map<string, unknown>();
  for (const payload of payloads) {
    for (const item of payload.results ?? []) {
      if (!item || typeof item !== "object") continue;
      const record = item as Record<string, unknown>;
      const key = typeof record.id === "number"
        ? String(record.id)
        : `${String(record.name ?? "")}::${String(record.latitude ?? "")}::${String(record.longitude ?? "")}`;
      // the same city from both providers (different ids, a few km apart): keep the first one
      const lat = Number(record.latitude), lon = Number(record.longitude), code = String(record.country_code ?? "").toUpperCase();
      const twin = [...results.values()].some((other) => {
        const o = other as Record<string, unknown>;
        return String(o.country_code ?? "").toUpperCase() === code && Math.abs(Number(o.latitude) - lat) < 0.08 && Math.abs(Number(o.longitude) - lon) < 0.08;
      });
      if (!results.has(key) && twin) continue;
      results.set(key, item);
    }
  }
  return [...results.values()].slice(0, 20);
}

// ---- OpenStreetMap fallback ----
// The main provider (Open-Meteo / GeoNames) often finds nothing for overseas cities typed in Chinese, Japanese, Korean
// or Thai (伦敦, 曼谷, ロンドン, 런던, ลอนดอน…). OpenStreetMap's Nominatim knows those local names, so when the main
// search comes back empty or thin we ask it too. Its usage policy asks for at most one request a second and a real
// User-Agent, so calls are spaced out and answers are cached for a day.
const NOMINATIM = "https://nominatim.openstreetmap.org/search";
const fallbackCache = new Map<string, { at: number; results: unknown[] }>();
let nominatimQueue: Promise<unknown> = Promise.resolve();
let nominatimLast = 0;

type NominatimPlace = {
  osm_id?: number; osm_type?: string; lat?: string; lon?: string; name?: string; display_name?: string;
  addresstype?: string; type?: string; class?: string; place_rank?: number;
  address?: Record<string, string>;
};

const OSM_FEATURE: Record<string, string> = { city: "PPLA", town: "PPL", village: "PPL", municipality: "PPL", hamlet: "PPL", suburb: "PPLX", city_district: "PPLX", borough: "PPLX", quarter: "PPLX", county: "ADM2", state: "ADM1", province: "ADM1", region: "ADM1", country: "PCLI" };

export function nominatimLanguage(locale: string) {
  return ({ "zh-Hans": "zh-CN,zh", "zh-Hant": "zh-TW,zh", ja: "ja", ko: "ko", vi: "vi", th: "th", en: "en" } as Record<string, string>)[locale] ?? "en";
}

/** Turns a Nominatim answer into the same shape Open-Meteo returns, so the page does not need to know the difference. */
export function normalizeNominatim(places: NominatimPlace[]) {
  return places.flatMap((place) => {
    const latitude = Number(place.lat), longitude = Number(place.lon);
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude) || typeof place.osm_id !== "number") return [];
    const kind = place.addresstype ?? place.type ?? "";
    if (!(kind in OSM_FEATURE) && place.class !== "place" && place.class !== "boundary") return [];
    const address = place.address ?? {};
    const name = place.name || (place.display_name ?? "").split(",")[0]?.trim();
    const country = address.country ?? (place.display_name ?? "").split(",").pop()?.trim() ?? "";
    if (!name || !country) return [];
    const admin1 = address.state ?? address.province ?? address.region;
    return [{
      // keep clear of GeoNames ids
      id: 9_000_000_000 + place.osm_id * 3 + (place.osm_type === "relation" ? 2 : place.osm_type === "way" ? 1 : 0),
      name, country, latitude, longitude,
      ...(address.country_code ? { country_code: address.country_code.toUpperCase() } : {}),
      ...(admin1 && admin1 !== name ? { admin1 } : {}),
      feature_code: OSM_FEATURE[kind] ?? "PPL",
    }];
  });
}

async function nominatimSearch(query: string, locale: string, fetchImpl: typeof fetch) {
  const key = `${locale}|${query.toLocaleLowerCase()}`;
  const cached = fallbackCache.get(key);
  if (cached && Date.now() - cached.at < 86_400_000) return cached.results;
  const run = async () => {
    const wait = 1100 - (Date.now() - nominatimLast);
    if (wait > 0) await new Promise((resolve) => setTimeout(resolve, wait));
    nominatimLast = Date.now();
    const params = new URLSearchParams({ q: query, format: "jsonv2", addressdetails: "1", limit: "8", "accept-language": nominatimLanguage(locale) });
    const response = await fetchImpl(`${NOMINATIM}?${params}`, { headers: { accept: "application/json", "user-agent": "Xuannova/1.0 (+https://xuannova.com)", referer: "https://xuannova.com/" }, signal: AbortSignal.timeout(6000) });
    if (!response.ok) return [];
    const results = normalizeNominatim(await response.json() as NominatimPlace[]);
    if (fallbackCache.size > 800) fallbackCache.delete(fallbackCache.keys().next().value as string);
    fallbackCache.set(key, { at: Date.now(), results });
    return results;
  };
  const next = nominatimQueue.then(run, run);
  nominatimQueue = next.catch(() => undefined);
  return next.catch(() => []);
}

export async function handleGeocodingApi(request: Request, fetchImpl: typeof fetch = fetch): Promise<Response | null> {
  const url = new URL(request.url);
  if (url.pathname !== "/api/geocode") return null;
  if (request.method !== "GET") return error("Method not allowed", 405);

  const query = (url.searchParams.get("q") ?? "").trim();
  const locale = url.searchParams.get("locale") ?? "en";
  if (query.length < 2 || query.length > 120) return error("Location query must contain 2 to 120 characters", 400);
  if (!isSupportedLocale(locale)) return error("Unsupported locale", 400);

  const responses = await Promise.allSettled(buildGeocodingUrls(query, locale).map(async (target) => {
    const response = await fetchImpl(target, { headers: { accept: "application/json" } });
    if (!response.ok) throw new Error(`Geocoding upstream returned ${response.status}`);
    return response.json() as Promise<GeocodingPayload>;
  }));
  const payloads = responses.flatMap((result) => result.status === "fulfilled" ? [result.value] : []);
  const found = mergeResults(payloads);
  // thin or empty answer, or a name not written in Latin letters: ask OpenStreetMap as well
  const nonLatin = /[^\u0000-\u024f\u1e00-\u1eff\s,.'-]/u.test(query);
  if (found.length < 3 || nonLatin) {
    const extra = await nominatimSearch(query, locale, fetchImpl);
    // for a name in Chinese, Japanese, Korean or Thai the OpenStreetMap match is usually the right city, so list it first
    if (extra.length) { if (nonLatin) payloads.unshift({ results: extra }); else payloads.push({ results: extra }); }
  }
  if (payloads.length === 0) return error("Global location service is temporarily unavailable", 503);
  return json({ results: mergeResults(payloads) });
}
