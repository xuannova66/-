/** Local-only prototype. Not an API and not authorized for real funds.
 * The caller must authenticate the member, keep RPC/configuration trusted and
 * use the database draft schema. Only direct, standard USDC transfers work;
 * this does not verify swaps or provision the recipient token account.
 */
import { bytesToHex } from "viem";
import { packageSettlement } from "./multichain-policy";
import { inspectSolanaDirectFromRpc } from "./direct-payment-rpc.draft";

type Statement = { bind(...values: unknown[]): Statement; first<T>(): Promise<T | null>; run(): Promise<{meta?:{changes?:number}}> };
type Database = { prepare(sql: string): Statement };
type Fetcher = (input: string, init: RequestInit) => Promise<Response>;
type Order = { id: string; member_id: string; chain: string; package_id: string; credits: number; buyer: string; recipient: string; settlement_asset: string; amount_units: string; order_reference: string; status: string; transaction_id: string | null };
const USDC_MINT = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";

export async function createSolanaDirectOrder(db: Database, input: { memberId: string; buyer: string; packageId: string; now: string }) {
  const linked = await db.prepare("SELECT address FROM member_wallet_links_v2 WHERE chain='solana' AND address=? AND member_id=?").bind(input.buyer, input.memberId).first<{address:string}>();
  if (!linked) throw new Error("WALLET_NOT_LINKED");
  const terms = packageSettlement("solana", input.packageId);
  const id = crypto.randomUUID();
  const reference = bytesToHex(crypto.getRandomValues(new Uint8Array(32))).slice(2);
  await db.prepare("INSERT INTO multichain_orders_draft(id,member_id,chain,package_id,credits,buyer,recipient,settlement_asset,amount_units,order_reference,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)")
    .bind(id,input.memberId,"solana",terms.packageId,terms.credits,input.buyer,terms.recipient,USDC_MINT,terms.amountUnits.toString(),reference,input.now).run();
  return { id, reference, recipient: terms.recipient, mint: USDC_MINT, amountUnits: terms.amountUnits.toString() };
}

export async function settleSolanaDirectOrder(db: Database, input: { memberId: string; orderId: string; signature: string; recipientTokenAccount: string; now: string; fetcher?: Fetcher }) {
  const order = await db.prepare("SELECT id,member_id,chain,package_id,credits,buyer,recipient,settlement_asset,amount_units,order_reference,status,transaction_id FROM multichain_orders_draft WHERE id=? AND member_id=?").bind(input.orderId,input.memberId).first<Order>();
  if (!order || order.chain !== "solana") throw new Error("ORDER_NOT_FOUND");
  if (order.status === "credited") {
    if (order.transaction_id !== input.signature) throw new Error("ORDER_ALREADY_CREDITED");
    return { status: "credited" as const, alreadyCredited: true };
  }
  const terms = packageSettlement("solana",order.package_id);
  if (order.recipient !== terms.recipient || order.settlement_asset !== USDC_MINT || order.amount_units !== terms.amountUnits.toString() || order.credits !== terms.credits) throw new Error("ORDER_TERMS_MISMATCH");
  if (!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(input.recipientTokenAccount)) throw new Error("INVALID_RECIPIENT_TOKEN_ACCOUNT");
  const proof = await inspectSolanaDirectFromRpc({ signature: input.signature, buyer: order.buyer, recipient: terms.recipient, recipientTokenAccount: input.recipientTokenAccount, mint: USDC_MINT, decimals: 6, amountUnits: terms.amountUnits, orderReference: order.order_reference }, input.fetcher);
  const result = await db.prepare("UPDATE multichain_orders_draft SET status='credited',transaction_id=?,event_index=?,credited_at=? WHERE id=? AND member_id=? AND status='pending'")
    .bind(proof.signature,proof.instructionIndex,input.now,order.id,input.memberId).run();
  if (result.meta?.changes === 1) return { status: "credited" as const, alreadyCredited: false };
  const current = await db.prepare("SELECT status,transaction_id FROM multichain_orders_draft WHERE id=? AND member_id=?").bind(order.id,input.memberId).first<Pick<Order,"status"|"transaction_id">>();
  if (current?.status === "credited" && current.transaction_id === input.signature) return { status: "credited" as const, alreadyCredited: true };
  throw new Error("ORDER_SETTLEMENT_CONFLICT");
}
