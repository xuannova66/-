/** Opt-in local scheduler primitive only: importing this file starts nothing.
 * It never broadcasts transactions and must not be enabled in production
 * before durable order submission, monitoring and chain audits are complete.
 */
type Timer=ReturnType<typeof setTimeout>;
type Result={checked:number;credited:number;pending:number};
type SchedulerOptions={intervalMs:number;run:()=>Promise<Result>;onResult?:(result:Result)=>void;onError?:()=>void};

export function createRecoveryScheduler(options:SchedulerOptions) {
  if (!Number.isSafeInteger(options.intervalMs) || options.intervalMs<30_000 || options.intervalMs>3_600_000) throw new Error("INVALID_RECOVERY_INTERVAL");
  let active=false, running=false, timer:Timer|undefined, generation=0;
  function schedule(epoch:number) {
    if(!active || epoch!==generation) return;
    timer=setTimeout(()=>{timer=undefined;void tick(epoch);},options.intervalMs);
  }
  async function tick(epoch:number) {
    if(!active || epoch!==generation || running) return;
    running=true;
    try {const result=await options.run();try {options.onResult?.(result);} catch { /* Metrics must not stop recovery. */ }}
    catch {try {options.onError?.();} catch { /* Never leak RPC errors. */ }}
    finally {running=false; if(active && epoch!==generation) schedule(generation); else schedule(epoch);}
  }
  return {
    start() {if(active) return; active=true; generation++; if(!running) void tick(generation);},
    stop() {active=false; generation++; if(timer!==undefined) {clearTimeout(timer);timer=undefined;}},
    state() {return {active,running};},
  };
}
