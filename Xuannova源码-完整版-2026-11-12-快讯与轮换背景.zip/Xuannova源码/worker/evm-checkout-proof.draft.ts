/** Development-only receipt inspection; not connected to the live ledger.
 * Caller must obtain chain ID, finality and the receipt from a trusted RPC,
 * and all expected values from a server-created order and verified config.
 */
import { decodeEventLog, getAddress, keccak256, parseAbi, toBytes, type Address, type Hex } from "viem";
import { packageSettlement } from "./multichain-policy";

const abi = parseAbi([
  "event Purchased(address indexed buyer, bytes32 indexed packageId, address indexed inputAsset, uint256 settlementAmount, uint32 credits, uint256 saleIndex, bytes32 orderReference)",
  "event Transfer(address indexed from, address indexed to, uint256 value)",
]);
type Log = { address: Address; data: Hex; topics: readonly Hex[]; logIndex: number };
type Receipt = { status: "success" | "reverted"; transactionHash: Hex; logs: readonly Log[] };
type Expected = { network: "ethereum" | "bsc"; chainId: number; expectedChainId: number; final: boolean; txHash: Hex; checkout: Address; settlementToken: Address; buyer: Address; recipient: Address; packageId: string; reference: Hex };

export function inspectEvmCheckoutReceipt(receipt: Receipt, expected: Expected) {
  const terms=packageSettlement(expected.network,expected.packageId);
  if (!expected.final || expected.chainId!==expected.expectedChainId || expected.chainId!==terms.chainId || receipt.status!=="success") throw new Error("TRANSACTION_NOT_FINAL_SUCCESS");
  if (!/^0x[0-9a-fA-F]{64}$/.test(expected.txHash) || receipt.transactionHash.toLowerCase()!==expected.txHash.toLowerCase() || !/^0x[0-9a-fA-F]{64}$/.test(expected.reference) || /^0x0{64}$/i.test(expected.reference)) throw new Error("INVALID_TRANSACTION_OR_REFERENCE");
  const checkout=getAddress(expected.checkout), token=getAddress(expected.settlementToken), buyer=getAddress(expected.buyer), recipient=getAddress(expected.recipient);
  if (recipient!==getAddress(terms.recipient)) throw new Error("WRONG_RECIPIENT");
  const packageKey=keccak256(toBytes(expected.packageId));
  const matching = receipt.logs.flatMap(log => {
    if (getAddress(log.address)!==checkout) return [];
    try {
      const event=decodeEventLog({abi,eventName:"Purchased",data:log.data,topics:log.topics as [Hex,...Hex[]]});
      const x=event.args;
      return getAddress(x.buyer)===buyer && x.packageId===packageKey && x.orderReference.toLowerCase()===expected.reference.toLowerCase() && x.settlementAmount===terms.amountUnits && Number(x.credits)===terms.credits ? [{logIndex:log.logIndex}] : [];
    } catch { return []; }
  });
  if (matching.length!==1 || !Number.isSafeInteger(matching[0].logIndex) || matching[0].logIndex<0) throw new Error("PURCHASE_EVENT_MISMATCH");
  const transfers=receipt.logs.flatMap(log=> {
    if (getAddress(log.address)!==token) return [];
    try { const event=decodeEventLog({abi,eventName:"Transfer",data:log.data,topics:log.topics as [Hex,...Hex[]]});
      return getAddress(event.args.from)===checkout && getAddress(event.args.to)===recipient && event.args.value===terms.amountUnits ? [log] : [];
    } catch { return []; }
  });
  if (transfers.length!==1) throw new Error("SETTLEMENT_TRANSFER_MISMATCH");
  return {transactionId:expected.txHash.slice(2).toLowerCase(),eventIndex:matching[0].logIndex,credits:terms.credits};
}
