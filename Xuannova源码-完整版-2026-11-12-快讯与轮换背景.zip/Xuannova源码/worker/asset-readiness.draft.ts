/** Development-only whitelist gate. Symbol or contract existence alone is not
 * proof of asset identity, liquidity or safe transfer behavior. Verification
 * flags must be operator-controlled, never accepted from a user request. */
import {getAddress,isAddress,type Address} from "viem";
type Chain="bsc"|"ethereum"|"solana"|"tron";
type Evidence={identityVerified:boolean;decimalsVerified:boolean;transferBehavior:"standard"|"taxed"|"unknown";routeVerified:boolean;enabled:boolean};
export type DraftAsset={chain:Chain;symbol:string;address:string|null;decimals:number|null;evidence:Evidence};

export function requireReadyAsset(asset:DraftAsset):DraftAsset {
 if(!asset || !["bsc","ethereum","solana","tron"].includes(asset.chain) || typeof asset.symbol!=="string" || !asset.symbol || typeof asset.address!=="string" || !asset.address || !Number.isInteger(asset.decimals) || asset.decimals!<0 || asset.decimals!>18)throw new Error("ASSET_CONFIGURATION_INCOMPLETE");
 if(asset.chain==="bsc"||asset.chain==="ethereum") {
  if(!isAddress(asset.address,{strict:false})||getAddress(asset.address.toLowerCase() as Address)==="0x0000000000000000000000000000000000000000")throw new Error("INVALID_ASSET_ADDRESS");
 } else if(asset.chain==="solana") {
  if(!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(asset.address))throw new Error("INVALID_ASSET_ADDRESS");
 } else if(!/^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(asset.address))throw new Error("INVALID_ASSET_ADDRESS");
 const e=asset.evidence;
 if(!e || e.identityVerified!==true || e.decimalsVerified!==true || e.routeVerified!==true || e.enabled!==true || e.transferBehavior!=="standard")throw new Error("ASSET_NOT_APPROVED");
 return asset;
}
