/** Isolated research implementation: direct TRC20 transfer only.
 * Inputs MUST be fetched from a trusted TRON node: a transaction body and
 * its walletsolidity/gettransactioninfobyid solidified receipt. The order
 * reference must be generated server-side and inserted into raw_data.data.
 * Not wired to login, RPC, ledger or payment UI; does not support DEX swaps.
 */
import { keccak256, toBytes } from "viem";

const TRANSFER = keccak256(toBytes("Transfer(address,address,uint256)")).slice(2).toLowerCase();
export type TronBody = { txID: string; raw_data: { data?: string; contract: Array<{ type: string; parameter: { value: { owner_address: string; contract_address: string } } }> } };
export type TronReceipt = { id: string; result?: string; receipt?: { result?: string }; log?: Array<{ address: string; topics: string[]; data: string }> };
export type TronDirectExpected = { txId: string; buyerHex: string; recipientHex: string; tokenHex: string; amountUnits: bigint; orderReference: string };

function tronHex(value: string): string {
  const raw = value.replace(/^0x/i, "").toLowerCase();
  const result = raw.length === 40 ? `41${raw}` : raw;
  if (!/^41[0-9a-f]{40}$/.test(result)) throw new Error("INVALID_TRON_ADDRESS");
  return result;
}
function indexedAddress(value: string): string {
  const topic = value.replace(/^0x/i, "").toLowerCase();
  if (!/^[0-9a-f]{64}$/.test(topic) || topic.slice(0, 24) !== "0".repeat(24)) throw new Error("INVALID_EVENT_TOPIC");
  return tronHex(topic.slice(24));
}
export function inspectTronDirectPayment(body: TronBody, receipt: TronReceipt, solidified: boolean, expected: TronDirectExpected) {
  const id = expected.txId.toLowerCase();
  if (!solidified || !/^[a-f0-9]{64}$/.test(id) || body?.txID?.toLowerCase() !== id || receipt?.id?.toLowerCase() !== id || receipt.result === "FAILED" || receipt.receipt?.result !== "SUCCESS") throw new Error("TRANSACTION_NOT_FINAL_SUCCESS");
  if (!/^[a-f0-9]{64}$/.test(expected.orderReference) || body.raw_data.data?.toLowerCase() !== expected.orderReference) throw new Error("ORDER_REFERENCE_MISMATCH");
  if (expected.amountUnits <= 0n) throw new Error("INVALID_AMOUNT");
  const buyer = tronHex(expected.buyerHex), recipient = tronHex(expected.recipientHex), token = tronHex(expected.tokenHex);
  const contracts = body.raw_data.contract;
  if (contracts.length !== 1 || contracts[0].type !== "TriggerSmartContract" || tronHex(contracts[0].parameter.value.owner_address) !== buyer || tronHex(contracts[0].parameter.value.contract_address) !== token) throw new Error("NOT_DIRECT_BUYER_TRANSFER");
  const matches = (receipt.log ?? []).flatMap((log, index) => {
    try {
      if (tronHex(log.address) !== token || log.topics.length !== 3 || log.topics[0].replace(/^0x/i, "").toLowerCase() !== TRANSFER || indexedAddress(log.topics[1]) !== buyer || indexedAddress(log.topics[2]) !== recipient) return [];
      const data = log.data.replace(/^0x/i, "");
      if (!/^[a-fA-F0-9]{64}$/.test(data) || BigInt(`0x${data}`) !== expected.amountUnits) return [];
      return [index];
    } catch { return []; }
  });
  if (matches.length !== 1) throw new Error("TRANSFER_NOT_UNIQUE_OR_NOT_DIRECT");
  return { transactionId: id, logIndex: matches[0], amountUnits: expected.amountUnits };
}
