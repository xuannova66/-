// 研习殿 · 点亮祈福灯: a member lights a digital lamp that glows in the hall for 24 hours (free at launch; the
// price in credits is set by HALL_LAMP_COST).
// Only real lamps are shown (no made-up lamps). A lamp carries the 道号, an optional short wish and a theme
// (peace / study / health / career / love / family). It is a cultural, reflective gesture; nothing is promised.
import { cleanDaoName, randomDaoName } from "./hall-presence";

type Statement = { bind(...values: unknown[]): Statement; first<T>(): Promise<T | null>; all<T>(): Promise<{ results?: T[] }>; run(): Promise<unknown> };
type Database = { prepare(sql: string): Statement; batch?(statements: Statement[]): Promise<Array<{ meta?: { changes?: number } }>> };

/** Free during the launch period; set HALL_LAMP_COST (credits) on the server to start charging (2 ≈ US$0.50). */
export const LAMP_COST = 0;
export const LAMP_HOURS = 24;
export function lampCost(value: string | undefined) { const n = Number(value); return Number.isInteger(n) && n >= 0 && n <= 50 ? n : LAMP_COST; }
export const LAMP_DAILY_LIMIT = 5;
export const LAMP_KINDS = ["peace", "study", "health", "career", "love", "family"] as const;
export type LampKind = (typeof LAMP_KINDS)[number];
export type Lamp = { id: string; name: string; wish: string | null; kind: LampKind; mine: boolean; createdAt: string; expiresAt: string };

const BLOCKED = /(https?:|www\.|\.com|\.net|\.cn|\.io|t\.me|@|微信|威信|vx|wx|qq|扣扣|telegram|whats\s*app|line\s*id|加我|私聊|代理|返利|赌|博彩|色情|约炮|fuck|shit|sex|porn)/i;
/** A short wish: up to 40 characters of letters, digits, CJK and ordinary punctuation; no links, contacts or abuse. */
export function cleanWish(value: unknown): string | null | false {
  if (value === undefined || value === null || value === "") return null;
  if (typeof value !== "string") return false;
  const text = value.normalize("NFC").replace(/[\u0000-\u001f\u007f\u200b-\u200f\u2028-\u202e]/g, "").replace(/\s+/g, " ").trim();
  if (!text) return null;
  if ([...text].length > 40) return false;
  if (!/^[\p{L}\p{M}\p{N} ·・'’,，.。!！?？、~～:：;；()（）&+-]+$/u.test(text)) return false;
  const folded = text.normalize("NFKC");
  if (BLOCKED.test(folded.replace(/\s/g, "")) || /\d{5,}/.test(folded)) return false;
  return text;
}

const toLamp = (row: { id: string; member_id: string; name: string; wish: string | null; kind: string; public: number; created_at: string; expires_at: string }, memberId: string | null): Lamp => ({
  id: row.id, name: row.name, wish: row.public || row.member_id === memberId ? row.wish : null,
  kind: (LAMP_KINDS as readonly string[]).includes(row.kind) ? row.kind as LampKind : "peace",
  mine: row.member_id === memberId, createdAt: row.created_at, expiresAt: row.expires_at,
});

/** Lamps glowing now: the most recent 60 public ones plus all of the member's own. Private lamps show no wish to others. */
export async function listLamps(db: Database, memberId: string | null, now: Date) {
  const nowIso = now.toISOString();
  const rows = await db.prepare("SELECT id, member_id, name, wish, kind, public, created_at, expires_at FROM hall_lamps WHERE expires_at > ? AND (public = 1 OR member_id = ?) ORDER BY created_at DESC LIMIT 80").bind(nowIso, memberId ?? "").all<Parameters<typeof toLamp>[0]>();
  const lamps = (rows.results ?? []).map((row) => toLamp(row, memberId));
  const mine = lamps.filter((lamp) => lamp.mine);
  const others = lamps.filter((lamp) => !lamp.mine).slice(0, 60);
  return [...mine, ...others];
}

export class LampError extends Error { constructor(public code: "INVALID_WISH" | "INVALID_NAME" | "DAILY_LIMIT" | "INSUFFICIENT_CREDITS") { super(code); } }

/** Light a lamp: when it costs credits, debit them (daily credits first) and write the ledger row and the lamp in one batch. */
export async function lightLamp(db: Database, input: { memberId: string; cost?: number; name?: unknown; wish?: unknown; kind?: unknown; public?: unknown; now: Date }) {
  const wish = cleanWish(input.wish);
  if (wish === false) throw new LampError("INVALID_WISH");
  let name = randomDaoName(input.memberId).name;
  if (input.name !== undefined && input.name !== null && input.name !== "") { const chosen = cleanDaoName(input.name); if (!chosen) throw new LampError("INVALID_NAME"); name = chosen; }
  const kind: LampKind = (LAMP_KINDS as readonly unknown[]).includes(input.kind) ? input.kind as LampKind : "peace";
  const visible = input.public === false ? 0 : 1;
  const nowIso = input.now.toISOString();
  const dayStart = new Date(input.now.getTime() - 24 * 3600_000).toISOString();
  const today = await db.prepare("SELECT COUNT(*) AS n FROM hall_lamps WHERE member_id = ? AND created_at > ?").bind(input.memberId, dayStart).first<{ n: number }>();
  if (Number(today?.n ?? 0) >= LAMP_DAILY_LIMIT) throw new LampError("DAILY_LIMIT");
  const id = crypto.randomUUID(), ledgerId = crypto.randomUUID();
  const expires = new Date(input.now.getTime() + LAMP_HOURS * 3600_000).toISOString();
  const cost = input.cost ?? LAMP_COST;
  if (cost === 0) {
    await db.prepare("INSERT INTO hall_lamps (id, member_id, name, wish, kind, public, ledger_id, created_at, expires_at) VALUES (?, ?, ?, ?, ?, ?, 'free', ?, ?)").bind(id, input.memberId, name, wish, kind, visible, nowIso, expires).run();
    await db.prepare("DELETE FROM hall_lamps WHERE expires_at < ?").bind(new Date(input.now.getTime() - 24 * 3600_000).toISOString()).run();
    return { id, name, wish, kind, mine: true, createdAt: nowIso, expiresAt: expires } satisfies Lamp;
  }
  const [debit] = await db.batch!([
    db.prepare("UPDATE members SET daily_credits = daily_credits - MIN(daily_credits, ?), credits = credits - MAX(0, ? - daily_credits), updated_at = ? WHERE id = ? AND credits + daily_credits >= ?").bind(cost, cost, nowIso, input.memberId, cost),
    db.prepare("INSERT INTO credit_ledger (id, member_id, order_id, delta, balance_after, reason, created_at) SELECT ?, id, NULL, ?, credits + daily_credits, ?, ? FROM members WHERE id = ? AND changes() = 1").bind(ledgerId, -cost, `hall_lamp:${kind}`, nowIso, input.memberId),
    db.prepare("INSERT INTO hall_lamps (id, member_id, name, wish, kind, public, ledger_id, created_at, expires_at) SELECT ?, ?, ?, ?, ?, ?, ?, ?, ? WHERE EXISTS (SELECT 1 FROM credit_ledger WHERE id = ?)").bind(id, input.memberId, name, wish, kind, visible, ledgerId, nowIso, expires, ledgerId),
  ]);
  if ((debit.meta?.changes ?? 0) !== 1) throw new LampError("INSUFFICIENT_CREDITS");
  // Old lamps are tidied up a day after they go out.
  await db.prepare("DELETE FROM hall_lamps WHERE expires_at < ?").bind(new Date(input.now.getTime() - 24 * 3600_000).toISOString()).run();
  return { id, name, wish, kind, mine: true, createdAt: nowIso, expiresAt: expires } satisfies Lamp;
}
