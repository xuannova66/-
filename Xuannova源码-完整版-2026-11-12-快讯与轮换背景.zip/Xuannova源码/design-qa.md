# Design QA — Xuanyuan Institute local edition

## Visual reference and scope

- Reference examined: public desktop tool forms at `https://www.qingnang.cc/bazi`, plus the two supplied desktop reference images, on 2026-07-29.
- Local implementation inspected at `http://localhost:3000/` on desktop and at a 390 × 844 mobile viewport.
- The comparison was made in one browser input with the public BaZi form screenshot followed by the Xuanyuan local BaZi screen. The local version deliberately preserves the Xuanyuan Institute name, supplied brand copy and original local artwork; no Qingnang logos, text, source files, paid content or original artwork were imported.

## Fidelity checks

| Surface | Result |
| --- | --- |
| Desktop hierarchy | Passed — slim dark header, full-bleed dark hero, centered institute mark, primary actions, floating theme control and a dense tool catalogue are present. |
| Brand and copy | Passed — the English visual wordmark is now the single upright `XUANYUAN` word; supplied English/Chinese copy replaces the source brand and copy. |
| Contrast and spacing | Passed — primary actions, header controls, cards and forms remain readable against the dark theme. |
| Desktop interaction | Passed — study-method drawer, 11 study routes, birth/pair/inquiry input families, local output panels, toolkit, daily rhythm, library, language picker, themes and membership view were exercised. |
| Responsive styling | Passed — a live 390 × 844 screenshot of the Liuyao flow confirmed the one-column header, category grid, casting controls and mobile navigation trigger. |
| Staged tool flow | Passed — each study route now has independent `input → ritual → chart → reading` hash stages, with only one substantive stage rendered at a time. |
| Chart richness | Passed — BaZi now shows four 12-field pillar cards plus an immediate 17-layer reference deck; Zi Wei, Qi Men, Liuyao and Da Liu Ren retain their own complete board structures rather than a shared generic result card. |
| Language isolation | Passed — Simplified Chinese, Traditional Chinese, Japanese, Korean, Vietnamese and Thai chart screens were checked live for stray English UI; inputs, selectors, headers, footer, library and tool stages use the active locale. |
| Worldwide location search | Passed — birth and inquiry forms use a searchable worldwide country/city field with returned coordinates and IANA time zone, rather than a fixed regional selector. |
| Time basis | Passed — after selecting New York and enabling true solar time, the generated BaZi chart displayed `真太阳时 · 11:01` alongside the civil-time context. |

## Functional QA evidence

- All 11 study routes load with their intended headings: Synthesis Reading, BaZi, BaZi Deep Reading, Compatibility, Zi Wei, Celestial Chart, Liuyao, Qi Men, Da Liu Ren, Inquiry Synthesis and Mirror Reflection.
- Confirmed solar/lunar conversion, Four Pillars, NaYin, zodiac and Five Elements counts from the local calendar data source for a supplied birth moment.
- Checked the full birth form: name, yin/yang orientation, solar/lunar/manual-pillar input, year/month/day/time, place and true-solar-time note.
- Checked the paired compatibility form for two separately configurable birth profiles.
- Checked Liuyao's system cast, manual coin-line and direct-line interfaces; generated a manual six-line result from a Japanese inquiry using the current moment.
- Checked Qi Men / Da Liu Ren shared inquiry controls: question category, question, current moment, date/time, location and advanced local note.
- Checked the toolkit's Time Calibration / Five Elements / Natal Chart flow for name, birth date, birth time and local calendar summary; other toolkit tools retain their purpose-specific text prompt.
- Confirmed all seven locale selections: English, Simplified Chinese, Traditional Chinese, Japanese, Korean, Vietnamese and Thai. Japanese tool form and result labels were checked live.
- Confirmed the seven-locale chart flow on a Qi Men board: all locale selections kept the active chart stage and non-English selections had no residual English chart controls or board labels.
- Confirmed Vietnamese mobile input at 390 × 844, including native calendar, place and action labels. The native place selector now renders Global / East Asia / Southeast Asia / Europe / Americas in the selected locale.
- Confirmed a Vietnamese library view with native article cards and detail text; no English source article body is shown outside the English locale.
- Confirmed ritual presentation at `#bazi/ritual`, including its intermediate state before the automatic transition to `#bazi/chart`.
- Re-ran the BaZi desktop chart for a complete input: all four pillars show stem/branch element, Ten God, hidden stem, life stage, NaYin, position, day-stem relation, seasonal status and cultural marker; the board directly exposes all 17 supporting reference layers.
- Rechecked the Simplified Chinese BaZi board after adding the reference deck: all visible rich-chart headings, labels and study notes are specific Chinese text, rather than a generic fallback label.
- Rechecked the English desktop hero: `XUANYUAN` stays horizontal and centered without the prior skewed story-mark treatment.
- Verified `pnpm run lint`, `pnpm test`, `pnpm run build`, `pnpm exec tsx --test tests/locale-copy.test.mjs tests/chart-engine.test.mjs` and SSR tests before deployment.
- Rechecked the complete BaZi result after selecting a worldwide city: the selected city remains locked after selection (no repeated dropdown), and its coordinates/time zone drive the local true-solar-time correction.
- Rechecked the Japanese result view: UI labels, chart-time indicator and country label switch with the active locale; classical chart symbols remain intentionally visible as the source notation.

## Privacy and implementation boundaries

- The public preview deploys only the built application assets. No local file paths, browser profile data, system files, contacts, credentials or API keys are included.
- The implementation uses independent deterministic cultural-study layouts and local data. It does not include Qingnang source code, copyrighted visual assets, or a claim of proprietary calculation parity.
- The interpretation view exposes a local request payload seam for a future API connection; no remote AI credential is embedded in this build.
- Worldwide search sends only the typed place query to Open-Meteo's public geocoding endpoint; birth details, questions and chart outputs remain in the browser.
- Confirmed Aureate, Paper and Nocturne theme choices, ending in Nocturne for the delivered preview.

## Result

No P0, P1 or P2 visual or functional issues remain from the checked desktop flows.

**Final result: passed**
