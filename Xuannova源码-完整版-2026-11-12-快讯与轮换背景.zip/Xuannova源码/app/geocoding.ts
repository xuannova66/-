export type GlobalLocation = {
  id: number;
  name: string;
  country: string;
  countryCode?: string;
  admin1?: string;
  latitude: number;
  longitude: number;
  timezone: string;
  label: string;
  /** GeoNames feature code from the provider: PPL… for cities and towns, PCLI for countries, ADM1 for provinces. */
  featureCode?: string;
};

type OpenMeteoPlace = Partial<Omit<GlobalLocation, "label" | "countryCode" | "featureCode">> & { country_code?: string; feature_code?: string };

const isoRegionCodes = `AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW`.split(" ");

// A compact bridge for common local spellings that are only indexed under an
// international name by the global city provider. Other cities still use the
// provider's worldwide index directly, with optional country-code filtering.
const citySearchAliases: Record<string, string[]> = {
  "東京": ["Tokyo"], "東京都": ["Tokyo"], "大阪": ["Osaka"], "大阪市": ["Osaka"], "京都": ["Kyoto"], "横浜": ["Yokohama"], "名古屋": ["Nagoya"], "札幌": ["Sapporo"], "福岡": ["Fukuoka"], "神戸": ["Kobe"], "仙台": ["Sendai"],
  "서울": ["Seoul"], "부산": ["Busan"], "인천": ["Incheon"], "대구": ["Daegu"], "대전": ["Daejeon"], "광주": ["Gwangju"], "울산": ["Ulsan"],
  "北京": ["Beijing"], "上海": ["Shanghai"], "广州": ["Guangzhou"], "深圳": ["Shenzhen"], "成都": ["Chengdu"], "重庆": ["Chongqing"], "西安": ["Xi'an"], "杭州": ["Hangzhou"], "武汉": ["Wuhan"], "南京": ["Nanjing"], "天津": ["Tianjin"],
  "台北": ["Taipei"], "臺北": ["Taipei"], "高雄": ["Kaohsiung"], "香港": ["Hong Kong"], "澳門": ["Macau"],
};

function geocodingLanguage(locale: string) {
  const languages: Record<string, string> = {
    "zh-Hans": "zh",
    "zh-Hant": "zh",
    ja: "ja",
    ko: "ko",
    vi: "vi",
    th: "th",
    en: "en",
  };
  return languages[locale] ?? "en";
}

function comparablePlaceName(value: string) {
  return value
    .trim()
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .toLocaleLowerCase()
    .replace(/[^\p{Letter}\p{Number}]+/gu, "");
}

function resemblesCountryName(query: string, countryName: string) {
  const normalizedQuery = comparablePlaceName(query);
  const normalizedCountry = comparablePlaceName(countryName);
  return normalizedQuery === normalizedCountry
    || normalizedQuery.endsWith(normalizedCountry)
    || normalizedCountry.endsWith(normalizedQuery);
}

type CountrySearchMatch = { code: string; englishName: string };

function countrySearchMatch(query: string, locale: string): CountrySearchMatch | null {
  const requestedName = query.trim();
  if (requestedName.length < 2 || typeof Intl.DisplayNames !== "function") return null;
  const possibleCode = requestedName.toUpperCase();
  const englishNames = new Intl.DisplayNames(["en"], { type: "region" });
  if (isoRegionCodes.includes(possibleCode)) return { code: possibleCode, englishName: englishNames.of(possibleCode) ?? possibleCode };
  const languages = [...new Set([locale, geocodingLanguage(locale), "en"])];
  try {
    for (const code of isoRegionCodes) {
      for (const language of languages) {
        const localizedName = new Intl.DisplayNames([language], { type: "region" }).of(code);
        if (localizedName && resemblesCountryName(requestedName, localizedName)) {
          return { code, englishName: englishNames.of(code) ?? code };
        }
      }
    }
  } catch {
    return null;
  }
  return null;
}

export function countrySearchName(query: string, locale: string) {
  return countrySearchMatch(query, locale)?.englishName ?? null;
}

export function buildGeocodingUrl(query: string, language: string, countryCode?: string) {
  const params = new URLSearchParams({ name: query.trim(), count: "8", language, format: "json" });
  if (countryCode) params.set("countryCode", countryCode);
  return `https://geocoding-api.open-meteo.com/v1/search?${params.toString()}`;
}

export function buildGeocodingUrls(query: string, locale: string) {
  const localizedLanguage = geocodingLanguage(locale);
  const normalizedQuery = query.trim();
  const [placeName, qualifier] = normalizedQuery.split(",", 2).map((part) => part.trim());
  const country = countrySearchMatch(qualifier || normalizedQuery, locale);
  const aliases = citySearchAliases[placeName] ?? [];
  const candidates = [
    { query: normalizedQuery, language: localizedLanguage },
    ...(localizedLanguage === "en" ? [] : [{ query: normalizedQuery, language: "en" }]),
    ...(country && qualifier && placeName ? [
      { query: placeName, language: localizedLanguage, countryCode: country.code },
      ...(localizedLanguage === "en" ? [] : [{ query: placeName, language: "en", countryCode: country.code }]),
      ...aliases.map((alias) => ({ query: alias, language: "en", countryCode: country.code })),
      { query: `${placeName}, ${country.englishName}`, language: "en", countryCode: country.code },
    ] : []),
    ...(!country && placeName ? aliases.map((alias) => ({ query: alias, language: "en" })) : []),
    ...(country && !qualifier && country.englishName !== normalizedQuery ? [{ query: country.englishName, language: "en", countryCode: country.code }] : []),
  ];
  return [...new Set(candidates.map((candidate) => buildGeocodingUrl(candidate.query, candidate.language, candidate.countryCode)))];
}

export function buildGlobalLocationSearchUrl(query: string, locale: string) {
  const params = new URLSearchParams({ q: query.trim(), locale });
  return `/api/geocode?${params.toString()}`;
}

export function buildTimezoneUrl(latitude: number, longitude: number) {
  const params = new URLSearchParams({ latitude: String(latitude), longitude: String(longitude), current: "temperature_2m", timezone: "auto" });
  return `https://api.open-meteo.com/v1/forecast?${params.toString()}`;
}

export function normalizeGeocodingResults(payload: { results?: OpenMeteoPlace[] | null }): GlobalLocation[] {
  return (payload.results ?? []).flatMap((place) => {
    if (typeof place.id !== "number" || !place.name || !place.country || typeof place.latitude !== "number" || typeof place.longitude !== "number") return [];
    const location = [place.name, place.admin1, place.country].filter(Boolean).join(", ");
    return [{
      id: place.id,
      name: place.name,
      country: place.country,
      ...(place.country_code ? { countryCode: place.country_code } : {}),
      ...(place.admin1 ? { admin1: place.admin1 } : {}),
      ...(typeof place.feature_code === "string" ? { featureCode: place.feature_code } : {}),
      latitude: place.latitude,
      longitude: place.longitude,
      timezone: typeof place.timezone === "string" ? place.timezone : "",
      label: location,
    }];
  });
}

export function mergeGeocodingResults(groups: GlobalLocation[][]) {
  const byId = new Map<number, GlobalLocation>();
  for (const location of groups.flat()) {
    const current = byId.get(location.id);
    if (!current || (!current.timezone && location.timezone)) byId.set(location.id, location);
  }
  return [...byId.values()].slice(0, 8);
}

export async function resolveLocationTimezone(location: GlobalLocation, fetchImpl: typeof fetch = fetch) {
  if (location.timezone) return location;
  try {
    const response = await fetchImpl(buildTimezoneUrl(location.latitude, location.longitude));
    if (!response.ok) return location;
    const payload = await response.json() as { timezone?: unknown };
    return typeof payload.timezone === "string" && payload.timezone
      ? { ...location, timezone: payload.timezone }
      : location;
  } catch {
    return location;
  }
}

export function formatGlobalLocation(location: GlobalLocation, locale: string) {
  let country = location.country;
  if (location.countryCode) {
    try {
      country = new Intl.DisplayNames([locale], { type: "region" }).of(location.countryCode) ?? location.country;
    } catch {
      country = location.country;
    }
  }
  return [location.name, location.admin1, country].filter(Boolean).join(", ");
}
