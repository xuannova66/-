/** Public contact details only. Administration credentials belong in Worker secrets. */
export const contactConfig = {
  supportEmail: "Xuannova66@gmail.com",
  telegram: { handle: "@xuannova3", url: "https://t.me/xuannova3" },
  x: { handle: "@xuannova", url: "https://x.com/xuannova" },
  whatsapp: { handle: "+601130189657", url: "https://wa.me/601130189657" },
  line: { handle: "xuannova", url: "https://line.me/R/ti/p/~xuannova" },
  // KakaoTalk has no public web link for adding a phone number; the number is shown with a copy button.
  kakaotalk: { handle: "+84077573448" },
} as const;

export const publicContacts: ReadonlyArray<{ label: string; handle: string; url?: string }> = [
  { label: "Email", handle: contactConfig.supportEmail },
  { label: "Telegram", handle: contactConfig.telegram.handle, url: contactConfig.telegram.url },
  { label: "X", handle: contactConfig.x.handle, url: contactConfig.x.url },
  { label: "WhatsApp", handle: contactConfig.whatsapp.handle, url: contactConfig.whatsapp.url },
  { label: "LINE", handle: contactConfig.line.handle, url: contactConfig.line.url },
  { label: "KakaoTalk", handle: contactConfig.kakaotalk.handle },
];

export const hasConfiguredContact = publicContacts.length > 0;

/** Legal operator shown on the policy pages. Fill in before launch (company name and registered address). */
export const legalEntity = { name: "", address: "" };

/**
 * 器物坊 (Workshop) address. "/shop" on the main domain always works. When shop.xuannova.com is set up
 * (DNS A record + the Caddy block in deploy/aws/Caddyfile), this can be changed to "https://shop.xuannova.com".
 */
export const workshopUrl = "/shop";
/** Workshop link that opens in the visitor's current language. */
export const workshopHref = (locale: string) => `${workshopUrl}?lang=${encodeURIComponent(locale)}`;

/**
 * Marketing / analytics IDs. Leave empty to load nothing. Scripts load only after the visitor
 * chooses "Accept all" in the cookie banner. Example: ga4: "G-XXXXXXX", metaPixel: "1234567890", tiktok: "CXXXXXXX".
 */
export const analyticsConfig = { ga4: "G-VEWRZGN10C", metaPixel: "", tiktok: "" };
