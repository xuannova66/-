import type { Locale } from "./site-content";

export type CreditCopy = {
  eyebrow: string;
  wallet: string;
  walletLead: string;
  available: string;
  credits: string;
  standardRule: string;
  synthesisRule: string;
  packages: string;
  packageLead: string;
  payWithUsdt: string;
  paymentPending: string;
  paymentSafetyNote: string;
  cost: string;
  insufficient: string;
  viewMembership: string;
  afterPayment: string;
  deviceNote: string;
};

const copy: Record<Locale, CreditCopy> = {
  en: {
    eyebrow: "CREDIT WALLET · USDT",
    wallet: "Interpretation credits",
    walletLead: "Credits are charged only when an interpretation is generated.",
    available: "Available credits",
    credits: "credits",
    standardRule: "Every interpretation · 20 credits",
    synthesisRule: "BaZi deep reading · 40 credits",
    packages: "USDT credit packages",
    packageLead: "Choose a package after the owner connects the payment channel.",
    payWithUsdt: "Pay with USDT",
    paymentPending: "USDT payment channel is being configured",
    paymentSafetyNote: "No payment is collected or confirmed in this preview. Credits are never added automatically before verification is connected.",
    cost: "This interpretation costs",
    insufficient: "Your balance is not enough for this interpretation.",
    viewMembership: "View credit packages",
    afterPayment: "After payment verification, credits will be added to your account.",
    deviceNote: "Current balance is stored only in this browser during the local preview.",
  },
  "zh-Hans": {
    eyebrow: "积分钱包 · USDT",
    wallet: "解读积分",
    walletLead: "仅在生成一次解读时扣除积分。",
    available: "可用积分",
    credits: "积分",
    standardRule: "每次解读 · 20 积分",
    synthesisRule: "八字详研 · 40 积分",
    packages: "USDT 积分套餐",
    packageLead: "站主接入收款通道后即可选择套餐。",
    payWithUsdt: "使用 USDT 支付",
    paymentPending: "USDT 收款通道配置中",
    paymentSafetyNote: "当前预览不会收款或确认支付；接入核验前，积分不会被自动充值。",
    cost: "本次解读消耗",
    insufficient: "当前积分不足，无法生成本次解读。",
    viewMembership: "查看积分套餐",
    afterPayment: "支付核验完成后，积分将加入你的账户。",
    deviceNote: "本地预览期间，当前积分余额仅保存在此浏览器中。",
  },
  "zh-Hant": {
    eyebrow: "積分錢包 · USDT",
    wallet: "解讀積分",
    walletLead: "僅在產生一次解讀時扣除積分。",
    available: "可用積分",
    credits: "積分",
    standardRule: "每次解讀 · 20 積分",
    synthesisRule: "八字詳研 · 40 積分",
    packages: "USDT 積分方案",
    packageLead: "站主接入收款通道後即可選擇方案。",
    payWithUsdt: "使用 USDT 付款",
    paymentPending: "USDT 收款通道設定中",
    paymentSafetyNote: "目前預覽不會收款或確認付款；接入核驗前，積分不會自動入帳。",
    cost: "本次解讀消耗",
    insufficient: "目前積分不足，無法產生本次解讀。",
    viewMembership: "查看積分方案",
    afterPayment: "付款核驗完成後，積分將加入你的帳戶。",
    deviceNote: "本地預覽期間，目前積分餘額僅儲存在此瀏覽器中。",
  },
  ja: {
    eyebrow: "クレジットウォレット · USDT",
    wallet: "解釈クレジット",
    walletLead: "解釈を生成したときだけクレジットが消費されます。",
    available: "利用可能なクレジット",
    credits: "クレジット",
    standardRule: "すべての解釈 · 20 クレジット",
    synthesisRule: "八字詳細 · 40 クレジット",
    packages: "USDT クレジットパッケージ",
    packageLead: "運営者が決済チャネルを接続するとパッケージを選択できます。",
    payWithUsdt: "USDT で支払う",
    paymentPending: "USDT 決済チャネルを設定中です",
    paymentSafetyNote: "このプレビューでは決済の受領・確認は行いません。認証連携前にクレジットが自動追加されることはありません。",
    cost: "この解釈の必要クレジット",
    insufficient: "この解釈に必要なクレジットが不足しています。",
    viewMembership: "クレジットパッケージを見る",
    afterPayment: "決済の確認後、クレジットがアカウントに追加されます。",
    deviceNote: "ローカルプレビュー中の残高は、このブラウザにのみ保存されます。",
  },
  ko: {
    eyebrow: "크레딧 지갑 · USDT",
    wallet: "해석 크레딧",
    walletLead: "해석을 생성할 때에만 크레딧이 차감됩니다.",
    available: "사용 가능 크레딧",
    credits: "크레딧",
    standardRule: "모든 해석 · 20 크레딧",
    synthesisRule: "사주 심화 · 40 크레딧",
    packages: "USDT 크레딧 패키지",
    packageLead: "운영자가 결제 채널을 연결하면 패키지를 선택할 수 있습니다.",
    payWithUsdt: "USDT로 결제",
    paymentPending: "USDT 결제 채널을 설정하고 있습니다",
    paymentSafetyNote: "이 미리보기에서는 결제를 수령하거나 확인하지 않습니다. 검증 연동 전에는 크레딧이 자동으로 추가되지 않습니다.",
    cost: "이번 해석에 필요한 크레딧",
    insufficient: "이번 해석에 필요한 크레딧이 부족합니다.",
    viewMembership: "크레딧 패키지 보기",
    afterPayment: "결제 확인 후 크레딧이 계정에 추가됩니다.",
    deviceNote: "로컬 미리보기 중 잔액은 이 브라우저에만 저장됩니다.",
  },
  vi: {
    eyebrow: "VÍ ĐIỂM · USDT",
    wallet: "Điểm diễn giải",
    walletLead: "Điểm chỉ được trừ khi một phần diễn giải được tạo.",
    available: "Điểm khả dụng",
    credits: "điểm",
    standardRule: "Mỗi lần diễn giải · 20 điểm",
    synthesisRule: "Bát tự chuyên sâu · 40 điểm",
    packages: "Gói điểm USDT",
    packageLead: "Bạn có thể chọn gói sau khi chủ sở hữu kết nối kênh thanh toán.",
    payWithUsdt: "Thanh toán bằng USDT",
    paymentPending: "Kênh thanh toán USDT đang được cấu hình",
    paymentSafetyNote: "Bản xem trước này không thu hoặc xác nhận thanh toán. Điểm không bao giờ được cộng tự động trước khi kết nối xác minh.",
    cost: "Chi phí của phần diễn giải này",
    insufficient: "Số dư của bạn không đủ cho phần diễn giải này.",
    viewMembership: "Xem gói điểm",
    afterPayment: "Sau khi thanh toán được xác minh, điểm sẽ được cộng vào tài khoản của bạn.",
    deviceNote: "Trong bản xem trước cục bộ, số dư chỉ được lưu trong trình duyệt này.",
  },
  th: {
    eyebrow: "กระเป๋าเครดิต · USDT",
    wallet: "เครดิตสำหรับคำอธิบาย",
    walletLead: "เครดิตจะถูกหักเมื่อสร้างคำอธิบายเท่านั้น",
    available: "เครดิตที่ใช้ได้",
    credits: "เครดิต",
    standardRule: "ทุกการอธิบาย · 20 เครดิต",
    synthesisRule: "ปาจื้อเชิงลึก · 40 เครดิต",
    packages: "แพ็กเกจเครดิต USDT",
    packageLead: "เลือกแพ็กเกจได้หลังจากผู้ดูแลเชื่อมต่อช่องทางการชำระเงินแล้ว",
    payWithUsdt: "ชำระด้วย USDT",
    paymentPending: "กำลังตั้งค่าช่องทางชำระเงิน USDT",
    paymentSafetyNote: "ตัวอย่างนี้จะไม่รับหรือยืนยันการชำระเงิน เครดิตจะไม่ถูกเพิ่มโดยอัตโนมัติก่อนเชื่อมต่อการตรวจสอบ",
    cost: "ค่าใช้จ่ายของคำอธิบายนี้",
    insufficient: "ยอดเครดิตของคุณไม่เพียงพอสำหรับคำอธิบายนี้",
    viewMembership: "ดูแพ็กเกจเครดิต",
    afterPayment: "หลังยืนยันการชำระเงิน เครดิตจะถูกเพิ่มในบัญชีของคุณ",
    deviceNote: "ในระหว่างตัวอย่าง ยอดเครดิตจะเก็บไว้ในเบราว์เซอร์นี้เท่านั้น",
  },
};

export function creditCopy(locale: Locale): CreditCopy {
  return copy[locale];
}
