"use client";
// Screens that are not on the first page a visitor sees are loaded as separate pieces, so a phone opening the site
// (or a QR code from a poster) downloads and starts much less code before the home page can be used. Right after the
// home page has settled they are fetched in the background, so tapping 黄历, 研习殿, 我的… later is still instant.
import { lazy, Suspense, type ComponentProps, type ComponentType } from "react";

const loaders = {
  member: () => import("./member-commerce-center"),
  hall: () => import("./study-hall-3d"),
  xiangshu: () => import("./xiangshu-screen"),
  cezi: () => import("./cezi-screen"),
  floorplan: () => import("./floorplan-fengshui"),
  library: () => import("./library-explorer"),
  almanac: () => import("./almanac-screen"),
};

function piece<P extends object>(load: () => Promise<{ default: ComponentType<P> }>) {
  const Lazy = lazy(load);
  return function LazyPiece(props: P) {
    return <Suspense fallback={<div className="lazy-screen-loading" aria-busy="true"><i /></div>}><Lazy {...props} /></Suspense>;
  };
}

type Member = typeof import("./member-commerce-center").MemberCommerceCenter;
type Hall = typeof import("./study-hall-3d").StudyHall3D;
type Xiangshu = typeof import("./xiangshu-screen").XiangshuScreen;
type Cezi = typeof import("./cezi-screen").CeziScreen;
type FloorPlan = typeof import("./floorplan-fengshui").FloorPlanFengShui;
type Library = typeof import("./library-explorer").LibraryExplorer;
type Almanac = typeof import("./almanac-screen").AlmanacScreen;

export const MemberCommerceCenter = piece<ComponentProps<Member>>(() => loaders.member().then((m) => ({ default: m.MemberCommerceCenter })));
export const StudyHall3D = piece<ComponentProps<Hall>>(() => loaders.hall().then((m) => ({ default: m.StudyHall3D })));
export const XiangshuScreen = piece<ComponentProps<Xiangshu>>(() => loaders.xiangshu().then((m) => ({ default: m.XiangshuScreen })));
export const CeziScreen = piece<ComponentProps<Cezi>>(() => loaders.cezi().then((m) => ({ default: m.CeziScreen })));
export const FloorPlanFengShui = piece<ComponentProps<FloorPlan>>(() => loaders.floorplan().then((m) => ({ default: m.FloorPlanFengShui })));
export const LibraryExplorer = piece<ComponentProps<Library>>(() => loaders.library().then((m) => ({ default: m.LibraryExplorer })));
export const AlmanacScreen = piece<ComponentProps<Almanac>>(() => loaders.almanac().then((m) => ({ default: m.AlmanacScreen })));

/** Fetch every piece in the background, one after another, once the first page is up. */
export function prefetchScreens() {
  if (typeof window === "undefined") return;
  const order: Array<keyof typeof loaders> = ["almanac", "member", "hall", "library", "xiangshu", "cezi", "floorplan"];
  const w = window as Window & { requestIdleCallback?: (cb: () => void, o?: { timeout: number }) => number };
  const next = () => {
    const key = order.shift();
    if (!key) return;
    loaders[key]().catch(() => undefined).finally(() => { if (w.requestIdleCallback) w.requestIdleCallback(next, { timeout: 2000 }); else setTimeout(next, 150); });
  };
  next();
}
