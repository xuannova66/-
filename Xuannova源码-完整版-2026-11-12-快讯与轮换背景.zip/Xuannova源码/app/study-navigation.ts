import type { AppRoute } from "./study-suite";

export type StudyStage = "input" | "ritual" | "chart" | "reading";

const routes = new Set<AppRoute>([
  "home",
  "flash",
  "hecan",
  "bazi",
  "detail",
  "compatibility",
  "liuyao",
  "ziwei",
  "qizheng",
  "qimen",
  "daliuren",
  "meihua",
  "jinkoujue",
  "heluo",
  "tieban",
  "taiyi",
  "zhuzhai",
  "zeri",
  "wenshi",
  "mirror",
  "toolkit",
  "daily",
  "library",
  "courses",
  "guide",
  "almanac",
  "xiangshu",
  "cezi",
  "membership",
  "credits",
  "admin",
]);

const stagedRoutes = new Set<AppRoute>([
  "hecan",
  "bazi",
  "detail",
  "compatibility",
  "liuyao",
  "ziwei",
  "qizheng",
  "qimen",
  "daliuren",
  "meihua",
  "jinkoujue",
  "heluo",
  "tieban",
  "taiyi",
  "zhuzhai",
  "zeri",
  "wenshi",
  "mirror",
  "toolkit",
  "daily",
]);

const stages = new Set<StudyStage>(["input", "ritual", "chart", "reading"]);

export function isStudyRoute(route: AppRoute): boolean {
  return stagedRoutes.has(route);
}

export function parseStudyLocation(hash: string): { route: AppRoute; stage: StudyStage } {
  const [rawRoute = "home", rawStage] = hash.replace(/^#/, "").split("/");
  const route = routes.has(rawRoute as AppRoute) ? (rawRoute as AppRoute) : "home";
  const stage = rawStage && stages.has(rawStage as StudyStage) && isStudyRoute(route) ? (rawStage as StudyStage) : "input";
  return { route, stage };
}

export function hashForStudyStage(route: AppRoute, stage: StudyStage = "input"): string {
  if (!isStudyRoute(route) || stage === "input") return `#${route}`;
  return `#${route}/${stage}`;
}

// ---------------------------------------------------------------------------------------------
// Real URLs for search engines: /{lang}/{route}/{stage}. English has no prefix (/bazi);
// other languages use /zh-hans/bazi, /ja/bazi … Old "#bazi" links are redirected client-side.
// ---------------------------------------------------------------------------------------------
export type UrlLocale = "en" | "zh-Hans" | "zh-Hant" | "ja" | "ko" | "vi" | "th";
export const URL_LOCALES: UrlLocale[] = ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"];
const localeSegment = (locale: UrlLocale) => locale.toLowerCase();
export const PUBLIC_ROUTES: AppRoute[] = ["home", "bazi", "detail", "ziwei", "qizheng", "compatibility", "hecan", "liuyao", "qimen", "daliuren", "meihua", "jinkoujue", "heluo", "tieban", "taiyi", "zhuzhai", "zeri", "wenshi", "mirror", "daily", "toolkit", "library", "courses", "guide", "almanac", "xiangshu", "cezi", "flash"];

export function parseStudyPath(pathname: string): { locale: UrlLocale | null; route: AppRoute; stage: StudyStage } {
  const parts = pathname.split("/").filter(Boolean).map((part) => decodeURIComponent(part));
  let locale: UrlLocale | null = null;
  const first = parts[0]?.toLowerCase();
  const matched = URL_LOCALES.find((code) => localeSegment(code) === first);
  if (matched) { locale = matched; parts.shift(); }
  const [rawRoute = "home", rawStage] = parts;
  const route = routes.has(rawRoute as AppRoute) ? (rawRoute as AppRoute) : "home";
  const stage = rawStage && stages.has(rawStage as StudyStage) && isStudyRoute(route) ? (rawStage as StudyStage) : "input";
  return { locale, route, stage };
}

export function pathFor(locale: UrlLocale, route: AppRoute, stage: StudyStage = "input"): string {
  const prefix = locale === "en" ? "" : `/${localeSegment(locale)}`;
  if (route === "home") return prefix || "/";
  const stagePart = isStudyRoute(route) && stage !== "input" ? `/${stage}` : "";
  return `${prefix}/${route}${stagePart}`;
}
