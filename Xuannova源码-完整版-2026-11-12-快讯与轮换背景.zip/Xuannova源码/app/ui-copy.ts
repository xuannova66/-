import type { Locale } from "./site-content";

export type UiCopy = {
  brandKicker: string;
  stage: { input: string; generating: string; chart: string; reading: string; backToChart: string; edit: string };
  chart: { openReading: string; backToForm: string; demo: string; favourable: string; avoid: string; source: string; localChart: string };
  account: { access: string; community: string; support: string };
  metrics: { paths: string; themes: string; languages: string; uploads: string };
  visual: { year: string; month: string; day: string; hour: string; seasonal: string };
  home: {
    sourceLabel: string;
    ribbon: string[];
    scholarCode: string;
    hermitCode: string;
    scholarFull: string;
    scholarDirect: string;
    hermitFull: string;
    hermitDirect: string;
    seal: string;
    heroBrand: string;
  };
  footer: { brand: string; copyright: string };
};

const copy: Record<Locale, UiCopy> = {
  en: {
    brandKicker: "Xuannova · STUDY",
    stage: { input: "Prepare study", generating: "Generating chart", chart: "Study chart", reading: "Reading", backToChart: "Back to chart", edit: "Edit information" },
    chart: { openReading: "Open full interpretation", backToForm: "Return to information", demo: "Local demonstration chart", favourable: "Favourable", avoid: "Avoid", source: "Study source", localChart: "Chart" },
    account: { access: "LOCAL ACCESS", community: "COMMUNITY", support: "SUPPORT" },
    metrics: { paths: "paths", themes: "themes", languages: "languages", uploads: "uploads" },
    visual: { year: "YEAR", month: "MONTH", day: "DAY", hour: "HOUR", seasonal: "SEASONAL RHYTHM" },
    home: { sourceLabel: "Study sources", ribbon: ["Yin–Yang", "Five Elements", "Qi", "Seasonal rhythm", "Twelve branches", "Chart language", "Mindful observation"], scholarCode: "SCHOLAR", hermitCode: "HERMIT", scholarFull: "Begin with the arrangement before naming its meaning. A chart is a structured field of information, not an authority over your choices.", scholarDirect: "Notice the pattern. Keep your choice.", hermitFull: "Nothing needs to be solved in one sitting. Keep the useful thread, leave the rest, and return when the day has changed.", hermitDirect: "Keep the useful thread. Leave the rest.", seal: "QI", heroBrand: "Xuannova" },
    footer: { brand: "Xuannova", copyright: "© 2026 Xuannova" },
  },
  "zh-Hans": {
    brandKicker: "Xuannova · 研习",
    stage: { input: "填写信息", generating: "正在生成盘面", chart: "研习盘面", reading: "解读", backToChart: "返回盘面", edit: "修改信息" },
    chart: { openReading: "进入完整解读", backToForm: "返回填写", demo: "示范盘", favourable: "宜", avoid: "忌", source: "研习依据", localChart: "盘面" },
    account: { access: "本地登录", community: "研习社群", support: "联系支持" },
    metrics: { paths: "条研习路径", themes: "个主题", languages: "种语言", uploads: "次上传" },
    visual: { year: "年柱", month: "月柱", day: "日柱", hour: "时柱", seasonal: "时序节律" },
    home: { sourceLabel: "研习源流", ribbon: ["阴阳", "五行", "炁", "四时节律", "十二地支", "盘面语言", "静观自省"], scholarCode: "学者", hermitCode: "隐士", scholarFull: "先看结构，再安放意义。盘面呈现的是结构信息，不替代你对人生的选择。", scholarDirect: "看见结构，选择仍在自己手中。", hermitFull: "不必在一次停留中解决所有事。保留有用的线索，其余暂放，等日子变化后再回看。", hermitDirect: "留住有用的线索，其余暂放。", seal: "炁", heroBrand: "Xuannova" },
    footer: { brand: "Xuannova", copyright: "© 2026 Xuannova" },
  },
  "zh-Hant": {
    brandKicker: "Xuannova · 研習",
    stage: { input: "填寫資料", generating: "正在生成盤面", chart: "研習盤面", reading: "解讀", backToChart: "返回盤面", edit: "修改資料" },
    chart: { openReading: "進入完整解讀", backToForm: "返回填寫", demo: "示範盤", favourable: "宜", avoid: "忌", source: "研習依據", localChart: "盤面" },
    account: { access: "本地登入", community: "研習社群", support: "聯絡支援" },
    metrics: { paths: "條研習路徑", themes: "個主題", languages: "種語言", uploads: "次上傳" },
    visual: { year: "年柱", month: "月柱", day: "日柱", hour: "時柱", seasonal: "時序節律" },
    home: { sourceLabel: "研習源流", ribbon: ["陰陽", "五行", "炁", "四時節律", "十二地支", "盤面語言", "靜觀自省"], scholarCode: "學者", hermitCode: "隱士", scholarFull: "先看結構，再安放意義。盤面呈現的是結構資訊，不取代你對人生的選擇。", scholarDirect: "看見結構，選擇仍在自己手中。", hermitFull: "不必在一次停留中解決所有事。保留有用的線索，其餘暫放，等日子變化後再回看。", hermitDirect: "留住有用的線索，其餘暫放。", seal: "炁", heroBrand: "Xuannova" },
    footer: { brand: "Xuannova", copyright: "© 2026 Xuannova" },
  },
  ja: {
    brandKicker: "Xuannova・学習",
    stage: { input: "情報を入力", generating: "盤面を生成中", chart: "学習盤面", reading: "解説", backToChart: "盤面に戻る", edit: "情報を編集" },
    chart: { openReading: "詳しい解釈を開く", backToForm: "入力に戻る", demo: "見本盤", favourable: "適", avoid: "避", source: "学習の根拠", localChart: "盤面" },
    account: { access: "ローカルアクセス", community: "学習コミュニティ", support: "サポート" },
    metrics: { paths: "の学習経路", themes: "のテーマ", languages: "言語", uploads: "件の送信" },
    visual: { year: "年柱", month: "月柱", day: "日柱", hour: "時柱", seasonal: "季節のリズム" },
    home: { sourceLabel: "学びの源流", ribbon: ["陰陽", "五行", "気", "季節のリズム", "十二支", "盤面の言葉", "静かな観察"], scholarCode: "学者", hermitCode: "隠者", scholarFull: "意味を決める前に、まず配置を見ます。盤面は構造情報の組み合わせであり、あなたの選択を決めるものではありません。", scholarDirect: "構造を見て、選択は自分で行いましょう。", hermitFull: "一度ですべてを解く必要はありません。役立つ糸だけを残し、ほかは置いて、日が変わってから戻りましょう。", hermitDirect: "役立つ糸を残し、ほかは置いてください。", seal: "気", heroBrand: "Xuannova" },
    footer: { brand: "Xuannova", copyright: "© 2026 Xuannova" },
  },
  ko: {
    brandKicker: "Xuannova · 학습",
    stage: { input: "정보 입력", generating: "판면 생성 중", chart: "학습 판면", reading: "해설", backToChart: "판면으로 돌아가기", edit: "정보 수정" },
    chart: { openReading: "전체 해석 열기", backToForm: "입력으로 돌아가기", demo: "예시 판면", favourable: "권장", avoid: "유의", source: "학습 근거", localChart: "판면" },
    account: { access: "로컬 접속", community: "학습 커뮤니티", support: "지원" },
    metrics: { paths: "개 학습 경로", themes: "개 주제", languages: "개 언어", uploads: "회 업로드" },
    visual: { year: "년주", month: "월주", day: "일주", hour: "시주", seasonal: "계절 리듬" },
    home: { sourceLabel: "학습의 뿌리", ribbon: ["음양", "오행", "기", "계절의 리듬", "십이지", "판면 언어", "고요한 관찰"], scholarCode: "학자", hermitCode: "은자", scholarFull: "의미를 붙이기 전에 먼저 배치를 살펴보세요. 판면은 구조 정보의 조합이며, 삶의 선택을 대신하지 않습니다.", scholarDirect: "구조를 보고, 선택은 스스로 하세요.", hermitFull: "한 번에 모두 해결할 필요는 없습니다. 쓸모 있는 실마리만 남기고 나머지는 두었다가, 날이 바뀐 뒤 다시 돌아오세요.", hermitDirect: "쓸모 있는 실마리만 남기고 나머지는 두세요.", seal: "기", heroBrand: "Xuannova" },
    footer: { brand: "Xuannova", copyright: "© 2026 Xuannova" },
  },
  vi: {
    brandKicker: "XUANNOVA · HỌC TẬP CỤC BỘ",
    stage: { input: "Nhập thông tin", generating: "Đang tạo biểu đồ", chart: "Biểu đồ học tập", reading: "Bài giải", backToChart: "Quay lại biểu đồ", edit: "Chỉnh sửa thông tin" },
    chart: { openReading: "Mở phần diễn giải đầy đủ", backToForm: "Quay lại phần nhập", demo: "Biểu đồ minh họa", favourable: "Nên", avoid: "Nên tránh", source: "Cơ sở học tập", localChart: "Biểu đồ" },
    account: { access: "TRUY CẬP CỤC BỘ", community: "CỘNG ĐỒNG", support: "HỖ TRỢ" },
    metrics: { paths: "lộ trình", themes: "chủ đề", languages: "ngôn ngữ", uploads: "lần tải lên" },
    visual: { year: "trụ năm", month: "trụ tháng", day: "trụ ngày", hour: "trụ giờ", seasonal: "NHỊP MÙA" },
    home: { sourceLabel: "Nguồn mạch học tập", ribbon: ["Âm Dương", "Ngũ Hành", "Khí", "Nhịp mùa", "Mười hai địa chi", "Ngôn ngữ bàn cục", "Quan sát tĩnh lặng"], scholarCode: "HỌC GIẢ", hermitCode: "ẨN SĨ", scholarFull: "Hãy nhìn bố cục trước khi gắn ý nghĩa. Biểu đồ là tổ hợp thông tin có cấu trúc, không thay thế lựa chọn của bạn.", scholarDirect: "Nhận ra cấu trúc; lựa chọn vẫn là của bạn.", hermitFull: "Không cần giải quyết mọi thứ trong một lần ngồi lại. Giữ sợi chỉ hữu ích, đặt phần còn lại xuống và trở lại khi ngày đã đổi khác.", hermitDirect: "Giữ sợi chỉ hữu ích, đặt phần còn lại xuống.", seal: "KHÍ", heroBrand: "Xuannova" },
    footer: { brand: "Xuannova", copyright: "© 2026 Xuannova" },
  },
  th: {
    brandKicker: "Xuannova · การศึกษา",
    stage: { input: "กรอกข้อมูล", generating: "กำลังสร้างกระดาน", chart: "กระดานศึกษา", reading: "คำอธิบาย", backToChart: "กลับสู่กระดาน", edit: "แก้ไขข้อมูล" },
    chart: { openReading: "เปิดคำอธิบายฉบับเต็ม", backToForm: "กลับไปกรอกข้อมูล", demo: "กระดานตัวอย่าง", favourable: "เหมาะ", avoid: "ควรหลีกเลี่ยง", source: "ข้อมูลอ้างอิง", localChart: "กระดาน" },
    account: { access: "การเข้าถึง", community: "ชุมชน", support: "ฝ่ายสนับสนุน" },
    metrics: { paths: "เส้นทางศึกษา", themes: "หัวข้อ", languages: "ภาษา", uploads: "ครั้งที่อัปโหลด" },
    visual: { year: "เสาปี", month: "เสาเดือน", day: "เสาวัน", hour: "เสาเวลา", seasonal: "จังหวะฤดูกาล" },
    home: { sourceLabel: "รากแห่งการศึกษา", ribbon: ["หยินหยาง", "ห้าธาตุ", "ชี่", "จังหวะฤดูกาล", "สิบสองกิ่งดิน", "ภาษาของผัง", "การสังเกตอย่างสงบ"], scholarCode: "นักวิชาการ", hermitCode: "ผู้สันโดษ", scholarFull: "พิจารณาการจัดวางก่อนกำหนดความหมาย กระดานคือข้อมูลที่มีโครงสร้าง ไม่ได้แทนที่การเลือกของคุณ.", scholarDirect: "เห็นโครงสร้าง แล้วเลือกด้วยตนเอง.", hermitFull: "ไม่ต้องแก้ทุกอย่างในครั้งเดียว เก็บเส้นด้ายที่มีประโยชน์ วางส่วนที่เหลือ และกลับมาเมื่อวันเปลี่ยนไป.", hermitDirect: "เก็บสิ่งที่มีประโยชน์และวางส่วนที่เหลือ.", seal: "ชี่", heroBrand: "เสวียนหยวน" },
    footer: { brand: "Xuannova", copyright: "© 2026 Xuannova" },
  },
};

export function uiCopy(locale: Locale): UiCopy {
  const safeLocale = locale in copy ? locale : "en";
  const base = copy[safeLocale];
  const reportLabels: Record<Locale, string> = {
    en: "View reading (first half free)", "zh-Hans": "看解读（前半部分免费）", "zh-Hant": "看解讀（前半部分免費）",
    ja: "解説を見る（前半無料）", ko: "해설 보기(앞부분 무료)", vi: "Xem bài giải (nửa đầu miễn phí)", th: "ดูคำอธิบาย (ครึ่งแรกฟรี)",
  };
  return {
    ...base,
    brandKicker: base.brandKicker.replace(/^[^·・]+([·・])/, "Xuannova$1"),
    chart: { ...base.chart, openReading: reportLabels[safeLocale] },
    home: { ...base.home, heroBrand: "Xuannova" },
    footer: { ...base.footer, brand: "Xuannova", copyright: "© 2026 Xuannova" },
  };
}
