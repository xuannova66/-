// Member-facing server messages in all seven languages. The server answers in English; pages show
// the visitor's language. Unknown messages fall back to a generic "could not complete" line.
import type { Locale } from "./site-content";

type Row = [string, string, string, string, string, string, string];
const L = (row: Row): Record<Locale, string> => ({ en: row[0], "zh-Hans": row[1], "zh-Hant": row[2], ja: row[3], ko: row[4], vi: row[5], th: row[6] });

const messages: Record<string, Record<Locale, string>> = {
  "This transaction hash has already been submitted": L(["This transaction hash has already been submitted. Each transfer can be used once.", "该交易哈希已经提交过，每笔转账只能使用一次。", "該交易哈希已經提交過，每筆轉帳只能使用一次。", "この取引ハッシュは提出済みです。1件の送金は1回だけ使えます。", "이미 제출된 거래 해시입니다. 송금 한 건은 한 번만 사용할 수 있습니다.", "Mã giao dịch này đã được gửi. Mỗi giao dịch chỉ dùng được một lần.", "แฮชธุรกรรมนี้ถูกส่งไปแล้ว การโอนแต่ละครั้งใช้ได้ครั้งเดียว"]),
  "Enter a valid transaction hash": L(["Enter the transaction hash shown in your wallet or block explorer.", "请填写钱包或区块浏览器中显示的交易哈希。", "請填寫錢包或區塊瀏覽器中顯示的交易哈希。", "ウォレットまたはブロックエクスプローラーに表示された取引ハッシュを入力してください。", "지갑이나 블록 탐색기에 표시된 거래 해시를 입력하세요.", "Nhập mã giao dịch hiển thị trong ví hoặc trình khám phá khối.", "กรอกแฮชธุรกรรมที่แสดงในกระเป๋าเงินหรือ block explorer"]),
  "TRC20 transaction hashes are 64 hexadecimal characters without 0x": L(["A TRC20 hash is 64 characters (0–9, a–f) and does not start with 0x. Check the network you paid on.", "TRC20 交易哈希为 64 位字符（0–9、a–f），不以 0x 开头。请确认付款所用网络。", "TRC20 交易哈希為 64 位字元（0–9、a–f），不以 0x 開頭。請確認付款所用網路。", "TRC20 のハッシュは 0x で始まらない 64 文字（0–9、a–f）です。送金したネットワークをご確認ください。", "TRC20 해시는 0x로 시작하지 않는 64자(0–9, a–f)입니다. 결제한 네트워크를 확인하세요.", "Mã TRC20 gồm 64 ký tự (0–9, a–f), không bắt đầu bằng 0x. Hãy kiểm tra mạng bạn đã chuyển.", "แฮช TRC20 มี 64 ตัวอักษร (0–9, a–f) และไม่ขึ้นต้นด้วย 0x โปรดตรวจสอบเครือข่ายที่ใช้โอน"]),
  "BSC transaction hashes start with 0x followed by 64 hexadecimal characters": L(["A BSC hash starts with 0x followed by 64 characters (0–9, a–f). Check the network you paid on.", "BSC 交易哈希以 0x 开头，后接 64 位字符（0–9、a–f）。请确认付款所用网络。", "BSC 交易哈希以 0x 開頭，後接 64 位字元（0–9、a–f）。請確認付款所用網路。", "BSC のハッシュは 0x の後に 64 文字（0–9、a–f）が続きます。送金したネットワークをご確認ください。", "BSC 해시는 0x 뒤에 64자(0–9, a–f)가 붙습니다. 결제한 네트워크를 확인하세요.", "Mã BSC bắt đầu bằng 0x và theo sau là 64 ký tự (0–9, a–f). Hãy kiểm tra mạng bạn đã chuyển.", "แฮช BSC ขึ้นต้นด้วย 0x ตามด้วย 64 ตัวอักษร (0–9, a–f) โปรดตรวจสอบเครือข่ายที่ใช้โอน"]),
  "Choose TRC20 or BSC / BEP20": L(["Choose the network you paid on: TRC20 or BSC / BEP20.", "请选择付款网络：TRC20 或 BSC / BEP20。", "請選擇付款網路：TRC20 或 BSC / BEP20。", "送金ネットワーク（TRC20 または BSC / BEP20）を選んでください。", "결제 네트워크(TRC20 또는 BSC / BEP20)를 선택하세요.", "Chọn mạng đã chuyển: TRC20 hoặc BSC / BEP20.", "เลือกเครือข่ายที่ใช้โอน: TRC20 หรือ BSC / BEP20"]),
  "Choose a valid credit package": L(["This package is not available. Please choose another one.", "该套餐不可用，请选择其他套餐。", "該套餐不可用，請選擇其他套餐。", "このパッケージは利用できません。別のものを選んでください。", "이 패키지는 사용할 수 없습니다. 다른 패키지를 선택하세요.", "Gói này không khả dụng. Vui lòng chọn gói khác.", "แพ็กเกจนี้ใช้ไม่ได้ โปรดเลือกแพ็กเกจอื่น"]),
  "Authentication required": L(["Please sign in first.", "请先登录。", "請先登入。", "先にサインインしてください。", "먼저 로그인하세요.", "Vui lòng đăng nhập trước.", "โปรดเข้าสู่ระบบก่อน"]),
  "Insufficient credits": L(["Your balance is not enough. Buy credits to continue.", "积分余额不足，请先购买积分。", "積分餘額不足，請先購買積分。", "クレジットが足りません。購入してから続けてください。", "크레딧이 부족합니다. 구매 후 계속하세요.", "Số điểm không đủ. Hãy mua thêm để tiếp tục.", "เครดิตไม่พอ โปรดซื้อเครดิตก่อน"]),
  "Your cart is empty": L(["Your cart is empty.", "购物车是空的。", "購物車是空的。", "カートは空です。", "장바구니가 비어 있습니다.", "Giỏ hàng trống.", "ตะกร้าว่างอยู่"]),
  "Not enough stock for a product in your cart": L(["One item in your cart does not have enough stock. Reduce the quantity.", "购物车中有商品库存不足，请减少数量。", "購物車中有商品庫存不足，請減少數量。", "カート内の商品の在庫が足りません。数量を減らしてください。", "장바구니 상품의 재고가 부족합니다. 수량을 줄이세요.", "Một sản phẩm trong giỏ không đủ hàng. Hãy giảm số lượng.", "สินค้าบางรายการในตะกร้ามีไม่พอ โปรดลดจำนวน"]),
  "A product in your cart is no longer available": L(["An item in your cart is no longer for sale. Remove it and try again.", "购物车中有商品已下架，请移除后重试。", "購物車中有商品已下架，請移除後重試。", "カート内の商品が販売終了しました。削除してからお試しください。", "장바구니 상품이 판매 종료되었습니다. 삭제 후 다시 시도하세요.", "Một sản phẩm đã ngừng bán. Hãy xóa khỏi giỏ và thử lại.", "สินค้าบางรายการเลิกขายแล้ว โปรดนำออกแล้วลองใหม่"]),
  "Enter the recipient name, phone, country and address": L(["Enter the recipient's name, phone, country and address.", "请填写收件人姓名、电话、国家和地址。", "請填寫收件人姓名、電話、國家和地址。", "受取人の氏名・電話番号・国・住所を入力してください。", "수령인 이름, 전화번호, 국가, 주소를 입력하세요.", "Nhập tên, số điện thoại, quốc gia và địa chỉ người nhận.", "กรอกชื่อ เบอร์โทร ประเทศ และที่อยู่ผู้รับ"]),
  "Invalid email or password": L(["The email or password is not correct.", "邮箱或密码不正确。", "信箱或密碼不正確。", "メールアドレスまたはパスワードが正しくありません。", "이메일 또는 비밀번호가 올바르지 않습니다.", "Email hoặc mật khẩu không đúng.", "อีเมลหรือรหัสผ่านไม่ถูกต้อง"]),
  "Enter a valid email address": L(["Enter a valid email address.", "请填写有效的邮箱地址。", "請填寫有效的信箱地址。", "有効なメールアドレスを入力してください。", "올바른 이메일 주소를 입력하세요.", "Nhập địa chỉ email hợp lệ.", "กรอกอีเมลที่ถูกต้อง"]),
  "Use a password with 6 to 128 characters": L(["Use a password with 6 to 128 characters.", "密码长度需为 6 至 128 个字符。", "密碼長度需為 6 至 128 個字元。", "パスワードは 6〜128 文字にしてください。", "비밀번호는 6~128자로 입력하세요.", "Mật khẩu cần 6 đến 128 ký tự.", "รหัสผ่านต้องมี 6 ถึง 128 ตัวอักษร"]),
  "This reset link is invalid or has expired": L(["This reset link is invalid or has expired. Request a new one.", "重置链接无效或已过期，请重新申请。", "重設連結無效或已過期，請重新申請。", "このリセットリンクは無効か期限切れです。もう一度申請してください。", "재설정 링크가 유효하지 않거나 만료되었습니다. 다시 요청하세요.", "Liên kết đặt lại không hợp lệ hoặc đã hết hạn. Hãy yêu cầu lại.", "ลิงก์รีเซ็ตใช้ไม่ได้หรือหมดอายุแล้ว โปรดขอใหม่"]),
};
const fallback = L(["We could not complete this request. Please try again.", "暂时无法完成该操作，请稍后重试。", "暫時無法完成該操作，請稍後重試。", "この操作を完了できませんでした。もう一度お試しください。", "요청을 완료하지 못했습니다. 다시 시도하세요.", "Không thể hoàn tất yêu cầu. Vui lòng thử lại.", "ไม่สามารถดำเนินการได้ โปรดลองอีกครั้ง"]);

/** The visitor-language version of a server message; null when the message is not a known one. */
export function localizeServerError(message: string, locale: Locale): string | null {
  return messages[message]?.[locale] ?? null;
}
export function serverErrorText(message: string, locale: Locale): string {
  return localizeServerError(message, locale) ?? fallback[locale];
}
