"use client";
// Small notice for credits added in the background: the daily +5 bonus and the first-purchase bonus.
// Any code that loads /api/member/me passes the reply to announceGrowth(); one <GrowthNotice> shows it.
import { useEffect, useState } from "react";
import type { Locale } from "./site-content";

type Notice = { kind: "daily" | "first"; amount: number };
export function announceGrowth(body: unknown) {
  if (typeof window === "undefined" || !body || typeof body !== "object") return;
  const reply = body as { dailyBonusAdded?: number; firstPurchaseBonus?: number };
  if (reply.firstPurchaseBonus) window.dispatchEvent(new CustomEvent<Notice>("xuannova:growth", { detail: { kind: "first", amount: reply.firstPurchaseBonus } }));
  if (reply.dailyBonusAdded) window.dispatchEvent(new CustomEvent<Notice>("xuannova:growth", { detail: { kind: "daily", amount: reply.dailyBonusAdded } }));
}

const copy: Record<Locale, { daily: string; first: string; close: string }> = {
  en: { daily: "+{n} daily credits added. They add up to 20 — come back tomorrow for more.", first: "Thank you for your first purchase: +{n} bonus credits added.", close: "Close" },
  "zh-Hans": { daily: "今日 +{n} 积分已到账，每日积分最多累积 20，明天再来领取。", first: "感谢首次购买，已额外赠送 {n} 积分。", close: "关闭" },
  "zh-Hant": { daily: "今日 +{n} 積分已入帳，每日積分最多累積 20，明天再來領取。", first: "感謝首次購買，已額外贈送 {n} 積分。", close: "關閉" },
  ja: { daily: "今日の +{n} クレジットを付与しました。最大20まで貯まります。明日もどうぞ。", first: "初回購入ありがとうございます。ボーナス {n} クレジットを追加しました。", close: "閉じる" },
  ko: { daily: "오늘의 +{n} 크레딧이 지급되었습니다. 최대 20까지 적립되니 내일도 받아 가세요.", first: "첫 구매 감사합니다. 보너스 {n} 크레딧을 추가했습니다.", close: "닫기" },
  vi: { daily: "Đã cộng +{n} điểm hôm nay. Tích lũy tối đa 20 — ngày mai nhớ quay lại nhé.", first: "Cảm ơn bạn đã mua lần đầu: đã tặng thêm {n} điểm.", close: "Đóng" },
  th: { daily: "ได้รับ +{n} เครดิตของวันนี้แล้ว สะสมได้สูงสุด 20 พรุ่งนี้มารับอีกนะ", first: "ขอบคุณที่ซื้อครั้งแรก เพิ่มเครดิตโบนัส {n} แล้ว", close: "ปิด" },
};

export function GrowthNotice({ locale }: { locale: Locale }) {
  const [notice, setNotice] = useState<Notice | null>(null);
  useEffect(() => {
    let timer = 0;
    const show = (event: Event) => {
      setNotice((event as CustomEvent<Notice>).detail);
      window.clearTimeout(timer);
      timer = window.setTimeout(() => setNotice(null), 6000);
    };
    window.addEventListener("xuannova:growth", show);
    return () => { window.removeEventListener("xuannova:growth", show); window.clearTimeout(timer); };
  }, []);
  if (!notice) return null;
  return <div className="growth-notice" role="status"><span>{(notice.kind === "first" ? copy[locale].first : copy[locale].daily).replace("{n}", String(notice.amount))}</span><button type="button" onClick={() => setNotice(null)} aria-label={copy[locale].close}>×</button></div>;
}
