"use client";
// On-site reader for the public-domain classics: table of contents, chapter view, previous/next and
// search inside the book. Texts are loaded in parts from /library/<book>/ only when opened.
import { Fragment, useCallback, useEffect, useRef, useState } from "react";
import type { Locale } from "./site-content";
import { fillShelf, loadShelf, onShelf, progressPercent, saveReadingPosition, shelfText, type ShelfItem } from "./library-shelf";

type Manifest = Record<string, { dir: string; start: number; source: string }>;
type BookIndex = { chapters: Array<{ title: string; part: number; chars: number }>; parts: number; start: number; source: string };
type Chapter = { title: string; text: string };
type Copy = { read: string; contents: string; previous: string; next: string; search: string; searching: string; noHits: string; hits: string; source: string; original: string; loading: string; close: string };
const copy: Record<Locale, Copy> = {
  en: { read: "Read the full text", contents: "Contents", previous: "Previous", next: "Next", search: "Search this book", searching: "Searching…", noHits: "No matches in this book.", hits: "matches", source: "Source text: public-domain edition (daizhige digital archive).", original: "Original Chinese text. The guide above summarises it in your language.", loading: "Loading…", close: "Close the reader" },
  "zh-Hans": { read: "在线阅读全文", contents: "目录", previous: "上一章", next: "下一章", search: "在本书中搜索", searching: "正在搜索…", noHits: "本书中没有找到。", hits: "处", source: "底本：公有领域古籍文本（殆知阁数字古籍）。", original: "", loading: "正在载入…", close: "关闭阅读" },
  "zh-Hant": { read: "線上閱讀全文", contents: "目錄", previous: "上一章", next: "下一章", search: "在本書中搜尋", searching: "正在搜尋…", noHits: "本書中沒有找到。", hits: "處", source: "底本：公有領域古籍文本（殆知閣數位古籍），已轉為繁體。", original: "", loading: "正在載入…", close: "關閉閱讀" },
  ja: { read: "全文を読む", contents: "目次", previous: "前の章", next: "次の章", search: "この本の中を検索", searching: "検索中…", noHits: "この本には見つかりませんでした。", hits: "件", source: "底本：パブリックドメインの古籍テキスト（殆知閣デジタル古籍）。", original: "原文（中国語）です。上のガイドが日本語で内容を紹介しています。", loading: "読み込み中…", close: "閉じる" },
  ko: { read: "전문 읽기", contents: "목차", previous: "이전 장", next: "다음 장", search: "이 책에서 검색", searching: "검색 중…", noHits: "이 책에서 찾지 못했습니다.", hits: "건", source: "저본: 퍼블릭 도메인 고적 텍스트(태지각 디지털 고적).", original: "중국어 원문입니다. 위의 안내가 한국어로 내용을 소개합니다.", loading: "불러오는 중…", close: "닫기" },
  vi: { read: "Đọc toàn văn", contents: "Mục lục", previous: "Chương trước", next: "Chương sau", search: "Tìm trong sách này", searching: "Đang tìm…", noHits: "Không tìm thấy trong sách này.", hits: "kết quả", source: "Văn bản gốc: bản cổ tịch thuộc phạm vi công cộng (kho số hóa Đãi Tri Các).", original: "Nguyên văn tiếng Hán. Phần giới thiệu phía trên tóm tắt bằng tiếng Việt.", loading: "Đang tải…", close: "Đóng" },
  th: { read: "อ่านฉบับเต็ม", contents: "สารบัญ", previous: "บทก่อน", next: "บทถัดไป", search: "ค้นหาในเล่มนี้", searching: "กำลังค้นหา…", noHits: "ไม่พบในเล่มนี้", hits: "ตำแหน่ง", source: "ต้นฉบับ: ข้อความตำราโบราณที่เป็นสาธารณสมบัติ (คลังดิจิทัลไต้จือเก๋อ)", original: "ข้อความต้นฉบับภาษาจีน คำแนะนำด้านบนสรุปเป็นภาษาไทย", loading: "กำลังโหลด…", close: "ปิด" },
};

// On-demand translation of the paragraphs on screen (cached on the server, so each passage is translated once).
const translateText: Record<Locale, { on: string; off: string; loading: string; failed: string; retry: string; limitGuest: string; limitMember: string; busy: string; note: string }> = {
  en: { on: "Show English translation", off: "Original only", loading: "Translating…", failed: "Translation unavailable right now.", retry: "Retry", limitGuest: "Today's free translations are used up. Sign in to translate more.", limitMember: "Today's translation limit is reached. Please continue tomorrow.", busy: "Translation is busy today. Please try again later.", note: "Machine translation of the classical text, shown under each paragraph as you read." },
  "zh-Hans": { on: "显示白话译文", off: "只看原文", loading: "正在翻译…", failed: "暂时无法翻译。", retry: "重试", limitGuest: "今天的免费翻译次数已用完，登录后可继续。", limitMember: "今天的翻译次数已用完，明天再继续。", busy: "今天翻译的人太多，请稍后再试。", note: "读到哪段，就在原文下方显示哪段的白话译文。" },
  "zh-Hant": { on: "顯示白話譯文", off: "只看原文", loading: "正在翻譯…", failed: "暫時無法翻譯。", retry: "重試", limitGuest: "今天的免費翻譯次數已用完，登入後可繼續。", limitMember: "今天的翻譯次數已用完，明天再繼續。", busy: "今天翻譯的人太多，請稍後再試。", note: "讀到哪段，就在原文下方顯示哪段的白話譯文。" },
  ja: { on: "日本語訳を表示", off: "原文のみ", loading: "翻訳中…", failed: "現在翻訳できません。", retry: "再試行", limitGuest: "本日の無料翻訳は上限に達しました。ログインすると続けられます。", limitMember: "本日の翻訳上限に達しました。明日また続けてください。", busy: "本日は混み合っています。しばらくしてからお試しください。", note: "読んでいる段落ごとに、原文の下に機械翻訳を表示します。" },
  ko: { on: "한국어 번역 보기", off: "원문만", loading: "번역 중…", failed: "지금은 번역할 수 없습니다.", retry: "다시 시도", limitGuest: "오늘의 무료 번역을 모두 사용했습니다. 로그인하면 계속할 수 있어요.", limitMember: "오늘 번역 한도에 도달했습니다. 내일 이어서 읽어 주세요.", busy: "오늘은 번역 요청이 많습니다. 잠시 후 다시 시도하세요.", note: "읽는 단락마다 원문 아래에 기계 번역을 보여 줍니다." },
  vi: { on: "Hiện bản dịch tiếng Việt", off: "Chỉ nguyên văn", loading: "Đang dịch…", failed: "Hiện chưa dịch được.", retry: "Thử lại", limitGuest: "Đã hết lượt dịch miễn phí hôm nay. Đăng nhập để dịch tiếp.", limitMember: "Đã đạt giới hạn dịch hôm nay. Hẹn bạn ngày mai.", busy: "Hôm nay quá nhiều yêu cầu dịch. Vui lòng thử lại sau.", note: "Đọc đến đoạn nào, bản dịch máy của đoạn đó hiện ngay bên dưới." },
  th: { on: "แสดงคำแปลภาษาไทย", off: "เฉพาะต้นฉบับ", loading: "กำลังแปล…", failed: "ยังแปลไม่ได้ในขณะนี้", retry: "ลองใหม่", limitGuest: "ใช้สิทธิ์แปลฟรีของวันนี้หมดแล้ว เข้าสู่ระบบเพื่อแปลต่อ", limitMember: "ถึงขีดจำกัดการแปลของวันนี้แล้ว พรุ่งนี้อ่านต่อได้", busy: "วันนี้มีผู้ใช้การแปลมาก โปรดลองใหม่ภายหลัง", note: "อ่านถึงย่อหน้าไหน จะแสดงคำแปลด้วยเครื่องของย่อหน้านั้นใต้ต้นฉบับ" },
};
type Chunk = { from: number; to: number };
const progressText: Record<Locale, string> = { en: "This chapter: {done} / {total} passages translated; more as you read on.", "zh-Hans": "本章已译 {done} / {total} 段，往下读会继续翻译。", "zh-Hant": "本章已譯 {done} / {total} 段，往下讀會繼續翻譯。", ja: "この章：{done} / {total} 段落を翻訳済み。読み進めると続きを翻訳します。", ko: "이 장: {done} / {total} 단락 번역됨. 계속 읽으면 이어서 번역합니다.", vi: "Chương này: đã dịch {done} / {total} đoạn; đọc tiếp sẽ dịch tiếp.", th: "บทนี้แปลแล้ว {done} / {total} ย่อหน้า อ่านต่อจะแปลต่อ" };
/** Groups a chapter's paragraphs into requests of up to 1,500 characters and 12 paragraphs. */
export function translationChunks(paragraphs: string[]): Chunk[] {
  const chunks: Chunk[] = [];
  let from = 0, chars = 0;
  paragraphs.forEach((paragraph, index) => {
    if (index > from && (chars + paragraph.length > 1500 || index - from >= 12)) { chunks.push({ from, to: index }); from = index; chars = 0; }
    chars += paragraph.length;
  });
  if (paragraphs.length > from) chunks.push({ from, to: paragraphs.length });
  return chunks;
}
type ChunkState = { status: "loading" | "done" | "error"; paragraphs?: string[]; code?: string };
const translatePreference = "xn.library.translate";

let manifestPromise: Promise<Manifest> | null = null;
export function loadLibraryManifest() {
  manifestPromise ??= fetch("/library/manifest.json").then((response) => (response.ok ? response.json() : {})).catch(() => ({}));
  return manifestPromise;
}

export function LibraryReader({ id, locale }: { id: string; locale: Locale }) {
  const text = copy[locale];
  const script = locale === "zh-Hant" ? "zh-Hant" : "zh-Hans";
  const [entry, setEntry] = useState<Manifest[string] | null | undefined>(undefined);
  const [open, setOpen] = useState(false);
  const [index, setIndex] = useState<BookIndex | null>(null);
  const [parts, setParts] = useState<Record<number, Chapter[]>>({});
  const [current, setCurrent] = useState(0);
  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<Array<{ chapter: number; snippet: string }> | null>(null);
  const [searching, setSearching] = useState(false);
  const [resume, setResume] = useState<ShelfItem | undefined>(undefined);
  const [startFresh, setStartFresh] = useState(false);
  const pendingParagraph = useRef<number | null>(null);
  // Set when the reader moves to another chapter: open it at the top once its text is on screen.
  const openAtTop = useRef(false);
  const articleRef = useRef<HTMLElement>(null);
  const tt = translateText[locale];
  const [translate, setTranslate] = useState(() => {
    try { const saved = typeof window === "undefined" ? null : window.localStorage.getItem(translatePreference); if (saved) return saved === "on"; } catch { /* storage unavailable */ }
    // On by default for every language: Chinese readers get the plain modern rendering (白话) under each passage.
    return true;
  });
  const [chunkState, setChunkState] = useState<Record<string, ChunkState>>({});
  const requested = useRef(new Set<string>());
  const retried = useRef(new Set<string>());
  useEffect(() => { let alive = true; void loadLibraryManifest().then((manifest) => { if (alive) setEntry(manifest[id] ?? null); }); return () => { alive = false; }; }, [id]);
  // Where this reader stopped last time (this browser, or the member's account).
  useEffect(() => {
    let alive = true;
    void loadShelf().then((shelf) => { if (alive) setResume(shelf.items[id]); });
    const stop = onShelf((shelf) => setResume(shelf.items[id]));
    return () => { alive = false; stop(); };
  }, [id]);
  const base = entry ? `/library/${entry.dir}` : "";
  const loadPart = useCallback(async (part: number): Promise<Chapter[]> => {
    if (parts[part]) return parts[part];
    const data = await fetch(`${base}/${script}-${part}.json`).then((response) => response.json()) as Chapter[];
    setParts((existing) => ({ ...existing, [part]: data }));
    return data;
  }, [base, parts, script]);
  useEffect(() => {
    if (!open || !entry || index) return;
    void fetch(`${base}/index-${script}.json`).then((response) => response.json()).then((data: BookIndex) => {
      setIndex(data);
      const saved = !startFresh && resume?.chapter !== null && resume?.chapter !== undefined && resume.chapter < data.chapters.length ? resume : null;
      if (saved) { setCurrent(saved.chapter as number); pendingParagraph.current = saved.paragraph ?? 0; } else setCurrent(entry.start ?? 0);
    });
  }, [open, entry, index, base, script, resume, startFresh]);
  const chapterInfo = index?.chapters[current];
  useEffect(() => { if (chapterInfo) void loadPart(chapterInfo.part); }, [chapterInfo, loadPart]);
  // Chapters are stored in order across parts, so a chapter's position inside its part is its offset from the part's first chapter.
  const chapterText = (() => {
    if (!index || !chapterInfo) return null;
    const first = index.chapters.findIndex((chapter) => chapter.part === chapterInfo.part);
    return parts[chapterInfo.part]?.[current - first] ?? null;
  })();
  const chapterParagraphs = chapterText ? chapterText.text.split("\n") : [];
  const chunks = chapterText ? translationChunks(chapterParagraphs) : [];
  const chunkKey = (chunk: Chunk) => `${id}|${locale}|${current}|${chunk.from}`;
  const requestChunk = useCallback(async (chunk: Chunk, force = false) => {
    if (!index || !chapterInfo) return;
    const key = `${id}|${locale}|${current}|${chunk.from}`;
    if (requested.current.has(key) && !force) return;
    requested.current.add(key);
    setChunkState((existing) => ({ ...existing, [key]: { status: "loading" } }));
    const first = index.chapters.findIndex((chapter) => chapter.part === chapterInfo.part);
    try {
      const response = await fetch("/api/library/translate", { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify({ book: id, script, part: chapterInfo.part, chapter: current - first, from: chunk.from, to: chunk.to, locale }) });
      const data = await response.json().catch(() => ({})) as { paragraphs?: string[]; code?: string };
      if (response.ok && Array.isArray(data.paragraphs)) setChunkState((existing) => ({ ...existing, [key]: { status: "done", paragraphs: data.paragraphs } }));
      else { requested.current.delete(key); setChunkState((existing) => ({ ...existing, [key]: { status: "error", code: data.code } })); }
    } catch { requested.current.delete(key); setChunkState((existing) => ({ ...existing, [key]: { status: "error" } })); }
  }, [index, chapterInfo, id, locale, current, script]);
  // Translate the passages that come into view (plus a little ahead), never the whole book at once.
  useEffect(() => {
    if (!open || !translate || !chapterText || typeof IntersectionObserver === "undefined") return;
    const list = translationChunks(chapterText.text.split("\n"));
    const observer = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        const number = Number((entry.target as HTMLElement).dataset.p);
        const chunk = list.find((item) => number >= item.from && number < item.to);
        if (chunk) void requestChunk(chunk);
      }
    }, { rootMargin: "300px 0px" });
    articleRef.current?.querySelectorAll("[data-p]").forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, [open, translate, chapterText, requestChunk]);
  const toggleTranslate = () => setTranslate((value) => { try { window.localStorage.setItem(translatePreference, value ? "off" : "on"); } catch { /* storage unavailable */ } return !value; });
  // "本章已译 12 / 34 段": how far the translation has reached in this chapter.
  const translationProgress = () => {
    const total = chapterParagraphs.filter((text) => text.trim()).length;
    let done = 0, loading = false;
    for (const chunk of chunks) {
      const state = chunkState[chunkKey(chunk)];
      if (state?.status === "done") done += chapterParagraphs.slice(chunk.from, chunk.to).filter((text) => text.trim()).length;
      if (state?.status === "loading") loading = true;
    }
    return progressText[locale].replace("{done}", String(done)).replace("{total}", String(total)) + (loading ? ` · ${tt.loading}` : "");
  };
  const translationFor = (number: number) => {
    const chunk = chunks.find((item) => number >= item.from && number < item.to);
    if (!chunk) return null;
    const state = chunkState[chunkKey(chunk)];
    if (!state) return null;
    if (state.status === "done") {
      const value = state.paragraphs?.[number - chunk.from];
      if (value) return <p className="library-translation" lang={locale}>{value}</p>;
      // A passage that came back empty (the model skipped it): ask once more for its chunk.
      if (chapterParagraphs[number]?.trim() && !retried.current.has(chunkKey(chunk))) { retried.current.add(chunkKey(chunk)); window.setTimeout(() => void requestChunk(chunk, true), 0); }
      return null;
    }
    if (number !== chunk.from) return null;
    if (state.status === "loading") return <p className="library-translation is-loading">{tt.loading}</p>;
    const message = state.code === "GUEST_LIMIT" ? tt.limitGuest : state.code === "MEMBER_LIMIT" ? tt.limitMember : state.code === "SITE_LIMIT" ? tt.busy : tt.failed;
    return <p className="library-translation is-error">{message} {state.code !== "GUEST_LIMIT" && state.code !== "MEMBER_LIMIT" && <button type="button" className="text-action" onClick={() => void requestChunk(chunk, true)}>{tt.retry}</button>}</p>;
  };
  // Next / previous chapter: start at the top of the new chapter once it has rendered (not where the old one ended).
  useEffect(() => {
    if (!chapterText || !openAtTop.current) return;
    openAtTop.current = false;
    window.requestAnimationFrame(() => articleRef.current?.scrollIntoView({ block: "start", behavior: "instant" as ScrollBehavior }));
  }, [chapterText]);
  // Reopen at the saved paragraph once its chapter is on screen.
  useEffect(() => {
    if (!chapterText || pendingParagraph.current === null) return;
    const target = articleRef.current?.querySelector<HTMLElement>(`[data-p="${pendingParagraph.current}"]`);
    pendingParagraph.current = null;
    if (target) window.requestAnimationFrame(() => target.scrollIntoView({ block: "start" }));
  }, [chapterText]);
  const remember = useCallback((chapter: number, paragraph: number) => {
    if (!index) return;
    saveReadingPosition(id, { chapter, chapterCount: index.chapters.length, paragraph, chapterTitle: index.chapters[chapter]?.title || String(chapter + 1) });
  }, [id, index]);
  // Remember the first paragraph still visible as the reader scrolls, and translate what is on or near the screen.
  // Runs when scrolling stops (and at least once a second during a long scroll), so the final position is never missed.
  useEffect(() => {
    if (!open || !chapterText) return;
    let idle: ReturnType<typeof setTimeout> | null = null;
    let lastRun = 0;
    const check = () => {
      lastRun = Date.now();
      const paragraphs = articleRef.current?.querySelectorAll<HTMLElement>("[data-p]");
      if (!paragraphs?.length) return;
      const first = [...paragraphs].find((element) => element.getBoundingClientRect().bottom > 90);
      if (first && articleRef.current && articleRef.current.getBoundingClientRect().top < window.innerHeight) remember(current, Number(first.dataset.p));
      // A fast scroll can carry passages past the screen between checks: translate everything near the screen now.
      if (translate) {
        const list = translationChunks(chapterText.text.split("\n"));
        for (const element of paragraphs) {
          const box = element.getBoundingClientRect();
          if (box.bottom < -400 || box.top > window.innerHeight + 400) continue;
          const number = Number(element.dataset.p);
          const chunk = list.find((item) => number >= item.from && number < item.to);
          if (chunk) void requestChunk(chunk);
        }
      }
    };
    const onScroll = () => {
      if (idle) clearTimeout(idle);
      idle = setTimeout(check, 350);
      if (Date.now() - lastRun > 1000) check();
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    check();
    return () => { window.removeEventListener("scroll", onScroll); if (idle) clearTimeout(idle); };
  }, [open, chapterText, current, remember, translate, requestChunk]);
  if (!entry) return null;
  const goTo = (chapter: number) => { openAtTop.current = true; setCurrent(chapter); setHits(null); remember(chapter, 0); };
  const runSearch = async () => {
    if (!index || !query.trim()) return;
    setSearching(true);
    const found: Array<{ chapter: number; snippet: string }> = [];
    let chapterNumber = 0;
    for (let part = 0; part < index.parts && found.length < 60; part += 1) {
      const chapters = await loadPart(part);
      for (const chapter of chapters) {
        const at = chapter.text.indexOf(query.trim());
        if (at >= 0 || chapter.title.includes(query.trim())) found.push({ chapter: chapterNumber, snippet: at >= 0 ? chapter.text.slice(Math.max(0, at - 24), at + 48).replace(/\n/g, " ") : chapter.title });
        chapterNumber += 1;
      }
    }
    setHits(found); setSearching(false);
  };
  const percent = progressPercent(resume);
  if (!open) return resume?.chapter !== null && resume?.chapter !== undefined
    ? <div className="library-resume">
        <button type="button" className="primary-action library-read" onClick={() => { setStartFresh(false); setOpen(true); }}>{fillShelf(shelfText.continueAt[locale], { title: resume.chapterTitle ?? String(resume.chapter + 1) })}<b>↗</b></button>
        <button type="button" className="text-action" onClick={() => { setStartFresh(true); setOpen(true); }}>{shelfText.fromStart[locale]}</button>
        {percent > 0 && <span className="library-progress" aria-label={fillShelf(shelfText.progress[locale], { p: percent })}><i style={{ width: `${percent}%` }} /><small>{fillShelf(shelfText.progress[locale], { p: percent })}</small></span>}
      </div>
    : <button type="button" className="primary-action library-read" onClick={() => setOpen(true)}>{text.read}<b>↗</b></button>;
  const readingPercent = index ? Math.max(1, Math.round(((current + 1) / index.chapters.length) * 100)) : 0;
  return <section className="library-reader" aria-label={text.read}>
    {text.original && !translate && <p className="library-reader-note">{text.original}</p>}
    {!index ? <p>{text.loading}</p> : <>
      <div className="library-reader-bar">
        <label><span>{text.contents}</span><select value={current} onChange={(event) => goTo(Number(event.target.value))}>{index.chapters.map((chapter, number) => <option key={number} value={number}>{chapter.title || number + 1}</option>)}</select></label>
        <button type="button" className={`library-translate-toggle${translate ? " is-on" : ""}`} aria-pressed={translate} onClick={toggleTranslate}>{translate ? tt.off : tt.on}</button>
        <form onSubmit={(event) => { event.preventDefault(); void runSearch(); }}><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={text.search} aria-label={text.search} /><button type="submit" className="text-action">{searching ? text.searching : "⌕"}</button></form>
      </div>
      {hits && <div className="library-hits">{hits.length ? <><small>{hits.length} {text.hits}</small>{hits.map((hit, number) => <button type="button" key={number} onClick={() => goTo(hit.chapter)}><b>{index.chapters[hit.chapter]?.title}</b><span>{hit.snippet}</span></button>)}</> : <p>{text.noHits}</p>}</div>}
      <span className="library-progress is-reading" aria-label={fillShelf(shelfText.progress[locale], { p: readingPercent })}><i style={{ width: `${readingPercent}%` }} /><small>{current + 1} / {index.chapters.length} · {fillShelf(shelfText.progress[locale], { p: readingPercent })}</small></span>
      {translate && <p className="library-translate-note">{tt.note} <b className="library-translate-progress">{translationProgress()}</b></p>}
      <article className="library-chapter" lang={script} ref={articleRef}>
        <h3>{chapterInfo?.title}</h3>
        {chapterText ? chapterParagraphs.map((paragraph, number) => <Fragment key={number}><p data-p={number}>{paragraph}</p>{translate && translationFor(number)}</Fragment>) : <p>{text.loading}</p>}
      </article>
      <nav className="library-reader-nav">
        <button type="button" className="text-action" disabled={current === 0} onClick={() => goTo(current - 1)}>← {text.previous}</button>
        <button type="button" className="text-action" disabled={current >= index.chapters.length - 1} onClick={() => goTo(current + 1)}>{text.next} →</button>
      </nav>
      <small className="library-source">{text.source}</small>
    </>}
    <button type="button" className="text-action" onClick={() => setOpen(false)}>{text.close}</button>
  </section>;
}
