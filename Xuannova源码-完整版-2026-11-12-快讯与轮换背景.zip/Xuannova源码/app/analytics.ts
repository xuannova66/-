"use client";
// Consent-gated analytics. Nothing loads until the visitor chooses "Accept all" and an ID is set in
// contact-config.ts. The loaders below are the vendors' standard snippets, injected only after consent.
// Funnel events: chart_created, reading_preview, reading_unlock, purchase_submitted, shop_order.
import { analyticsConfig } from "./contact-config";

type Win = Window & { gtag?: (...args: unknown[]) => void; fbq?: (...args: unknown[]) => void; ttq?: { track: (event: string, params?: object) => void } };
let loaded = false;
const safeId = (value: string) => value.replace(/[^A-Za-z0-9_-]/g, "");

function hasFullConsent() {
  try { return window.localStorage.getItem("xuannova-consent") === "all"; } catch { return false; }
}
function inline(code: string) { const script = document.createElement("script"); script.text = code; document.head.appendChild(script); }

export function initAnalytics() {
  if (loaded || typeof window === "undefined" || !hasFullConsent()) return;
  const ga4 = safeId(analyticsConfig.ga4); const pixel = safeId(analyticsConfig.metaPixel); const tiktok = safeId(analyticsConfig.tiktok);
  if (!ga4 && !pixel && !tiktok) return;
  loaded = true;
  if (ga4) {
    const tag = document.createElement("script"); tag.async = true; tag.src = `https://www.googletagmanager.com/gtag/js?id=${ga4}`; document.head.appendChild(tag);
    inline(`window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}window.gtag=gtag;gtag('js',new Date());gtag('config','${ga4}',{anonymize_ip:true});`);
  }
  if (pixel) {
    inline(`!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','${pixel}');fbq('track','PageView');`);
  }
  if (tiktok) {
    inline(`!function(w,d,t){w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie"];ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e};ttq.load=function(e,n){var i="https://analytics.tiktok.com/i18n/pixel/events.js";ttq._i=ttq._i||{};ttq._i[e]=[];ttq._i[e]._u=i;ttq._t=ttq._t||{};ttq._t[e]=+new Date;ttq._o=ttq._o||{};ttq._o[e]=n||{};var o=d.createElement("script");o.type="text/javascript";o.async=!0;o.src=i+"?sdkid="+e+"&lib="+t;var a=d.getElementsByTagName("script")[0];a.parentNode.insertBefore(o,a)};ttq.load('${tiktok}');ttq.page();}(window,document,'ttq');`);
  }
}

/** Record a funnel event. Does nothing without consent or configured IDs. Never pass personal data. */
export function track(event: string, params: Record<string, string | number> = {}) {
  if (typeof window === "undefined" || !hasFullConsent()) return;
  initAnalytics();
  const w = window as Win;
  w.gtag?.("event", event, params);
  w.fbq?.("trackCustom", event, params);
  w.ttq?.track(event, params);
}
