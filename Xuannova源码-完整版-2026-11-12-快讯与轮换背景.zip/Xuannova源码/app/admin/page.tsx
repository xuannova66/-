"use client";

/**
 * Stand-alone operations console at /admin.
 * Not linked from the public site; share the URL only with administrators.
 */
import { useEffect, useState } from "react";
import { AdminConsole } from "../admin-console";
import { languageOptions, type Locale } from "../site-content";

export default function AdminPage() {
  const [locale, setLocale] = useState<Locale>("zh-Hans");

  useEffect(() => {
    const timer = window.setTimeout(() => {
      const stored = window.localStorage.getItem("xuanyuan-locale") as Locale | null;
      if (stored && languageOptions.some((option) => option.value === stored)) setLocale(stored);
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    window.localStorage.setItem("xuanyuan-locale", locale);
    document.documentElement.lang = locale;
    document.title = "Xuannova · Operations";
  }, [locale]);

  return (
    <main className="suite-shell admin-shell" data-theme="aureate" data-locale={locale} data-route="admin">
      <header className="admin-shell-bar">
        <b>Xuannova · Operations</b>
        <label>
          <select value={locale} onChange={(event) => setLocale(event.target.value as Locale)} aria-label="Language">
            {languageOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
          </select>
        </label>
      </header>
      <section className="route-screen admin-screen" data-route="admin">
        <AdminConsole locale={locale} />
      </section>
    </main>
  );
}
