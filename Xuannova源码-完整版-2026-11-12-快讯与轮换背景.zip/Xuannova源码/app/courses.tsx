"use client";
// Video courses: lessons published in the admin console. Registered members watch every lesson free;
// a lesson marked "open to all" plays for visitors too. Video addresses of members-only lessons are
// only sent by the server to signed-in members, and uploaded files are streamed only to them.
import { useEffect, useState } from "react";
import type { Locale } from "./site-content";
import { BenefitsTable } from "./benefits";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

export const coursesLabel = L("Video courses", "视频课程", "影片課程", "動画講座", "영상 강좌", "Khóa học video", "คอร์สวิดีโอ");
const text = {
  eyebrow: L("Video courses · watch free after registering", "视频课程 · 免费注册后观看", "影片課程 · 免費註冊後觀看", "動画講座 · 無料登録で視聴", "영상 강좌 · 무료 가입 후 시청", "Khóa học video · đăng ký miễn phí để xem", "คอร์สวิดีโอ · สมัครฟรีแล้วดูได้"),
  title: L("Video lessons on the classics", "典籍视频课", "典籍影片課", "古典の動画講義", "고전 영상 강의", "Bài giảng video về kinh điển", "บทเรียนวิดีโอจากตำราดั้งเดิม"),
  lead: L("Registered members watch every lesson free. Registering is free and takes a minute.", "注册即成为会员，全部课程免费观看。注册不收费，一分钟完成。", "註冊即成為會員，全部課程免費觀看。註冊不收費，一分鐘完成。", "登録すると会員になり、すべての講座を無料で視聴できます。登録は無料で1分ほどです。", "가입하면 회원이 되어 모든 강좌를 무료로 볼 수 있습니다. 가입은 무료이며 1분이면 됩니다.", "Đăng ký là thành viên và xem miễn phí mọi bài học. Đăng ký miễn phí, chỉ mất một phút.", "สมัครแล้วเป็นสมาชิก ดูทุกบทเรียนได้ฟรี การสมัครไม่มีค่าใช้จ่ายและใช้เวลาเพียงหนึ่งนาที"),
  soon: L("New lessons are being prepared and will appear here.", "课程正在录制，上线后会显示在这里。", "課程正在錄製，上線後會顯示在這裡。", "講義を準備中です。公開後ここに表示されます。", "강의를 준비 중이며 공개되면 여기에 표시됩니다.", "Bài giảng đang được chuẩn bị và sẽ hiển thị tại đây.", "กำลังเตรียมบทเรียน และจะแสดงที่นี่เมื่อเผยแพร่"),
  members: L("Watch free after registering", "免费注册后观看", "免費註冊後觀看", "無料登録で視聴", "무료 가입 후 시청", "Đăng ký miễn phí để xem", "สมัครฟรีแล้วดูได้"),
  open: L("Open to all", "公开课", "公開課", "どなたでも", "누구나 시청", "Mở cho mọi người", "เปิดให้ทุกคน"),
  minutes: L("min", "分钟", "分鐘", "分", "분", "phút", "นาที"),
  more: L("Show {n} more ↓", "展开其余 {n} 个视频 ↓", "展開其餘 {n} 個影片 ↓", "残り {n} 本を表示 ↓", "나머지 {n}개 보기 ↓", "Xem thêm {n} video ↓", "ดูอีก {n} วิดีโอ ↓"),
  fewer: L("Show fewer ↑", "收起 ↑", "收起 ↑", "閉じる ↑", "접기 ↑", "Thu gọn ↑", "ย่อ ↑"),
  all: L("All courses", "全部课程", "全部課程", "すべての講座", "전체 강좌", "Tất cả khóa học", "คอร์สทั้งหมด"),
  close: L("Close", "关闭", "關閉", "閉じる", "닫기", "Đóng", "ปิด"),
  signInTitle: L("Sign in to watch", "登录后观看", "登入後觀看", "ログインして視聴", "로그인 후 시청", "Đăng nhập để xem", "เข้าสู่ระบบเพื่อดู"),
  signInLead: L("Register free to watch this lesson. Sign in, or register free with your email.", "本课免费注册后即可观看。请登录，或用邮箱免费注册。", "本課免費註冊後即可觀看。請登入，或用信箱免費註冊。", "この講座は会員なら無料です。ログインするか、メールで無料登録してください。", "이 강좌는 회원 무료입니다. 로그인하거나 이메일로 무료 가입하세요.", "Bài học này miễn phí cho thành viên. Hãy đăng nhập hoặc đăng ký miễn phí bằng email.", "บทเรียนนี้สมาชิกดูฟรี เข้าสู่ระบบ หรือสมัครฟรีด้วยอีเมล"),
  signIn: L("Sign in or register", "登录 / 注册", "登入 / 註冊", "ログイン / 登録", "로그인 / 가입", "Đăng nhập / Đăng ký", "เข้าสู่ระบบ / สมัคร"),
  error: L("This video could not be played. Please refresh and try again.", "视频暂时无法播放，请刷新后重试。", "影片暫時無法播放，請重新整理後再試。", "動画を再生できませんでした。再読み込みしてもう一度お試しください。", "영상을 재생할 수 없습니다. 새로고침 후 다시 시도하세요.", "Không phát được video. Vui lòng tải lại trang và thử lại.", "ไม่สามารถเล่นวิดีโอได้ โปรดรีเฟรชแล้วลองอีกครั้ง"),
};

export type Lecture = { id: string; title: Partial<L7>; summary: Partial<L7>; videoUrl: string | null; mediaUrl: string | null; membersOnly: boolean; locked: boolean; durationMinutes: number | null };
const pick = (map: Partial<L7>, locale: Locale) => map[locale] ?? map.en ?? map["zh-Hans"] ?? Object.values(map)[0] ?? "";

/** YouTube / Vimeo links become embeds; uploaded files and other links play in a native video element. */
export function embedFor(url: string) {
  const youtube = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([\w-]{6,})/);
  if (youtube) return { kind: "iframe" as const, src: `https://www.youtube-nocookie.com/embed/${youtube[1]}?autoplay=1` };
  const vimeo = url.match(/vimeo\.com\/(\d+)/);
  if (vimeo) return { kind: "iframe" as const, src: `https://player.vimeo.com/video/${vimeo[1]}?autoplay=1` };
  return { kind: "video" as const, src: url };
}

/** A cover for the card: the YouTube thumbnail, or a frame from an uploaded video the viewer can watch. */
function LectureThumb({ lecture }: { lecture: Lecture }) {
  const youtube = lecture.videoUrl?.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([\w-]{6,})/)?.[1];
  const [failed, setFailed] = useState(false);
  return <span className={`lecture-thumb${lecture.locked ? " is-locked" : ""}`} aria-hidden="true">
    {!failed && youtube && <img src={`https://i.ytimg.com/vi/${youtube}/hqdefault.jpg`} alt="" loading="lazy" onError={() => setFailed(true)} />}
    {!failed && !youtube && lecture.mediaUrl && <video src={`${lecture.mediaUrl}#t=2`} preload="metadata" muted playsInline onError={() => setFailed(true)} />}
    <i>{lecture.locked ? "🔒" : "▶"}</i>
  </span>;
}

function useLectures() {
  const [lectures, setLectures] = useState<Lecture[] | null>(null);
  useEffect(() => {
    let cancelled = false;
    const load = () => fetch("/api/lectures", { credentials: "same-origin", cache: "no-store" })
      .then((response) => (response.ok ? response.json() : { lectures: [] }))
      .then((payload: { lectures?: Lecture[] }) => { if (!cancelled) setLectures(payload.lectures ?? []); })
      .catch(() => { if (!cancelled) setLectures([]); });
    void load();
    // Signing in or out elsewhere on the page changes which lessons unlock.
    window.addEventListener("xuannova:member", load);
    return () => { cancelled = true; window.removeEventListener("xuannova:member", load); };
  }, []);
  return lectures;
}

function LectureGrid({ locale, lectures, onSignIn }: { locale: Locale; lectures: Lecture[]; onSignIn: () => void }) {
  const [playing, setPlaying] = useState<Lecture | null>(null);
  const [asking, setAsking] = useState<Lecture | null>(null);
  const [failed, setFailed] = useState(false);
  const source = playing ? playing.mediaUrl ?? playing.videoUrl : null;
  const embed = source ? embedFor(source) : null;
  useEffect(() => {
    if (!playing && !asking) return;
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") { setPlaying(null); setAsking(null); } };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [playing, asking]);
  return <>
    <div className="lecture-grid">{lectures.map((lecture) => <button type="button" key={lecture.id} className={lecture.locked ? "is-locked" : undefined} onClick={() => { setFailed(false); if (lecture.locked) setAsking(lecture); else setPlaying(lecture); }}>
      <LectureThumb lecture={lecture} />
      <strong>{pick(lecture.title, locale)}</strong>
      <small>{lecture.membersOnly ? text.members[locale] : text.open[locale]}{lecture.durationMinutes ? ` · ${lecture.durationMinutes} ${text.minutes[locale]}` : ""}</small>
      {pick(lecture.summary, locale) && <span>{pick(lecture.summary, locale)}</span>}
    </button>)}</div>
    {playing && embed && <div className="legal-backdrop" role="presentation" onClick={() => setPlaying(null)}>
      <section className="lecture-player" role="dialog" aria-modal="true" aria-label={pick(playing.title, locale)} onClick={(event) => event.stopPropagation()}>
        <header><h3>{pick(playing.title, locale)}</h3><button type="button" onClick={() => setPlaying(null)} aria-label={text.close[locale]}>×</button></header>
        {embed.kind === "iframe"
          ? <iframe src={embed.src} title={pick(playing.title, locale)} allow="autoplay; encrypted-media; picture-in-picture" allowFullScreen />
          : <video src={embed.src} controls autoPlay playsInline controlsList="nodownload" onContextMenu={(event) => event.preventDefault()} onError={() => setFailed(true)} />}
        {failed && <p className="lecture-error" role="alert">{text.error[locale]}</p>}
      </section>
    </div>}
    {asking && <div className="legal-backdrop" role="presentation" onClick={() => setAsking(null)}>
      <section className="lecture-signin" role="dialog" aria-modal="true" aria-labelledby="lecture-signin-title" onClick={(event) => event.stopPropagation()}>
        <header><h3 id="lecture-signin-title">{text.signInTitle[locale]}</h3><button type="button" onClick={() => setAsking(null)} aria-label={text.close[locale]}>×</button></header>
        <p><b>{pick(asking.title, locale)}</b></p>
        <p>{text.signInLead[locale]}</p>
        <button type="button" className="primary-action" onClick={() => { setAsking(null); onSignIn(); }}>{text.signIn[locale]}<b>↗</b></button>
      </section>
    </div>}
  </>;
}

/** Home page: the first three lessons (the rest fold out) and a link to the full course page. */
export function HomeLectureHall({ locale, onAll, onSignIn }: { locale: Locale; onAll: () => void; onSignIn: () => void }) {
  const lectures = useLectures();
  const [more, setMore] = useState(false);
  return <section className="home-lectures" id="lectures" aria-labelledby="home-lectures-title">
    <header><p>{text.eyebrow[locale]}</p><h2 id="home-lectures-title">{text.title[locale]}</h2><span>{text.lead[locale]}</span></header>
    {lectures && lectures.length > 0
      ? <><LectureGrid locale={locale} lectures={more ? lectures : lectures.slice(0, 3)} onSignIn={onSignIn} />
        <div className="lecture-more-row">{lectures.length > 3 && <button type="button" className="text-action lecture-all" onClick={() => setMore(!more)} aria-expanded={more}>{more ? text.fewer[locale] : text.more[locale].replace("{n}", String(lectures.length - 3))}</button>}<button type="button" className="text-action lecture-all" onClick={onAll}>{text.all[locale]} →</button></div></>
      : <p className="lecture-soon">{text.soon[locale]}</p>}
  </section>;
}

/** The video course page (/courses). */
export function CoursesScreen({ locale, onSignIn }: { locale: Locale; onSignIn: () => void }) {
  const lectures = useLectures();
  return <section className="route-screen courses-screen" data-route="courses" aria-labelledby="courses-title">
    <header className="courses-head"><p>{text.eyebrow[locale]}</p><h1 id="courses-title">{coursesLabel[locale]}</h1><span>{text.lead[locale]}</span></header>
    {lectures === null ? null : lectures.length ? <LectureGrid locale={locale} lectures={lectures} onSignIn={onSignIn} /> : <p className="lecture-soon">{text.soon[locale]}</p>}
    <BenefitsTable locale={locale} />
  </section>;
}
