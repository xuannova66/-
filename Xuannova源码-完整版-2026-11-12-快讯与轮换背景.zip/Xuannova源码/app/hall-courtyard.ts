// 研习殿 · the temple grounds around the hall: an open-fronted main hall (roof, beams, columns, plaque), a courtyard
// with a stone path, an incense burner with rising smoke, stone lanterns, red maples and pines, a lotus pond with
// benches, a mountain gate (山门) at the far end, layered hills and a dusk sky. Everything is drawn from simple shapes
// and canvas textures (no model or image files) and kept low-poly so phones stay smooth.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Three = any;

function canvas(width: number, height: number, draw: (ctx: CanvasRenderingContext2D) => void) {
  const element = document.createElement("canvas");
  element.width = width; element.height = height;
  const ctx = element.getContext("2d");
  if (ctx) draw(ctx);
  return element;
}
function rng(seed: number) { let s = seed >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }

const grassCanvas = () => canvas(256, 256, (ctx) => {
  const rand = rng(7);
  ctx.fillStyle = "#5d5a3a"; ctx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 2600; i += 1) {
    const g = 70 + rand() * 50;
    ctx.fillStyle = `rgba(${Math.round(g * 1.05)},${Math.round(g * 1.02)},${Math.round(g * 0.55)},${(0.25 + rand() * 0.4).toFixed(2)})`;
    ctx.fillRect(rand() * 256, rand() * 256, 1.5, 3 + rand() * 4);
  }
  for (let i = 0; i < 90; i += 1) { ctx.fillStyle = `rgba(${170 + rand() * 60},${70 + rand() * 50},40,.55)`; ctx.beginPath(); ctx.arc(rand() * 256, rand() * 256, 1.5 + rand() * 2, 0, Math.PI * 2); ctx.fill(); } // fallen leaves
});
const pavingCanvas = () => canvas(256, 256, (ctx) => {
  const rand = rng(11);
  ctx.fillStyle = "#4c4842"; ctx.fillRect(0, 0, 256, 256);
  for (let row = 0; row < 4; row += 1) for (let col = 0; col < 3; col += 1) {
    const x = col * 86 + (row % 2 ? 43 : 0) - 43, y = row * 64;
    const shade = 92 + rand() * 30;
    ctx.fillStyle = `rgb(${shade},${shade - 4},${shade - 10})`; ctx.fillRect(x + 2, y + 2, 82, 60);
    for (let k = 0; k < 40; k += 1) { ctx.fillStyle = `rgba(30,28,24,${(rand() * 0.15).toFixed(2)})`; ctx.fillRect(x + 2 + rand() * 80, y + 2 + rand() * 58, 2 + rand() * 4, 1 + rand() * 3); }
  }
});
const waterCanvas = () => canvas(256, 256, (ctx) => {
  const g = ctx.createLinearGradient(0, 0, 0, 256); g.addColorStop(0, "#2f5560"); g.addColorStop(1, "#1d3a44");
  ctx.fillStyle = g; ctx.fillRect(0, 0, 256, 256);
  const rand = rng(5);
  for (let i = 0; i < 70; i += 1) { ctx.strokeStyle = `rgba(200,230,235,${(0.05 + rand() * 0.12).toFixed(2)})`; ctx.beginPath(); const x = rand() * 256, y = rand() * 256; ctx.moveTo(x, y); ctx.quadraticCurveTo(x + 10, y - 3, x + 22, y); ctx.stroke(); }
});
const skyCanvas = () => canvas(16, 512, (ctx) => {
  const g = ctx.createLinearGradient(0, 0, 0, 512);
  g.addColorStop(0, "#2a3557"); g.addColorStop(0.42, "#6d5d7a"); g.addColorStop(0.62, "#d99a6c"); g.addColorStop(0.72, "#f2c58a"); g.addColorStop(1, "#f6d9a6");
  ctx.fillStyle = g; ctx.fillRect(0, 0, 16, 512);
});
const hillsCanvas = (color: string, seed: number, peaks: number) => canvas(1024, 256, (ctx) => {
  const rand = rng(seed);
  ctx.fillStyle = color; ctx.beginPath(); ctx.moveTo(0, 256);
  let y = 150;
  for (let x = 0; x <= 1024; x += 16) { y = Math.max(40, Math.min(210, y + (rand() - 0.5) * 34 + Math.sin(x / 1024 * Math.PI * peaks) * 6)); ctx.lineTo(x, y); }
  ctx.lineTo(1024, 256); ctx.closePath(); ctx.fill();
});
const roofCanvas = () => canvas(128, 128, (ctx) => {
  ctx.fillStyle = "#2c2f33"; ctx.fillRect(0, 0, 128, 128);
  for (let x = 0; x < 128; x += 16) { const g = ctx.createLinearGradient(x, 0, x + 16, 0); g.addColorStop(0, "#1e2124"); g.addColorStop(0.5, "#454a50"); g.addColorStop(1, "#1e2124"); ctx.fillStyle = g; ctx.fillRect(x, 0, 16, 128); }
  for (let y = 0; y < 128; y += 22) { ctx.fillStyle = "rgba(0,0,0,.35)"; ctx.fillRect(0, y, 128, 3); }
});
export const plaqueCanvas = (text: string, small: string) => canvas(768, 256, (ctx) => {
  ctx.fillStyle = "#1d3b33"; ctx.fillRect(0, 0, 768, 256);
  ctx.strokeStyle = "#d9b25c"; ctx.lineWidth = 14; ctx.strokeRect(10, 10, 748, 236);
  ctx.lineWidth = 3; ctx.strokeRect(30, 30, 708, 196);
  ctx.fillStyle = "#f0d48a"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
  ctx.font = '700 104px "Noto Serif SC", "Songti SC", serif'; ctx.fillText(text, 384, small ? 112 : 128);
  if (small) { ctx.font = '500 34px Georgia, serif'; ctx.fillStyle = "#d9c08a"; ctx.fillText(small, 384, 196); }
});
const glowCanvas = (color: string) => canvas(64, 64, (ctx) => { const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 32); g.addColorStop(0, color); g.addColorStop(1, "rgba(0,0,0,0)"); ctx.fillStyle = g; ctx.fillRect(0, 0, 64, 64); });

export type Courtyard = {
  /** Hall roof and ceiling: hidden when the camera looks down into the hall from above. */
  roof: Three[]; roofY: number;
  /** Front columns, beam, plaque and eave lanterns: hidden when the camera stands just behind them inside the hall. */
  facade: Three[];
  /** Where people may walk (the pond is kept clear). */
  clamp: (x: number, z: number) => { x: number; z: number };
  /** Paths for strolling members: a loop around the courtyard and spots to stop at. */
  loop: Array<[number, number]>; spots: Array<{ x: number; z: number; face: number; sit?: boolean }>;
  gateZ: number; frontZ: number;
  /** Places in the shade of the courtyard trees (for members sitting or standing under them). */
  treeSpots: Array<{ x: number; z: number; face: number }>;
  update: (time: number, camera?: { x: number; y: number; z: number }) => void;
};

export function buildCourtyard(THREE: Three, scene: Three, opts: { frontZ: number; hallHalf: number; narrow: boolean; plaque: string; plaqueSmall: string; gate: string }): Courtyard {
  const { frontZ, hallHalf, narrow } = opts;
  const texture = (source: HTMLCanvasElement, repeatX = 1, repeatY = repeatX) => { const t = new THREE.CanvasTexture(source); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; if (repeatX !== 1 || repeatY !== 1) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(repeatX, repeatY); } return t; };
  const std = (params: Record<string, unknown>) => new THREE.MeshStandardMaterial({ roughness: 0.85, ...params });
  const add = (mesh: Three, x: number, y: number, z: number) => { mesh.position.set(x, y, z); scene.add(mesh); return mesh; };
  const gateZ = frontZ + (narrow ? 30 : 34);
  const yardHalf = hallHalf + 12;

  // sky dome and far hills
  const sky = new THREE.Mesh(new THREE.SphereGeometry(160, 24, 16), new THREE.MeshBasicMaterial({ map: texture(skyCanvas()), side: THREE.BackSide, fog: false, depthWrite: false }));
  sky.position.set(0, -20, frontZ); scene.add(sky);
  const hillLayers: Array<[string, number, number, number]> = [["#4a4560", 120, 34, 3], ["#3b3a4c", 95, 26, 5], ["#2e3038", 75, 18, 7]];
  hillLayers.forEach(([color, radius, height, peaks], index) => {
    const ring = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, height, 48, 1, true), new THREE.MeshBasicMaterial({ map: texture(hillsCanvas(color, 3 + index * 7, peaks), 3, 1), transparent: true, side: THREE.BackSide, fog: false, depthWrite: false }));
    ring.position.set(0, height / 2 - 2, frontZ); scene.add(ring);
  });
  // a low sun glow above the hills behind the gate
  const sun = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture(glowCanvas("rgba(255,214,150,.9)")), depthWrite: false, transparent: true, fog: false }));
  sun.scale.set(60, 60, 1); sun.position.set(-30, 18, frontZ + 110); scene.add(sun);

  // ground: grass everywhere, stone paving in the courtyard
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(240, 240), std({ map: texture(grassCanvas(), 60), roughness: 1 }));
  ground.rotation.x = -Math.PI / 2; ground.position.set(0, -0.01, frontZ); scene.add(ground);
  const pathWidth = narrow ? 5 : 6;
  const paving = new THREE.Mesh(new THREE.PlaneGeometry(pathWidth, gateZ - frontZ + 2), std({ map: texture(pavingCanvas(), 2, (gateZ - frontZ) / 3), roughness: 0.95 }));
  paving.rotation.x = -Math.PI / 2; add(paving, 0, 0.005, (frontZ + gateZ) / 2);
  const plaza = new THREE.Mesh(new THREE.CircleGeometry(7.5, 40), std({ map: texture(pavingCanvas(), 4), roughness: 0.95 }));
  plaza.rotation.x = -Math.PI / 2; const plazaZ = frontZ + (gateZ - frontZ) * 0.42; add(plaza, 0, 0.006, plazaZ);
  // the hall platform edge and front steps
  const stoneMat = std({ color: "#6f6a62" });
  add(new THREE.Mesh(new THREE.BoxGeometry(hallHalf * 2 + 3, 0.5, 1.2), stoneMat), 0, 0.25 - 0.45, frontZ + 0.6);
  for (let k = 0; k < 3; k += 1) add(new THREE.Mesh(new THREE.BoxGeometry(pathWidth + 1, 0.12, 0.6), std({ color: k % 2 ? "#7b766d" : "#6a655d" })), 0, 0.06 - k * 0.0, frontZ + 1.3 + k * 0.6);

  // ---- the main hall: columns, beams, roof, plaque
  const red = std({ color: "#6b1f17", roughness: 0.6 });
  const beamMat = std({ color: "#3a2a20", roughness: 0.7 });
  const gold = std({ color: "#c9a14a", metalness: 0.6, roughness: 0.35 });
  const roofY = 11;
  const backZ = -9.4;
  const columns = narrow ? [-hallHalf + 0.4, -hallHalf / 3, hallHalf / 3, hallHalf - 0.4] : [-hallHalf + 0.4, -hallHalf * 0.55, -hallHalf * 0.2, hallHalf * 0.2, hallHalf * 0.55, hallHalf - 0.4];
  const colGeo = new THREE.CylinderGeometry(0.42, 0.48, roofY, 14);
  const facade: Three[] = [];
  for (const x of columns) {
    facade.push(add(new THREE.Mesh(colGeo, red), x, roofY / 2, frontZ - 0.6));
    facade.push(add(new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.75, 0.4, 14), stoneMat), x, 0.2, frontZ - 0.6));
  }
  // front beam with painted band and the plaque
  facade.push(add(new THREE.Mesh(new THREE.BoxGeometry(hallHalf * 2 + 1.6, 0.9, 0.7), std({ color: "#24443c", roughness: 0.6 })), 0, roofY - 0.9, frontZ - 0.6));
  facade.push(add(new THREE.Mesh(new THREE.BoxGeometry(hallHalf * 2 + 1.6, 0.2, 0.75), gold), 0, roofY - 0.4, frontZ - 0.6));
  const plaque = new THREE.Mesh(new THREE.PlaneGeometry(narrow ? 5.4 : 6.6, narrow ? 1.8 : 2.2), new THREE.MeshStandardMaterial({ map: texture(plaqueCanvas(opts.plaque, opts.plaqueSmall)), roughness: 0.5, emissive: new THREE.Color("#ffffff"), emissiveIntensity: 0.25, emissiveMap: texture(plaqueCanvas(opts.plaque, opts.plaqueSmall)) }));
  facade.push(add(plaque, 0, roofY - 2.4, frontZ - 0.2));
  // hanging red lanterns along the eave
  const lanternMat = std({ color: "#c0392b", emissive: new THREE.Color("#ff6a3a"), emissiveIntensity: 0.6, roughness: 0.5 });
  const lanternGlow = texture(glowCanvas("rgba(255,150,90,1)"));
  const eaveLanterns: Three[] = [];
  for (const x of columns.slice(0, -1).map((value, index) => (value + columns[index + 1]) / 2).filter((x) => Math.abs(x) > (narrow ? 3.2 : 3.8))) {
    const lamp = add(new THREE.Mesh(new THREE.SphereGeometry(0.42, 14, 10), lanternMat), x, roofY - 2.3, frontZ + 0.2); lamp.scale.y = 1.25;
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: lanternGlow, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0.6 }));
    glow.scale.set(2.4, 2.4, 1); add(glow, x, roofY - 2.3, frontZ + 0.25); eaveLanterns.push(lamp); facade.push(lamp, glow);
  }
  // walls on both sides with a lattice band, and the back wall above the mural
  const wallMat = std({ color: "#5a2a22", roughness: 0.9 });
  for (const side of [-1, 1]) {
    const wall = new THREE.Mesh(new THREE.BoxGeometry(0.4, roofY, frontZ - backZ), wallMat);
    add(wall, side * (hallHalf + 0.3), roofY / 2, (frontZ + backZ) / 2 - 0.3);
  }
  // roof: deep overhanging eaves, ridge and gold ridge ends; ceiling below
  const roof: Three[] = [];
  const roofMat = std({ map: texture(roofCanvas(), 10, 3), roughness: 0.8, side: THREE.DoubleSide });
  const depth = frontZ - backZ + 5, width = hallHalf * 2 + 7;
  const slope = 0.42;
  for (const side of [-1, 1]) {
    const half = new THREE.Mesh(new THREE.PlaneGeometry(width, depth / 2 / Math.cos(slope)), roofMat);
    half.rotation.x = -Math.PI / 2 + side * slope;
    half.position.set(0, roofY + 0.4 + Math.tan(slope) * depth / 4, (frontZ + backZ) / 2 + side * depth / 4);
    scene.add(half); roof.push(half);
  }
  const ridge = add(new THREE.Mesh(new THREE.BoxGeometry(width - 2, 0.6, 0.7), std({ color: "#1f2226" })), 0, roofY + 0.4 + Math.tan(slope) * depth / 2, (frontZ + backZ) / 2); roof.push(ridge);
  for (const side of [-1, 1]) { const end = add(new THREE.Mesh(new THREE.ConeGeometry(0.45, 1.4, 8), gold), side * (width / 2 - 1), roofY + 1.2 + Math.tan(slope) * depth / 2, (frontZ + backZ) / 2); end.rotation.z = side * -0.5; roof.push(end); }
  const ceiling = new THREE.Mesh(new THREE.PlaneGeometry(hallHalf * 2 + 1, frontZ - backZ), std({ color: "#2b1d16", side: THREE.DoubleSide }));
  ceiling.rotation.x = Math.PI / 2; add(ceiling, 0, roofY, (frontZ + backZ) / 2); roof.push(ceiling);

  // ---- courtyard pieces
  // incense burner (鼎) on the plaza, with rising smoke
  const bronze = std({ color: "#5c4a2c", metalness: 0.65, roughness: 0.45 });
  add(new THREE.Mesh(new THREE.CylinderGeometry(1.1, 0.9, 1.2, 20), bronze), 0, 1.25, plazaZ);
  add(new THREE.Mesh(new THREE.TorusGeometry(1.15, 0.12, 8, 24), gold), 0, 1.85, plazaZ).rotation.x = Math.PI / 2;
  for (let k = 0; k < 3; k += 1) { const leg = add(new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.16, 0.8, 8), bronze), Math.cos(k * 2.09) * 0.7, 0.4, plazaZ + Math.sin(k * 2.09) * 0.7); leg.rotation.z = Math.cos(k * 2.09) * 0.15; }
  add(new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.8, 0.3, 20), stoneMat), 0, 0.15, plazaZ);
  const smokeTex = texture(glowCanvas("rgba(235,230,220,.55)"));
  const smoke = Array.from({ length: 10 }, (_, index) => {
    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: smokeTex, transparent: true, depthWrite: false, opacity: 0.4 }));
    scene.add(sprite); return { sprite, phase: index / 10 };
  });
  // stone lanterns along the path
  const lanternStone = std({ color: "#8a857b" });
  const flameTex = texture(glowCanvas("rgba(255,190,110,1)"));
  const stoneLights: Three[] = [];
  const along = narrow ? [0.18, 0.62, 0.86] : [0.15, 0.62, 0.84];
  for (const k of along) for (const side of [-1, 1]) {
    const x = side * (pathWidth / 2 + 1.3), z = frontZ + (gateZ - frontZ) * k;
    add(new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.3, 1.3, 8), lanternStone), x, 0.65, z);
    add(new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.6, 0.75), lanternStone), x, 1.6, z);
    add(new THREE.Mesh(new THREE.ConeGeometry(0.7, 0.5, 4), lanternStone), x, 2.15, z).rotation.y = Math.PI / 4;
    const flame = new THREE.Sprite(new THREE.SpriteMaterial({ map: flameTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0.85 }));
    flame.scale.set(1.2, 1.2, 1); add(flame, x, 1.6, z); stoneLights.push(flame);
  }
  // trees: red maples and dark pines, low-poly clumps
  const trunkMat = std({ color: "#3b2a20" });
  const leafMats = ["#b8401f", "#d0602a", "#c9902f", "#a33a24", "#e0a040"].map((color) => std({ color, roughness: 0.9, flatShading: true }));
  const pineMat = std({ color: "#2f4a3a", roughness: 0.9, flatShading: true });
  const leafGeo = new THREE.IcosahedronGeometry(1, 0);
  const rand = rng(21);
  const sway: Array<{ group: Three; phase: number }> = [];
  // 祈福灯 hung in the maples: small glowing lanterns that sway (more light around the courtyard at dusk)
  const wishColors = ["#e8574a", "#f0a23c", "#f4d06a", "#e9787a", "#d9b25c"];
  const wishGlow = texture(glowCanvas("rgba(255,180,100,1)"));
  const wishLamps: Array<{ lamp: Three; glow: Three; tree: Three; ox: number; oy: number; oz: number; phase: number }> = [];
  const treeSpots: Array<{ x: number; z: number; face: number }> = [];
  const trees: Three[] = [];
  const tree = (x: number, z: number, scale: number, pine: boolean) => {
    const group = new THREE.Group(); group.position.set(x, 0, z); group.scale.setScalar(scale);
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.32, 3.2, 7), trunkMat); trunk.position.y = 1.6; group.add(trunk);
    if (pine) {
      for (let k = 0; k < 3; k += 1) { const cone = new THREE.Mesh(new THREE.ConeGeometry(1.8 - k * 0.45, 2, 8), pineMat); cone.position.y = 3 + k * 1.1; group.add(cone); }
    } else {
      for (let k = 0; k < 6; k += 1) {
        const clump = new THREE.Mesh(leafGeo, leafMats[Math.floor(rand() * leafMats.length)]);
        clump.position.set((rand() - 0.5) * 2.6, 3.4 + rand() * 1.6, (rand() - 0.5) * 2.6); clump.scale.setScalar(0.9 + rand() * 0.8); group.add(clump);
      }
      if (Math.abs(x) < yardHalf) for (let k = 0; k < 3; k += 1) {
        const color = wishColors[Math.floor(rand() * wishColors.length)];
        const lamp = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.32, 10), std({ color, emissive: new THREE.Color(color), emissiveIntensity: 0.9 }));
        const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: wishGlow, color: new THREE.Color(color), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0.7 }));
        glow.scale.set(1.3, 1.3, 1);
        const angle = rand() * Math.PI * 2;
        const ox = Math.cos(angle) * 1.3 * scale, oz = Math.sin(angle) * 1.3 * scale, oy = (2.6 + rand() * 0.6) * scale;
        scene.add(lamp, glow);
        wishLamps.push({ lamp, glow, tree: group, ox, oy, oz, phase: rand() * 6 });
      }
    }
    scene.add(group); sway.push({ group, phase: rand() * 6 }); trees.push(group);
  };
  const span = gateZ - frontZ;
  const treeRows = narrow ? [0.24, 0.42, 0.6, 0.78, 0.95] : [0.22, 0.4, 0.58, 0.76, 0.93];
  treeRows.forEach((k, index) => {
    for (const side of [-1, 1]) {
      const x = side * (pathWidth / 2 + 4.2 + (index % 2) * 1.8 + rand() * 1.2), z = frontZ + span * k;
      if (side === 1 && k > 0.2 && k < 0.58) continue; // the pond sits here
      tree(x, z, 0.95 + rand() * 0.45, index % 3 === 2);
      // a spot beside the trunk, on the path side, facing the path
      treeSpots.push({ x: x - side * 1.4, z: z + (rand() - 0.5) * 1.2, face: side > 0 ? -Math.PI / 2 : Math.PI / 2 });
      tree(side * (yardHalf + 2 + rand() * 4), z + rand() * 3, 1.1 + rand() * 0.5, index % 2 === 0);
      // and under the same tree, on its far side, looking at the hall
      treeSpots.push({ x: x + side * 1.3, z: z - 1.1, face: Math.PI });
    }
  });
  // lotus pond on the right, with pads and a few pink flowers, and benches facing it
  const pondX = pathWidth / 2 + (narrow ? 6.2 : 7.5), pondZ = frontZ + span * 0.38, pondR = narrow ? 3.6 : 4.6;
  const pondRim = new THREE.Mesh(new THREE.TorusGeometry(pondR, 0.28, 8, 40), stoneMat); pondRim.rotation.x = Math.PI / 2; add(pondRim, pondX, 0.12, pondZ);
  const water = new THREE.Mesh(new THREE.CircleGeometry(pondR, 40), new THREE.MeshStandardMaterial({ map: texture(waterCanvas(), 2), roughness: 0.15, metalness: 0.3 }));
  water.rotation.x = -Math.PI / 2; add(water, pondX, 0.06, pondZ);
  const padMat = std({ color: "#3f6b3a", roughness: 0.7, side: THREE.DoubleSide });
  const petal = std({ color: "#f2b8c6", emissive: new THREE.Color("#5a2030"), emissiveIntensity: 0.25 });
  const flowers: Three[] = [];
  for (let k = 0; k < 11; k += 1) {
    const a = rand() * Math.PI * 2, r = rand() * (pondR - 0.8);
    const pad = new THREE.Mesh(new THREE.CircleGeometry(0.35 + rand() * 0.25, 12, 0.3, Math.PI * 1.85), padMat); pad.rotation.x = -Math.PI / 2; pad.rotation.z = rand() * 6; add(pad, pondX + Math.cos(a) * r, 0.09, pondZ + Math.sin(a) * r);
    if (k % 3 === 0) { const flower = add(new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.35, 6, 1, true), petal), pondX + Math.cos(a) * r, 0.25, pondZ + Math.sin(a) * r); flower.rotation.x = Math.PI; flowers.push(flower); }
  }
  const benchMat = std({ color: "#4a3426" });
  const benches: Array<{ x: number; z: number; face: number }> = [];
  for (const dz of [-pondR - 1.6, pondR + 1.6]) {
    const x = pondX - 0.4, z = pondZ + dz;
    add(new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.12, 0.6), benchMat), x, 0.55, z);
    for (const dx of [-1, 1]) add(new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.55, 0.5), benchMat), x + dx * 1.0, 0.27, z);
    benches.push({ x, z, face: dz < 0 ? 0 : Math.PI });
  }
  // mountain gate (山门 / 牌坊) at the far end
  const gateGroup = new THREE.Group(); gateGroup.position.set(0, 0, gateZ); scene.add(gateGroup);
  const gateHalf = pathWidth / 2 + 1.4;
  for (const side of [-1, 1]) {
    const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.45, 7, 12), red); pillar.position.set(side * gateHalf, 3.5, 0); gateGroup.add(pillar);
    const base = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1, 1.2), stoneMat); base.position.set(side * gateHalf, 0.5, 0); gateGroup.add(base);
  }
  const lintel = new THREE.Mesh(new THREE.BoxGeometry(gateHalf * 2 + 2, 0.7, 0.7), std({ color: "#24443c" })); lintel.position.y = 6.2; gateGroup.add(lintel);
  const gateRoof = new THREE.Mesh(new THREE.BoxGeometry(gateHalf * 2 + 3.4, 0.5, 2.2), std({ map: texture(roofCanvas(), 4, 1) })); gateRoof.position.y = 7.4; gateGroup.add(gateRoof);
  const gateRidge = new THREE.Mesh(new THREE.BoxGeometry(gateHalf * 2 + 1, 0.4, 0.5), std({ color: "#1f2226" })); gateRidge.position.y = 7.85; gateGroup.add(gateRidge);
  const gatePlaque = new THREE.Mesh(new THREE.PlaneGeometry(3.6, 1.2), new THREE.MeshStandardMaterial({ map: texture(plaqueCanvas(opts.gate, "")), roughness: 0.5 }));
  gatePlaque.position.set(0, 6.95, -0.4); gatePlaque.rotation.y = Math.PI; gateGroup.add(gatePlaque);
  const gatePlaqueFront = gatePlaque.clone(); gatePlaqueFront.position.z = 0.4; gatePlaqueFront.rotation.y = 0; gateGroup.add(gatePlaqueFront);
  // low courtyard walls on both sides
  const wallLow = std({ color: "#7a3a2c" });
  for (const side of [-1, 1]) {
    add(new THREE.Mesh(new THREE.BoxGeometry(0.5, 2.2, span), wallLow), side * yardHalf, 1.1, frontZ + span / 2);
    add(new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.3, span), std({ color: "#2c2f33" })), side * yardHalf, 2.35, frontZ + span / 2);
    add(new THREE.Mesh(new THREE.BoxGeometry(yardHalf - gateHalf - 0.5, 2.2, 0.5), wallLow), side * (gateHalf + 0.5 + (yardHalf - gateHalf - 0.5) / 2), 1.1, gateZ);
  }

  // where strolling members go: a loop round the plaza and down the path, and places to stop
  const loop: Array<[number, number]> = [[-2.2, frontZ + 2.5], [-2.2, plazaZ - 8.5], [-8.5, plazaZ], [-2.2, plazaZ + 8.5], [-2.2, gateZ - 2.5], [2.2, gateZ - 2.5], [2.2, plazaZ + 8.5], [8.5, plazaZ], [2.2, plazaZ - 8.5], [2.2, frontZ + 2.5]];
  const spots = [
    { x: 0, z: plazaZ + 2.6, face: Math.PI }, { x: -1.5, z: plazaZ - 2.5, face: 0 }, { x: 1.5, z: plazaZ - 2.5, face: 0 }, // bowing at the burner
    ...benches.map((bench) => ({ ...bench, sit: true })),
    { x: pondX - pondR - 0.8, z: pondZ - 1, face: -Math.PI / 2 }, { x: pondX - pondR - 0.8, z: pondZ + 1.2, face: -Math.PI / 2 }, // at the pond
    { x: -pathWidth / 2 - 2.5, z: frontZ + span * 0.15, face: Math.PI }, { x: 1, z: frontZ + 3.2, face: Math.PI }, // before the hall
  ];

  const clamp = (x: number, z: number) => {
    let cx = Math.max(-yardHalf + 1, Math.min(yardHalf - 1, x));
    let cz = Math.max(-5.6, Math.min(gateZ - 1.2, z));
    // inside the hall: stay between its walls
    if (cz < frontZ - 0.6) cx = Math.max(-hallHalf + 0.6, Math.min(hallHalf - 0.6, cx));
    // keep out of the pond and the burner
    const dx = cx - pondX, dz = cz - pondZ, d = Math.hypot(dx, dz);
    if (d < pondR + 0.6) { cx = pondX + (dx / (d || 1)) * (pondR + 0.6); cz = pondZ + (dz / (d || 1)) * (pondR + 0.6); }
    const bx = cx, bz = cz - plazaZ, bd = Math.hypot(bx, bz);
    if (bd < 2.2) { cx = (bx / (bd || 1)) * 2.2; cz = plazaZ + (bz / (bd || 1)) * 2.2; }
    return { x: cx, z: cz };
  };

  const update = (time: number, camera?: { x: number; y: number; z: number }) => {
    // a tree right next to the camera is hidden so it never fills the screen
    if (camera) gateGroup.visible = camera.z < gateZ - 1.5;
    if (camera) for (const tree of trees) tree.visible = Math.hypot(tree.position.x - camera.x, tree.position.z - camera.z) > 7 * tree.scale.x || camera.y > 12;
    for (const wish of wishLamps) {
      const swing = Math.sin(time * 0.9 + wish.phase) * 0.06;
      wish.lamp.position.set(wish.tree.position.x + wish.ox + swing, wish.oy + Math.sin(time * 1.3 + wish.phase) * 0.04, wish.tree.position.z + wish.oz);
      wish.lamp.visible = wish.tree.visible;
      wish.glow.position.copy(wish.lamp.position); wish.glow.visible = wish.tree.visible;
      const pulse = 1.3 * (1 + Math.sin(time * 2 + wish.phase) * 0.06); wish.glow.scale.set(pulse, pulse, 1);
    }
    for (const puff of smoke) {
      const k = (time * 0.12 + puff.phase) % 1;
      puff.sprite.position.set(Math.sin(time * 0.6 + puff.phase * 9) * 0.3 * k, 2 + k * 5.5, plazaZ + Math.cos(time * 0.5 + puff.phase * 7) * 0.2 * k);
      const size = 0.8 + k * 2.4; puff.sprite.scale.set(size, size, 1);
      puff.sprite.material.opacity = 0.42 * (1 - k) * Math.min(1, k * 6);
    }
    for (const tree of sway) tree.group.rotation.z = Math.sin(time * 0.6 + tree.phase) * 0.012;
    for (const flame of stoneLights) { const f = 1 + Math.sin(time * 9 + flame.position.z) * 0.08; flame.scale.set(1.2 * f, 1.2 * f, 1); }
    for (const lamp of eaveLanterns) lamp.rotation.z = Math.sin(time * 0.8 + lamp.position.x) * 0.06;
  };

  return { roof, roofY, facade, treeSpots, clamp, loop, spots, gateZ, frontZ, update };
}
