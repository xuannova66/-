// Search metadata for every public URL: title, description, canonical, hreflang and structured data.
import type { Metadata } from "next";
import { titleForRoute, type AppRoute } from "./study-suite";
import { PUBLIC_ROUTES, URL_LOCALES, pathFor, type UrlLocale } from "./study-navigation";

export const SITE_URL = "https://xuannova.com";

type L7 = Record<UrlLocale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

const siteName = L("Xuannova · Eastern traditional culture study", "Xuannova · 东方传统文化研习", "Xuannova · 東方傳統文化研習", "Xuannova · 東洋伝統文化の学び", "Xuannova · 동양 전통문화 학습", "Xuannova · Học văn hóa truyền thống phương Đông", "Xuannova · ศึกษาวัฒนธรรมดั้งเดิมตะวันออก");
const homeDescription = L(
  "Free BaZi, Zi Wei Dou Shu, I Ching, Qi Men and daily almanac charts calculated from classical rules, in seven languages. Founding team with 26 years in Eastern metaphysics; 58 mentors review the content.",
  "免费八字排盘、紫微斗数、六爻、奇门遁甲与每日黄历，按典籍规则计算，支持 7 种语言。创始团队深耕东方命理 26 年，58 位导师参与内容审校。",
  "免費八字排盤、紫微斗數、六爻、奇門遁甲與每日黃曆，按典籍規則計算，支援 7 種語言。創始團隊深耕東方命理 26 年，58 位導師參與內容審校。",
  "四柱推命・紫微斗数・六爻・奇門遁甲・毎日の暦を古典の規則で無料作成。7言語対応。創業チームは東洋命理に26年、58名の講師が内容を監修。",
  "사주팔자, 자미두수, 육효, 기문둔갑, 매일 역서를 고전 규칙으로 무료 계산합니다. 7개 언어 지원. 창립 팀 26년 경력, 58명의 강사가 콘텐츠를 감수합니다.",
  "Lập lá số Bát Tự, Tử Vi, Lục Hào, Kỳ Môn và lịch hằng ngày miễn phí theo quy tắc kinh điển, 7 ngôn ngữ. Đội ngũ sáng lập 26 năm kinh nghiệm, 58 người hướng dẫn thẩm định nội dung.",
  "คำนวณดวงปาจื้อ จื่อเวย ลิ่วเหยา ฉีเหมิน และปฏิทินรายวันฟรีตามกฎตำราดั้งเดิม รองรับ 7 ภาษา ทีมผู้ก่อตั้งมีประสบการณ์ 26 ปี และผู้สอน 58 ท่านร่วมตรวจทานเนื้อหา",
);
const routeDescriptions: Partial<Record<AppRoute, L7>> = {
  flash: L("Xuannova Flash: today's news read through the five elements, the I Ching and the solar terms, with a line from the classics. In seven languages.", "Xuannova 快讯：用五行、易经与节气解读今日热点，配一句经典。七种语言。", "Xuannova 快訊：用五行、易經與節氣解讀今日熱點，配一句經典。七種語言。", "Xuannova 速報：今日のニュースを五行・易経・節気で読み、古典の一句を添えて。7言語。", "Xuannova 속보: 오늘의 뉴스를 오행·주역·절기로 읽고 고전 한 구절을 더합니다. 7개 언어.", "Tin nhanh Xuannova: tin nóng hôm nay qua ngũ hành, Kinh Dịch và tiết khí, kèm một câu kinh điển. 7 ngôn ngữ.", "ข่าวด่วน Xuannova: ข่าววันนี้ผ่านห้าธาตุ อี้จิง และฤดูกาล พร้อมวลีจากคัมภีร์ 7 ภาษา"),
  meihua: L("Plum blossom numerology: cast from the moment, two numbers or a phrase; original, mutual and changed hexagrams with body and function.", "梅花易数起卦：按时间、数字或一句话起卦，看本卦、互卦、变卦与体用生克。", "梅花易數起卦：按時間、數字或一句話起卦，看本卦、互卦、變卦與體用生剋。", "梅花易数：時刻・数字・一文で卦を立て、本卦・互卦・変卦と体用を見ます。", "매화역수: 시간, 숫자, 한 문장으로 괘를 세워 본괘·호괘·변괘와 체용을 봅니다.", "Mai Hoa Dịch Số: lập quẻ theo thời gian, con số hoặc một câu; quẻ chủ, hỗ, biến và thể dụng.", "เหมยฮวาอี้ซู่: ตั้งกว้าจากเวลา ตัวเลข หรือประโยค ดูกว้าหลัก กว้าซ้อน กว้าแปร และกายกับการใช้"),
  jinkoujue: L("Jin Kou Jue (Golden Mouth Formula): human stem, noble general, general spirit and earth position, with the use position and their relations.", "金口诀起课：人元、贵神、将神、地分四位，看用爻、旺衰与上下生克。", "金口訣起課：人元、貴神、將神、地分四位，看用爻、旺衰與上下生剋。", "金口訣：人元・貴神・将神・地分の四位と用爻、旺衰、上下の生剋。", "금구결: 인원, 귀신, 장신, 지분 네 자리와 용효, 왕쇠, 상하 생극.", "Kim Khẩu Quyết: bốn vị nhân nguyên, quý thần, tướng thần, địa phân, cùng dụng hào và sinh khắc.", "จินโข่วเจวี๋ย: สี่ตำแหน่ง ก้านมนุษย์ เทพผู้อุปถัมภ์ เทพแม่ทัพ และตำแหน่งดิน พร้อมตำแหน่งใช้"),
  heluo: L("He Luo numerology: heaven and earth numbers from the eight characters, Former and Later Heaven hexagrams, Yuan Tang line and life periods.", "河洛理数排盘：八字化天数地数，得先天卦、后天卦、元堂与一生大运年限。", "河洛理數排盤：八字化天數地數，得先天卦、後天卦、元堂與一生大運年限。", "河洛理数：八字から天数・地数を出し、先天卦・後天卦・元堂と人生の運期。", "하락이수: 사주에서 천수와 지수를 내어 선천괘, 후천괘, 원당과 평생 운기.", "Hà Lạc Lý Số: thiên số, địa số từ bát tự, quẻ tiên thiên, hậu thiên, nguyên đường và các vận đời.", "เหอลั่วหลี่ซู่: เลขฟ้าและเลขดินจากปาจื้อ กว้าก่อนฟ้า หลังฟ้า หยวนถัง และช่วงวัย"),
  tieban: L("Tie Ban number framework: Tai Xuan numbers of the eight characters, the derived hexagram and the eight quarters of the birth hour. Verse texts not included.", "铁板神数数理排盘：八字太玄数、所得之卦与出生时辰八刻考刻（不含条文）。", "鐵板神數數理排盤：八字太玄數、所得之卦與出生時辰八刻考刻（不含條文）。", "鉄板神数の数理：八字の太玄数、得られる卦、出生時辰の八刻（条文は含みません）。", "철판신수 수리: 사주의 태현수, 얻은 괘, 출생 시진의 팔각(조문 미포함).", "Khung số Thiết Bản: số Thái Huyền của bát tự, quẻ suy ra và tám khắc của giờ sinh (không kèm điều văn).", "กรอบตัวเลขเถี่ยป่าน: เลขไท่เสวียนของปาจื้อ กว้าที่ได้ และแปดช่วงของยามเกิด (ไม่รวมคำกลอน)"),
  taiyi: L("Tai Yi yearly reckoning: accumulated years, the palace Tai Yi occupies, years in palace and the five 72-year eras.", "太乙神数年计：积年、太乙所在宫位、居宫年数与五元大势。", "太乙神數年計：積年、太乙所在宮位、居宮年數與五元大勢。", "太乙神数・年計：積年、太乙の宮、在宮年数と五元。", "태을신수 연계: 적년, 태을의 궁, 머문 햇수와 오원.", "Thái Ất niên kế: tích niên, cung Thái Ất, số năm ở cung và ngũ nguyên.", "ไท่อี่ประจำปี: ปีสะสม วังของไท่อี่ ปีที่อยู่ในวัง และห้ายุค"),
  xiangshu: L("Palm and face reading from one photo: hand shape, life, head and heart lines, mounts; face shape, three courts and five features, read by the classical rules. Photos are not stored.", "手相面相：上传一张照片，看手型、生命线、智慧线、感情线与掌丘，或脸型、三停与五官，按传统相法解读。照片不保存。", "手相面相：上傳一張照片，看手型、生命線、智慧線、感情線與掌丘，或臉型、三停與五官，按傳統相法解讀。照片不保存。", "手相・人相：写真一枚から手の型・生命線・頭脳線・感情線・丘、または顔の型・三停・五官を伝統の相法で読みます。写真は保存しません。", "수상·관상: 사진 한 장으로 손 모양, 생명선·두뇌선·감정선, 구 또는 얼굴형, 삼정, 오관을 전통 상법으로 봅니다. 사진은 저장하지 않습니다.", "Xem tướng tay & mặt từ một ảnh: dáng tay, các đường chỉ, các gò; dáng mặt, tam đình và ngũ quan theo tướng pháp truyền thống. Không lưu ảnh.", "ลายมือและโหงวเฮ้งจากรูปเดียว: รูปมือ เส้นชีวิต สมอง หัวใจ เนินฝ่ามือ หรือรูปหน้า สามส่วน และห้าอวัยวะ ตามหลักดั้งเดิม ไม่เก็บรูป"),
  zeri: L("Personal date selection: favourable days for a wedding, moving house, opening a business and more, with clashes against your zodiac and day branch left out.", "专业择日：按你的八字挑选嫁娶、搬家、开业等吉日，避开冲生肖、冲日柱及岁破、月破、四离四绝、杨公忌。", "專業擇日：按你的八字挑選嫁娶、搬家、開業等吉日，避開沖生肖、沖日柱及歲破、月破、四離四絕、楊公忌。", "個人の日取り：結婚・引っ越し・開業などの吉日を、干支の冲を避けて命盤に合わせて選びます。", "개인 택일: 결혼, 이사, 개업 등의 길일을 띠와 일지의 충을 피해 사주에 맞춰 고릅니다.", "Chọn ngày theo tuổi: ngày tốt cho cưới hỏi, chuyển nhà, khai trương…, tránh ngày xung tuổi và xung chi ngày.", "เลือกฤกษ์เฉพาะตัว: วันดีสำหรับแต่งงาน ย้ายบ้าน เปิดกิจการ ฯลฯ เลี่ยงวันชงกับปีนักษัตรและกิ่งวัน"),
  cezi: L("Character divination (测字): one Chinese character, its Kangxi strokes, radical and components, and a hexagram cast from the strokes.", "测字：一个汉字的康熙笔画、部首、拆字与五行，并以笔画起卦解读你的问题。", "測字：一個漢字的康熙筆畫、部首、拆字與五行，並以筆畫起卦解讀你的問題。", "測字：漢字一字の康熙画数・部首・構成要素と、画数から立てる卦。", "측자: 한자 한 글자의 강희 획수, 부수, 구성 요소와 획수로 세우는 괘.", "Đoán chữ: số nét Khang Hy, bộ thủ, thành phần của một chữ Hán và quẻ lập từ số nét.", "ทำนายอักษร: จำนวนขีดคังซี หมวดนำ ส่วนประกอบ และกว้าที่ตั้งจากจำนวนขีด"),
  zhuzhai: L("Home analysis: personal trigram, house trigram by facing, the eight directions and this year's flying stars.", "住宅详情分析：命卦、宅卦与坐向，八方吉凶参考与今年流年飞星。", "住宅詳情分析：命卦、宅卦與坐向，八方吉凶參考與今年流年飛星。", "住まいの詳細分析：本命卦・宅卦と坐向、八方位と今年の飛星。", "주택 상세 분석: 본명괘, 좌향에 따른 택괘, 팔방위와 올해 비성.", "Phân tích chi tiết nhà ở: mệnh quái, trạch quái theo tọa hướng, tám phương và phi tinh năm nay.", "วิเคราะห์รายละเอียดบ้าน: กว้าประจำตัว กว้าบ้านตามทิศ แปดทิศ และดาวบินปีนี้"),
  bazi: L("Free BaZi (Four Pillars) chart: ten gods, hidden stems, life stages, NaYin, luck cycles, shen-sha and branch relations, calculated from classical rules.", "免费八字排盘：十神、藏干、十二长生、纳音、大运、神煞与地支关系，按典籍规则计算。", "免費八字排盤：十神、藏干、十二長生、納音、大運、神煞與地支關係，按典籍規則計算。", "無料の四柱推命：通変星・蔵干・十二運・納音・大運・神殺・地支の関係を古典の規則で計算します。", "무료 사주팔자: 십성, 장간, 십이운성, 납음, 대운, 신살, 지지 관계를 고전 규칙으로 계산합니다.", "Lá số Bát Tự miễn phí: thập thần, tàng can, trường sinh, nạp âm, đại vận, thần sát và quan hệ địa chi.", "ดวงปาจื้อฟรี: สิบเทพ ก้านซ่อน สิบสองช่วง น่ายิน วัฏจักรสิบปี ดาวพิเศษ และความสัมพันธ์กิ่งดิน"),
  ziwei: L("Free Zi Wei Dou Shu chart with the 14 main stars, auxiliary stars, four transformations, brightness and decade limits.", "免费紫微斗数排盘：十四主星、辅星、四化、庙旺与大限。", "免費紫微斗數排盤：十四主星、輔星、四化、廟旺與大限。", "無料の紫微斗数：十四主星・補佐星・四化・廟旺・大限。", "무료 자미두수: 14주성, 보좌성, 사화, 묘왕, 대한.", "Lá số Tử Vi miễn phí: 14 chính tinh, phụ tinh, tứ hóa, miếu vượng và đại hạn.", "ผังจื่อเวยฟรี: ดาวหลัก 14 ดวง ดาวเสริม สี่การแปร ความแรง และรอบสิบปี"),
  liuyao: L("Six-line I Ching divination by the Na Jia method: palaces, world and response lines, six relatives and six spirits.", "六爻纳甲起卦：八宫、世应、六亲、六神与变卦。", "六爻納甲起卦：八宮、世應、六親、六神與變卦。", "納甲法による六爻占：八宮・世応・六親・六神・変卦。", "납갑법 육효: 팔궁, 세응, 육친, 육신, 변괘.", "Lục Hào nạp giáp: bát cung, thế ứng, lục thân, lục thần và quẻ biến.", "ลิ่วเหยาแบบน่าเจี่ย: แปดวัง เส้นตนและเส้นตอบ หกญาติ หกวิญญาณ"),
  qimen: L("Hour Qi Men Dun Jia chart: bureau, nine stars, eight gates and eight deities for the current moment.", "时家奇门遁甲排盘：定局、九星、八门、八神。", "時家奇門遁甲排盤：定局、九星、八門、八神。", "時家奇門遁甲：局・九星・八門・八神。", "시가 기문둔갑: 국, 구성, 팔문, 팔신.", "Kỳ Môn Độn Giáp theo giờ: cục, cửu tinh, bát môn, bát thần.", "ฉีเหมินตุ้นเจี่ยรายชั่วยาม: ผัง เก้าดาว แปดประตู แปดเทพ"),
  daliuren: L("Da Liu Ren chart: monthly general, heaven and earth plates, four lessons, three transmissions and heavenly generals.", "大六壬排盘：月将、天地盘、四课、三传与天将。", "大六壬排盤：月將、天地盤、四課、三傳與天將。", "大六壬：月将・天地盤・四課・三伝・天将。", "대육임: 월장, 천지반, 사과, 삼전, 천장.", "Đại Lục Nhâm: nguyệt tướng, thiên địa bàn, tứ khóa, tam truyền, thiên tướng.", "ต้าลิ่วเหริน: แม่ทัพเดือน แผ่นฟ้าดิน สี่บท สามจุดส่ง แม่ทัพฟ้า"),
  daily: L("Today's almanac: hour pillars, auspicious hours, day officer, solar terms and traditional favourable and cautionary activities.", "今日黄历：十二时辰、黄道吉时、建除、节气与宜忌。", "今日黃曆：十二時辰、黃道吉時、建除、節氣與宜忌。", "今日の暦：十二時辰・吉時・十二直・節気・宜忌。", "오늘의 역서: 12시진, 길시, 건제, 절기, 의기.", "Lịch hôm nay: mười hai giờ, giờ hoàng đạo, trực, tiết khí và nên/kiêng.", "ปฏิทินวันนี้: สิบสองยาม ยามมงคล เจ้าหน้าที่ประจำวัน สารท และสิ่งที่ควร/ไม่ควร"),
  compatibility: L("Compare two BaZi charts: stem combinations, branch relations and element balance.", "两人八字合盘：天干五合、地支关系与五行互补。", "兩人八字合盤：天干五合、地支關係與五行互補。", "二人の四柱の相性：干合・地支の関係・五行の補完。", "두 사람의 사주 궁합: 천간합, 지지 관계, 오행 보완.", "So sánh hai lá số Bát Tự: hợp can, quan hệ chi và ngũ hành.", "เปรียบเทียบดวงปาจื้อสองคน: การรวมก้าน ความสัมพันธ์กิ่ง และสมดุลธาตุ"),
  toolkit: L("Study references: birth-hour finder, five-element balance, name study, natal chart, I Ching, tarot and dream images.", "术数百宝：寻时定盘、五行喜忌、姓名参详、星盘、周易研习、塔罗与解梦。", "術數百寶：尋時定盤、五行喜忌、姓名參詳、星盤、周易研習、塔羅與解夢。", "研究の常備：生まれ時刻の確認、五行、名前、ネイタルチャート、易経、タロット、夢。", "학습 상비: 출생 시각 찾기, 오행, 이름, 출생 차트, 주역, 타로, 꿈.", "Tra cứu thường dùng: tìm giờ sinh, ngũ hành, tên gọi, bản đồ sao, Kinh Dịch, tarot và giấc mơ.", "ข้อมูลอ้างอิงประจำการศึกษา: หาเวลาเกิด ธาตุทั้งห้า ชื่อ ผังดาว อี้จิง ไพ่ทาโรต์ และความฝัน"),
  almanac: L("Daily Chinese almanac: is today a good day? Favourable and unfavourable activities, zodiac clash, lucky hours and a good-day finder for weddings, moving house and more.", "每日黄历：今天日子好不好？宜忌、冲煞、吉时，还能按结婚、搬家、开业等事项找好日子。", "每日黃曆：今天日子好不好？宜忌、沖煞、吉時，還能按結婚、搬家、開業等事項找好日子。", "毎日の暦（黄暦）：今日は良い日？宜忌・冲・よい時間帯、結婚や引っ越しなどの良い日探し。", "매일의 황력: 오늘은 좋은 날일까? 의기, 충, 좋은 시간, 결혼·이사 등 좋은 날 찾기.", "Xem ngày tốt xấu mỗi ngày: việc nên làm, nên tránh, tuổi xung, giờ tốt và tìm ngày tốt để cưới hỏi, chuyển nhà…", "ปฏิทินจีนรายวัน: วันนี้ดีไหม สิ่งที่ควรทำและควรเลี่ยง ปีชง ช่วงเวลาดี และหาวันดีสำหรับแต่งงาน ย้ายบ้าน ฯลฯ"),
  guide: L("Beginner's guide to Xuannova: how to start, which method to choose, how to read your chart, free and paid readings, and common questions.", "Xuannova 新手指南：怎么开始、选哪个方法、怎么看懂命盘、免费与付费规则和常见问题。", "Xuannova 新手指南：怎麼開始、選哪個方法、怎麼看懂命盤、免費與付費規則和常見問題。", "Xuannova 初心者ガイド：始め方、方法の選び方、命盤の読み方、無料と有料、よくある質問。", "Xuannova 초보자 가이드: 시작하는 법, 방법 고르기, 명반 읽는 법, 무료와 유료, 자주 묻는 질문.", "Hướng dẫn Xuannova cho người mới: cách bắt đầu, chọn phương pháp, đọc lá số, miễn phí và trả phí, câu hỏi thường gặp.", "คู่มือมือใหม่ของ Xuannova: วิธีเริ่ม เลือกวิธีไหน อ่านผังอย่างไร อะไรฟรีอะไรเสียเงิน และคำถามที่พบบ่อย"),
  courses: L("Video lessons on the classics of Eastern traditional culture, free for registered members.", "东方传统文化典籍视频课程，免费注册后即可观看。", "東方傳統文化典籍影片課程，免費註冊後即可觀看。", "東洋伝統文化の古典を学ぶ動画講座。登録会員は無料で視聴できます。", "동양 전통문화 고전 영상 강좌, 가입 회원은 무료로 시청합니다.", "Khóa học video về kinh điển văn hóa truyền thống phương Đông, miễn phí cho thành viên đã đăng ký.", "คอร์สวิดีโอตำราวัฒนธรรมดั้งเดิมตะวันออก สมาชิกที่สมัครแล้วดูฟรี"),
  library: L("A free library of public-domain classics on yin-yang, the five elements, the I Ching and Chinese astrology.", "免费藏经阁：阴阳、五行、周易与命理的公有领域典籍。", "免費藏經閣：陰陽、五行、周易與命理的公有領域典籍。", "無料の蔵書：陰陽・五行・易経・命理のパブリックドメイン古典。", "무료 장서: 음양, 오행, 주역, 명리의 퍼블릭 도메인 고전.", "Thư viện miễn phí: kinh điển công cộng về âm dương, ngũ hành, Kinh Dịch và mệnh lý.", "ห้องสมุดฟรี: ตำราสาธารณสมบัติเรื่องหยินหยาง ห้าธาตุ อี้จิง และโหราศาสตร์จีน"),
};

const hreflang = (locale: UrlLocale) => (locale === "zh-Hans" ? "zh-Hans" : locale === "zh-Hant" ? "zh-Hant" : locale);

export function metadataFor(locale: UrlLocale, route: AppRoute): Metadata {
  const isHome = route === "home";
  const title = isHome ? siteName[locale] : `${titleForRoute(route, locale)} · Xuannova`;
  const description = (routeDescriptions[route] ?? homeDescription)[locale];
  const languages = Object.fromEntries(URL_LOCALES.map((code) => [hreflang(code), `${SITE_URL}${pathFor(code, route)}`]));
  return {
    title,
    description,
    alternates: { canonical: `${SITE_URL}${pathFor(locale, route)}`, languages: { ...languages, "x-default": `${SITE_URL}${pathFor("en", route)}` } },
    openGraph: { title, description, url: `${SITE_URL}${pathFor(locale, route)}`, siteName: "Xuannova", locale, images: [{ url: `${SITE_URL}/xuannova-og.jpg`, width: 1730, height: 909, alt: "Xuannova" }] },
    twitter: { card: "summary_large_image", title, description, images: [`${SITE_URL}/xuannova-og.jpg`] },
  };
}

export function structuredDataFor(locale: UrlLocale, route: AppRoute) {
  const url = `${SITE_URL}${pathFor(locale, route)}`;
  const graph: Array<Record<string, unknown>> = [
    { "@type": "Organization", "@id": `${SITE_URL}/#org`, name: "Xuannova", url: SITE_URL, logo: `${SITE_URL}/icon-512.png` },
    { "@type": "WebSite", "@id": `${SITE_URL}/#site`, name: "Xuannova", url: SITE_URL, inLanguage: URL_LOCALES, publisher: { "@id": `${SITE_URL}/#org` } },
  ];
  if (route !== "home") {
    const collection = route === "library" || route === "flash";
    graph.push({ "@type": collection ? "CollectionPage" : "WebApplication", name: titleForRoute(route, locale), url, inLanguage: locale, applicationCategory: collection ? undefined : "LifestyleApplication", operatingSystem: collection ? undefined : "Web", offers: collection ? undefined : { "@type": "Offer", price: "0", priceCurrency: "USD" }, description: (routeDescriptions[route] ?? homeDescription)[locale] });
    graph.push({ "@type": "BreadcrumbList", itemListElement: [{ "@type": "ListItem", position: 1, name: "Xuannova", item: `${SITE_URL}${pathFor(locale, "home")}` }, { "@type": "ListItem", position: 2, name: titleForRoute(route, locale), item: url }] });
  }
  return { "@context": "https://schema.org", "@graph": graph };
}

/** Every public URL in every language, for the sitemap. */
export function allPublicUrls() {
  return PUBLIC_ROUTES.flatMap((route) => URL_LOCALES.map((locale) => ({ locale, route, url: `${SITE_URL}${pathFor(locale, route)}` })));
}
