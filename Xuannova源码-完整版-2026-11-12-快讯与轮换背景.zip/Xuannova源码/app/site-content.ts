export type Locale = "en" | "zh-Hans" | "zh-Hant" | "ja" | "ko" | "vi" | "th";

export type ToolKey = "bazi" | "ziwei" | "qimen" | "tarot" | "iching" | "chart";

export type ThemeKey = "aureate" | "paper" | "nocturne";

export type StudyVisualKind = "pillars" | "palaces" | "spread" | "hexagram" | "celestial" | "timing" | "comparison" | "daily";

export type StudyModuleKey =
  | "synthesis"
  | "bazi"
  | "detail"
  | "compatibility"
  | "liuyao"
  | "ziwei"
  | "qizheng"
  | "qimen"
  | "daliuren"
  | "daily"
  | "toolkit";

export type StudyModule = {
  key: StudyModuleKey;
  mark: string;
  title: string;
  chineseTitle: string;
  subtitle: string;
  description: string;
  paired: boolean;
  visual: StudyVisualKind;
};

export const themeOptions: Array<{ key: ThemeKey; label: string; detail: string }> = [
  { key: "aureate", label: "Aureate", detail: "Plum · bronze · pearl" },
  { key: "paper", label: "Paper", detail: "Warm paper · ink · copper" },
  { key: "nocturne", label: "Nocturne", detail: "Blue-black · lunar silver" },
];

export const studyModules: StudyModule[] = [
  { key: "synthesis", mark: "参", title: "Synthesis Reading", chineseTitle: "合参研习", subtitle: "Three lenses, one considered view", description: "A local multi-lens overview that holds several symbolic patterns together.", paired: false, visual: "comparison" },
  { key: "bazi", mark: "命", title: "BaZi", chineseTitle: "八字排盘", subtitle: "Four pillars study", description: "Enter a birth moment and generate a four-pillar cultural study template.", paired: false, visual: "pillars" },
  { key: "detail", mark: "批", title: "BaZi Deep Reading", chineseTitle: "八字详研", subtitle: "Layered pillar observation", description: "A deeper reading layout for observing balance, rhythm and recurring themes.", paired: false, visual: "pillars" },
  { key: "compatibility", mark: "缘", title: "Compatibility", chineseTitle: "双人合盘", subtitle: "Two charts in dialogue", description: "Place two study profiles side by side and compare reflection themes.", paired: true, visual: "comparison" },
  { key: "liuyao", mark: "卦", title: "Liuyao", chineseTitle: "六爻起卦", subtitle: "Six-line contemplation", description: "A question-led hexagram template for careful symbolic observation.", paired: false, visual: "hexagram" },
  { key: "ziwei", mark: "紫", title: "Zi Wei", chineseTitle: "紫微斗数", subtitle: "Twelve-house study", description: "A twelve-house visual field for exploring symbolic placement and perspective.", paired: false, visual: "palaces" },
  { key: "qizheng", mark: "星", title: "Celestial Chart", chineseTitle: "星盘研习", subtitle: "Celestial sector view", description: "A local twelve-sector sky map for studying cyclical orientation.", paired: false, visual: "celestial" },
  { key: "qimen", mark: "奇", title: "Qi Men", chineseTitle: "奇门遁甲", subtitle: "Nine-palace timing field", description: "A nine-palace field for reflecting on context, direction and timing.", paired: false, visual: "timing" },
  { key: "daliuren", mark: "壬", title: "Da Liu Ren", chineseTitle: "大六壬", subtitle: "Three-transmission study", description: "A temporal observation layout for holding a question across beginning, middle and return.", paired: false, visual: "timing" },
  { key: "daily", mark: "辰", title: "Daily Rhythm", chineseTitle: "每日时序", subtitle: "Seasonal rhythm note", description: "A quiet daily check-in on seasons, pace and personal intention.", paired: false, visual: "daily" },
  { key: "toolkit", mark: "宝", title: "Study Toolkit", chineseTitle: "百宝袋", subtitle: "Small practical prompts", description: "A compact deck of useful study prompts for the present moment.", paired: false, visual: "spread" },
];

export const toolOrder: ToolKey[] = ["bazi", "ziwei", "qimen", "tarot", "iching", "chart"];

export const languageOptions: Array<{ value: Locale; label: string }> = [
  { value: "en", label: "English" },
  { value: "zh-Hans", label: "中文（简体）" },
  { value: "zh-Hant", label: "中文（繁體）" },
  { value: "ja", label: "日本語" },
  { value: "ko", label: "한국어" },
  { value: "vi", label: "Tiếng Việt" },
  { value: "th", label: "ไทย" },
];

type ToolCopy = { title: string; subtitle: string; mark: string; description: string };

export type SiteCopy = {
  nav: { services: string; tools: string; philosophy: string; library: string };
  language: string;
  join: string;
  eyebrow: string;
  heroTitle: string;
  slogan: string;
  altSlogan: string;
  heroDescription: string;
  primaryCta: string;
  secondaryCta: string;
  servicesEyebrow: string;
  servicesTitle: string;
  services: Array<{ number: string; title: string; description: string }>;
  storyEyebrow: string;
  storyTitle: string;
  story: string[];
  disclosure: string;
  ethosEyebrow: string;
  ethosTitle: string;
  ethos: Array<{ title: string; description: string }>;
  toolsEyebrow: string;
  toolsTitle: string;
  toolsDescription: string;
  tools: Record<ToolKey, ToolCopy>;
  studioEyebrow: string;
  studioTitle: string;
  studioDescription: string;
  birthDate: string;
  birthTime: string;
  focus: string;
  focusPlaceholder: string;
  generate: string;
  regenerate: string;
  resultTitle: string;
  visualNote: string;
  prompts: string;
  privateCta: string;
  libraryCta: string;
  disclaimerTitle: string;
  disclaimer: string;
  footerLine: string;
  inputHint: string;
};

const englishTools: Record<ToolKey, ToolCopy> = {
  bazi: { title: "BaZi", subtitle: "Personal Innate Energy Blueprint", mark: "八", description: "A four-pillar study template for noticing rhythm, balance and personal reflection." },
  ziwei: { title: "Zi Wei", subtitle: "Celestial house study", mark: "紫", description: "A twelve-house visual for studying symbolic relationships and life themes." },
  qimen: { title: "Qi Men", subtitle: "Timing field map", mark: "奇", description: "A nine-palace observation board for reflecting on context and timing." },
  tarot: { title: "Tarot", subtitle: "Symbolic reflection", mark: "☽", description: "A three-card reflection spread for naming what is present, emerging and worth tending." },
  iching: { title: "I Ching", subtitle: "Six-line contemplation", mark: "☷", description: "A six-line visual prompt for holding a question with patience and nuance." },
  chart: { title: "Natal Chart", subtitle: "Celestial perspective", mark: "✦", description: "A twelve-sector study wheel for exploring recurring themes and personal orientation." },
};

const chineseTools: Record<ToolKey, ToolCopy> = {
  bazi: { title: "八字", subtitle: "先天能量蓝图解析", mark: "八", description: "以四柱研习模板，观察节律、平衡与个人觉知。" },
  ziwei: { title: "紫微", subtitle: "星曜宫位研习", mark: "紫", description: "用十二宫可视化图谱，理解象征关系与人生主题。" },
  qimen: { title: "奇门", subtitle: "时机场域观察", mark: "奇", description: "以九宫观察盘，帮助梳理当下情境与时机。" },
  tarot: { title: "塔罗牌", subtitle: "象征意象阅读", mark: "☽", description: "以三张牌的观察结构，命名当下、萌发与值得照看的部分。" },
  iching: { title: "六爻", subtitle: "六爻卦象观照", mark: "☷", description: "以六爻视觉提示，耐心而细致地安放一个问题。" },
  chart: { title: "星盘解析", subtitle: "星体视角研习", mark: "✦", description: "以十二宫学习圆盘，探索反复出现的主题与个人取向。" },
};

const traditionalTools: Record<ToolKey, ToolCopy> = {
  bazi: { title: "八字", subtitle: "先天能量藍圖解析", mark: "八", description: "以四柱研習模板，觀察節律、平衡與個人覺知。" },
  ziwei: { title: "紫微", subtitle: "星曜宮位研習", mark: "紫", description: "用十二宮視覺化圖譜，理解象徵關係與人生主題。" },
  qimen: { title: "奇門", subtitle: "時機場域觀察", mark: "奇", description: "以九宮觀察盤，協助梳理當下情境與時機。" },
  tarot: { title: "塔羅牌", subtitle: "象徵意象閱讀", mark: "☽", description: "以三張牌的觀察結構，命名當下、萌發與值得照看的部分。" },
  iching: { title: "六爻", subtitle: "六爻卦象觀照", mark: "☷", description: "以六爻視覺提示，耐心而細緻地安放一個問題。" },
  chart: { title: "星盤解析", subtitle: "星體視角研習", mark: "✦", description: "以十二宮學習圓盤，探索反覆出現的主題與個人取向。" },
};

const chineseServices = [
  { number: "01", title: "先天命盘研习", description: "按典籍规则排出八字、紫微等命盘，了解传统命理如何描述性格与人生节奏，作为自我观察的参考。" },
  { number: "02", title: "住宅方位文化", description: "以八宅与年飞星了解传统住宅方位的说法，作为布置居所时的文化参考，不承诺任何效果。" },
  { number: "03", title: "时序与择日文化", description: "了解节气、建除与宜忌等传统时间观，作为安排日常的文化参考。" },
];

const traditionalServices = [
  { number: "01", title: "先天命盤研習", description: "按典籍規則排出八字、紫微等命盤，了解傳統命理如何描述性格與人生節奏，作為自我觀察的參考。" },
  { number: "02", title: "住宅方位文化", description: "以八宅與年飛星了解傳統住宅方位的說法，作為布置居所時的文化參考，不承諾任何效果。" },
  { number: "03", title: "時序與擇日文化", description: "了解節氣、建除與宜忌等傳統時間觀，作為安排日常的文化參考。" },
];

const englishServices = [
  { number: "01", title: "Birth chart study", description: "Charts such as BaZi and Zi Wei calculated from classical rules, to learn how tradition describes character and life rhythm." },
  { number: "02", title: "House directions in tradition", description: "Learn the Eight Mansions and annual flying stars as a cultural reference for arranging a home, with no promised effect." },
  { number: "03", title: "Calendar and timing culture", description: "Learn solar terms, day officers and traditional favourable activities as a cultural reference for everyday planning." },
];

const japaneseTools: Record<ToolKey, ToolCopy> = {
  bazi: { title: "四柱", subtitle: "生まれ持つエネルギーの設計図", mark: "八", description: "四柱の学習テンプレートで、リズム、バランス、内省を見つめます。" },
  ziwei: { title: "紫微斗数", subtitle: "星と宮の学習", mark: "紫", description: "十二宮の可視化から、象徴的な関係と人生のテーマを学びます。" },
  qimen: { title: "奇門遁甲", subtitle: "時機の場の観察", mark: "奇", description: "九宮の観察盤で、状況と時機を静かに見つめます。" },
  tarot: { title: "タロット", subtitle: "象徴による内省", mark: "☽", description: "三枚のスプレッドで、今あるもの、芽生え、手入れしたいものを言葉にします。" },
  iching: { title: "易経", subtitle: "六爻の観照", mark: "☷", description: "六爻の視覚的な手がかりで、問いを丁寧に抱えます。" },
  chart: { title: "出生図", subtitle: "天体の視点", mark: "✦", description: "十二分区の学習ホイールで、繰り返すテーマと自分の方向性を見つめます。" },
};

const koreanTools: Record<ToolKey, ToolCopy> = {
  bazi: { title: "사주", subtitle: "타고난 에너지 설계도", mark: "八", description: "사주 학습 템플릿으로 리듬, 균형, 자기 성찰을 살펴봅니다." },
  ziwei: { title: "자미두수", subtitle: "별과 궁의 학습", mark: "紫", description: "십이궁 시각화로 상징적 관계와 삶의 주제를 공부합니다." },
  qimen: { title: "기문둔갑", subtitle: "시점의 장 관찰", mark: "奇", description: "구궁 관찰판으로 상황과 시점을 살펴봅니다." },
  tarot: { title: "타로", subtitle: "상징 성찰", mark: "☽", description: "세 장의 펼침으로 현재, 떠오르는 것, 돌볼 부분을 이름 붙입니다." },
  iching: { title: "주역", subtitle: "육효 관조", mark: "☷", description: "육효 시각 단서로 질문을 차분하고 섬세하게 바라봅니다." },
  chart: { title: "출생 차트", subtitle: "천체의 관점", mark: "✦", description: "열두 구역 학습 원판으로 반복되는 주제와 개인의 방향을 살핍니다." },
};

const vietnameseTools: Record<ToolKey, ToolCopy> = {
  bazi: { title: "Bát Tự", subtitle: "Bản đồ năng lượng bẩm sinh", mark: "八", description: "Mẫu Tứ Trụ giúp quan sát nhịp điệu, sự cân bằng và suy ngẫm cá nhân." },
  ziwei: { title: "Tử Vi", subtitle: "Nghiên cứu sao và cung", mark: "紫", description: "Biểu đồ mười hai cung giúp học về các mối liên hệ biểu tượng và chủ đề cuộc sống." },
  qimen: { title: "Kỳ Môn", subtitle: "Quan sát trường thời điểm", mark: "奇", description: "Bàn cửu cung giúp suy ngẫm về bối cảnh và thời điểm." },
  tarot: { title: "Tarot", subtitle: "Suy ngẫm biểu tượng", mark: "☽", description: "Trải bài ba lá giúp gọi tên điều đang hiện diện, đang mở ra và cần được chăm sóc." },
  iching: { title: "Kinh Dịch", subtitle: "Chiêm nghiệm sáu hào", mark: "☷", description: "Gợi ý trực quan sáu hào giúp giữ một câu hỏi với sự kiên nhẫn và tinh tế." },
  chart: { title: "Biểu đồ sao", subtitle: "Góc nhìn thiên thể", mark: "✦", description: "Vòng học tập mười hai khu vực giúp khám phá chủ đề lặp lại và định hướng cá nhân." },
};

const thaiTools: Record<ToolKey, ToolCopy> = {
  bazi: { title: "ปาจื้อ", subtitle: "แผนผังพลังงานโดยกำเนิด", mark: "八", description: "แม่แบบสี่เสาช่วยสังเกตจังหวะ ความสมดุล และการใคร่ครวญตนเอง" },
  ziwei: { title: "จื่อเวย", subtitle: "การศึกษาเรื่องดาวและเรือน", mark: "紫", description: "ภาพสิบสองเรือนช่วยศึกษาความสัมพันธ์เชิงสัญลักษณ์และประเด็นชีวิต" },
  qimen: { title: "ฉีเหมิน", subtitle: "การสังเกตสนามเวลา", mark: "奇", description: "กระดานเก้าวังช่วยใคร่ครวญบริบทและช่วงเวลา" },
  tarot: { title: "ไพ่ทาโรต์", subtitle: "การใคร่ครวญเชิงสัญลักษณ์", mark: "☽", description: "ไพ่สามใบช่วยเรียกชื่อสิ่งที่มีอยู่ สิ่งที่กำลังก่อตัว และสิ่งที่ควรดูแล" },
  iching: { title: "อี้จิง", subtitle: "การพิจารณาหกเส้น", mark: "☷", description: "ภาพชวนคิดหกเส้นช่วยให้ถือคำถามไว้ด้วยความอดทนและละเอียดอ่อน" },
  chart: { title: "แผนภาพดวงกำเนิด", subtitle: "มุมมองแห่งท้องฟ้า", mark: "✦", description: "วงล้อสิบสองส่วนช่วยสำรวจประเด็นที่เกิดซ้ำและทิศทางส่วนตัว" },
};

const japaneseServices = [
  { number: "01", title: "命式の学び", description: "古典の規則で四柱推命や紫微斗数の命式を作成し、伝統が性格や人生のリズムをどう描くかを学びます。" },
  { number: "02", title: "住まいの方位文化", description: "八宅と年の飛星から伝統的な住まいの方位の考え方を学び、文化的な参考にします。効果を約束するものではありません。" },
  { number: "03", title: "暦と日選びの文化", description: "節気・十二直・宜忌など伝統的な時間の考え方を、日々の予定づくりの参考として学びます。" },
];

const koreanServices = [
  { number: "01", title: "명반 학습", description: "고전 규칙으로 사주·자미두수 명반을 계산해 전통이 성격과 삶의 리듬을 어떻게 설명하는지 배웁니다." },
  { number: "02", title: "주거 방위 문화", description: "팔택과 연비성으로 전통적인 주거 방위 설명을 배우고 문화적 참고로 삼습니다. 효과를 약속하지 않습니다." },
  { number: "03", title: "역법과 택일 문화", description: "절기·건제·의기 등 전통 시간관을 일상 계획의 문화적 참고로 배웁니다." },
];

const vietnameseServices = [
  { number: "01", title: "Học lá số", description: "Lập lá số Bát Tự, Tử Vi theo quy tắc kinh điển để tìm hiểu cách truyền thống mô tả tính cách và nhịp sống." },
  { number: "02", title: "Văn hóa phương hướng nhà ở", description: "Tìm hiểu Bát Trạch và phi tinh năm như một tham khảo văn hóa khi bố trí nhà, không cam kết hiệu quả." },
  { number: "03", title: "Văn hóa lịch và chọn ngày", description: "Tìm hiểu tiết khí, trực và nên/kiêng như tham khảo văn hóa cho việc sắp xếp hằng ngày." },
];

const thaiServices = [
  { number: "01", title: "ศึกษาผังดวง", description: "คำนวณผังปาจื้อ จื่อเวย ตามกฎตำรา เพื่อเรียนรู้ว่าประเพณีอธิบายนิสัยและจังหวะชีวิตอย่างไร" },
  { number: "02", title: "วัฒนธรรมทิศบ้าน", description: "เรียนรู้แปดคฤหาสน์และดาวบินประจำปีเป็นข้อมูลทางวัฒนธรรมสำหรับการจัดบ้าน โดยไม่รับประกันผล" },
  { number: "03", title: "วัฒนธรรมปฏิทินและการเลือกวัน", description: "เรียนรู้สารท เจ้าหน้าที่ประจำวัน และสิ่งที่ควร/ไม่ควร เป็นข้อมูลทางวัฒนธรรมสำหรับการวางแผนประจำวัน" },
];

const rawSiteContent: Record<Locale, SiteCopy> = {
  en: {
    nav: { services: "Services", tools: "Study tools", philosophy: "Philosophy", library: "Wisdom library" }, language: "Language", join: "Membership",
    eyebrow: "Eastern cosmic energy studies · Worldwide", heroTitle: "Xuannova · Unlock the Primordial Eastern Cosmic Vital Force",
    slogan: "Align Yin-Yang energy flows, balance your soul with cosmic aura", altSlogan: "Ancient Eastern subtle wisdom, a global sanctuary for spiritual seekers",
    heroDescription: "A considered study space for people exploring classical East Asian cosmology, symbolic systems and mindful self-observation.",
    primaryCta: "Create a free chart", secondaryCta: "Explore Ancient Wisdom Library",
    servicesEyebrow: "Three paths of study", servicesTitle: "Ancient frameworks, held with a modern and thoughtful lens.", services: englishServices,
    storyEyebrow: "The institute", storyTitle: "A global sanctuary for original Eastern cosmic energy wisdom.",
    story: [
      "Xuannova is an international spiritual community dedicated to the timeless primordial energy wisdom of ancient East Asia.",
      "For thousands of years, Eastern sages perceived the invisible universal vital force — Qi, penetrating all existence in the cosmos. They summarized the universal laws of Yin-Yang circulation and Five Elements transformation, to interpret individual innate energy blueprint, environmental aura, and the cyclic shifts of life energy.",
      "We pass down this profound Eastern esoteric system to modern people worldwide: decode your personal energetic constitution and life aura cycles; harmonize the aura of your living and working space; and follow seasonal rhythms when considering pivotal life moments."
    ],
    disclosure: "All study materials are for metaphysical culture learning, spiritual tuning and wellness reference only. They are not a deterministic statement about anyone’s fate or future.",
    ethosEyebrow: "Four commitments", ethosTitle: "Study begins with attention — and returns agency to the individual.",
    ethos: [
      { title: "Inherit Origins", description: "Preserve authentic ancient Eastern cosmic energy philosophy." },
      { title: "Vibration Tuning", description: "Harmonize mind and body through reflective aura wisdom for modern life." },
      { title: "Global Inclusive", description: "Open to spiritual seekers worldwide, without regional boundaries." },
      { title: "Self Awakening", description: "Inspire inner awareness and awaken your inherent vital force." },
    ],
    toolsEyebrow: "Six study instruments", toolsTitle: "Make a study chart, then sit with what it invites you to notice.", toolsDescription: "Each instrument creates a deterministic visual template from the information you enter. It is designed for study and reflection, not prediction.", tools: englishTools,
    studioEyebrow: "Study workspace", studioTitle: "Create a private reflection chart.", studioDescription: "No account, payment or data upload is required. Your inputs remain in this browser session.",
    birthDate: "Date of birth", birthTime: "Time of birth", focus: "Reflection focus (optional)", focusPlaceholder: "For example: a decision, relationship or new beginning", generate: "Generate study chart", regenerate: "Create another view", resultTitle: "Your study visual", visualNote: "A symbolic, deterministic template for cultural study — not a prediction or diagnosis.", prompts: "Observation prompts", privateCta: "Book Private Aura Consultation", libraryCta: "Explore Ancient Wisdom Library",
    disclaimerTitle: "Disclaimer:", disclaimer: "All content on Xuannova is for traditional-culture learning and entertainment. It is not prediction, and it is not medical, legal, financial or psychological advice.", footerLine: "Eastern traditional culture · Learning in seven languages", inputHint: "Choose a tool, add a few details, and generate a visual for personal study."
  },
  "zh-Hans": {
    nav: { services: "核心服务", tools: "研习工具", philosophy: "本院理念", library: "知识库" }, language: "语言", join: "加入会员",
    eyebrow: "东方本源能量研习 · 面向全球", heroTitle: "Xuannova | 溯源东方亘古宇宙本源之力", slogan: "循阴阳气场流转，调和身心与天地能量", altSlogan: "沉睡千年东方灵韵，当代全球研习秘境",
    heroDescription: "面向全球的东方古老灵性智慧研习社群，以经典宇宙观、象征体系与内在觉察，陪伴你回到当下。", primaryCta: "免费排盘", secondaryCta: "浏览东方能量知识库",
    servicesEyebrow: "三大核心服务", servicesTitle: "以东方古老框架，安静地理解人与环境、节律之间的关系。", services: chineseServices,
    storyEyebrow: "Xuannova简介", storyTitle: "汇聚东方本源能量体系的全球研习社群。", story: [
      "Xuannova，汇聚传承数千年的东方本源能量体系，是面向全球的东方古老灵性智慧研习社群。",
      "自古以来，东方先贤洞悉天地间无处不在的无形生命气场（炁/Qi），归纳阴阳循环、五行运化、时序节律这套宇宙底层法则，以此解读人体内在能量禀赋、空间环境气场、人生阶段能量起伏规律。",
      "我们深耕这套独属于东方的神秘生命哲学：梳理个人先天能量蓝图，认清自身气场特质与能量周期；调和居家、办公空间能量场域；顺应天地时序能量流转，在人生重大抉择节点顺势而行。"
    ], disclosure: "本院所有内容均为东方传统形而上文化、宇宙能量哲学研习参考，侧重身心觉知、内在调频与生活状态优化；不存在宿命定论、神力干预、厄运化解等绝对功效，所有人生选择始终由个人主导。",
    ethosEyebrow: "四大核心理念", ethosTitle: "向内觉察，尊重选择，也让古老智慧在当代生活中保持清醒。", ethos: [
      { title: "承源", description: "恪守上古东方宇宙能量文脉，传承正统阴阳五行本源智慧。" }, { title: "调频", description: "以古老气场法则调和身心，适配现代高压生活节奏。" }, { title: "包容", description: "打破地域壁垒，面向全球所有追寻内在力量的修行者开放。" }, { title: "自知", description: "讲求向内觉察，不依附外力，唤醒自身本具生命能量。" }
    ],
    toolsEyebrow: "六种研习工具", toolsTitle: "生成一张研习盘面，再从中安静地观察当下。", toolsDescription: "各工具会依据你填写的信息生成确定性的视觉研习模板，仅用于文化学习与自我觉察，并非预测。", tools: chineseTools,
    studioEyebrow: "研习工作台", studioTitle: "创建一张私人的观察盘。", studioDescription: "无需账号、付费或上传资料；你的输入仅保留在当前浏览器会话中。", birthDate: "出生日期", birthTime: "出生时间", focus: "想观察的主题（选填）", focusPlaceholder: "例如：一个决定、一段关系或新的开始", generate: "生成研习盘", regenerate: "再生成一张", resultTitle: "你的研习盘面", visualNote: "这是供文化研习使用的象征性固定模板，并非命运预测或诊断。", prompts: "观察提示", privateCta: "预约一对一气场解读", libraryCta: "浏览东方能量知识库",
    disclaimerTitle: "温馨提示：", disclaimer: "Xuannova 全部内容仅供东方传统文化学习与娱乐参考，不构成预测，也不构成医疗、法律、财务或心理建议。", footerLine: "东方传统文化 · 七种语言研习", inputHint: "选择工具，填写少量信息，即可生成一张仅供个人研习的盘面。"
  },
  "zh-Hant": {
    nav: { services: "核心服務", tools: "研習工具", philosophy: "本院理念", library: "知識庫" }, language: "語言", join: "加入會員", eyebrow: "東方本源能量研習 · 面向全球", heroTitle: "Xuannova｜溯源東方亙古宇宙本源之力", slogan: "循陰陽氣場流轉，調和身心與天地能量", altSlogan: "沉睡千年東方靈韻，當代全球研習秘境", heroDescription: "面向全球的東方古老靈性智慧研習社群，以經典宇宙觀、象徵系統與內在覺察，陪伴你回到當下。", primaryCta: "免費排盤", secondaryCta: "瀏覽東方能量知識庫", servicesEyebrow: "三大核心服務", servicesTitle: "以東方古老框架，安靜地理解人、環境與節律的關係。", services: traditionalServices,
    storyEyebrow: "Xuannova簡介", storyTitle: "匯聚東方本源能量系統的全球研習社群。", story: ["Xuannova，匯聚傳承數千年的東方本源能量系統，是面向全球的東方古老靈性智慧研習社群。", "東方先賢以陰陽循環、五行運化與時序節律理解宇宙中的生命氣場（炁／Qi），並以此觀察個人、環境與人生階段的能量變化。", "我們以清醒、開放的方式研習這套哲學：梳理個人先天能量藍圖、調和空間感受，並在重要選擇前觀察天地時序。"], disclosure: "本院全部內容均為東方傳統形而上文化、宇宙能量哲學研習參考，側重身心覺知、內在調頻與生活狀態優化；不存在宿命定論、神力干預或絕對功效，所有人生選擇始終由個人主導。", ethosEyebrow: "四大核心理念", ethosTitle: "向內覺察，尊重選擇，讓古老智慧在當代生活中保持清醒。", ethos: [{ title: "承源", description: "傳承正統陰陽五行本源智慧。" }, { title: "調頻", description: "以古老氣場法則調和身心。" }, { title: "包容", description: "面向全球所有追尋內在力量的研習者。" }, { title: "自知", description: "不依附外力，喚醒自身本具生命能量。" }], toolsEyebrow: "六種研習工具", toolsTitle: "生成一張研習盤面，再從中安靜地觀察當下。", toolsDescription: "各工具會依據你填寫的資訊生成固定的視覺研習模板，只供文化學習與自我覺察，並非預測。", tools: traditionalTools,
    studioEyebrow: "研習工作台", studioTitle: "建立一張私人的觀察盤。", studioDescription: "無需帳號、付費或上傳資料；你的輸入只保留於目前瀏覽器工作階段。", birthDate: "出生日期", birthTime: "出生時間", focus: "想觀察的主題（選填）", focusPlaceholder: "例如：一個決定、一段關係或新的開始", generate: "生成研習盤", regenerate: "再生成一張", resultTitle: "你的研習盤面", visualNote: "這是供文化研習使用的象徵性固定模板，並非命運預測或診斷。", prompts: "觀察提示", privateCta: "預約一對一氣場解讀", libraryCta: "瀏覽東方能量知識庫", disclaimerTitle: "溫馨提示：", disclaimer: "Xuannova 全部內容僅供東方傳統文化學習與娛樂參考，不構成預測，也不構成醫療、法律、財務或心理建議。", footerLine: "東方傳統文化 · 七種語言研習", inputHint: "選擇工具、填寫少量資訊，即可生成一張僅供個人研習的盤面。"
  },
  ja: {
    nav: { services: "学びの領域", tools: "学習ツール", philosophy: "理念", library: "知識庫" }, language: "言語", join: "メンバーシップ", eyebrow: "東洋宇宙エネルギーの学び · 世界へ", heroTitle: "Xuannova｜東洋の根源的な宇宙の力をたどる", slogan: "陰陽の流れとともに、心身と天地の調和を見つめる", altSlogan: "千年を越える東洋の知恵、世界の探求者のための静かな場", heroDescription: "古典的な東アジアの宇宙観、象徴体系、内省を学ぶためのグローバルなコミュニティです。", primaryCta: "無料で命式を作成", secondaryCta: "東洋の知恵の知識庫へ", servicesEyebrow: "三つの学び", servicesTitle: "古い枠組みを、現代の静かなまなざしで。", services: japaneseServices, storyEyebrow: "Xuannovaについて", storyTitle: "東洋の宇宙エネルギーの知恵を学ぶ、世界に開かれた場。", story: ["Xuannovaは、古代東アジアの根源的なエネルギーの知恵を学ぶ国際的なスピリチュアル・コミュニティです。", "陰陽、五行、季節のリズムを、自己と環境を丁寧に観察するための文化的なレンズとして紹介します。"], disclosure: "掲載内容は伝統文化・精神性・心身の気づきに関する学習資料であり、運命の予言や確実な効果を約束するものではありません。", ethosEyebrow: "四つの約束", ethosTitle: "内なる気づきを大切にし、人生の選択を本人に返す。", ethos: [{ title: "源を継ぐ", description: "東洋の宇宙哲学を丁寧に受け継ぐ。" }, { title: "調律", description: "現代生活のなかで心身を見つめる。" }, { title: "世界に開く", description: "境界を越えて探求者を迎える。" }, { title: "自己覚醒", description: "外部に頼らず内なる力に気づく。" }], toolsEyebrow: "六つの学習ツール", toolsTitle: "学習チャートを作り、今の自分を観察する。", toolsDescription: "入力内容から一定の視覚テンプレートを作ります。文化学習と内省のためのもので、予測ではありません。", tools: japaneseTools, studioEyebrow: "学習ワークスペース", studioTitle: "個人の観察チャートを作成。", studioDescription: "アカウント、支払い、データ送信は不要です。入力はこのブラウザのセッション内にのみ残ります。", birthDate: "生年月日", birthTime: "出生時刻", focus: "考えたいテーマ（任意）", focusPlaceholder: "例：決断、関係、新しい始まり", generate: "学習チャートを作成", regenerate: "別の表示を作る", resultTitle: "あなたの学習ビジュアル", visualNote: "文化学習用の象徴的なテンプレートであり、予言や診断ではありません。", prompts: "観察のヒント", privateCta: "個別オーラ相談を予約", libraryCta: "東洋の知恵の知識庫へ", disclaimerTitle: "免責事項：", disclaimer: "Xuannova のすべての内容は伝統文化の学習と娯楽のための参考です。予言ではなく、医療・法律・金融・心理の助言でもありません。", footerLine: "東洋の伝統文化 · 7言語で学ぶ", inputHint: "ツールを選び、少し情報を入力すると、個人学習用のチャートが作成されます。"
  },
  ko: {
    nav: { services: "핵심 분야", tools: "학습 도구", philosophy: "철학", library: "지혜 도서관" }, language: "언어", join: "멤버십", eyebrow: "동양 우주 에너지 연구 · 세계를 향해", heroTitle: "Xuannova｜동양 태고의 우주 근원 에너지를 탐구하다", slogan: "음양의 흐름을 따라 몸과 마음, 우주의 조화를 바라봅니다", altSlogan: "천년의 동양 지혜, 세계 탐구자를 위한 고요한 공간", heroDescription: "고전 동아시아 우주론과 상징 체계, 내면 관찰을 함께 공부하는 글로벌 커뮤니티입니다.", primaryCta: "무료로 명반 만들기", secondaryCta: "동양 지혜 도서관 둘러보기", servicesEyebrow: "세 가지 학습 영역", servicesTitle: "오래된 틀을 현대의 사려 깊은 시선으로 탐구합니다.", services: koreanServices, storyEyebrow: "Xuannova 소개", storyTitle: "동양 우주 에너지 지혜를 배우는 열린 세계 공동체.", story: ["Xuannova은 고대 동아시아의 근원 에너지 지혜를 배우는 국제적 영성 커뮤니티입니다.", "음양, 오행, 계절의 리듬을 자신과 환경을 섬세하게 관찰하는 문화적 렌즈로 소개합니다."], disclosure: "모든 자료는 전통 문화와 영성, 정서적 웰빙을 위한 학습 참고용이며 운명 예측이나 확정적 효능을 제공하지 않습니다.", ethosEyebrow: "네 가지 약속", ethosTitle: "내면의 알아차림을 존중하고, 삶의 선택권을 개인에게 돌려드립니다.", ethos: [{ title: "근원을 잇다", description: "동양 우주 철학을 정성스럽게 계승합니다." }, { title: "조율", description: "현대 생활 속 몸과 마음을 살핍니다." }, { title: "열린 세계", description: "국경을 넘어 모든 탐구자를 환영합니다." }, { title: "자기 각성", description: "외부에 의지하지 않고 내재된 힘을 발견합니다." }], toolsEyebrow: "여섯 가지 학습 도구", toolsTitle: "학습 차트를 만들고 현재의 나를 관찰하세요.", toolsDescription: "입력한 정보로 일정한 시각 템플릿을 만듭니다. 문화 학습과 성찰을 위한 것이며 예측이 아닙니다.", tools: koreanTools, studioEyebrow: "학습 공간", studioTitle: "개인 관찰 차트 만들기.", studioDescription: "계정, 결제, 데이터 업로드가 필요 없습니다. 입력은 현재 브라우저 세션에만 남습니다.", birthDate: "생년월일", birthTime: "출생 시각", focus: "살펴볼 주제 (선택)", focusPlaceholder: "예: 결정, 관계, 새로운 시작", generate: "학습 차트 만들기", regenerate: "다른 보기 만들기", resultTitle: "나의 학습 비주얼", visualNote: "문화 학습을 위한 상징적 템플릿이며 예측이나 진단이 아닙니다.", prompts: "관찰 질문", privateCta: "개인 오라 상담 예약", libraryCta: "동양 지혜 도서관 둘러보기", disclaimerTitle: "면책 고지:", disclaimer: "Xuannova의 모든 콘텐츠는 전통문화 학습과 오락을 위한 참고용입니다. 예언이 아니며 의료·법률·금융·심리 조언도 아닙니다.", footerLine: "동양 전통문화 · 7개 언어로 배우기", inputHint: "도구를 선택하고 몇 가지 정보를 입력하면 개인 학습용 차트가 생성됩니다."
  },
  vi: {
    nav: { services: "Lĩnh vực học", tools: "Công cụ", philosophy: "Triết lý", library: "Thư viện tri thức" }, language: "Ngôn ngữ", join: "Thành viên", eyebrow: "Nghiên cứu năng lượng vũ trụ phương Đông · Toàn cầu", heroTitle: "Xuannova · Khám phá nguồn năng lượng vũ trụ cổ xưa của phương Đông", slogan: "Đi cùng dòng chảy Âm-Dương, tìm sự cân bằng giữa tâm hồn và vũ trụ", altSlogan: "Trí tuệ phương Đông ngàn năm, không gian cho người tìm kiếm trên toàn thế giới", heroDescription: "Cộng đồng toàn cầu để học về vũ trụ quan Đông Á cổ điển, hệ biểu tượng và sự quan sát nội tâm.", primaryCta: "Lập lá số miễn phí", secondaryCta: "Khám phá thư viện tri thức Đông phương", servicesEyebrow: "Ba hướng học", servicesTitle: "Những khuôn khổ cổ xưa, được tiếp cận bằng góc nhìn hiện đại và sâu sắc.", services: vietnameseServices, storyEyebrow: "Về Xuannova", storyTitle: "Không gian toàn cầu dành cho tri thức năng lượng vũ trụ phương Đông.", story: ["Xuannova là cộng đồng quốc tế dành cho việc nghiên cứu trí tuệ năng lượng nguyên bản của Đông Á cổ đại.", "Âm-Dương, Ngũ Hành và nhịp điệu mùa được giới thiệu như một lăng kính văn hóa để quan sát bản thân và môi trường."], disclosure: "Mọi nội dung chỉ phục vụ nghiên cứu văn hóa truyền thống, học tập tâm linh và tham khảo về sự cân bằng cảm xúc; không phải dự đoán số mệnh hay cam kết kết quả.", ethosEyebrow: "Bốn cam kết", ethosTitle: "Bắt đầu bằng sự chú ý, và trao quyền lựa chọn trở về mỗi cá nhân.", ethos: [{ title: "Gìn giữ cội nguồn", description: "Trân trọng triết lý vũ trụ phương Đông cổ xưa." }, { title: "Điều hòa", description: "Quan sát tâm và thân trong đời sống hiện đại." }, { title: "Mở rộng toàn cầu", description: "Chào đón người tìm hiểu từ mọi nơi." }, { title: "Tự nhận biết", description: "Khơi gợi nhận thức và sức sống bên trong." }], toolsEyebrow: "Sáu công cụ học tập", toolsTitle: "Tạo biểu đồ học tập, rồi lắng nghe điều nó gợi bạn quan sát.", toolsDescription: "Mỗi công cụ tạo một mẫu trực quan cố định từ thông tin bạn nhập. Dành cho học tập và suy ngẫm, không phải dự đoán.", tools: vietnameseTools, studioEyebrow: "Không gian học", studioTitle: "Tạo biểu đồ suy ngẫm riêng tư.", studioDescription: "Không cần tài khoản, thanh toán hay tải dữ liệu lên. Thông tin của bạn chỉ ở trong phiên trình duyệt này.", birthDate: "Ngày sinh", birthTime: "Giờ sinh", focus: "Chủ đề suy ngẫm (không bắt buộc)", focusPlaceholder: "Ví dụ: một quyết định, mối quan hệ hoặc khởi đầu mới", generate: "Tạo biểu đồ học tập", regenerate: "Tạo góc nhìn khác", resultTitle: "Biểu đồ học tập của bạn", visualNote: "Mẫu biểu tượng cố định cho việc học văn hóa — không phải dự đoán hay chẩn đoán.", prompts: "Gợi ý quan sát", privateCta: "Đặt lịch tư vấn hào quang riêng", libraryCta: "Khám phá thư viện tri thức Đông phương", disclaimerTitle: "Tuyên bố miễn trừ:", disclaimer: "Toàn bộ nội dung trên Xuannova dùng để học hỏi văn hóa truyền thống và giải trí. Đây không phải dự đoán, cũng không phải tư vấn y tế, pháp lý, tài chính hay tâm lý.", footerLine: "Văn hóa truyền thống phương Đông · Học bằng 7 ngôn ngữ", inputHint: "Chọn công cụ, nhập vài thông tin và tạo biểu đồ để tự học."
  },
  th: {
    nav: { services: "แนวทางศึกษา", tools: "เครื่องมือ", philosophy: "แนวคิด", library: "คลังความรู้" }, language: "ภาษา", join: "สมาชิก", eyebrow: "การศึกษาเรื่องพลังจักรวาลตะวันออก · เพื่อผู้คนทั่วโลก", heroTitle: "Xuannova · ค้นหารากพลังจักรวาลดั้งเดิมแห่งตะวันออก", slogan: "ตามการไหลเวียนของหยินหยาง เพื่อมองหาสมดุลของกายใจและจักรวาล", altSlogan: "ภูมิปัญญาตะวันออกนับพันปี พื้นที่สงบสำหรับผู้แสวงหาทั่วโลก", heroDescription: "ชุมชนระดับโลกสำหรับเรียนรู้จักรวาลวิทยาเอเชียตะวันออก ระบบสัญลักษณ์ และการสังเกตภายในตนเอง.", primaryCta: "สร้างผังดวงฟรี", secondaryCta: "สำรวจคลังปัญญาตะวันออก", servicesEyebrow: "สามแนวทางการเรียนรู้", servicesTitle: "กรอบคิดโบราณ มองผ่านสายตาที่รอบคอบของคนร่วมสมัย.", services: thaiServices, storyEyebrow: "เกี่ยวกับXuannova", storyTitle: "พื้นที่เปิดกว้างระดับโลกสำหรับภูมิปัญญาพลังจักรวาลตะวันออก.", story: ["Xuannovaคือชุมชนทางจิตวิญญาณนานาชาติที่อุทิศให้แก่ภูมิปัญญาพลังงานดั้งเดิมของเอเชียตะวันออกโบราณ.", "เรานำเสนอหยินหยาง ธาตุทั้งห้า และจังหวะฤดูกาลในฐานะเลนส์ทางวัฒนธรรมเพื่อสังเกตตนเองและสภาพแวดล้อมอย่างละเอียด."], disclosure: "เนื้อหาทั้งหมดมีไว้เพื่อการศึกษาวัฒนธรรมดั้งเดิม การเรียนรู้ทางจิตวิญญาณ และการอ้างอิงด้านสมดุลทางอารมณ์เท่านั้น ไม่ใช่การทำนายชะตาหรือการรับประกันผลลัพธ์.", ethosEyebrow: "สี่คำมั่น", ethosTitle: "เริ่มจากการใส่ใจ และคืนอำนาจการเลือกให้กับแต่ละคน.", ethos: [{ title: "สืบสานต้นกำเนิด", description: "เคารพปรัชญาจักรวาลตะวันออกโบราณ." }, { title: "ปรับสมดุล", description: "สังเกตใจและกายในชีวิตสมัยใหม่." }, { title: "เปิดกว้างสู่โลก", description: "ต้อนรับผู้แสวงหาจากทุกแห่ง." }, { title: "ตื่นรู้ภายใน", description: "ชวนให้ค้นพบพลังชีวิตที่มีอยู่ภายใน." }], toolsEyebrow: "หกเครื่องมือการเรียนรู้", toolsTitle: "สร้างแผนภาพการเรียนรู้บนเครื่อง แล้วใช้มันสังเกตช่วงเวลาปัจจุบัน.", toolsDescription: "แต่ละเครื่องมือสร้างแม่แบบภาพแบบคงที่จากข้อมูลที่คุณกรอก เพื่อการเรียนรู้และการใคร่ครวญ ไม่ใช่การทำนาย.", tools: thaiTools, studioEyebrow: "พื้นที่เรียนรู้บนเครื่อง", studioTitle: "สร้างแผนภาพสังเกตตนเองแบบส่วนตัว.", studioDescription: "ไม่ต้องมีบัญชี การชำระเงิน หรือการอัปโหลดข้อมูล ข้อมูลของคุณอยู่เฉพาะในเซสชันเบราว์เซอร์นี้.", birthDate: "วันเกิด", birthTime: "เวลาเกิด", focus: "หัวข้อที่อยากใคร่ครวญ (ไม่บังคับ)", focusPlaceholder: "เช่น การตัดสินใจ ความสัมพันธ์ หรือการเริ่มต้นใหม่", generate: "สร้างแผนภาพการเรียนรู้", regenerate: "สร้างมุมมองใหม่", resultTitle: "ภาพการเรียนรู้ของคุณ", visualNote: "แม่แบบเชิงสัญลักษณ์เพื่อการเรียนรู้ทางวัฒนธรรม ไม่ใช่การทำนายหรือการวินิจฉัย.", prompts: "คำถามชวนสังเกต", privateCta: "นัดปรึกษาออร่าส่วนตัว", libraryCta: "สำรวจคลังปัญญาตะวันออก", disclaimerTitle: "ข้อสงวนสิทธิ์:", disclaimer: "เนื้อหาทั้งหมดของ Xuannova มีไว้เพื่อการเรียนรู้วัฒนธรรมดั้งเดิมและความบันเทิง ไม่ใช่คำทำนาย และไม่ใช่คำแนะนำทางการแพทย์ กฎหมาย การเงิน หรือจิตวิทยา", footerLine: "วัฒนธรรมดั้งเดิมตะวันออก · เรียนรู้ได้ 7 ภาษา", inputHint: "เลือกเครื่องมือ กรอกข้อมูลเล็กน้อย แล้วสร้างแผนภาพบนเครื่องเพื่อการเรียนรู้ส่วนตัว."
  }
};

const displayedTerminology: Record<Locale, Array<[string, string]>> = {
  en: [["symbolic systems", "classical frameworks"], ["symbolic patterns", "chart patterns"], ["symbolic observation", "chart observation"], ["symbolic placement", "star-and-palace placement"], ["symbolic relationships", "star-and-palace relationships"], ["Symbolic reflection", "Card reflection"], ["A symbolic, deterministic template", "A deterministic visual template"]],
  "zh-Hans": [["象征体系", "经典体系"], ["象征性固定模板", "固定视觉模板"], ["象征关系", "星曜宫位关系"], ["象征意象", "牌面意象"]],
  "zh-Hant": [["象徵系統", "經典體系"], ["象徵性固定模板", "固定視覺模板"], ["象徵關係", "星曜宮位關係"], ["象徵意象", "牌面意象"]],
  ja: [["象徴体系", "古典体系"], ["象徴的なテンプレート", "固定の視覚テンプレート"], ["象徴的な関係", "星と宮の関係"], ["象徴による内省", "カードによる内省"]],
  ko: [["상징 체계", "고전 체계"], ["상징적 템플릿", "고정 시각 템플릿"], ["상징적 관계", "별과 궁의 관계"], ["상징 성찰", "카드 성찰"]],
  vi: [["hệ biểu tượng", "hệ cổ điển"], ["Mẫu biểu tượng cố định", "Mẫu trực quan cố định"], ["mối liên hệ biểu tượng", "mối liên hệ sao-cung"], ["Suy ngẫm biểu tượng", "Suy ngẫm bằng lá bài"]],
  th: [["ระบบสัญลักษณ์", "ระบบดั้งเดิม"], ["แม่แบบเชิงสัญลักษณ์", "แม่แบบภาพแบบคงที่"], ["ความสัมพันธ์เชิงสัญลักษณ์", "ความสัมพันธ์ของดาวและวัง"], ["การใคร่ครวญเชิงสัญลักษณ์", "การใคร่ครวญด้วยไพ่"]],
};

function cleanDisplayedCopy<T>(value: T, locale: Locale): T {
  if (typeof value === "string") return displayedTerminology[locale].reduce<string>((text, [from, to]) => text.replaceAll(from, to), value) as T;
  if (Array.isArray(value)) return value.map((entry) => cleanDisplayedCopy(entry, locale)) as T;
  if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).map(([key, entry]) => [key, cleanDisplayedCopy(entry, locale)])) as T;
  return value;
}

export const siteContent: Record<Locale, SiteCopy> = Object.fromEntries(
  (Object.entries(rawSiteContent) as Array<[Locale, SiteCopy]>).map(([locale, content]) => [locale, cleanDisplayedCopy(content, locale)]),
) as Record<Locale, SiteCopy>;
