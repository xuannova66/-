import type { InterpretationResponse } from "./chart-model";
import type { Locale } from "./site-content";

/** Neutral fallbacks for missing/duplicate provider suggestions; never assert a prediction. */
const fallback: Record<Locale, string[]> = {
  en: ["Which details support this reading, and where are its limits?", "What other perspective could help me understand this situation?", "What small step could I try and review in daily life?", "How could I communicate more clearly with the people involved?", "How could I clarify my priorities before making a choice?", "What additional context would make a follow-up more useful?"],
  "zh-Hans": ["这份解读有哪些依据，又有哪些局限？", "还有哪些不同角度能帮助我理解当前情况？", "我可以在日常中尝试并复盘哪一个小行动？", "我怎样与相关的人沟通得更清楚？", "做选择前，我可以怎样梳理自己的优先事项？", "补充哪些信息能让下一次提问更具体？"],
  "zh-Hant": ["這份解讀有哪些依據，又有哪些局限？", "還有哪些不同角度能幫助我理解目前情況？", "我可以在日常中嘗試並回顧哪一個小行動？", "我怎樣與相關的人溝通得更清楚？", "做選擇前，我可以怎樣梳理自己的優先事項？", "補充哪些資訊能讓下一次提問更具體？"],
  ja: ["この解説の根拠と限界は何ですか？", "今の状況を理解するために、ほかにどんな視点がありますか？", "日常で試して振り返れる小さな行動は何ですか？", "関係する人に、より分かりやすく伝えるにはどうすればよいですか？", "選択する前に、自分の優先順位をどう整理できますか？", "次の質問を具体的にするには、どんな情報を補えばよいですか？"],
  ko: ["이 해석의 근거와 한계는 무엇인가요?", "현재 상황을 이해하는 데 도움이 될 다른 관점은 무엇인가요?", "일상에서 시도하고 돌아볼 작은 행동은 무엇인가요?", "관련된 사람들과 더 명확하게 소통하려면 어떻게 해야 하나요?", "선택 전에 제 우선순위를 어떻게 정리할 수 있나요?", "다음 질문을 더 구체적으로 하려면 어떤 정보를 보태야 하나요?"],
  vi: ["Cơ sở và giới hạn của bài luận giải này là gì?", "Góc nhìn nào khác có thể giúp tôi hiểu tình huống hiện tại?", "Tôi có thể thử và nhìn lại hành động nhỏ nào trong đời sống?", "Tôi có thể giao tiếp rõ ràng hơn với những người liên quan như thế nào?", "Tôi nên làm rõ các ưu tiên của mình thế nào trước khi lựa chọn?", "Thông tin nào sẽ giúp câu hỏi tiếp theo cụ thể hơn?"],
  th: ["คำอธิบายนี้มีพื้นฐานและข้อจำกัดอะไรบ้าง", "มีมุมมองอื่นใดที่ช่วยให้เข้าใจสถานการณ์นี้ได้บ้าง", "มีการกระทำเล็ก ๆ อะไรที่ลองทำและทบทวนในชีวิตประจำวันได้", "จะสื่อสารกับผู้เกี่ยวข้องให้ชัดเจนขึ้นได้อย่างไร", "ก่อนตัดสินใจจะจัดลำดับความสำคัญของตัวเองอย่างไร", "ควรให้ข้อมูลอะไรเพิ่มเพื่อให้คำถามต่อไปชัดเจนขึ้น"],
};

function questionKey(value: string) {
  return value.normalize("NFKC").toLowerCase().replace(/[\p{P}\p{Z}\s]/gu, "");
}

/** Keep model-specific questions first; fill gaps without another paid provider call. */
export function selectFollowUps(items: readonly unknown[], context: { locale: string; question?: string; previousQuestions?: readonly string[] }) {
  const locale = Object.hasOwn(fallback, context.locale) ? context.locale as Locale : "en";
  const used = new Set([context.question ?? "", ...(context.previousQuestions ?? []).slice(-10)].map(questionKey));
  const questions: string[] = [];
  for (const item of [...items.slice(0, 12), ...fallback[locale]]) {
    if (typeof item !== "string") continue;
    const question = item.trim();
    if (!question || question.length > 220 || !/\p{L}/u.test(question)) continue;
    const key = questionKey(question);
    if (used.has(key)) continue;
    questions.push(question);
    used.add(key);
    if (questions.length === 3) break;
  }
  // If all safe fallback topics were asked, return fewer rather than repeat them.
  return questions;
}

export type ReadingTurn = { question: string; answer: string };
export type FollowUpContext = { chartFingerprint: string; draftId?: string; turns: ReadingTurn[] };
type ContextDraft = { chartFingerprint: string; draftId: string; question: string; unlocked: boolean; full?: InterpretationResponse };

/** Include every section's outline, not just the first 2,400 characters of a long report. */
export function summarizeReading(reading: InterpretationResponse) {
  return [reading.conclusion?.slice(0, 300), reading.summary.slice(0, 400),
    ...(reading.keyPoints ?? []).slice(0, 3).map((point) => point.slice(0, 100)),
    ...reading.sections.slice(0, 10).map((section) => `${section.title.slice(0, 60)}: ${section.text.slice(0, 100)}`),
  ].filter(Boolean).join("\n").slice(0, 2400);
}

/** Only an unlocked report from this chart may seed the conversation. Never send locked content. */
export function followUpHistory(chartFingerprint: string, context: FollowUpContext, draft: ContextDraft | null): ReadingTurn[] {
  const current = draft?.chartFingerprint === chartFingerprint && draft.unlocked && draft.full ? draft : null;
  const sameContext = context.chartFingerprint === chartFingerprint && context.draftId === current?.draftId;
  if (sameContext && context.turns.length) return context.turns.slice(-10);
  if (!current?.full) return [];
  return [{ question: current.question, answer: summarizeReading(current.full) }];
}
