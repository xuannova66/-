"use client";
// Tap-to-explain for chart labels. A term with an explanation gets a dotted underline; tapping it
// opens a small panel (fixed to the viewport so table cells and scroll areas never clip it).
import { useEffect, useRef, useState, type ReactNode } from "react";
import type { Locale } from "./site-content";
import { chartTermTip } from "./chart-terms";
import { shortGloss } from "./glossary";
import { useReadingMode } from "./reading-mode";

const OPEN_EVENT = "xn:chart-term-open";
let nextId = 0;

/** `tip` overrides the chart-label lookup (used for terms inside reading text); `gloss` is the short plain note shown in 普通版. */
export function ChartTerm({ raw, locale, children, tip: givenTip, gloss }: { raw: string; locale: Locale; children: ReactNode; tip?: string; gloss?: string | null }) {
  const tip = givenTip ?? chartTermTip(raw, locale);
  const mode = useReadingMode();
  const note = mode === "beginner" ? (gloss === undefined ? shortGloss(raw, locale) : gloss) : null;
  const [place, setPlace] = useState<{ left: number; top: number; above: boolean } | null>(null);
  const button = useRef<HTMLButtonElement>(null);
  const id = useRef(0);
  if (id.current === 0) { nextId += 1; id.current = nextId; }
  useEffect(() => {
    if (!place) return;
    const close = () => setPlace(null);
    const onOther = (event: Event) => { if ((event as CustomEvent<number>).detail !== id.current) close(); };
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") close(); };
    const onDown = (event: PointerEvent) => { if (!(event.target instanceof Node) || !button.current?.parentElement?.contains(event.target)) close(); };
    window.addEventListener(OPEN_EVENT, onOther);
    window.addEventListener("scroll", close, true);
    window.addEventListener("resize", close);
    window.addEventListener("keydown", onKey);
    window.addEventListener("pointerdown", onDown);
    return () => {
      window.removeEventListener(OPEN_EVENT, onOther);
      window.removeEventListener("scroll", close, true);
      window.removeEventListener("resize", close);
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("pointerdown", onDown);
    };
  }, [place]);
  if (!tip) return <>{children}{note && <small className="term-gloss">{note}</small>}</>;
  const toggle = (event: React.MouseEvent) => {
    event.preventDefault(); event.stopPropagation();
    if (place) { setPlace(null); return; }
    const rect = button.current?.getBoundingClientRect();
    if (!rect) return;
    const width = Math.min(300, window.innerWidth - 24);
    const left = Math.max(12, Math.min(rect.left, window.innerWidth - width - 12));
    const above = rect.bottom + 180 > window.innerHeight && rect.top > 200;
    setPlace({ left, top: above ? rect.top - 8 : rect.bottom + 8, above });
    window.dispatchEvent(new CustomEvent(OPEN_EVENT, { detail: id.current }));
  };
  return <span className="chart-term-wrap">
    <button ref={button} type="button" className="chart-term" aria-expanded={Boolean(place)} onClick={toggle}>{children}</button>
    {note && <small className="term-gloss">{note}</small>}
    {place && <span className={`chart-term-tip ${place.above ? "above" : ""}`} role="tooltip" style={{ left: place.left, top: place.top }}>
      <b>{children}</b>{tip}
    </span>}
  </span>;
}
