// Home hero backdrop for the dark themes: four scenes that take turns, cross-fading.
//   0 经典 the original home background (photo + starry SVG sky underneath); the canvas stays clear, only the ring and dust move
//   1 墨山 ink mountains — ink-black sky, layered ink ridges in mist, a pale moon, mist drifting, cranes now and then
//   2 深空 deep space   — midnight-blue sky, a milky way band, nebula glow, twinkling stars, the Northern Dipper, meteors
//   3 流金 flowing gold — champagne-gold silk ribbons of light over gold-rimmed ridges, rising gold dust
// The heavy parts (sky, ridges, milky way) are painted once per size into offscreen canvases; each frame only blits
// them and draws the small moving things, so it stays light on phones. Scenes 1 and 2 are painted on idle time,
// after the first one is already showing, so the first screen is never held up.

export type HeroEngine = { show: (scene: number) => void; destroy: () => void };
type Canvas2D = CanvasRenderingContext2D;

export const SCENE_COUNT = 4;
export const SCENE_SECONDS = 11;
const FADE_SECONDS = 2.2;
const GOLD = "#d9b876";

function seeded(seed: number) {
  let s = seed >>> 0;
  return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
}

/** A ridge line made by midpoint displacement: jagged like brushwork, smoothed a little. */
function ridge(width: number, base: number, height: number, rough: number, rand: () => number) {
  const n = 129;
  const ys = new Array<number>(n).fill(0);
  ys[0] = rand(); ys[n - 1] = rand();
  for (let step = n - 1, amp = 1; step > 1; step >>= 1, amp *= rough) {
    for (let i = step >> 1; i < n; i += step) ys[i] = (ys[i - (step >> 1)] + ys[i + (step >> 1)]) / 2 + (rand() - 0.5) * amp;
  }
  const min = Math.min(...ys), max = Math.max(...ys);
  return ys.map((v, i) => ({ x: (i / (n - 1)) * width, y: base - ((v - min) / (max - min || 1)) * height }));
}

function fillRidge(ctx: Canvas2D, pts: Array<{ x: number; y: number }>, bottom: number, top: string, foot: string, rim?: string) {
  const peak = Math.min(...pts.map((p) => p.y));
  const g = ctx.createLinearGradient(0, peak, 0, bottom);
  g.addColorStop(0, top); g.addColorStop(1, foot);
  ctx.beginPath(); ctx.moveTo(pts[0].x, bottom);
  for (const p of pts) ctx.lineTo(p.x, p.y);
  ctx.lineTo(pts[pts.length - 1].x, bottom); ctx.closePath();
  ctx.fillStyle = g; ctx.fill();
  if (rim) {
    ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.strokeStyle = rim; ctx.lineWidth = 1.1; ctx.stroke();
  }
}

function glow(ctx: Canvas2D, x: number, y: number, r: number, color: string, alpha: number) {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, `rgba(${color},${alpha})`); g.addColorStop(1, `rgba(${color},0)`);
  ctx.fillStyle = g; ctx.fillRect(x - r, y - r, r * 2, r * 2);
}

/** Static layer of each scene, painted once per size. */
function paintScene(scene: number, ctx: Canvas2D, w: number, h: number) {
  if (scene === 0) return;
  const small = w < 700;
  const at = (base: number) => (small ? 0.2 + base * 0.36 : base); // where a ridge foot sits
  const tall = (height: number) => (small ? height * 0.55 : height);
  const rand = seeded(17 + scene * 101);
  if (scene === 1) {
    const sky = ctx.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, "#1b1f27"); sky.addColorStop(0.5, "#2c3038"); sky.addColorStop(1, "#3a3a38");
    ctx.fillStyle = sky; ctx.fillRect(0, 0, w, h);
    // pale moon with a halo
    const mx = small ? w * 0.86 : w * 0.6, my = small ? h * 0.08 : h * 0.12, mr = small ? 20 : Math.min(w, h) * 0.05;
    glow(ctx, mx, my, mr * 9, "240,226,190", 0.2);
    glow(ctx, mx, my, mr * 2.4, "248,236,206", 0.32);
    ctx.fillStyle = "rgba(238,229,206,.86)"; ctx.beginPath(); ctx.arc(mx, my, mr, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "rgba(200,188,160,.18)"; ctx.beginPath(); ctx.arc(mx - mr * 0.3, my - mr * 0.15, mr * 0.28, 0, Math.PI * 2); ctx.arc(mx + mr * 0.35, my + mr * 0.3, mr * 0.18, 0, Math.PI * 2); ctx.fill();
    // a few faint stars
    for (let i = 0; i < (small ? 30 : 60); i += 1) { ctx.fillStyle = `rgba(236,230,216,${(0.15 + rand() * 0.35).toFixed(2)})`; ctx.fillRect(rand() * w, rand() * h * 0.5, 1, 1); }
    // ink ridges: far ones pale and misty, near ones deep ink; each fades into mist at its foot
    const layers = [
      { base: 0.6, height: 0.3, top: "rgba(150,154,160,.55)", foot: "rgba(90,92,96,0)", rough: 0.58 },
      { base: 0.7, height: 0.26, top: "rgba(104,108,116,.85)", foot: "rgba(70,72,76,.08)", rough: 0.55 },
      { base: 0.8, height: 0.24, top: "rgba(62,65,72,.95)", foot: "rgba(46,48,52,.35)", rough: 0.52 },
      { base: 0.9, height: 0.2, top: "rgba(32,34,38,1)", foot: "rgba(24,25,28,.9)", rough: 0.5 },
      { base: 1.0, height: 0.15, top: "rgba(8,9,10,1)", foot: "rgba(6,7,8,1)", rough: 0.48 },
    ];
    layers.forEach((layer, i) => {
      const foot = at(layer.base);
      fillRidge(ctx, ridge(w, h * foot, h * tall(layer.height), layer.rough, rand), h, layer.top, layer.foot);
      // mist band resting at the foot of the ridge
      const mist = ctx.createLinearGradient(0, h * (foot - 0.07), 0, h * (foot + 0.02));
      mist.addColorStop(0, "rgba(180,182,178,0)"); mist.addColorStop(0.6, `rgba(220,218,210,${(0.2 - i * 0.03).toFixed(3)})`); mist.addColorStop(1, "rgba(180,182,178,0)");
      ctx.fillStyle = mist; ctx.fillRect(0, h * (foot - 0.07), w, h * 0.09);
    });
    return;
  }
  if (scene === 2) {
    const sky = ctx.createLinearGradient(0, 0, w * 0.3, h);
    sky.addColorStop(0, "#0a1230"); sky.addColorStop(0.5, "#16245a"); sky.addColorStop(1, "#1d2650");
    ctx.fillStyle = sky; ctx.fillRect(0, 0, w, h);
    // nebula glow
    glow(ctx, w * 0.22, h * 0.32, Math.max(w, h) * 0.4, "90,100,210", 0.32);
    glow(ctx, w * 0.78, h * 0.6, Math.max(w, h) * 0.36, "60,150,180", 0.24);
    glow(ctx, w * 0.6, h * 0.2, Math.max(w, h) * 0.24, "160,100,190", 0.2);
    glow(ctx, w * 0.5, h * 0.05, Math.max(w, h) * 0.3, "230,200,140", 0.1);
    // milky way: a diagonal band, dense small stars plus a soft glow along it
    const band = (t: number) => ({ x: -w * 0.1 + t * w * 1.2, y: h * 0.95 - t * h * 0.95 });
    for (let i = 0; i < 26; i += 1) { const p = band(i / 25); glow(ctx, p.x, p.y, Math.min(w, h) * 0.22, "200,205,245", 0.1); }
    for (let i = 0; i < (small ? 900 : 2200); i += 1) {
      const t = rand(), p = band(t), spread = (rand() - 0.5) * (rand() < 0.7 ? 0.16 : 0.42) * Math.min(w, h);
      const x = p.x + spread * 0.7, y = p.y + spread;
      ctx.fillStyle = `rgba(${215 + Math.round(rand() * 40)},${215 + Math.round(rand() * 30)},255,${(0.15 + rand() * 0.55).toFixed(2)})`;
      ctx.fillRect(x, y, rand() < 0.92 ? 1 : 1.6, rand() < 0.92 ? 1 : 1.6);
    }
    // dark dust lane through the band
    ctx.save(); ctx.globalCompositeOperation = "multiply";
    for (let i = 0; i < 14; i += 1) { const p = band(0.15 + i / 18); glow(ctx, p.x + 18, p.y + 6, Math.min(w, h) * 0.06, "20,22,40", 0.35); }
    ctx.restore();
    // scattered field stars
    for (let i = 0; i < (small ? 160 : 380); i += 1) { ctx.fillStyle = `rgba(236,234,250,${(0.2 + rand() * 0.6).toFixed(2)})`; const r = rand() < 0.9 ? 0.6 : 1.2; ctx.beginPath(); ctx.arc(rand() * w, rand() * h, r, 0, Math.PI * 2); ctx.fill(); }
    // far horizon: a low dark ridge so the sky has ground
    fillRidge(ctx, ridge(w, h * at(1.0), h * tall(0.12), 0.5, rand), h, "rgba(6,8,18,1)", "rgba(4,5,12,1)", "rgba(120,140,220,.18)");
    return;
  }
  // scene 3: flowing gold
  const sky = ctx.createLinearGradient(0, 0, 0, h);
  sky.addColorStop(0, "#221a10"); sky.addColorStop(0.55, "#3a2a16"); sky.addColorStop(1, "#4a361c");
  ctx.fillStyle = sky; ctx.fillRect(0, 0, w, h);
  glow(ctx, w * 0.5, h * at(0.72), Math.max(w, h) * 0.6, "240,200,120", 0.3);
  glow(ctx, w * 0.82, h * 0.18, Math.max(w, h) * 0.34, "250,225,170", 0.18);
  const layers = [
    { base: 0.78, height: 0.28, top: "rgba(96,72,38,.9)", foot: "rgba(60,44,24,.4)", rim: "rgba(245,214,150,.7)" },
    { base: 0.9, height: 0.22, top: "rgba(52,38,20,1)", foot: "rgba(36,27,15,.9)", rim: "rgba(245,214,150,.5)" },
    { base: 1.0, height: 0.14, top: "rgba(26,19,11,1)", foot: "rgba(18,14,8,1)", rim: "rgba(245,214,150,.36)" },
  ];
  for (const layer of layers) fillRidge(ctx, ridge(w, h * at(layer.base), h * tall(layer.height), 0.55, rand), h, layer.top, layer.foot, layer.rim);
}

type Mote = { x: number; y: number; r: number; speed: number; drift: number; phase: number };

export function createHeroEngine(canvas: HTMLCanvasElement, onScene: (scene: number) => void, reduce: boolean): HeroEngine {
  const ctx = canvas.getContext("2d");
  if (!ctx) return { show: () => undefined, destroy: () => undefined };
  let width = 0, height = 0, dpr = 1;
  const layers: Array<HTMLCanvasElement | null> = [null, null, null, null];
  let motes: Mote[] = [], twinkles: Array<{ x: number; y: number; r: number; phase: number; speed: number }> = [];
  let scene = 0, previous = -1, fade = 1, dwell = 0;
  let shooting: { x: number; y: number; vx: number; vy: number; life: number } | null = null;
  let nextShoot = 3 + Math.random() * 4;
  let crane = -1; // seconds into the crane flight, -1 when none
  let nextCrane = 2 + Math.random() * 4;
  const idle = (fn: () => void) => {
    const w = window as Window & { requestIdleCallback?: (cb: () => void, o?: { timeout: number }) => number };
    if (w.requestIdleCallback) w.requestIdleCallback(fn, { timeout: 1500 }); else setTimeout(fn, 200);
  };
  let sprite: HTMLCanvasElement | null = null;
  const glowSprite = () => {
    if (sprite) return sprite;
    sprite = document.createElement("canvas"); sprite.width = sprite.height = 32;
    const s = sprite.getContext("2d");
    if (s) { const g = s.createRadialGradient(16, 16, 0, 16, 16, 16); g.addColorStop(0, "rgba(240,210,150,1)"); g.addColorStop(0.35, "rgba(226,186,110,.45)"); g.addColorStop(1, "rgba(217,184,118,0)"); s.fillStyle = g; s.fillRect(0, 0, 32, 32); }
    return sprite;
  };
  let generation = 0;
  const paint = (index: number) => {
    if (width < 2) return;
    const layer = document.createElement("canvas");
    layer.width = Math.round(width * dpr); layer.height = Math.round(height * dpr);
    const lctx = layer.getContext("2d");
    if (!lctx) return;
    lctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    paintScene(index, lctx, width, height);
    if (index > 0) {
      // soft dark pool behind the headline so the text stays easy to read on every scene
      const cy = height * (width < 700 ? 0.36 : 0.45), r = Math.max(width, height) * 0.5;
      const g = lctx.createRadialGradient(width / 2, cy, 0, width / 2, cy, r);
      g.addColorStop(0, "rgba(10,10,14,.34)"); g.addColorStop(0.55, "rgba(10,10,14,.12)"); g.addColorStop(1, "rgba(6,6,8,0)");
      lctx.fillStyle = g; lctx.fillRect(0, 0, width, height);
    }
    layers[index] = layer;
  };
  const setup = () => {
    const rect = canvas.getBoundingClientRect();
    if (rect.width < 2 || rect.height < 2) { width = 0; return; }
    if (Math.abs(rect.width - width) < 1 && Math.abs(rect.height - height) < 1) return;
    dpr = Math.min(window.devicePixelRatio || 1, rect.width < 700 ? 1.5 : 1.25);
    width = rect.width; height = rect.height;
    canvas.width = Math.round(width * dpr); canvas.height = Math.round(height * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const small = width < 700;
    motes = Array.from({ length: small ? 22 : 40 }, () => ({ x: Math.random() * width, y: Math.random() * height, r: 3 + Math.random() * 6, speed: 6 + Math.random() * 14, drift: (Math.random() - 0.5) * 10, phase: Math.random() * 6 }));
    twinkles = Array.from({ length: small ? 18 : 34 }, () => ({ x: Math.random() * width, y: Math.random() * height * 0.75, r: 0.8 + Math.random() * 1.2, phase: Math.random() * 6, speed: 0.8 + Math.random() * 1.8 }));
    layers.fill(null);
    const gen = ++generation;
    paint(scene);
    // the other scenes on idle time, one at a time
    [0, 1, 2, 3].filter((i) => i !== scene).forEach((i, k) => idle(() => setTimeout(() => { if (gen === generation && !layers[i]) paint(i); }, k * 120)));
  };

  // ---- moving parts per scene ----
  const ringAndBagua = (time: number, alpha: number) => {
    const small = width < 700;
    const cx = width * 0.5, cy = small ? height * 0.36 : height * 0.46;
    const radius = Math.min(width, height) * (small ? 0.46 : 0.44);
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(-time * 0.012);
    ctx.strokeStyle = `rgba(226,196,130,${(0.2 * alpha).toFixed(3)})`; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(0, 0, radius * 1.08, 0, Math.PI * 2); ctx.stroke();
    for (let i = 0; i < 72; i += 1) { const a = (i / 72) * Math.PI * 2, long = i % 9 === 0; ctx.beginPath(); ctx.moveTo(Math.cos(a) * radius * (long ? 1 : 1.04), Math.sin(a) * radius * (long ? 1 : 1.04)); ctx.lineTo(Math.cos(a) * radius * 1.08, Math.sin(a) * radius * 1.08); ctx.stroke(); }
    ctx.restore();
  };
  const drawMist = (time: number, alpha: number) => {
    for (let band = 0; band < 3; band += 1) {
      const x = ((time * (10 + band * 6) + band * width * 0.55) % (width * 1.8)) - width * 0.4;
      const y = height * (0.62 + band * 0.11);
      const g = ctx.createRadialGradient(x, y, 10, x, y, width * 0.5);
      g.addColorStop(0, `rgba(200,200,196,${(0.075 * alpha).toFixed(3)})`); g.addColorStop(1, "rgba(200,200,196,0)");
      ctx.fillStyle = g; ctx.fillRect(0, 0, width, height);
    }
  };
  const drawCranes = (alpha: number) => {
    if (crane < 0) return;
    const t = crane / 14; // 14 s across the sky
    const small = width < 700;
    const bx = -60 + t * (width + 120), by = height * (small ? 0.28 : 0.3) - t * height * 0.08;
    ctx.strokeStyle = `rgba(14,15,17,${(0.85 * alpha).toFixed(3)})`; ctx.lineWidth = small ? 1.4 : 1.8; ctx.lineCap = "round";
    [[0, 0], [-26, 12], [-48, 26]].forEach(([dx, dy], i) => {
      const flap = Math.sin(crane * 5 + i) * 5, s = small ? 0.8 : 1;
      const x = bx + dx * s, y = by + dy * s;
      ctx.beginPath(); ctx.moveTo(x - 11 * s, y - flap); ctx.quadraticCurveTo(x - 4 * s, y - 2, x, y); ctx.quadraticCurveTo(x + 4 * s, y - 2, x + 11 * s, y - flap); ctx.stroke();
    });
  };
  const drawStarsAndDipper = (time: number, alpha: number) => {
    for (const s of twinkles) {
      const a = (0.2 + 0.8 * (0.5 + 0.5 * Math.sin(time * s.speed + s.phase))) * alpha;
      ctx.fillStyle = `rgba(240,240,255,${a.toFixed(3)})`; ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2); ctx.fill();
    }
    // Northern Dipper, drawn in gold, line by line
    const small = width < 700;
    const ox = small ? width * 0.1 : width * 0.62, oy = small ? height * 0.08 : height * 0.1, k = Math.min(width, height) * (small ? 0.0042 : 0.0036);
    const dipper = [[0, 22], [22, 12], [44, 14], [62, 24], [70, 44], [96, 48], [100, 26]];
    const shown = Math.min(dipper.length, Math.floor(((time % SCENE_SECONDS) / 4) * dipper.length) + 1);
    ctx.strokeStyle = `rgba(217,184,118,${(0.42 * alpha).toFixed(3)})`; ctx.lineWidth = 0.9;
    ctx.beginPath(); dipper.slice(0, shown).forEach(([x, y], i) => (i ? ctx.lineTo(ox + x * k, oy + y * k) : ctx.moveTo(ox + x * k, oy + y * k))); if (shown > 3) ctx.lineTo(ox + dipper[3][0] * k, oy + dipper[3][1] * k); ctx.stroke();
    const spr = glowSprite();
    dipper.forEach(([x, y]) => { const r = 9; ctx.globalAlpha = 0.9 * alpha; ctx.drawImage(spr, ox + x * k - r, oy + y * k - r, r * 2, r * 2); });
    ctx.globalAlpha = 1;
    if (shooting) {
      const tail = 110, ex = shooting.x - (shooting.vx * tail) / 600, ey = shooting.y - (shooting.vy * tail) / 600;
      const g = ctx.createLinearGradient(shooting.x, shooting.y, ex, ey);
      g.addColorStop(0, `rgba(255,244,220,${(Math.min(1, shooting.life) * alpha).toFixed(2)})`); g.addColorStop(1, "rgba(255,244,220,0)");
      ctx.strokeStyle = g; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(shooting.x, shooting.y); ctx.lineTo(ex, ey); ctx.stroke();
    }
  };
  const drawRibbons = (time: number, alpha: number) => {
    const small = width < 700;
    const rows = small ? 5 : 7;
    ctx.save(); ctx.globalCompositeOperation = "lighter";
    for (let r = 0; r < rows; r += 1) {
      const baseY = height * (small ? 0.4 : 0.64) + r * height * (small ? 0.02 : 0.03);
      const amp = height * (small ? 0.045 + r * 0.006 : 0.06 + r * 0.01), speed = 0.18 + r * 0.03, phase = r * 0.7;
      ctx.beginPath();
      for (let x = -10; x <= width + 10; x += 8) {
        const y = baseY + Math.sin(x / width * Math.PI * 2 * 1.1 + time * speed + phase) * amp + Math.sin(x / width * Math.PI * 5 - time * speed * 1.6) * amp * 0.18;
        if (x === -10) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.strokeStyle = `rgba(226,190,120,${((0.05 + (r === 3 ? 0.12 : 0.04)) * alpha).toFixed(3)})`; ctx.lineWidth = r === 3 ? 1.6 : 1; ctx.stroke();
    }
    // sparks riding along the brightest ribbon
    const spr = glowSprite();
    for (let i = 0; i < (small ? 10 : 18); i += 1) {
      const u = ((time * 0.05 + i / (small ? 10 : 18)) % 1);
      const x = u * width, baseY = height * (small ? 0.4 : 0.64) + 3 * height * (small ? 0.02 : 0.03), amp = height * (small ? 0.045 + 3 * 0.006 : 0.06 + 3 * 0.01);
      const y = baseY + Math.sin(x / width * Math.PI * 2 * 1.1 + time * (0.18 + 0.09) + 2.1) * amp + Math.sin(x / width * Math.PI * 5 - time * 0.27 * 1.6) * amp * 0.18;
      const r = 6 + 4 * Math.sin(time * 2 + i);
      ctx.globalAlpha = 0.75 * alpha; ctx.drawImage(spr, x - r, y - r, r * 2, r * 2);
    }
    ctx.restore(); ctx.globalAlpha = 1;
  };
  const drawDust = (time: number, alpha: number, strength: number) => {
    const spr = glowSprite();
    for (const m of motes) {
      const a = (0.2 + 0.5 * (0.5 + 0.5 * Math.sin(time * 1.3 + m.phase))) * alpha * strength;
      ctx.globalAlpha = a; ctx.drawImage(spr, m.x - m.r, m.y - m.r, m.r * 2, m.r * 2);
    }
    ctx.globalAlpha = 1;
  };
  const drawScene = (index: number, time: number, alpha: number) => {
    const layer = layers[index];
    if (!layer) return false;
    if (index > 0) { ctx.globalAlpha = alpha; ctx.drawImage(layer, 0, 0, width, height); ctx.globalAlpha = 1; }
    if (index === 0) { drawDust(time, alpha, 0.7); }
    else if (index === 1) { drawMist(time, alpha); drawCranes(alpha); drawDust(time, alpha, 0.45); }
    else if (index === 2) { drawStarsAndDipper(time, alpha); drawDust(time, alpha, 0.25); }
    else { drawRibbons(time, alpha); drawDust(time, alpha, 1); }
    ringAndBagua(time, alpha);
    return true;
  };

  let clock = 0;
  const frame = () => {
    if (width < 2) return;
    ctx.clearRect(0, 0, width, height);
    if (previous >= 0 && fade < 1) {
      // into the clear "classic" scene: fade the old one out; otherwise lay the new one over the old
      if (scene === 0) { drawScene(previous, clock, 1 - fade); drawScene(0, clock, fade); }
      else { if (!drawScene(previous, clock, 1)) ctx.clearRect(0, 0, width, height); drawScene(scene, clock, fade); }
    } else drawScene(scene, clock, 1);
  };
  const go = (next: number) => {
    if (next === scene) return;
    if (!layers[next]) paint(next);
    previous = scene; scene = next; fade = reduce ? 1 : 0; dwell = 0;
    onScene(scene);
    if (reduce) frame();
  };

  let raf = 0, last = performance.now(), visible = true;
  const tick = (now: number) => {
    const dt = Math.min(0.05, (now - last) / 1000); last = now; clock += dt;
    if (fade < 1) fade = Math.min(1, fade + dt / FADE_SECONDS);
    dwell += dt;
    if (dwell > SCENE_SECONDS) go((scene + 1) % SCENE_COUNT);
    for (const m of motes) { m.y -= m.speed * dt; m.x += Math.sin(clock * 0.5 + m.phase) * m.drift * dt; if (m.y < -10) { m.y = height + 10; m.x = Math.random() * width; } }
    nextShoot -= dt;
    if (!shooting && nextShoot <= 0 && scene === 2) { shooting = { x: width * (0.15 + Math.random() * 0.5), y: height * (0.05 + Math.random() * 0.2), vx: 520 + Math.random() * 220, vy: 160 + Math.random() * 120, life: 1 }; nextShoot = 3.5 + Math.random() * 5; }
    if (shooting) { shooting.x += shooting.vx * dt; shooting.y += shooting.vy * dt; shooting.life -= dt * 1.3; if (shooting.life <= 0) shooting = null; }
    if (crane >= 0) { crane += dt; if (crane > 14) crane = -1; }
    else if (scene === 1) { nextCrane -= dt; if (nextCrane <= 0) { crane = 0; nextCrane = 18 + Math.random() * 10; } }
    frame();
    raf = visible && !document.hidden ? requestAnimationFrame(tick) : 0;
  };
  const start = () => { if (!raf && visible && !document.hidden && !reduce) { last = performance.now(); raf = requestAnimationFrame(tick); } };

  setup();
  if (reduce) frame(); else start();
  canvas.dataset.ready = "1";
  const resize = new ResizeObserver(() => { setup(); frame(); });
  resize.observe(canvas);
  const seen = new IntersectionObserver((entries) => { visible = entries.some((e) => e.isIntersecting); if (visible) start(); }, { threshold: 0 });
  seen.observe(canvas);
  const onVisibility = () => start();
  document.addEventListener("visibilitychange", onVisibility);
  return {
    show: (next) => go(((next % SCENE_COUNT) + SCENE_COUNT) % SCENE_COUNT),
    destroy: () => { cancelAnimationFrame(raf); resize.disconnect(); seen.disconnect(); document.removeEventListener("visibilitychange", onVisibility); },
  };
}

export { GOLD };
