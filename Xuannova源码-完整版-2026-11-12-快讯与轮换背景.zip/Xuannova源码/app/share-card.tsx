"use client";
// 9:16 share image (1080 × 1920) drawn in the browser: chart highlights, the free part of the reading,
// the Xuannova mark, the domain and a QR code (with the member's invite code when signed in).
// Only the free part (conclusion, key points, summary) is ever drawn.
import { useState } from "react";
import type { Locale } from "./site-content";
import type { CompleteChart, InterpretationResponse } from "./chart-model";
import { localizeBoardTerm } from "./complete-chart-board";
import { pathFor } from "./study-navigation";
import { track } from "./analytics";
import { countShare } from "./share-stats-client";
import { canShareImages } from "./poster-art";
import qrcodeFactory from "./vendor/qrcode";

type QrCode = { addData: (data: string) => void; make: () => void; getModuleCount: () => number; isDark: (row: number, col: number) => boolean };
const qrcode = qrcodeFactory as unknown as (typeNumber: number, level: "L" | "M" | "Q" | "H") => QrCode;

const W = 1080;
const H = 1920;
const C = { bg: "#0D0E12", card: "#14161B", line: "#23262E", ink: "#ECE6D8", soft: "#A39C8C", gold: "#D4B06A", jade: "#7DB3A3" };

type Copy = { make: string; making: string; save: string; share: string; note: string; footer: string; scan: string };
const copy: Record<Locale, Copy> = {
  en: { make: "Create share image", making: "Drawing…", save: "Save image", share: "Share", note: "The image shows only the free part of the reading.", footer: "Discover your Eastern Wisdom", scan: "Scan to read the full reading" },
  "zh-Hans": { make: "生成分享图", making: "正在生成…", save: "保存图片", share: "分享", note: "分享图只包含免费部分的内容。", footer: "发现你的东方智慧", scan: "扫码查看完整解读" },
  "zh-Hant": { make: "產生分享圖", making: "正在產生…", save: "儲存圖片", share: "分享", note: "分享圖只包含免費部分的內容。", footer: "發現你的東方智慧", scan: "掃碼查看完整解讀" },
  ja: { make: "シェア画像を作成", making: "作成中…", save: "画像を保存", share: "シェア", note: "画像には無料部分の内容だけが入ります。", footer: "あなたの東洋の知恵を見つけよう", scan: "読み取って全文を見る" },
  ko: { make: "공유 이미지 만들기", making: "만드는 중…", save: "이미지 저장", share: "공유", note: "이미지에는 무료 부분만 들어갑니다.", footer: "당신의 동양 지혜를 발견하세요", scan: "스캔하여 전체 해석 보기" },
  vi: { make: "Tạo ảnh chia sẻ", making: "Đang tạo…", save: "Lưu ảnh", share: "Chia sẻ", note: "Ảnh chỉ chứa phần miễn phí của bài giải.", footer: "Khám phá trí tuệ phương Đông của bạn", scan: "Quét để xem bài giải đầy đủ" },
  th: { make: "สร้างภาพสำหรับแชร์", making: "กำลังสร้าง…", save: "บันทึกภาพ", share: "แชร์", note: "ภาพมีเฉพาะส่วนที่ดูฟรีเท่านั้น", footer: "ค้นพบปัญญาตะวันออกของคุณ", scan: "สแกนเพื่ออ่านฉบับเต็ม" },
};
/** Shown under the QR code when the link carries the member's invite code. */
const inviteScan: Record<Locale, string> = { en: "Scan to join · 5 bonus credits on your first purchase", "zh-Hans": "扫码注册 · 首次购买再得 5 积分", "zh-Hant": "掃碼註冊 · 首次購買再得 5 積分", ja: "読み取って登録 · 初回購入で5クレジット追加", ko: "스캔해서 가입 · 첫 구매 시 5크레딧 추가", vi: "Quét để đăng ký · thêm 5 điểm khi mua lần đầu", th: "สแกนเพื่อสมัคร · ซื้อครั้งแรกรับเพิ่ม 5 เครดิต" };
export const fontFor = (locale: Locale) => (locale === "th" ? '"Noto Sans Thai", "Noto Sans", sans-serif' : locale === "ko" ? '"Noto Sans KR", sans-serif' : locale === "ja" ? '"Noto Sans JP", sans-serif' : '"Noto Sans SC", "Noto Sans", sans-serif');

/** Break text into lines that fit a width. Uses word segmentation where available (needed for Thai). */
export function wrap(ctx: CanvasRenderingContext2D, text: string, width: number, locale: Locale, maxLines: number) {
  const Segmenter = (Intl as unknown as { Segmenter?: new (locale: string, options: { granularity: string }) => { segment: (input: string) => Iterable<{ segment: string }> } }).Segmenter;
  const pieces = Segmenter ? Array.from(new Segmenter(locale, { granularity: "word" }).segment(text), (part) => part.segment) : Array.from(text);
  const lines: string[] = [];
  let line = "";
  const closing = /^[。、，．,.!?！？:：;；)）」』】"”'’…]+$/u;
  for (const piece of pieces) {
    // Closing punctuation never starts a line; it stays with the previous text even if slightly over.
    if (ctx.measureText(line + piece).width > width && line && !closing.test(piece)) {
      lines.push(line.trimEnd()); line = piece.trimStart();
      if (lines.length === maxLines) break;
    } else line += piece;
  }
  if (lines.length < maxLines && line) lines.push(line.trimEnd());
  if (lines.length === maxLines && pieces.join("").length > lines.join("").length + 1) lines[maxLines - 1] = `${lines[maxLines - 1].replace(/.$/u, "")}…`;
  return lines;
}

export function drawShareCard(canvas: HTMLCanvasElement, options: { chart: CompleteChart; reading: InterpretationResponse; locale: Locale; link: string; toolTitle: string }) {
  const { chart, reading, locale, link, toolTitle } = options;
  const text = copy[locale];
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext("2d")!;
  const font = fontFor(locale);
  ctx.fillStyle = C.bg; ctx.fillRect(0, 0, W, H);
  // Faint compass rings behind the header.
  ctx.strokeStyle = "rgba(212,176,106,.16)"; ctx.lineWidth = 2;
  for (const r of [380, 300, 220]) { ctx.beginPath(); ctx.arc(W / 2, 330, r, 0, Math.PI * 2); ctx.stroke(); }
  ctx.textAlign = "center";
  ctx.fillStyle = C.gold; ctx.font = `600 64px "Cormorant Garamond", Georgia, serif`; ctx.fillText("Xuannova", W / 2, 170);
  ctx.fillStyle = C.ink; ctx.font = `600 76px ${font}`; ctx.fillText(toolTitle, W / 2, 300);
  ctx.fillStyle = C.soft; ctx.font = `400 34px ${font}`; ctx.fillText(localizeBoardTerm(chart.board.label, locale), W / 2, 360);
  // Chart highlights: up to four cells (title + main value).
  const cells = chart.board.cells.slice(0, 4);
  const cellW = (W - 160 - (cells.length - 1) * 20) / Math.max(1, cells.length);
  cells.forEach((cell, index) => {
    const x = 80 + index * (cellW + 20);
    ctx.fillStyle = C.card; ctx.strokeStyle = C.line; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.roundRect(x, 430, cellW, 210, 22); ctx.fill(); ctx.stroke();
    ctx.fillStyle = C.soft; ctx.font = `400 28px ${font}`; ctx.fillText(localizeBoardTerm(cell.title, locale).slice(0, 12), x + cellW / 2, 490);
    ctx.fillStyle = C.gold; ctx.font = `600 ${cells.length > 3 ? 52 : 60}px ${font}`; ctx.fillText(localizeBoardTerm(cell.subtitle ?? "—", locale).slice(0, 8), x + cellW / 2, 585);
  });
  // The free part of the reading.
  ctx.textAlign = "left";
  let y = 740;
  ctx.fillStyle = C.ink; ctx.font = `600 50px ${font}`;
  for (const line of wrap(ctx, reading.conclusion || reading.summary, W - 160, locale, 4)) { ctx.fillText(line, 80, y); y += 70; }
  y += 30;
  (reading.keyPoints ?? []).slice(0, 3).forEach((point, index) => {
    ctx.font = `400 36px ${font}`;
    const lines = wrap(ctx, point, W - 300, locale, 3);
    const boxH = 50 + lines.length * 50;
    ctx.fillStyle = C.card; ctx.strokeStyle = C.line; ctx.beginPath(); ctx.roundRect(80, y, W - 160, boxH, 20); ctx.fill(); ctx.stroke();
    ctx.fillStyle = C.jade; ctx.font = `600 34px Georgia, serif`; ctx.fillText(String(index + 1).padStart(2, "0"), 112, y + 62);
    ctx.fillStyle = C.ink; ctx.font = `400 36px ${font}`;
    lines.forEach((line, lineIndex) => ctx.fillText(line, 190, y + 62 + lineIndex * 50));
    y += boxH + 22;
  });
  // QR code and footer.
  const qr = qrcode(0, "M"); qr.addData(link); qr.make();
  const count = qr.getModuleCount();
  const size = 300; const cell = size / count; const qx = W - 80 - size; const qy = H - 120 - size;
  ctx.fillStyle = "#FFFFFF"; ctx.beginPath(); ctx.roundRect(qx - 20, qy - 20, size + 40, size + 40, 18); ctx.fill();
  ctx.fillStyle = "#000000";
  for (let r = 0; r < count; r += 1) for (let c = 0; c < count; c += 1) if (qr.isDark(r, c)) ctx.fillRect(qx + c * cell, qy + r * cell, Math.ceil(cell), Math.ceil(cell));
  ctx.fillStyle = C.gold; ctx.font = `600 54px "Cormorant Garamond", Georgia, serif`; ctx.fillText("xuannova.com", 80, H - 330);
  ctx.fillStyle = C.ink; ctx.font = `400 34px ${font}`;
  wrap(ctx, link.includes("invite=") ? inviteScan[locale] : text.scan, W - 520, locale, 2).forEach((line, index) => ctx.fillText(line, 80, H - 260 + index * 46));
  ctx.fillStyle = C.soft; ctx.font = `400 26px ${font}`;
  wrap(ctx, text.footer, W - 520, locale, 2).forEach((line, index) => ctx.fillText(line, 80, H - 150 + index * 36));
}

export function ShareCardButton({ chart, reading, locale, inviteCode, route, toolTitle }: { chart: CompleteChart; reading: InterpretationResponse; locale: Locale; inviteCode?: string | null; route: string; toolTitle: string }) {
  const text = copy[locale];
  const [image, setImage] = useState<{ url: string; blob: Blob } | null>(null);
  const [busy, setBusy] = useState(false);
  const make = async () => {
    setBusy(true);
    try {
      await document.fonts?.ready;
      const canvas = document.createElement("canvas");
      const path = pathFor(locale, route as Parameters<typeof pathFor>[1]);
      const link = `https://xuannova.com${path}?utm_source=chart-card${inviteCode ? `&invite=${encodeURIComponent(inviteCode)}` : ""}`;
      drawShareCard(canvas, { chart, reading, locale, link, toolTitle });
      const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/png"));
      if (blob) { setImage((previous) => { if (previous) URL.revokeObjectURL(previous.url); return { url: URL.createObjectURL(blob), blob }; }); track("share_image", { tool: chart.tool }); countShare("chart-card", "made"); }
    } finally { setBusy(false); }
  };
  const share = async () => {
    if (!image) return;
    const file = new File([image.blob], "xuannova.png", { type: "image/png" });
    const nav = navigator as Navigator & { canShare?: (data: { files: File[] }) => boolean };
    if (nav.canShare?.({ files: [file] })) { try { await nav.share({ files: [file], title: "Xuannova" }); track("share", { method: "native", tool: chart.tool }); countShare("chart-card", "shared"); } catch { /* cancelled */ } }
  };
  return <div className="share-card-tool">
    <button type="button" className="secondary-action" onClick={() => void make()} disabled={busy}>{busy ? text.making : text.make}<b>↗</b></button>
    <small>{text.note}</small>
    {image && <figure className="share-card-preview">
      <button type="button" className="share-card-close" onClick={() => setImage((previous) => { if (previous) URL.revokeObjectURL(previous.url); return null; })} aria-label="×">×</button>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={image.url} alt={text.make} width={270} height={480} />
      <figcaption><a className="primary-action" href={image.url} download="xuannova.png" onClick={() => { track("share", { method: "download", tool: chart.tool }); countShare("chart-card", "saved"); }}>{text.save}<b>↓</b></a>
        {canShareImages() && <button type="button" className="text-action" onClick={() => void share()}>{text.share}</button>}</figcaption>
    </figure>}
  </div>;
}
