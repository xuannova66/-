// Cloudflare Workers runtime module (only present in the Workers build).
declare module "cloudflare:workers" {
  export const env: Record<string, any>;
}
