/** Feature-gated local integration for binding a second wallet to a member.
 * Not yet wired into the payment UI. This signs a login challenge, never a
 * transaction. Server must authenticate the existing member and origin.
 */
import { bytesToHex } from "viem";
import { connectSolanaDraft, connectTronDraft, type SolanaWallet, type TronWallet } from "./non-evm-wallet-session.draft";

export type SolanaSignWallet = SolanaWallet & { signMessage(message: Uint8Array, display: "utf8"): Promise<{signature: Uint8Array}> };
export type TronSignWallet = Omit<TronWallet, "tronWeb"> & {tronWeb?: false | {ready?:boolean; defaultAddress?:{base58?:string}; trx?:{signMessageV2(message:string):Promise<string>}}};
type Challenge = {nonce:string;chain:string;address:string;message:string;expiresAt:number};
type Fetcher = (input: string, init: RequestInit) => Promise<Response>;
const inFlight = new WeakSet<object>();
function solanaAccountStillMatches(provider:SolanaSignWallet,address:string):boolean {
  return Boolean(provider.publicKey && provider.publicKey.toString()===address && provider.isConnected!==false);
}

async function post(path: string, payload: unknown, fetcher: Fetcher): Promise<unknown> {
  const response = await fetcher(path, {method:"POST",credentials:"same-origin",headers:{"content-type":"application/json"},body:JSON.stringify(payload)});
  if (!response.ok) throw new Error("WALLET_LINK_REQUEST_FAILED");
  try { return await response.json(); } catch { throw new Error("WALLET_LINK_INVALID_RESPONSE"); }
}
async function challenge(chain: "solana"|"tron", address:string, fetcher:Fetcher):Promise<Challenge> {
  const value=await post("/api/member/wallet-links/challenge",{chain,address},fetcher) as Partial<Challenge>;
  if (value.chain!==chain || value.address!==address || typeof value.nonce!=="string" || !/^[a-f0-9]{64}$/.test(value.nonce) || typeof value.message!=="string" || !value.message.includes(`\nNonce: ${value.nonce}\n`) || !value.message.includes(`\nAddress: ${address}\n`) || !Number.isSafeInteger(value.expiresAt)) throw new Error("WALLET_LINK_INVALID_RESPONSE");
  return value as Challenge;
}
async function finish(nonce:string, signature:string, fetcher:Fetcher):Promise<void> {
  const result=await post("/api/member/wallet-links/verify",{nonce,signature},fetcher) as {linked?:unknown};
  if (result?.linked!==true) throw new Error("WALLET_LINK_INVALID_RESPONSE");
}
export async function linkSolanaWallet(provider: SolanaSignWallet, fetcher:Fetcher=fetch):Promise<string> {
  if (!provider || typeof provider.signMessage!=="function") throw new Error("WALLET_NOT_AVAILABLE");
  if (inFlight.has(provider)) throw new Error("WALLET_LINK_PENDING");
  inFlight.add(provider);
  try {
    const {address}=await connectSolanaDraft(provider);
    if (!solanaAccountStillMatches(provider,address)) throw new Error("WALLET_ACCOUNT_CHANGED");
    const request=await challenge("solana",address,fetcher);
    const signed=await provider.signMessage(new TextEncoder().encode(request.message),"utf8");
    if (!solanaAccountStillMatches(provider,address)) throw new Error("WALLET_ACCOUNT_CHANGED");
    if (!(signed?.signature instanceof Uint8Array) || signed.signature.length!==64) throw new Error("WALLET_SIGNATURE_INVALID");
    await finish(request.nonce,bytesToHex(signed.signature),fetcher);
    return address;
  } finally {inFlight.delete(provider);}
}
export async function linkTronWallet(provider: TronSignWallet, fetcher:Fetcher=fetch):Promise<string> {
  if (!provider || typeof provider.request!=="function") throw new Error("WALLET_NOT_AVAILABLE");
  if (inFlight.has(provider)) throw new Error("WALLET_LINK_PENDING");
  inFlight.add(provider);
  try {
    const {address}=await connectTronDraft(provider);
    const web=provider.tronWeb;
    if (!web || !web.trx || typeof web.trx.signMessageV2!=="function") throw new Error("WALLET_NOT_AVAILABLE");
    const request=await challenge("tron",address,fetcher);
    const signature=await web.trx.signMessageV2(request.message);
    if (!provider.tronWeb || !provider.tronWeb.ready || provider.tronWeb.defaultAddress?.base58!==address) throw new Error("WALLET_ACCOUNT_CHANGED");
    if (typeof signature!=="string" || !/^0x[0-9a-fA-F]{130}$/.test(signature)) throw new Error("WALLET_SIGNATURE_INVALID");
    await finish(request.nonce,signature,fetcher);
    return address;
  } finally {inFlight.delete(provider);}
}
