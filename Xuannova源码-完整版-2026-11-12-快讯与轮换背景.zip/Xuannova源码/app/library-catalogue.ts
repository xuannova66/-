import type { Locale } from "./site-content";

export type LibraryCategory = "foundation" | "bazi" | "ziwei" | "qimen" | "liuyao" | "daliuren" | "qizheng" | "reflection";

export type ArchiveMethod =
  | "hecan" | "bazi" | "detail" | "compatibility" | "liuyao" | "ziwei" | "qizheng" | "qimen" | "daliuren" | "wenshi" | "mirror"
  | "time" | "elements" | "dream" | "name" | "tarot" | "iching" | "natal"
  | "meihua" | "jinkoujue" | "heluo" | "tieban" | "taiyi" | "zhuzhai";

export type ClassicalWork = {
  id: string;
  category: LibraryCategory;
  title: string;
  originalTitle: string;
  era: string;
  tags: string[];
  methods: ArchiveMethod[];
  description: string;
  sourceUrl: string;
  cover: "ink" | "vermilion" | "jade" | "night" | "ochre" | "plum";
};

export const libraryCategories: LibraryCategory[] = ["foundation", "bazi", "ziwei", "qimen", "liuyao", "daliuren", "qizheng", "reflection"];

const ctext = "https://ctext.org/";
// Works without a specific public page link to a title search on the Chinese Text Project instead of its home page.
const work = (record: ClassicalWork) => (record.sourceUrl === ctext ? { ...record, sourceUrl: `https://ctext.org/wiki.pl?if=en&searchu=${encodeURIComponent(record.originalTitle)}` } : record);

export const classicalWorks: ClassicalWork[] = [
  work({ id: "zhouyi", category: "foundation", title: "Book of Changes", originalTitle: "周易", era: "Classical canon", tags: ["trigrams", "change"], methods: ["hecan", "liuyao", "iching", "wenshi", "meihua", "heluo"], description: "A foundational record for trigrams, lines and change-oriented study.", sourceUrl: "https://ctext.org/book-of-changes", cover: "ink" }),
  work({ id: "xici", category: "foundation", title: "Great Treatise", originalTitle: "易傳·繫辭", era: "Classical commentary", tags: ["images", "sequence"], methods: ["hecan", "iching", "mirror", "meihua", "heluo"], description: "Commentary on classical images, sequence and attentive observation.", sourceUrl: "https://ctext.org/book-of-changes/xi-ci-shang", cover: "jade" }),
  work({ id: "wuxingdayi", category: "foundation", title: "Essential Meanings of the Five Phases", originalTitle: "五行大義", era: "Sui dynasty", tags: ["five phases", "correspondence"], methods: ["bazi", "detail", "elements", "hecan", "name", "zhuzhai"], description: "A reference shelf for Five Elements correspondences and terminology.", sourceUrl: "https://ctext.org/wiki.pl?if=en&res=994005", cover: "ochre" }),
  work({ id: "huainanzi", category: "foundation", title: "Masters of Huainan", originalTitle: "淮南子", era: "Han dynasty", tags: ["season", "cosmos"], methods: ["qizheng", "time", "natal", "mirror", "taiyi"], description: "Cosmology, seasons and natural imagery for cultural study.", sourceUrl: "https://ctext.org/huainanzi", cover: "night" }),
  work({ id: "yuanhai", category: "bazi", title: "The Sea of Ziping", originalTitle: "淵海子平", era: "Ming compilation", tags: ["four pillars", "ten gods"], methods: ["bazi", "detail", "hecan", "compatibility", "tieban"], description: "A broad four-pillars reference for structural terminology and examples.", sourceUrl: "https://ctext.org/wiki.pl?chapter=901791&if=en", cover: "ink" }),
  work({ id: "sanming", category: "bazi", title: "Comprehensive Guide to the Three Destinies", originalTitle: "三命通會", era: "Ming dynasty", tags: ["pillars", "seasonal balance"], methods: ["bazi", "detail", "hecan", "tieban"], description: "A detailed four-pillars shelf for seasonal context and chart vocabulary.", sourceUrl: ctext, cover: "plum" }),
  work({ id: "ditiansui", category: "bazi", title: "Drops of Heavenly Marrow", originalTitle: "滴天髓", era: "Classical commentary", tags: ["stems", "balance"], methods: ["bazi", "detail", "elements"], description: "A concise conceptual record used in elemental balance discussions.", sourceUrl: ctext, cover: "jade" }),
  work({ id: "zipingzhenquan", category: "bazi", title: "True Principles of Ziping", originalTitle: "子平真詮", era: "Qing dynasty", tags: ["patterns", "useful spirit"], methods: ["bazi", "detail", "hecan"], description: "A reference for pattern language and seasonal reading structure.", sourceUrl: ctext, cover: "ochre" }),
  work({ id: "qiongtong", category: "bazi", title: "Treasury of Seasonal Penetration", originalTitle: "窮通寶鑑", era: "Qing compilation", tags: ["months", "seasons"], methods: ["bazi", "detail", "time"], description: "A month-by-month shelf for seasonal correspondences.", sourceUrl: ctext, cover: "vermilion" }),
  work({ id: "ziweiquanshu", category: "ziwei", title: "Complete Book of Zi Wei Dou Shu", originalTitle: "紫微斗數全書", era: "Traditional compilation", tags: ["twelve houses", "stars"], methods: ["ziwei", "hecan", "compatibility"], description: "A twelve-house reference shelf for star and palace terminology.", sourceUrl: ctext, cover: "night" }),
  work({ id: "qimentongzong", category: "qimen", title: "Orthodox Transmission of Qi Men Dun Jia", originalTitle: "奇門遁甲統宗", era: "Traditional compilation", tags: ["nine palaces", "eight gates"], methods: ["qimen", "wenshi", "time"], description: "A nine-palace resource for gates, stars, spirits and timing structure.", sourceUrl: "https://ctext.org/wiki.pl?if=en&res=535687", cover: "vermilion" }),
  work({ id: "qimenbaojian", category: "qimen", title: "Imperial Qi Men Treasury", originalTitle: "御定奇門寶鑑", era: "Qing compilation", tags: ["timing", "palaces"], methods: ["qimen", "wenshi", "hecan"], description: "A reference layer for timing-board vocabulary and structure.", sourceUrl: ctext, cover: "ink" }),
  work({ id: "bushizhengzong", category: "liuyao", title: "Orthodox Methods of Divination", originalTitle: "卜筮正宗", era: "Qing compilation", tags: ["six lines", "relations"], methods: ["liuyao", "iching", "wenshi"], description: "A six-line reference for structural terms, six relations and changing lines.", sourceUrl: "https://ctext.org/wiki.pl?chapter=909268&if=en", cover: "plum" }),
  work({ id: "zengshanbuyi", category: "liuyao", title: "Expanded and Revised Divination", originalTitle: "增刪卜易", era: "Qing dynasty", tags: ["six lines", "cases"], methods: ["liuyao", "iching"], description: "A study shelf for six-line case structure and terminology.", sourceUrl: ctext, cover: "jade" }),
  work({ id: "huozhulin", category: "liuyao", title: "Forest of Fire Pearls", originalTitle: "火珠林", era: "Traditional text", tags: ["trigrams", "line images"], methods: ["liuyao", "iching", "mirror"], description: "A historical reference record for hexagram and line imagery.", sourceUrl: ctext, cover: "vermilion" }),
  work({ id: "yiyin", category: "liuyao", title: "Hidden Meanings of the Changes", originalTitle: "易隱", era: "Qing dynasty", tags: ["change", "inquiry"], methods: ["liuyao", "iching", "wenshi"], description: "A supplemental reference for reflective inquiry through changes.", sourceUrl: ctext, cover: "night" }),
  work({ id: "liurendaquan", category: "daliuren", title: "Great Compendium of Da Liu Ren", originalTitle: "六壬大全", era: "Traditional compilation", tags: ["four classes", "three transmissions"], methods: ["daliuren", "wenshi", "qimen", "jinkoujue"], description: "A reference shelf for the four classes and three transmissions layout.", sourceUrl: ctext, cover: "ochre" }),
  work({ id: "bifafu", category: "daliuren", title: "Ode of the Essential Methods", originalTitle: "畢法賦", era: "Traditional verse", tags: ["transmissions", "classifications"], methods: ["daliuren", "wenshi"], description: "A compact verse reference for Da Liu Ren study vocabulary.", sourceUrl: ctext, cover: "ink" }),
  work({ id: "liurenshending", category: "daliuren", title: "Da Liu Ren Canon of Settled Methods", originalTitle: "六壬神定經", era: "Traditional text", tags: ["twelve generals", "transmissions"], methods: ["daliuren", "qimen", "jinkoujue"], description: "A catalogue record for the wider Da Liu Ren structural tradition.", sourceUrl: ctext, cover: "plum" }),
  work({ id: "xingxuedacheng", category: "qizheng", title: "Great Compendium of Star Studies", originalTitle: "星學大成", era: "Ming compilation", tags: ["celestial", "sectors"], methods: ["qizheng", "natal"], description: "A reference record for celestial sectors and observational language.", sourceUrl: ctext, cover: "jade" }),
  work({ id: "xiejibianfang", category: "qizheng", title: "Imperial Compendium of Auspicious Timing", originalTitle: "協紀辨方書", era: "Qing compilation", tags: ["calendar", "season"], methods: ["time", "qizheng", "qimen", "taiyi", "zhuzhai"], description: "A calendar and seasonal timing reference for cultural study.", sourceUrl: ctext, cover: "ochre" }),
  work({ id: "zhougong", category: "reflection", title: "Duke of Zhou's Dream Book", originalTitle: "周公解夢", era: "Folklore compilation", tags: ["dream", "images"], methods: ["dream", "mirror"], description: "A folklore-oriented shelf for reflecting on dream images, not medical or predictive advice.", sourceUrl: ctext, cover: "plum" }),
  work({ id: "caigentan", category: "reflection", title: "Vegetable Roots Discourses", originalTitle: "菜根譚", era: "Ming anthology", tags: ["reflection", "conduct"], methods: ["mirror", "compatibility", "hecan"], description: "A reflective reading shelf for self-observation and relationships.", sourceUrl: "https://ctext.org/wiki.pl?if=en&res=865193", cover: "ink" }),
];

type LocalizedLibraryTitles = Partial<Record<Locale, Record<string, string>>>;

// A source title remains useful for archival search, but the title printed on a
// card is always the reader's language rather than a Chinese/English fallback.
const libraryTitleTranslations: LocalizedLibraryTitles = {
  "zh-Hans": {
    zhouyi: "周易", xici: "易传·系辞", wuxingdayi: "五行大义", huainanzi: "淮南子",
    yuanhai: "渊海子平", sanming: "三命通会", ditiansui: "滴天髓", zipingzhenquan: "子平真诠", qiongtong: "穷通宝鉴",
    ziweiquanshu: "紫微斗数全书", qimentongzong: "奇门遁甲统宗", qimenbaojian: "御定奇门宝鉴",
    bushizhengzong: "卜筮正宗", zengshanbuyi: "增删卜易", huozhulin: "火珠林", yiyin: "易隐", liurendaquan: "六壬大全", bifafu: "毕法赋", liurenshending: "六壬神定经", xingxuedacheng: "星学大成", xiejibianfang: "协纪辨方书", zhougong: "周公解梦", caigentan: "菜根谭"
  },
  "zh-Hant": {
  },
  ja: {
    zhouyi: "周易", xici: "易伝・繋辞", wuxingdayi: "五行大義", huainanzi: "淮南子",
    yuanhai: "淵海子平", sanming: "三命通会", ditiansui: "滴天髄", zipingzhenquan: "子平真詮", qiongtong: "窮通宝鑑",
    ziweiquanshu: "紫微斗数全書", qimentongzong: "奇門遁甲統宗", qimenbaojian: "御定奇門宝鑑",
    bushizhengzong: "卜筮正宗", zengshanbuyi: "増刪卜易", huozhulin: "火珠林", yiyin: "易隠", liurendaquan: "六壬大全", bifafu: "畢法賦", liurenshending: "六壬神定経", xingxuedacheng: "星学大成", xiejibianfang: "協紀辨方書", zhougong: "周公解夢", caigentan: "菜根譚"
  },
  ko: {
    zhouyi: "주역", xici: "역전·계사", wuxingdayi: "오행대의", huainanzi: "회남자",
    yuanhai: "연해자평", sanming: "삼명통회", ditiansui: "적천수", zipingzhenquan: "자평진전", qiongtong: "궁통보감",
    ziweiquanshu: "자미두수전서", qimentongzong: "기문둔갑통종", qimenbaojian: "어정기문보감",
    bushizhengzong: "복서정종", zengshanbuyi: "증산복역", huozhulin: "화주림", yiyin: "역은", liurendaquan: "육임대전", bifafu: "필법부", liurenshending: "육임신정경", xingxuedacheng: "성학대성", xiejibianfang: "협기변방서", zhougong: "주공해몽", caigentan: "채근담"
  },
  vi: {
    zhouyi: "Kinh Dịch", xici: "Hệ Từ", wuxingdayi: "Ngũ Hành Đại Nghĩa", huainanzi: "Hoài Nam Tử",
    yuanhai: "Uyên Hải Tử Bình", sanming: "Tam Mệnh Thông Hội", ditiansui: "Đích Thiên Tủy", zipingzhenquan: "Tử Bình Chân Thuyên", qiongtong: "Cùng Thông Bảo Giám",
    ziweiquanshu: "Tử Vi Đẩu Số Toàn Thư", qimentongzong: "Kỳ Môn Độn Giáp Thống Tông", qimenbaojian: "Ngự Định Kỳ Môn Bảo Giám",
    bushizhengzong: "Bốc Phệ Chính Tông", zengshanbuyi: "Tăng San Bốc Dịch", huozhulin: "Hỏa Châu Lâm", yiyin: "Dịch Ẩn", liurendaquan: "Lục Nhâm Đại Toàn", bifafu: "Tất Pháp Phú", liurenshending: "Lục Nhâm Thần Định Kinh", xingxuedacheng: "Tinh Học Đại Thành", xiejibianfang: "Hiệp Kỷ Biện Phương Thư", zhougong: "Chu Công Giải Mộng", caigentan: "Thái Căn Đàm"
  },
  th: {
    zhouyi: "คัมภีร์อี้จิง", xici: "อี้จ้วน·ซี่ฉือ", wuxingdayi: "อู่สิงต้าหยี่", huainanzi: "หวยหนานจื่อ",
    yuanhai: "ยวนไห่จื่อผิง", sanming: "ซานมิ่งทงฮุ่ย", ditiansui: "ตี้เทียนสุ่ย", zipingzhenquan: "จื่อผิงเจินเฉวียน", qiongtong: "ฉงทงเป่าเจี้ยน",
    ziweiquanshu: "จื่อเวยโต้วซู่เฉวียนชู", qimentongzong: "ฉีเหมินตุ้นเจี่ยทงจง", qimenbaojian: "อวี้ติ้งฉีเหมินเป่าเจี้ยน",
    bushizhengzong: "ปู้ซื่อเจิ้งจง", zengshanbuyi: "เจิงซานปู้อี้", huozhulin: "หั่วจูหลิน", yiyin: "อี้อิ่น", liurendaquan: "ต้าหลิ่วเริ่น", bifafu: "ปี้ฝ่าฟู่", liurenshending: "ลิ่วเริ่นเสินติ้งจิง", xingxuedacheng: "ซิงเสวียต้าฉง", xiejibianfang: "เซี่ยจีเปี้ยนฟางชู", zhougong: "โจวกงเจี่ยเมิ่ง", caigentan: "ไช่เกินถาน"
  }
};

export function localizedLibraryTitle(work: ClassicalWork, locale: Locale): string {
  return libraryTitleTranslations[locale]?.[work.id] ?? (locale === "en" ? work.title : work.originalTitle);
}

// Tarot has no Chinese classic on this shelf (the library keeps 23 Eastern classics).
const requiredMethods: ArchiveMethod[] = ["hecan", "bazi", "detail", "compatibility", "liuyao", "ziwei", "qizheng", "qimen", "daliuren", "wenshi", "mirror", "time", "elements", "dream", "name", "iching", "natal", "meihua", "jinkoujue", "heluo", "tieban", "taiyi", "zhuzhai"];

export function coversAllStudyMethods(): boolean {
  const coverage = new Set(classicalWorks.flatMap((item) => item.methods));
  return requiredMethods.every((method) => coverage.has(method));
}
