"use client";
// 我的静室 (member centre tab): create your own quiet room, invite family and friends with a link, see who is in the
// room right now (by 道号), and share saved birth profiles so everyone in the room can study that chart and its life
// K-line together. No chat. Invitation links arrive as ?tab=rooms&room=<token>.
import { useCallback, useEffect, useMemo, useState } from "react";
import type { Locale } from "./site-content";
import { MemberAvatar } from "./member-avatar";
import { LifeKLineChart } from "./life-kline-chart";
import { createStudyResult } from "./study-engine";
import { pathFor } from "./study-navigation";
import { localizeBoardTerm } from "./complete-chart-board";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });
const T = {
  title: L("My quiet room", "我的静室", "我的靜室", "わたしの静室", "나의 정실", "Tịnh thất của tôi", "ห้องสงบของฉัน"),
  lead: L("A private room for you and the people you invite. See who is here, and study the charts you choose to share, together.", "只属于你和你邀请的人。能看到谁在静室里，一起看大家分享的命盘和人生K线。", "只屬於你和你邀請的人。能看到誰在靜室裡，一起看大家分享的命盤和人生K線。", "あなたと招待した人だけの部屋。誰がいるかが分かり、共有した命式と人生Kラインを一緒に見られます。", "나와 초대한 사람만의 방입니다. 누가 있는지 보고, 공유한 명식과 인생 K라인을 함께 봅니다.", "Phòng riêng cho bạn và người bạn mời. Thấy ai đang ở đây và cùng xem lá số, biểu đồ nến được chia sẻ.", "ห้องส่วนตัวของคุณและคนที่คุณเชิญ เห็นว่าใครอยู่ และดูดวงกับกราฟชีวิตที่แบ่งปันไว้ด้วยกัน"),
  create: L("Open my quiet room", "开启我的静室", "開啟我的靜室", "静室を開く", "정실 열기", "Mở tịnh thất", "เปิดห้องสงบ"),
  myRooms: L("Rooms", "静室", "靜室", "静室", "정실", "Các phòng", "ห้อง"),
  owner: L("Host", "室主", "室主", "室主", "방장", "Chủ phòng", "เจ้าของห้อง"),
  members: L("{n} people", "{n} 人", "{n} 人", "{n} 人", "{n}명", "{n} người", "{n} คน"),
  online: L("here now", "在静室中", "在靜室中", "在室中", "지금 있음", "đang ở đây", "อยู่ตอนนี้"),
  invite: L("Invitation link", "邀请链接", "邀請連結", "招待リンク", "초대 링크", "Liên kết mời", "ลิงก์เชิญ"),
  inviteLead: L("Send this link to family or friends. They sign in and join; up to 12 people.", "把链接发给家人或朋友，对方登录后即可加入，最多 12 人。", "把連結發給家人或朋友，對方登入後即可加入，最多 12 人。", "家族や友人に送ってください。ログインすると参加できます（最大12人）。", "가족이나 친구에게 보내세요. 로그인하면 참여할 수 있어요(최대 12명).", "Gửi liên kết cho người thân, bạn bè. Họ đăng nhập là vào được, tối đa 12 người.", "ส่งลิงก์ให้ครอบครัวหรือเพื่อน เข้าสู่ระบบแล้วเข้าร่วมได้ สูงสุด 12 คน"),
  copy: L("Copy", "复制", "複製", "コピー", "복사", "Sao chép", "คัดลอก"),
  copied: L("Copied", "已复制", "已複製", "コピーしました", "복사됨", "Đã sao chép", "คัดลอกแล้ว"),
  resetLink: L("New link (old one stops working)", "换新链接（旧链接失效）", "換新連結（舊連結失效）", "リンクを作り直す（旧リンクは無効）", "새 링크(기존 링크 만료)", "Tạo liên kết mới (liên kết cũ hết hiệu lực)", "สร้างลิงก์ใหม่ (ลิงก์เดิมใช้ไม่ได้)"),
  rename: L("Rename room", "改室名", "改室名", "部屋名を変更", "방 이름 변경", "Đổi tên phòng", "เปลี่ยนชื่อห้อง"),
  myName: L("My Taoist name here", "我在此的道号", "我在此的道號", "ここでの道号", "여기서의 도호", "Đạo hiệu của tôi ở đây", "ฉายาของฉันในห้องนี้"),
  change: L("Change", "修改", "修改", "変更", "변경", "Đổi", "เปลี่ยน"),
  save: L("Save", "保存", "儲存", "保存", "저장", "Lưu", "บันทึก"),
  cancel: L("Cancel", "取消", "取消", "キャンセル", "취소", "Hủy", "ยกเลิก"),
  shares: L("Shared charts", "大家分享的命盘", "大家分享的命盤", "共有された命式", "공유된 명식", "Lá số được chia sẻ", "ดวงที่แบ่งปัน"),
  noShares: L("No charts yet. Share one of your saved profiles to study it together.", "还没有人分享命盘。可以把你保存的档案分享进来一起看。", "還沒有人分享命盤。可以把你保存的檔案分享進來一起看。", "まだ共有はありません。保存したプロフィールを共有して一緒に見ましょう。", "아직 공유된 명식이 없어요. 저장한 프로필을 공유해 함께 보세요.", "Chưa có lá số nào. Hãy chia sẻ hồ sơ đã lưu để cùng xem.", "ยังไม่มีดวง แบ่งปันโปรไฟล์ที่บันทึกไว้เพื่อดูด้วยกัน"),
  share: L("Share a chart", "分享一个命盘", "分享一個命盤", "命式を共有", "명식 공유", "Chia sẻ lá số", "แบ่งปันดวง"),
  pick: L("Choose a saved profile", "选择已保存的档案", "選擇已保存的檔案", "保存したプロフィールを選ぶ", "저장한 프로필 선택", "Chọn hồ sơ đã lưu", "เลือกโปรไฟล์ที่บันทึก"),
  noProfiles: L("You have no saved profiles yet. Add one under Profiles first.", "你还没有保存档案，请先在「我的档案」里添加。", "你還沒有保存檔案，請先在「我的檔案」裡添加。", "保存したプロフィールがありません。先に「プロフィール」で追加してください。", "저장한 프로필이 없어요. 먼저 '내 프로필'에서 추가하세요.", "Bạn chưa có hồ sơ. Hãy thêm trong mục Hồ sơ trước.", "ยังไม่มีโปรไฟล์ โปรดเพิ่มในหน้าโปรไฟล์ก่อน"),
  consent: L("I have this person's permission. Everyone in this room will see their birth date, time and chart.", "我已征得本人同意。静室里的每个人都能看到他的出生日期、时间和命盘。", "我已徵得本人同意。靜室裡的每個人都能看到他的出生日期、時間和命盤。", "本人の同意を得ています。この部屋の全員が生年月日・時刻・命式を見られます。", "본인의 동의를 받았습니다. 이 방의 모든 사람이 생년월일·시각·명식을 볼 수 있습니다.", "Tôi đã được người này đồng ý. Mọi người trong phòng sẽ thấy ngày giờ sinh và lá số.", "ฉันได้รับอนุญาตจากเจ้าของดวงแล้ว ทุกคนในห้องจะเห็นวันเวลาเกิดและดวง"),
  doShare: L("Share to this room", "分享到静室", "分享到靜室", "この部屋に共有", "이 방에 공유", "Chia sẻ vào phòng", "แบ่งปันเข้าห้อง"),
  sharedBy: L("shared by {n}", "{n} 分享", "{n} 分享", "{n} が共有", "{n} 공유", "{n} chia sẻ", "แบ่งปันโดย {n}"),
  view: L("Study this chart", "看命盘与人生K线", "看命盤與人生K線", "命式と人生Kラインを見る", "명식과 인생 K라인 보기", "Xem lá số và biểu đồ nến", "ดูดวงและกราฟชีวิต"),
  hide: L("Hide", "收起", "收起", "閉じる", "접기", "Thu gọn", "ซ่อน"),
  remove: L("Remove", "移除", "移除", "削除", "삭제", "Gỡ", "ลบ"),
  removeMember: L("Remove from room", "请出静室", "請出靜室", "部屋から外す", "방에서 내보내기", "Mời ra khỏi phòng", "เชิญออกจากห้อง"),
  leave: L("Leave this room", "退出静室", "退出靜室", "退室する", "방 나가기", "Rời phòng", "ออกจากห้อง"),
  close: L("Close the room (deletes everything in it)", "关闭静室（里面的内容全部删除）", "關閉靜室（裡面的內容全部刪除）", "部屋を閉じる（中身はすべて削除）", "방 닫기(모든 내용 삭제)", "Đóng phòng (xóa toàn bộ)", "ปิดห้อง (ลบทุกอย่างในห้อง)"),
  confirmClose: L("Close this room for everyone?", "确定关闭静室？所有成员都会离开。", "確定關閉靜室？所有成員都會離開。", "全員に対してこの部屋を閉じますか？", "모두에게 이 방을 닫을까요?", "Đóng phòng này với mọi người?", "ปิดห้องนี้สำหรับทุกคน?"),
  joinTitle: L("You are invited to a quiet room", "你被邀请进入静室", "你被邀請進入靜室", "静室に招待されています", "정실에 초대되었습니다", "Bạn được mời vào tịnh thất", "คุณได้รับเชิญเข้าห้องสงบ"),
  join: L("Join", "加入静室", "加入靜室", "参加する", "참여하기", "Tham gia", "เข้าร่วม"),
  signInFirst: L("Sign in or create an account to join.", "请先登录或注册，再加入静室。", "請先登入或註冊，再加入靜室。", "参加するにはログインまたは登録してください。", "참여하려면 로그인하거나 가입하세요.", "Hãy đăng nhập hoặc đăng ký để tham gia.", "โปรดเข้าสู่ระบบหรือสมัครก่อนเข้าร่วม"),
  invalid: L("This invitation link is no longer valid.", "这个邀请链接已失效。", "這個邀請連結已失效。", "この招待リンクは無効です。", "이 초대 링크는 더 이상 유효하지 않습니다.", "Liên kết mời đã hết hiệu lực.", "ลิงก์เชิญนี้ใช้ไม่ได้แล้ว"),
  full: L("This room is full.", "这个静室已满。", "這個靜室已滿。", "この部屋は満員です。", "이 방은 가득 찼습니다.", "Phòng đã đủ người.", "ห้องนี้เต็มแล้ว"),
  back: L("All rooms", "全部静室", "全部靜室", "すべての部屋", "전체 방", "Tất cả phòng", "ห้องทั้งหมด"),
  privacy: L("Members appear only by their Taoist name. Emails and saved profiles stay private unless you share a chart.", "成员只显示道号，不显示邮箱；你保存的档案不会公开，除非你主动分享。", "成員只顯示道號，不顯示郵箱；你保存的檔案不會公開，除非你主動分享。", "メンバーは道号だけが表示されます。メールや保存したプロフィールは、共有しない限り公開されません。", "구성원은 도호만 표시됩니다. 이메일과 저장한 프로필은 직접 공유하지 않는 한 공개되지 않습니다.", "Thành viên chỉ hiện đạo hiệu. Email và hồ sơ đã lưu được giữ kín, trừ khi bạn chia sẻ.", "สมาชิกแสดงเพียงฉายา อีเมลและโปรไฟล์เป็นส่วนตัวเว้นแต่คุณจะแบ่งปัน"),
  failed: L("Something went wrong. Please try again.", "操作没有成功，请再试一次。", "操作沒有成功，請再試一次。", "うまくいきませんでした。もう一度お試しください。", "실패했습니다. 다시 시도해 주세요.", "Không thành công, vui lòng thử lại.", "ไม่สำเร็จ โปรดลองอีกครั้ง"),
  nameRefused: L("That name can't be used.", "这个名字不能用。", "這個名字不能用。", "この名前は使えません。", "이 이름은 쓸 수 없어요.", "Không dùng được tên này.", "ใช้ชื่อนี้ไม่ได้"),
};

type RoomSummary = { id: string; name: string; role: string; members: number };
type RoomMember = { id: string; daoName: string; role: "owner" | "member"; self: boolean; online: boolean };
type RoomShare = { id: string; label: string; by: string; mine: boolean; chart: { date: string; time: string; calendar: "solar" | "lunar"; gender: "yin" | "yang"; leapMonth: boolean; timeKnown: boolean }; createdAt: string };
type Room = { id: string; name: string; role: "owner" | "member"; inviteToken: string | null; members: RoomMember[]; shares: RoomShare[] };
type Profile = { id: string; label: string; name: string; date: string };

async function api<T>(path: string, body?: unknown): Promise<{ ok: boolean; status: number; data: T & { error?: string; code?: string } }> {
  const response = await fetch(path, { method: body === undefined ? "GET" : "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) });
  const data = await response.json().catch(() => ({})) as T & { error?: string; code?: string };
  return { ok: response.ok, status: response.status, data };
}

function SharedChart({ share, locale }: { share: RoomShare; locale: Locale }) {
  const result = useMemo(() => {
    try { return createStudyResult({ birthDate: share.chart.date, birthTime: share.chart.time, calendar: share.chart.calendar, leapMonth: share.chart.leapMonth, gender: share.chart.gender, focus: "", name: share.label, companionName: "", module: "bazi", version: 1 }); } catch { return null; }
  }, [share]);
  if (!result) return null;
  const labels = { en: ["Year", "Month", "Day", "Hour"], "zh-Hans": ["年柱", "月柱", "日柱", "时柱"], "zh-Hant": ["年柱", "月柱", "日柱", "時柱"], ja: ["年柱", "月柱", "日柱", "時柱"], ko: ["연주", "월주", "일주", "시주"], vi: ["Trụ năm", "Trụ tháng", "Trụ ngày", "Trụ giờ"], th: ["เสาปี", "เสาเดือน", "เสาวัน", "เสายาม"] }[locale];
  return <div className="room-chart">
    <div className="room-pillars">{result.pillars.map((pillar, index) => <div key={index}><small>{labels[index]}</small><b>{localizeBoardTerm(pillar, locale)}</b></div>)}</div>
    <p className="room-chart-meta">{result.calendar.solar.slice(0, 16)} · {result.calendar.lunar}</p>
    {result.astro.luck && <LifeKLineChart pillars={result.pillars} birthYear={Number(result.calendar.solar.slice(0, 4))} luck={result.astro.luck} locale={locale} />}
  </div>;
}

export function MemberRooms({ locale, onOpenProfiles }: { locale: Locale; onOpenProfiles?: () => void }) {
  const t = (key: keyof typeof T) => T[key][locale];
  const [rooms, setRooms] = useState<RoomSummary[] | null>(null);
  const [room, setRoom] = useState<Room | null>(null);
  const [notice, setNotice] = useState("");
  const [invite, setInvite] = useState<{ token: string; name: string; members: number; full: boolean } | null | "invalid">(null);
  const [editing, setEditing] = useState<"" | "room" | "me">("");
  const [draft, setDraft] = useState("");
  const [sharing, setSharing] = useState(false);
  const [profiles, setProfiles] = useState<Profile[] | null>(null);
  const [profileId, setProfileId] = useState("");
  const [consent, setConsent] = useState(false);
  const [open, setOpen] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const loadRooms = useCallback(async () => { const result = await api<{ rooms: RoomSummary[] }>("/api/rooms"); setRooms(result.ok ? result.data.rooms : []); return result.ok ? result.data.rooms : []; }, []);
  const openRoom = useCallback(async (id: string) => { const result = await api<{ room: Room }>(`/api/rooms/${id}/heartbeat`, {}); if (result.ok) { setRoom(result.data.room); setNotice(""); } else setNotice(result.data.error ?? t("failed")); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    void loadRooms().then((list) => {
      const token = new URLSearchParams(window.location.search).get("room");
      if (token && /^[0-9a-f]{24}$/.test(token)) {
        void api<{ room: { id: string; name: string; members: number; full: boolean } }>(`/api/rooms/invite/${token}`).then((result) => {
          if (!result.ok) { setInvite("invalid"); return; }
          if (list.some((item) => item.id === result.data.room.id)) { void openRoom(result.data.room.id); return; }
          setInvite({ token, ...result.data.room });
        });
      } else if (list.length === 1) void openRoom(list[0].id);
    });
  }, [loadRooms, openRoom]);

  // Presence in the room: refresh every 20 s while the room is open and the page visible.
  useEffect(() => {
    if (!room) return;
    const id = room.id;
    const timer = setInterval(() => { if (!document.hidden) void openRoom(id); }, 20_000);
    return () => clearInterval(timer);
  }, [room?.id, openRoom]); // eslint-disable-line react-hooks/exhaustive-deps

  const act = async (action: string, body: Record<string, unknown> = {}) => {
    if (!room) return false;
    const result = await api<{ room?: Room; rooms?: RoomSummary[] }>(`/api/rooms/${room.id}/${action}`, body);
    if (!result.ok) { setNotice(result.data.code === "NAME_REFUSED" ? t("nameRefused") : result.data.error ?? t("failed")); return false; }
    if (result.data.room) setRoom(result.data.room);
    if (result.data.rooms) { setRoom(null); setRooms(result.data.rooms); }
    setNotice("");
    return true;
  };
  const create = async () => { const result = await api<{ room: Room }>("/api/rooms/create", {}); if (result.ok) { setRoom(result.data.room); void loadRooms(); } else setNotice(result.data.error ?? t("failed")); };
  const join = async (token: string) => {
    const result = await api<{ room: Room }>("/api/rooms/join", { token });
    if (result.ok) { setInvite(null); setRoom(result.data.room); void loadRooms(); try { window.history.replaceState(null, "", `${window.location.pathname}?tab=rooms`); } catch { /* ignore */ } }
    else setNotice(result.data.code === "ROOM_FULL" ? t("full") : result.data.error ?? t("failed"));
  };
  const startShare = async () => {
    setSharing(true); setConsent(false); setProfileId("");
    const result = await api<{ profiles: Profile[] }>("/api/member/profiles");
    setProfiles(result.ok ? result.data.profiles : []);
  };
  const inviteUrl = room?.inviteToken && typeof window !== "undefined" ? `${window.location.origin}${pathFor(locale, "membership")}?tab=rooms&room=${room.inviteToken}` : "";

  if (invite === "invalid") return <section className="mc-card room-card"><p>{t("invalid")}</p></section>;
  if (invite) return <section className="mc-card room-card room-join">
    <small>{t("joinTitle")}</small>
    <h3>{invite.name}</h3>
    <p>{t("members").replace("{n}", String(invite.members))}</p>
    {invite.full ? <p className="mc-inline is-error">{t("full")}</p> : <button type="button" className="primary-action" onClick={() => void join(invite.token)}>{t("join")}<b>↗</b></button>}
    <p className="room-privacy">{t("privacy")}</p>
    {notice && <p className="mc-inline is-error" role="status">{notice}</p>}
  </section>;

  if (!room) return <section className="mc-card room-card">
    <header><h3>{t("title")}</h3><p>{t("lead")}</p></header>
    {rooms && rooms.length > 0 && <div className="room-list"><small>{t("myRooms")}</small>{rooms.map((item) => <button type="button" key={item.id} onClick={() => void openRoom(item.id)}><b>{item.name}</b><span>{item.role === "owner" ? `${t("owner")} · ` : ""}{t("members").replace("{n}", String(item.members))}</span><em>→</em></button>)}</div>}
    {rooms && !rooms.some((item) => item.role === "owner") && <button type="button" className="primary-action" onClick={() => void create()}>{t("create")}<b>↗</b></button>}
    <p className="room-privacy">{t("privacy")}</p>
    {notice && <p className="mc-inline is-error" role="status">{notice}</p>}
  </section>;

  const me = room.members.find((member) => member.self);
  const onlineCount = room.members.filter((member) => member.online).length;
  return <section className="mc-card room-card room-view">
    <div className="room-top">
      {rooms && rooms.length > 1 && <button type="button" className="text-action" onClick={() => setRoom(null)}>← {t("back")}</button>}
      {editing === "room" ? <form className="room-inline" onSubmit={(event) => { event.preventDefault(); void act("rename", { name: draft }).then((ok) => { if (ok) setEditing(""); }); }}><input value={draft} maxLength={16} onChange={(event) => setDraft(event.target.value)} autoFocus /><button type="submit" className="secondary-action">{t("save")}</button><button type="button" className="text-action" onClick={() => setEditing("")}>{t("cancel")}</button></form>
        : <h3>{room.name}{room.role === "owner" && <button type="button" className="text-action" onClick={() => { setDraft(room.name); setEditing("room"); }}>{t("rename")}</button>}</h3>}
      <p>{t("members").replace("{n}", String(room.members.length))} · <span className="room-online-dot" />{onlineCount} {t("online")}</p>
    </div>

    <div className="room-circle" aria-label={t("members").replace("{n}", String(room.members.length))}>
      <div className="room-taiji" aria-hidden="true" />
      {room.members.map((member, index) => {
        const angle = (index / Math.max(1, room.members.length)) * Math.PI * 2 - Math.PI / 2;
        return <div key={member.id} className={`room-seat${member.online ? " is-online" : ""}${member.self ? " is-self" : ""}`} style={{ left: `${50 + Math.cos(angle) * 40}%`, top: `${50 + Math.sin(angle) * 40}%` }}>
          <MemberAvatar seed={member.id} className="room-avatar" />
          <b>{member.daoName}</b>
          <small>{member.role === "owner" ? t("owner") : member.online ? t("online") : ""}</small>
          {room.role === "owner" && !member.self && <button type="button" className="room-remove" onClick={() => void act("remove", { memberId: member.id })} aria-label={`${t("removeMember")} ${member.daoName}`}>×</button>}
        </div>;
      })}
    </div>

    {me && <div className="room-me">{t("myName")}：{editing === "me"
      ? <form className="room-inline" onSubmit={(event) => { event.preventDefault(); void act("me", { daoName: draft }).then((ok) => { if (ok) setEditing(""); }); }}><input value={draft} maxLength={20} onChange={(event) => setDraft(event.target.value)} autoFocus /><button type="submit" className="secondary-action">{t("save")}</button><button type="button" className="text-action" onClick={() => setEditing("")}>{t("cancel")}</button></form>
      : <><b>{me.daoName}</b><button type="button" className="text-action" onClick={() => { setDraft(me.daoName); setEditing("me"); }}>{t("change")}</button></>}</div>}

    {room.inviteToken && <div className="room-invite">
      <small>{t("invite")}</small>
      <div><code>{inviteUrl}</code><button type="button" className="secondary-action" onClick={() => { void navigator.clipboard?.writeText(inviteUrl).then(() => { setCopied(true); setTimeout(() => setCopied(false), 1800); }); }}>{copied ? t("copied") : t("copy")}</button></div>
      <p>{t("inviteLead")}</p>
      <button type="button" className="text-action" onClick={() => void act("reset-link")}>{t("resetLink")}</button>
    </div>}

    <div className="room-shares">
      <header><h4>{t("shares")}</h4>{!sharing && <button type="button" className="secondary-action" onClick={() => void startShare()}>{t("share")}</button>}</header>
      {sharing && <div className="room-share-form">
        {profiles === null ? <p>…</p> : profiles.length === 0 ? <p>{t("noProfiles")} {onOpenProfiles && <button type="button" className="text-action" onClick={onOpenProfiles}>→</button>}</p> : <>
          <label><span>{t("pick")}</span><select value={profileId} onChange={(event) => setProfileId(event.target.value)}><option value="">—</option>{profiles.map((profile) => <option key={profile.id} value={profile.id}>{profile.name || profile.label} · {profile.date}</option>)}</select></label>
          <label className="room-consent"><input type="checkbox" checked={consent} onChange={(event) => setConsent(event.target.checked)} /><span>{t("consent")}</span></label>
          <div><button type="button" className="primary-action" disabled={!profileId || !consent} onClick={() => void act("share", { profileId, consent: true }).then((ok) => { if (ok) setSharing(false); })}>{t("doShare")}<b>↗</b></button><button type="button" className="text-action" onClick={() => setSharing(false)}>{t("cancel")}</button></div>
        </>}
      </div>}
      {room.shares.length === 0 ? <p className="room-empty">{t("noShares")}</p> : room.shares.map((share) => <article key={share.id} className="room-share">
        <div className="room-share-head"><b>{share.label}</b><small>{t("sharedBy").replace("{n}", share.by)} · {share.chart.date}</small>
          <span><button type="button" className="text-action" onClick={() => setOpen(open === share.id ? null : share.id)}>{open === share.id ? t("hide") : t("view")}</button>
          {(share.mine || room.role === "owner") && <button type="button" className="text-action" onClick={() => void act("unshare", { shareId: share.id })}>{t("remove")}</button>}</span></div>
        {open === share.id && <SharedChart share={share} locale={locale} />}
      </article>)}
    </div>

    <div className="room-foot">
      <p className="room-privacy">{t("privacy")}</p>
      {room.role === "owner"
        ? <button type="button" className="text-action room-danger" onClick={() => { if (window.confirm(t("confirmClose"))) void act("leave"); }}>{t("close")}</button>
        : <button type="button" className="text-action room-danger" onClick={() => void act("leave")}>{t("leave")}</button>}
    </div>
    {notice && <p className="mc-inline is-error" role="status">{notice}</p>}
  </section>;
}
