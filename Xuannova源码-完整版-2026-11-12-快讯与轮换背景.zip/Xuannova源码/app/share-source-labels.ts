import type { Locale } from "./site-content";
type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

export const sourceLabels: Record<string, L7> = {
  "daily-card": L("Daily colour card", "五行穿搭日签", "五行穿搭日籤", "五行コーデ日めくり", "오행 코디 카드", "Thiệp màu may mắn", "การ์ดสีมงคล"),
  "action-card": L("Action guide (home)", "今日行动指南（首页）", "今日行動指南（首頁）", "行動ガイド（ホーム）", "행동 가이드(홈)", "Hướng dẫn hành động (trang chủ)", "คู่มือวันนี้ (หน้าแรก)"),
  "almanac-card": L("Almanac day card", "黄历海报（黄历页）", "黃曆海報（黃曆頁）", "暦ポスター", "역서 포스터", "Thiệp lịch", "โปสเตอร์ปฏิทิน"),
  "lamp-card": L("Prayer lamp card", "祈福灯海报", "祈福燈海報", "祈りの灯ポスター", "기원등 포스터", "Thiệp đèn cầu phúc", "โปสเตอร์โคมอธิษฐาน"),
  "chart-card": L("Chart / reading card", "命盘解读海报", "命盤解讀海報", "命盤ポスター", "명반 포스터", "Thiệp lá số", "โปสเตอร์ผังดวง"),
  "flash-card": L("Xuannova Flash", "Xuannova 快讯", "Xuannova 快訊", "Xuannova 速報", "Xuannova 속보", "Tin nhanh Xuannova", "ข่าวด่วน Xuannova"),
  "invite-link": L("Invitation link", "邀请链接", "邀請連結", "招待リンク", "초대 링크", "Liên kết mời", "ลิงก์เชิญ"),
  other: L("Other / direct", "其他（直接注册等）", "其他（直接註冊等）", "その他", "기타", "Khác", "อื่น ๆ"),
};
export const sourceLabel = (source: string, locale: Locale) => (sourceLabels[source] ?? sourceLabels.other)[locale];

export const shareReportText = {
  title: L("Which posters bring people in", "哪种海报带来的人最多", "哪種海報帶來的人最多", "どのポスターが人を呼んでいるか", "어떤 포스터가 사람을 데려오나", "Ảnh nào mang người đến nhiều nhất", "โปสเตอร์ไหนพาคนมามากที่สุด"),
  hint: L("Last 30 days. Counts only, no personal data. Sign-ups are credited to the first shared poster or link the person opened on that device.", "最近 30 天。只计数，不记录个人信息。注册来源按此人在该设备上第一次打开的分享海报或链接计算。", "最近 30 天。只計數，不記錄個人資訊。註冊來源按此人在該裝置上第一次打開的分享海報或連結計算。", "直近30日。件数のみで個人情報は保存しません。登録は、その端末で最初に開いた共有ポスター／リンクに計上します。", "최근 30일. 건수만 집계하며 개인정보는 저장하지 않습니다. 가입은 그 기기에서 처음 연 공유 포스터/링크로 집계됩니다.", "30 ngày qua. Chỉ đếm số, không lưu dữ liệu cá nhân. Đăng ký được tính cho ảnh/liên kết chia sẻ đầu tiên mở trên thiết bị đó.", "30 วันล่าสุด นับจำนวนเท่านั้น ไม่เก็บข้อมูลส่วนตัว การสมัครนับตามโปสเตอร์/ลิงก์แรกที่เปิดบนอุปกรณ์นั้น"),
  source: L("Source", "来源", "來源", "流入元", "출처", "Nguồn", "แหล่งที่มา"),
  made: L("Made", "生成", "產生", "作成", "생성", "Tạo", "สร้าง"),
  saved: L("Saved", "保存", "儲存", "保存", "저장", "Lưu", "บันทึก"),
  shared: L("Shared", "分享", "分享", "シェア", "공유", "Chia sẻ", "แชร์"),
  visits: L("Visits", "扫码/点开", "掃碼/點開", "訪問", "방문", "Lượt mở", "เข้าชม"),
  signups: L("Sign-ups", "注册", "註冊", "登録", "가입", "Đăng ký", "สมัคร"),
  invited: L("With invite code", "带邀请码", "帶邀請碼", "招待コード付き", "초대코드 가입", "Có mã mời", "มีรหัสเชิญ"),
  buyers: L("Bought", "已购买", "已購買", "購入", "구매", "Đã mua", "ซื้อแล้ว"),
  mySources: L("Where they came from", "他们从哪里来", "他們從哪裡來", "どこから来たか", "어디서 왔나", "Họ đến từ đâu", "มาจากไหน"),
};
