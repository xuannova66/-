"use client";

import { useState } from "react";
import type { Locale } from "./site-content";
import { AdminGrowthTools, adminGrowthTabLabels } from "./admin-growth-tools";
import { AdminWorkshop, workshopTabLabel } from "./admin-workshop";
import { AdminFlash, flashTabLabel } from "./admin-flash";

type AdminOrder = { id: string; memberEmail: string; buyerAddress: string | null; amountUsdt: string; settlementCurrency?: "USDT" | "USDC"; credits: number; network: string; transactionHash: string; status: "pending" | "approved" | "rejected"; submittedAt: string; reviewNote: string | null };
type AdminOverview = { memberCount: number; outstandingCredits: number; pendingOrderCount: number; invitationCount: number; invitationCredits: number };
type AdminMember = { id: string; email: string | null; walletAddress: string | null; balance: number; inviteCode: string | null; invitedByMemberId: string | null; createdAt: string; updatedAt: string };
type Invitation = { inviterId: string; inviterEmail: string; inviteCode: string | null; inviteeId: string; inviteeEmail: string; joinedAt: string; inviterReward: number; inviteeReward: number };
type LedgerEntry = { id: string; memberId: string; memberEmail: string; orderId: string | null; delta: number; balanceAfter: number; reason: string; createdAt: string };
type AdminReading = { id: string; member: string; tool: string; question: string; response: { summary: string }; cost: number; createdAt: string };
type AdminTab = "overview" | "orders" | "members" | "invitations" | "ledger" | "readings" | "groups" | "packages" | "grants" | "lectures" | "teams" | "workshop" | "flash";

type AdminCopy = {
  eyebrow: string; title: string; lead: string; email: string; password: string; enter: string; refresh: string; signedIn: string; pending: string; approved: string; rejected: string; approve: string; reject: string; hash: string; noOrders: string; noData: string;
  overview: string; orders: string; members: string; invitations: string; ledger: string; memberCount: string; outstandingCredits: string; pendingOrderCount: string; invitationCount: string; invitationCredits: string;
  orderReview: string; memberSearch: string; search: string; memberBalance: string; inviteCode: string; inviter: string; joinedMember: string; joinedAt: string; reward: string; ledgerReason: string; balanceAfter: string; occurredAt: string;
  adjustCredits: string; selectedMember: string; delta: string; adjustmentNote: string; saveAdjustment: string; cancel: string; adjustmentHint: string; adjusted: string;
  reason: { invitationJoin: string; invitationShare: string; paymentApproval: string; adminAdjustment: string; interpretation: string; other: string };
};

const copy: Record<Locale, AdminCopy> = {
  en: {
    eyebrow: "OWNER OPERATIONS", title: "Operations console", lead: "Review payments, member balances, invitations, and every credit movement from one protected workspace.", email: "Administrator email", password: "Administrator password", enter: "Enter console", refresh: "Refresh data", signedIn: "Administrator session active", pending: "Pending", approved: "Approved", rejected: "Rejected", approve: "Approve & issue credits", reject: "Reject", hash: "Transaction hash", noOrders: "No submitted payment orders.", noData: "No records to show.",
    overview: "Overview", orders: "Payments", members: "Members", invitations: "Invitations", ledger: "Credit ledger", memberCount: "Members", outstandingCredits: "Outstanding credits", pendingOrderCount: "Pending payments", invitationCount: "Successful invitations", invitationCredits: "Invitation credits issued",
    orderReview: "Payment review", memberSearch: "Search wallet address or email", search: "Search", memberBalance: "Balance", inviteCode: "Invite code", inviter: "Inviter", joinedMember: "New member", joinedAt: "Joined", reward: "Reward", ledgerReason: "Reason", balanceAfter: "Balance after", occurredAt: "Recorded", adjustCredits: "Adjust credits", selectedMember: "Selected member", delta: "Credit change", adjustmentNote: "Internal note", saveAdjustment: "Save adjustment", cancel: "Cancel", adjustmentHint: "Enter a whole number. Negative numbers deduct credits; a balance can never fall below zero.", adjusted: "Credit adjustment recorded.",
    reason: { invitationJoin: "Joined with invitation", invitationShare: "Invitation reward", paymentApproval: "Payment approval", adminAdjustment: "Administrator adjustment", interpretation: "Interpretation", other: "Other credit event" },
  },
  "zh-Hans": {
    eyebrow: "站主运营后台", title: "运营管理台", lead: "在一个受保护的空间内审核订单、查看会员积分、邀请关系与全部积分流水。", email: "管理员邮箱", password: "管理员密码", enter: "进入后台", refresh: "刷新数据", signedIn: "管理员会话已生效", pending: "待审核", approved: "已批准", rejected: "已拒绝", approve: "批准并发放积分", reject: "拒绝", hash: "交易哈希", noOrders: "暂无提交的支付订单。", noData: "暂无可显示的记录。",
    overview: "总览", orders: "支付订单", members: "会员", invitations: "邀请奖励", ledger: "积分流水", memberCount: "会员总数", outstandingCredits: "现有积分", pendingOrderCount: "待审核订单", invitationCount: "成功邀请", invitationCredits: "已发邀请积分",
    orderReview: "支付审核", memberSearch: "搜索钱包地址或邮箱", search: "搜索", memberBalance: "积分余额", inviteCode: "邀请码", inviter: "邀请人", joinedMember: "新会员", joinedAt: "注册时间", reward: "奖励", ledgerReason: "来源", balanceAfter: "变动后余额", occurredAt: "记录时间", adjustCredits: "调整积分", selectedMember: "已选会员", delta: "积分变动", adjustmentNote: "内部备注", saveAdjustment: "保存调整", cancel: "取消", adjustmentHint: "请输入整数。负数扣除积分；余额不会低于 0。", adjusted: "积分调整已记录。",
    reason: { invitationJoin: "受邀注册奖励", invitationShare: "邀请成功奖励", paymentApproval: "支付订单批准", adminAdjustment: "管理员调整", interpretation: "工具解读", other: "其他积分事件" },
  },
  "zh-Hant": {
    eyebrow: "站主營運後台", title: "營運管理台", lead: "在受保護的空間內審核訂單、查看會員積分、邀請關係與全部積分流水。", email: "管理員信箱", password: "管理員密碼", enter: "進入後台", refresh: "重新整理資料", signedIn: "管理員工作階段已生效", pending: "待審核", approved: "已核准", rejected: "已拒絕", approve: "核准並發放積分", reject: "拒絕", hash: "交易雜湊", noOrders: "暫無提交的付款訂單。", noData: "暫無可顯示的紀錄。",
    overview: "總覽", orders: "付款訂單", members: "會員", invitations: "邀請獎勵", ledger: "積分流水", memberCount: "會員總數", outstandingCredits: "現有積分", pendingOrderCount: "待審核訂單", invitationCount: "成功邀請", invitationCredits: "已發邀請積分",
    orderReview: "付款審核", memberSearch: "搜尋錢包地址或信箱", search: "搜尋", memberBalance: "積分餘額", inviteCode: "邀請碼", inviter: "邀請人", joinedMember: "新會員", joinedAt: "註冊時間", reward: "獎勵", ledgerReason: "來源", balanceAfter: "變動後餘額", occurredAt: "紀錄時間", adjustCredits: "調整積分", selectedMember: "已選會員", delta: "積分變動", adjustmentNote: "內部備註", saveAdjustment: "儲存調整", cancel: "取消", adjustmentHint: "請輸入整數。負數扣除積分；餘額不會低於 0。", adjusted: "積分調整已記錄。",
    reason: { invitationJoin: "受邀註冊獎勵", invitationShare: "邀請成功獎勵", paymentApproval: "付款訂單核准", adminAdjustment: "管理員調整", interpretation: "工具解讀", other: "其他積分事件" },
  },
  ja: {
    eyebrow: "運営管理", title: "運営コンソール", lead: "保護された管理画面で、決済、会員残高、招待関係、すべてのクレジット履歴を確認できます。", email: "管理者メール", password: "管理者パスワード", enter: "コンソールに入る", refresh: "データを更新", signedIn: "管理者セッションが有効です", pending: "審査待ち", approved: "承認済み", rejected: "却下", approve: "承認してクレジットを付与", reject: "却下", hash: "トランザクションハッシュ", noOrders: "送信された支払い注文はありません。", noData: "表示する記録はありません。",
    overview: "概要", orders: "支払い", members: "会員", invitations: "招待報酬", ledger: "クレジット履歴", memberCount: "会員数", outstandingCredits: "保有クレジット", pendingOrderCount: "未審査の支払い", invitationCount: "成功した招待", invitationCredits: "付与済み招待クレジット",
    orderReview: "支払い審査", memberSearch: "ウォレットアドレスまたはメールを検索", search: "検索", memberBalance: "残高", inviteCode: "招待コード", inviter: "招待者", joinedMember: "新規会員", joinedAt: "登録日時", reward: "報酬", ledgerReason: "理由", balanceAfter: "変更後の残高", occurredAt: "記録日時", adjustCredits: "クレジットを調整", selectedMember: "選択中の会員", delta: "クレジット変更", adjustmentNote: "内部メモ", saveAdjustment: "調整を保存", cancel: "キャンセル", adjustmentHint: "整数を入力してください。負の数は差し引きです。残高は 0 未満になりません。", adjusted: "クレジット調整を記録しました。",
    reason: { invitationJoin: "招待登録報酬", invitationShare: "招待成功報酬", paymentApproval: "支払い承認", adminAdjustment: "管理者調整", interpretation: "解読ツール", other: "その他のクレジット処理" },
  },
  ko: {
    eyebrow: "운영 관리", title: "운영자 콘솔", lead: "보호된 관리 공간에서 결제, 회원 잔액, 초대 관계 및 모든 크레딧 기록을 확인합니다.", email: "관리자 이메일", password: "관리자 비밀번호", enter: "콘솔 입장", refresh: "데이터 새로고침", signedIn: "관리자 세션이 활성화되었습니다", pending: "검토 대기", approved: "승인됨", rejected: "거절됨", approve: "승인하고 크레딧 지급", reject: "거절", hash: "거래 해시", noOrders: "제출된 결제 주문이 없습니다.", noData: "표시할 기록이 없습니다.",
    overview: "개요", orders: "결제", members: "회원", invitations: "초대 보상", ledger: "크레딧 내역", memberCount: "회원 수", outstandingCredits: "보유 크레딧", pendingOrderCount: "검토 대기 결제", invitationCount: "성공한 초대", invitationCredits: "지급된 초대 크레딧",
    orderReview: "결제 검토", memberSearch: "지갑 주소 또는 이메일 검색", search: "검색", memberBalance: "잔액", inviteCode: "초대 코드", inviter: "초대한 회원", joinedMember: "신규 회원", joinedAt: "가입 시간", reward: "보상", ledgerReason: "사유", balanceAfter: "변경 후 잔액", occurredAt: "기록 시간", adjustCredits: "크레딧 조정", selectedMember: "선택한 회원", delta: "크레딧 변경", adjustmentNote: "내부 메모", saveAdjustment: "조정 저장", cancel: "취소", adjustmentHint: "정수를 입력하세요. 음수는 크레딧을 차감하며 잔액은 0 미만이 될 수 없습니다.", adjusted: "크레딧 조정이 기록되었습니다.",
    reason: { invitationJoin: "초대 가입 보상", invitationShare: "초대 성공 보상", paymentApproval: "결제 승인", adminAdjustment: "관리자 조정", interpretation: "해석 도구", other: "기타 크레딧 처리" },
  },
  vi: {
    eyebrow: "VẬN HÀNH CHỦ SỞ HỮU", title: "Bảng điều khiển vận hành", lead: "Kiểm tra thanh toán, số dư thành viên, quan hệ mời và mọi biến động điểm trong một khu vực được bảo vệ.", email: "Email quản trị", password: "Mật khẩu quản trị", enter: "Vào bảng điều khiển", refresh: "Làm mới dữ liệu", signedIn: "Phiên quản trị đang hoạt động", pending: "Chờ duyệt", approved: "Đã duyệt", rejected: "Đã từ chối", approve: "Duyệt và cấp điểm", reject: "Từ chối", hash: "Mã băm giao dịch", noOrders: "Không có đơn thanh toán nào đã gửi.", noData: "Không có dữ liệu để hiển thị.",
    overview: "Tổng quan", orders: "Thanh toán", members: "Thành viên", invitations: "Thưởng mời", ledger: "Sổ điểm", memberCount: "Thành viên", outstandingCredits: "Điểm hiện có", pendingOrderCount: "Thanh toán chờ duyệt", invitationCount: "Lời mời thành công", invitationCredits: "Điểm mời đã cấp",
    orderReview: "Duyệt thanh toán", memberSearch: "Tìm địa chỉ ví hoặc email", search: "Tìm", memberBalance: "Số dư", inviteCode: "Mã mời", inviter: "Người mời", joinedMember: "Thành viên mới", joinedAt: "Thời điểm tham gia", reward: "Thưởng", ledgerReason: "Lý do", balanceAfter: "Số dư sau", occurredAt: "Thời điểm ghi nhận", adjustCredits: "Điều chỉnh điểm", selectedMember: "Thành viên đã chọn", delta: "Thay đổi điểm", adjustmentNote: "Ghi chú nội bộ", saveAdjustment: "Lưu điều chỉnh", cancel: "Hủy", adjustmentHint: "Nhập số nguyên. Số âm sẽ trừ điểm; số dư không bao giờ thấp hơn 0.", adjusted: "Đã ghi nhận điều chỉnh điểm.",
    reason: { invitationJoin: "Thưởng đăng ký qua lời mời", invitationShare: "Thưởng mời thành công", paymentApproval: "Duyệt thanh toán", adminAdjustment: "Điều chỉnh của quản trị viên", interpretation: "Công cụ diễn giải", other: "Sự kiện điểm khác" },
  },
  th: {
    eyebrow: "การดำเนินงานเจ้าของ", title: "คอนโซลการดำเนินงาน", lead: "ตรวจสอบการชำระเงิน ยอดเครดิตสมาชิก ความสัมพันธ์การเชิญ และรายการเครดิตทั้งหมดในพื้นที่ที่ได้รับการปกป้อง", email: "อีเมลผู้ดูแล", password: "รหัสผ่านผู้ดูแล", enter: "เข้าสู่คอนโซล", refresh: "รีเฟรชข้อมูล", signedIn: "เซสชันผู้ดูแลใช้งานอยู่", pending: "รอตรวจสอบ", approved: "อนุมัติแล้ว", rejected: "ปฏิเสธแล้ว", approve: "อนุมัติและเพิ่มเครดิต", reject: "ปฏิเสธ", hash: "แฮชธุรกรรม", noOrders: "ไม่มีคำสั่งชำระเงินที่ส่งมา", noData: "ไม่มีข้อมูลให้แสดง",
    overview: "ภาพรวม", orders: "การชำระเงิน", members: "สมาชิก", invitations: "รางวัลการเชิญ", ledger: "บัญชีเครดิต", memberCount: "จำนวนสมาชิก", outstandingCredits: "เครดิตคงเหลือ", pendingOrderCount: "การชำระเงินรอตรวจสอบ", invitationCount: "การเชิญสำเร็จ", invitationCredits: "เครดิตจากการเชิญที่ออกแล้ว",
    orderReview: "ตรวจสอบการชำระเงิน", memberSearch: "ค้นหาที่อยู่กระเป๋าเงินหรืออีเมล", search: "ค้นหา", memberBalance: "ยอดคงเหลือ", inviteCode: "รหัสเชิญ", inviter: "ผู้เชิญ", joinedMember: "สมาชิกใหม่", joinedAt: "เวลาสมัคร", reward: "รางวัล", ledgerReason: "เหตุผล", balanceAfter: "ยอดหลังรายการ", occurredAt: "เวลาที่บันทึก", adjustCredits: "ปรับเครดิต", selectedMember: "สมาชิกที่เลือก", delta: "การเปลี่ยนแปลงเครดิต", adjustmentNote: "หมายเหตุภายใน", saveAdjustment: "บันทึกการปรับ", cancel: "ยกเลิก", adjustmentHint: "ใส่จำนวนเต็ม ค่าลบจะหักเครดิต และยอดคงเหลือจะไม่ต่ำกว่า 0", adjusted: "บันทึกการปรับเครดิตแล้ว",
    reason: { invitationJoin: "รางวัลสมัครผ่านคำเชิญ", invitationShare: "รางวัลเชิญสำเร็จ", paymentApproval: "อนุมัติการชำระเงิน", adminAdjustment: "การปรับโดยผู้ดูแล", interpretation: "เครื่องมือวิเคราะห์", other: "รายการเครดิตอื่น" },
  },
};

function requestError(cause: unknown) {
  return cause instanceof Error ? cause.message : "Request failed";
}

async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(path, { credentials: "same-origin", headers: { "content-type": "application/json", ...(init?.headers ?? {}) }, ...init });
  const payload = await response.json() as T & { error?: string };
  if (!response.ok) throw new Error(payload.error ?? "Request failed");
  return payload;
}

// Old orders may predate the format check: flag a hash that cannot belong to its network before approval.
const hashLooksWrong = (network: string, hash: string) => (network === "trc20" ? !/^[0-9a-fA-F]{64}$/.test(hash) : network === "bsc" ? !/^0x[0-9a-fA-F]{64}$/.test(hash) : false);
const hashWarning: Record<Locale, string> = { en: "Hash format does not match this network — check on the explorer before approving.", "zh-Hans": "哈希格式与该网络不符，批准前请在区块浏览器核对。", "zh-Hant": "哈希格式與該網路不符，批准前請在區塊瀏覽器核對。", ja: "ハッシュ形式がこのネットワークと一致しません。承認前にエクスプローラーで確認してください。", ko: "해시 형식이 이 네트워크와 맞지 않습니다. 승인 전에 탐색기에서 확인하세요.", vi: "Định dạng mã không khớp với mạng này — hãy kiểm tra trên trình khám phá trước khi duyệt.", th: "รูปแบบแฮชไม่ตรงกับเครือข่ายนี้ โปรดตรวจสอบบน explorer ก่อนอนุมัติ" };

export function AdminConsole({ locale }: { locale: Locale }) {
  const text = copy[locale];
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [overview, setOverview] = useState<AdminOverview | null>(null);
  const [orders, setOrders] = useState<AdminOrder[] | null>(null);
  const [members, setMembers] = useState<AdminMember[]>([]);
  const [invitations, setInvitations] = useState<Invitation[]>([]);
  const [ledger, setLedger] = useState<LedgerEntry[]>([]);
  const [readings, setReadings] = useState<AdminReading[]>([]);
  const [tab, setTab] = useState<AdminTab>("overview");
  const [memberSearch, setMemberSearch] = useState("");
  const [selectedMember, setSelectedMember] = useState<AdminMember | null>(null);
  const [delta, setDelta] = useState("10");
  const [reason, setReason] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState("");

  const loadOperations = async (search = memberSearch) => {
    setBusy("load");
    try {
      const query = encodeURIComponent(search.trim());
      const [overviewResult, orderResult, memberResult, invitationResult, ledgerResult, readingResult] = await Promise.all([
        api<{ overview: AdminOverview }>("/api/admin/overview", { method: "GET", headers: {} }),
        api<{ orders: AdminOrder[] }>("/api/admin/orders", { method: "GET", headers: {} }),
        api<{ members: AdminMember[] }>(`/api/admin/members?search=${query}`, { method: "GET", headers: {} }),
        api<{ invitations: Invitation[] }>("/api/admin/invitations", { method: "GET", headers: {} }),
        api<{ entries: LedgerEntry[] }>("/api/admin/ledger", { method: "GET", headers: {} }),
        api<{ interpretations: AdminReading[] }>("/api/admin/interpretations", { method: "GET", headers: {} }),
      ]);
      setOverview(overviewResult.overview);
      setOrders(orderResult.orders);
      setMembers(memberResult.members);
      setInvitations(invitationResult.invitations);
      setLedger(ledgerResult.entries);
      setReadings(readingResult.interpretations);
    } catch (cause) {
      setNotice(requestError(cause));
    } finally {
      setBusy("");
    }
  };

  async function login(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy("login");
    setNotice("");
    try {
      await api("/api/auth/admin/login", { method: "POST", body: JSON.stringify({ email, password }) });
      setPassword("");
      await loadOperations("");
    } catch (cause) {
      setNotice(requestError(cause));
    } finally {
      setBusy("");
    }
  }

  async function decide(id: string, decision: "approve" | "reject") {
    setBusy(id);
    setNotice("");
    const body = decision === "approve" ? { decision: "approve" } : { decision: "reject" };
    try {
      await api(`/api/admin/orders/${id}/decision`, { method: "POST", body: JSON.stringify(body) });
      await loadOperations();
    } catch (cause) {
      setNotice(requestError(cause));
    } finally {
      setBusy("");
    }
  }

  async function adjustCredits(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedMember) return;
    const value = Number(delta);
    setBusy(`adjust:${selectedMember.id}`);
    setNotice("");
    try {
      await api(`/api/admin/members/${selectedMember.id}/credits`, { method: "POST", body: JSON.stringify({ delta: value, reason }) });
      setSelectedMember(null);
      setReason("");
      await loadOperations();
      setNotice(text.adjusted);
    } catch (cause) {
      setNotice(requestError(cause));
    } finally {
      setBusy("");
    }
  }

  function reasonLabel(value: string) {
    if (value === "invitation_purchase") return ({ en: "Invitation purchase reward", "zh-Hans": "邀请购买奖励", "zh-Hant": "邀請購買獎勵", ja: "招待購入報酬", ko: "초대 구매 보상", vi: "Thưởng mua hàng qua lời mời", th: "รางวัลการซื้อจากคำเชิญ" } as Record<Locale, string>)[locale];
    if (value === "invitation_join") return text.reason.invitationJoin;
    if (value === "invitation_share") return text.reason.invitationShare;
    if (value === "payment_approval") return text.reason.paymentApproval;
    if (value === "admin_adjustment") return text.reason.adminAdjustment;
    if (value.startsWith("interpretation:")) return text.reason.interpretation;
    if (value.startsWith("daily_login_bonus:")) return ({ en: "Daily bonus", "zh-Hans": "每日赠送", "zh-Hant": "每日贈送", ja: "毎日のボーナス", ko: "매일 보너스", vi: "Điểm tặng hằng ngày", th: "คะแนนรายวัน" } as Record<Locale, string>)[locale];
    if (value.startsWith("admin_grant:")) return ({ en: "Approved credit grant", "zh-Hans": "审批加积分", "zh-Hant": "審批加積分", ja: "承認済み付与", ko: "승인된 지급", vi: "Cộng điểm đã duyệt", th: "เพิ่มคะแนนที่อนุมัติแล้ว" } as Record<Locale, string>)[locale];
    return text.reason.other;
  }

  function formatDate(value: string) {
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? value : new Intl.DateTimeFormat(locale, { dateStyle: "medium", timeStyle: "short" }).format(parsed);
  }

  const readingLabels: Record<Locale, string> = { en: "Reading records", "zh-Hans": "解读记录", "zh-Hant": "解讀紀錄", ja: "鑑定履歴", ko: "해석 기록", vi: "Lịch sử luận giải", th: "ประวัติคำอธิบาย" };
  const growthLabels = adminGrowthTabLabels(locale);
  const tabs: Array<[AdminTab, string]> = [["overview", text.overview], ["orders", text.orders], ["members", text.members], ["invitations", text.invitations], ["ledger", text.ledger], ["readings", readingLabels[locale]], ["groups", growthLabels.groups], ["packages", growthLabels.packages], ["grants", growthLabels.grants], ["lectures", growthLabels.lectures], ["teams", growthLabels.teams], ["workshop", workshopTabLabel(locale)], ["flash", flashTabLabel(locale)]];

  return <section className="admin-console" data-testid="admin-console">
    <header className="route-heading"><p>{text.eyebrow}</p><h1>{text.title}</h1><p>{text.lead}</p></header>
    {orders === null ? <form onSubmit={login} className="admin-login-form"><label>{text.email}<input type="email" value={email} onChange={(event) => setEmail(event.target.value)} autoComplete="username" required /></label><label>{text.password}<input type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete="current-password" required /></label><button className="primary-action" type="submit" disabled={busy === "login"}>{text.enter}</button></form> : <>
      <header className="admin-session"><p>{text.signedIn}</p><button className="text-action" type="button" onClick={() => void loadOperations()} disabled={busy === "load"}>{text.refresh}</button></header>
      <nav className="admin-tabs" aria-label={text.title}>{tabs.map(([id, label]) => <button key={id} type="button" className={tab === id ? "active" : ""} onClick={() => setTab(id)}>{label}</button>)}</nav>
      {tab === "overview" && overview && <section className="admin-panel admin-overview" aria-label={text.overview}><dl><div><dt>{text.memberCount}</dt><dd>{overview.memberCount}</dd></div><div><dt>{text.outstandingCredits}</dt><dd>{overview.outstandingCredits}</dd></div><div><dt>{text.pendingOrderCount}</dt><dd>{overview.pendingOrderCount}</dd></div><div><dt>{text.invitationCount}</dt><dd>{overview.invitationCount}</dd></div><div><dt>{text.invitationCredits}</dt><dd>{overview.invitationCredits}</dd></div></dl></section>}
      {tab === "orders" && <section className="admin-panel admin-orders"><header><p>{text.orderReview}</p></header>{orders.length ? orders.map((order) => <article key={order.id} data-status={order.status}><div><b>{order.memberEmail}</b><small>{order.amountUsdt} {order.settlementCurrency ?? "USDT"} · {order.credits} · {order.network.toUpperCase()} · {formatDate(order.submittedAt)}</small><code>{text.hash}: {order.transactionHash}</code>{hashLooksWrong(order.network, order.transactionHash) && <em className="admin-warning">{hashWarning[locale]}</em>}</div><strong>{order.status === "pending" ? text.pending : order.status === "approved" ? text.approved : text.rejected}</strong>{order.status === "pending" && <aside><button type="button" className="primary-action" disabled={busy === order.id} onClick={() => void decide(order.id, "approve")}>{text.approve}</button><button type="button" className="text-action" disabled={busy === order.id} onClick={() => void decide(order.id, "reject")}>{text.reject}</button></aside>}</article>) : <p>{text.noOrders}</p>}</section>}
      {tab === "members" && <section className="admin-panel admin-members"><form className="admin-member-search" onSubmit={(event) => { event.preventDefault(); void loadOperations(memberSearch); }}><label>{text.memberSearch}<input value={memberSearch} onChange={(event) => setMemberSearch(event.target.value)} autoComplete="off" /></label><button className="text-action" type="submit" disabled={busy === "load"}>{text.search}</button></form><div className="admin-table"><div className="admin-table-head"><span>{text.members}</span><span>{text.memberBalance}</span><span>{text.inviteCode}</span><span /></div>{members.length ? members.map((member) => <article key={member.id}><div><b>{member.walletAddress ?? member.email}</b><small>{member.invitedByMemberId ? text.invitations : "—"}</small></div><strong>{member.balance}</strong><code>{member.inviteCode ?? "—"}</code><button className="text-action" type="button" onClick={() => { setSelectedMember(member); setDelta("10"); setReason(""); }}>{text.adjustCredits}</button></article>) : <p>{text.noData}</p>}</div>{selectedMember && <form className="admin-adjustment" onSubmit={adjustCredits}><header><span>{text.selectedMember}</span><b>{selectedMember.walletAddress ?? selectedMember.email}</b></header><label>{text.delta}<input type="number" value={delta} min="-10000" max="10000" step="1" onChange={(event) => setDelta(event.target.value)} required /></label><label>{text.adjustmentNote}<input value={reason} minLength={3} maxLength={240} onChange={(event) => setReason(event.target.value)} required /></label><p>{text.adjustmentHint}</p><aside><button className="primary-action" type="submit" disabled={busy === `adjust:${selectedMember.id}`}>{text.saveAdjustment}</button><button className="text-action" type="button" onClick={() => setSelectedMember(null)}>{text.cancel}</button></aside></form>}</section>}
      {tab === "invitations" && <section className="admin-panel admin-table"><div className="admin-table-head admin-invitation-head"><span>{text.inviter}</span><span>{text.joinedMember}</span><span>{text.reward}</span><span>{text.joinedAt}</span></div>{invitations.length ? invitations.map((invitation) => <article key={invitation.inviteeId}><div><b>{invitation.inviterEmail}</b><code>{invitation.inviteCode ?? "—"}</code></div><div><b>{invitation.inviteeEmail}</b></div><strong>+{invitation.inviterReward} / +{invitation.inviteeReward}</strong><small>{formatDate(invitation.joinedAt)}</small></article>) : <p>{text.noData}</p>}</section>}
      {tab === "ledger" && <section className="admin-panel admin-table"><div className="admin-table-head admin-ledger-head"><span>{text.members}</span><span>{text.ledgerReason}</span><span>{text.delta}</span><span>{text.balanceAfter}</span><span>{text.occurredAt}</span></div>{ledger.length ? ledger.map((entry) => <article key={entry.id}><b>{entry.memberEmail}</b><span>{reasonLabel(entry.reason)}</span><strong data-positive={entry.delta > 0}>{entry.delta > 0 ? "+" : ""}{entry.delta}</strong><span>{entry.balanceAfter}</span><small>{formatDate(entry.createdAt)}</small></article>) : <p>{text.noData}</p>}</section>}
      {tab === "readings" && <section className="admin-panel admin-orders"><header><p>{readingLabels[locale]}</p></header>{readings.length ? readings.map((reading) => <article key={reading.id}><div><b>{reading.member} · {reading.tool}</b><small>{formatDate(reading.createdAt)} · {reading.cost} {locale === "zh-Hans" ? "积分" : "credits"}</small><p>{reading.question}</p><p>{reading.response.summary}</p></div></article>) : <p>{text.noData}</p>}</section>}
      {(tab === "groups" || tab === "packages" || tab === "grants" || tab === "lectures" || tab === "teams") && <AdminGrowthTools locale={locale} view={tab} />}
      {tab === "workshop" && <AdminWorkshop locale={locale} />}
      {tab === "flash" && <AdminFlash locale={locale} />}
    </>}
    {notice && <p className="commerce-notice" role="status">{notice}</p>}
  </section>;
}
