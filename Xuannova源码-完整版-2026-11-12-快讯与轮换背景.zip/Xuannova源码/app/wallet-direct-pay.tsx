"use client";
// Wallet payment on Ethereum and Solana (USDC / USDT) and TRON (USDT), each with four wallets (see direct-wallets.ts). The server creates an order with a
// reference; the wallet signs one direct transfer that carries it; the server credits the package once the chain has
// finalised the transfer. Nothing here touches private keys: the member approves the transfer in their own wallet.
import { useCallback, useEffect, useRef, useState } from "react";
import type { Locale } from "./site-content";
import { directWallets, prepareDirectWallets, walletDiagnostics, DirectWalletError, type DirectChain, type DirectWallet } from "./direct-wallets";
import { CoinChip } from "./payment-chains";
import { tpBridgeAvailable, tpSwitchWallet } from "./tp-bridge";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

export const walletPayText = {
  option: L("Pay with wallet", "钱包直接支付", "錢包直接支付", "ウォレットで支払う", "지갑으로 결제", "Thanh toán bằng ví", "ชำระด้วยกระเป๋าเงิน"),
  optionLead: L("Connect a wallet ({wallet}), approve one transfer, credits arrive automatically.", "连接钱包（{wallet}），确认一笔转账，积分自动到账。", "連接錢包（{wallet}），確認一筆轉帳，積分自動到帳。", "ウォレット（{wallet}）に接続して送金を1回承認すると、自動で付与されます。", "지갑({wallet})을 연결하고 송금 한 번을 승인하면 자동으로 지급됩니다.", "Kết nối ví ({wallet}), xác nhận một lần chuyển, điểm tự động cộng.", "เชื่อมกระเป๋า ({wallet}) ยืนยันการโอนครั้งเดียว เครดิตเข้าอัตโนมัติ"),
  coin: L("Pay with", "支付币种", "支付幣種", "支払い通貨", "결제 코인", "Thanh toán bằng", "ชำระด้วย"),
  connect: L("Connect {wallet}", "连接 {wallet}", "連接 {wallet}", "{wallet} に接続", "{wallet} 연결", "Kết nối {wallet}", "เชื่อม {wallet}"),
  connected: L("Wallet", "钱包", "錢包", "ウォレット", "지갑", "Ví", "กระเป๋า"),
  pay: L("Pay {amount} {coin}", "支付 {amount} {coin}", "支付 {amount} {coin}", "{amount} {coin} を支払う", "{amount} {coin} 결제", "Thanh toán {amount} {coin}", "ชำระ {amount} {coin}"),
  noWallet: L("{wallet} was not found in this browser. Install it, or open this page inside the {wallet} app.", "当前浏览器没有检测到 {wallet}。请安装插件，或在 {wallet} App 内打开本页。", "目前瀏覽器沒有偵測到 {wallet}。請安裝外掛，或在 {wallet} App 內開啟本頁。", "このブラウザで {wallet} が見つかりません。拡張機能を入れるか、{wallet} アプリ内でこのページを開いてください。", "이 브라우저에서 {wallet}을 찾지 못했어요. 확장 프로그램을 설치하거나 {wallet} 앱에서 이 페이지를 여세요.", "Không tìm thấy {wallet} trong trình duyệt. Hãy cài tiện ích hoặc mở trang này trong ứng dụng {wallet}.", "ไม่พบ {wallet} ในเบราว์เซอร์นี้ ติดตั้งส่วนขยาย หรือเปิดหน้านี้ในแอป {wallet}"),
  openInApp: L("Open in {wallet} app", "在 {wallet} App 中打开", "在 {wallet} App 中開啟", "{wallet} アプリで開く", "{wallet} 앱에서 열기", "Mở trong ứng dụng {wallet}", "เปิดในแอป {wallet}"),
  preparing: L("Preparing the order…", "正在创建订单…", "正在建立訂單…", "注文を作成中…", "주문 생성 중…", "Đang tạo đơn…", "กำลังสร้างคำสั่งซื้อ…"),
  approve: L("Approve the transfer in your wallet…", "请在钱包中确认转账…", "請在錢包中確認轉帳…", "ウォレットで送金を承認してください…", "지갑에서 송금을 승인하세요…", "Hãy xác nhận chuyển khoản trong ví…", "โปรดยืนยันการโอนในกระเป๋าเงิน…"),
  confirming: L("Sent. Waiting for the chain to finalise (usually under a minute)…", "已发送，等待链上最终确认（通常 1 分钟内）…", "已發送，等待鏈上最終確認（通常 1 分鐘內）…", "送信済み。チェーンの確定を待っています（通常1分以内）…", "전송됨. 체인 확정을 기다리는 중(보통 1분 이내)…", "Đã gửi. Đang chờ chuỗi xác nhận (thường dưới 1 phút)…", "ส่งแล้ว รอเชนยืนยัน (ปกติไม่เกิน 1 นาที)…"),
  credited: L("Payment confirmed. {n} credits added.", "支付成功，已到账 {n} 积分。", "支付成功，已到帳 {n} 積分。", "支払いを確認しました。{n} クレジットを付与しました。", "결제가 확인되었습니다. {n} 크레딧이 지급되었어요.", "Đã xác nhận thanh toán. Đã cộng {n} điểm.", "ยืนยันการชำระแล้ว เพิ่ม {n} เครดิต"),
  slow: L("The chain is still confirming. Keep this page or come back later: the payment is saved and will be credited once final.", "链上仍在确认中。可停留本页或稍后再回来，支付记录已保存，确认后会自动到账。", "鏈上仍在確認中。可停留本頁或稍後再回來，支付紀錄已保存，確認後會自動到帳。", "チェーンで確認中です。このページのまま、または後で戻ってください。確定後に付与されます。", "체인에서 아직 확인 중입니다. 이 페이지에 있거나 나중에 돌아오세요. 확정되면 지급됩니다.", "Chuỗi vẫn đang xác nhận. Ở lại trang hoặc quay lại sau: thanh toán đã lưu và sẽ được cộng khi xác nhận.", "เชนยังยืนยันอยู่ อยู่หน้านี้หรือกลับมาภายหลัง การชำระถูกบันทึกแล้วและจะเพิ่มเครดิตเมื่อยืนยัน"),
  checkAgain: L("Check again", "再次检查", "再次檢查", "もう一度確認", "다시 확인", "Kiểm tra lại", "ตรวจสอบอีกครั้ง"),
  rejected: L("The transfer was cancelled in the wallet.", "已在钱包中取消转账。", "已在錢包中取消轉帳。", "ウォレットで送金がキャンセルされました。", "지갑에서 송금이 취소되었습니다.", "Đã hủy chuyển khoản trong ví.", "ยกเลิกการโอนในกระเป๋าเงินแล้ว"),
  failed: L("Payment could not be completed", "支付未完成", "支付未完成", "支払いを完了できませんでした", "결제를 완료하지 못했습니다", "Không thể hoàn tất thanh toán", "ชำระเงินไม่สำเร็จ"),
  fee: L("Network fee is paid by your wallet in {gas}. Amount: exactly the package price (1 {coin} = 1 US dollar).", "网络手续费由钱包以 {gas} 支付；金额等于套餐价格（1 {coin} = 1 美元）。", "網路手續費由錢包以 {gas} 支付；金額等於套餐價格（1 {coin} = 1 美元）。", "ネットワーク手数料はウォレットが {gas} で支払います。金額はパッケージ価格と同じ（1 {coin} = 1 米ドル）。", "네트워크 수수료는 지갑에서 {gas}로 지불합니다. 금액은 패키지 가격과 같습니다(1 {coin} = 1달러).", "Phí mạng do ví trả bằng {gas}. Số tiền đúng bằng giá gói (1 {coin} = 1 USD).", "ค่าธรรมเนียมเครือข่ายจ่ายด้วย {gas} จากกระเป๋า จำนวนเท่ากับราคาแพ็กเกจ (1 {coin} = 1 ดอลลาร์)"),
  chooseWallet: L("Choose a wallet", "选择钱包", "選擇錢包", "ウォレットを選ぶ", "지갑 선택", "Chọn ví", "เลือกกระเป๋าเงิน"),
  connectShort: L("Connect", "连接", "連接", "接続", "연결", "Kết nối", "เชื่อมต่อ"),
  connecting: L("Connecting…", "连接中…", "連接中…", "接続中…", "연결 중…", "Đang kết nối…", "กำลังเชื่อมต่อ…"),
  switchTp: L("Switch to a {chain} wallet in TokenPocket", "请在 TokenPocket 里切换到 {chain} 钱包", "請在 TokenPocket 裡切換到 {chain} 錢包", "TokenPocket で {chain} ウォレットに切り替えてください", "TokenPocket에서 {chain} 지갑으로 전환하세요", "Chuyển sang ví {chain} trong TokenPocket", "สลับเป็นกระเป๋า {chain} ใน TokenPocket"),
  switchTpLead: L("TokenPocket only connects the network of the wallet selected in the app. Tap here to reopen this page on {chain}, or switch the wallet at the top of the app and refresh.", "TokenPocket 每次只连接 App 里当前选中钱包的网络。点这里会在 {chain} 网络下重新打开本页；也可以在 App 顶部切换钱包后刷新页面。", "TokenPocket 每次只連接 App 裡目前選中錢包的網路。點這裡會在 {chain} 網路下重新開啟本頁；也可以在 App 頂部切換錢包後重新整理頁面。", "TokenPocket はアプリで選択中のウォレットのネットワークにだけ接続します。ここをタップすると {chain} でこのページを開き直します。アプリ上部でウォレットを切り替えて再読み込みしても構いません。", "TokenPocket은 앱에서 선택한 지갑의 네트워크에만 연결됩니다. 여기를 누르면 {chain}에서 이 페이지를 다시 엽니다. 앱 상단에서 지갑을 바꾼 뒤 새로고침해도 됩니다.", "TokenPocket chỉ kết nối mạng của ví đang chọn trong ứng dụng. Chạm vào đây để mở lại trang trên {chain}, hoặc đổi ví ở đầu ứng dụng rồi tải lại.", "TokenPocket เชื่อมต่อเฉพาะเครือข่ายของกระเป๋าที่เลือกในแอป แตะที่นี่เพื่อเปิดหน้านี้ใหม่บน {chain} หรือสลับกระเป๋าที่ด้านบนของแอปแล้วรีเฟรช"),
  install: L("Not installed · Install", "未安装 · 去安装", "未安裝 · 去安裝", "未インストール · 入手", "미설치 · 설치", "Chưa cài · Cài đặt", "ยังไม่ติดตั้ง · ติดตั้ง"),
  openApp: L("Open in the app", "在 App 中打开", "在 App 中開啟", "アプリで開く", "앱에서 열기", "Mở trong ứng dụng", "เปิดในแอป"),
  switchWallet: L("Use another wallet", "换一个钱包", "換一個錢包", "別のウォレット", "다른 지갑", "Dùng ví khác", "ใช้กระเป๋าอื่น"),
  wrongChain: L("Switch the wallet to Ethereum mainnet and try again.", "请在钱包里切换到以太坊主网后再试。", "請在錢包裡切換到以太坊主網後再試。", "ウォレットをイーサリアム メインネットに切り替えて、もう一度お試しください。", "지갑을 이더리움 메인넷으로 바꾼 뒤 다시 시도하세요.", "Hãy chuyển ví sang Ethereum mainnet rồi thử lại.", "โปรดสลับกระเป๋าเป็น Ethereum mainnet แล้วลองใหม่"),
  confirmingEth: L("Sent. Waiting for 12 Ethereum confirmations (about 3 minutes)…", "已发送，等待以太坊 12 个区块确认（约 3 分钟）…", "已發送，等待以太坊 12 個區塊確認（約 3 分鐘）…", "送信済み。イーサリアムの 12 承認を待っています（約3分）…", "전송됨. 이더리움 12 컨펌을 기다리는 중(약 3분)…", "Đã gửi. Đang chờ 12 xác nhận Ethereum (khoảng 3 phút)…", "ส่งแล้ว รอการยืนยัน Ethereum 12 บล็อก (ประมาณ 3 นาที)…"),
  short: L("This wallet ({addr}) holds {have} {coin} on {chain}; this package needs {need} {coin}.", "这个钱包（{addr}）在 {chain} 上只有 {have} {coin}，本次需要 {need} {coin}。", "這個錢包（{addr}）在 {chain} 上只有 {have} {coin}，本次需要 {need} {coin}。", "このウォレット（{addr}）の {chain} 上の {coin} は {have} です。必要なのは {need} {coin} です。", "이 지갑({addr})의 {chain} {coin} 잔액은 {have}이며, 이번 결제에는 {need} {coin}이 필요합니다.", "Ví này ({addr}) chỉ có {have} {coin} trên {chain}; gói này cần {need} {coin}.", "กระเป๋านี้ ({addr}) มี {coin} บน {chain} เพียง {have} แต่ต้องใช้ {need} {coin}"),
  sameAddress: L("Coins on another network (for example BNB Chain) do not count here, even at the same address. Choose the network where your coins actually are.", "注意：同一个地址在其他链（例如 BNB 链）上的币，不能用于这里。请选择币实际所在的网络付款。", "注意：同一個地址在其他鏈（例如 BNB 鏈）上的幣，不能用於這裡。請選擇幣實際所在的網路付款。", "同じアドレスでも、別のネットワーク（例：BNB Chain）にある通貨はここでは使えません。通貨が実際にあるネットワークを選んでください。", "같은 주소라도 다른 네트워크(예: BNB 체인)에 있는 코인은 여기서 쓸 수 없습니다. 코인이 실제로 있는 네트워크를 선택하세요.", "Coin trên mạng khác (ví dụ BNB Chain) không dùng được ở đây, kể cả cùng địa chỉ. Hãy chọn mạng nơi coin của bạn thực sự nằm.", "เหรียญบนเครือข่ายอื่น (เช่น BNB Chain) ใช้ที่นี่ไม่ได้ แม้เป็นที่อยู่เดียวกัน โปรดเลือกเครือข่ายที่เหรียญของคุณอยู่จริง"),
  useOther: L("Pay with {other} instead (you hold {have})", "改用 {other} 支付（钱包里有 {have}）", "改用 {other} 支付（錢包裡有 {have}）", "{other} で支払う（保有 {have}）", "{other}(보유 {have})로 결제", "Trả bằng {other} (đang có {have})", "จ่ายด้วย {other} แทน (มี {have})"),
  noGas: L("Not enough {gas} for the network fee: you hold {have} {gas}, about {need} {gas} is needed. Add a little {gas} to this wallet first.", "钱包里的 {gas} 不够付网络手续费：现有 {have} {gas}，至少需要约 {need} {gas}。请先往这个钱包转入少量 {gas}。", "錢包裡的 {gas} 不夠付網路手續費：現有 {have} {gas}，至少需要約 {need} {gas}。請先往這個錢包轉入少量 {gas}。", "ネットワーク手数料の {gas} が足りません（保有 {have}、必要 約 {need}）。先に少量の {gas} を入れてください。", "네트워크 수수료용 {gas}가 부족합니다(보유 {have}, 필요 약 {need}). 먼저 {gas}를 조금 입금하세요.", "Không đủ {gas} trả phí mạng: đang có {have} {gas}, cần khoảng {need} {gas}. Hãy nạp ít {gas} vào ví trước.", "{gas} ไม่พอจ่ายค่าธรรมเนียม: มี {have} {gas} ต้องใช้ประมาณ {need} {gas} โปรดโอน {gas} เข้ากระเป๋านี้ก่อน"),
  viewTx: L("View transaction", "查看交易", "查看交易", "取引を見る", "거래 보기", "Xem giao dịch", "ดูธุรกรรม"),
};

type Chain = DirectChain;
const coinsFor: Record<Chain, string[]> = { ethereum: ["USDC", "USDT"], solana: ["USDC", "USDT"], tron: ["USDT"] };
const gasFor: Record<Chain, string> = { ethereum: "ETH", solana: "SOL", tron: "TRX" };
const explorer = (chain: Chain, id: string) => chain === "ethereum" ? `https://etherscan.io/tx/${id}` : chain === "solana" ? `https://solscan.io/tx/${id}` : `https://tronscan.org/#/transaction/${id}`;
const pendingKey = "xn.walletpay.pending";
const isPhone = () => typeof navigator !== "undefined" && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
const shortAddr = (value: string) => `${value.slice(0, 6)}…${value.slice(-6)}`;

const readPending = (): { chain: Chain; orderId: string; transactionId: string; packageId: string } | null => { try { const value = JSON.parse(window.localStorage.getItem(pendingKey) ?? "null"); return value && value.orderId && value.transactionId ? value : null; } catch { return null; } };
const writePending = (value: unknown) => { try { if (value) window.localStorage.setItem(pendingKey, JSON.stringify(value)); else window.localStorage.removeItem(pendingKey); } catch { /* storage unavailable */ } };

async function post<T>(path: string, body: unknown): Promise<{ status: number; data: T & { error?: string } }> {
  const response = await fetch(path, { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
  const data = await response.json().catch(() => ({})) as T & { error?: string };
  return { status: response.status, data };
}

type Stage = "idle" | "preparing" | "approve" | "confirming" | "slow" | "done";

export function WalletDirectPay({ chain, packageId, price, locale, onCredited, onBusy }: { chain: Chain; packageId: string; price: string; locale: Locale; onCredited: (credits: number) => void; onBusy?: (busy: boolean) => void }) {
  const [wallets, setWallets] = useState<DirectWallet[]>([]);
  const [wallet, setWallet] = useState<DirectWallet | null>(null);
  const t = (key: keyof typeof walletPayText, values: Record<string, string> = {}) => Object.entries({ wallet: wallet?.label ?? "", ...values }).reduce((text, [name, value]) => text.replaceAll(`{${name}}`, value), walletPayText[key][locale]);
  const [coin, setCoin] = useState(coinsFor[chain][0]);
  const [address, setAddress] = useState("");
  const [stage, setStage] = useState<Stage>("idle");
  const [message, setMessage] = useState("");
  const [txId, setTxId] = useState("");
  const [switchTo, setSwitchTo] = useState<{ asset: string; have: string } | null>(null);
  const pending = useRef<{ chain: Chain; orderId: string; transactionId: string; packageId: string } | null>(null);
  const timer = useRef<number | undefined>(undefined);

  // Wallets announce themselves asynchronously (EIP-6963, Wallet Standard): look again shortly after opening.
  useEffect(() => {
    prepareDirectWallets();
    setWallets(directWallets(chain)); setWallet(null); setAddress(""); setCoin(coinsFor[chain][0]);
    // Wallet apps (TokenPocket, TronLink…) can inject their provider a few seconds after the page loads: keep looking.
    let tries = 0;
    const again = window.setInterval(() => { tries += 1; setWallets(directWallets(chain)); if (tries >= 16) window.clearInterval(again); }, 500);
    return () => window.clearInterval(again);
  }, [chain]);
  useEffect(() => { onBusy?.(stage === "preparing" || stage === "approve"); }, [stage, onBusy]);
  useEffect(() => () => window.clearTimeout(timer.current), []);

  const poll = useCallback(async (attempt = 0) => {
    const current = pending.current;
    if (!current) return;
    try {
      const { status, data } = await post<{ status?: string; credits?: number }>(`/api/pay/${current.chain}/confirm`, { orderId: current.orderId, transactionId: current.transactionId });
      if (status === 200 && data.status === "credited") { writePending(null); pending.current = null; setStage("done"); setMessage(walletPayText.credited[locale].replace("{n}", String(data.credits ?? ""))); onCredited(data.credits ?? 0); return; }
      if (status === 202 || status === 503) {
        if (attempt >= 60) { setStage("slow"); setMessage(walletPayText.slow[locale]); return; }
        timer.current = window.setTimeout(() => void poll(attempt + 1), 5000);
        return;
      }
      writePending(null); pending.current = null; setStage("idle"); setMessage(`${walletPayText.failed[locale]}: ${data.error ?? status}`);
    } catch {
      timer.current = window.setTimeout(() => void poll(attempt + 1), 5000);
    }
  }, [locale, onCredited]);

  // Resume a payment that was sent but not yet credited (page closed or reloaded while confirming).
  useEffect(() => {
    const saved = readPending();
    if (saved && saved.chain === chain) { pending.current = saved; setTxId(saved.transactionId); setStage("confirming"); setMessage(walletPayText.confirming[locale]); void poll(); }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chain]);

  const describe = (cause: unknown) => cause instanceof DirectWalletError && cause.code === "REJECTED" ? walletPayText.rejected[locale]
    : cause instanceof DirectWalletError && cause.code === "WRONG_CHAIN" ? walletPayText.wrongChain[locale]
    : `${walletPayText.failed[locale]}: ${cause instanceof Error ? cause.message : String(cause)}`;

  const connect = async (choice: DirectWallet) => {
    setMessage(""); setWallet(choice);
    try { setAddress(await choice.connect()); }
    catch (cause) {
      setWallet(null);
      // Inside TokenPocket a wallet on another chain cannot switch by itself: open TokenPocket's own wallet picker.
      if (choice.id === "tokenpocket" && cause instanceof DirectWalletError && cause.code === "WRONG_CHAIN" && tpBridgeAvailable() && await tpSwitchWallet(chain)) return;
      setMessage(describe(cause));
    }
  };

  const pay = async () => {
    if (!address || !wallet) return;
    setStage("preparing"); setMessage(walletPayText.preparing[locale]);
    setSwitchTo(null);
    const created = await post<{ order?: Record<string, string>; code?: string; detail?: { have: string; need: string; asset: string; other?: { asset: string; have: string }; gas?: string; gasHave?: string; gasNeed?: string } }>(`/api/pay/${chain}/order`, { packageId, asset: coin, buyer: address }).catch(() => null);
    const order = created?.data.order;
    if (!created || !order) {
      setStage("idle");
      const detail = created?.data.detail;
      const chainName = chain === "ethereum" ? "Ethereum" : chain === "solana" ? "Solana" : "TRON";
      if (created?.data.code === "INSUFFICIENT_BALANCE" && detail) {
        setMessage(`${t("short", { addr: shortAddr(address), have: detail.have, need: detail.need, coin: detail.asset, chain: chainName })} ${walletPayText.sameAddress[locale]}`);
        if (detail.other && Number(detail.other.have) >= Number(detail.need)) setSwitchTo(detail.other);
      } else if (created?.data.code === "INSUFFICIENT_GAS" && detail?.gas) {
        setMessage(t("noGas", { gas: detail.gas, have: detail.gasHave ?? "0", need: detail.gasNeed ?? "" }));
      } else setMessage(`${walletPayText.failed[locale]}: ${created?.data.error ?? ""}`);
      return;
    }
    setStage("approve"); setMessage(t("approve"));
    let transactionId = "";
    try { transactionId = await wallet.pay(order, address); }
    catch (cause) { setStage("idle"); setMessage(describe(cause)); return; }
    pending.current = { chain, orderId: order.orderId, transactionId, packageId };
    writePending(pending.current);
    setTxId(transactionId); setStage("confirming"); setMessage(chain === "ethereum" ? walletPayText.confirmingEth[locale] : walletPayText.confirming[locale]);
    void poll();
  };

  const busy = stage === "preparing" || stage === "approve" || stage === "confirming";
  const here = typeof window === "undefined" ? "" : window.location.href;
  const phone = isPhone();
  return <div className="mc-pay wallet-direct" data-testid={`wallet-direct-${chain}`}>
    <div className="wallet-direct-coins" role="radiogroup" aria-label={t("coin")}>
      <small>{t("coin")}</small>
      <div>{coinsFor[chain].map((item) => <button key={item} type="button" role="radio" aria-checked={coin === item} className={coin === item ? "is-active" : ""} disabled={busy || stage === "done"} onClick={() => setCoin(item)}><CoinChip symbol={item} /></button>)}</div>
    </div>
    {!address && stage !== "confirming" && stage !== "slow" && <div className="wallet-direct-wallets">
      <small>{walletPayText.chooseWallet[locale]}</small>
      {wallets.some((item) => item.switchInApp) && <p className="mc-hint is-warning">{t("switchTpLead", { chain: { ethereum: "Ethereum", solana: "Solana", tron: "TRON" }[chain] })}</p>}
      <div className="mc-wallet-grid">{wallets.map((item) => item.installed
        ? <button key={item.id} type="button" className="mc-wallet" disabled={busy} onClick={() => void connect(item)}>{item.icon ? <img src={item.icon} alt="" /> : <i>◆</i>}<span><b>{item.label}</b><small>{wallet?.id === item.id ? walletPayText.connecting[locale] : walletPayText.connectShort[locale]}</small></span></button>
        : item.switchInApp && item.appLink
        ? <a key={item.id} className="mc-wallet is-switch" href={item.appLink(here)} onClick={(event) => { if (!tpBridgeAvailable()) return; event.preventDefault(); void tpSwitchWallet(chain).then((ok) => { if (!ok) setMessage(t("switchTpLead", { chain: { ethereum: "Ethereum", solana: "Solana", tron: "TRON" }[chain] })); }); }}><i>⇄</i><span><b>{item.label}</b><small>{t("switchTp", { chain: { ethereum: "Ethereum", solana: "Solana", tron: "TRON" }[chain] })}</small></span></a>
        : <a key={item.id} className="mc-wallet is-missing" href={phone && item.appLink ? item.appLink(here) : item.installUrl} target={phone && item.appLink ? undefined : "_blank"} rel="noreferrer"><i>◇</i><span><b>{item.label}</b><small>{phone && item.appLink ? walletPayText.openApp[locale] : walletPayText.install[locale]}</small></span></a>)}</div>
    </div>}
    <dl className="mc-summary">
      <div><dt>{t("connected")}</dt><dd>{address ? <><code>{shortAddr(address)}</code>{wallet && ` · ${wallet.label}`}</> : "—"}</dd></div>
      <div className="is-total"><dt>{t("coin")}</dt><dd>{price} {coin}</dd></div>
    </dl>
    <p className="mc-hint">{t("fee", { gas: gasFor[chain], coin })}</p>
    {address && stage !== "done" && stage !== "confirming" && stage !== "slow" && <div className="wallet-direct-actions">
      <button type="button" className="primary-action mc-submit" disabled={busy} onClick={() => void pay()}>{t("pay", { amount: price, coin })}<b>↗</b></button>
      <button type="button" className="text-action" disabled={busy} onClick={() => { setAddress(""); setWallet(null); setMessage(""); }}>{walletPayText.switchWallet[locale]}</button>
    </div>}
    {stage === "slow" && <button type="button" className="secondary-action" onClick={() => { setStage("confirming"); setMessage(walletPayText.confirming[locale]); void poll(); }}>{t("checkAgain")}</button>}
    {switchTo && stage === "idle" && <button type="button" className="secondary-action" onClick={() => { setCoin(switchTo.asset); setSwitchTo(null); setMessage(""); }}>{t("useOther", { other: switchTo.asset, have: switchTo.have })}</button>}
    {message && <p className={`mc-inline is-${stage === "done" ? "success" : stage === "idle" ? "error" : "info"}`} role="status">{busy && <span className="wallet-direct-spin" aria-hidden="true" />}{message}</p>}
    {txId && <a className="text-action" href={explorer(chain, txId)} target="_blank" rel="noreferrer">{t("viewTx")}</a>}
  </div>;
}

/** Shown on the credits page with ?walletcheck=1: which wallet objects this browser exposes (for support screenshots). */
export function WalletCheck() {
  const [rows, setRows] = useState<Array<[string, string]>>([]);
  useEffect(() => {
    if (!new URLSearchParams(window.location.search).has("walletcheck")) return;
    prepareDirectWallets();
    const update = () => setRows(walletDiagnostics());
    update();
    const timer = window.setInterval(update, 1000);
    return () => window.clearInterval(timer);
  }, []);
  if (!rows.length) return null;
  return <section className="mc-card wallet-check"><h3>Wallet check</h3><dl>{rows.map(([key, value]) => <div key={key}><dt>{key}</dt><dd>{value}</dd></div>)}</dl></section>;
}
