"use client";
// Home hero, moving layer: a large bagua ring turning very slowly, gold dust drifting up, mist sliding across,
// twinkling stars and now and then a shooting star. Drawn on one canvas; it pauses when the hero is off screen or
// the tab is hidden, and shows a still frame when the visitor prefers reduced motion.
import { useEffect, useRef, useState } from "react";
import { createHeroEngine, SCENE_COUNT, type HeroEngine } from "./hero-scenes";

const TRIGRAMS = [[1, 1, 1], [0, 1, 1], [1, 0, 1], [0, 0, 1], [1, 1, 0], [0, 1, 0], [1, 0, 0], [0, 0, 0]];

function PaperMotion() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const reduce = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
    let width = 0, height = 0, dpr = 1, accent = "#d4a85c", paper = false;
    type Dust = { x: number; y: number; r: number; speed: number; drift: number; phase: number };
    type Star = { x: number; y: number; r: number; phase: number; speed: number };
    let dust: Dust[] = [], stars: Star[] = [];
    let shooting: { x: number; y: number; vx: number; vy: number; life: number } | null = null;
    let nextShoot = 4 + Math.random() * 6;

    const rgba = (hex: string, alpha: number) => {
      const value = hex.replace("#", "").trim();
      const full = value.length === 3 ? value.split("").map((c) => c + c).join("") : value.slice(0, 6);
      const n = parseInt(full, 16);
      return Number.isNaN(n) ? `rgba(212,168,92,${alpha})` : `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${alpha})`;
    };
    const setup = () => {
      const rect = canvas.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      width = rect.width; height = rect.height;
      canvas.width = Math.round(width * dpr); canvas.height = Math.round(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const styles = getComputedStyle(canvas);
      accent = styles.getPropertyValue("--accent").trim() || "#d4a85c";
      paper = canvas.closest("[data-theme='paper']") !== null;
      const small = width < 700;
      dust = Array.from({ length: small ? 26 : 48 }, () => ({ x: Math.random() * width, y: Math.random() * height, r: 0.6 + Math.random() * 1.8, speed: 6 + Math.random() * 14, drift: (Math.random() - 0.5) * 8, phase: Math.random() * 6 }));
      stars = Array.from({ length: small ? 14 : 26 }, () => ({ x: Math.random() * width, y: Math.random() * height * 0.55, r: 0.5 + Math.random() * 1.2, phase: Math.random() * 6, speed: 0.6 + Math.random() * 1.6 }));
    };

    const drawRing = (time: number) => {
      const small = width < 700;
      const cx = small ? width * 0.5 : width * 0.5, cy = small ? height * 0.36 : height * 0.46;
      const radius = Math.min(width, height) * (small ? 0.46 : 0.44);
      const turn = time * ((Math.PI * 2) / 160);
      ctx.save(); ctx.translate(cx, cy);
      // outer ring of 72 ticks
      ctx.save(); ctx.rotate(-turn * 0.6);
      ctx.strokeStyle = rgba(accent, paper ? 0.16 : 0.13); ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(0, 0, radius * 1.08, 0, Math.PI * 2); ctx.stroke();
      for (let i = 0; i < 72; i += 1) {
        const a = (i / 72) * Math.PI * 2, long = i % 9 === 0;
        ctx.beginPath(); ctx.moveTo(Math.cos(a) * radius * (long ? 1.0 : 1.04), Math.sin(a) * radius * (long ? 1.0 : 1.04)); ctx.lineTo(Math.cos(a) * radius * 1.08, Math.sin(a) * radius * 1.08); ctx.stroke();
      }
      ctx.restore();
      // the eight trigrams
      ctx.save(); ctx.rotate(turn);
      ctx.fillStyle = rgba(accent, paper ? 0.2 : 0.16);
      const bar = radius * 0.16, gap = radius * 0.035, thick = radius * 0.026;
      TRIGRAMS.forEach((lines, index) => {
        ctx.save(); ctx.rotate((index / 8) * Math.PI * 2);
        lines.forEach((solid, row) => {
          const y = -radius * 0.86 + row * (thick + gap);
          if (solid) ctx.fillRect(-bar / 2, y, bar, thick);
          else { ctx.fillRect(-bar / 2, y, bar * 0.42, thick); ctx.fillRect(bar * 0.08, y, bar * 0.42, thick); }
        });
        ctx.restore();
      });
      ctx.strokeStyle = rgba(accent, paper ? 0.14 : 0.1); ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(0, 0, radius * 0.66, 0, Math.PI * 2); ctx.stroke();
      ctx.restore();
      ctx.restore();
    };

    const frame = (time: number) => {
      if (width < 2 || height < 2) return; // hidden (the home page stays mounted while other pages show)
      ctx.clearRect(0, 0, width, height);
      // mist bands sliding across
      for (let band = 0; band < 2; band += 1) {
        const x = ((time * (8 + band * 5) + band * width * 0.6) % (width * 1.6)) - width * 0.3;
        const y = height * (0.62 + band * 0.16);
        const g = ctx.createRadialGradient(x, y, 10, x, y, width * 0.45);
        g.addColorStop(0, paper ? "rgba(255,255,255,.28)" : "rgba(200,190,170,.06)"); g.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = g; ctx.fillRect(0, 0, width, height);
      }
      drawRing(time);
      // twinkling stars (dark themes)
      if (!paper) for (const star of stars) {
        const alpha = 0.25 + 0.55 * (0.5 + 0.5 * Math.sin(time * star.speed + star.phase));
        ctx.fillStyle = `rgba(236,230,216,${alpha.toFixed(3)})`; ctx.beginPath(); ctx.arc(star.x, star.y, star.r, 0, Math.PI * 2); ctx.fill();
      }
      // gold dust rising
      for (const mote of dust) {
        const alpha = 0.25 + 0.45 * (0.5 + 0.5 * Math.sin(time * 1.3 + mote.phase));
        const g = ctx.createRadialGradient(mote.x, mote.y, 0, mote.x, mote.y, mote.r * 4);
        g.addColorStop(0, rgba(accent, alpha)); g.addColorStop(1, rgba(accent, 0));
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(mote.x, mote.y, mote.r * 4, 0, Math.PI * 2); ctx.fill();
      }
      // a shooting star now and then
      if (shooting && !paper) {
        const tail = 90;
        const g = ctx.createLinearGradient(shooting.x, shooting.y, shooting.x - shooting.vx * tail / 600, shooting.y - shooting.vy * tail / 600);
        g.addColorStop(0, `rgba(255,240,210,${Math.min(1, shooting.life).toFixed(2)})`); g.addColorStop(1, "rgba(255,240,210,0)");
        ctx.strokeStyle = g; ctx.lineWidth = 1.4;
        ctx.beginPath(); ctx.moveTo(shooting.x, shooting.y); ctx.lineTo(shooting.x - shooting.vx * tail / 600, shooting.y - shooting.vy * tail / 600); ctx.stroke();
      }
    };

    let raf = 0, last = performance.now(), clock = 0, visible = true;
    const tick = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000); last = now; clock += dt;
      for (const mote of dust) {
        mote.y -= mote.speed * dt; mote.x += Math.sin(clock * 0.5 + mote.phase) * mote.drift * dt;
        if (mote.y < -10) { mote.y = height + 10; mote.x = Math.random() * width; }
      }
      nextShoot -= dt;
      if (!shooting && nextShoot <= 0) { shooting = { x: width * (0.2 + Math.random() * 0.6), y: height * (0.05 + Math.random() * 0.2), vx: 520 + Math.random() * 200, vy: 180 + Math.random() * 120, life: 1 }; nextShoot = 7 + Math.random() * 9; }
      if (shooting) { shooting.x += shooting.vx * dt; shooting.y += shooting.vy * dt; shooting.life -= dt * 1.4; if (shooting.life <= 0) shooting = null; }
      frame(clock);
      raf = visible && !document.hidden ? requestAnimationFrame(tick) : 0;
    };
    const start = () => { if (!raf && visible && !document.hidden && !reduce) { last = performance.now(); raf = requestAnimationFrame(tick); } };

    setup();
    if (reduce) frame(0); else start();
    const resize = new ResizeObserver(() => { setup(); if (reduce) frame(0); });
    resize.observe(canvas);
    const seen = new IntersectionObserver((entries) => { visible = entries.some((entry) => entry.isIntersecting); if (visible) start(); }, { threshold: 0 });
    seen.observe(canvas);
    const onVisibility = () => start();
    document.addEventListener("visibilitychange", onVisibility);
    return () => { cancelAnimationFrame(raf); resize.disconnect(); seen.disconnect(); document.removeEventListener("visibilitychange", onVisibility); };
  }, []);
  return <canvas ref={ref} className="hero-motion" aria-hidden="true" />;
}

const SCENE_NAMES = ["经典", "墨山", "深空", "流金"];

/** Dark themes: the three rotating scenes (ink mountains, deep space, flowing gold) with small dots to pick one. */
function SceneMotion() {
  const ref = useRef<HTMLCanvasElement>(null);
  const engine = useRef<HeroEngine | null>(null);
  const [scene, setScene] = useState(0);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const reduce = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
    engine.current = createHeroEngine(canvas, setScene, reduce);
    return () => { engine.current?.destroy(); engine.current = null; };
  }, []);
  return <>
    <canvas ref={ref} className="hero-motion hero-scenes" aria-hidden="true" />
    <div className="hero-scene-dots" role="group" aria-label="background">
      {Array.from({ length: SCENE_COUNT }, (_, index) => <button type="button" key={index} aria-label={SCENE_NAMES[index]} aria-pressed={scene === index} className={scene === index ? "active" : ""} onClick={() => engine.current?.show(index)} />)}
    </div>
  </>;
}

/** Home hero, moving layer. Follows the theme: the light "paper" theme keeps the quiet bagua ring and gold dust,
 * the dark themes get the rotating Eastern-realm scenes. */
export function HeroMotion() {
  const probe = useRef<HTMLSpanElement>(null);
  const [paper, setPaper] = useState<boolean | null>(null);
  useEffect(() => {
    const shell = probe.current?.closest("[data-theme]");
    const read = () => setPaper(shell?.getAttribute("data-theme") === "paper");
    read();
    if (!shell) return;
    const watch = new MutationObserver(read);
    watch.observe(shell, { attributes: true, attributeFilter: ["data-theme"] });
    return () => watch.disconnect();
  }, []);
  return <>
    <span ref={probe} hidden />
    {paper === null ? null : paper ? <PaperMotion /> : <SceneMotion />}
  </>;
}
