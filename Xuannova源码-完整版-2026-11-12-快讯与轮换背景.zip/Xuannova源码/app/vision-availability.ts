"use client";
// Whether 手相面相 is switched on (the server has a vision model configured). Checked once per page load.
// The method is always listed; until a vision key is configured its page says it opens soon, and it switches on
// by itself as soon as VISION_API_URL / VISION_API_KEY / VISION_MODEL are set on the server.
import { useSyncExternalStore } from "react";
import { STUDY_METHOD_COUNT } from "./method-categories";

let available: boolean | null = null;
let started = false;
const listeners = new Set<() => void>();

function load() {
  if (started || typeof window === "undefined") return;
  started = true;
  fetch("/api/vision/status", { credentials: "same-origin" })
    .then((response) => (response.ok ? response.json() : { configured: false }))
    .then((payload: { configured?: boolean }) => { available = Boolean(payload.configured); })
    .catch(() => { available = false; })
    .finally(() => listeners.forEach((listener) => listener()));
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  load();
  return () => { listeners.delete(listener); };
}

/** true / false once known; null while loading (and during server rendering). */
export function useVisionAvailable(): boolean | null {
  return useSyncExternalStore(subscribe, () => available, () => null);
}

/** Routes that should not be listed right now. */
export function useHiddenRoutes(): string[] {
  return [];
}

/** Number of study methods currently offered. */
export function useStudyMethodCount() {
  return STUDY_METHOD_COUNT - useHiddenRoutes().length;
}
