"use client";
// Twelve-month outlook for the year: each solar-term month's pillar and its traditional relationship
// to the reader's day master (from the birth details saved in this browser). Cultural reference only.
import { useEffect, useState } from "react";
import { Solar, Lunar } from "lunar-javascript";
import type { Locale } from "./site-content";
import { tenGod } from "./bazi-reference";
import { localizeBoardTerm } from "./complete-chart-board";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

const names: Record<string, L7> = {
  比肩: L("Peer", "比肩", "比肩", "比肩", "비견", "Tỷ kiên", "เทียบเคียง"),
  劫财: L("Rob Wealth", "劫财", "劫財", "劫財", "겁재", "Kiếp tài", "แย่งทรัพย์"),
  食神: L("Eating God", "食神", "食神", "食神", "식신", "Thực thần", "เทพอาหาร"),
  伤官: L("Hurting Officer", "伤官", "傷官", "傷官", "상관", "Thương quan", "ทำลายขุนนาง"),
  正财: L("Direct Wealth", "正财", "正財", "正財", "정재", "Chính tài", "ทรัพย์ตรง"),
  偏财: L("Indirect Wealth", "偏财", "偏財", "偏財", "편재", "Thiên tài", "ทรัพย์รอง"),
  正官: L("Direct Officer", "正官", "正官", "正官", "정관", "Chính quan", "ขุนนางตรง"),
  七杀: L("Seven Killings", "七杀", "七殺", "偏官", "편관", "Thất sát", "เจ็ดพิฆาต"),
  正印: L("Direct Resource", "正印", "正印", "正印", "정인", "Chính ấn", "ตราประทับตรง"),
  偏印: L("Indirect Resource", "偏印", "偏印", "偏印", "편인", "Thiên ấn", "ตราประทับรอง"),
};
const group = (god: string) => (["比肩", "劫财"].includes(god) ? "self" : ["食神", "伤官"].includes(god) ? "output" : ["正财", "偏财"].includes(god) ? "wealth" : ["正官", "七杀"].includes(god) ? "order" : "support");
const notes: Record<string, L7> = {
  self: L("Traditionally a month for your own initiative and for working alongside peers; keep an eye on shared money.", "传统上偏重自主与同伴协作的月份，合作与人情往来较多，留意共同开支。", "傳統上偏重自主與同伴協作的月份，合作與人情往來較多，留意共同開支。", "伝統的には自主性と仲間との協力の月。共同の出費に気を配りましょう。", "전통적으로 주도성과 동료와의 협력이 두드러지는 달입니다. 공동 지출에 유의하세요.", "Theo truyền thống là tháng của sự chủ động và hợp tác cùng bạn bè; lưu ý chi tiêu chung.", "ตามตำราเป็นเดือนแห่งความริเริ่มและการร่วมมือกับเพื่อน ระวังค่าใช้จ่ายร่วมกัน"),
  output: L("Traditionally good for expression, creative work and sharing ideas; choose words with care.", "传统上利于表达、创作与展示想法，说话做事宜留分寸。", "傳統上利於表達、創作與展示想法，說話做事宜留分寸。", "伝統的には表現・創作・発信に向く月。言葉選びは丁寧に。", "전통적으로 표현과 창작, 아이디어 공유에 좋은 달입니다. 말은 신중하게.", "Theo truyền thống thuận cho việc thể hiện, sáng tạo và chia sẻ ý tưởng; nên cân nhắc lời nói.", "ตามตำราเหมาะกับการแสดงออก งานสร้างสรรค์ และการเสนอความคิด ระวังคำพูด"),
  wealth: L("Traditionally a practical month for money, plans and results; keep budgets realistic.", "传统上偏重务实、理财与成果的月份，预算宜稳健。", "傳統上偏重務實、理財與成果的月份，預算宜穩健。", "伝統的には実務・お金・成果に向く月。予算は堅実に。", "전통적으로 실무와 재정, 성과에 집중하는 달입니다. 예산은 현실적으로.", "Theo truyền thống là tháng thực tế cho tài chính, kế hoạch và kết quả; giữ ngân sách hợp lý.", "ตามตำราเป็นเดือนแห่งความเป็นจริง การเงิน และผลลัพธ์ วางงบให้รอบคอบ"),
  order: L("Traditionally a month of rules, responsibility and expectations from others; pace yourself.", "传统上偏重规则、责任与外界要求的月份，宜调节节奏。", "傳統上偏重規則、責任與外界要求的月份，宜調節節奏。", "伝統的には規則・責任・周囲の期待が増す月。ペース配分を。", "전통적으로 규칙과 책임, 주변의 기대가 커지는 달입니다. 속도를 조절하세요.", "Theo truyền thống là tháng của quy tắc, trách nhiệm và kỳ vọng từ người khác; giữ nhịp vừa phải.", "ตามตำราเป็นเดือนแห่งกฎเกณฑ์ ความรับผิดชอบ และความคาดหวัง ควรจัดจังหวะให้ดี"),
  support: L("Traditionally a month for learning, rest and help from mentors; good for planning ahead.", "传统上利于学习、休整与贵人相助，适合规划长远。", "傳統上利於學習、休整與貴人相助，適合規劃長遠。", "伝統的には学び・休養・目上の助けに恵まれる月。先の計画に良い時期。", "전통적으로 배움과 휴식, 귀인의 도움이 있는 달입니다. 장기 계획에 좋습니다.", "Theo truyền thống thuận cho học tập, nghỉ ngơi và sự giúp đỡ của người đi trước; hợp để lập kế hoạch.", "ตามตำราเหมาะกับการเรียนรู้ พักผ่อน และได้ผู้ใหญ่ช่วยเหลือ เหมาะกับการวางแผนระยะยาว"),
};
const text = {
  title: L("Your year, month by month", "流年月历", "流年月曆", "流年の月ごとの流れ", "올해의 월별 흐름", "Năm của bạn theo từng tháng", "ปีของคุณรายเดือน"),
  lead: L("Each solar-term month compared with your day master, from the birth details saved in this browser.", "按节气月，用本浏览器保存的出生信息，对照你的日主。", "按節氣月，用本瀏覽器儲存的出生資訊，對照你的日主。", "このブラウザに保存した生年月日から、節気の月ごとに日主と照らし合わせます。", "이 브라우저에 저장된 출생 정보로 절기 월마다 일주와 비교합니다.", "Mỗi tháng tiết khí so với nhật chủ của bạn, theo thông tin ngày sinh lưu trong trình duyệt này.", "เทียบแต่ละเดือนตามสารทกับเจ้าวันของคุณ จากข้อมูลวันเกิดที่บันทึกในเบราว์เซอร์นี้"),
  empty: L("Make a BaZi chart once and this calendar will appear here.", "先排一次八字盘，这里就会显示你的流年月历。", "先排一次八字盤，這裡就會顯示你的流年月曆。", "一度八字の盤を作ると、ここに表示されます。", "사주를 한 번 작성하면 여기에 표시됩니다.", "Lập lá số Bát tự một lần, lịch này sẽ hiện ở đây.", "สร้างผังปาจื้อหนึ่งครั้ง ปฏิทินนี้จะแสดงที่นี่"),
  from: L("from", "起", "起", "から", "부터", "từ", "เริ่ม"),
  now: L("This month", "本月", "本月", "今月", "이번 달", "Tháng này", "เดือนนี้"),
};
const themes: Record<string, L7> = {
  self: L("Self and peers", "自主与同伴", "自主與同伴", "自分と仲間", "나와 동료", "Bản thân và bạn bè", "ตัวเองและเพื่อน"),
  output: L("Expression and creativity", "表达与创作", "表達與創作", "表現と創造", "표현과 창작", "Thể hiện và sáng tạo", "การแสดงออกและความคิดสร้างสรรค์"),
  wealth: L("Money and results", "财务与成果", "財務與成果", "お金と成果", "재물과 성과", "Tiền bạc và kết quả", "การเงินและผลลัพธ์"),
  order: L("Duty and pressure", "责任与压力", "責任與壓力", "責任とプレッシャー", "책임과 압박", "Trách nhiệm và áp lực", "หน้าที่และแรงกดดัน"),
  support: L("Learning and support", "学习与贵人", "學習與貴人", "学びと支え", "배움과 도움", "Học hỏi và quý nhân", "การเรียนรู้และผู้อุปถัมภ์"),
};
const more = {
  yearTitle: L("{y}: the year's theme for you", "{y} 年对你的主题", "{y} 年對你的主題", "{y}年のあなたのテーマ", "{y}년 당신의 주제", "Chủ đề năm {y} với bạn", "ธีมปี {y} สำหรับคุณ"),
  basedOn: L("Based on your day master {stem} ({element}), from the birth date saved in this browser.", "依据：你的日主 {stem}（{element}），来自本浏览器保存的出生日期。", "依據：你的日主 {stem}（{element}），來自本瀏覽器儲存的出生日期。", "このブラウザに保存した生年月日の日主 {stem}（{element}）に基づきます。", "이 브라우저에 저장된 생년월일의 일간 {stem}({element}) 기준입니다.", "Dựa trên nhật chủ {stem} ({element}) từ ngày sinh lưu trong trình duyệt này.", "อิงจากเจ้าวัน {stem} ({element}) จากวันเกิดที่บันทึกในเบราว์เซอร์นี้"),
  howTitle: L("How to read this calendar", "怎么看这张月历？", "怎麼看這張月曆？", "このカレンダーの読み方", "이 달력 보는 법", "Cách đọc lịch này", "วิธีอ่านปฏิทินนี้"),
  how: L("In Chinese tradition a month starts on a solar term (around the 4th to 8th of each calendar month), not on the 1st. Each month has its own pair of characters (stem and branch). Comparing that month's stem with your day master gives one of five themes, shown in colour. The theme describes what tends to come to the foreground that month; it is a reflection prompt, not a forecast.",
         "按中国传统，一个月从“节气”开始（大约每个公历月的 4 日到 8 日），而不是 1 号。每个月都有自己的干支；用这个月的天干和你的日主对照，就得到五种主题之一（用颜色区分）。主题说明这个月比较容易凸显的方面，是给你思考的提示，不是预测。",
         "按中國傳統，一個月從「節氣」開始（大約每個公曆月的 4 日到 8 日），而不是 1 號。每個月都有自己的干支；用這個月的天干和你的日主對照，就得到五種主題之一（用顏色區分）。主題說明這個月比較容易凸顯的方面，是給你思考的提示，不是預測。",
         "中国の伝統では、月は1日ではなく節気（毎月4〜8日ごろ）から始まります。各月には干支があり、その月の天干をあなたの日主と比べると、5つのテーマのいずれかになります（色で表示）。テーマはその月に表に出やすいことを示す、考えるためのヒントで、予言ではありません。",
         "중국 전통에서 한 달은 1일이 아니라 절기(매달 4~8일경)에 시작합니다. 달마다 간지가 있고, 그달의 천간을 당신의 일간과 비교하면 다섯 주제 중 하나가 됩니다(색으로 표시). 주제는 그달에 두드러지기 쉬운 면을 알려 주는 생각의 실마리이며, 예측이 아닙니다.",
         "Theo truyền thống Trung Hoa, tháng bắt đầu từ tiết khí (khoảng ngày 4 đến 8 mỗi tháng dương lịch), không phải ngày 1. Mỗi tháng có một cặp can chi; so can của tháng với nhật chủ của bạn sẽ ra một trong năm chủ đề (phân biệt bằng màu). Chủ đề cho biết điều dễ nổi bật trong tháng, là gợi ý để suy ngẫm, không phải dự đoán.",
         "ตามธรรมเนียมจีน เดือนเริ่มที่สารท (ราววันที่ 4–8 ของแต่ละเดือนสากล) ไม่ใช่วันที่ 1 แต่ละเดือนมีก้านกิ่งของตัวเอง เมื่อนำก้านของเดือนมาเทียบกับเจ้าวันของคุณ จะได้หนึ่งในห้าธีม (แยกด้วยสี) ธีมบอกเรื่องที่มักโดดเด่นในเดือนนั้น เป็นข้อคิด ไม่ใช่คำทำนาย"),
  godLabel: L("Ten God", "十神", "十神", "通変星", "십성", "Thập thần", "สิบเทพ"),
};
const elementOfStem: Record<string, L7> = {
  wood: L("Wood", "木", "木", "木", "목", "Mộc", "ไม้"), fire: L("Fire", "火", "火", "火", "화", "Hỏa", "ไฟ"), earth: L("Earth", "土", "土", "土", "토", "Thổ", "ดิน"), metal: L("Metal", "金", "金", "金", "금", "Kim", "โลหะ"), water: L("Water", "水", "水", "水", "수", "Thủy", "น้ำ"),
};
const stemElement = (stem: string) => ("甲乙".includes(stem) ? "wood" : "丙丁".includes(stem) ? "fire" : "戊己".includes(stem) ? "earth" : "庚辛".includes(stem) ? "metal" : "water");
const fillText = (template: string, values: Record<string, string | number>) => template.replace(/\{(\w+)\}/g, (_, key: string) => String(values[key] ?? ""));
const showPillars = (locale: Locale) => locale === "zh-Hans" || locale === "zh-Hant" || locale === "ja";

type Month = { start: string; pillar: string; god: string; current: boolean };
export function computeMonthlyOutlook(dayStem: string, year: number, today = new Date()): Month[] {
  const months: Month[] = [];
  for (let month = 1; month <= 12; month += 1) {
    // The 20th lies inside the solar-term month that begins early in that calendar month.
    const lunar = Solar.fromYmd(year, month, 20).getLunar();
    const jie = lunar.getPrevJie(true).getSolar();
    const start = `${jie.getYear()}-${String(jie.getMonth()).padStart(2, "0")}-${String(jie.getDay()).padStart(2, "0")}`;
    const pillar = lunar.getMonthInGanZhiExact();
    months.push({ start, pillar, god: tenGod(dayStem, pillar[0]), current: false });
  }
  const todayIso = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  const index = months.map((item) => item.start).filter((start) => start <= todayIso).length - 1;
  if (index >= 0) months[index].current = true;
  return months;
}

function dayStemFromProfile(): string | null {
  try {
    const profile = JSON.parse(window.localStorage.getItem("xuannova-profile") ?? "null") as { date?: string; time?: string; calendar?: string; leapMonth?: boolean } | null;
    if (!profile?.date || profile.calendar === "pillars" || !/^\d{4}-\d{2}-\d{2}$/.test(profile.date)) return null;
    const [y, m, d] = profile.date.split("-").map(Number);
    const [hh, mm] = (profile.time && /^\d{2}:\d{2}/.test(profile.time) ? profile.time : "12:00").split(":").map(Number);
    const solar = profile.calendar === "lunar" ? Lunar.fromYmdHms(y, profile.leapMonth ? -m : m, d, hh, mm, 0).getSolar() : Solar.fromYmdHms(y, m, d, hh, mm, 0);
    return solar.getLunar().getEightChar().getDayGan();
  } catch { return null; }
}

export function MonthlyOutlook({ locale, onMakeChart }: { locale: Locale; onMakeChart: () => void }) {
  const [months, setMonths] = useState<Month[] | null | undefined>(undefined);
  const [dayStem, setDayStem] = useState<string | null>(null);
  const year = new Date().getFullYear();
  useEffect(() => {
    const timer = window.setTimeout(() => { const stem = dayStemFromProfile(); setDayStem(stem); setMonths(stem ? computeMonthlyOutlook(stem, year) : null); }, 0);
    return () => window.clearTimeout(timer);
  }, [year]);
  const yearPillar = Solar.fromYmd(year, 7, 1).getLunar().getYearInGanZhiExact() as string;
  const yearGod = dayStem ? tenGod(dayStem, yearPillar[0]) : "";
  const range = (index: number) => {
    if (!months) return "";
    const start = new Date(`${months[index].start}T12:00:00`);
    const next = months[index + 1] ? new Date(`${months[index + 1].start}T12:00:00`) : new Date(Solar.fromYmd(year + 1, 1, 20).getLunar().getPrevJie(true).getSolar().toYmd() + "T12:00:00");
    next.setDate(next.getDate() - 1);
    const format = (date: Date) => date.toLocaleDateString(locale, { month: "short", day: "numeric" });
    return `${format(start)} – ${format(next)}`;
  };
  if (months === undefined) return null;
  return <section className="monthly-outlook" aria-labelledby="monthly-outlook-title">
    <header><h2 id="monthly-outlook-title">{text.title[locale]} · {year}</h2><p>{text.lead[locale]}</p></header>
    <details className="monthly-how"><summary>{more.howTitle[locale]}<b>+</b></summary><p>{more.how[locale]}</p>
      <ul className="monthly-legend">{(["self", "output", "wealth", "order", "support"] as const).map((key) => <li key={key} className={`monthly-${key}`}><b>{themes[key][locale]}</b><span>{notes[key][locale]}</span></li>)}</ul>
    </details>
    {months === null ? <p className="monthly-empty"><button type="button" className="text-action" onClick={onMakeChart}>{text.empty[locale]} →</button></p>
      : <>
        {dayStem && <div className={`monthly-year monthly-${group(yearGod)}`}>
          <small>{fillText(more.yearTitle[locale], { y: year })}{showPillars(locale) ? ` · ${yearPillar}` : ""}</small>
          <b>{themes[group(yearGod)][locale]}</b>
          <span>{more.godLabel[locale]}: {names[yearGod]?.[locale] ?? yearGod}</span>
          <p>{fillText(more.basedOn[locale], { stem: localizeBoardTerm(dayStem, locale), element: elementOfStem[stemElement(dayStem)][locale] })}</p>
        </div>}
        <ol>{months.map((item, index) => <li key={item.start} className={`monthly-${group(item.god)}${item.current ? " is-current" : ""}`}>
          <small>{range(index)}{item.current ? ` · ${text.now[locale]}` : ""}</small>
          <b>{themes[group(item.god)][locale]}</b>
          <em>{more.godLabel[locale]}: {names[item.god]?.[locale] ?? item.god}{showPillars(locale) ? ` · ${item.pillar}` : ""}</em>
          <span>{notes[group(item.god)][locale]}</span>
        </li>)}</ol>
      </>}
  </section>;
}
