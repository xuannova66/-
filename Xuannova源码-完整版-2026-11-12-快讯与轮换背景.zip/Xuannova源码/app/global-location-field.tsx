"use client";

import { useEffect, useId, useState, type ReactNode } from "react";
import { buildGeocodingUrls, buildGlobalLocationSearchUrl, formatGlobalLocation, mergeGeocodingResults, normalizeGeocodingResults, resolveLocationTimezone, type GlobalLocation } from "./geocoding";

type LocationText = {
  placeholder: string;
  searching: string;
  noResults: string;
  externalNotice: string;
  selected: string;
  timezoneUnavailable: string;
};

export function GlobalLocationField({
  label,
  value,
  selected,
  locale,
  text,
  onChange,
  onSelect,
  disabled = false,
  help,
}: {
  label: string;
  /** Optional "?" help shown next to the label. */
  help?: ReactNode;
  value: string;
  selected: GlobalLocation | null;
  locale: string;
  text: LocationText;
  onChange: (value: string) => void;
  onSelect: (location: GlobalLocation) => void;
  disabled?: boolean;
}) {
  const fieldId = useId();
  const isSelected = Boolean(selected);
  const displayValue = selected ? formatGlobalLocation(selected, locale) : value;
  const query = displayValue.trim();
  const [results, setResults] = useState<GlobalLocation[]>([]);
  const [searching, setSearching] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  useEffect(() => {
    if (query.length < 2 || isSelected) return;
    const controller = new AbortController();
    const timer = window.setTimeout(async () => {
      setSearching(true);
      try {
        let payloads: Array<{ results?: GlobalLocation[] }>;
        const routedResponse = await fetch(buildGlobalLocationSearchUrl(query, locale), { signal: controller.signal });
        if (routedResponse.ok) {
          payloads = [await routedResponse.json() as { results?: GlobalLocation[] }];
        } else {
          const responses = await Promise.all(buildGeocodingUrls(query, locale).map(async (url) => {
            const response = await fetch(url, { signal: controller.signal });
            if (!response.ok) return { results: [] };
            return response.json() as Promise<{ results?: GlobalLocation[] }>;
          }));
          payloads = responses;
        }
        const matches = mergeGeocodingResults(payloads.map((payload) => normalizeGeocodingResults(payload)));
        const resolved = await Promise.all(matches.map((location) => resolveLocationTimezone(location, fetch)));
        if (!controller.signal.aborted) {
          setResults(resolved);
          setHasSearched(true);
        }
      } catch {
        if (!controller.signal.aborted) {
          setResults([]);
          setHasSearched(true);
        }
      } finally {
        if (!controller.signal.aborted) setSearching(false);
      }
    }, 280);
    return () => {
      controller.abort();
      window.clearTimeout(timer);
    };
  }, [isSelected, locale, query]);

  return <div className="global-location-field">
    <label htmlFor={fieldId}><span>{label}{help}</span><input id={fieldId} value={displayValue} disabled={disabled} autoComplete="off" placeholder={text.placeholder} onChange={(event) => { setResults([]); setSearching(false); setHasSearched(false); onChange(event.target.value); }} /></label>
    <p className="field-hint">{text.externalNotice}</p>
    {!isSelected && query.length >= 2 && searching && <p className="location-status" role="status">{text.searching}</p>}
    {!isSelected && query.length >= 2 && !searching && hasSearched && results.length === 0 && <p className="location-status" role="status">{text.noResults}</p>}
    {!isSelected && query.length >= 2 && !searching && results.length > 0 && <div className="location-results" role="listbox" aria-label={label}>{results.map((location) => <button key={location.id} type="button" role="option" aria-selected="false" onClick={() => { onSelect({ ...location, label: formatGlobalLocation(location, locale) }); setResults([]); setHasSearched(false); }}><span><b>{location.name}</b><small>{[location.admin1, formatGlobalLocation({ ...location, name: "", admin1: undefined }, locale)].filter(Boolean).join(" · ")}</small></span><em>{location.latitude.toFixed(2)}°, {location.longitude.toFixed(2)}° · {location.timezone || text.timezoneUnavailable}</em></button>)}</div>}
    {isSelected && <p className="location-selected">{text.selected}: {displayValue}</p>}
  </div>;
}
