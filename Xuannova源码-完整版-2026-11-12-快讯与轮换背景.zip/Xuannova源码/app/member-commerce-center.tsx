"use client";

import { shareReportText, sourceLabel } from "./share-source-labels";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { rememberScroll } from "./scroll-memory";
import { tpBridgeAvailable, tpSwitchWallet } from "./tp-bridge";
import { formatUnits, type Address, type EIP1193Provider, type Hex } from "viem";
import { BenefitsTable, benefitsText, CREDIT_RULES, CreditPriceList, fillCredits } from "./benefits";
import { creditPackages, firstPurchaseBonusCredits, paymentNetworks, walletProviders, type PaymentNetworkId, type WalletProviderId } from "../worker/commerce-policy";
import {
  availableWallets,
  inTokenPocket,
  connectWallet,
  explorerTxUrl,
  purchasePackage,
  getUsdcCheckoutQuote,
  purchaseUsdcPackage,
  shortAddress,
  signMessage,
  walletInstallUrl,
  WalletError,
  type CheckoutConfig,
  type PaymentStage,
  type WalletOption,
} from "./wallet-connect";
import type { Locale } from "./site-content";
import { tokenDecimals, type UsdcPaymentToken, type UsdcQuote } from "./usdc-payment-quote";
import { ContactIconRow } from "./contact-icons";
import { announceGrowth } from "./growth-notice";
import { GoogleSignIn } from "./google-sign-in";
import { track } from "./analytics";
import { localizeServerError } from "./server-errors";
import { PasswordReset } from "./password-reset";
import { toolkitName } from "./toolkit-copy";
import { MultichainWalletLink } from "./multichain-wallet-link";
import { pathFor } from "./study-navigation";
import { MemberBookshelf } from "./member-bookshelf";
import { ChainBadge, CoinChip, NetworkLogo, payChains, payChainText, type PayChainId } from "./payment-chains";
import { WalletCheck, WalletDirectPay, walletPayText } from "./wallet-direct-pay";
import { MemberAvatar } from "./member-avatar";
import { MemberRooms } from "./member-rooms";
import { MemberPrivacy, MemberProfiles, MemberReports, SolarTermToggle, libraryText } from "./member-library";
import { titleForRoute, type AppRoute, type ToolkitKey } from "./study-suite";

type Member = { id: string; email: string | null; walletAddress: string | null; balance: number; dailyCredits?: number; inviteCode: string | null; signedInWith?: "email" | "wallet"; firstPurchaseOffer?: boolean };
type Invitation = { id: string; label: string; via: "email" | "wallet"; joinedAt: string; reward: number };
type LedgerEntry = { id: string; delta: number; balanceAfter: number; reason: string; createdAt: string; orderId: string | null };
type Order = {
  id: string;
  packageId: string;
  amountUsdt: string;
  settlementCurrency?: "USDT" | "USDC";
  credits: number;
  network: string;
  transactionHash: string;
  status: "pending" | "approved" | "rejected";
  submittedAt: string;
  reviewedAt: string | null;
  reviewNote: string | null;
  buyerAddress: string | null;
  feeWei: string | null;
};

type BnbCoin = "legacy" | UsdcPaymentToken;
/** "USDT · USDC · BNB · ASTER +12" for long coin lists. */
const shortCoins = (coins: string[], keep = 4) => coins.length > keep ? `${coins.slice(0, keep).join(" · ")} +${coins.length - keep}` : coins.join(" · ");
/** BNB Chain coins: USDT pays the credit store directly; USDC, BNB and ASTER go through the checkout contract at a live quote. */
const bnbCoinOptions = (usdcOnly: boolean, extra: string[] = []): Array<{ value: BnbCoin; label: string }> => [
  usdcOnly ? { value: "USDT", label: "USDT" } : { value: "legacy", label: "USDT" },
  { value: "USDC", label: "USDC" }, { value: "BNB", label: "BNB" }, { value: "ASTER", label: "ASTER" },
  ...extra.map((coin) => ({ value: coin as BnbCoin, label: coin })),
];
const bnbQuoteText = {
  updating: { en: "Getting the live price…", "zh-Hans": "正在获取实时价格…", "zh-Hant": "正在取得即時價格…", ja: "リアルタイム価格を取得中…", ko: "실시간 가격을 가져오는 중…", vi: "Đang lấy giá trực tiếp…", th: "กำลังดึงราคาเรียลไทม์…" } as Record<Locale, string>,
  refresh: { en: "Refresh price", "zh-Hans": "刷新报价", "zh-Hant": "重新報價", ja: "価格を更新", ko: "가격 새로고침", vi: "Cập nhật giá", th: "รีเฟรชราคา" } as Record<Locale, string>,
  noRoute: { en: "The price could not be fetched right now (BSC network or exchange pool busy). Try again shortly, or pay with USDT.", "zh-Hans": "暂时取不到价格（BSC 网络或兑换池繁忙），请稍后再试，或改用 USDT 支付。", "zh-Hant": "暫時取不到價格（BSC 網路或兌換池繁忙），請稍後再試，或改用 USDT 付款。", ja: "現在価格を取得できません（BSC ネットワークまたは交換プールが混雑）。少し待つか USDT で支払ってください。", ko: "지금은 가격을 가져올 수 없습니다(BSC 네트워크 또는 교환 풀 혼잡). 잠시 후 다시 시도하거나 USDT로 결제하세요.", vi: "Chưa lấy được giá (mạng BSC hoặc pool đang bận). Thử lại sau hoặc trả bằng USDT.", th: "ยังดึงราคาไม่ได้ (เครือข่าย BSC หรือพูลแลกเปลี่ยนไม่ว่าง) ลองใหม่ภายหลังหรือจ่ายด้วย USDT" } as Record<Locale, string>,
  thinPool: { en: "{coin} has too little exchange depth for this package right now (you would overpay). Choose a smaller package or another coin.", "zh-Hans": "{coin} 目前在交易所的兑换量不够这个套餐（会多付不少），请换小一点的套餐或其他币种。", "zh-Hant": "{coin} 目前在交易所的兌換量不夠這個方案（會多付不少），請換小一點的方案或其他幣種。", ja: "{coin} は現在このパッケージに対して取引量が足りません（割高になります）。小さいパッケージか別の通貨を選んでください。", ko: "{coin}은 지금 이 패키지를 결제하기에 거래 유동성이 부족합니다(더 많이 내게 됩니다). 더 작은 패키지나 다른 코인을 선택하세요.", vi: "{coin} hiện không đủ thanh khoản cho gói này (sẽ trả thêm nhiều). Hãy chọn gói nhỏ hơn hoặc coin khác.", th: "{coin} ตอนนี้สภาพคล่องไม่พอสำหรับแพ็กเกจนี้ (จะจ่ายแพงขึ้น) โปรดเลือกแพ็กเกจเล็กลงหรือเหรียญอื่น" } as Record<Locale, string>,
  shortToken: { en: "Not enough {coin} in this wallet on BNB Chain (about {need} needed, including 1% price buffer).", "zh-Hans": "这个钱包在 BNB 链上的 {coin} 不够（约需 {need}，含 1% 价格浮动）。", "zh-Hant": "這個錢包在 BNB 鏈上的 {coin} 不夠（約需 {need}，含 1% 價格浮動）。", ja: "このウォレットの BNB Chain 上の {coin} が足りません（約 {need} 必要、1% の価格変動分を含む）。", ko: "이 지갑의 BNB 체인 {coin}이 부족합니다(약 {need} 필요, 1% 가격 변동 포함).", vi: "Ví này không đủ {coin} trên BNB Chain (cần khoảng {need}, gồm 1% biên giá).", th: "{coin} บน BNB Chain ในกระเป๋านี้ไม่พอ (ต้องการประมาณ {need} รวมส่วนเผื่อราคา 1%)" } as Record<Locale, string>,
  twoSteps: { en: "Your wallet asks twice the first time: once to allow the {coin} amount, then once to pay.", "zh-Hans": "第一次用 {coin} 支付时钱包会弹出两次：先授权 {coin} 额度，再确认支付。", "zh-Hant": "第一次用 {coin} 付款時錢包會彈出兩次：先授權 {coin} 額度，再確認付款。", ja: "初回は {coin} の使用許可と支払いの2回、ウォレットで承認します。", ko: "처음에는 {coin} 사용 허용과 결제, 두 번 승인합니다.", vi: "Lần đầu ví sẽ hỏi hai lần: cho phép dùng {coin}, rồi thanh toán.", th: "ครั้งแรกกระเป๋าจะถามสองครั้ง: อนุญาตใช้ {coin} แล้วจึงชำระ" } as Record<Locale, string>,
};
const bnbCoinText = {
  direct: { en: "Exact price", "zh-Hans": "按标价直付", "zh-Hant": "按標價直付", ja: "定価で直接", ko: "정가 직접 결제", vi: "Đúng giá niêm yết", th: "จ่ายตามราคา" } as Record<Locale, string>,
  swap: { en: "Live quote", "zh-Hans": "实时报价", "zh-Hant": "即時報價", ja: "リアルタイム見積", ko: "실시간 견적", vi: "Báo giá trực tiếp", th: "ราคาเรียลไทม์" } as Record<Locale, string>,
  directNote: { en: "Pays the package price in USDT straight from your wallet. No quote needed.", "zh-Hans": "直接从钱包支付套餐标价的 USDT，无需报价。", "zh-Hant": "直接從錢包支付方案標價的 USDT，無需報價。", ja: "ウォレットから USDT で定価をそのまま支払います。見積は不要です。", ko: "지갑에서 패키지 가격만큼 USDT를 바로 결제합니다. 견적이 필요 없습니다.", vi: "Trả đúng giá gói bằng USDT từ ví, không cần báo giá.", th: "จ่าย USDT ตามราคาแพ็กเกจจากกระเป๋าโดยตรง ไม่ต้องขอราคา" } as Record<Locale, string>,
  swapNote: { en: "Paying with another coin: get a live quote first; it is converted to USDC at that rate (the quote lasts two minutes).", "zh-Hans": "用其他币种支付：先获取实时报价，按报价换成 USDC 结算（报价两分钟内有效）。", "zh-Hant": "用其他幣種付款：先取得即時報價，按報價換成 USDC 結算（報價兩分鐘內有效）。", ja: "他の通貨で支払う場合は先に見積を取得し、そのレートで USDC に換算して決済します（見積の有効期限は2分）。", ko: "다른 코인으로 결제할 때는 먼저 실시간 견적을 받고, 그 환율로 USDC로 정산합니다(견적은 2분간 유효).", vi: "Trả bằng coin khác: lấy báo giá trước, quy đổi sang USDC theo giá đó (báo giá có hiệu lực 2 phút).", th: "จ่ายด้วยเหรียญอื่น: ขอราคาเรียลไทม์ก่อน แล้วแปลงเป็น USDC ตามราคานั้น (ราคามีผล 2 นาที)" } as Record<Locale, string>,
  afterQuote: { en: "{coin} amount shown after the quote", "zh-Hans": "获取报价后显示 {coin} 数量", "zh-Hant": "取得報價後顯示 {coin} 數量", ja: "見積後に {coin} の数量を表示", ko: "견적 후 {coin} 수량 표시", vi: "Số {coin} hiện sau khi báo giá", th: "แสดงจำนวน {coin} หลังขอราคา" } as Record<Locale, string>,
};
const usdcPaymentCopy: Record<Locale, { method: string; quote: string; estimated: string; maximum: string; expiry: string; fee: string; unavailable: string }> = {
  en: { method: "Payment asset", quote: "Get quote", estimated: "Estimated", maximum: "Maximum authorized", expiry: "Quote expires in two minutes; request a new quote if needed.", fee: "Platform fee in BNB, plus network fees shown in your wallet:", unavailable: "No valid route; request another quote." },
  "zh-Hans": { method: "支付币种", quote: "获取报价", estimated: "预计支付", maximum: "最多支付", expiry: "报价两分钟内有效，过期请重新获取。", fee: "平台手续费如下，另有网络费用，以钱包显示为准：", unavailable: "暂无可用兑换路线，请重新获取报价。" },
  "zh-Hant": { method: "付款幣種", quote: "取得報價", estimated: "預計付款", maximum: "最多付款", expiry: "報價兩分鐘內有效，過期請重新取得。", fee: "平台手續費如下，另有網路費用，以錢包顯示為準：", unavailable: "暫無可用兌換路線，請重新取得報價。" },
  ja: { method: "支払通貨", quote: "見積もり", estimated: "支払予定", maximum: "最大支払額", expiry: "見積もりは2分間有効です。", fee: "以下の手数料のほか、ネットワーク手数料がかかります：", unavailable: "利用可能な交換経路がありません。" },
  ko: { method: "결제 자산", quote: "견적 받기", estimated: "예상 결제액", maximum: "최대 결제액", expiry: "견적은 2분간 유효합니다.", fee: "아래 플랫폼 수수료 외에 네트워크 수수료가 부과됩니다:", unavailable: "사용 가능한 교환 경로가 없습니다." },
  vi: { method: "Tài sản thanh toán", quote: "Lấy báo giá", estimated: "Dự kiến trả", maximum: "Tối đa", expiry: "Báo giá có hiệu lực trong hai phút.", fee: "Phí nền tảng bên dưới, cộng phí mạng theo ví:", unavailable: "Không có tuyến đổi khả dụng." },
  th: { method: "สินทรัพย์ที่ชำระ", quote: "รับใบเสนอราคา", estimated: "ยอดโดยประมาณ", maximum: "ยอดสูงสุด", expiry: "ใบเสนอราคามีอายุสองนาที", fee: "ค่าธรรมเนียมแพลตฟอร์มด้านล่าง และค่าธรรมเนียมเครือข่ายตามที่แสดงในกระเป๋า:", unavailable: "ไม่มีเส้นทางแลกเปลี่ยนที่ใช้ได้" },
};

type CommerceCopy = {
  eyebrow: string; title: string; lead: string; connect: string; connecting: string; signing: string; notInstalled: string; install: string;
  account: string; balance: string; credits: string; signOut: string; packages: string; choose: string; payment: string;
  network: string; fee: string; total: string; pay: string; payWith: string; chainNotice: string; autoCredit: string; notConfigured: string;
  stageSwitching: string; stageApproving: string; stagePaying: string; stageConfirming: string; stageVerifying: string; paid: string; pendingChain: string;
  orders: string; noOrders: string; pending: string; approved: string; rejected: string; viewTx: string; loading: string; connectFirst: string;
  requestFailed: string; rejectedByUser: string; wrongChain: string; insufficientUsdt: string; insufficientBnb: string; invalidInviteCode: string;
  inviteTitle: string; inviteLead: string; inviteCode: string; inviteInput: string; inviteInputHint: string; copyInvite: string; inviteCopied: string; inviteReward: string;
  refreshBalance: string; balanceRefreshed: string; createFirst: string;
};

const copy: Record<Locale, CommerceCopy> = {
  en: { eyebrow: "XUANNOVA · MEMBERSHIP", title: "Your study credits", lead: "Sign in with your wallet and pay in USDT (BEP20). Credits are issued automatically once the purchase is confirmed on BNB Smart Chain.", connect: "Connect wallet", connecting: "Connecting…", signing: "Confirm the sign-in message in your wallet…", notInstalled: "Not detected", install: "Install", account: "Signed-in wallet", balance: "Available balance", credits: "credits", signOut: "Sign out", packages: "Credit packages", choose: "Choose", payment: "Pay with wallet", network: "Network", fee: "Platform fee", total: "You pay", pay: "Pay", payWith: "Paying wallet", chainNotice: "Your wallet will switch to BNB Smart Chain. You need USDT (BEP20) for the package plus a little BNB for the platform fee and network fees.", autoCredit: "Credits arrive automatically after on-chain confirmation — no manual review.", notConfigured: "Checkout is not available yet. The store contract has not been deployed.", stageSwitching: "Switching to BNB Smart Chain…", stageApproving: "Approve USDT spending in your wallet…", stagePaying: "Confirm the payment in your wallet…", stageConfirming: "Waiting for block confirmations…", stageVerifying: "Verifying the purchase and issuing credits…", paid: "Payment confirmed. Credits have been added to your balance.", pendingChain: "Payment is still confirming. Credits will appear shortly — use Refresh balance.", orders: "Your purchases", noOrders: "No purchase yet.", pending: "Confirming", approved: "Credited", rejected: "Rejected", viewTx: "View on BscScan", loading: "Loading account…", connectFirst: "Connect a wallet to select a package.", requestFailed: "We could not complete this request. Please try again.", rejectedByUser: "The request was cancelled in your wallet.", wrongChain: "Please switch your wallet to BNB Smart Chain.", insufficientUsdt: "Not enough USDT (BEP20) in this wallet.", insufficientBnb: "Not enough BNB for the platform fee and network fees.", invalidInviteCode: "That invitation code is not valid.", inviteTitle: "Invite & earn", inviteLead: "Share your invitation link. When someone you invite completes their first purchase, you both receive 5 credits.", inviteCode: "Your invitation code", inviteInput: "Invitation code (optional)", inviteInputHint: "Enter a code from the person who invited you", copyInvite: "Copy invitation link", inviteCopied: "Invitation link copied", inviteReward: "5 credits each after their first purchase", refreshBalance: "Refresh balance", balanceRefreshed: "Balance refreshed from your account.", createFirst: "Create an account or sign in to select a package." },
  "zh-Hans": { eyebrow: "Xuannova · 会员", title: "你的研习积分", lead: "使用钱包登录，用 USDT（BEP20）支付。购买在币安智能链上确认后，积分自动到账。", connect: "连接钱包", connecting: "连接中…", signing: "请在钱包中确认登录签名…", notInstalled: "未检测到", install: "安装", account: "已登录钱包", balance: "可用余额", credits: "积分", signOut: "退出登录", packages: "积分套餐", choose: "选择", payment: "钱包支付", network: "网络", fee: "平台手续费", total: "实付", pay: "支付", payWith: "付款钱包", chainNotice: "钱包将切换到币安智能链（BSC）。需持有套餐对应的 USDT（BEP20），以及少量 BNB 用于平台手续费和网络费用。", autoCredit: "链上确认后积分自动到账，无需人工审核。", notConfigured: "支付暂未开放：购买合约尚未部署。", stageSwitching: "正在切换到币安智能链…", stageApproving: "请在钱包中授权 USDT…", stagePaying: "请在钱包中确认支付…", stageConfirming: "等待区块确认…", stageVerifying: "正在核验交易并发放积分…", paid: "支付成功，积分已到账。", pendingChain: "交易仍在确认中，积分稍后到账，可点击“刷新余额”。", orders: "你的购买记录", noOrders: "尚无购买记录。", pending: "确认中", approved: "已到账", rejected: "已拒绝", viewTx: "在 BscScan 查看", loading: "正在加载账户…", connectFirst: "请先连接钱包，再选择套餐。", requestFailed: "暂时无法完成请求，请稍后再试。", rejectedByUser: "已在钱包中取消操作。", wrongChain: "请将钱包切换到币安智能链（BSC）。", insufficientUsdt: "钱包内 USDT（BEP20）余额不足。", insufficientBnb: "BNB 不足，无法支付平台手续费和网络费用。", invalidInviteCode: "邀请码无效，请检查后重试。", inviteTitle: "邀请奖励", inviteLead: "受邀会员首次成功购买服务后，邀请人和该会员各获得 5 积分。", inviteCode: "你的邀请码", inviteInput: "邀请码（可选）", inviteInputHint: "填写邀请你的用户提供的邀请码", copyInvite: "复制邀请链接", inviteCopied: "邀请链接已复制", inviteReward: "首次成功购买后，双方各得 5 积分", refreshBalance: "刷新余额", balanceRefreshed: "已从账户刷新积分余额。", createFirst: "请先创建账户或登录，再选择套餐。" },
  "zh-Hant": { eyebrow: "Xuannova · 會員", title: "你的研習積分", lead: "使用錢包登入，以 USDT（BEP20）付款。購買在幣安智能鏈上確認後，積分自動入帳。", connect: "連接錢包", connecting: "連接中…", signing: "請在錢包中確認登入簽名…", notInstalled: "未偵測到", install: "安裝", account: "已登入錢包", balance: "可用餘額", credits: "積分", signOut: "登出", packages: "積分方案", choose: "選擇", payment: "錢包付款", network: "網路", fee: "平台手續費", total: "實付", pay: "付款", payWith: "付款錢包", chainNotice: "錢包將切換到幣安智能鏈（BSC）。需持有方案對應的 USDT（BEP20），以及少量 BNB 用於平台手續費與網路費用。", autoCredit: "鏈上確認後積分自動入帳，無需人工審核。", notConfigured: "付款尚未開放：購買合約尚未部署。", stageSwitching: "正在切換到幣安智能鏈…", stageApproving: "請在錢包中授權 USDT…", stagePaying: "請在錢包中確認付款…", stageConfirming: "等待區塊確認…", stageVerifying: "正在核驗交易並發放積分…", paid: "付款成功，積分已入帳。", pendingChain: "交易仍在確認中，積分稍後入帳，可點選「重新整理餘額」。", orders: "你的購買紀錄", noOrders: "尚無購買紀錄。", pending: "確認中", approved: "已入帳", rejected: "已拒絕", viewTx: "在 BscScan 查看", loading: "正在載入帳戶…", connectFirst: "請先連接錢包，再選擇方案。", requestFailed: "暫時無法完成請求，請稍後再試。", rejectedByUser: "已在錢包中取消操作。", wrongChain: "請將錢包切換到幣安智能鏈（BSC）。", insufficientUsdt: "錢包內 USDT（BEP20）餘額不足。", insufficientBnb: "BNB 不足，無法支付平台手續費與網路費用。", invalidInviteCode: "邀請碼無效，請檢查後再試。", inviteTitle: "邀請獎勵", inviteLead: "受邀會員首次成功購買服務後，邀請人和該會員各獲得 5 積分。", inviteCode: "你的邀請碼", inviteInput: "邀請碼（選填）", inviteInputHint: "填寫邀請你的用戶提供的邀請碼", copyInvite: "複製邀請連結", inviteCopied: "邀請連結已複製", inviteReward: "首次成功購買後，雙方各得 5 積分", refreshBalance: "重新整理餘額", balanceRefreshed: "已從帳戶重新整理積分餘額。", createFirst: "請先建立帳戶或登入，再選擇方案。" },
  ja: { eyebrow: "Xuannova · メンバー", title: "学習クレジット", lead: "ウォレットでサインインし、USDT（BEP20）で支払います。BNB Smart Chain 上で購入が確定すると、クレジットは自動的に付与されます。", connect: "ウォレットを接続", connecting: "接続中…", signing: "ウォレットでサインインメッセージを承認してください…", notInstalled: "未検出", install: "インストール", account: "サインイン中のウォレット", balance: "利用可能残高", credits: "クレジット", signOut: "サインアウト", packages: "クレジットパッケージ", choose: "選択", payment: "ウォレットで支払う", network: "ネットワーク", fee: "プラットフォーム手数料", total: "お支払い額", pay: "支払う", payWith: "支払うウォレット", chainNotice: "ウォレットは BNB Smart Chain に切り替わります。パッケージ分の USDT（BEP20）と、手数料およびネットワーク手数料用の少量の BNB が必要です。", autoCredit: "オンチェーン確定後、クレジットは自動付与されます。手動審査はありません。", notConfigured: "決済はまだ利用できません。ストアコントラクトが未デプロイです。", stageSwitching: "BNB Smart Chain に切り替え中…", stageApproving: "ウォレットで USDT の使用を承認してください…", stagePaying: "ウォレットで支払いを確認してください…", stageConfirming: "ブロック確認を待っています…", stageVerifying: "購入を検証しクレジットを付与中…", paid: "支払いが確定し、クレジットが残高に追加されました。", pendingChain: "取引はまだ確認中です。まもなく反映されます。「残高を更新」をお試しください。", orders: "購入履歴", noOrders: "購入履歴はまだありません。", pending: "確認中", approved: "付与済み", rejected: "却下", viewTx: "BscScan で見る", loading: "アカウントを読み込み中…", connectFirst: "パッケージを選ぶ前にウォレットを接続してください。", requestFailed: "リクエストを完了できませんでした。もう一度お試しください。", rejectedByUser: "ウォレットで操作がキャンセルされました。", wrongChain: "ウォレットを BNB Smart Chain に切り替えてください。", insufficientUsdt: "このウォレットの USDT（BEP20）が不足しています。", insufficientBnb: "手数料とネットワーク手数料用の BNB が不足しています。", invalidInviteCode: "招待コードが正しくありません。", inviteTitle: "招待特典", inviteLead: "招待リンクを共有してください。招待した方が初めて購入すると、お二人に5クレジットずつ付与されます。", inviteCode: "あなたの招待コード", inviteInput: "招待コード（任意）", inviteInputHint: "招待者から受け取ったコードを入力", copyInvite: "招待リンクをコピー", inviteCopied: "招待リンクをコピーしました", inviteReward: "初回購入後、お二人に各5クレジット", refreshBalance: "残高を更新", balanceRefreshed: "アカウントからクレジット残高を更新しました。", createFirst: "パッケージを選ぶ前に、アカウントを作成またはサインインしてください。" },
  ko: { eyebrow: "Xuannova · 멤버십", title: "학습 크레딧", lead: "지갑으로 로그인하고 USDT(BEP20)로 결제하세요. BNB 스마트 체인에서 구매가 확정되면 크레딧이 자동 지급됩니다.", connect: "지갑 연결", connecting: "연결 중…", signing: "지갑에서 로그인 메시지를 확인하세요…", notInstalled: "감지되지 않음", install: "설치", account: "로그인한 지갑", balance: "사용 가능 잔액", credits: "크레딧", signOut: "로그아웃", packages: "크레딧 패키지", choose: "선택", payment: "지갑으로 결제", network: "네트워크", fee: "플랫폼 수수료", total: "결제 금액", pay: "결제", payWith: "결제 지갑", chainNotice: "지갑이 BNB 스마트 체인으로 전환됩니다. 패키지 금액의 USDT(BEP20)와 수수료·네트워크 수수료용 소량의 BNB가 필요합니다.", autoCredit: "온체인 확정 후 크레딧이 자동 지급됩니다. 수동 검토가 없습니다.", notConfigured: "아직 결제를 이용할 수 없습니다. 스토어 컨트랙트가 배포되지 않았습니다.", stageSwitching: "BNB 스마트 체인으로 전환 중…", stageApproving: "지갑에서 USDT 사용을 승인하세요…", stagePaying: "지갑에서 결제를 확인하세요…", stageConfirming: "블록 확인 대기 중…", stageVerifying: "구매를 검증하고 크레딧을 지급하는 중…", paid: "결제가 확정되어 크레딧이 잔액에 추가되었습니다.", pendingChain: "거래가 아직 확인 중입니다. 곧 반영됩니다. '잔액 새로고침'을 눌러 주세요.", orders: "구매 내역", noOrders: "아직 구매 내역이 없습니다.", pending: "확인 중", approved: "지급 완료", rejected: "거절됨", viewTx: "BscScan에서 보기", loading: "계정을 불러오는 중…", connectFirst: "패키지를 선택하려면 먼저 지갑을 연결하세요.", requestFailed: "요청을 완료할 수 없습니다. 다시 시도해 주세요.", rejectedByUser: "지갑에서 요청이 취소되었습니다.", wrongChain: "지갑을 BNB 스마트 체인으로 전환해 주세요.", insufficientUsdt: "이 지갑의 USDT(BEP20)가 부족합니다.", insufficientBnb: "수수료와 네트워크 수수료용 BNB가 부족합니다.", invalidInviteCode: "유효하지 않은 초대 코드입니다.", inviteTitle: "초대 보상", inviteLead: "초대 링크를 공유하세요. 초대한 분이 첫 구매를 마치면 두 분 모두 5크레딧을 받습니다.", inviteCode: "내 초대 코드", inviteInput: "초대 코드(선택)", inviteInputHint: "초대한 사람이 제공한 코드를 입력하세요", copyInvite: "초대 링크 복사", inviteCopied: "초대 링크가 복사되었습니다", inviteReward: "첫 구매 후 두 분께 각각 5크레딧", refreshBalance: "잔액 새로고침", balanceRefreshed: "계정의 크레딧 잔액을 새로고침했습니다.", createFirst: "패키지를 선택하려면 먼저 계정을 만들거나 로그인하세요." },
  vi: { eyebrow: "XUANNOVA · THÀNH VIÊN", title: "Điểm học tập của bạn", lead: "Đăng nhập bằng ví và thanh toán bằng USDT (BEP20). Điểm được cấp tự động khi giao dịch được xác nhận trên BNB Smart Chain.", connect: "Kết nối ví", connecting: "Đang kết nối…", signing: "Xác nhận thông điệp đăng nhập trong ví…", notInstalled: "Chưa phát hiện", install: "Cài đặt", account: "Ví đã đăng nhập", balance: "Số dư khả dụng", credits: "điểm", signOut: "Đăng xuất", packages: "Gói điểm", choose: "Chọn", payment: "Thanh toán bằng ví", network: "Mạng lưới", fee: "Phí nền tảng", total: "Bạn trả", pay: "Thanh toán", payWith: "Ví thanh toán", chainNotice: "Ví sẽ chuyển sang BNB Smart Chain. Bạn cần USDT (BEP20) cho gói và một ít BNB cho phí nền tảng và phí mạng.", autoCredit: "Điểm được cấp tự động sau khi xác nhận trên chuỗi — không cần duyệt thủ công.", notConfigured: "Thanh toán chưa khả dụng. Hợp đồng cửa hàng chưa được triển khai.", stageSwitching: "Đang chuyển sang BNB Smart Chain…", stageApproving: "Phê duyệt chi tiêu USDT trong ví…", stagePaying: "Xác nhận thanh toán trong ví…", stageConfirming: "Đang chờ xác nhận khối…", stageVerifying: "Đang xác minh giao dịch và cấp điểm…", paid: "Thanh toán đã xác nhận. Điểm đã được cộng vào số dư.", pendingChain: "Giao dịch vẫn đang xác nhận. Điểm sẽ sớm xuất hiện — hãy dùng Làm mới số dư.", orders: "Giao dịch của bạn", noOrders: "Chưa có giao dịch nào.", pending: "Đang xác nhận", approved: "Đã cấp", rejected: "Đã từ chối", viewTx: "Xem trên BscScan", loading: "Đang tải tài khoản…", connectFirst: "Hãy kết nối ví trước khi chọn gói.", requestFailed: "Không thể hoàn tất yêu cầu. Vui lòng thử lại.", rejectedByUser: "Yêu cầu đã bị hủy trong ví.", wrongChain: "Vui lòng chuyển ví sang BNB Smart Chain.", insufficientUsdt: "Không đủ USDT (BEP20) trong ví này.", insufficientBnb: "Không đủ BNB cho phí nền tảng và phí mạng.", invalidInviteCode: "Mã mời không hợp lệ.", inviteTitle: "Mời bạn bè & nhận điểm", inviteLead: "Chia sẻ liên kết mời của bạn. Khi người được mời hoàn tất lần mua đầu tiên, cả hai đều nhận 5 điểm.", inviteCode: "Mã mời của bạn", inviteInput: "Mã mời (không bắt buộc)", inviteInputHint: "Nhập mã từ người đã mời bạn", copyInvite: "Sao chép liên kết mời", inviteCopied: "Đã sao chép liên kết mời", inviteReward: "Mỗi bên 5 điểm sau lần mua đầu tiên", refreshBalance: "Làm mới số dư", balanceRefreshed: "Đã làm mới số dư điểm từ tài khoản của bạn.", createFirst: "Hãy tạo tài khoản hoặc đăng nhập trước khi chọn gói." },
  th: { eyebrow: "Xuannova · สมาชิก", title: "เครดิตการศึกษาของคุณ", lead: "เข้าสู่ระบบด้วยกระเป๋าเงินและชำระด้วย USDT (BEP20) เครดิตจะเพิ่มอัตโนมัติเมื่อการซื้อได้รับการยืนยันบน BNB Smart Chain", connect: "เชื่อมต่อกระเป๋าเงิน", connecting: "กำลังเชื่อมต่อ…", signing: "ยืนยันข้อความเข้าสู่ระบบในกระเป๋าเงิน…", notInstalled: "ไม่พบ", install: "ติดตั้ง", account: "กระเป๋าเงินที่เข้าสู่ระบบ", balance: "ยอดคงเหลือที่ใช้ได้", credits: "เครดิต", signOut: "ออกจากระบบ", packages: "แพ็กเกจเครดิต", choose: "เลือก", payment: "ชำระด้วยกระเป๋าเงิน", network: "เครือข่าย", fee: "ค่าธรรมเนียมแพลตฟอร์ม", total: "ยอดชำระ", pay: "ชำระเงิน", payWith: "กระเป๋าที่ชำระ", chainNotice: "กระเป๋าเงินจะสลับไปยัง BNB Smart Chain คุณต้องมี USDT (BEP20) ตามแพ็กเกจ และ BNB เล็กน้อยสำหรับค่าธรรมเนียมและค่าธรรมเนียมเครือข่าย", autoCredit: "เครดิตเพิ่มอัตโนมัติหลังยืนยันบนเชน ไม่ต้องตรวจสอบด้วยมือ", notConfigured: "ยังไม่เปิดให้ชำระเงิน สัญญาร้านค้ายังไม่ได้ติดตั้ง", stageSwitching: "กำลังสลับไป BNB Smart Chain…", stageApproving: "อนุมัติการใช้ USDT ในกระเป๋าเงิน…", stagePaying: "ยืนยันการชำระเงินในกระเป๋าเงิน…", stageConfirming: "รอการยืนยันบล็อก…", stageVerifying: "กำลังตรวจสอบการซื้อและเพิ่มเครดิต…", paid: "ชำระเงินสำเร็จ เครดิตถูกเพิ่มในยอดคงเหลือแล้ว", pendingChain: "ธุรกรรมยังอยู่ระหว่างยืนยัน เครดิตจะปรากฏในไม่ช้า — กด รีเฟรชยอดคงเหลือ", orders: "รายการซื้อของคุณ", noOrders: "ยังไม่มีรายการซื้อ", pending: "กำลังยืนยัน", approved: "เพิ่มเครดิตแล้ว", rejected: "ปฏิเสธแล้ว", viewTx: "ดูบน BscScan", loading: "กำลังโหลดบัญชี…", connectFirst: "กรุณาเชื่อมต่อกระเป๋าเงินก่อนเลือกแพ็กเกจ", requestFailed: "ไม่สามารถดำเนินการตามคำขอได้ โปรดลองอีกครั้ง", rejectedByUser: "คำขอถูกยกเลิกในกระเป๋าเงิน", wrongChain: "กรุณาสลับกระเป๋าเงินไปยัง BNB Smart Chain", insufficientUsdt: "USDT (BEP20) ในกระเป๋าเงินนี้ไม่พอ", insufficientBnb: "BNB ไม่พอสำหรับค่าธรรมเนียมและค่าธรรมเนียมเครือข่าย", invalidInviteCode: "รหัสเชิญไม่ถูกต้อง", inviteTitle: "เชิญเพื่อนและรับเครดิต", inviteLead: "แชร์ลิงก์เชิญของคุณ เมื่อผู้ที่คุณเชิญซื้อครั้งแรกสำเร็จ ทั้งสองฝ่ายจะได้รับคนละ 5 คะแนน", inviteCode: "รหัสเชิญของคุณ", inviteInput: "รหัสเชิญ (ไม่บังคับ)", inviteInputHint: "กรอกรหัสจากผู้ที่เชิญคุณ", copyInvite: "คัดลอกลิงก์เชิญ", inviteCopied: "คัดลอกลิงก์เชิญแล้ว", inviteReward: "คนละ 5 คะแนนหลังการซื้อครั้งแรก", refreshBalance: "รีเฟรชยอดคงเหลือ", balanceRefreshed: "รีเฟรชยอดเครดิตจากบัญชีของคุณแล้ว", createFirst: "กรุณาสร้างบัญชีหรือเข้าสู่ระบบก่อนเลือกแพ็กเกจ" },
};

const packageNames: Record<Locale, Record<(typeof creditPackages)[number]["id"], string>> = {
  en: { seed: "Starter Pack", path: "Popular Pack", ritual: "Value Pack", synthesis: "Ultimate Pack" },
  "zh-Hans": { seed: "入门体验包", path: "热门套餐", ritual: "大容量套餐", synthesis: "至尊旗舰套餐" },
  "zh-Hant": { seed: "入門體驗包", path: "熱門方案", ritual: "大容量方案", synthesis: "至尊旗艦方案" },
  ja: { seed: "スターターパック", path: "人気パック", ritual: "大容量パック", synthesis: "プレミアムパック" },
  ko: { seed: "입문 체험 패키지", path: "인기 패키지", ritual: "대용량 패키지", synthesis: "프리미엄 패키지" },
  vi: { seed: "Gói trải nghiệm", path: "Gói phổ biến", ritual: "Gói dung lượng lớn", synthesis: "Gói cao cấp" },
  th: { seed: "แพ็กเกจเริ่มต้น", path: "แพ็กเกจยอดนิยม", ritual: "แพ็กเกจขนาดใหญ่", synthesis: "แพ็กเกจพรีเมียม" },
};

// Daily bonus: +5 per local day, kept up to 20 (see worker/commerce-api.ts refreshDailyCredits).
const dailyBonusLine: Record<Locale, (credits: number) => string> = {
  en: (credits) => `Daily bonus balance: ${credits} credits · +5 each day at your local midnight, kept up to 20`,
  "zh-Hans": (credits) => `赠送积分 ${credits} · 每天当地时间 0 点 +5，最多累积 20`,
  "zh-Hant": (credits) => `贈送積分 ${credits} · 每天當地時間 0 點 +5，最多累積 20`,
  ja: (credits) => `ボーナス残高 ${credits} · 毎日現地時間0時に+5、最大20まで貯まります`,
  ko: (credits) => `보너스 잔액 ${credits} · 매일 현지 시간 자정에 +5, 최대 20까지 적립`,
  vi: (credits) => `Điểm tặng: ${credits} · Mỗi ngày +5 lúc 0 giờ giờ địa phương, tích tối đa 20`,
  th: (credits) => `คะแนนโบนัส ${credits} · เพิ่ม +5 ทุกวันเวลาเที่ยงคืนตามเวลาท้องถิ่น สะสมได้สูงสุด 20`,
};
const emailFirstNote: Record<Locale, string> = {
  en: "New email? Your account is created with this password. No verification code needed.",
  "zh-Hans": "新邮箱会用这个密码直接创建账户，无需验证码。",
  "zh-Hant": "新信箱會用這個密碼直接建立帳戶，無需驗證碼。",
  ja: "新しいメールアドレスは、このパスワードでそのままアカウントが作成されます。確認コードは不要です。",
  ko: "새 이메일은 이 비밀번호로 바로 계정이 만들어집니다. 인증 코드는 필요 없습니다.",
  vi: "Email mới sẽ được tạo tài khoản ngay với mật khẩu này, không cần mã xác minh.",
  th: "อีเมลใหม่จะสร้างบัญชีด้วยรหัสผ่านนี้ทันที ไม่ต้องใช้รหัสยืนยัน",
};
const exclusiveLabel: Record<Locale, string> = { en: "Exclusive", "zh-Hans": "专属", "zh-Hant": "專屬", ja: "専用", ko: "전용", vi: "Riêng", th: "เฉพาะคุณ" };

const cardCopy: Record<Locale, { pay: string; opening: string; waiting: string; paid: string; failed: string; pending: string }> = {
  en: { pay: "Pay by card", opening: "Opening secure card checkout…", waiting: "Confirming your card payment…", paid: "Payment received. Your credits have been added.", failed: "The card payment did not go through. No credits were charged.", pending: "Your payment is still being confirmed. Credits appear here as soon as it completes." },
  "zh-Hans": { pay: "银行卡支付", opening: "正在打开安全的银行卡支付页面…", waiting: "正在确认你的银行卡付款…", paid: "已收到付款，积分已到账。", failed: "银行卡付款未成功，没有扣款。", pending: "付款仍在确认中，完成后积分会显示在这里。" },
  "zh-Hant": { pay: "銀行卡付款", opening: "正在開啟安全的銀行卡付款頁面…", waiting: "正在確認你的銀行卡付款…", paid: "已收到付款，積分已入帳。", failed: "銀行卡付款未成功，沒有扣款。", pending: "付款仍在確認中，完成後積分會顯示在這裡。" },
  ja: { pay: "カードで支払う", opening: "安全なカード決済ページを開いています…", waiting: "カード決済を確認しています…", paid: "お支払いを受け付けました。クレジットを追加しました。", failed: "カード決済は完了しませんでした。請求はありません。", pending: "お支払いを確認中です。完了しだいここにクレジットが表示されます。" },
  ko: { pay: "카드로 결제", opening: "안전한 카드 결제 페이지를 여는 중…", waiting: "카드 결제를 확인하는 중…", paid: "결제가 완료되어 크레딧이 추가되었습니다.", failed: "카드 결제가 완료되지 않았습니다. 청구되지 않았습니다.", pending: "결제를 확인하는 중입니다. 완료되면 여기에 크레딧이 표시됩니다." },
  vi: { pay: "Thanh toán bằng thẻ", opening: "Đang mở trang thanh toán thẻ an toàn…", waiting: "Đang xác nhận thanh toán thẻ…", paid: "Đã nhận thanh toán. Điểm đã được cộng.", failed: "Thanh toán thẻ không thành công. Bạn không bị trừ tiền.", pending: "Thanh toán vẫn đang được xác nhận. Điểm sẽ hiện ở đây khi hoàn tất." },
  th: { pay: "ชำระด้วยบัตร", opening: "กำลังเปิดหน้าชำระเงินด้วยบัตรที่ปลอดภัย…", waiting: "กำลังยืนยันการชำระด้วยบัตร…", paid: "ได้รับการชำระแล้ว เพิ่มเครดิตเรียบร้อย", failed: "การชำระด้วยบัตรไม่สำเร็จ ไม่มีการเรียกเก็บเงิน", pending: "การชำระยังอยู่ระหว่างยืนยัน เครดิตจะแสดงที่นี่เมื่อเสร็จสิ้น" },
};

type DualCopy = {
  email: string; password: string; signIn: string; create: string; createAndSignIn: string; switchToSignIn: string; switchToCreate: string; accountExists: string; invalidCredentials: string; passwordRule: string;
  hash: string; hashHint: string; submit: string; manual: string; warning: string; recipient: string; copy: string; copied: string;
  orEmail: string; orWallet: string; linkWallet: string; walletLinked: string; walletTaken: string; manualTitle: string; manualHint: string;
};

const dualCopy: Record<Locale, DualCopy> = {
  en: { email: "Email address", password: "Password", signIn: "Sign in", create: "Create account", createAndSignIn: "Create & sign in", switchToSignIn: "Already have an account? Sign in", switchToCreate: "New here? Create an account", accountExists: "An account already uses this email. Please sign in instead.", invalidCredentials: "The email or password is not correct.", passwordRule: "Use a password with 6 to 128 characters.", hash: "Transaction hash", hashHint: "Paste the completed USDT transfer hash after payment.", submit: "Submit for review", manual: "A reviewer confirms the transfer and then credits the account. Scanning a code never adds credits automatically.", warning: "Send only USDT on the selected network. A transfer on another network cannot be credited.", recipient: "Recipient address", copy: "Copy", copied: "Copied", orEmail: "Or sign in with email", orWallet: "Or connect a wallet", linkWallet: "Connect a wallet to pay on-chain", walletLinked: "Wallet linked to your account.", walletTaken: "This wallet is already linked to another account.", manualTitle: "Manual USDT transfer (reviewed by staff)", manualHint: "No wallet? Transfer USDT to the address below and submit the transaction hash. Credits are issued after review." },
  "zh-Hans": { email: "邮箱地址", password: "密码", signIn: "登录", create: "创建账户", createAndSignIn: "创建并登录", switchToSignIn: "已有账户？去登录", switchToCreate: "首次使用？创建账户", accountExists: "该邮箱已注册，请直接登录。", invalidCredentials: "邮箱或密码不正确。", passwordRule: "密码长度需为 6 至 128 个字符。", hash: "交易哈希", hashHint: "完成 USDT 转账后，粘贴对应的交易哈希。", submit: "提交审核", manual: "审核人员确认转账后才会为账户发放积分；扫码本身绝不会自动到账。", warning: "仅可在所选网络发送 USDT。使用其他网络转账将无法入账。", recipient: "收款地址", copy: "复制", copied: "已复制", orEmail: "或使用邮箱登录", orWallet: "或连接钱包登录", linkWallet: "连接钱包以链上支付", walletLinked: "钱包已绑定到当前账户。", walletTaken: "该钱包已绑定到其他账户。", manualTitle: "手动转账 USDT（人工审核）", manualHint: "没有钱包？向下方地址转账 USDT 后提交交易哈希，审核通过后发放积分。" },
  "zh-Hant": { email: "信箱地址", password: "密碼", signIn: "登入", create: "建立帳戶", createAndSignIn: "建立並登入", switchToSignIn: "已有帳戶？前往登入", switchToCreate: "首次使用？建立帳戶", accountExists: "此信箱已註冊，請直接登入。", invalidCredentials: "信箱或密碼不正確。", passwordRule: "密碼長度須為 6 至 128 個字元。", hash: "交易雜湊", hashHint: "完成 USDT 轉帳後，貼上對應的交易雜湊。", submit: "提交審核", manual: "審核人員確認轉帳後才會為帳戶發放積分；掃碼本身絕不會自動入帳。", warning: "僅可在所選網路傳送 USDT。使用其他網路轉帳將無法入帳。", recipient: "收款地址", copy: "複製", copied: "已複製", orEmail: "或使用信箱登入", orWallet: "或連接錢包登入", linkWallet: "連接錢包以鏈上付款", walletLinked: "錢包已綁定到目前帳戶。", walletTaken: "此錢包已綁定到其他帳戶。", manualTitle: "手動轉帳 USDT（人工審核）", manualHint: "沒有錢包？向下方地址轉帳 USDT 後提交交易雜湊，審核通過後發放積分。" },
  ja: { email: "メールアドレス", password: "パスワード", signIn: "サインイン", create: "アカウント作成", createAndSignIn: "作成してサインイン", switchToSignIn: "すでにアカウントをお持ちですか？ サインイン", switchToCreate: "初めてですか？ アカウントを作成", accountExists: "このメールアドレスはすでに登録されています。サインインしてください。", invalidCredentials: "メールアドレスまたはパスワードが正しくありません。", passwordRule: "パスワードは6～128文字で設定してください。", hash: "トランザクションハッシュ", hashHint: "USDT送金の完了後、該当するトランザクションハッシュを貼り付けてください。", submit: "審査に送信", manual: "担当者が送金を確認してからクレジットを付与します。QRコードを読み取るだけで自動付与されることはありません。", warning: "選択したネットワーク上のUSDTのみ送信してください。他のネットワークの送金は加算できません。", recipient: "受取アドレス", copy: "コピー", copied: "コピー済み", orEmail: "またはメールでサインイン", orWallet: "またはウォレットを接続", linkWallet: "ウォレットを接続してオンチェーンで支払う", walletLinked: "ウォレットをアカウントに紐付けました。", walletTaken: "このウォレットは別のアカウントに紐付いています。", manualTitle: "USDT 手動送金（担当者が審査）", manualHint: "ウォレットがない場合は、下記アドレスに USDT を送金しトランザクションハッシュを送信してください。審査後にクレジットが付与されます。" },
  ko: { email: "이메일 주소", password: "비밀번호", signIn: "로그인", create: "계정 만들기", createAndSignIn: "계정 만들기 및 로그인", switchToSignIn: "이미 계정이 있나요? 로그인", switchToCreate: "처음이신가요? 계정 만들기", accountExists: "이 이메일은 이미 등록되어 있습니다. 로그인해 주세요.", invalidCredentials: "이메일 또는 비밀번호가 올바르지 않습니다.", passwordRule: "비밀번호는 6자에서 128자로 설정해 주세요.", hash: "거래 해시", hashHint: "USDT 전송을 완료한 후 해당 거래 해시를 붙여넣으세요.", submit: "검토 요청 제출", manual: "검토자가 전송을 확인한 뒤 크레딧을 지급합니다. QR 코드를 스캔하는 것만으로는 자동 지급되지 않습니다.", warning: "선택한 네트워크에서 USDT만 보내세요. 다른 네트워크 전송은 적립할 수 없습니다.", recipient: "수취 주소", copy: "복사", copied: "복사됨", orEmail: "또는 이메일로 로그인", orWallet: "또는 지갑 연결", linkWallet: "지갑을 연결해 온체인 결제", walletLinked: "지갑이 계정에 연결되었습니다.", walletTaken: "이 지갑은 이미 다른 계정에 연결되어 있습니다.", manualTitle: "USDT 수동 전송(담당자 검토)", manualHint: "지갑이 없나요? 아래 주소로 USDT를 보낸 뒤 거래 해시를 제출하세요. 검토 후 크레딧이 지급됩니다." },
  vi: { email: "Địa chỉ email", password: "Mật khẩu", signIn: "Đăng nhập", create: "Tạo tài khoản", createAndSignIn: "Tạo tài khoản và đăng nhập", switchToSignIn: "Đã có tài khoản? Đăng nhập", switchToCreate: "Lần đầu dùng? Tạo tài khoản", accountExists: "Email này đã được đăng ký. Vui lòng đăng nhập.", invalidCredentials: "Email hoặc mật khẩu không đúng.", passwordRule: "Mật khẩu phải dài từ 6 đến 128 ký tự.", hash: "Mã băm giao dịch", hashHint: "Sau khi hoàn tất chuyển USDT, hãy dán mã băm giao dịch tương ứng.", submit: "Gửi để xét duyệt", manual: "Người duyệt xác nhận giao dịch rồi mới cấp điểm. Quét mã không bao giờ tự động cộng điểm.", warning: "Chỉ gửi USDT trên mạng đã chọn. Chuyển trên mạng khác không thể được ghi có.", recipient: "Địa chỉ nhận", copy: "Sao chép", copied: "Đã sao chép", orEmail: "Hoặc đăng nhập bằng email", orWallet: "Hoặc kết nối ví", linkWallet: "Kết nối ví để thanh toán trên chuỗi", walletLinked: "Đã liên kết ví với tài khoản của bạn.", walletTaken: "Ví này đã được liên kết với tài khoản khác.", manualTitle: "Chuyển USDT thủ công (nhân viên duyệt)", manualHint: "Không có ví? Chuyển USDT đến địa chỉ bên dưới rồi gửi mã băm giao dịch. Điểm được cấp sau khi duyệt." },
  th: { email: "อีเมล", password: "รหัสผ่าน", signIn: "เข้าสู่ระบบ", create: "สร้างบัญชี", createAndSignIn: "สร้างบัญชีและเข้าสู่ระบบ", switchToSignIn: "มีบัญชีอยู่แล้ว? เข้าสู่ระบบ", switchToCreate: "ใช้งานครั้งแรก? สร้างบัญชี", accountExists: "อีเมลนี้มีบัญชีอยู่แล้ว โปรดเข้าสู่ระบบ", invalidCredentials: "อีเมลหรือรหัสผ่านไม่ถูกต้อง", passwordRule: "รหัสผ่านต้องมีความยาว 6 ถึง 128 อักขระ", hash: "แฮชธุรกรรม", hashHint: "หลังโอน USDT สำเร็จ ให้ใส่แฮชธุรกรรมที่เกี่ยวข้อง", submit: "ส่งเพื่อตรวจสอบ", manual: "ผู้ตรวจสอบจะยืนยันการโอนก่อนจึงเพิ่มเครดิต การสแกน QR เพียงอย่างเดียวจะไม่เพิ่มเครดิตโดยอัตโนมัติ", warning: "ส่งเฉพาะ USDT บนเครือข่ายที่เลือก การโอนจากเครือข่ายอื่นไม่สามารถเพิ่มเครดิตได้", recipient: "ที่อยู่ผู้รับ", copy: "คัดลอก", copied: "คัดลอกแล้ว", orEmail: "หรือเข้าสู่ระบบด้วยอีเมล", orWallet: "หรือเชื่อมต่อกระเป๋าเงิน", linkWallet: "เชื่อมต่อกระเป๋าเงินเพื่อชำระบนเชน", walletLinked: "เชื่อมกระเป๋าเงินกับบัญชีของคุณแล้ว", walletTaken: "กระเป๋าเงินนี้ถูกเชื่อมกับบัญชีอื่นแล้ว", manualTitle: "โอน USDT ด้วยตนเอง (เจ้าหน้าที่ตรวจสอบ)", manualHint: "ไม่มีกระเป๋าเงิน? โอน USDT ไปยังที่อยู่ด้านล่างแล้วส่งแฮชธุรกรรม เครดิตจะเพิ่มหลังตรวจสอบ" },
};

type FeedbackCopy = { registered: string; signedIn: string; walletSignedIn: string; walletCreated: string; signedOut: string; manualSubmitted: string; connectingWallet: string; linkingWallet: string; processing: string };
const ledgerCopy: Record<Locale, { title: string; empty: string; purchase: string; system: string; invite: string; spend: string; adjustment: string; other: string; balanceAfter: string }> = {
  en: { title: "Credit history", empty: "No credit activity yet.", purchase: "Purchase credits", system: "System grant", invite: "Invitation reward", spend: "Interpretation usage", adjustment: "Account adjustment", other: "Other credit activity", balanceAfter: "Balance after" },
  "zh-Hans": { title: "积分记录", empty: "暂无积分变动记录。", purchase: "购买到账", system: "系统赠送", invite: "邀请赠送", spend: "分析扣除", adjustment: "账户调整", other: "其他积分变动", balanceAfter: "变动后余额" },
  "zh-Hant": { title: "積分紀錄", empty: "暫無積分異動紀錄。", purchase: "購買入帳", system: "系統贈送", invite: "邀請贈送", spend: "分析扣除", adjustment: "帳戶調整", other: "其他積分異動", balanceAfter: "異動後餘額" },
  ja: { title: "クレジット履歴", empty: "クレジットの履歴はありません。", purchase: "購入クレジット", system: "システム付与", invite: "招待特典", spend: "分析で使用", adjustment: "アカウント調整", other: "その他の変動", balanceAfter: "変更後残高" },
  ko: { title: "크레딧 내역", empty: "아직 크레딧 내역이 없습니다.", purchase: "구매 적립", system: "시스템 지급", invite: "초대 보상", spend: "분석 차감", adjustment: "계정 조정", other: "기타 크레딧 변동", balanceAfter: "변동 후 잔액" },
  vi: { title: "Lịch sử điểm", empty: "Chưa có hoạt động điểm.", purchase: "Điểm mua", system: "Tặng từ hệ thống", invite: "Thưởng mời bạn", spend: "Trừ khi phân tích", adjustment: "Điều chỉnh tài khoản", other: "Hoạt động điểm khác", balanceAfter: "Số dư sau thay đổi" },
  th: { title: "ประวัติเครดิต", empty: "ยังไม่มีรายการเครดิต", purchase: "เครดิตจากการซื้อ", system: "เครดิตจากระบบ", invite: "รางวัลการเชิญ", spend: "หักจากการวิเคราะห์", adjustment: "ปรับยอดบัญชี", other: "รายการเครดิตอื่น ๆ", balanceAfter: "ยอดคงเหลือหลังรายการ" },
};

const loadMoreLabel: Record<Locale, string> = { en: "Show older records", "zh-Hans": "查看更早的记录", "zh-Hant": "查看更早的紀錄", ja: "以前の履歴を表示", ko: "이전 내역 보기", vi: "Xem bản ghi cũ hơn", th: "ดูรายการก่อนหน้า" };
/** The tool a reading was for, in the visitor's language (e.g. "BaZi", "Tarot"). */
function toolLabel(tool: string, locale: Locale) {
  if (tool.startsWith("toolkit-")) { const key = tool.slice(8) as ToolkitKey; try { return toolkitName(key, locale) || tool; } catch { return tool; } }
  try { return titleForRoute(tool as AppRoute, locale) || tool; } catch { return tool; }
}

const firstBonusLabel: Record<Locale, string> = { en: "First-purchase bonus", "zh-Hans": "首购赠送", "zh-Hant": "首購贈送", ja: "初回購入ボーナス", ko: "첫 구매 보너스", vi: "Thưởng mua lần đầu", th: "โบนัสซื้อครั้งแรก" };
let ledgerLocale: Locale = "en";
function ledgerReason(reason: string, labels: (typeof ledgerCopy)[Locale]) {
  if (reason === "first_purchase_bonus" || reason === "first_purchase_bonus_reversed") return firstBonusLabel[ledgerLocale];
  if (reason === "payment_approval") return labels.purchase;
  if (reason.startsWith("daily_login_bonus:")) return labels.system;
  if (reason === "invitation_purchase") return labels.invite;
  if (reason.startsWith("interpretation:")) return labels.spend;
  if (reason === "admin_adjustment") return labels.adjustment;
  return labels.other;
}

const feedbackCopy: Record<Locale, FeedbackCopy> = {
  en: { registered: "Account created. You are signed in.", signedIn: "Signed in successfully.", walletSignedIn: "Wallet signed in successfully.", walletCreated: "Wallet account created. You are signed in.", signedOut: "You have signed out.", manualSubmitted: "Transfer submitted. Credits will be issued after review.", connectingWallet: "Opening your wallet…", linkingWallet: "Confirm in your wallet to link it to this account…", processing: "Processing…" },
  "zh-Hans": { registered: "注册成功，已自动登录。", signedIn: "登录成功。", walletSignedIn: "钱包登录成功。", walletCreated: "钱包账户已创建并登录。", signedOut: "已退出登录。", manualSubmitted: "转账凭证已提交，审核通过后积分自动到账。", connectingWallet: "正在唤起钱包…", linkingWallet: "请在钱包中确认签名，以绑定到当前账户…", processing: "处理中…" },
  "zh-Hant": { registered: "註冊成功，已自動登入。", signedIn: "登入成功。", walletSignedIn: "錢包登入成功。", walletCreated: "錢包帳戶已建立並登入。", signedOut: "已登出。", manualSubmitted: "轉帳憑證已提交，審核通過後積分自動入帳。", connectingWallet: "正在喚起錢包…", linkingWallet: "請在錢包中確認簽名，以綁定到目前帳戶…", processing: "處理中…" },
  ja: { registered: "アカウントを作成し、サインインしました。", signedIn: "サインインしました。", walletSignedIn: "ウォレットでサインインしました。", walletCreated: "ウォレットアカウントを作成し、サインインしました。", signedOut: "サインアウトしました。", manualSubmitted: "送金情報を送信しました。審査後にクレジットが付与されます。", connectingWallet: "ウォレットを開いています…", linkingWallet: "ウォレットで署名を承認すると、このアカウントに紐付けられます…", processing: "処理中…" },
  ko: { registered: "계정이 생성되어 로그인되었습니다.", signedIn: "로그인되었습니다.", walletSignedIn: "지갑으로 로그인되었습니다.", walletCreated: "지갑 계정이 생성되어 로그인되었습니다.", signedOut: "로그아웃되었습니다.", manualSubmitted: "전송 정보가 제출되었습니다. 검토 후 크레딧이 지급됩니다.", connectingWallet: "지갑을 여는 중…", linkingWallet: "지갑에서 서명을 확인하면 이 계정에 연결됩니다…", processing: "처리 중…" },
  vi: { registered: "Đã tạo tài khoản và đăng nhập.", signedIn: "Đăng nhập thành công.", walletSignedIn: "Đăng nhập bằng ví thành công.", walletCreated: "Đã tạo tài khoản ví và đăng nhập.", signedOut: "Bạn đã đăng xuất.", manualSubmitted: "Đã gửi thông tin chuyển khoản. Điểm sẽ được cấp sau khi duyệt.", connectingWallet: "Đang mở ví…", linkingWallet: "Xác nhận chữ ký trong ví để liên kết với tài khoản này…", processing: "Đang xử lý…" },
  th: { registered: "สร้างบัญชีและเข้าสู่ระบบแล้ว", signedIn: "เข้าสู่ระบบสำเร็จ", walletSignedIn: "เข้าสู่ระบบด้วยกระเป๋าเงินสำเร็จ", walletCreated: "สร้างบัญชีกระเป๋าเงินและเข้าสู่ระบบแล้ว", signedOut: "ออกจากระบบแล้ว", manualSubmitted: "ส่งข้อมูลการโอนแล้ว เครดิตจะเพิ่มหลังตรวจสอบ", connectingWallet: "กำลังเปิดกระเป๋าเงิน…", linkingWallet: "ยืนยันลายเซ็นในกระเป๋าเงินเพื่อเชื่อมกับบัญชีนี้…", processing: "กำลังดำเนินการ…" },
};

type LayoutCopy = { buy: string; choosePayment: string; qrPay: string; qrPayLead: string; walletPay: string; walletPayLead: string; bindWallet: string; bindWalletLead: string; statusReview: string; statusDone: string; statusRejected: string; methodQr: string; methodOnchain: string; records: string; recordsLead: string; close: string; back: string; buyCredits: string; buyCreditsLead: string; inviteList: string; inviteListEmpty: string; inviteCount: string; contact: string; contactLead: string; joinedAt: string; assets: string; store: string; storeLead: string; backToCenter: string; center: string; centerLead: string; walletTab: string; emailTab: string; walletPayTab: string; manualPayTab: string; profile: string; method: string; methodEmail: string; methodWallet: string; linkedWallet: string; noWallet: string; copyAddress: string; recentOrders: string; recommended: string; step1: string; step2: string; summary: string; packageLabel: string; welcome: string; welcomeLead: string };
const layoutCopy: Record<Locale, LayoutCopy> = {
  en: { buy: "Buy", choosePayment: "Choose a payment method", qrPay: "Scan to pay", qrPayLead: "Transfer USDT to our address, then submit the transaction hash. Credited after review.", walletPay: "Pay with wallet", walletPayLead: "Approve in your wallet; credits arrive automatically once the chain confirms.", bindWallet: "Link a wallet", bindWalletLead: "Link a wallet to this account to pay on-chain.", statusReview: "Under review", statusDone: "Completed", statusRejected: "Rejected", methodQr: "QR transfer", methodOnchain: "Wallet", records: "Purchase records", recordsLead: "Wallet purchases appear here automatically once detected on chain.", close: "Close", back: "Back", buyCredits: "Buy credits", buyCreditsLead: "Choose a package and pay in USDT — on-chain or by manual transfer.", inviteList: "Invited members", inviteListEmpty: "Nobody has joined with your code yet.", inviteCount: "members joined", contact: "Contact us", contactLead: "Reach the team on any of these channels.", joinedAt: "Joined", assets: "Assets", store: "Credit store", storeLead: "Choose a package and pay on BNB Chain, Ethereum, Solana or TRON. Credits arrive once the payment is confirmed.", backToCenter: "Back to my account", center: "My account", centerLead: "Your balance, purchases and invitation rewards in one place.", walletTab: "Wallet", emailTab: "Email", walletPayTab: "Pay with wallet", manualPayTab: "Manual transfer", profile: "Account", method: "Signed in with", methodEmail: "Email", methodWallet: "Wallet", linkedWallet: "Linked wallet", noWallet: "No wallet linked", copyAddress: "Copy", recentOrders: "Recent purchases", recommended: "Popular", step1: "1 · Choose a package", step2: "2 · Pay", summary: "Order summary", packageLabel: "Package", welcome: "Sign in to Xuannova Institute", welcomeLead: "Connect a wallet or use your email. Credits stay on one account either way." },
  "zh-Hans": { buy: "购买", choosePayment: "选择支付方式", qrPay: "扫码支付", qrPayLead: "向收款地址转 USDT 后提交交易哈希，后台审核通过后到账。", walletPay: "钱包支付", walletPayLead: "在钱包中确认，链上确认后自动到账。", bindWallet: "绑定钱包", bindWalletLead: "绑定钱包后即可链上支付。", statusReview: "后台审核", statusDone: "已完成", statusRejected: "已拒绝", methodQr: "扫码支付", methodOnchain: "钱包支付", records: "购买记录", recordsLead: "钱包支付在链上确认后会自动出现在这里。", close: "关闭", back: "返回", buyCredits: "购买积分", buyCreditsLead: "选择套餐后用 USDT 支付，支持钱包链上支付或手动转账。", inviteList: "邀请列表", inviteListEmpty: "还没有人通过你的邀请码加入。", inviteCount: "人已加入", contact: "官方联系方式", contactLead: "有任何问题可通过以下渠道联系我们。", joinedAt: "加入时间", assets: "资产", store: "购买积分", storeLead: "选择套餐，可用 BNB Chain、以太坊、Solana、TRON 四个网络付款，确认到账后发放积分。", backToCenter: "返回个人中心", center: "个人中心", centerLead: "积分余额、购买记录与邀请奖励，尽在此处。", walletTab: "钱包登录", emailTab: "邮箱登录", walletPayTab: "钱包支付", manualPayTab: "手动转账", profile: "账户", method: "登录方式", methodEmail: "邮箱", methodWallet: "钱包", linkedWallet: "已绑定钱包", noWallet: "未绑定钱包", copyAddress: "复制", recentOrders: "最近购买", recommended: "热门", step1: "1 · 选择套餐", step2: "2 · 支付", summary: "订单摘要", packageLabel: "套餐", welcome: "登录Xuannova", welcomeLead: "连接钱包或使用邮箱登录，两种方式共用同一个账户与积分。" },
  "zh-Hant": { buy: "購買", choosePayment: "選擇付款方式", qrPay: "掃碼付款", qrPayLead: "向收款地址轉 USDT 後提交交易雜湊，後台審核通過後入帳。", walletPay: "錢包付款", walletPayLead: "在錢包中確認，鏈上確認後自動入帳。", bindWallet: "綁定錢包", bindWalletLead: "綁定錢包後即可鏈上付款。", statusReview: "後台審核", statusDone: "已完成", statusRejected: "已拒絕", methodQr: "掃碼付款", methodOnchain: "錢包付款", records: "購買紀錄", recordsLead: "錢包付款在鏈上確認後會自動出現在這裡。", close: "關閉", back: "返回", buyCredits: "購買積分", buyCreditsLead: "選擇方案後以 USDT 付款，支援錢包鏈上付款或手動轉帳。", inviteList: "邀請列表", inviteListEmpty: "還沒有人透過你的邀請碼加入。", inviteCount: "人已加入", contact: "官方聯絡方式", contactLead: "有任何問題可透過以下管道聯絡我們。", joinedAt: "加入時間", assets: "資產", store: "購買積分", storeLead: "選擇套餐，可用 BNB Chain、以太坊、Solana、TRON 四個網路付款，確認到帳後發放積分。", backToCenter: "返回個人中心", center: "個人中心", centerLead: "積分餘額、購買紀錄與邀請獎勵，盡在此處。", walletTab: "錢包登入", emailTab: "信箱登入", walletPayTab: "錢包付款", manualPayTab: "手動轉帳", profile: "帳戶", method: "登入方式", methodEmail: "信箱", methodWallet: "錢包", linkedWallet: "已綁定錢包", noWallet: "未綁定錢包", copyAddress: "複製", recentOrders: "最近購買", recommended: "熱門", step1: "1 · 選擇方案", step2: "2 · 付款", summary: "訂單摘要", packageLabel: "方案", welcome: "登入Xuannova", welcomeLead: "連接錢包或使用信箱登入，兩種方式共用同一個帳戶與積分。" },
  ja: { buy: "購入", choosePayment: "支払い方法を選択", qrPay: "QR で支払う", qrPayLead: "受取アドレスに USDT を送金し、トランザクションハッシュを送信。審査後に付与されます。", walletPay: "ウォレットで支払う", walletPayLead: "ウォレットで承認すると、チェーン確定後に自動付与されます。", bindWallet: "ウォレットを連携", bindWalletLead: "このアカウントにウォレットを連携するとオンチェーンで支払えます。", statusReview: "審査中", statusDone: "完了", statusRejected: "却下", methodQr: "QR 送金", methodOnchain: "ウォレット", records: "購入履歴", recordsLead: "ウォレット購入はチェーンで検出され次第ここに表示されます。", close: "閉じる", back: "戻る", buyCredits: "クレジットを購入", buyCreditsLead: "パッケージを選び USDT で支払います。ウォレットまたは手動送金に対応。", inviteList: "招待したメンバー", inviteListEmpty: "まだあなたのコードで参加した人はいません。", inviteCount: "人が参加", contact: "公式連絡先", contactLead: "ご質問は以下のチャンネルからどうぞ。", joinedAt: "参加日", assets: "資産", store: "クレジットストア", storeLead: "パッケージを選び、BNB Chain・Ethereum・Solana・TRON で支払えます。確認後にクレジットが付与されます。", backToCenter: "マイページへ戻る", center: "マイページ", centerLead: "残高・購入履歴・招待特典をここで確認できます。", walletTab: "ウォレット", emailTab: "メール", walletPayTab: "ウォレットで支払う", manualPayTab: "手動送金", profile: "アカウント", method: "サインイン方法", methodEmail: "メール", methodWallet: "ウォレット", linkedWallet: "連携済みウォレット", noWallet: "ウォレット未連携", copyAddress: "コピー", recentOrders: "最近の購入", recommended: "人気", step1: "1 · パッケージを選ぶ", step2: "2 · 支払う", summary: "注文内容", packageLabel: "パッケージ", welcome: "Xuannovaにサインイン", welcomeLead: "ウォレット接続またはメールでサインイン。どちらも同じアカウントとクレジットを共有します。" },
  ko: { buy: "구매", choosePayment: "결제 방식 선택", qrPay: "QR로 결제", qrPayLead: "수취 주소로 USDT를 보낸 뒤 거래 해시를 제출하세요. 검토 후 지급됩니다.", walletPay: "지갑으로 결제", walletPayLead: "지갑에서 승인하면 체인 확정 후 자동 지급됩니다.", bindWallet: "지갑 연결", bindWalletLead: "이 계정에 지갑을 연결하면 온체인 결제가 가능합니다.", statusReview: "검토 중", statusDone: "완료", statusRejected: "거절됨", methodQr: "QR 전송", methodOnchain: "지갑", records: "구매 내역", recordsLead: "지갑 결제는 체인에서 감지되면 자동으로 여기에 표시됩니다.", close: "닫기", back: "뒤로", buyCredits: "크레딧 구매", buyCreditsLead: "패키지를 선택하고 USDT로 결제하세요. 지갑 결제 또는 수동 전송 지원.", inviteList: "초대한 회원", inviteListEmpty: "아직 내 코드로 가입한 사람이 없습니다.", inviteCount: "명 가입", contact: "공식 연락처", contactLead: "문의는 아래 채널로 연락해 주세요.", joinedAt: "가입일", assets: "자산", store: "크레딧 스토어", storeLead: "패키지를 고르고 BNB Chain, 이더리움, 솔라나, TRON으로 결제하세요. 확인 후 크레딧이 지급됩니다.", backToCenter: "마이페이지로 돌아가기", center: "마이페이지", centerLead: "잔액, 구매 내역, 초대 보상을 한곳에서 확인하세요.", walletTab: "지갑", emailTab: "이메일", walletPayTab: "지갑 결제", manualPayTab: "수동 전송", profile: "계정", method: "로그인 방식", methodEmail: "이메일", methodWallet: "지갑", linkedWallet: "연결된 지갑", noWallet: "연결된 지갑 없음", copyAddress: "복사", recentOrders: "최근 구매", recommended: "인기", step1: "1 · 패키지 선택", step2: "2 · 결제", summary: "주문 요약", packageLabel: "패키지", welcome: "Xuannova에 로그인", welcomeLead: "지갑을 연결하거나 이메일로 로그인하세요. 두 방식 모두 같은 계정과 크레딧을 공유합니다." },
  vi: { buy: "Mua", choosePayment: "Chọn phương thức thanh toán", qrPay: "Quét mã để thanh toán", qrPayLead: "Chuyển USDT đến địa chỉ nhận rồi gửi mã băm giao dịch. Cấp sau khi duyệt.", walletPay: "Thanh toán bằng ví", walletPayLead: "Xác nhận trong ví; điểm tự động cấp khi chuỗi xác nhận.", bindWallet: "Liên kết ví", bindWalletLead: "Liên kết ví với tài khoản này để thanh toán trên chuỗi.", statusReview: "Đang duyệt", statusDone: "Hoàn thành", statusRejected: "Đã từ chối", methodQr: "Chuyển khoản QR", methodOnchain: "Ví", records: "Lịch sử mua", recordsLead: "Giao dịch bằng ví sẽ tự động hiển thị ở đây khi được phát hiện trên chuỗi.", close: "Đóng", back: "Quay lại", buyCredits: "Mua điểm", buyCreditsLead: "Chọn gói và thanh toán bằng USDT — qua ví hoặc chuyển khoản thủ công.", inviteList: "Thành viên đã mời", inviteListEmpty: "Chưa có ai tham gia bằng mã của bạn.", inviteCount: "người đã tham gia", contact: "Liên hệ chính thức", contactLead: "Liên hệ với chúng tôi qua các kênh sau.", joinedAt: "Tham gia", assets: "Tài sản", store: "Cửa hàng điểm", storeLead: "Chọn gói và thanh toán trên BNB Chain, Ethereum, Solana hoặc TRON. Điểm được cộng khi xác nhận thanh toán.", backToCenter: "Về tài khoản của tôi", center: "Tài khoản của tôi", centerLead: "Số dư, giao dịch và thưởng mời ở cùng một nơi.", walletTab: "Ví", emailTab: "Email", walletPayTab: "Thanh toán bằng ví", manualPayTab: "Chuyển khoản thủ công", profile: "Tài khoản", method: "Đăng nhập bằng", methodEmail: "Email", methodWallet: "Ví", linkedWallet: "Ví đã liên kết", noWallet: "Chưa liên kết ví", copyAddress: "Sao chép", recentOrders: "Giao dịch gần đây", recommended: "Phổ biến", step1: "1 · Chọn gói", step2: "2 · Thanh toán", summary: "Tóm tắt đơn hàng", packageLabel: "Gói", welcome: "Đăng nhập Xuannova", welcomeLead: "Kết nối ví hoặc dùng email. Cả hai cách đều dùng chung một tài khoản và điểm." },
  th: { buy: "ซื้อ", choosePayment: "เลือกวิธีชำระเงิน", qrPay: "สแกนเพื่อชำระ", qrPayLead: "โอน USDT ไปยังที่อยู่รับเงินแล้วส่งแฮชธุรกรรม เพิ่มเครดิตหลังตรวจสอบ", walletPay: "ชำระด้วยกระเป๋าเงิน", walletPayLead: "ยืนยันในกระเป๋าเงิน เครดิตเพิ่มอัตโนมัติเมื่อเชนยืนยัน", bindWallet: "เชื่อมกระเป๋าเงิน", bindWalletLead: "เชื่อมกระเป๋าเงินกับบัญชีนี้เพื่อชำระบนเชน", statusReview: "รอตรวจสอบ", statusDone: "เสร็จสิ้น", statusRejected: "ปฏิเสธ", methodQr: "โอนผ่าน QR", methodOnchain: "กระเป๋าเงิน", records: "ประวัติการซื้อ", recordsLead: "การซื้อผ่านกระเป๋าเงินจะแสดงที่นี่อัตโนมัติเมื่อตรวจพบบนเชน", close: "ปิด", back: "ย้อนกลับ", buyCredits: "ซื้อเครดิต", buyCreditsLead: "เลือกแพ็กเกจแล้วชำระด้วย USDT — ผ่านกระเป๋าเงินหรือโอนด้วยตนเอง", inviteList: "สมาชิกที่เชิญ", inviteListEmpty: "ยังไม่มีใครเข้าร่วมด้วยรหัสของคุณ", inviteCount: "คนเข้าร่วม", contact: "ช่องทางติดต่อทางการ", contactLead: "ติดต่อเราได้ผ่านช่องทางต่อไปนี้", joinedAt: "เข้าร่วมเมื่อ", assets: "สินทรัพย์", store: "ร้านเครดิต", storeLead: "เลือกแพ็กเกจและชำระบน BNB Chain, Ethereum, Solana หรือ TRON เครดิตเข้าเมื่อยืนยันการชำระ", backToCenter: "กลับไปบัญชีของฉัน", center: "บัญชีของฉัน", centerLead: "ยอดเครดิต รายการซื้อ และรางวัลเชิญ อยู่ที่นี่ทั้งหมด", walletTab: "กระเป๋าเงิน", emailTab: "อีเมล", walletPayTab: "ชำระด้วยกระเป๋าเงิน", manualPayTab: "โอนด้วยตนเอง", profile: "บัญชี", method: "เข้าสู่ระบบด้วย", methodEmail: "อีเมล", methodWallet: "กระเป๋าเงิน", linkedWallet: "กระเป๋าเงินที่เชื่อม", noWallet: "ยังไม่เชื่อมกระเป๋าเงิน", copyAddress: "คัดลอก", recentOrders: "การซื้อล่าสุด", recommended: "ยอดนิยม", step1: "1 · เลือกแพ็กเกจ", step2: "2 · ชำระเงิน", summary: "สรุปคำสั่งซื้อ", packageLabel: "แพ็กเกจ", welcome: "เข้าสู่ระบบ Xuannova", welcomeLead: "เชื่อมต่อกระเป๋าเงินหรือใช้อีเมล ทั้งสองวิธีใช้บัญชีและเครดิตเดียวกัน" },
};

async function request<T>(path: string, init?: RequestInit): Promise<T & { code?: string }> {
  const response = await fetch(path, { credentials: "same-origin", headers: { "content-type": "application/json", ...(init?.headers ?? {}) }, ...init });
  const payload = await response.json() as T & { error?: string; code?: string };
  // 202 carries an error body ("still confirming"): treat it as a failure with status 202.
  if (!response.ok || response.status === 202 || (payload && typeof payload === "object" && "error" in payload && payload.error)) {
    const failure = new Error(payload.error ?? "Request failed") as Error & { code?: string; status?: number };
    failure.code = payload.code;
    failure.status = response.status;
    throw failure;
  }
  return payload;
}

type TeamStats = { invited: number; purchasers: number; totalUsd: string; totalCredits?: number; sources?: Array<{ source: string; invited: number }> };
const guideLead: Record<Locale, string> = { en: "How to start, which method to pick, and how to read your chart.", "zh-Hans": "怎么开始、选哪个方法、怎么看懂命盘。", "zh-Hant": "怎麼開始、選哪個方法、怎麼看懂命盤。", ja: "始め方、方法の選び方、命盤の読み方。", ko: "시작하는 법, 방법 고르기, 명반 읽는 법.", vi: "Cách bắt đầu, chọn phương pháp và đọc lá số.", th: "เริ่มอย่างไร เลือกวิธีไหน และอ่านผังอย่างไร" };
const teamCopy: Record<Locale, { title: string; invited: string; purchasers: string; total: string; credits: string; note: string }> = {
  en: { title: "My team", invited: "Joined with my code", purchasers: "Have purchased", total: "Team study spending (USD)", credits: "Team study credits", note: "Counts the credits and amounts bought through approved USDT orders and paid card orders by members who joined with your code." },
  "zh-Hans": { title: "我的团队", invited: "邀请人数", purchasers: "已购买人数", total: "团队研习投入（USD）", credits: "团队研习总积分", note: "按通过你的邀请码加入的会员统计：已审核通过的 USDT 订单和已支付的银行卡订单所购买的积分与金额（不含每日赠送、空投和活动赠送）。" },
  "zh-Hant": { title: "我的團隊", invited: "邀請人數", purchasers: "已購買人數", total: "團隊研習投入（USD）", credits: "團隊研習總積分", note: "按透過你的邀請碼加入的會員統計：已核准的 USDT 訂單和已付款的信用卡訂單所購買的積分與金額（不含每日贈送、空投和活動贈送）。" },
  ja: { title: "マイチーム", invited: "招待した人数", purchasers: "購入した人数", total: "チームの学習利用額（USD）", credits: "チームの学習クレジット合計", note: "あなたのコードで参加した会員の、承認済み USDT 注文と支払済みカード注文で購入したクレジットと金額を集計しています（毎日の付与・エアドロップ・特典は含みません）。" },
  ko: { title: "내 팀", invited: "초대 인원", purchasers: "구매 인원", total: "팀 학습 이용액(USD)", credits: "팀 학습 크레딧 합계", note: "내 코드로 가입한 회원의 승인된 USDT 주문과 결제된 카드 주문으로 구매한 크레딧과 금액을 합산합니다(매일 지급·에어드롭·이벤트 지급 제외)." },
  vi: { title: "Đội của tôi", invited: "Đã tham gia bằng mã của tôi", purchasers: "Đã mua", total: "Chi tiêu học tập của đội (USD)", credits: "Tổng điểm học của đội", note: "Tính điểm và số tiền từ các đơn USDT đã duyệt và đơn thẻ đã thanh toán của thành viên tham gia bằng mã của bạn (không gồm điểm tặng hằng ngày, airdrop và khuyến mãi)." },
  th: { title: "ทีมของฉัน", invited: "เข้าร่วมด้วยรหัสของฉัน", purchasers: "ซื้อแล้ว", total: "ยอดใช้จ่ายด้านการศึกษาของทีม (USD)", credits: "เครดิตการศึกษารวมของทีม", note: "นับเครดิตและยอดเงินจากคำสั่งซื้อ USDT ที่อนุมัติและคำสั่งซื้อบัตรที่ชำระแล้วของสมาชิกที่เข้าร่วมด้วยรหัสของคุณ (ไม่รวมเครดิตรายวัน แอร์ดรอป และโปรโมชัน)" },
};

const growthCopy: Record<Locale, { offer: string; reminder: string; reminderLead: string; reminderNoMail: string; reminderNeedsEmail: string; saved: string }> = {
  en: { offer: "First purchase: get {n} extra credits with any package.", reminder: "Email me a daily reminder", reminderLead: "One short email a day (from 8 am your time) when your 5 daily credits are ready, with a link to today's almanac. Unsubscribe any time.", reminderNoMail: "Reminder emails are not switched on for this site yet.", reminderNeedsEmail: "Sign in with an email address to receive reminders.", saved: "Saved." },
  "zh-Hans": { offer: "首次购买任意套餐，额外赠送 {n} 积分。", reminder: "每天邮件提醒我", reminderLead: "每天一封简短邮件（当地时间早上 8 点后），提醒领取 5 个每日积分，并附今日黄历链接。可随时退订。", reminderNoMail: "本站暂未开通邮件提醒。", reminderNeedsEmail: "使用邮箱登录后才能接收提醒。", saved: "已保存。" },
  "zh-Hant": { offer: "首次購買任意方案，額外贈送 {n} 積分。", reminder: "每天郵件提醒我", reminderLead: "每天一封簡短郵件（當地時間早上 8 點後），提醒領取 5 個每日積分，並附今日黃曆連結。可隨時退訂。", reminderNoMail: "本站暫未開通郵件提醒。", reminderNeedsEmail: "使用信箱登入後才能接收提醒。", saved: "已儲存。" },
  ja: { offer: "初回購入なら、どのパッケージでも {n} クレジットを追加でプレゼント。", reminder: "毎日メールで知らせる", reminderLead: "毎日のクレジット5が受け取れることを、1日1通（現地時間の朝8時以降）お知らせします。今日の暦へのリンク付き。いつでも停止できます。", reminderNoMail: "このサイトではまだメール通知が有効になっていません。", reminderNeedsEmail: "通知を受け取るにはメールアドレスでログインしてください。", saved: "保存しました。" },
  ko: { offer: "첫 구매 시 어떤 패키지든 {n} 크레딧을 추가로 드립니다.", reminder: "매일 이메일 알림 받기", reminderLead: "매일 5크레딧을 받을 수 있을 때 하루 한 통(현지 시간 오전 8시 이후) 짧은 메일과 오늘의 역 링크를 보내 드립니다. 언제든 해지할 수 있습니다.", reminderNoMail: "이 사이트는 아직 이메일 알림을 켜지 않았습니다.", reminderNeedsEmail: "알림을 받으려면 이메일로 로그인하세요.", saved: "저장했습니다." },
  vi: { offer: "Mua lần đầu bất kỳ gói nào: tặng thêm {n} điểm.", reminder: "Gửi email nhắc tôi mỗi ngày", reminderLead: "Mỗi ngày một email ngắn (sau 8 giờ sáng giờ địa phương) khi 5 điểm hằng ngày đã sẵn sàng, kèm liên kết lịch hôm nay. Có thể hủy bất cứ lúc nào.", reminderNoMail: "Trang này chưa bật email nhắc nhở.", reminderNeedsEmail: "Hãy đăng nhập bằng email để nhận nhắc nhở.", saved: "Đã lưu." },
  th: { offer: "ซื้อครั้งแรกแพ็กเกจใดก็ได้ รับเครดิตเพิ่ม {n}", reminder: "ส่งอีเมลเตือนทุกวัน", reminderLead: "อีเมลสั้น ๆ วันละฉบับ (หลัง 8 โมงเช้าเวลาท้องถิ่น) เมื่อ 5 เครดิตประจำวันพร้อมรับ พร้อมลิงก์ปฏิทินวันนี้ ยกเลิกได้ทุกเมื่อ", reminderNoMail: "เว็บไซต์ยังไม่ได้เปิดการแจ้งเตือนทางอีเมล", reminderNeedsEmail: "เข้าสู่ระบบด้วยอีเมลเพื่อรับการแจ้งเตือน", saved: "บันทึกแล้ว" },
};

const roomInviteText: Record<Locale, string> = { en: "You have been invited to a quiet room. Sign in or create an account to join.", "zh-Hans": "你收到了静室邀请，登录或注册后即可加入。", "zh-Hant": "你收到了靜室邀請，登入或註冊後即可加入。", ja: "静室に招待されています。ログインまたは登録すると参加できます。", ko: "정실 초대를 받았습니다. 로그인하거나 가입하면 참여할 수 있어요.", vi: "Bạn được mời vào tịnh thất. Đăng nhập hoặc đăng ký để tham gia.", th: "คุณได้รับเชิญเข้าห้องสงบ เข้าสู่ระบบหรือสมัครเพื่อเข้าร่วม" };
type CenterTab = "overview" | "reports" | "profiles" | "rooms" | "shelf" | "credits" | "invite" | "settings";
const centerTabMarks: Record<CenterTab, string> = { overview: "◎", reports: "卷", profiles: "命", rooms: "室", shelf: "藏", credits: "积", invite: "缘", settings: "设" };
type CenterTabCopy = { names: Record<CenterTab, string>; leads: Partial<Record<CenterTab, string>>; statInvited: string; statTeam: string; statSpent: string };
const centerTabs: Record<Locale, CenterTabCopy> = {
  en: { names: { overview: "Overview", reports: "Reports", profiles: "Profiles", rooms: "Quiet room", shelf: "Bookshelf", credits: "Credits", invite: "Invitations", settings: "Settings" }, leads: { reports: "Every unlocked report, notes and follow-ups", profiles: "Saved birth details for you and family", shelf: "Favourite classics and where you stopped", invite: "Your code, link and team" }, statInvited: "Invited", statTeam: "Team study credits", statSpent: "Credits used" },
  "zh-Hans": { names: { overview: "概览", reports: "我的报告", profiles: "我的档案", rooms: "我的静室", shelf: "我的书架", credits: "积分记录", invite: "邀请奖励", settings: "提醒与隐私" }, leads: { reports: "解锁过的报告、笔记与追问", profiles: "本人与家人的出生资料", shelf: "收藏的典籍与阅读进度", invite: "邀请码、链接与我的团队" }, statInvited: "已邀请", statTeam: "团队研习总积分", statSpent: "已使用积分" },
  "zh-Hant": { names: { overview: "概覽", reports: "我的報告", profiles: "我的檔案", rooms: "我的靜室", shelf: "我的書架", credits: "積分紀錄", invite: "邀請獎勵", settings: "提醒與隱私" }, leads: { reports: "解鎖過的報告、筆記與追問", profiles: "本人與家人的出生資料", shelf: "收藏的典籍與閱讀進度", invite: "邀請碼、連結與我的團隊" }, statInvited: "已邀請", statTeam: "團隊研習總積分", statSpent: "已使用積分" },
  ja: { names: { overview: "概要", reports: "レポート", profiles: "プロフィール", rooms: "静室", shelf: "本棚", credits: "クレジット履歴", invite: "招待特典", settings: "通知とプライバシー" }, leads: { reports: "解錠したレポート、メモ、追加質問", profiles: "本人と家族の出生情報", shelf: "お気に入りの古典と読書位置", invite: "招待コード、リンク、チーム" }, statInvited: "招待した人", statTeam: "チームの学習クレジット", statSpent: "使用したクレジット" },
  ko: { names: { overview: "개요", reports: "내 리포트", profiles: "내 프로필", rooms: "나의 정실", shelf: "내 서재", credits: "크레딧 내역", invite: "초대 보상", settings: "알림과 개인정보" }, leads: { reports: "잠금 해제한 리포트, 메모, 추가 질문", profiles: "본인과 가족의 출생 정보", shelf: "즐겨찾는 고전과 읽은 위치", invite: "초대 코드, 링크, 내 팀" }, statInvited: "초대한 사람", statTeam: "팀 학습 크레딧", statSpent: "사용한 크레딧" },
  vi: { names: { overview: "Tổng quan", reports: "Báo cáo", profiles: "Hồ sơ", rooms: "Tịnh thất", shelf: "Tủ sách", credits: "Lịch sử điểm", invite: "Mời bạn", settings: "Nhắc nhở & riêng tư" }, leads: { reports: "Báo cáo đã mở khóa, ghi chú và hỏi tiếp", profiles: "Thông tin sinh của bạn và gia đình", shelf: "Kinh điển yêu thích và vị trí đang đọc", invite: "Mã mời, liên kết và nhóm của bạn" }, statInvited: "Đã mời", statTeam: "Điểm học của nhóm", statSpent: "Điểm đã dùng" },
  th: { names: { overview: "ภาพรวม", reports: "รายงานของฉัน", profiles: "โปรไฟล์", rooms: "ห้องสงบ", shelf: "ชั้นหนังสือ", credits: "ประวัติเครดิต", invite: "รางวัลเชิญเพื่อน", settings: "การแจ้งเตือนและความเป็นส่วนตัว" }, leads: { reports: "รายงานที่ปลดล็อก บันทึก และคำถามต่อ", profiles: "ข้อมูลวันเกิดของคุณและครอบครัว", shelf: "ตำราที่ชอบและตำแหน่งที่อ่านค้าง", invite: "รหัสเชิญ ลิงก์ และทีมของคุณ" }, statInvited: "เชิญแล้ว", statTeam: "เครดิตศึกษาของทีม", statSpent: "เครดิตที่ใช้" },
};

function ReminderToggle({ locale }: { locale: Locale }) {
  const text = growthCopy[locale];
  const [state, setState] = useState<{ enabled: boolean; hasEmail: boolean; mailConfigured: boolean } | null>(null);
  const [note, setNote] = useState("");
  useEffect(() => { void fetch("/api/member/reminders", { credentials: "same-origin" }).then((response) => (response.ok ? response.json() : null)).then((value) => setState(value)).catch(() => setState(null)); }, []);
  if (!state) return null;
  const disabled = !state.mailConfigured || !state.hasEmail;
  return <section className="mc-reminder">
    <label><input type="checkbox" checked={state.enabled} disabled={disabled && !state.enabled} onChange={(event) => {
      const enabled = event.target.checked;
      void fetch("/api/member/reminders", { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify({ enabled, timezone: Intl.DateTimeFormat().resolvedOptions().timeZone, locale }) })
        .then((response) => { if (response.ok) { setState({ ...state, enabled }); setNote(text.saved); window.setTimeout(() => setNote(""), 2000); } });
    }} /> <b>{text.reminder}</b></label>
    <p>{!state.mailConfigured ? text.reminderNoMail : !state.hasEmail ? text.reminderNeedsEmail : text.reminderLead}</p>
    {note && <small role="status">{note}</small>}
  </section>;
}

/** Account from the previous visit in this tab (undefined = not loaded yet). Cleared on sign-out via setMember(null). */
let lastKnownMember: Member | null | undefined;

export function MemberCommerceCenter({ locale, mode = "store", onBuyCredits, active = true }: { locale: Locale; mode?: "center" | "store"; onBuyCredits?: () => void; active?: boolean }) {
  const text = useMemo(() => ({ ...copy[locale], ...dualCopy[locale], ...feedbackCopy[locale], ...layoutCopy[locale] }), [locale]);
  ledgerLocale = locale;
  // Start from the account seen last time (the component remounts on every visit to 我的), so the sign-in screen
  // never flashes for a member while the account is being reloaded.
  const [member, setMember] = useState<Member | null>(() => lastKnownMember ?? null);
  const [accountLoaded, setAccountLoaded] = useState(lastKnownMember !== undefined);
  useEffect(() => { if (accountLoaded) lastKnownMember = member; }, [member, accountLoaded]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [invitations, setInvitations] = useState<Invitation[]>([]);
  const [team, setTeam] = useState<TeamStats | null>(null);
  const [ledger, setLedger] = useState<LedgerEntry[]>([]);
  const [ledgerNext, setLedgerNext] = useState<string | null>(null);
  const [wallets, setWallets] = useState<WalletOption[]>([]);
  const [session, setSession] = useState<{ provider: EIP1193Provider; address: Address; walletId: WalletProviderId } | null>(null);
  const [config, setConfig] = useState<CheckoutConfig | null>(null);
  const [inviteCode, setInviteCode] = useState("");
  const [centerTab, setCenterTab] = useState<CenterTab>("overview");
  // Other pages (e.g. the beginner's guide) can open a tab: the account page stays mounted, so ?tab= is not read again.
  useEffect(() => {
    const open = (event: Event) => { const tab = (event as CustomEvent<string>).detail; if (tab in centerTabMarks) setCenterTab(tab as CenterTab); };
    window.addEventListener("xn:member-tab", open);
    return () => window.removeEventListener("xn:member-tab", open);
  }, []);
  const [profileAdd, setProfileAdd] = useState(false);
  const [roomInvite, setRoomInvite] = useState(false);
  useEffect(() => { setRoomInvite(/^[0-9a-f]{24}$/.test(new URLSearchParams(window.location.search).get("room") ?? "")); }, []);
  useEffect(() => {
    const timer = window.setTimeout(() => {
      const fromUrl = new URLSearchParams(window.location.search).get("tab");
      if (fromUrl && fromUrl in centerTabMarks) setCenterTab(fromUrl as CenterTab);
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);
  useEffect(() => {
    // Read after mount so server and client render the same initial markup.
    const timer = window.setTimeout(() => {
      const fromLink = new URLSearchParams(window.location.search).get("invite")?.trim().toUpperCase() ?? "";
      if (fromLink) setInviteCode(fromLink);
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isRegister, setIsRegister] = useState(false);
  const [authTab, setAuthTab] = useState<"wallet" | "email">("email");
  const [directBusy, setDirectBusy] = useState(false);
  const [checkout, setCheckout] = useState<{ packageId: string; step: "choose" | "qr" | "wallet" | "direct" } | null>(null);
  const [networkId, setNetworkId] = useState<PaymentNetworkId>(paymentNetworks[0].id);
  const [payChain, setPayChain] = useState<PayChainId>("bsc");
  const [transactionHash, setTransactionHash] = useState("");
  const [selectedPackageId, setSelectedPackageId] = useState<string>(creditPackages[0].id);
  const [noticeState, setNoticeState] = useState<{ text: string; kind: "success" | "error" | "info" } | null>(null);
  const notice = noticeState?.text ?? "";
  /** Show a message. Errors stay until the next action; success / info fade out. */
  const setNotice = useCallback((text: string, kind: "success" | "error" | "info" = "error") => {
    setNoticeState(text ? { text, kind } : null);
  }, []);
  useEffect(() => {
    if (!noticeState || noticeState.kind === "error") return;
    const timer = window.setTimeout(() => setNoticeState(null), noticeState.kind === "info" ? 30_000 : 6_000);
    return () => window.clearTimeout(timer);
  }, [noticeState]);
  const [busy, setBusy] = useState<"" | WalletProviderId | "pay" | "card" | "refresh" | "signout" | "email" | "manual">("");
  const [stage, setStage] = useState<PaymentStage | null>(null);
  const [lastHash, setLastHash] = useState<Hex | null>(null);
  const [pendingHash, setPendingHash] = useState<Hex | null>(null);
  const [pendingCheckout, setPendingCheckout] = useState<"legacy" | "usdc">("legacy");
  const [pendingPackageId, setPendingPackageId] = useState<string | null>(null);
  const [paymentAsset, setPaymentAsset] = useState<"legacy" | UsdcPaymentToken>("legacy");
  const [quoting, setQuoting] = useState(false);
  const quoteRef = useRef<() => void>(() => undefined);
  const [usdcQuote, setUsdcQuote] = useState<UsdcQuote | null>(null);
  useEffect(() => {
    const timer = window.setTimeout(() => {
      setPendingHash(null); setPendingPackageId(null); setPendingCheckout("legacy");
      if (!member?.id) return;
      try {
        const raw = window.localStorage.getItem(`xuannova:pending-payment:${member.id}`);
        if (!raw) return;
        const data = JSON.parse(raw) as { hash?: unknown; checkout?: unknown; packageId?: unknown };
        if (typeof data.hash !== "string" || !/^0x[0-9a-fA-F]{64}$/.test(data.hash) || (data.checkout !== "legacy" && data.checkout !== "usdc") || typeof data.packageId !== "string" || !creditPackages.some((item) => item.id === data.packageId)) return;
        setPendingHash(data.hash as Hex); setPendingCheckout(data.checkout); setPendingPackageId(data.packageId); setSelectedPackageId(data.packageId);
      } catch { /* persistence is best-effort; server reconciliation still monitors the chain */ }
    }, 0);
    return () => window.clearTimeout(timer);
  }, [member?.id]);
  const selectedPackage = useMemo(() => creditPackages.find((item) => item.id === selectedPackageId) ?? creditPackages[0], [selectedPackageId]);
  const selectedNetwork = useMemo(() => paymentNetworks.find((item) => item.id === networkId) ?? paymentNetworks[0], [networkId]);

  function displayError(cause: unknown) {
    if (typeof console !== "undefined") console.error("[Xuannova]", cause);
    if (cause instanceof WalletError) {
      if (cause.code === "REJECTED") return text.rejectedByUser;
      if (cause.code === "WRONG_CHAIN") return text.wrongChain;
      if (cause.code === "INSUFFICIENT_USDT") return text.insufficientUsdt;
      if (cause.code === "INSUFFICIENT_BNB") return text.insufficientBnb;
      if (cause.code === "INSUFFICIENT_TOKEN" && usdcQuote) return bnbQuoteText.shortToken[locale].replace("{coin}", usdcQuote.token).replace("{need}", formatUnits(usdcQuote.maxInput, tokenDecimals(usdcQuote.token)));
      if (cause.code === "NOT_CONFIGURED") return text.notConfigured;
      if (cause.code === "NOT_INSTALLED") return text.notInstalled;
    }
    const message = cause instanceof Error ? cause.message : "";
    if (message === "An account already exists for this email") return text.accountExists;
    if (message === "Invalid email or password") return text.invalidCredentials;
    if (message === "Use a password with 6 to 128 characters") return text.passwordRule;
    if (message === "This wallet is already linked to another account") return text.walletTaken;
    if (message === "Invitation code is invalid") return text.invalidInviteCode;
    if (message === "Checkout is not configured yet") return text.notConfigured;
    const known = localizeServerError(message, locale);
    if (known) return known;
    // Surface the underlying wallet / RPC reason so failures are diagnosable.
    if (cause instanceof WalletError && cause.code === "FAILED" && message) {
      const detail = message.split("\n").find((line) => line.trim()) ?? message;
      return `${text.requestFailed} (${detail.trim().slice(0, 140)})`;
    }
    return text.requestFailed;
  }

  const [cardPackages, setCardPackages] = useState<string[]>([]);
  useEffect(() => {
    let alive = true;
    void fetch("/api/auth/providers").then((response) => response.json()).then((data: { dodo?: { packages: string[] } | null }) => { if (alive) setCardPackages(data.dodo?.packages ?? []); }).catch(() => undefined);
    // Back from Dodo checkout: wait for the signed webhook to add the credits.
    const orderId = new URLSearchParams(window.location.search).get("dodo_order");
    if (orderId) {
      let tries = 0;
      const poll = async () => {
        tries += 1;
        try {
          const result = await fetch(`/api/payments/dodo/order?id=${encodeURIComponent(orderId)}`, { credentials: "same-origin" }).then((response) => response.json()) as { order?: { status: string } };
          if (result.order?.status === "paid") { setNotice(cardCopy[locale].paid, "success"); track("purchase_card_paid", {}); void refresh(); return; }
          if (result.order?.status === "failed") { setNotice(cardCopy[locale].failed); return; }
        } catch { /* keep waiting */ }
        if (alive && tries < 20) window.setTimeout(() => void poll(), 3000); else if (alive) setNotice(cardCopy[locale].pending, "info");
      };
      setNotice(cardCopy[locale].waiting, "info");
      void poll();
    }
    return () => { alive = false; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const [exclusivePackages, setExclusivePackages] = useState<Array<{ id: string; name: string; credits: number; usdt: string }>>([]);
  const refresh = useCallback(async (announce = false) => {
    try {
      const account = await request<{ member: Member | null }>("/api/member/me?soft=1", { method: "GET", headers: {} });
      announceGrowth(account);
      setAccountLoaded(true);
      if (!account.member) { setMember(null); setOrders([]); setLedger([]); return; }
      setMember(account.member);
    } catch (cause) {
      setAccountLoaded(true);
      // Only a rejected session signs the UI out; transient errors keep the current view.
      if ((cause as { status?: number }).status === 401) { setMember(null); setOrders([]); setLedger([]); }
      return;
    }
    try {
      const [nextOrders, nextInvitations, nextLedger] = await Promise.all([
        request<{ orders: Order[] }>("/api/member/orders", { method: "GET", headers: {} }),
        request<{ invitations: Invitation[] }>("/api/member/invitations", { method: "GET", headers: {} }),
        request<{ entries: LedgerEntry[]; nextBefore?: string | null }>("/api/member/ledger", { method: "GET", headers: {} }),
      ]);
      setOrders(nextOrders.orders);
      try { setExclusivePackages((await request<{ packages: Array<{ id: string; name: string; credits: number; usdt: string }> }>("/api/member/packages", { method: "GET", headers: {} })).packages); } catch { setExclusivePackages([]); }
      setInvitations(nextInvitations.invitations);
      try { setTeam(await request<TeamStats>("/api/member/team", { method: "GET", headers: {} })); } catch { setTeam(null); }
      setLedger(nextLedger.entries); setLedgerNext(nextLedger.nextBefore ?? null);
      if (announce) setNotice(text.balanceRefreshed, "success");
    } catch { /* keep previous data */ }
  }, [text.balanceRefreshed, setNotice]);

  useEffect(() => {
    const timer = window.setTimeout(() => { void refresh(); }, 0);
    // Prepared in the background (not on screen): load once, refresh again when it is opened.
    if (!active) return () => window.clearTimeout(timer);
    const interval = window.setInterval(() => { void refresh(); }, 20_000);
    const refreshOnReturn = () => { if (document.visibilityState === "visible") void refresh(); };
    window.addEventListener("focus", refreshOnReturn);
    document.addEventListener("visibilitychange", refreshOnReturn);
    return () => {
      window.clearTimeout(timer);
      window.clearInterval(interval);
      window.removeEventListener("focus", refreshOnReturn);
      document.removeEventListener("visibilitychange", refreshOnReturn);
    };
  }, [refresh, active]);

  useEffect(() => {
    // Let the site header switch its "membership" entry to "my account".
    window.dispatchEvent(new CustomEvent("xuannova:member", { detail: member ? { id: member.id } : null }));
  }, [member]);

  useEffect(() => {
    // EIP-6963 announcements arrive asynchronously; sample twice.
    const first = window.setTimeout(() => setWallets(availableWallets()), 0);
    // Wallet apps can inject their provider a few seconds late: keep sampling for 8 seconds.
    let samples = 0;
    const sampler = window.setInterval(() => { samples += 1; setWallets(availableWallets()); if (samples >= 16) window.clearInterval(sampler); }, 500);
    request<CheckoutConfig>("/api/checkout/config", { method: "GET", headers: {} }).then((next) => { setConfig(next); if (next.usdcOnly && next.usdcCheckoutAddress) setPaymentAsset("USDC"); }).catch(() => setConfig(null));
    return () => { window.clearTimeout(first); window.clearInterval(sampler); };
  }, []);

  async function signInWith(walletId: WalletProviderId) {
    setBusy(walletId); setNotice("");
    const linking = Boolean(member);
    setNotice(text.connectingWallet, "info");
    try {
      const { address, provider } = await connectWallet(walletId);
      const challenge = await request<{ message: string }>("/api/auth/wallet/nonce", { method: "POST", body: JSON.stringify({ address }) });
      setNotice(linking ? text.linkingWallet : text.signing, "info");
      const signature = await signMessage(provider, address, challenge.message);
      const result = await request<{ member: Member; linked?: boolean; created?: boolean }>("/api/auth/wallet/verify", {
        method: "POST",
        body: JSON.stringify({ address, message: challenge.message, signature, ...(inviteCode.trim() ? { inviteCode: inviteCode.trim() } : {}) }),
      });
      setMember(result.member);
      setSession({ provider, address, walletId });
      try { window.localStorage.setItem("xuanyuan.wallet", walletId); } catch { /* storage may be unavailable */ }
      setNotice(result.linked ? text.walletLinked : result.created ? text.walletCreated : text.walletSignedIn, "success");
      await refresh();
    } catch (cause) { setNotice(displayError(cause)); }
    finally { setBusy(""); }
  }

  async function authenticate(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy("email"); setNotice(text.processing, "info");
    try {
      // Email first: an existing email signs in; a new email creates the account with this password.
      const result = await request<{ member: Member }>(isRegister ? "/api/auth/register" : "/api/auth/login", { method: "POST", body: JSON.stringify({ email, password, autoRegister: true, ...(inviteCode.trim() ? { inviteCode } : {}) }) });
      track("login", { method: "email" });
      setMember(result.member); setPassword(""); await refresh();
      setNotice(isRegister ? text.registered : text.signedIn, "success");
    } catch (cause) { setNotice(displayError(cause)); }
    finally { setBusy(""); }
  }

  async function copyAddress() {
    try { await navigator.clipboard.writeText(selectedNetwork.address); setNotice(text.copied, "success"); }
    catch { setNotice(selectedNetwork.address, "info"); }
  }

  async function submitManualOrder(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy("manual"); setNotice(text.processing, "info");
    try {
      await request<{ order: Order }>("/api/orders/manual", { method: "POST", body: JSON.stringify({ packageId: checkout?.packageId ?? selectedPackage.id, network: selectedNetwork.id, transactionHash }) });
      track("purchase_submitted", { package: checkout?.packageId ?? selectedPackage.id }); setTransactionHash(""); setCheckout(null); setNotice(text.manualSubmitted, "success"); await refresh();
    } catch (cause) { setNotice(displayError(cause)); }
    finally { setBusy(""); }
  }

  async function signOut() {
    setBusy("signout"); setNotice("");
    try { await request<{ ok: true }>("/api/auth/logout", { method: "POST", body: "{}" }); setMember(null); setOrders([]); setSession(null); setNotice(text.signedOut, "success"); }
    catch (cause) { setNotice(displayError(cause)); }
    finally { setBusy(""); }
  }

  async function copyInviteLink() {
    if (!member?.inviteCode) return;
    const inviteLink = `${window.location.origin}/?invite=${encodeURIComponent(member.inviteCode)}&utm_source=invite-link#membership`;
    try { await navigator.clipboard.writeText(inviteLink); setNotice(text.inviteCopied, "success"); }
    catch { setNotice(inviteLink, "info"); }
  }

  async function reconnectForPayment() {
    if (session) {
      const accounts = await session.provider.request({ method: "eth_accounts" }) as string[];
      if (member?.walletAddress && accounts[0]?.toLowerCase() === member.walletAddress.toLowerCase() && session.address.toLowerCase() === member.walletAddress.toLowerCase()) return session;
      setSession(null);
      throw new WalletError("FAILED", "Connected wallet no longer matches the signed-in account");
    }
    // Session cookie survived a reload; re-open the wallet that owns this address,
    // trying the wallet used at sign-in first so only one prompt appears.
    let preferred: string | null = null;
    try { preferred = window.localStorage.getItem("xuanyuan.wallet") ?? window.localStorage.getItem("Xuannova.wallet"); } catch { /* ignore */ }
    const installed = wallets.filter((item) => item.installed).sort((a, b) => (a.id === preferred ? -1 : b.id === preferred ? 1 : 0));
    for (const wallet of installed) {
      try {
        const { address, provider } = await connectWallet(wallet.id);
        if (member?.walletAddress && address.toLowerCase() === member.walletAddress.toLowerCase()) {
          const next = { provider, address, walletId: wallet.id };
          setSession(next);
          return next;
        }
      } catch { /* try the next wallet */ }
    }
    throw new WalletError("NOT_INSTALLED", "Wallet not available");
  }

  async function confirmPurchase(hash: Hex, checkoutKind: "legacy" | "usdc" = "legacy", packageId: string = selectedPackage.id) {
    setStage("verifying");
    try {
      const result = await request<{ order: Order; member: Member }>("/api/orders", { method: "POST", body: JSON.stringify({ transactionHash: hash, packageId, checkout: checkoutKind }) });
      setMember(result.member);
      setPendingHash(null); setPendingPackageId(null);
      try { if (member?.id) window.localStorage.removeItem(`xuannova:pending-payment:${member.id}`); } catch { /* best effort */ }
      setCheckout(null);
      setNotice(text.paid, "success");
    } catch (cause) {
      const failure = cause as Error & { status?: number };
      // Paid on chain but not credited yet: remember the hash so the user can retry
      // verification instead of paying a second time.
      setPendingHash(hash);
      if (failure.status === 202) setNotice(text.pendingChain, "info");
      else throw cause;
    }
  }

  async function pay() {
    if (!member || !config) return;
    setBusy("pay"); setNotice(text.processing, "info"); setLastHash(null);
    try {
      if (pendingHash) {
        await confirmPurchase(pendingHash, pendingCheckout, pendingPackageId ?? selectedPackage.id);
        await refresh();
        return;
      }
      const active = await reconnectForPayment();
      const kind = paymentAsset === "legacy" ? "legacy" : "usdc";
      const stageUpdate = (next: PaymentStage, txHash?: Hex) => { setStage(next); if (txHash) { setLastHash(txHash); setPendingHash(txHash); setPendingCheckout(kind); setPendingPackageId(selectedPackage.id); try { window.localStorage.setItem(`xuannova:pending-payment:${member.id}`, JSON.stringify({ hash: txHash, checkout: kind, packageId: selectedPackage.id })); } catch { /* background chain reconciliation remains available */ } } };
      // A quote lasts two minutes: take a fresh one if it is missing or about to expire.
      let quote = usdcQuote;
      if (kind === "usdc" && (!quote || quote.deadline - BigInt(Math.floor(Date.now() / 1000)) < 45n)) quote = await requestUsdcQuote(true);
      if (kind === "usdc" && !quote) throw new WalletError("FAILED", bnbQuoteText.noRoute[locale]);
      const hash = kind === "usdc" && quote ? await purchaseUsdcPackage({
        provider: active.provider, address: active.address, packageId: selectedPackage.id, config, quote, onStage: stageUpdate,
      }) : kind === "legacy" ? await purchasePackage({
        provider: active.provider,
        address: active.address,
        packageId: selectedPackage.id,
        config,
        onStage: stageUpdate,
      }) : (() => { throw new WalletError("FAILED", "Quote required"); })();
      await confirmPurchase(hash, kind);
      await refresh();
    } catch (cause) {
      if ((cause as { code?: string })?.code === "TX_REVERTED") {
        setPendingHash(null); setPendingPackageId(null);
        try { window.localStorage.removeItem(`xuannova:pending-payment:${member.id}`); } catch { /* best effort */ }
      }
      setNotice(displayError(cause));
    }
    finally { setBusy(""); setStage(null); }
  }

  async function requestUsdcQuote(silent = false) {
    if (!config || paymentAsset === "legacy") return null;
    if (!silent) { setQuoting(true); setNotice(""); }
    try {
      // Read-only: public BSC RPCs, no wallet prompt.
      const quote = await getUsdcCheckoutQuote({ config, packageId: selectedPackage.id, token: paymentAsset });
      setUsdcQuote(quote);
      return quote;
    } catch (cause) {
      if (typeof console !== "undefined") console.error("[Xuannova] quote", cause);
      if (!silent) { setUsdcQuote(null); setNotice(cause instanceof Error && cause.message === "PRICE_IMPACT_TOO_HIGH" ? bnbQuoteText.thinPool[locale].replace("{coin}", paymentAsset) : bnbQuoteText.noRoute[locale]); }
      return null;
    }
    finally { if (!silent) setQuoting(false); }
  }  quoteRef.current = () => { void requestUsdcQuote(); };
  // Quote automatically when a coin other than USDT is chosen, and keep it fresh while the payment page is open.
  const quoteKey = checkout?.step === "wallet" && paymentAsset !== "legacy" && !pendingHash ? `${paymentAsset}:${selectedPackage.id}` : "";
  useEffect(() => {
    if (!quoteKey) return;
    quoteRef.current();
    const timer = window.setInterval(() => quoteRef.current(), 60_000);
    return () => window.clearInterval(timer);
  }, [quoteKey]);


  const stageText: Record<PaymentStage, string> = { switching: text.stageSwitching, approving: text.stageApproving, paying: text.stagePaying, confirming: text.stageConfirming, verifying: text.stageVerifying };
  const walletLabel = (id: WalletProviderId) => walletProviders.find((item) => item.id === id)?.label ?? id;
  const identity = member ? (member.signedInWith === "wallet" && member.walletAddress ? member.walletAddress : member.email ?? member.walletAddress ?? "") : "";
  async function copyText(value: string) {
    try { await navigator.clipboard.writeText(value); setNotice(text.copied, "success"); } catch { setNotice(value, "info"); }
  }

  const walletButtons = (compact = false) => wallets.map((wallet) => wallet.installed
    ? <button key={wallet.id} type="button" className="mc-wallet" disabled={busy !== ""} onClick={() => void signInWith(wallet.id)}>{wallet.icon ? <img src={wallet.icon} alt="" /> : <i>◆</i>}<span><b>{wallet.label}</b><small>{busy === wallet.id ? text.connecting : text.connect}</small></span></button>
    : wallet.id === "tokenpocket" && inTokenPocket()
    ? <a key={wallet.id} className={`mc-wallet is-switch${compact ? " is-compact" : ""}`} href={`tpoutside://pull.activity?param=${encodeURIComponent(JSON.stringify({ url: window.location.href, chain: "BSC", source: "Xuannova" }))}`} onClick={(event) => { if (!tpBridgeAvailable()) return; event.preventDefault(); void tpSwitchWallet("bsc"); }}><i>⇄</i><span><b>{wallet.label}</b><small>{walletPayText.switchTp[locale].replace("{chain}", "BNB Chain")}</small></span></a>
    : <a key={wallet.id} className={`mc-wallet is-missing${compact ? " is-compact" : ""}`} href={walletInstallUrl(wallet.id)} target="_blank" rel="noreferrer"><i>◇</i><span><b>{wallet.label}</b><small>{text.notInstalled} · {text.install}</small></span></a>);

  const openCheckout = (packageId: string) => { if (pendingHash && pendingPackageId && packageId !== pendingPackageId) { setNotice(text.pendingChain, "info"); return; } setSelectedPackageId(packageId); setCheckout({ packageId, step: "choose" }); setUsdcQuote(null); setNotice(""); setLastHash(null); };
  // Card payment (Dodo Payments): opens Dodo's hosted checkout; credits arrive by signed webhook.
  const payByCard = async (packageId: string) => {
    setBusy("card"); setNotice(cardCopy[locale].opening, "info");
    try {
      track("purchase_card_start", { package: packageId });
      const result = await request<{ url: string }>("/api/payments/dodo/checkout", { method: "POST", body: JSON.stringify({ packageId, locale }) });
      window.location.assign(result.url);
    } catch (cause) { setNotice(displayError(cause)); setBusy(""); }
  };
  /** Coins the wallet payment accepts on each network (BNB Chain: USDT direct; USDC, BNB, ASTER via the checkout contract when it is configured). */
  const walletCoinsFor = (id: string) => id === "bsc" ? (config?.usdcCheckoutAddress ? ["USDT", "USDC", "BNB", "ASTER", ...(config.checkoutTokens ?? [])] : ["USDT"]) : id === "solana" || id === "ethereum" ? ["USDC", "USDT"] : id === "tron" ? ["USDT"] : [];
  const packageCredits = (credits: number) => <>
    <p className="mc-package-credits"><b>{fillCredits(benefitsText.base[locale], { n: credits })}</b><small>{fillCredits(benefitsText.reports[locale], { n: Math.floor(credits / CREDIT_RULES.report) })}</small></p>
    {(!member || member.firstPurchaseOffer) && <p className="mc-package-bonus"><span>{fillCredits(benefitsText.firstBonus[locale], { n: firstPurchaseBonusCredits })}</span><small>{fillCredits(benefitsText.firstTotal[locale], { n: credits + firstPurchaseBonusCredits })}</small></p>}
  </>;
  const packageCards = creditPackages.map((item, index) => <article key={item.id} className={`mc-package${selectedPackage.id === item.id && checkout ? " is-selected" : ""}`}>
    {index === 1 && <em>{text.recommended}</em>}
    <h4>{packageNames[locale][item.id]}</h4>
    <strong>${item.usdt}</strong>
    {packageCredits(item.credits)}
    <button type="button" className="primary-action mc-buy-button" disabled={!member || busy === "pay"} onClick={() => openCheckout(item.id)}>{text.buy}<b>↗</b></button>
    {cardPackages.includes(item.id) && <button type="button" className="secondary-action mc-card-button" disabled={!member || busy === "card"} onClick={() => void payByCard(item.id)}>{cardCopy[locale].pay}</button>}
  </article>).concat(exclusivePackages.map((item) => <article key={item.id} className={`mc-package is-exclusive${checkout?.packageId === item.id ? " is-selected" : ""}`}>
    <em>{exclusiveLabel[locale]}</em>
    <h4>{item.name}</h4>
    <strong>${item.usdt}</strong>
    {packageCredits(item.credits)}
    {/* Exclusive packages are paid by reviewed manual transfer (the on-chain store only sells the public packages). */}
    <button type="button" className="primary-action mc-buy-button" disabled={!member || busy === "pay"} onClick={() => { setCheckout({ packageId: item.id, step: "qr" }); setNotice(""); setLastHash(null); }}>{text.buy}<b>↗</b></button>
    {cardPackages.includes(item.id) && <button type="button" className="secondary-action mc-card-button" disabled={!member || busy === "card"} onClick={() => void payByCard(item.id)}>{cardCopy[locale].pay}</button>}
  </article>));

  const orderStatus = (order: Order) => order.status === "rejected" ? text.statusRejected : order.status === "approved" ? text.statusDone : text.statusReview;
  const orderMethod = (order: Order) => order.buyerAddress ? text.methodOnchain : text.methodQr;

  const toast = noticeState && <div className={`commerce-toast is-${noticeState.kind}`} role={noticeState.kind === "error" ? "alert" : "status"} aria-live="polite"><span>{noticeState.kind === "success" ? "✓" : noticeState.kind === "error" ? "!" : "…"}</span><p>{noticeState.text}</p><button type="button" aria-label="close" onClick={() => setNoticeState(null)}>×</button></div>;

  if (!member && !accountLoaded) {
    return <section className="member-commerce-center mc mc-loading" data-testid="member-commerce-center" aria-busy="true"><p className="mc-loading-line"><span className="wallet-direct-spin" aria-hidden="true" />{text.loading}</p></section>;
  }
  if (!member) {
    return <section className="member-commerce-center mc" data-testid="member-commerce-center">
      {toast}
      <div className="mc-auth" data-testid="wallet-sign-in">
        <header className="mc-auth-head"><span>{text.eyebrow}</span><h2>{text.welcome}</h2><p>{text.welcomeLead}</p></header>
        {roomInvite && <p className="mc-first-offer">◎ {roomInviteText[locale]}</p>}
        <nav className="mc-tabs" role="tablist">
          <button type="button" role="tab" aria-selected={authTab === "email"} className={authTab === "email" ? "is-active" : ""} onClick={() => { setAuthTab("email"); setNotice(""); }}>{text.emailTab}</button>
          <button type="button" role="tab" aria-selected={authTab === "wallet"} className={authTab === "wallet" ? "is-active" : ""} onClick={() => { setAuthTab("wallet"); setNotice(""); }}>{text.walletTab}</button>
        </nav>
        {authTab === "wallet" ? <div className="mc-auth-panel">
          <div className="mc-wallet-grid">{walletButtons()}</div>
          <label className="mc-field"><span>{text.inviteInput}</span><input value={inviteCode} maxLength={10} autoComplete="off" placeholder={text.inviteInputHint} onChange={(event) => setInviteCode(event.target.value.toUpperCase())} /></label>
        </div> : <form className="mc-auth-panel" onSubmit={authenticate} data-testid="email-sign-in">
          <label className="mc-field"><span>{text.email}</span><input type="email" required autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} /></label>
          <label className="mc-field"><span>{text.password}</span><input type="password" required minLength={6} autoComplete={isRegister ? "new-password" : "current-password"} value={password} onChange={(event) => setPassword(event.target.value)} /></label>
          {<label className="mc-field"><span>{text.inviteInput}</span><input value={inviteCode} maxLength={10} autoComplete="off" placeholder={text.inviteInputHint} onChange={(event) => setInviteCode(event.target.value.toUpperCase())} /></label>}
          <button className="primary-action mc-submit" type="submit" disabled={busy !== ""}>{isRegister ? text.createAndSignIn : `${text.signIn} / ${text.create}`}<b>↗</b></button>
          <p className="mc-muted mc-auth-note">{emailFirstNote[locale]}</p>
          <GoogleSignIn locale={locale} inviteCode={inviteCode.trim() || undefined} onSignedIn={() => { void refresh(); setNotice(text.signedIn, "success"); }} onError={(message) => setNotice(message)} />
        </form>}
        {!member && <PasswordReset locale={locale} />}
        {notice && <p className={`mc-inline is-${noticeState?.kind ?? "info"}`} role="status">{notice}</p>}
      </div>
      <WalletCheck /><section className="mc-card mc-preview"><BenefitsTable locale={locale} /></section>
      <section className="mc-card mc-preview"><header><h3>{text.packages}</h3><p>{text.createFirst}</p></header><div className="pay-network-strip" aria-label={payChainText.chooseNetwork[locale]}>{payChains.map((item) => <span key={item.id} className="is-open"><ChainBadge chain={item} /><b>{item.name}</b><small>{payChainText.coinsNow[locale]}</small></span>)}</div>{<p className="mc-first-offer">🎁 {growthCopy[locale].offer.replace("{n}", String(firstPurchaseBonusCredits))}</p>}<div className="mc-package-grid">{packageCards}</div><CreditPriceList locale={locale} /></section>
    </section>;
  }

  const inviteLink = member.inviteCode ? `${typeof window === "undefined" ? "" : window.location.origin}/?invite=${encodeURIComponent(member.inviteCode)}&utm_source=invite-link#membership` : "";

  if (mode === "center") {
    const tabs = centerTabs[locale];
    const go = (next: CenterTab) => { if (next !== "profiles") setProfileAdd(false); setCenterTab(next); try { window.history.replaceState(null, "", `${window.location.pathname}?tab=${next}`); } catch { /* ignore */ } };
    return <section className="member-commerce-center mc mc-dashboard" data-testid="member-commerce-center">
      {toast}
      <section className="mc-dash-hero">
        <div className="mc-dash-who">
          <MemberAvatar seed={member?.id ?? ""} />
          <div className="mc-identity">
            <small>{text.eyebrow}</small>
            <p className="commerce-identity" title={identity}>{member.signedInWith === "wallet" && member.walletAddress ? <code>{shortAddress(member.walletAddress)}</code> : identity}<button type="button" className="mc-copy" onClick={() => void copyText(identity)} aria-label={text.copyAddress}>⧉</button></p>
            <div className="mc-tags">
              <span>{text.method}: {member.signedInWith === "wallet" ? text.methodWallet : text.methodEmail}{session && ` · ${walletLabel(session.walletId)}`}</span>
              {member.walletAddress
                ? <span className="is-ok" title={member.walletAddress}>{text.linkedWallet} · {shortAddress(member.walletAddress)}</span>
                : <span className="is-muted">{text.noWallet}</span>}
            </div>
          </div>
        </div>
        <div className="mc-dash-balance">
          <small>{text.balance}</small>
          <b>{member.balance}</b>
          <span>{text.credits}</span>
          <small className="mc-daily-credit">{dailyBonusLine[locale](member.dailyCredits ?? 0)}</small>
        </div>
        <div className="mc-dash-actions">
          <button type="button" className="primary-action mc-submit" onClick={onBuyCredits}>{text.buyCredits}<b>↗</b></button>
          <div>
            <button className="text-action" type="button" onClick={() => void refresh(true)} disabled={busy !== ""}>{text.refreshBalance}</button>
            <button className="text-action" type="button" onClick={signOut} disabled={busy !== ""}>{text.signOut}</button>
          </div>
        </div>
        <dl className="mc-dash-stats">
          <div><dt>{tabs.statInvited}</dt><dd>{team?.invited ?? invitations.length}</dd></div>
          <div><dt>{tabs.statTeam}</dt><dd>{(team?.totalCredits ?? 0).toLocaleString()}</dd></div>
          <div><dt>{tabs.statSpent}</dt><dd>{ledger.filter((entry) => entry.delta < 0).reduce((sum, entry) => sum - entry.delta, 0)}</dd></div>
        </dl>
      </section>

      <nav className="mc-tabs" aria-label={text.center}>
        {(Object.keys(tabs.names) as CenterTab[]).map((key) => <button type="button" key={key} className={centerTab === key ? "active" : ""} aria-current={centerTab === key ? "page" : undefined} onClick={() => { setProfileAdd(false); go(key); }}><i aria-hidden="true">{centerTabMarks[key]}</i><span>{tabs.names[key]}</span></button>)}
      </nav>

      <div className="mc-tab-body">
        {centerTab === "overview" && <div className="mc-overview">
          <div className="mc-quick">
            <button type="button" className="mc-quick-card is-primary" onClick={() => { setProfileAdd(true); go("profiles"); }}><i aria-hidden="true">＋</i><b>{libraryText.addOther[locale]}</b><small>{tabs.leads.profiles}</small><em>→</em></button>
            {(["reports", "shelf", "invite"] as CenterTab[]).map((key) => <button type="button" key={key} className="mc-quick-card" onClick={() => go(key)}><i aria-hidden="true">{centerTabMarks[key]}</i><b>{tabs.names[key]}</b><small>{tabs.leads[key]}</small><em>→</em></button>)}
          </div>
          {!member.walletAddress && <div className="mc-link"><p>{text.linkWallet}</p><div className="mc-wallet-grid">{walletButtons(true)}</div></div>}
          <section className="mc-card mc-guide"><a href={pathFor(locale, "guide")} onClick={(event) => { if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return; event.preventDefault(); rememberScroll(); window.history.pushState({ scrollY: 0 }, "", pathFor(locale, "guide")); window.dispatchEvent(new Event("xn:navigate")); window.scrollTo({ top: 0, behavior: "instant" }); }}><b>{titleForRoute("guide", locale)}</b><span>{guideLead[locale]}</span><i>→</i></a></section>
          <section className="mc-card mc-reminders"><ReminderToggle locale={locale} /><SolarTermToggle locale={locale} /></section>
        </div>}
        {centerTab === "reports" && <MemberReports locale={locale} />}
        {centerTab === "profiles" && <MemberProfiles key={profileAdd ? "adding" : "list"} locale={locale} startAdding={profileAdd} />}
        {centerTab === "rooms" && <MemberRooms locale={locale} onOpenProfiles={() => setCenterTab("profiles")} />}
        {centerTab === "shelf" && <MemberBookshelf locale={locale} />}
        {centerTab === "credits" && <>
          <section className="mc-card mc-ledger">
            <header><h3>{ledgerCopy[locale].title}</h3><p className="ml-muted">{libraryText.creditsNote[locale]}</p></header>
            {ledger.length ? <ul className="mc-list">{ledger.map((entry) => <li key={entry.id}>
              <div><b>{ledgerReason(entry.reason, ledgerCopy[locale])}{entry.reason.startsWith("interpretation:") ? ` · ${toolLabel(entry.reason.slice("interpretation:".length), locale)}` : ""}</b><small>{new Date(entry.createdAt).toLocaleString(locale)} · {ledgerCopy[locale].balanceAfter}: {entry.balanceAfter}</small></div>
              <strong className={entry.delta < 0 ? "mc-ledger-negative" : ""}>{entry.delta > 0 ? "+" : ""}{entry.delta}</strong>
            </li>)}</ul> : <p className="mc-muted">{ledgerCopy[locale].empty}</p>}
            {ledgerNext && <button type="button" className="text-action" onClick={async () => { try { const more = await request<{ entries: LedgerEntry[]; nextBefore?: string | null }>(`/api/member/ledger?before=${encodeURIComponent(ledgerNext)}`, { method: "GET", headers: {} }); setLedger((current) => [...current, ...more.entries]); setLedgerNext(more.nextBefore ?? null); } catch { /* keep the list */ } }}>{loadMoreLabel[locale]}</button>}
          </section>
        </>}
        {centerTab === "invite" && <div className="mc-invite-tab">
          {member.inviteCode && <section className="mc-card mc-invite"><header><h3>{text.inviteTitle}</h3><p>{text.inviteLead}</p></header>
            <div className="mc-invite-code"><small>{text.inviteCode}</small><code>{member.inviteCode}</code></div>
            <div className="mc-invite-link"><code>{inviteLink}</code></div>
            <button type="button" className="primary-action mc-submit" onClick={copyInviteLink}>{text.copyInvite}<b>⧉</b></button>
          </section>}
          <section className="mc-card mc-invitees">
            <header><h3>{text.inviteList}</h3><p>{invitations.length} {text.inviteCount} · +{invitations.length * 5} {text.credits}</p></header>
            {team && <section className="mc-team" aria-label={teamCopy[locale].title}><h4>{teamCopy[locale].title}</h4><dl>
              <div><dt>{teamCopy[locale].invited}</dt><dd>{team.invited}</dd></div>
              <div><dt>{teamCopy[locale].purchasers}</dt><dd>{team.purchasers}</dd></div>
              <div><dt>{teamCopy[locale].total}</dt><dd>${team.totalUsd}</dd></div>
              <div><dt>{teamCopy[locale].credits}</dt><dd>{(team.totalCredits ?? 0).toLocaleString()}</dd></div>
            </dl>{team.sources && team.sources.length > 0 && <div className="mc-team-sources"><b>{shareReportText.mySources[locale]}</b><ul>{team.sources.map((row) => <li key={row.source}><span>{sourceLabel(row.source, locale)}</span><em>{row.invited}</em></li>)}</ul></div>}<small>{teamCopy[locale].note}</small></section>}
            {invitations.length ? <ul className="mc-list">{invitations.map((row) => <li key={row.id}><div><b>{row.label}</b><small>{row.via === "wallet" ? text.methodWallet : text.methodEmail} · {text.joinedAt} {new Date(row.joinedAt).toLocaleDateString(locale)}</small></div><strong>+{row.reward}</strong></li>)}</ul> : <p className="mc-muted">{text.inviteListEmpty}</p>}
          </section>
        </div>}
        {centerTab === "settings" && <>
          <section className="mc-card mc-reminders"><ReminderToggle locale={locale} /><SolarTermToggle locale={locale} /></section>
          <MemberPrivacy locale={locale} />
      <section className="mc-card mc-contact mc-contact-bar"><header><h3>{text.contact}</h3><p>{text.contactLead}</p></header>
        <ContactIconRow className="mc-contact-icons" copied={text.copyAddress + " ✓"} />
      </section>
        </>}
      </div>
      {notice && <p className={`mc-inline is-${noticeState?.kind ?? "info"}`} role="status">{notice}</p>}
    </section>;
  }

  const exclusiveCheckout = checkout ? exclusivePackages.find((item) => item.id === checkout.packageId) : undefined;
  const checkoutPackage = exclusiveCheckout ?? (checkout ? creditPackages.find((item) => item.id === checkout.packageId) ?? selectedPackage : selectedPackage);
  const checkoutName = exclusiveCheckout?.name ?? packageNames[locale][checkoutPackage.id as (typeof creditPackages)[number]["id"]];

  return <section className="member-commerce-center mc" data-testid="member-commerce-center">
    {toast}
    <header className="mc-hero mc-hero-lead"><p>{text.storeLead}</p></header>
    <section className="mc-profile mc-profile-compact">
      <MemberAvatar seed={member?.id ?? ""} />
      <div className="mc-identity"><small>{text.profile}</small><p className="commerce-identity" title={identity}>{member.signedInWith === "wallet" && member.walletAddress ? <code>{shortAddress(member.walletAddress)}</code> : identity}</p></div>
      <div className="mc-balance"><small>{text.balance}</small><b>{member.balance}</b><span>{text.credits}</span><small className="mc-daily-credit">{dailyBonusLine[locale](member.dailyCredits ?? 0)}</small></div>
      <div className="mc-actions"><button className="text-action" type="button" onClick={() => void refresh(true)} disabled={busy !== ""}>{text.refreshBalance}</button></div>
    </section>

    {config?.multichainWalletLinkEnabled && <MultichainWalletLink locale={locale} />}

    <WalletCheck />
    <section className="mc-card"><BenefitsTable locale={locale} /></section>
    <section className="mc-card"><header><h3>{text.packages}</h3><p>{text.autoCredit}</p></header><div className="pay-network-strip" aria-label={payChainText.chooseNetwork[locale]}>{payChains.map((item) => <span key={item.id} className="is-open"><ChainBadge chain={item} /><b>{item.name}</b><small>{payChainText.coinsNow[locale]}</small></span>)}</div>{(!member || member.firstPurchaseOffer) && <p className="mc-first-offer">🎁 {growthCopy[locale].offer.replace("{n}", String(firstPurchaseBonusCredits))}</p>}<div className="mc-package-grid">{packageCards}</div><CreditPriceList locale={locale} /></section>

    <section className="mc-card mc-orders" data-testid="purchase-records"><header><h3>{text.records}</h3><p>{text.recordsLead}</p></header>
      {orders.length ? <ul>{orders.map((order) => <li key={order.id}>
        <div><b>{order.amountUsdt} {order.settlementCurrency ?? "USDT"} · {order.credits} {text.credits}</b><small>{orderMethod(order)} · {order.network.toUpperCase()} · {new Date(order.submittedAt).toLocaleString(locale)}</small>{order.buyerAddress ? <a href={explorerTxUrl(order.transactionHash, config)} target="_blank" rel="noreferrer">{text.viewTx}</a> : <small className="mc-hash">{order.transactionHash}</small>}{order.status === "rejected" && order.reviewNote && <small>{order.reviewNote}</small>}</div>
        <strong data-status={order.status}>{orderStatus(order)}</strong>
      </li>)}</ul> : <p className="mc-muted">{text.noOrders}</p>}
    </section>
    {notice && !checkout && <p className={`mc-inline is-${noticeState?.kind ?? "info"}`} role="status">{notice}</p>}

    {checkout && <div className="mc-modal-backdrop" role="presentation" onClick={() => { if (busy === "" && !directBusy) setCheckout(null); }}>
      <div className="mc-modal" role="dialog" aria-modal="true" data-testid="wallet-checkout" onClick={(event) => event.stopPropagation()}>
        <header className="mc-modal-head">
          {checkout.step !== "choose" && !exclusiveCheckout && <button type="button" className="mc-copy" onClick={() => setCheckout({ ...checkout, step: "choose" })} disabled={busy !== "" || directBusy}>← {text.back}</button>}
          <div><small>{text.packageLabel}</small><b>{checkoutName} · ${checkoutPackage.usdt} · {checkoutPackage.credits} {text.credits} Nova</b></div>
          <button type="button" className="mc-copy" onClick={() => setCheckout(null)} disabled={busy !== "" || directBusy} aria-label={text.close}>×</button>
        </header>

        {checkout.step === "choose" && (() => {
          const chain = payChains.find((item) => item.id === payChain) ?? payChains[0];
          const walletOpen = chain.id === "bsc";
          const walletCoins = walletCoinsFor(chain.id);
          const directChain = chain.id === "solana" || chain.id === "tron" || chain.id === "ethereum" ? chain.id : null;
          const openCoins = [...new Set([...walletCoins, ...chain.transferCoins])];
          return <div className="mc-choice pay-choice">
            <h3>{payChainText.chooseNetwork[locale]}</h3>
            <div className="pay-chains" role="radiogroup">
              {payChains.map((item) => <button type="button" role="radio" aria-checked={payChain === item.id} key={item.id} className={`pay-chain${payChain === item.id ? " is-active" : ""}`} onClick={() => setPayChain(item.id)}>
                <ChainBadge chain={item} /><b>{item.name}</b><small>{shortCoins([...new Set([...walletCoinsFor(item.id), ...item.transferCoins])])}</small>
              </button>)}
            </div>
            <div className={`pay-chain-panel is-${chain.id}`}>
              <div className="pay-chain-head"><ChainBadge chain={chain} /><div><b>{chain.name}</b><small>{payChainText.coins[locale]} · {openCoins.join(" · ")}</small></div></div>
              <div className="pay-coins"><div>{openCoins.map((coin) => <CoinChip key={coin} symbol={coin} />)}</div></div>
              <h3>{payChainText.chooseMethod[locale]}</h3>
              {walletOpen && (member.walletAddress
                ? <button type="button" className="mc-option is-primary" disabled={!config?.enabled} onClick={() => setCheckout({ ...checkout, step: "wallet" })}><i>◆</i><span><b>{walletPayText.option[locale]}</b><small>{config?.enabled ? <>{walletPayText.optionLead[locale].replace("{wallet}", "MetaMask · OKX · Binance · TokenPocket")}<br />{payChainText.payCoins[locale].replace("{coins}", shortCoins(walletCoins, 6))}</> : text.notConfigured}</small></span><em>→</em></button>
                : <div className="mc-option is-static"><i>◇</i><span><b>{text.bindWallet}</b><small>{text.bindWalletLead}</small><span className="mc-wallet-grid">{walletButtons(true)}</span></span></div>)}
              {directChain && <button type="button" className="mc-option is-primary" onClick={() => setCheckout({ ...checkout, step: "direct" })}><i>◆</i><span><b>{walletPayText.option[locale]}</b><small>{walletPayText.optionLead[locale].replace("{wallet}", directChain === "ethereum" ? "MetaMask · OKX · Binance · TokenPocket" : directChain === "solana" ? "Phantom · OKX · Binance · TokenPocket" : "TronLink · OKX · TokenPocket · Bitget")}<br />{payChainText.payCoins[locale].replace("{coins}", walletCoins.join(" · "))}</small></span><em>→</em></button>}
              {chain.qrNetwork && <button type="button" className="mc-option" onClick={() => { setNetworkId(chain.qrNetwork as PaymentNetworkId); setCheckout({ ...checkout, step: "qr" }); }}><i>▦</i><span><b>{payChainText.qrNetwork[locale].replace("{coin}", chain.transferCoins.join(" / ")).replace("{chain}", chain.short)}</b><small>{payChainText.qrLead[locale]}</small></span><em>→</em></button>}
            </div>
          </div>;
        })()}

        {checkout.step === "qr" && <form className="mc-pay" onSubmit={submitManualOrder} data-testid="manual-transfer">
          <div className="mc-networks">{paymentNetworks.map((network) => <label key={network.id} className={networkId === network.id ? "is-active" : ""}><input type="radio" name="network" value={network.id} checked={networkId === network.id} onChange={() => setNetworkId(network.id)} /><NetworkLogo network={network.id} /><span>{network.label}</span></label>)}</div>
          <div className="mc-transfer">
            <img className="pay-qr" src={selectedNetwork.qrImage} alt={`${selectedNetwork.label} QR`} />
            <dl className="mc-summary">
              <div><dt>{text.total}</dt><dd>{checkoutPackage.usdt} {networkId === "erc20" || networkId === "solana" ? "USDC / USDT" : "USDT"}</dd></div>
              <div><dt>{text.recipient}</dt><dd><code>{selectedNetwork.address}</code><button type="button" className="mc-copy" onClick={copyAddress} aria-label={text.copy}>⧉</button></dd></div>
            </dl>
          </div>
          <p className="mc-hint is-warning">{networkId === "erc20" || networkId === "solana" ? payChainText.stableNote[locale] : text.warning}</p>
          <label className="mc-field"><span>{text.hash}</span><input required value={transactionHash} onChange={(event) => setTransactionHash(event.target.value)} placeholder={text.hashHint} /></label>
          <p className="mc-hint">{text.manual}</p>
          <button type="submit" className="primary-action mc-submit" disabled={busy !== ""}>{text.submit}<b>↗</b></button>
        </form>}

        {checkout.step === "direct" && (payChain === "solana" || payChain === "tron" || payChain === "ethereum") && <WalletDirectPay chain={payChain} packageId={checkoutPackage.id} price={checkoutPackage.usdt} locale={locale} onBusy={setDirectBusy} onCredited={() => { void refresh(true); }} />}

        {checkout.step === "wallet" && <div className="mc-pay">
          {config?.usdcCheckoutAddress && <div className="mc-field"><span>{usdcPaymentCopy[locale].method}</span><div className="mc-coin-choice" role="radiogroup" aria-label={usdcPaymentCopy[locale].method}>{bnbCoinOptions(Boolean(config.usdcOnly), config.checkoutTokens ?? []).map((option) => <button key={option.value} type="button" role="radio" aria-checked={paymentAsset === option.value} className={paymentAsset === option.value ? "is-active" : ""} disabled={busy !== "" || Boolean(pendingHash)} onClick={() => { setPaymentAsset(option.value); setUsdcQuote(null); }}><b>{option.label}</b>{option.value === "legacy" ? <small>{bnbCoinText.direct[locale]}</small> : null}</button>)}</div><small className="mc-coin-note">{paymentAsset === "legacy" ? bnbCoinText.directNote[locale] : bnbCoinText.swapNote[locale]}</small></div>}
          <dl className="mc-summary">
            <div><dt>{text.network}</dt><dd>{config?.chainName ?? "BNB Smart Chain"} (BEP20){config?.testnet && " · TESTNET"}</dd></div>
            <div><dt>{text.payWith}</dt><dd><code>{shortAddress(member.walletAddress ?? "")}</code>{session && ` · ${walletLabel(session.walletId)}`}</dd></div>
            <div className="is-total"><dt>{text.total}</dt><dd>{paymentAsset === "legacy" ? `${checkoutPackage.usdt} USDT` : usdcQuote ? `≈ ${formatUnits(usdcQuote.estimatedInput, tokenDecimals(usdcQuote.token))} ${usdcQuote.token}` : `${checkoutPackage.usdt} USD · ${bnbCoinText.afterQuote[locale].replace("{coin}", paymentAsset)}`}</dd></div>
          </dl>
          {paymentAsset !== "legacy" && !pendingHash && <>{quoting && !usdcQuote && <p className="mc-hint">{bnbQuoteText.updating[locale]}</p>}{usdcQuote && <div role="status" className="mc-quote"><p>{usdcPaymentCopy[locale].estimated}: {formatUnits(usdcQuote.estimatedInput, tokenDecimals(usdcQuote.token))} {usdcQuote.token}</p><p>{usdcPaymentCopy[locale].maximum}: {formatUnits(usdcQuote.maxInput, tokenDecimals(usdcQuote.token))} {usdcQuote.token}</p><p>{usdcPaymentCopy[locale].expiry}</p><p>{usdcPaymentCopy[locale].fee} {formatUnits(BigInt(config?.platformFeeWei ?? "0"), 18)} BNB</p>{paymentAsset !== "BNB" && <p>{bnbQuoteText.twoSteps[locale].replaceAll("{coin}", paymentAsset)}</p>}</div>}<button type="button" className="text-action" disabled={busy !== "" || quoting} onClick={() => void requestUsdcQuote()}>{quoting ? bnbQuoteText.updating[locale] : bnbQuoteText.refresh[locale]}</button></>}
          <button type="button" className="primary-action mc-submit" disabled={busy !== "" || !config?.enabled || (paymentAsset !== "legacy" && !pendingHash && !usdcQuote && quoting)} onClick={() => void pay()}>{busy === "pay" && stage ? stageText[stage] : pendingHash ? text.stageVerifying.replace(/…$/, "") : paymentAsset === "legacy" ? `${text.pay} · ${checkoutPackage.usdt} USDT` : `${text.pay} · ${paymentAsset}`}<b>↗</b></button>
          {lastHash && <a className="text-action" href={explorerTxUrl(lastHash, config)} target="_blank" rel="noreferrer">{text.viewTx}</a>}
        </div>}

        {notice && <p className={`mc-inline is-${noticeState?.kind ?? "info"}`} role="status">{notice}</p>}
      </div>
    </div>}
  </section>;
}
