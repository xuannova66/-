"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { createInterpretationRequest, type CompleteChart, type InterpretationResponse } from "./chart-model";
import { creditCopy } from "./credit-copy";
import { CostLine } from "./benefits";
import { SampleReportButton } from "./sample-report";
import { interpretationCost, type CreditWallet } from "./credit-wallet";
import type { Locale } from "./site-content";
import { track } from "./analytics";
import { trustText } from "./trust-copy";
import { splitTerms } from "./glossary";
import { ChartTerm } from "./chart-term";
import { ReadingModeToggle, useReadingMode } from "./reading-mode";
import { ShareCardButton } from "./share-card";
import { titleForRoute, type AppRoute } from "./study-suite";
import { nextStepRoutes } from "./reading-next-steps";
import { ContactIconRow } from "./contact-icons";
import { announceGrowth } from "./growth-notice";
import { followUpHistory, selectFollowUps, summarizeReading, type FollowUpContext } from "./reading-followups";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });
const moreText = {
  title: L("Explore another perspective", "也可以探索这些方面", "也可以探索這些方面", "別の視点から考える", "다른 관점도 살펴보세요", "Khám phá góc nhìn khác", "ลองสำรวจมุมมองอื่น"),
  lead: L("Tap a question to put it in the box above, then ask. Each answer uses {cost} credits.", "点一下问题，会自动填进上方提问框，再点“提问”即可。每次回答 {cost} 积分。", "點一下問題，會自動填進上方提問框，再點「提問」即可。每次回答 {cost} 積分。", "質問をタップすると上の入力欄に入ります。「質問する」を押してください。回答ごとに {cost} クレジットです。", "질문을 누르면 위 입력란에 들어갑니다. '질문'을 눌러 주세요. 답변마다 {cost} 크레딧이 사용됩니다.", "Chạm vào câu hỏi để điền vào ô phía trên, rồi bấm Hỏi. Mỗi câu trả lời dùng {cost} điểm.", "แตะคำถามเพื่อใส่ลงในช่องด้านบน แล้วกดถาม แต่ละคำตอบใช้ {cost} เครดิต"),
  advisorEyebrow: L("Free consultation", "免费咨询", "免費諮詢", "無料相談", "무료 상담", "Tư vấn miễn phí", "ปรึกษาฟรี"),
  advisor: L("A dedicated advisor stays with you throughout: an Eastern-culture mentor explains your chart one-to-one and answers your questions.", "专属顾问全程对接，东方文化导师一对一为您讲解盘面、答疑解惑。", "專屬顧問全程對接，東方文化導師一對一為您講解盤面、答疑解惑。", "専属アドバイザーが最後までサポート。東洋文化の講師がマンツーマンで盤面を解説し、疑問にお答えします。", "전담 상담사가 끝까지 함께합니다. 동양 문화 강사가 일대일로 판면을 설명하고 궁금한 점에 답해 드립니다.", "Tư vấn viên riêng đồng hành suốt quá trình: giảng viên văn hóa phương Đông giải thích bàn của bạn và giải đáp thắc mắc một kèm một.", "มีที่ปรึกษาเฉพาะดูแลตลอด ผู้สอนวัฒนธรรมตะวันออกอธิบายผังของคุณแบบตัวต่อตัวและตอบทุกข้อสงสัย"),
  advisorNote: L("Free of charge. Tap an icon to start a chat.", "不收费，点图标即可联系。", "不收費，點圖示即可聯絡。", "無料です。アイコンをタップして連絡できます。", "무료입니다. 아이콘을 눌러 연락하세요.", "Miễn phí. Chạm vào biểu tượng để liên hệ.", "ไม่มีค่าใช้จ่าย แตะไอคอนเพื่อติดต่อ"),
};

const askMore: Record<Locale, string> = { en: "Want to ask about something specific?", "zh-Hans": "想问具体的事？", "zh-Hant": "想問具體的事？", ja: "具体的に聞きたいことはありますか？", ko: "구체적으로 묻고 싶은 것이 있나요?", vi: "Muốn hỏi về một việc cụ thể?", th: "อยากถามเรื่องที่เจาะจงไหม?" };
const sameQuestion = L("Write a different question first", "请先写一个新的问题", "請先寫一個新的問題", "先に別の質問を書いてください", "먼저 다른 질문을 적어 주세요", "Hãy viết một câu hỏi khác trước", "โปรดเขียนคำถามใหม่ก่อน");
// After a reading is unlocked, the ask button makes a new reading for a different question (it does not re-charge the current one).
const anotherReading = L("New question, new reading · {cost} credits", "换个问题再解读 · {cost} 积分", "換個問題再解讀 · {cost} 積分", "別の質問で新しく作成 · {cost} クレジット", "다른 질문으로 새 해석 · {cost} 크레딧", "Câu hỏi khác, luận giải mới · {cost} điểm", "คำถามใหม่ คำอธิบายใหม่ · {cost} เครดิต");

const growthText = {
  streaming: L("Writing your reading… it appears here as it is written.", "正在生成，内容会陆续显示在这里…", "正在產生，內容會陸續顯示在這裡…", "作成中です。書き上がった部分から表示されます…", "작성 중입니다. 작성되는 대로 여기에 표시됩니다…", "Đang viết bài luận giải… nội dung sẽ hiện dần tại đây.", "กำลังเขียนคำอธิบาย… เนื้อหาจะแสดงที่นี่ทีละส่วน"),
  inviteTitle: L("Invite a friend", "邀请好友一起看", "邀請好友一起看", "友だちを招待", "친구 초대하기", "Mời bạn bè", "ชวนเพื่อน"),
  inviteLead: L("When a friend joins with your link and makes a first purchase, you and your friend each receive {n} credits.", "好友通过你的链接注册，首次购买后，你和好友各得 {n} 积分。", "好友透過你的連結註冊，首次購買後，你和好友各得 {n} 積分。", "あなたのリンクから登録した友だちが初めて購入すると、あなたと友だちにそれぞれ {n} クレジット。", "친구가 내 링크로 가입해 첫 구매를 하면 나와 친구가 각각 {n} 크레딧을 받습니다.", "Khi bạn bè đăng ký qua liên kết của bạn và mua lần đầu, cả hai mỗi người nhận {n} điểm.", "เมื่อเพื่อนสมัครผ่านลิงก์ของคุณและซื้อครั้งแรก คุณและเพื่อนได้รับคนละ {n} เครดิต"),
  copyLink: L("Copy invite link", "复制邀请链接", "複製邀請連結", "招待リンクをコピー", "초대 링크 복사", "Sao chép liên kết mời", "คัดลอกลิงก์เชิญ"),
  copied: L("Copied", "已复制", "已複製", "コピーしました", "복사됨", "Đã sao chép", "คัดลอกแล้ว"),
  showAll: L("Show all ({n})", "显示全部（{n}）", "顯示全部（{n}）", "すべて表示（{n}）", "모두 보기({n})", "Xem tất cả ({n})", "ดูทั้งหมด ({n})"),
  showLess: L("Show recent only", "只看最近", "只看最近", "最近のみ表示", "최근만 보기", "Chỉ xem gần đây", "ดูเฉพาะล่าสุด"),
  remove: L("Remove", "移除", "移除", "削除", "삭제", "Xóa", "ลบ"),
  removeHint: L("Removed from the list. Credits are not affected.", "已从列表移除，不影响积分。", "已從列表移除，不影響積分。", "一覧から削除しました。クレジットには影響しません。", "목록에서 삭제했습니다. 크레딧에는 영향이 없습니다.", "Đã xóa khỏi danh sách. Không ảnh hưởng đến điểm.", "ลบออกจากรายการแล้ว ไม่กระทบเครดิต"),
  clearAll: L("Clear the list", "清空记录", "清空紀錄", "一覧を空にする", "기록 비우기", "Xóa danh sách", "ล้างรายการ"),
  confirmClear: L("Tap again to clear all", "再点一次确认清空", "再點一次確認清空", "もう一度押すとすべて削除", "한 번 더 누르면 모두 삭제", "Chạm lần nữa để xóa hết", "แตะอีกครั้งเพื่อล้างทั้งหมด"),
};
const invitationReward = 5;

function InviteCard({ locale, inviteCode }: { locale: Locale; inviteCode: string }) {
  const [copied, setCopied] = useState(false);
  const link = `https://xuannova.com/${locale === "en" ? "" : `${locale.toLowerCase()}`}?invite=${encodeURIComponent(inviteCode)}&utm_source=invite-link`;
  return <aside className="reading-invite" aria-label={growthText.inviteTitle[locale]}>
    <div><b>{growthText.inviteTitle[locale]}</b><p>{growthText.inviteLead[locale].replace("{n}", String(invitationReward))}</p></div>
    <button type="button" className="secondary-action" onClick={() => { void navigator.clipboard?.writeText(link).then(() => { setCopied(true); track("invite_copy", { from: "reading" }); window.setTimeout(() => setCopied(false), 2000); }).catch(() => undefined); }}>{copied ? growthText.copied[locale] : growthText.copyLink[locale]}</button>
  </aside>;
}

function FollowUpBlock({ items, locale, cost, previousQuestions, onPick }: { items: string[]; locale: Locale; cost: number; previousQuestions: string[]; onPick: (question: string) => void }) {
  const questions = selectFollowUps(items, { locale, previousQuestions });
  if (!questions.length) return null;
  return <section className="reading-followups" aria-labelledby="reading-followups-title">
    <h4 id="reading-followups-title">{moreText.title[locale]}</h4>
    <p>{moreText.lead[locale].replace("{cost}", String(cost))}</p>
    <div>{questions.map((item) => <button type="button" key={item} onClick={() => onPick(item)}><span>{item}</span><b aria-hidden="true">→</b></button>)}</div>
  </section>;
}

function AdvisorNote({ locale }: { locale: Locale }) {
  return <aside className="reading-advisor" aria-label={moreText.advisorEyebrow[locale]}>
    <small>{moreText.advisorEyebrow[locale]}</small>
    <p>{moreText.advisor[locale]}</p>
    <ContactIconRow />
    <span>{moreText.advisorNote[locale]}</span>
  </aside>;
}

type InterpretationCopy = {
  eyebrow: string; title: string; hint: string; ready: string; noAnswer: string; structured: string; conversation: string; conversationHint: string;
  signInRequired: string; insufficientCredits: string; working: string; serviceError: string; configurationError: string; providerBusyError: string; responseRetryError: string;
  freeAction: string; askAction: string; previewBadge: string; lockedTitle: string; lockedLead: string; signIn: string; unlock: string; unlocking: string; previewLimit: string;
  chartIncomplete: string; history: string; disclaimer: string; nextSteps: string; unlocked: string; conversationLocked: string; paidAction: string; freeUsed: string; freeUsedMember: string; freeUsedSignIn: string;
};

export const interpretationCopy: Record<Locale, InterpretationCopy> = {
  en: { eyebrow: "Reading report", title: "Your chart reading", hint: "Write the question you want this chart to address", ready: "The free first half starts right away. You can ask about something specific below.", noAnswer: "The chart is ready. Add a question to begin a reading.", structured: "Full report", conversation: "Conversation", conversationHint: "Ask follow-up questions in a dialogue. Each answer uses credits.", signInRequired: "Sign in to continue.", insufficientCredits: "Your balance is below the credits needed to unlock this reading.", working: "Writing your full reading… this usually takes about a minute.", serviceError: "The reading service is temporarily unavailable. Please try again shortly.", configurationError: "The reading service is being configured. Please try again later.", providerBusyError: "The reading service is busy. Please try again in a minute.", responseRetryError: "The reading took too long. Please try again.", freeAction: "Read the first part free", askAction: "Ask", previewBadge: "Free preview", lockedTitle: "The rest of this reading is locked", lockedLead: "Sign in and unlock the complete reading for {cost} credits. It opens instantly and is not regenerated.", signIn: "Sign in / register", unlock: "Unlock the full reading · {cost} credits", unlocking: "Unlocking…", previewLimit: "Today's free previews are used up. Sign in to unlock, or come back tomorrow.", chartIncomplete: "The chart is incomplete. Check the birth date, time and place, then generate the chart again.", history: "My readings", disclaimer: "Generated automatically by the Xuannova reading system from classical rules. For cultural learning and entertainment only.", nextSteps: "Explore next", unlocked: "Full reading unlocked", conversationLocked: "Conversation answers need a signed-in account with credits.", paidAction: "Get the full reading · {cost} credits", freeUsed: "You have used your free preview. Sign in to get full readings with credits.", freeUsedMember: "Your free preview has been used. A full reading costs {cost} credits.", freeUsedSignIn: "Sign in to continue" },
  "zh-Hans": { eyebrow: "解读报告", title: "你的命盘解读", hint: "写下你想让这张盘回答的问题", ready: "免费的前半部分会马上开始生成；想问具体的事，可以在下方提问。", noAnswer: "盘面已就绪；填写问题即可开始解读。", structured: "完整报告", conversation: "对话追问", conversationHint: "以对话方式继续追问，每次回答消耗积分。", signInRequired: "请先登录。", insufficientCredits: "当前积分不足以解锁这份解读。", working: "正在生成完整解读，通常需要 1 分钟左右…", serviceError: "解读服务暂时不可用，请稍后再试。", configurationError: "解读服务正在配置，请稍后再试。", providerBusyError: "解读服务繁忙，请一分钟后再试。", responseRetryError: "生成时间过长，请重试。", freeAction: "免费查看前半部分", askAction: "提问", previewBadge: "免费部分", lockedTitle: "后半部分已锁定", lockedLead: "登录后用 {cost} 积分解锁完整解读，立即打开，不会重新生成。", signIn: "登录 / 注册", unlock: "解锁完整解读 · {cost} 积分", unlocking: "正在解锁…", previewLimit: "今天的免费查看次数已用完，登录后可解锁，或明天再来。", chartIncomplete: "盘面信息不完整，请检查出生日期、时间和出生地后重新排盘。", history: "我的解读", disclaimer: "由 Xuannova 解读系统按典籍规则自动生成，仅供文化学习与娱乐参考。", nextSteps: "接下来可以看", unlocked: "已解锁完整解读", conversationLocked: "对话追问需要登录并有积分。", paidAction: "生成完整解读 · {cost} 积分", freeUsed: "免费半份解读已经用过了。登录后可用积分生成完整解读。", freeUsedMember: "免费半份解读已用过，完整解读需要 {cost} 积分。", freeUsedSignIn: "登录后继续" },
  "zh-Hant": { eyebrow: "解讀報告", title: "你的命盤解讀", hint: "寫下你想讓這張盤回答的問題", ready: "免費的前半部分會馬上開始產生；想問具體的事，可以在下方提問。", noAnswer: "盤面已就緒；填寫問題即可開始解讀。", structured: "完整報告", conversation: "對話追問", conversationHint: "以對話方式繼續追問，每次回答消耗積分。", signInRequired: "請先登入。", insufficientCredits: "目前積分不足以解鎖這份解讀。", working: "正在產生完整解讀，通常需要 1 分鐘左右…", serviceError: "解讀服務暫時無法使用，請稍後再試。", configurationError: "解讀服務正在設定，請稍後再試。", providerBusyError: "解讀服務繁忙，請一分鐘後再試。", responseRetryError: "產生時間過長，請重試。", freeAction: "免費查看前半部分", askAction: "提問", previewBadge: "免費部分", lockedTitle: "後半部分已鎖定", lockedLead: "登入後用 {cost} 積分解鎖完整解讀，立即開啟，不會重新產生。", signIn: "登入 / 註冊", unlock: "解鎖完整解讀 · {cost} 積分", unlocking: "正在解鎖…", previewLimit: "今天的免費查看次數已用完，登入後可解鎖，或明天再來。", chartIncomplete: "盤面資訊不完整，請檢查出生日期、時間和出生地後重新排盤。", history: "我的解讀", disclaimer: "由 Xuannova 解讀系統按典籍規則自動產生，僅供文化學習與娛樂參考。", nextSteps: "接下來可以看", unlocked: "已解鎖完整解讀", conversationLocked: "對話追問需要登入並有積分。", paidAction: "產生完整解讀 · {cost} 積分", freeUsed: "免費半份解讀已經用過了。登入後可用積分產生完整解讀。", freeUsedMember: "免費半份解讀已用過，完整解讀需要 {cost} 積分。", freeUsedSignIn: "登入後繼續" },
  ja: { eyebrow: "鑑定レポート", title: "あなたの盤の解説", hint: "この盤で確かめたい質問を書いてください", ready: "無料の前半をすぐに作成します。具体的に聞きたいことは下で質問できます。", noAnswer: "盤面の準備ができました。質問を入力して始めましょう。", structured: "完全レポート", conversation: "対話で質問", conversationHint: "対話形式で追加の質問ができます。回答ごとにクレジットを使います。", signInRequired: "続けるにはログインしてください。", insufficientCredits: "このレポートを解除するにはクレジットが足りません。", working: "レポートを作成しています。通常1分ほどかかります…", serviceError: "現在レポートを作成できません。しばらくしてからお試しください。", configurationError: "サービスを設定中です。後ほどお試しください。", providerBusyError: "混み合っています。1分ほどしてからお試しください。", responseRetryError: "時間がかかりすぎました。もう一度お試しください。", freeAction: "前半を無料で読む", askAction: "質問する", previewBadge: "無料部分", lockedTitle: "後半はロックされています", lockedLead: "ログインして {cost} クレジットで全文を解除できます。すぐに開き、作り直すことはありません。", signIn: "ログイン / 登録", unlock: "全文を解除 · {cost} クレジット", unlocking: "解除しています…", previewLimit: "本日の無料閲覧回数を使い切りました。ログインして解除するか、明日またお越しください。", chartIncomplete: "盤面の情報が不足しています。生年月日・時刻・出生地を確認して作り直してください。", history: "私のレポート", disclaimer: "Xuannova の鑑定システムが古典の規則に基づいて自動作成しています。文化学習と娯楽の参考としてお使いください。", nextSteps: "次に見る", unlocked: "全文を解除しました", conversationLocked: "対話での質問にはログインとクレジットが必要です。", paidAction: "完全な解説を作成 · {cost} クレジット", freeUsed: "無料の前半プレビューは使用済みです。サインインするとクレジットで完全な解説を作成できます。", freeUsedMember: "無料プレビューは使用済みです。完全な解説は {cost} クレジットです。", freeUsedSignIn: "サインインして続ける" },
  ko: { eyebrow: "해석 보고서", title: "나의 판면 해설", hint: "이 판면으로 알고 싶은 질문을 적어 주세요", ready: "무료 앞부분을 바로 만듭니다. 구체적으로 묻고 싶은 것은 아래에서 질문하세요.", noAnswer: "판면이 준비되었습니다. 질문을 입력해 시작하세요.", structured: "전체 보고서", conversation: "대화로 질문", conversationHint: "대화 형식으로 추가 질문을 할 수 있으며, 답변마다 크레딧이 사용됩니다.", signInRequired: "계속하려면 로그인하세요.", insufficientCredits: "이 해석을 열기에 크레딧이 부족합니다.", working: "전체 해석을 만드는 중입니다. 보통 1분 정도 걸립니다…", serviceError: "지금은 해석을 만들 수 없습니다. 잠시 후 다시 시도하세요.", configurationError: "서비스를 설정하는 중입니다. 나중에 다시 시도하세요.", providerBusyError: "요청이 많습니다. 1분 후 다시 시도하세요.", responseRetryError: "시간이 너무 오래 걸렸습니다. 다시 시도하세요.", freeAction: "앞부분 무료로 보기", askAction: "질문하기", previewBadge: "무료 부분", lockedTitle: "나머지 부분은 잠겨 있습니다", lockedLead: "로그인 후 {cost} 크레딧으로 전체 해석을 열 수 있습니다. 바로 열리며 다시 생성하지 않습니다.", signIn: "로그인 / 가입", unlock: "전체 해석 열기 · {cost} 크레딧", unlocking: "여는 중…", previewLimit: "오늘의 무료 보기 횟수를 모두 사용했습니다. 로그인해 열거나 내일 다시 오세요.", chartIncomplete: "판면 정보가 부족합니다. 생년월일, 시간, 출생지를 확인한 뒤 다시 만드세요.", history: "내 해석", disclaimer: "Xuannova 해석 시스템이 고전 규칙에 따라 자동으로 만든 내용이며, 문화 학습과 오락 참고용입니다.", nextSteps: "다음에 볼 것", unlocked: "전체 해석이 열렸습니다", conversationLocked: "대화 질문은 로그인과 크레딧이 필요합니다.", paidAction: "전체 해석 만들기 · {cost} 크레딧", freeUsed: "무료 미리보기를 이미 사용했습니다. 로그인하면 크레딧으로 전체 해석을 받을 수 있습니다.", freeUsedMember: "무료 미리보기를 사용했습니다. 전체 해석은 {cost} 크레딧입니다.", freeUsedSignIn: "로그인하고 계속" },
  vi: { eyebrow: "Báo cáo luận giải", title: "Bài giải lá số của bạn", hint: "Viết câu hỏi bạn muốn lá số này trả lời", ready: "Nửa đầu miễn phí sẽ được tạo ngay. Muốn hỏi việc cụ thể, hãy đặt câu hỏi bên dưới.", noAnswer: "Lá số đã sẵn sàng. Hãy nhập câu hỏi để bắt đầu.", structured: "Báo cáo đầy đủ", conversation: "Hỏi đáp", conversationHint: "Tiếp tục hỏi theo dạng hội thoại; mỗi câu trả lời dùng điểm.", signInRequired: "Vui lòng đăng nhập để tiếp tục.", insufficientCredits: "Số điểm hiện có chưa đủ để mở khóa bài này.", working: "Đang tạo bài luận giải đầy đủ, thường mất khoảng một phút…", serviceError: "Dịch vụ luận giải tạm thời không khả dụng. Vui lòng thử lại sau.", configurationError: "Dịch vụ đang được cấu hình. Vui lòng thử lại sau.", providerBusyError: "Dịch vụ đang bận. Vui lòng thử lại sau một phút.", responseRetryError: "Thời gian tạo quá lâu. Vui lòng thử lại.", freeAction: "Xem miễn phí phần đầu", askAction: "Đặt câu hỏi", previewBadge: "Phần miễn phí", lockedTitle: "Phần còn lại đang bị khóa", lockedLead: "Đăng nhập và mở khóa toàn bộ bài với {cost} điểm. Mở ngay, không tạo lại.", signIn: "Đăng nhập / Đăng ký", unlock: "Mở khóa toàn bộ · {cost} điểm", unlocking: "Đang mở khóa…", previewLimit: "Lượt xem miễn phí hôm nay đã hết. Hãy đăng nhập để mở khóa hoặc quay lại vào ngày mai.", chartIncomplete: "Thông tin lá số chưa đủ. Hãy kiểm tra ngày, giờ và nơi sinh rồi lập lại.", history: "Bài của tôi", disclaimer: "Do hệ thống luận giải Xuannova tự động tạo theo quy tắc kinh điển, chỉ dùng để học hỏi văn hóa và giải trí.", nextSteps: "Xem tiếp", unlocked: "Đã mở khóa toàn bộ", conversationLocked: "Hỏi đáp cần đăng nhập và có điểm.", paidAction: "Tạo bài giải đầy đủ · {cost} điểm", freeUsed: "Bạn đã dùng lượt xem miễn phí. Đăng nhập để dùng điểm nhận bài giải đầy đủ.", freeUsedMember: "Lượt xem miễn phí đã dùng. Bài giải đầy đủ cần {cost} điểm.", freeUsedSignIn: "Đăng nhập để tiếp tục" },
  th: { eyebrow: "รายงานคำอธิบาย", title: "คำอธิบายผังของคุณ", hint: "เขียนคำถามที่อยากให้ผังนี้ตอบ", ready: "ครึ่งแรกฟรีจะเริ่มสร้างทันที หากอยากถามเรื่องเจาะจง ถามได้ด้านล่าง", noAnswer: "ผังพร้อมแล้ว กรอกคำถามเพื่อเริ่มต้น", structured: "รายงานฉบับเต็ม", conversation: "ถามต่อแบบสนทนา", conversationHint: "ถามต่อแบบสนทนาได้ แต่ละคำตอบจะใช้คะแนน", signInRequired: "โปรดเข้าสู่ระบบเพื่อดำเนินการต่อ", insufficientCredits: "คะแนนไม่พอสำหรับปลดล็อกคำอธิบายนี้", working: "กำลังสร้างคำอธิบายฉบับเต็ม โดยปกติใช้เวลาประมาณหนึ่งนาที…", serviceError: "บริการคำอธิบายไม่พร้อมใช้งานชั่วคราว โปรดลองอีกครั้งภายหลัง", configurationError: "กำลังตั้งค่าบริการ โปรดลองอีกครั้งภายหลัง", providerBusyError: "บริการมีผู้ใช้มาก โปรดลองอีกครั้งในอีกหนึ่งนาที", responseRetryError: "ใช้เวลานานเกินไป โปรดลองอีกครั้ง", freeAction: "อ่านส่วนแรกฟรี", askAction: "ถาม", previewBadge: "ส่วนที่อ่านฟรี", lockedTitle: "ส่วนที่เหลือถูกล็อกไว้", lockedLead: "เข้าสู่ระบบแล้วปลดล็อกฉบับเต็มด้วย {cost} คะแนน เปิดได้ทันทีโดยไม่สร้างใหม่", signIn: "เข้าสู่ระบบ / สมัคร", unlock: "ปลดล็อกฉบับเต็ม · {cost} คะแนน", unlocking: "กำลังปลดล็อก…", previewLimit: "สิทธิ์อ่านฟรีวันนี้หมดแล้ว เข้าสู่ระบบเพื่อปลดล็อก หรือกลับมาพรุ่งนี้", chartIncomplete: "ข้อมูลผังไม่ครบ โปรดตรวจสอบวัน เวลา และสถานที่เกิด แล้วสร้างผังใหม่", history: "คำอธิบายของฉัน", disclaimer: "สร้างโดยอัตโนมัติจากระบบคำอธิบายของ Xuannova ตามกฎตำราดั้งเดิม เพื่อการเรียนรู้วัฒนธรรมและความบันเทิงเท่านั้น", nextSteps: "ดูต่อ", unlocked: "ปลดล็อกฉบับเต็มแล้ว", conversationLocked: "การถามต่อแบบสนทนาต้องเข้าสู่ระบบและมีคะแนน", paidAction: "สร้างคำอธิบายฉบับเต็ม · {cost} เครดิต", freeUsed: "คุณใช้สิทธิ์ดูตัวอย่างฟรีไปแล้ว เข้าสู่ระบบเพื่อใช้เครดิตรับคำอธิบายฉบับเต็ม", freeUsedMember: "ใช้สิทธิ์ดูฟรีแล้ว คำอธิบายฉบับเต็มใช้ {cost} เครดิต", freeUsedSignIn: "เข้าสู่ระบบเพื่อดำเนินการต่อ" },
};

type Mode = "structured" | "conversation";
type SavedReading = { id: string; question: string; response: InterpretationResponse; createdAt: string; tool?: string; locale?: string };
const languageName: Record<string, string> = { en: "English", "zh-Hans": "简体中文", "zh-Hant": "繁體中文", ja: "日本語", ko: "한국어", vi: "Tiếng Việt", th: "ไทย" };
type Draft = { draftId: string; question: string; chartFingerprint: string; preview: InterpretationResponse; lockedSections: string[]; unlocked: boolean; full?: InterpretationResponse };
const draftStorageKey = "xuannova:reading-draft";
const freeUsedKey = "xuannova:free-preview-used";

function serviceMessage(code: string | undefined, text: InterpretationCopy) {
  if (code === "QUESTION_REQUIRED") return text.noAnswer;
  if (code === "CHART_INCOMPLETE") return text.chartIncomplete;
  if (code === "PREVIEW_LIMIT") return text.previewLimit;
  if (code === "AI_NOT_CONFIGURED" || code === "AI_AUTH_FAILED" || code === "AI_REQUEST_REJECTED") return text.configurationError;
  if (code === "AI_RATE_LIMITED") return text.providerBusyError;
  if (code === "AI_INVALID_RESPONSE" || code === "AI_TIMEOUT") return text.responseRetryError;
  return text.serviceError;
}

function readStoredDraft(fingerprint: string): Draft | null {
  try {
    const raw = window.sessionStorage.getItem(draftStorageKey);
    const draft = raw ? JSON.parse(raw) as Draft : null;
    return draft && draft.chartFingerprint === fingerprint ? draft : null;
  } catch { return null; }
}
function storeDraft(draft: Draft | null) {
  try {
    if (draft) window.sessionStorage.setItem(draftStorageKey, JSON.stringify(draft));
    else window.sessionStorage.removeItem(draftStorageKey);
  } catch { /* storage is optional */ }
}

/** Text with glossary terms marked: hover or tap a term to see a one-line explanation. */
function WithTerms({ text, locale }: { text: string; locale: Locale }) {
  // Each term (first mention) can be tapped for an explanation; in 普通版 a short plain note follows it.
  return <>{splitTerms(text, locale).map((part, index) => typeof part === "string" ? part : <ChartTerm key={index} raw={part.term} locale={locale} tip={part.tip} gloss={part.short ?? null}>{part.term}</ChartTerm>)}</>;
}

const keyPointsTitle: Record<Locale, string> = { en: "Three key points", "zh-Hans": "三个重点", "zh-Hant": "三個重點", ja: "三つの要点", ko: "핵심 세 가지", vi: "Ba điểm chính", th: "สามประเด็นสำคัญ" };
/** The opening phrase of a key point (up to the first comma or colon), shown in bold so the gist reads at a glance. */
function splitLead(text: string): [string, string] {
  const match = /^(.{2,26}?[：:，,。．.；;])\s*/.exec(text);
  return match && match[1].length < text.length - 4 ? [match[1], text.slice(match[0].length)] : ["", text];
}

function ReadingBody({ response, locale }: { response: InterpretationResponse; locale: Locale }) {
  return <>
    <ReadingModeToggle locale={locale} inReading />
    {response.conclusion ? <h3 className="reading-conclusion">{response.conclusion}</h3> : <h3>{response.summary}</h3>}
    {response.keyPoints && response.keyPoints.length > 0 && <section className="reading-key-block" aria-label={keyPointsTitle[locale]}>
      <h4><span aria-hidden="true">✦</span>{keyPointsTitle[locale]}</h4>
      <ul className="reading-key-points">{response.keyPoints.map((point, index) => { const [lead, rest] = splitLead(point); return <li key={index}><b className="kp-num">{index + 1}</b><p>{lead && <strong><WithTerms text={lead} locale={locale} /></strong>}<WithTerms text={rest} locale={locale} /></p></li>; })}</ul>
    </section>}
    {response.conclusion && <p className="reading-summary"><WithTerms text={response.summary} locale={locale} /></p>}
    <div>{response.sections.map((section) => <section key={section.title}><b>{section.title}</b>{section.text.split(/\n+/).filter((paragraph) => paragraph.trim()).map((paragraph, index) => <p key={index}><WithTerms text={paragraph.trim()} locale={locale} /></p>)}</section>)}</div>
  </>;
}

const defaultReportQuestion: Record<Locale, string> = {
  en: "Give an overall reading of this chart: character, strengths, current timing and what to keep in mind.",
  "zh-Hans": "请对这张盘做整体解读：性格特点、优势、当前时运与需要留意之处。",
  "zh-Hant": "請對這張盤做整體解讀：性格特點、優勢、當前時運與需要留意之處。",
  ja: "この盤を総合的に読んでください：性格、強み、今の流れ、気をつけたい点。",
  ko: "이 판을 종합적으로 읽어 주세요: 성격, 강점, 현재의 흐름, 유의할 점.",
  vi: "Hãy luận giải tổng quan lá số này: tính cách, điểm mạnh, vận hiện tại và điều cần lưu ý.",
  th: "ช่วยอ่านผังนี้แบบภาพรวม: นิสัย จุดแข็ง จังหวะเวลาตอนนี้ และสิ่งที่ควรระวัง",
};

export function InterpretationPanel({ chart, locale, wallet, onSpend, onOpenMembership, onNavigate, autoStart = false }: { autoStart?: boolean; chart: CompleteChart; locale: Locale; wallet: CreditWallet; onSpend: (tool: string) => boolean; onOpenMembership: () => void; onNavigate?: (route: string) => void }) {
  void wallet; void onSpend;
  const text = interpretationCopy[locale];
  const walletText = creditCopy(locale);
  const [question, setQuestion] = useState(chart.inputSummary.focus?.trim() ?? "");
  const [response, setResponse] = useState<InterpretationResponse | null>(null);
  const [blocked, setBlocked] = useState(false);
  const [blockMessage, setBlockMessage] = useState("");
  const [mode, setMode] = useState<Mode>("structured");
  const [balance, setBalance] = useState<number | null>(null);
  const [signedIn, setSignedIn] = useState(false);
  const [inviteCode, setInviteCode] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [needsMembership, setNeedsMembership] = useState(false);
  const [history, setHistory] = useState<SavedReading[]>([]);
  const [historyAll, setHistoryAll] = useState(false);
  const [historyNote, setHistoryNote] = useState("");
  const [confirmClear, setConfirmClear] = useState(false);
  const [streaming, setStreaming] = useState<InterpretationResponse | null>(null);
  const [draft, setDraft] = useState<Draft | null>(null);
  // The free half reading is offered once; the server decides, this only picks the right button label.
  const [freeUsed, setFreeUsed] = useState(false);
  // Members' daily free full reading (default: 八字排盘). `freeFullTool` = this tool is on the free list.
  const [freeFull, setFreeFull] = useState<{ tools: string[]; available: boolean }>({ tools: [], available: false });
  const [conversationContext, setConversationContext] = useState<FollowUpContext>({ chartFingerprint: "", turns: [] });
  const request = createInterpretationRequest({ tool: chart.tool, locale, question, chart });
  // 普通版 readings are written in everyday language; 专业版 keeps full terminology (the same switch as the chart board).
  const readingStyle = useReadingMode() === "beginner" ? "plain" : "expert";
  const chartFingerprint = JSON.stringify(request.chart);
  // Full reports: 40 credits for the BaZi deep reading, otherwise 20; follow-up answers are always 20.
  const reportCost = interpretationCost(chart.tool);
  const followUpCost = interpretationCost("");
  const cost = mode === "conversation" ? followUpCost : reportCost;
  const freeFullTool = freeFull.tools.includes(chart.tool);
  const freeFullNow = freeFullTool && freeFull.available && signedIn && mode === "structured";
  const questionEmpty = question.trim().length === 0;
  // A visitor who has no question yet still gets an overall report; only conversation mode needs one.
  const reportQuestion = questionEmpty ? defaultReportQuestion[locale] : question.trim();
  const insufficientBalance = balance !== null && balance < cost;
  const fill = (value: string) => value.replace("{cost}", String(cost));
  const shareRoute = chart.tool.startsWith("toolkit-") ? "toolkit" : chart.tool;

  const refreshBalance = useCallback(async () => {
    try {
      const result = await fetch("/api/member/me?soft=1", { method: "GET", credentials: "same-origin" });
      const payload = result.ok ? await result.json() as { member?: { balance?: number; inviteCode?: string | null } | null } : null;
      announceGrowth(payload);
      if (!payload?.member) { setBalance(null); setSignedIn(false); setInviteCode(null); return; }
      setInviteCode(payload.member.inviteCode ?? null);
      setSignedIn(true);
      setBalance(typeof payload.member?.balance === "number" ? payload.member.balance : null);
    } catch { setBalance(null); }
  }, []);
  // The free first half is available every time; the server only says "no" when the daily safety limit is reached.
  const refreshFreeStatus = useCallback(async () => {
    try {
      const result = await fetch("/api/readings/free-status", { credentials: "same-origin", cache: "no-store" });
      if (!result.ok) return;
      const status = await result.json() as { free?: boolean; freeFull?: { tools: string[]; available: boolean } };
      if (typeof status.free === "boolean") {
        setFreeUsed(!status.free);
      }
      if (status.freeFull) setFreeFull(status.freeFull);
    } catch { /* keep the stored flag */ }
  }, []);
  const refreshHistory = useCallback(async () => {
    try {
      const result = await fetch("/api/member/interpretations", { credentials: "same-origin" });
      if (!result.ok) return;
      const payload = await result.json() as { interpretations?: SavedReading[] };
      setHistory(Array.isArray(payload.interpretations) ? payload.interpretations : []);
    } catch { /* History is optional; keep the reading flow available. */ }
  }, []);

  useEffect(() => {
    const initial = window.setTimeout(() => {
      void refreshBalance();
      void refreshHistory();
      // Coming back from sign-in or the credits page: restore the same free preview for this chart.
      // The free first half is offered every time; clear the old "used once" flag from earlier versions.
      setFreeUsed(false);
      try { window.localStorage.removeItem(freeUsedKey); } catch { /* storage unavailable */ }
      void refreshFreeStatus();
      const stored = readStoredDraft(chartFingerprint);
      if (stored) { setDraft(stored); setQuestion(stored.question); }
    }, 0);
    const refreshOnFocus = () => { void refreshBalance(); void refreshFreeStatus(); };
    // Signing in or out (e.g. a new account) changes whether the free half is still available.
    window.addEventListener("xuannova:member", refreshOnFocus);
    window.addEventListener("focus", refreshOnFocus);
    return () => { window.clearTimeout(initial); window.removeEventListener("focus", refreshOnFocus); window.removeEventListener("xuannova:member", refreshOnFocus); };
  }, [refreshBalance, refreshHistory, refreshFreeStatus, chartFingerprint]);

  const fail = (code: string | undefined, status: number) => {
    setBlocked(true);
    setNeedsMembership(status === 402);
    setBlockMessage(status === 401 ? text.signInRequired : status === 402 ? text.insufficientCredits : serviceMessage(code, text));
  };

  /** Structured report: one free first half per device/account; after that a full reading for credits. */
  const requestPreview = async (pay = false) => {
    if (pay && !signedIn) { onOpenMembership(); return; }
    setBusy(true); setBlocked(false); setNeedsMembership(false); setBlockMessage("");
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 150_000);
    try {
      const result = await fetch("/api/readings/preview", { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify({ tool: chart.tool, locale, question: reportQuestion, chart: request.chart, pay, stream: true, style: readingStyle }), signal: controller.signal });
      type PreviewPayload = { code?: string; draftId?: string; preview?: InterpretationResponse; lockedSections?: string[]; unlocked?: boolean; freeFull?: boolean; response?: InterpretationResponse; member?: { balance: number }; signedIn?: boolean };
      let status = result.status;
      let payload: PreviewPayload = {};
      if ((result.headers.get("content-type") ?? "").includes("text/event-stream") && result.body) {
        // Streamed reading: show the parts already written, then handle the final result as usual.
        const reader = result.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        let finished = false;
        while (!finished) {
          const { value, done } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          let split: number;
          while ((split = buffer.indexOf("\n\n")) >= 0) {
            const block = buffer.slice(0, split); buffer = buffer.slice(split + 2);
            const data = block.split("\n").filter((line) => line.startsWith("data:")).map((line) => line.slice(5).trim()).join("");
            if (!data) continue;
            try {
              const event = JSON.parse(data) as { type: string; reading?: Partial<InterpretationResponse>; status?: number; body?: PreviewPayload };
              if (event.type === "partial" && event.reading) setStreaming({ title: "", summary: "", followUps: [], ...event.reading, sections: event.reading.sections ?? [] });
              if (event.type === "done") { status = event.status ?? 502; payload = event.body ?? {}; finished = true; }
            } catch { /* ignore a malformed event */ }
          }
        }
        if (!finished) { status = 502; payload = { code: "AI_UNAVAILABLE" }; }
      } else {
        payload = await result.json() as PreviewPayload;
      }
      setStreaming(null);
      if (payload.code === "FREE_PREVIEW_USED") {
        setFreeUsed(true); setBlocked(true);
        setNeedsMembership(!payload.signedIn);
        setBlockMessage(payload.signedIn ? fill(text.freeUsedMember) : text.freeUsed);
        if (payload.signedIn) setSignedIn(true);
        return;
      }
      if (payload.unlocked && payload.response && payload.draftId) {
        track(payload.freeFull ? "reading_free_full" : "reading_paid", { tool: chart.tool });
        if (payload.freeFull) setFreeFull((current) => ({ ...current, available: false }));
        const full: Draft = { draftId: payload.draftId, question: reportQuestion, chartFingerprint, preview: payload.response, full: payload.response, lockedSections: [], unlocked: true };
        setDraft(full); storeDraft(null); setResponse(null);
        if (payload.member) setBalance(payload.member.balance);
        void refreshHistory();
        return;
      }
      if (status >= 400 || !payload.draftId || !payload.preview) { fail(payload.code, status); if (status === 402) await refreshBalance(); return; }
      track("reading_preview", { tool: chart.tool });
      const next: Draft = { draftId: payload.draftId, question: reportQuestion, chartFingerprint, preview: payload.preview, lockedSections: payload.lockedSections ?? [], unlocked: false };
      setDraft(next); storeDraft(next); setResponse(null);
    } catch {
      setBlocked(true); setBlockMessage(controller.signal.aborted ? text.responseRetryError : text.serviceError);
    } finally { window.clearTimeout(timeout); setBusy(false); setStreaming(null); }
  };

  // One click from the chart: the free first half starts right away (no question needed).
  const autoStarted = useRef(false);
  const startPreview = useRef(requestPreview);
  useEffect(() => { startPreview.current = requestPreview; });
  useEffect(() => {
    if (!autoStart) return;
    const timer = window.setTimeout(() => {
      if (autoStarted.current) return;
      autoStarted.current = true;
      if (!readStoredDraft(chartFingerprint)) void startPreview.current(false);
    }, 0);
    return () => window.clearTimeout(timer);
  }, [autoStart, chartFingerprint]);

  const hideHistory = async (id: string | null) => {
    try {
      const result = await fetch(id ? `/api/member/interpretations/${id}/hide` : "/api/member/interpretations/hide-all", { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: "{}" });
      if (!result.ok) return;
      setHistory((items) => (id ? items.filter((item) => item.id !== id) : []));
      setHistoryNote(growthText.removeHint[locale]); setConfirmClear(false);
      window.setTimeout(() => setHistoryNote(""), 2500);
    } catch { /* keep the list */ }
  };

  // A suggested question goes into the box in follow-up mode; the reader still presses Ask (no charge on a single tap).
  const pickFollowUp = (item: string) => {
    setMode("conversation"); setQuestion(item);
    window.setTimeout(() => {
      const box = document.getElementById("reading-question") as HTMLTextAreaElement | null;
      box?.scrollIntoView({ behavior: "smooth", block: "center" });
      box?.focus({ preventScroll: true });
    }, 50);
  };

  const unlock = async () => {
    // Signed in on a free tool with today's free full reading still available: get it free instead of paying.
    if (freeFullNow) { await requestPreview(false); return; }
    if (!draft) return;
    track("reading_unlock", { tool: chart.tool, signedIn: signedIn ? 1 : 0 });
    if (!signedIn) { storeDraft(draft); onOpenMembership(); return; }
    setBusy(true); setBlocked(false);
    try {
      const result = await fetch("/api/readings/unlock", { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify({ draftId: draft.draftId }) });
      const payload = await result.json() as { code?: string; response?: InterpretationResponse; member?: { balance: number }; interpretation?: SavedReading };
      if (!result.ok || !payload.response) {
        if (result.status === 401) { setSignedIn(false); storeDraft(draft); onOpenMembership(); return; }
        if (result.status === 402) await refreshBalance();
        fail(payload.code, result.status); return;
      }
      const next = { ...draft, unlocked: true, full: payload.response };
      setDraft(next); storeDraft(next);
      if (payload.member) setBalance(payload.member.balance);
      if (payload.interpretation) setHistory((items) => [payload.interpretation!, ...items.filter((item) => item.id !== payload.interpretation!.id)]);
    } catch { setBlocked(true); setBlockMessage(text.serviceError); } finally { setBusy(false); }
  };

  /** Conversation follow-ups are paid answers for signed-in members. */
  const interpretStudy = async () => {
    if (question.trim().length === 0) {
      setBusy(false); setBlocked(true); setResponse(null); setNeedsMembership(false); setBlockMessage(serviceMessage("QUESTION_REQUIRED", text));
      return;
    }
    setBusy(true); setBlocked(false); setNeedsMembership(false); setBlockMessage("");
    const controller = new AbortController();
    const requestTimeout = window.setTimeout(() => controller.abort(), 150_000);
    try {
      const currentTurns = followUpHistory(chartFingerprint, conversationContext, draft);
      const result = await fetch("/api/interpretations", { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify({ tool: chart.tool, locale, question, mode, style: readingStyle, chart: request.chart, ...(mode === "conversation" && currentTurns.length ? { conversationHistory: currentTurns } : {}) }), signal: controller.signal });
      const payload = await result.json() as { code?: string; member?: { balance: number }; response?: InterpretationResponse; interpretation?: SavedReading };
      if (!result.ok || !payload.response) {
        setResponse(null);
        if (result.status === 402) await refreshBalance();
        fail(payload.code, result.status);
        return;
      }
      setBalance(payload.member?.balance ?? null);
      setResponse(payload.response);
      if (mode === "conversation") {
        const answer = summarizeReading(payload.response);
        const draftId = draft?.chartFingerprint === chartFingerprint && draft.unlocked && draft.full ? draft.draftId : undefined;
        setConversationContext({ chartFingerprint, draftId, turns: [...currentTurns, { question: question.trim(), answer }].slice(-10) });
      }
      if (payload.interpretation) setHistory((items) => [payload.interpretation!, ...items.filter((item) => item.id !== payload.interpretation!.id)]);
      setQuestion("");
    } catch {
      setBlocked(true); setResponse(null); setNeedsMembership(false); setBlockMessage(controller.signal.aborted ? text.responseRetryError : text.serviceError);
    } finally { window.clearTimeout(requestTimeout); setBusy(false); }
  };

  const nextRoutes = nextStepRoutes(chart.tool);
  const shownDraft = draft && draft.chartFingerprint === chartFingerprint ? draft : null;
  const previousQuestions = followUpHistory(chartFingerprint, conversationContext, draft).map((turn) => turn.question);
  const hasReading = Boolean(shownDraft || response);
  const controls = <>
    <div className="reading-mode-switch" role="tablist" aria-label={text.title}><button type="button" role="tab" aria-selected={mode === "structured"} className={mode === "structured" ? "active" : ""} onClick={() => setMode("structured")}>{text.structured}</button><button type="button" role="tab" aria-selected={mode === "conversation"} className={mode === "conversation" ? "active" : ""} onClick={() => setMode("conversation")}>{text.conversation}</button></div>
    {mode === "conversation" && <p className="conversation-hint">{signedIn ? text.conversationHint : text.conversationLocked}</p>}
    <textarea id="reading-question" value={question} onChange={(event) => setQuestion(event.target.value)} placeholder={text.hint} aria-label={text.hint} />
    {mode === "conversation" && questionEmpty && <p className="interpretation-empty" role="status">{text.noAnswer}</p>}
    {mode === "conversation" && insufficientBalance && <aside className="interpretation-credit-block" role="status"><p>{text.insufficientCredits}</p><button type="button" className="secondary-action" onClick={onOpenMembership}>{walletText.viewMembership}<b>↗</b></button></aside>}
    {mode === "structured"
      ? (shownDraft && !shownDraft.unlocked && reportQuestion === shownDraft.question ? null : <button type="button" className={shownDraft?.unlocked ? "secondary-action" : "primary-action"} onClick={() => void requestPreview(freeUsed)} disabled={busy || Boolean(shownDraft?.unlocked && reportQuestion === shownDraft.question)} title={shownDraft?.unlocked && reportQuestion === shownDraft.question ? sameQuestion[locale] : undefined}>{busy ? text.working : freeFullNow ? trustText.freeFullAction[locale] : !freeUsed ? text.freeAction : signedIn ? fill(shownDraft?.unlocked ? anotherReading[locale] : text.paidAction) : text.freeUsedSignIn}<b>↗</b></button>)
      : <>{signedIn && <CostLine locale={locale} cost={followUpCost} balance={balance} />}<button type="button" className="primary-action" onClick={() => signedIn ? void interpretStudy() : onOpenMembership()} disabled={busy || questionEmpty || insufficientBalance}>{busy ? text.working : signedIn ? `${text.askAction} · ${cost} ${walletText.credits}` : text.signIn}<b>↗</b></button></>}
  </>;
  return <section className="interpretation-panel" aria-label={text.title} data-testid="interpretation-panel">
    <header><span>{text.eyebrow}</span><h2>{text.title}</h2><p>{text.ready}</p></header>
    <aside className="interpretation-credit-status"><span>{walletText.cost}</span><b>{freeFullNow ? trustText.freeToday[locale] : `${cost} ${walletText.credits}`}</b><p>{walletText.available}: <strong>{balance ?? "—"} {walletText.credits}</strong></p></aside>
    {!hasReading && !(busy && streaming) && controls}
    {!hasReading && !(busy && streaming) && <p className="sample-report-link"><SampleReportButton locale={locale} className="text-action" /></p>}
    {blocked && <aside className="interpretation-credit-block" role="status"><p>{blockMessage}</p>{needsMembership && <button type="button" className="secondary-action" onClick={onOpenMembership}>{walletText.viewMembership}<b>↗</b></button>}</aside>}
    {history.length > 0 && <details className="interpretation-history"><summary>{text.history} <small>({history.length})</small><b>+</b></summary><div>
      {(historyAll ? history : history.slice(0, 5)).map((item) => <div className="history-row" key={item.id}>
        <button type="button" onClick={() => { setMode("structured"); setDraft(null); setResponse(item.response); }}><small>{new Date(item.createdAt).toLocaleString(locale)}{item.tool ? ` · ${titleForRoute((item.tool.startsWith("toolkit-") ? "toolkit" : item.tool) as AppRoute, locale) ?? item.tool}` : ""}{item.locale && item.locale !== locale ? ` · ${languageName[item.locale] ?? item.locale}` : ""}</small><b>{item.question}</b></button>
        <button type="button" className="history-remove" aria-label={`${growthText.remove[locale]}: ${item.question}`} title={growthText.remove[locale]} onClick={() => void hideHistory(item.id)}>×</button>
      </div>)}
      <footer>
        {history.length > 5 && <button type="button" className="text-action" onClick={() => setHistoryAll(!historyAll)}>{historyAll ? growthText.showLess[locale] : growthText.showAll[locale].replace("{n}", String(history.length))}</button>}
        <button type="button" className="text-action history-clear" onClick={() => { if (confirmClear) void hideHistory(null); else { setConfirmClear(true); window.setTimeout(() => setConfirmClear(false), 4000); } }}>{confirmClear ? growthText.confirmClear[locale] : growthText.clearAll[locale]}</button>
      </footer>
    </div></details>}
    {historyNote && <p className="history-note" role="status">{historyNote}</p>}
    {busy && streaming && <article className="interpretation-output is-streaming" aria-live="polite"><small>{growthText.streaming[locale]}</small><ReadingBody locale={locale} response={streaming} /></article>}
    {shownDraft && (mode === "structured" || shownDraft.unlocked) && <article className={`interpretation-output ${shownDraft.unlocked ? "" : "is-preview"}`}>
      <small>{shownDraft.unlocked ? text.unlocked : text.previewBadge} · {(shownDraft.full ?? shownDraft.preview).title}</small>
      <ReadingBody locale={locale} response={shownDraft.full ?? shownDraft.preview} />
      {!shownDraft.unlocked && <div className="reading-locked" aria-live="polite">
        <ul aria-hidden="true">{shownDraft.lockedSections.map((title) => <li key={title}><b>{title}</b><span /></li>)}</ul>
        {shownDraft.preview.teaser && <p className="reading-teaser">{shownDraft.preview.teaser}</p>}
        <h4>{text.lockedTitle}</h4>
        {freeFullTool && !signedIn ? <p className="reading-free-full-cta">{trustText.signUpForFull[locale]}</p> : <p>{fill(text.lockedLead)}</p>}
        {(signedIn || !freeFullTool) && <CostLine locale={locale} cost={reportCost} balance={signedIn ? balance : null} free={freeFullNow} />}
        <button type="button" className="primary-action" onClick={() => void unlock()} disabled={busy}>{busy ? text.unlocking : freeFullNow ? trustText.freeFullAction[locale] : signedIn ? fill(text.unlock) : text.signIn}<b>↗</b></button>
        {signedIn && insufficientBalance && <button type="button" className="secondary-action" onClick={onOpenMembership}>{walletText.viewMembership}<b>↗</b></button>}
      </div>}
      {shownDraft.unlocked && shownDraft.full && !response && <FollowUpBlock items={shownDraft.full.followUps} locale={locale} cost={followUpCost} previousQuestions={previousQuestions} onPick={pickFollowUp} />}
    </article>}
    {response && <article className={`interpretation-output ${mode === "conversation" ? "conversation-output" : ""}`}><small>{response.title}</small><ReadingBody locale={locale} response={response} /><FollowUpBlock items={response.followUps} locale={locale} cost={followUpCost} previousQuestions={previousQuestions} onPick={pickFollowUp} /></article>}
    {hasReading && <section className="reading-ask-more" aria-label={askMore[locale]}><h3>{askMore[locale]}</h3>{controls}</section>}
    {mode === "structured" && shownDraft && <ShareCardButton chart={chart} reading={shownDraft.preview} locale={locale} inviteCode={inviteCode} route={shareRoute} toolTitle={titleForRoute(shareRoute as AppRoute, locale)} />}
    {(shownDraft?.unlocked || response) && inviteCode && <InviteCard locale={locale} inviteCode={inviteCode} />}
    {(shownDraft || response) && <AdvisorNote locale={locale} />}
    {(shownDraft?.unlocked || response) && nextRoutes.length > 0 && <nav className="reading-next-steps" aria-label={text.nextSteps}><span>{text.nextSteps}</span>{nextRoutes.map((route) => <button type="button" key={route.route} onClick={() => onNavigate?.(route.route)}>{route.label[locale]}</button>)}</nav>}
    <p className="reading-disclaimer">{trustText.readingNote[locale]}</p>
  </section>;
}
