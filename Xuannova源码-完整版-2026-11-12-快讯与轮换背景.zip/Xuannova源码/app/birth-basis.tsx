"use client";
// "本次计算依据": the date, the birth time actually used, the birthplace and the correction rule, shown on every
// birth-chart result so the page says exactly how the chart was calculated.
import type { Locale } from "./site-content";
import type { StudyResult } from "./study-engine";
import { birthTimeText } from "./birth-time";

export function BirthBasis({ result, locale }: { result: StudyResult; locale: Locale }) {
  const t = (key: keyof typeof birthTimeText) => birthTimeText[key][locale];
  const input = result.input;
  if (!input || input.calendar === "pillars") return null;
  const calendar = result.calendar;
  const place = input.location?.label || input.place?.trim() || "";
  const minutes = calendar.solarCorrectionMinutes ?? 0;
  const rule = input.timeUnknown ? "—"
    : calendar.timeBasis === "true-solar" ? t("trueSolar").replace("{t}", `${calendar.trueSolarDate ?? ""} ${calendar.trueSolarTime ?? ""}`.trim()).replace("{m}", `${minutes >= 0 ? "+" : ""}${minutes}`)
      : t("civilNoPlace");
  return <section className={`birth-basis${input.example ? " is-example" : ""}`} aria-label={t("basisTitle")}>
    {input.example && <p className="birth-basis-example"><b className="example-chip">{t("example")}</b>{t("exampleChart")}</p>}
    <h3>{t("basisTitle")}</h3>
    <dl>
      <div><dt>{t("basisDate")}</dt><dd>{calendar.civilDate} · {calendar.lunar}</dd></div>
      <div><dt>{t("basisTime")}</dt><dd>{input.timeUnknown ? t("timeUnknownBasis") : calendar.civilTime}</dd></div>
      <div><dt>{t("basisPlace")}</dt><dd>{place || t("noPlace")}</dd></div>
      <div><dt>{t("basisRule")}</dt><dd>{rule}</dd></div>
    </dl>
  </section>;
}
