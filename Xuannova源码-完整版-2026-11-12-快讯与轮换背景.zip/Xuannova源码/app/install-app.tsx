"use client";
// 像 App 一样用：register the service worker, offer "Add to home screen" (Android/Chrome install prompt, or the
// Share → Add to Home Screen steps on iPhone/iPad Safari), and open the right section from a home-screen shortcut.
import { useEffect, useState, useSyncExternalStore } from "react";
import type { Locale } from "./site-content";
import { track } from "./analytics";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });
const text = {
  title: L("Add Xuannova to your home screen", "把 Xuannova 添加到手机桌面", "把 Xuannova 加到手機主畫面", "Xuannova をホーム画面に追加", "Xuannova를 홈 화면에 추가", "Thêm Xuannova vào màn hình chính", "เพิ่ม Xuannova ไว้ที่หน้าจอโฮม"),
  lead: L("Opens full-screen like an app — your daily card, almanac and study hall in one tap.", "像 App 一样全屏打开，每天一点就看日签、黄历和研习殿。", "像 App 一樣全螢幕開啟，每天一點就看日籤、黃曆和研習殿。", "アプリのように全画面で開き、日めくり・暦・研習殿にワンタップ。", "앱처럼 전체 화면으로 열려 데일리 카드·역서·연습전을 한 번에.", "Mở toàn màn hình như ứng dụng — thiệp hằng ngày, lịch và điện học chỉ một chạm.", "เปิดเต็มจอเหมือนแอป ดูการ์ดประจำวัน ปฏิทิน และหอศึกษาได้ในแตะเดียว"),
  install: L("Add to home screen", "添加到桌面", "加到主畫面", "ホーム画面に追加", "홈 화면에 추가", "Thêm vào màn hình chính", "เพิ่มไปที่หน้าจอโฮม"),
  later: L("Not now", "以后再说", "以後再說", "あとで", "나중에", "Để sau", "ไว้ทีหลัง"),
  inline: L("Add to home screen — open your daily card in one tap", "添加到桌面，每天一点就看日签", "加到主畫面，每天一點就看日籤", "ホーム画面に追加して毎日ワンタップ", "홈 화면에 추가하고 매일 한 번에 보기", "Thêm vào màn hình chính để mở mỗi ngày", "เพิ่มไว้หน้าจอโฮม เปิดดูทุกวันในแตะเดียว"),
  iosTitle: L("On iPhone / iPad (Safari)", "iPhone / iPad（Safari）这样添加", "iPhone / iPad（Safari）這樣新增", "iPhone / iPad（Safari）の場合", "iPhone / iPad (Safari)에서", "Trên iPhone / iPad (Safari)", "บน iPhone / iPad (Safari)"),
  ios1: L("Tap the Share button at the bottom of Safari", "点 Safari 底部的「分享」按钮", "點 Safari 底部的「分享」按鈕", "Safari 下部の「共有」ボタンをタップ", "Safari 하단의 '공유' 버튼을 누르세요", "Chạm nút Chia sẻ ở cuối Safari", "แตะปุ่ม แชร์ ด้านล่างของ Safari"),
  ios2: L("Choose “Add to Home Screen”", "选择「添加到主屏幕」", "選擇「加入主畫面」", "「ホーム画面に追加」を選ぶ", "'홈 화면에 추가'를 선택하세요", "Chọn “Thêm vào MH chính”", "เลือก “เพิ่มไปยังหน้าจอโฮม”"),
  ios3: L("Tap “Add” — the taiji icon appears on your home screen", "点「添加」，桌面上就会出现太极图标", "點「新增」，主畫面就會出現太極圖示", "「追加」で太極アイコンがホーム画面に", "'추가'를 누르면 홈 화면에 태극 아이콘이 생깁니다", "Chạm “Thêm” — biểu tượng thái cực xuất hiện", "แตะ “เพิ่ม” ไอคอนไท่จี๋จะอยู่บนหน้าจอโฮม"),
  iosOther: L("In other iPhone browsers, open this page in Safari first.", "如果在微信或其他浏览器里，请先用 Safari 打开本页。", "如果在微信或其他瀏覽器裡，請先用 Safari 開啟本頁。", "他のブラウザでは、まず Safari で開いてください。", "다른 브라우저라면 먼저 Safari로 여세요.", "Ở trình duyệt khác, hãy mở trang bằng Safari trước.", "หากใช้เบราว์เซอร์อื่น ให้เปิดหน้านี้ด้วย Safari ก่อน"),
  androidTitle: L("On Android", "安卓手机这样添加", "安卓手機這樣新增", "Android の場合", "안드로이드에서", "Trên Android", "บน Android"),
  and1: L("Tap the browser menu ⋮ (top right)", "点浏览器右上角的菜单 ⋮", "點瀏覽器右上角的選單 ⋮", "ブラウザ右上のメニュー ⋮ をタップ", "브라우저 오른쪽 위 메뉴 ⋮ 를 누르세요", "Chạm menu ⋮ của trình duyệt (góc trên phải)", "แตะเมนู ⋮ ของเบราว์เซอร์ (มุมขวาบน)"),
  and2: L("Choose “Install app” or “Add to Home screen”", "选择「安装应用」或「添加到主屏幕」", "選擇「安裝應用程式」或「加到主畫面」", "「アプリをインストール」または「ホーム画面に追加」", "'앱 설치' 또는 '홈 화면에 추가' 선택", "Chọn “Cài đặt ứng dụng” hoặc “Thêm vào MH chính”", "เลือก “ติดตั้งแอป” หรือ “เพิ่มลงในหน้าจอหลัก”"),
  and3: L("Confirm — the taiji icon appears on your home screen", "确认后，桌面上就会出现太极图标", "確認後，主畫面就會出現太極圖示", "確認するとホーム画面に太極アイコンが", "확인하면 홈 화면에 태극 아이콘이 생깁니다", "Xác nhận — biểu tượng thái cực xuất hiện", "ยืนยัน ไอคอนไท่จี๋จะอยู่บนหน้าจอหลัก"),
  andOther: L("In WeChat or other in-app browsers, open this page in Chrome first.", "如果在微信等 App 里打开，请先用 Chrome 或手机浏览器打开本页。", "如果在微信等 App 裡開啟，請先用 Chrome 或手機瀏覽器開啟本頁。", "アプリ内ブラウザでは、まず Chrome で開いてください。", "앱 내 브라우저라면 먼저 Chrome으로 여세요.", "Trong trình duyệt của ứng dụng khác, hãy mở bằng Chrome trước.", "หากเปิดในแอปอื่น ให้เปิดหน้านี้ด้วย Chrome ก่อน"),
  ok: L("Got it", "知道了", "知道了", "わかりました", "확인", "Đã hiểu", "เข้าใจแล้ว"),
};

type PromptEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: "accepted" | "dismissed" }> };
let deferred: PromptEvent | null = null;
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((listener) => listener());
let started = false;

function start() {
  if (started || typeof window === "undefined") return;
  started = true;
  window.addEventListener("beforeinstallprompt", (event) => { event.preventDefault(); deferred = event as PromptEvent; emit(); });
  window.addEventListener("appinstalled", () => { deferred = null; track("app_installed", {}); emit(); });
  if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) {
    window.addEventListener("load", () => { navigator.serviceWorker.register("/sw.js").catch(() => undefined); }, { once: true });
    if (document.readyState === "complete") navigator.serviceWorker.register("/sw.js").catch(() => undefined);
  }
}

const standalone = () => typeof window !== "undefined" && (window.matchMedia?.("(display-mode: standalone)").matches || (navigator as Navigator & { standalone?: boolean }).standalone === true);
const isAndroid = () => typeof navigator !== "undefined" && /android/i.test(navigator.userAgent);
const isIos = () => typeof navigator !== "undefined" && (/iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1));

function useInstall() {
  const prompt = useSyncExternalStore((listener) => { listeners.add(listener); return () => { listeners.delete(listener); }; }, () => deferred, () => null);
  const [env, setEnv] = useState({ standalone: true, ios: false, android: false });
  useEffect(() => {
    start();
    const timer = window.setTimeout(() => {
      const opened = standalone();
      // Opened from the home screen once: remember it, so the browser tab stops asking too.
      if (opened) { try { localStorage.setItem("xn.installed", String(Date.now())); } catch { /* storage blocked */ } }
      setEnv({ standalone: opened, ios: isIos(), android: isAndroid() });
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);
  // Phones only (the text says "phone home screen"): Chrome's own prompt when it has one, otherwise the steps.
  void prompt;
  const available = !env.standalone && (env.ios || env.android);
  const install = async () => {
    if (deferred) { const event = deferred; deferred = null; emit(); await event.prompt(); const choice = await event.userChoice.catch(() => null); track("app_install_prompt", { outcome: choice?.outcome ?? "unknown" }); return "prompted" as const; }
    return env.ios ? "ios" as const : env.android ? "android" as const : "none" as const;
  };
  return { available, ios: env.ios, install };
}

function IosSteps({ locale, onClose, android = false }: { locale: Locale; onClose: () => void; android?: boolean }) {
  return <div className="poster-overlay" role="presentation" onClick={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <div className="install-ios" role="dialog" aria-modal="true" aria-label={text.iosTitle[locale]}>
      <button type="button" className="sample-close install-ios-close" onClick={onClose} aria-label={text.ok[locale]}>×</button>
      <img src="/icon-192.png" alt="" width={64} height={64} />
      <h3>{(android ? text.androidTitle : text.iosTitle)[locale]}</h3>
      {android ? <ol>
        <li><span className="install-ios-icon" aria-hidden="true">⋮</span>{text.and1[locale]}</li>
        <li><span className="install-ios-icon" aria-hidden="true">＋</span>{text.and2[locale]}</li>
        <li><span className="install-ios-icon" aria-hidden="true">✓</span>{text.and3[locale]}</li>
      </ol> : <ol>
        <li><span className="install-ios-icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="20" height="20"><path d="M12 3v12M7 8l5-5 5 5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></svg></span>{text.ios1[locale]}</li>
        <li><span className="install-ios-icon" aria-hidden="true">＋</span>{text.ios2[locale]}</li>
        <li><span className="install-ios-icon" aria-hidden="true">✓</span>{text.ios3[locale]}</li>
      </ol>}
      <small>{(android ? text.andOther : text.iosOther)[locale]}</small>
      <button type="button" className="primary-action" onClick={onClose}>{text.ok[locale]}<b>→</b></button>
    </div>
  </div>;
}

/** Inline button (under the daily cards). Hidden when already installed or not installable. */
export function InstallAppButton({ locale }: { locale: Locale }) {
  const { available, install } = useInstall();
  const [steps, setSteps] = useState<false | "ios" | "android">(false);
  if (!available) return null;
  return <>
    <button type="button" className="install-inline" onClick={() => void install().then((result) => { if (result === "ios" || result === "android") setSteps(result); })}>
      <img src="/icon-192.png" alt="" width={28} height={28} /><span>{text.inline[locale]}</span><b>＋</b>
    </button>
    {steps && <IosSteps locale={locale} android={steps === "android"} onClose={() => setSteps(false)} />}
  </>;
}

const DISMISS_KEY = "xn.install.later", INSTALLED_KEY = "xn.installed";
/** Bottom banner ~5 s into every visit until the site is on the home screen; "Not now" only hides it for this visit. */
export function InstallApp({ locale }: { locale: Locale }) {
  const { available, install } = useInstall();
  const [show, setShow] = useState(false);
  const [steps, setSteps] = useState<false | "ios" | "android">(false);
  useEffect(() => {
    // A home-screen shortcut can ask for a section: /?go=today or /?go=hall.
    const go = new URLSearchParams(window.location.search).get("go");
    if (go === "today" || go === "hall") window.setTimeout(() => document.getElementById(go)?.scrollIntoView({ behavior: "instant" as ScrollBehavior, block: "start" }), 700);
    const installed = () => { try { localStorage.setItem(INSTALLED_KEY, String(Date.now())); } catch { /* storage blocked */ } setShow(false); };
    window.addEventListener("appinstalled", installed);
    try { if (sessionStorage.getItem(DISMISS_KEY) || Date.now() - Number(localStorage.getItem(INSTALLED_KEY) || 0) < 30 * 86400_000) return () => window.removeEventListener("appinstalled", installed); } catch { /* storage blocked: still offer */ }
    // ~5 s after the page opens — counted only while the cookie notice is not on screen, so they never overlap.
    let clear = 0;
    const timer = window.setInterval(() => {
      if (document.querySelector(".cookie-banner")) return;
      clear += 1;
      if (clear >= 5) { window.clearInterval(timer); setShow(true); }
    }, 1000);
    return () => { window.clearInterval(timer); window.removeEventListener("appinstalled", installed); };
  }, []);
  const dismiss = () => { setShow(false); try { sessionStorage.setItem(DISMISS_KEY, "1"); } catch { /* storage blocked */ } };
  return <>
    {show && available && <aside className="install-banner" role="dialog" aria-label={text.title[locale]}>
      <img src="/icon-192.png" alt="" width={44} height={44} />
      <div><b>{text.title[locale]}</b><span>{text.lead[locale]}</span></div>
      <button type="button" className="primary-action" onClick={() => void install().then((result) => { if (result === "ios" || result === "android") setSteps(result); else setShow(false); })}>{text.install[locale]}</button>
      <button type="button" className="install-close" onClick={dismiss} aria-label={text.later[locale]}>×</button>
    </aside>}
    {steps && <IosSteps locale={locale} android={steps === "android"} onClose={() => { setSteps(false); dismiss(); }} />}
  </>;
}

const backLabel = L("Back", "返回", "返回", "戻る", "뒤로", "Quay lại", "กลับ");
/** Opened from the home screen there is no browser bar, so pages other than home get a back button in the header. */
export function AppBackButton({ locale, show, onHome }: { locale: Locale; show: boolean; onHome: () => void }) {
  const [app, setApp] = useState(false);
  useEffect(() => {
    const timer = window.setTimeout(() => setApp(standalone()), 0);
    // The app has hydrated: let the launch screen fade out.
    document.documentElement.dataset.booted = "1";
    return () => window.clearTimeout(timer);
  }, []);
  if (!app || !show) return null;
  return <button type="button" className="app-back" aria-label={backLabel[locale]} onClick={() => { if (window.history.length > 1) window.history.back(); else onHome(); }}>
    <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" /></svg>
  </button>;
}
