// Small, dependency-free helpers for Solana and TRON wallet payments: base58, TRON address conversion and the
// Solana legacy transaction message (SPL TransferChecked + Memo). Shared by the browser and the server.

const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
const INDEX = new Map([...ALPHABET].map((char, index) => [char, index]));

export function base58Encode(bytes: Uint8Array): string {
  let zeros = 0;
  while (zeros < bytes.length && bytes[zeros] === 0) zeros += 1;
  const digits: number[] = [];
  for (const byte of bytes) {
    let carry = byte;
    for (let i = 0; i < digits.length; i += 1) { carry += digits[i] << 8; digits[i] = carry % 58; carry = Math.floor(carry / 58); }
    while (carry) { digits.push(carry % 58); carry = Math.floor(carry / 58); }
  }
  return "1".repeat(zeros) + digits.reverse().map((digit) => ALPHABET[digit]).join("");
}

export function base58Decode(text: string): Uint8Array {
  let zeros = 0;
  while (zeros < text.length && text[zeros] === "1") zeros += 1;
  const bytes: number[] = [];
  for (const char of text) {
    const value = INDEX.get(char);
    if (value === undefined) throw new Error("INVALID_BASE58");
    let carry = value;
    for (let i = 0; i < bytes.length; i += 1) { carry += bytes[i] * 58; bytes[i] = carry & 0xff; carry >>= 8; }
    while (carry) { bytes.push(carry & 0xff); carry >>= 8; }
  }
  return new Uint8Array([...new Array(zeros).fill(0), ...bytes.reverse()]);
}

export const isSolanaAddress = (value: unknown): value is string => typeof value === "string" && /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(value) && (() => { try { return base58Decode(value).length === 32; } catch { return false; } })();
export const isSolanaSignature = (value: unknown): value is string => typeof value === "string" && /^[1-9A-HJ-NP-Za-km-z]{64,88}$/.test(value);

async function sha256(bytes: Uint8Array): Promise<Uint8Array> {
  return new Uint8Array(await crypto.subtle.digest("SHA-256", bytes as Uint8Array<ArrayBuffer>));
}

/** TRON base58check address (T…) → 41-prefixed hex, after checking the checksum. */
export async function tronToHex(address: string): Promise<string> {
  if (!/^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(address)) throw new Error("INVALID_TRON_ADDRESS");
  const raw = base58Decode(address);
  if (raw.length !== 25 || raw[0] !== 0x41) throw new Error("INVALID_TRON_ADDRESS");
  const payload = raw.slice(0, 21);
  const check = (await sha256(await sha256(payload))).slice(0, 4);
  if (check.some((byte, index) => byte !== raw[21 + index])) throw new Error("INVALID_TRON_ADDRESS");
  return [...payload].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

function compactU16(value: number): number[] {
  const out: number[] = [];
  let rest = value;
  for (;;) { const byte = rest & 0x7f; rest >>= 7; if (!rest) { out.push(byte); return out; } out.push(byte | 0x80); }
}

export const SPL_TOKEN_PROGRAM = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA";
export const MEMO_PROGRAM = "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr";

/**
 * Legacy Solana message: the buyer (fee payer, signer) moves `amount` of `mint` from `source` to `destination`
 * with SPL TransferChecked, and a Memo instruction carries the order reference.
 * Account order: [buyer (signer, writable), source, destination (writable), mint, token program, memo program (readonly)].
 */
export function solanaTransferMessage(input: { buyer: string; source: string; destination: string; mint: string; amount: bigint; decimals: number; memo: string; recentBlockhash: string }): Uint8Array {
  const keys = [input.buyer, input.source, input.destination, input.mint, SPL_TOKEN_PROGRAM, MEMO_PROGRAM];
  if (new Set(keys).size !== keys.length) throw new Error("DUPLICATE_ACCOUNT");
  const keyBytes = keys.map((key) => { const bytes = base58Decode(key); if (bytes.length !== 32) throw new Error("INVALID_ACCOUNT"); return bytes; });
  const blockhash = base58Decode(input.recentBlockhash);
  if (blockhash.length !== 32) throw new Error("INVALID_BLOCKHASH");
  if (input.amount <= 0n || input.amount >= 1n << 64n || !Number.isInteger(input.decimals) || input.decimals < 0 || input.decimals > 18) throw new Error("INVALID_AMOUNT");
  const amount: number[] = [];
  let rest = input.amount;
  for (let i = 0; i < 8; i += 1) { amount.push(Number(rest & 0xffn)); rest >>= 8n; }
  const transferData = [12, ...amount, input.decimals];
  const memoData = [...new TextEncoder().encode(input.memo)];
  const instructions = [
    [4, ...compactU16(4), 1, 3, 2, 0, ...compactU16(transferData.length), ...transferData],
    [5, ...compactU16(0), ...compactU16(memoData.length), ...memoData],
  ];
  return new Uint8Array([
    1, 0, 3, // signatures required, readonly signed, readonly unsigned (mint, token program, memo program)
    ...compactU16(keys.length), ...keyBytes.flatMap((bytes) => [...bytes]),
    ...blockhash,
    ...compactU16(instructions.length), ...instructions.flat(),
  ]);
}
