"use client";

// Admin: 器物坊 products and order fulfilment (check transfer → paid → shipped, or reject).
import { useCallback, useEffect, useState } from "react";
import type { Locale } from "./site-content";

type L7 = Partial<Record<Locale, string>>;
type Product = { id: string; name: L7; description: L7; priceUsdt: string; imageUrl: string | null; stock: number; active: boolean; sortOrder: number };
type Order = { id: string; memberEmail?: string; items: Array<{ name: L7; quantity: number; priceUsdt: string }>; totalUsdt: string; network: string; transactionHash: string; shipping: Record<string, string>; status: string; tracking: string | null; createdAt: string };
const LOCALES: Locale[] = ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"];
const T = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): Record<Locale, string> => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });
const text = {
  tab: T("Workshop", "器物坊", "器物坊", "工房", "공방", "Xưởng", "โรงงานศิลป์"),
  products: T("Products", "商品", "商品", "商品", "상품", "Sản phẩm", "สินค้า"),
  orders: T("Orders", "订单", "訂單", "注文", "주문", "Đơn hàng", "คำสั่งซื้อ"),
  name: T("Name", "名称", "名稱", "名称", "이름", "Tên", "ชื่อ"),
  description: T("Description", "描述", "描述", "説明", "설명", "Mô tả", "รายละเอียด"),
  price: T("Price (USDT)", "价格（USDT）", "價格（USDT）", "価格（USDT）", "가격(USDT)", "Giá (USDT)", "ราคา (USDT)"),
  image: T("Image URL", "图片链接", "圖片連結", "画像 URL", "이미지 URL", "Ảnh (URL)", "ลิงก์รูปภาพ"),
  stock: T("Stock", "库存", "庫存", "在庫", "재고", "Tồn kho", "สต็อก"),
  active: T("On sale", "上架", "上架", "販売中", "판매 중", "Đang bán", "วางขาย"),
  save: T("Save product", "保存商品", "儲存商品", "商品を保存", "상품 저장", "Lưu sản phẩm", "บันทึกสินค้า"),
  edit: T("Edit", "编辑", "編輯", "編集", "편집", "Sửa", "แก้ไข"),
  markPaid: T("Transfer verified → paid", "已核对到账 → 已付款", "已核對入帳 → 已付款", "入金確認 → 入金済み", "입금 확인 → 결제 완료", "Đã xác minh → đã thanh toán", "ตรวจสอบแล้ว → ชำระแล้ว"),
  markShipped: T("Mark shipped", "标记已发货", "標記已出貨", "発送済みにする", "발송 처리", "Đánh dấu đã gửi", "ทำเครื่องหมายจัดส่งแล้ว"),
  reject: T("Reject (returns stock)", "驳回（退回库存）", "駁回（退回庫存）", "却下（在庫を戻す）", "거절(재고 복구)", "Từ chối (trả tồn kho)", "ปฏิเสธ (คืนสต็อก)"),
  tracking: T("Tracking number", "物流单号", "物流單號", "追跡番号", "운송장 번호", "Mã vận đơn", "เลขพัสดุ"),
  none: T("Nothing yet.", "暂无。", "暫無。", "まだありません。", "아직 없습니다.", "Chưa có.", "ยังไม่มี"),
  hint: T("Verify each USDT transfer on the block explorer (amount, network, receiving address) before marking an order as paid.", "标记“已付款”前，请在区块浏览器核对每笔 USDT 转账的金额、网络和收款地址。", "標記「已付款」前，請在區塊瀏覽器核對每筆 USDT 轉帳的金額、網路和收款地址。", "入金済みにする前に、ブロックエクスプローラーで USDT 送金の金額・ネットワーク・受取アドレスを確認してください。", "결제 완료로 바꾸기 전에 블록 탐색기에서 USDT 송금 금액, 네트워크, 수취 주소를 확인하세요.", "Trước khi đánh dấu đã thanh toán, hãy kiểm tra số tiền, mạng và địa chỉ nhận của giao dịch USDT trên trình khám phá khối.", "ก่อนทำเครื่องหมายว่าชำระแล้ว โปรดตรวจสอบยอด เครือข่าย และที่อยู่รับของการโอน USDT บน block explorer"),
};
const empty = { id: "", name: {} as L7, description: {} as L7, priceUsdt: "", imageUrl: "", stock: "0", sortOrder: "0", active: true };

async function call<R>(path: string, body?: unknown): Promise<R> {
  const response = await fetch(path, { method: body === undefined ? "GET" : "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) });
  const payload = await response.json() as R & { error?: string };
  if (!response.ok) throw new Error(payload.error ?? "Request failed");
  return payload;
}

export const workshopTabLabel = (locale: Locale) => text.tab[locale];

export function AdminWorkshop({ locale }: { locale: Locale }) {
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [form, setForm] = useState(empty);
  const [tracking, setTracking] = useState<Record<string, string>>({});
  const [notice, setNotice] = useState("");
  const load = useCallback(async () => {
    try {
      setProducts((await call<{ products: Product[] }>("/api/admin/shop/products")).products);
      setOrders((await call<{ orders: Order[] }>("/api/admin/shop/orders")).orders);
    } catch (cause) { setNotice((cause as Error).message); }
  }, []);
  useEffect(() => { const timer = window.setTimeout(() => { void load(); }, 0); return () => window.clearTimeout(timer); }, [load]);
  const act = async (action: () => Promise<unknown>) => { setNotice(""); try { await action(); await load(); } catch (cause) { setNotice((cause as Error).message); } };
  const label = (map: L7) => map[locale] ?? map.en ?? map["zh-Hans"] ?? "";
  return <section className="admin-panel admin-growth">
    <h3>{text.products[locale]}</h3>
    <form onSubmit={(event) => { event.preventDefault(); void act(async () => { await call("/api/admin/shop/products", { id: form.id || undefined, name: form.name, description: form.description, priceUsdt: form.priceUsdt, imageUrl: form.imageUrl || undefined, stock: Number(form.stock), sortOrder: Number(form.sortOrder), active: form.active }); setForm(empty); }); }}>
      {LOCALES.map((code) => <label key={`n-${code}`}>{text.name[locale]} · {code}<input value={form.name[code] ?? ""} onChange={(event) => setForm({ ...form, name: { ...form.name, [code]: event.target.value } })} /></label>)}
      {LOCALES.map((code) => <label key={`d-${code}`}>{text.description[locale]} · {code}<input value={form.description[code] ?? ""} onChange={(event) => setForm({ ...form, description: { ...form.description, [code]: event.target.value } })} /></label>)}
      <label>{text.price[locale]}<input required inputMode="decimal" value={form.priceUsdt} onChange={(event) => setForm({ ...form, priceUsdt: event.target.value })} /></label>
      <label>{text.image[locale]}<input value={form.imageUrl} onChange={(event) => setForm({ ...form, imageUrl: event.target.value })} placeholder="https://…" /></label>
      <label>{text.stock[locale]}<input type="number" min={0} value={form.stock} onChange={(event) => setForm({ ...form, stock: event.target.value })} /></label>
      <label className="admin-check"><input type="checkbox" checked={form.active} onChange={(event) => setForm({ ...form, active: event.target.checked })} />{text.active[locale]}</label>
      <button type="submit" className="primary-action">{text.save[locale]}</button>
    </form>
    <div className="admin-list">{products.length ? products.map((product) => <article key={product.id}><b>{label(product.name)}</b><small>{product.priceUsdt} USDT · {text.stock[locale]} {product.stock} · {product.active ? text.active[locale] : "—"}</small>
      <button type="button" className="text-action" onClick={() => setForm({ id: product.id, name: product.name, description: product.description, priceUsdt: product.priceUsdt, imageUrl: product.imageUrl ?? "", stock: String(product.stock), sortOrder: String(product.sortOrder), active: product.active })}>{text.edit[locale]}</button></article>) : <p>{text.none[locale]}</p>}</div>
    <h3>{text.orders[locale]}</h3>
    <p className="admin-hint">{text.hint[locale]}</p>
    <div className="admin-list">{orders.length ? orders.map((order) => <article key={order.id} data-status={order.status}>
      <b>{order.memberEmail ?? ""} · {order.totalUsdt} USDT · {order.network.toUpperCase()} · {order.status}</b>
      <small>{order.items.map((item) => `${label(item.name)} × ${item.quantity}`).join(", ")}</small>
      <small><code>{order.transactionHash}</code></small>
      <small>{[order.shipping.name, order.shipping.phone, order.shipping.country, order.shipping.address, order.shipping.postcode, order.shipping.note].filter(Boolean).join(" · ")}</small>
      <div>
        {order.status === "pending" && <button type="button" className="text-action" onClick={() => void act(() => call(`/api/admin/shop/orders/${order.id}`, { status: "paid" }))}>{text.markPaid[locale]}</button>}
        {order.status === "paid" && <><input placeholder={text.tracking[locale]} value={tracking[order.id] ?? ""} onChange={(event) => setTracking({ ...tracking, [order.id]: event.target.value })} />
          <button type="button" className="text-action" onClick={() => void act(() => call(`/api/admin/shop/orders/${order.id}`, { status: "shipped", tracking: tracking[order.id] }))}>{text.markShipped[locale]}</button></>}
        {(order.status === "pending" || order.status === "paid") && <button type="button" className="text-action" onClick={() => void act(() => call(`/api/admin/shop/orders/${order.id}`, { status: "rejected" }))}>{text.reject[locale]}</button>}
      </div></article>) : <p>{text.none[locale]}</p>}</div>
    {notice && <p className="commerce-notice" role="status">{notice}</p>}
  </section>;
}
