"use client";
// Beginner guidance: the home "three steps" strip, field help ("?"), the first-visit tip and
// "How to use this" box on every method and toolkit tool, and the /guide page.
import { Fragment } from "react";
import { GuideDaily, guideDailyTitle } from "./guide-daily";
import { methodCategories } from "./method-categories";
import { useHiddenRoutes } from "./vision-availability";
import { useEffect, useRef, useState, type ReactNode } from "react";
import type { Locale } from "./site-content";
import { titleForRoute, toolkitItems, type AppRoute, type ToolkitKey } from "./study-suite";
import { toolkitName } from "./toolkit-copy";
import { pathFor } from "./study-navigation";
import { methodPitch } from "./method-pitch";
import { setPendingToolkitTool } from "./method-drawer-extras";
import { chartTermTip } from "./chart-terms";
import { glossary } from "./glossary";
import { methodNoteTitle, methodNotes } from "./method-notes";
import { trustText } from "./trust-copy";
import { fieldHelp, firstVisit, guideFaq, guideText, howTo, howToLabels, startSteps } from "./guide-content";

const FIRST_VISIT_KEY = "xuannova-first-visit-done";

function readFlag(key: string) { try { return window.localStorage.getItem(key) === "1"; } catch { return false; } }
function writeFlag(key: string) { try { window.localStorage.setItem(key, "1"); } catch { /* private mode */ } }

function routeLink(locale: Locale, route: AppRoute, navigate: (route: AppRoute) => void, children: ReactNode, className?: string) {
  return <a className={className} href={pathFor(locale, route)} onClick={(event) => {
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return;
    event.preventDefault(); navigate(route);
  }}>{children}</a>;
}

/** Home: three steps to start, right under the hero. */
export function StartSteps({ locale, navigate }: { locale: Locale; navigate: (route: AppRoute) => void }) {
  const steps = [[startSteps.s1, startSteps.d1], [startSteps.s2, startSteps.d2], [startSteps.s3, startSteps.d3]] as const;
  return <section className="start-steps" aria-labelledby="start-steps-title">
    <header><h2 id="start-steps-title">{startSteps.title[locale]}</h2>{routeLink(locale, "guide", navigate, <>{startSteps.guide[locale]} →</>, "start-steps-guide")}</header>
    <ol>{steps.map(([title, detail], index) => <li key={index}><b>{index + 1}</b><div><strong>{title[locale]}</strong><span>{detail[locale]}</span></div></li>)}</ol>
    <div className="start-steps-foot"><p>{startSteps.noTime[locale]}</p><button type="button" className="primary-action" onClick={() => navigate("bazi")}>{startSteps.begin[locale]}<b>→</b></button></div>
  </section>;
}

/** A small "?" next to a form label that opens a short explanation (a panel fixed to the viewport). */
export function FieldHelp({ topic, locale }: { topic: "time" | "calendar" | "place" | "gender" | "question"; locale: Locale }) {
  const [place, setPlace] = useState<{ left: number; top: number } | null>(null);
  const button = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    if (!place) return;
    const close = () => setPlace(null);
    const onDown = (event: PointerEvent) => { if (!(event.target instanceof Node) || !button.current?.parentElement?.contains(event.target)) close(); };
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") close(); };
    window.addEventListener("pointerdown", onDown); window.addEventListener("keydown", onKey);
    window.addEventListener("scroll", close, true); window.addEventListener("resize", close);
    return () => { window.removeEventListener("pointerdown", onDown); window.removeEventListener("keydown", onKey); window.removeEventListener("scroll", close, true); window.removeEventListener("resize", close); };
  }, [place]);
  const toggle = (event: React.MouseEvent) => {
    event.preventDefault(); event.stopPropagation();
    if (place) { setPlace(null); return; }
    const rect = button.current?.getBoundingClientRect();
    if (!rect) return;
    const width = Math.min(320, window.innerWidth - 24);
    setPlace({ left: Math.max(12, Math.min(rect.left - 12, window.innerWidth - width - 12)), top: rect.bottom + 8 });
  };
  return <span className="field-help">
    <button ref={button} type="button" className="field-help-toggle" aria-expanded={Boolean(place)} aria-label={fieldHelp.label[locale]} title={fieldHelp.label[locale]} onClick={toggle}>?</button>
    {place && <span className="field-help-text" role="note" style={{ left: place.left, top: place.top }} onClick={(event) => { event.preventDefault(); event.stopPropagation(); }}>{fieldHelp[topic][locale]}</span>}
  </span>;
}

/** Top of every method form and toolkit tool: first-visit tip and a "How to use this" box. */
export function MethodHelp({ helpKey, locale, navigate }: { helpKey: string; locale: Locale; navigate: (route: AppRoute) => void }) {
  const entry = howTo[helpKey];
  const [showFirst, setShowFirst] = useState(false);
  useEffect(() => { const timer = window.setTimeout(() => setShowFirst(!readFlag(FIRST_VISIT_KEY)), 0); return () => window.clearTimeout(timer); }, []);
  const dismiss = () => { writeFlag(FIRST_VISIT_KEY); setShowFirst(false); };
  if (!entry) return null;
  return <div className="method-help">
    {helpKey === "bazi" && <p className="method-promo">★ {trustText.promo[locale]}</p>}
    {showFirst && <div className="first-visit-tip" role="status">
      <p>{firstVisit.text[locale]}</p>
      <div>
        {helpKey !== "bazi" && helpKey !== "detail" && <button type="button" className="text-action" onClick={() => { dismiss(); navigate("bazi"); }}>{firstVisit.bazi[locale]}</button>}
        {routeLink(locale, "guide", navigate, startSteps.guide[locale], "text-action")}
        <button type="button" className="secondary-action" onClick={dismiss}>{firstVisit.dismiss[locale]}</button>
      </div>
    </div>}
    <details className="how-to-box">
      <summary>{howToLabels.title[locale]}<b>+</b></summary>
      <dl>
        <div><dt>{howToLabels.goodFor[locale]}</dt><dd>{entry.goodFor[locale]}</dd></div>
        <div><dt>{howToLabels.enter[locale]}</dt><dd>{entry.enter[locale]}</dd></div>
        <div><dt>{howToLabels.tip[locale]}</dt><dd>{entry.tip[locale]}</dd></div>
      </dl>
      {routeLink(locale, "guide", navigate, <>{startSteps.guide[locale]} →</>, "how-to-guide")}
    </details>
    {methodNotes[helpKey] && <details className="how-to-box method-notes-box">
      <summary>{methodNoteTitle[locale]}<b>+</b></summary>
      <ul>{methodNotes[helpKey].map((note, index) => <li key={index}>{note[locale]}</li>)}</ul>
    </details>}
  </div>;
}

const colon = (locale: Locale) => (locale === "zh-Hans" || locale === "zh-Hant" || locale === "ja" ? "：" : ": ");

/** The beginner's guide page (/guide). */
export function GuideScreen({ locale, navigate }: { locale: Locale; navigate: (route: AppRoute) => void }) {
  const hiddenRoutes = useHiddenRoutes();
  const steps = [[startSteps.s1, startSteps.d1], [startSteps.s2, startSteps.d2], [startSteps.s3, startSteps.d3]] as const;
  const openTool = (key: ToolkitKey) => { setPendingToolkitTool(key); navigate("toolkit"); };
  const methodRow = (route: AppRoute) => {
    const entry = howTo[route];
    return <li key={route}>{routeLink(locale, route, navigate, <>
      <strong>{titleForRoute(route, locale)}</strong>
      <span>{entry?.goodFor[locale] ?? methodPitch(route, locale)}</span>
      {entry && <small>{howToLabels.enter[locale]}{colon(locale)}{entry.enter[locale]}</small>}
      <b>{howToLabels.open[locale]} →</b>
    </>)}</li>;
  };
  const keyTerms = ["Day master", "Element balance", "Ten God", "Ten-year study cycles"];
  // Display names come from the reading glossary (same words the readings use).
  const keyTermNames: Record<string, string> = { "Day master": "Day Master", "Element balance": "Five Elements", "Ten God": "Ten Gods", "Ten-year study cycles": "Luck cycle" };
  const termName = (term: string) => glossary.find((entry) => entry.names.en.includes(keyTermNames[term]))?.names[locale][0] ?? term;
  return <section className="route-screen guide-screen" data-route="guide" aria-labelledby="guide-title">
    <header className="guide-hero">
      <p>Xuannova</p>
      <h1 id="guide-title">{guideText.title[locale]}</h1>
      <span>{guideText.lead[locale]}</span>
    </header>
    <nav className="guide-toc" aria-label={guideText.title[locale]}>
      {[["guide-what", guideText.whatTitle], ["guide-steps", startSteps.title], ["guide-daily", guideDailyTitle], ["guide-choose", guideText.chooseTitle], ["guide-chart", guideText.chartTitle], ["guide-price", guideText.priceTitle], ["guide-faq", guideText.faqTitle]].map(([id, label]) => <a key={id as string} href={`#${id as string}`} onClick={(event) => { event.preventDefault(); document.getElementById(id as string)?.scrollIntoView({ behavior: "smooth", block: "start" }); }}>{(label as Record<Locale, string>)[locale]}</a>)}
    </nav>
    <article id="guide-what" className="guide-block"><h2>{guideText.whatTitle[locale]}</h2><p>{guideText.what[locale]}</p></article>
    <article id="guide-steps" className="guide-block">
      <h2>{startSteps.title[locale]}</h2>
      <ol className="guide-steps">{steps.map(([title, detail], index) => <li key={index}><b>{index + 1}</b><div><strong>{title[locale]}</strong><span>{detail[locale]}</span></div></li>)}</ol>
      <p className="guide-note">{startSteps.noTime[locale]}</p>
    </article>
    <GuideDaily locale={locale} navigate={navigate} />
    <article id="guide-choose" className="guide-block">
      <h2>{guideText.chooseTitle[locale]}</h2>
      {methodCategories.map((category) => <Fragment key={category.key}>
        <h3>{category.title[locale]}</h3>
        <ul className="guide-methods">{category.routes.filter((route) => !hiddenRoutes.includes(route)).map(methodRow)}</ul>
      </Fragment>)}
      <h3>{guideText.groupTools[locale]}</h3>
      <ul className="guide-methods">{toolkitItems.map((item) => {
        const entry = howTo[`toolkit-${item.key}`];
        return <li key={item.key}><a href={`${pathFor(locale, "toolkit")}?tool=${item.key}`} onClick={(event) => { if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return; event.preventDefault(); openTool(item.key); }}>
          <strong>{toolkitName(item.key, locale)}</strong>
          <span>{entry?.goodFor[locale]}</span>
          {entry && <small>{howToLabels.enter[locale]}{colon(locale)}{entry.enter[locale]}</small>}
          <b>{howToLabels.open[locale]} →</b>
        </a></li>;
      })}</ul>
    </article>
    <article id="guide-chart" className="guide-block">
      <h2>{guideText.chartTitle[locale]}</h2>
      <p>{guideText.chart[locale]}</p>
      <h3>{guideText.keyTerms[locale]}</h3>
      <dl className="guide-terms">{keyTerms.map((term) => <div key={term}><dt>{termName(term)}</dt><dd>{chartTermTip(term, locale)}</dd></div>)}</dl>
    </article>
    <article id="guide-price" className="guide-block">
      <h2>{guideText.priceTitle[locale]}</h2>
      <p>{guideText.price[locale]}</p>
      <h3>{guideText.videoTitle[locale]}</h3>
      <p>{guideText.video[locale]} {routeLink(locale, "courses", navigate, <>{titleForRoute("courses", locale)} →</>, "text-action")}</p>
    </article>
    <article id="guide-faq" className="guide-block">
      <h2>{guideText.faqTitle[locale]}</h2>
      <div className="guide-faq">{guideFaq.map((item, index) => <details key={index}><summary>{item.q[locale]}<b>+</b></summary><p>{item.a[locale]}</p></details>)}</div>
      <p className="guide-note">{guideText.help[locale]}</p>
    </article>
    <footer className="guide-cta"><button type="button" className="primary-action" onClick={() => navigate("bazi")}>{startSteps.begin[locale]}<b>→</b></button></footer>
  </section>;
}
