export type SolarTimeInput = {
  date: string;
  time: string;
  longitude: number;
  timezone: string;
};

export type SolarTimeResult = {
  civilDate: string;
  civilTime: string;
  trueSolarDate: string;
  trueSolarTime: string;
  correctionMinutes: number;
  equationOfTimeMinutes: number;
  longitudeCorrectionMinutes: number;
  daylightSavingCorrectionMinutes: number;
  timezoneOffsetMinutes: number;
  standardOffsetMinutes: number;
  standardMeridian: number;
};

function toParts(date: string, time: string) {
  const [year = 1994, month = 1, day = 1] = date.split("-").map(Number);
  const [hour = 0, minute = 0] = time.split(":").map(Number);
  return { year, month, day, hour, minute };
}

function formatSyntheticLocal(ms: number) {
  const instant = new Date(ms);
  const date = [instant.getUTCFullYear(), String(instant.getUTCMonth() + 1).padStart(2, "0"), String(instant.getUTCDate()).padStart(2, "0")].join("-");
  const time = [String(instant.getUTCHours()).padStart(2, "0"), String(instant.getUTCMinutes()).padStart(2, "0")].join(":");
  return { date, time };
}

function timezoneOffsetAt(instant: number, timezone: string) {
  try {
    const parts = new Intl.DateTimeFormat("en-CA", {
      timeZone: timezone,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hourCycle: "h23",
    }).formatToParts(new Date(instant));
    const values = Object.fromEntries(parts.filter((part) => part.type !== "literal").map((part) => [part.type, part.value]));
    const localAsUtc = Date.UTC(Number(values.year), Number(values.month) - 1, Number(values.day), Number(values.hour), Number(values.minute), Number(values.second));
    return Math.round((localAsUtc - instant) / 60_000);
  } catch {
    return 0;
  }
}

function localCivilInstant(parts: ReturnType<typeof toParts>, timezone: string) {
  const guessedInstant = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute);
  const firstOffset = timezoneOffsetAt(guessedInstant, timezone);
  const refinedInstant = guessedInstant - firstOffset * 60_000;
  const refinedOffset = timezoneOffsetAt(refinedInstant, timezone);
  return { instant: guessedInstant - refinedOffset * 60_000, offset: refinedOffset };
}

function standardTimezoneOffset(year: number, timezone: string) {
  const january = timezoneOffsetAt(Date.UTC(year, 0, 15, 12), timezone);
  const july = timezoneOffsetAt(Date.UTC(year, 6, 15, 12), timezone);
  return Math.min(january, july);
}

function equationOfTime(year: number, month: number, day: number) {
  const start = Date.UTC(year, 0, 0);
  const current = Date.UTC(year, month - 1, day);
  const dayOfYear = Math.round((current - start) / 86_400_000);
  const b = (2 * Math.PI * (dayOfYear - 81)) / 364;
  return 9.87 * Math.sin(2 * b) - 7.53 * Math.cos(b) - 1.5 * Math.sin(b);
}

// Mainland China keeps one legal time (Beijing, UTC+8) nationwide. Geocoders may return the
// unofficial Xinjiang zone (UTC+6), which would shift the civil reference by two hours.
const CIVIL_TIMEZONE_ALIASES: Record<string, string> = { "Asia/Urumqi": "Asia/Shanghai", "Asia/Kashgar": "Asia/Shanghai" };
export function normalizeCivilTimezone(timezone: string, countryCode?: string) {
  if (countryCode && countryCode.toUpperCase() === "CN") return "Asia/Shanghai";
  return CIVIL_TIMEZONE_ALIASES[timezone] ?? timezone;
}

/** UTC epoch (ms) for a civil date/time in an IANA time zone. */
export function civilInstantUtc(date: string, time: string, timezone: string) {
  return localCivilInstant(toParts(date, time), normalizeCivilTimezone(timezone)).instant;
}

export function calculateTrueSolarTime(rawInput: SolarTimeInput): SolarTimeResult {
  const input = { ...rawInput, timezone: normalizeCivilTimezone(rawInput.timezone) };
  const parts = toParts(input.date, input.time);
  const { offset: timezoneOffsetMinutes } = localCivilInstant(parts, input.timezone);
  const standardOffsetMinutes = standardTimezoneOffset(parts.year, input.timezone);
  const standardMeridian = standardOffsetMinutes / 4;
  const equationOfTimeMinutes = equationOfTime(parts.year, parts.month, parts.day);
  const longitudeCorrectionMinutes = 4 * (input.longitude - standardMeridian);
  const daylightSavingCorrectionMinutes = timezoneOffsetMinutes - standardOffsetMinutes;
  const correctionMinutes = equationOfTimeMinutes + longitudeCorrectionMinutes - daylightSavingCorrectionMinutes;
  const civilSyntheticTime = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute);
  const trueSolar = formatSyntheticLocal(civilSyntheticTime + Math.round(correctionMinutes) * 60_000);

  return {
    civilDate: input.date,
    civilTime: input.time,
    trueSolarDate: trueSolar.date,
    trueSolarTime: trueSolar.time,
    correctionMinutes: Math.round(correctionMinutes),
    equationOfTimeMinutes: Math.round(equationOfTimeMinutes * 10) / 10,
    longitudeCorrectionMinutes: Math.round(longitudeCorrectionMinutes * 10) / 10,
    daylightSavingCorrectionMinutes,
    timezoneOffsetMinutes,
    standardOffsetMinutes,
    standardMeridian,
  };
}
