"use client";

// "Sign in with Google" — shown only when the server has a Google client ID configured.
import { useEffect, useRef, useState } from "react";
import type { Locale } from "./site-content";

type GoogleId = { accounts: { id: { initialize(options: { client_id: string; callback: (response: { credential: string }) => void }): void; renderButton(element: HTMLElement, options: Record<string, unknown>): void } } };
declare global { interface Window { google?: GoogleId } }

const localeTag: Record<Locale, string> = { en: "en", "zh-Hans": "zh_CN", "zh-Hant": "zh_TW", ja: "ja", ko: "ko", vi: "vi", th: "th" };

export function GoogleSignIn({ locale, inviteCode, onSignedIn, onError }: { locale: Locale; inviteCode?: string; onSignedIn: () => void; onError: (message: string) => void }) {
  const container = useRef<HTMLDivElement>(null);
  const [clientId, setClientId] = useState<string | null>(null);
  const callbacks = useRef({ inviteCode, onSignedIn, onError });
  useEffect(() => { callbacks.current = { inviteCode, onSignedIn, onError }; });
  useEffect(() => {
    let cancelled = false;
    fetch("/api/auth/providers", { credentials: "same-origin" }).then((response) => response.ok ? response.json() : null).then((payload: { google?: { clientId: string } | null } | null) => {
      if (!cancelled) setClientId(payload?.google?.clientId ?? null);
    }).catch(() => undefined);
    return () => { cancelled = true; };
  }, []);
  useEffect(() => {
    if (!clientId || !container.current) return;
    const render = () => {
      if (!window.google || !container.current) return;
      window.google.accounts.id.initialize({
        client_id: clientId,
        callback: async ({ credential }) => {
          try {
            const response = await fetch("/api/auth/google", { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify({ credential, ...(callbacks.current.inviteCode ? { inviteCode: callbacks.current.inviteCode } : {}) }) });
            if (!response.ok) { callbacks.current.onError(((await response.json()) as { error?: string }).error ?? "Google sign-in failed"); return; }
            callbacks.current.onSignedIn();
          } catch { callbacks.current.onError("Google sign-in failed"); }
        },
      });
      window.google.accounts.id.renderButton(container.current, { theme: "outline", size: "large", width: 280, locale: localeTag[locale] });
    };
    if (window.google) { render(); return; }
    const script = document.createElement("script");
    script.src = "https://accounts.google.com/gsi/client";
    script.async = true;
    script.onload = render;
    document.head.appendChild(script);
  }, [clientId, locale]);
  if (!clientId) return null;
  return <div className="google-sign-in" ref={container} />;
}
