/** Local-only preflight. This validates configuration, not contract safety or
 * bytecode provenance; independent audit and deployment verification remain
 * mandatory. Reader/provider must be connected to the intended mainnet. */
import {decodeFunctionResult,encodeFunctionData,getAddress,parseAbi,type Address,type Hex} from "viem";
import type {EvmProvider,EvmSession} from "./evm-wallet-session.draft";
import {assertEvmSession} from "./evm-wallet-session.draft";
import {settlementNetworks} from "../worker/multichain-policy";
const abi=parseAbi(["function settlement() view returns(address)","function treasury() view returns(address)"]);
const tokenAbi=parseAbi(["function decimals() view returns(uint8)"]);
const ZERO="0x0000000000000000000000000000000000000000";
export async function verifyEthereumCheckoutDraft(input:{provider:EvmProvider;session:EvmSession;checkout:Address;settlement:Address}) {
 if(input.session.network!=="ethereum")throw new Error("WRONG_CHAIN");
 await assertEvmSession(input.provider,input.session);
 const checkout=getAddress(input.checkout),settlement=getAddress(input.settlement);
 if(checkout===ZERO||settlement===ZERO||checkout===settlement)throw new Error("INVALID_CHECKOUT_CONFIGURATION");
 const [code,tokenCode,settlementRaw,treasuryRaw,decimalsRaw]=await Promise.all([
  input.provider.request({method:"eth_getCode",params:[checkout,"latest"]}),input.provider.request({method:"eth_getCode",params:[settlement,"latest"]}),
  input.provider.request({method:"eth_call",params:[{to:checkout,data:encodeFunctionData({abi,functionName:"settlement"})},"latest"]}),
  input.provider.request({method:"eth_call",params:[{to:checkout,data:encodeFunctionData({abi,functionName:"treasury"})},"latest"]}),
  input.provider.request({method:"eth_call",params:[{to:settlement,data:encodeFunctionData({abi:tokenAbi,functionName:"decimals"})},"latest"]}),
 ]);
 if(typeof code!=="string"||!/^0x(?:[0-9a-fA-F]{2})+$/.test(code)||typeof tokenCode!=="string"||!/^0x(?:[0-9a-fA-F]{2})+$/.test(tokenCode))throw new Error("CONTRACT_CODE_MISSING");
 try {
  const onchainToken=decodeFunctionResult({abi,functionName:"settlement",data:settlementRaw as Hex});
  const recipient=decodeFunctionResult({abi,functionName:"treasury",data:treasuryRaw as Hex});
  const decimals=decodeFunctionResult({abi:tokenAbi,functionName:"decimals",data:decimalsRaw as Hex});
  if(getAddress(onchainToken)!==settlement||getAddress(recipient)!==getAddress(settlementNetworks.ethereum.recipient)||decimals!==6)throw new Error("CHECKOUT_CONFIGURATION_MISMATCH");
 } catch {throw new Error("CHECKOUT_CONFIGURATION_MISMATCH");}
 await assertEvmSession(input.provider,input.session);
}
