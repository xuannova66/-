"use client";
// Member avatar: one of the eight trigrams, chosen from the account id so it stays the same on every device,
// drawn as three gold lines inside a ringed medallion. No photo is stored.
const TRIGRAMS = [
  { lines: [1, 1, 1], name: "乾" }, { lines: [0, 1, 1], name: "兑" }, { lines: [1, 0, 1], name: "离" }, { lines: [0, 0, 1], name: "震" },
  { lines: [1, 1, 0], name: "巽" }, { lines: [0, 1, 0], name: "坎" }, { lines: [1, 0, 0], name: "艮" }, { lines: [0, 0, 0], name: "坤" },
];
const TINTS = [["#2a2418", "#3b2f1b"], ["#1f2622", "#27362d"], ["#2a1d1d", "#3a2424"], ["#1c2230", "#253049"]];

function seedOf(value: string) {
  let hash = 2166136261;
  for (const char of value) { hash ^= char.charCodeAt(0); hash = Math.imul(hash, 16777619); }
  return hash >>> 0;
}

export function MemberAvatar({ seed, className = "mc-avatar" }: { seed: string; className?: string }) {
  const value = seedOf(seed || "xuannova");
  const trigram = TRIGRAMS[value % 8];
  const [inner, outer] = TINTS[(value >>> 3) % TINTS.length];
  const id = `av${value.toString(36)}`;
  // Lines from top to bottom; the trigram's first entry is the bottom line.
  const rows = [...trigram.lines].reverse();
  return <span className={`${className} member-avatar`} aria-hidden="true" title={trigram.name}>
    <svg viewBox="0 0 64 64" width="100%" height="100%">
      <defs>
        <linearGradient id={`${id}-ring`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#f2d792" /><stop offset=".55" stopColor="#c59a4a" /><stop offset="1" stopColor="#8a6428" /></linearGradient>
        <radialGradient id={`${id}-bg`} cx=".35" cy=".3" r=".9"><stop offset="0" stopColor={outer} /><stop offset="1" stopColor={inner} /></radialGradient>
      </defs>
      <circle cx="32" cy="32" r="31" fill={`url(#${id}-ring)`} />
      <circle cx="32" cy="32" r="28" fill={`url(#${id}-bg)`} />
      <circle cx="32" cy="32" r="24.5" fill="none" stroke="#c59a4a" strokeOpacity=".35" strokeWidth=".8" strokeDasharray="1.5 2.5" />
      {rows.map((solid, index) => {
        const y = 22 + index * 10;
        return solid
          ? <rect key={index} x="18" y={y - 2.6} width="28" height="5.2" rx="1.2" fill={`url(#${id}-ring)`} />
          : <g key={index}><rect x="18" y={y - 2.6} width="12" height="5.2" rx="1.2" fill={`url(#${id}-ring)`} /><rect x="34" y={y - 2.6} width="12" height="5.2" rx="1.2" fill={`url(#${id}-ring)`} /></g>;
      })}
    </svg>
  </span>;
}
