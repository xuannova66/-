"use client";

// Home sections: choose by goal, free advisor, and the charity commitment. Lecture videos live in courses.tsx.
import type { Locale } from "./site-content";
import { ContactIconRow } from "./contact-icons";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

export const charityLine = L(
  "Every year Xuannova sets aside a dedicated charity fund, using part of its income to help 1,000–10,000 people facing hardship around the world.",
  "Xuannova 每年拨出专项公益资金，将部分经营所得帮扶全球 1,000–10,000 名困境个体。",
  "Xuannova 每年撥出專項公益資金，將部分經營所得幫扶全球 1,000–10,000 名困境個體。",
  "Xuannova は毎年、公益のための専用資金を設け、事業収益の一部で世界の 1,000～10,000 人の困難を抱える方々を支援しています。",
  "Xuannova는 매년 공익 기금을 따로 마련해 수익의 일부로 전 세계 1,000~10,000명의 어려움에 처한 분들을 돕습니다.",
  "Mỗi năm Xuannova dành riêng một quỹ thiện nguyện, dùng một phần thu nhập để hỗ trợ 1.000–10.000 người gặp khó khăn trên khắp thế giới.",
  "ทุกปี Xuannova จัดสรรกองทุนเพื่อสาธารณประโยชน์ โดยนำรายได้ส่วนหนึ่งไปช่วยเหลือผู้ที่ประสบความยากลำบาก 1,000–10,000 คนทั่วโลก",
);

const text = {
  goalEyebrow: L("Start from your question", "从你的问题开始", "從你的問題開始", "知りたいことから選ぶ", "궁금한 것에서 시작하기", "Bắt đầu từ câu hỏi của bạn", "เริ่มจากคำถามของคุณ"),
  goalTitle: L("What would you like to explore?", "你想了解什么？", "你想了解什麼？", "何を知りたいですか？", "무엇을 알아보고 싶으신가요?", "Bạn muốn tìm hiểu điều gì?", "คุณอยากสำรวจเรื่องใด"),
  advisorEyebrow: L("Personal advisor · free", "专属顾问 · 免费", "專屬顧問 · 免費", "専属アドバイザー · 無料", "전담 상담 · 무료", "Tư vấn riêng · miễn phí", "ที่ปรึกษาส่วนตัว · ฟรี"),
  advisorTitle: L("Not sure where to start? Ask us.", "不知道从哪开始？问我们。", "不知道從哪開始？問我們。", "どこから始めればよいか迷ったら、お気軽に。", "어디서 시작할지 모르겠다면 문의하세요.", "Chưa biết bắt đầu từ đâu? Hãy hỏi chúng tôi.", "ไม่แน่ใจว่าจะเริ่มตรงไหน? ถามเราได้"),
  advisorLead: L("Help choosing a tool or understanding a report, before or after you buy — always free of charge.", "选工具、看懂报告、购买前后的问题，都可以联系专属顾问，全部免费。", "選工具、看懂報告、購買前後的問題，都可以聯絡專屬顧問，全部免費。", "ツール選びやレポートの読み方、購入前後のご質問まで、専属アドバイザーが無料でお手伝いします。", "도구 선택, 보고서 이해, 구매 전후 문의까지 전담 상담이 모두 무료로 도와드립니다.", "Chọn công cụ, hiểu báo cáo, câu hỏi trước và sau khi mua — tư vấn riêng luôn miễn phí.", "เลือกเครื่องมือ อ่านรายงาน หรือคำถามก่อนและหลังซื้อ ที่ปรึกษาส่วนตัวช่วยฟรีเสมอ"),
  charityEyebrow: L("Our commitment", "我们的承诺", "我們的承諾", "私たちの約束", "우리의 약속", "Cam kết của chúng tôi", "คำมั่นของเรา"),
};

const goals: Array<{ route: string; mark: string; title: L7; lead: L7 }> = [
  { route: "bazi", mark: "命", title: L("Understand myself", "了解自己", "了解自己", "自分を知る", "나를 알기", "Hiểu về bản thân", "รู้จักตัวเอง"), lead: L("Personality, strengths and rhythm of life", "性格、优势与人生节奏", "性格、優勢與人生節奏", "性格・強み・人生のリズム", "성격, 강점, 삶의 리듬", "Tính cách, thế mạnh và nhịp sống", "บุคลิก จุดแข็ง และจังหวะชีวิต") },
  { route: "compatibility", mark: "合", title: L("A relationship", "感情与关系", "感情與關係", "人間関係", "관계와 인연", "Một mối quan hệ", "ความสัมพันธ์"), lead: L("How two charts meet", "两个人的盘面如何相合", "兩個人的盤面如何相合", "二人の命式の相性", "두 사람의 명반이 만나는 방식", "Hai lá số hòa hợp ra sao", "สองผังพบกันอย่างไร") },
  { route: "liuyao", mark: "爻", title: L("One specific question", "问一件具体的事", "問一件具體的事", "具体的な一つの問い", "구체적인 한 가지 질문", "Một câu hỏi cụ thể", "คำถามเฉพาะเรื่อง"), lead: L("Cast a hexagram for it", "起一卦来看", "起一卦來看", "卦を立てて見る", "괘를 세워 보기", "Lập một quẻ để xem", "ตั้งกว้าเพื่อดู") },
  { route: "qimen", mark: "奇", title: L("Timing and choices", "时机与选择", "時機與選擇", "タイミングと選択", "시기와 선택", "Thời điểm và lựa chọn", "จังหวะเวลาและทางเลือก"), lead: L("Read the moment's layout", "看此刻的格局", "看此刻的格局", "今この時の配置を読む", "지금의 배치를 읽기", "Đọc bố cục của thời khắc", "อ่านผังของช่วงเวลานี้") },
  { route: "daily", mark: "日", title: L("Plan today", "安排今天", "安排今天", "今日の予定", "오늘 계획", "Sắp xếp hôm nay", "วางแผนวันนี้"), lead: L("Hours, almanac and solar term", "时辰、黄历与节气", "時辰、黃曆與節氣", "時辰・暦注・節気", "시진, 역서, 절기", "Giờ, lịch và tiết khí", "ยาม ปฏิทิน และสารท") },
  { route: "hecan", mark: "参", title: L("The full picture", "全面看一看", "全面看一看", "全体を見る", "전체적으로 보기", "Bức tranh toàn cảnh", "ภาพรวมทั้งหมด"), lead: L("BaZi and Zi Wei together", "八字与紫微合参", "八字與紫微合參", "四柱と紫微を合わせて", "사주와 자미두수 함께", "Bát Tự và Tử Vi kết hợp", "ปาจื้อและจื่อเวยร่วมกัน") },
];

export function HomeGoalEntry({ locale, navigate }: { locale: Locale; navigate: (route: string) => void }) {
  return <section className="home-goals" aria-labelledby="home-goals-title">
    <header><p>{text.goalEyebrow[locale]}</p><h2 id="home-goals-title">{text.goalTitle[locale]}</h2></header>
    <div>{goals.map((goal) => <button type="button" key={goal.route} onClick={() => navigate(goal.route)}><i aria-hidden="true">{goal.mark}</i><strong>{goal.title[locale]}</strong><span>{goal.lead[locale]}</span></button>)}</div>
  </section>;
}

export function HomeAdvisor({ locale }: { locale: Locale }) {
  return <section className="home-advisor" aria-labelledby="home-advisor-title">
    <div><p>{text.advisorEyebrow[locale]}</p><h2 id="home-advisor-title">{text.advisorTitle[locale]}</h2><span>{text.advisorLead[locale]}</span></div>
    <ContactIconRow className="home-advisor-icons" />
  </section>;
}

export function HomeCharity({ locale }: { locale: Locale }) {
  return <section className="home-charity" aria-label={text.charityEyebrow[locale]}><p>{text.charityEyebrow[locale]}</p><h2>{charityLine[locale]}</h2></section>;
}

/** Headings of the home sections added for the shorter home page (sample report, pricing). */
export const homeSectionText = {
  sampleEyebrow: L("Sample report", "报告示例", "報告示例", "レポート例", "리포트 예시", "Báo cáo mẫu", "รายงานตัวอย่าง"),
  sampleTitle: L("What you get, before you start", "先看看报告长什么样", "先看看報告長什麼樣", "始める前に、レポートの中身を", "시작하기 전에 리포트를 먼저 보세요", "Xem báo cáo trông thế nào trước khi bắt đầu", "ดูหน้าตารายงานก่อนเริ่ม"),
  sampleLead: L("A clearly marked fictional case: the plain summary, how the chart maps to the text, the chapters, where the free part ends, and what you can ask next.", "用一个明确标注的虚构案例，展示白话总结、盘面与解释的对应、章节、免费与付费的界线，以及可以继续追问什么。", "用一個明確標註的虛構案例，展示白話總結、盤面與解釋的對應、章節、免費與付費的界線，以及可以繼續追問什麼。", "架空と明記したケースで、要約・盤と解説の対応・章立て・無料部分の範囲・追加質問を紹介します。", "가상임을 명시한 사례로 요약, 차트와 해석의 연결, 장 구성, 무료 범위, 추가 질문을 보여 드립니다.", "Một trường hợp hư cấu ghi rõ: tóm tắt, lá số khớp với lời giải, các chương, ranh giới miễn phí và câu hỏi tiếp theo.", "กรณีสมมติที่ระบุชัดเจน แสดงบทสรุป การเชื่อมผังกับคำอธิบาย บทต่าง ๆ ขอบเขตส่วนฟรี และคำถามต่อ"),
  pricingEyebrow: L("Pricing · free benefits", "收费与免费权益", "收費與免費權益", "料金と無料特典", "요금과 무료 혜택", "Chi phí và quyền lợi miễn phí", "ราคาและสิทธิ์ฟรี"),
  pricingTitle: L("What is free, what uses credits", "哪些免费，哪些用积分", "哪些免費，哪些用積分", "無料のもの、クレジットを使うもの", "무료인 것, 크레딧을 쓰는 것", "Cái gì miễn phí, cái gì dùng điểm", "อะไรฟรี อะไรใช้เครดิต"),
  heroPanel: L("Start with a free BaZi chart", "先免费排一张八字盘", "先免費排一張八字盤", "まずは無料で八字の命式を", "먼저 무료로 사주 차트를", "Bắt đầu với lá số Bát tự miễn phí", "เริ่มด้วยผังปาจื้อฟรี"),
  catalogueTitle: L("Popular methods · {n} in all", "常用研习方法 · 共 {n} 种", "常用研習方法 · 共 {n} 種", "よく使う方法 · 全 {n} 種", "자주 쓰는 방법 · 총 {n}가지", "Phương pháp phổ biến · tổng {n}", "วิธีที่นิยม · ทั้งหมด {n} วิธี"),
  buy: L("See credit packages", "查看积分套餐", "查看積分方案", "クレジットパッケージを見る", "크레딧 패키지 보기", "Xem các gói điểm", "ดูแพ็กเกจเครดิต"),
};
