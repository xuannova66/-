/** Local-only approval flow. Requires explicit user gesture; not live-wired.
 * A returned hash is not a confirmed approval. The caller must check its
 * receipt and allowance, obtain a fresh quote, then separately ask the user
 * to confirm the purchase. Never auto-repeat an ambiguous submission.
 */
import {encodeFunctionData,getAddress,parseAbi,type Address,type Hex} from "viem";
import {assertEvmSession,type EvmProvider,type EvmSession} from "./evm-wallet-session.draft";
const tokenAbi=parseAbi(["function allowance(address owner,address spender) view returns(uint256)","function approve(address spender,uint256 amount) returns(bool)"]);
const ZERO="0x0000000000000000000000000000000000000000";

export async function requestEthereumDraftApproval(input:{provider:EvmProvider;session:EvmSession;token:Address;checkout:Address;allowedTokens:readonly Address[];amount:bigint;onHash:(hash:Hex)=>Promise<void>}) {
  if(input.session.network!=="ethereum")throw new Error("WRONG_CHAIN");
  await assertEvmSession(input.provider,input.session);
  const token=getAddress(input.token),checkout=getAddress(input.checkout);
  if(token===ZERO || checkout===ZERO || !input.allowedTokens.map(getAddress).includes(token) || typeof input.amount!=="bigint" || input.amount<=0n || input.amount>=(1n<<256n)) throw new Error("INVALID_APPROVAL_REQUEST");
  const data=encodeFunctionData({abi:tokenAbi,functionName:"allowance",args:[input.session.address,checkout]});
  const allowance=await input.provider.request({method:"eth_call",params:[{to:token,data},"latest"]});
  if(typeof allowance!=="string" || !/^0x[0-9a-fA-F]{64}$/.test(allowance))throw new Error("ALLOWANCE_UNAVAILABLE");
  // The RPC request may take long enough for the active wallet or chain to
  // change. Do not report the old account's allowance as currently usable.
  await assertEvmSession(input.provider,input.session);
  if(BigInt(allowance)>=input.amount)return {status:"already_sufficient" as const};
  // Some tokens require resetting an existing nonzero allowance to zero.
  // Do not perform this extra approval silently or assume token compatibility.
  if(BigInt(allowance)>0n)throw new Error("NONZERO_ALLOWANCE_REQUIRES_REVIEW");
  const approval=encodeFunctionData({abi:tokenAbi,functionName:"approve",args:[checkout,input.amount]});
  const tx={from:input.session.address,to:token,data:approval,value:"0x0"};
  const gas=await input.provider.request({method:"eth_estimateGas",params:[tx]});
  if(typeof gas!=="string" || !/^0x[0-9a-fA-F]+$/.test(gas) || BigInt(gas)<=0n || BigInt(gas)>2_000_000n)throw new Error("GAS_ESTIMATE_UNAVAILABLE");
  await assertEvmSession(input.provider,input.session);
  let hash:unknown;
  try{hash=await input.provider.request({method:"eth_sendTransaction",params:[{...tx,gas:`0x${((BigInt(gas)*120n+99n)/100n).toString(16)}`}]});}
  catch(error){
    if(error && typeof error==="object" && "code" in error && error.code===4001)throw new Error("WALLET_REQUEST_REJECTED");
    throw new Error("APPROVAL_OUTCOME_UNKNOWN_CHECK_WALLET");
  }
  if(typeof hash!=="string" || !/^0x[0-9a-fA-F]{64}$/.test(hash))throw new Error("APPROVAL_OUTCOME_UNKNOWN_CHECK_WALLET");
  try{await input.onHash(hash as Hex);return {status:"submitted" as const,hash:hash as Hex,recoveryRecorded:true};}
  catch{return {status:"submitted" as const,hash:hash as Hex,recoveryRecorded:false};}
}
