export type LocalSession = {
  email: string;
  mode: "local";
};

const sessionKey = "xuanyuan-institute-local-session";

export function isValidEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}

export function createLocalSession(email: string): LocalSession {
  return { email: email.trim().toLowerCase(), mode: "local" };
}

export function readLocalSession(): LocalSession | null {
  if (typeof window === "undefined") return null;
  try {
    const value = window.localStorage.getItem(sessionKey);
    if (!value) return null;
    const session = JSON.parse(value) as LocalSession;
    return session.mode === "local" && isValidEmail(session.email) ? session : null;
  } catch {
    return null;
  }
}

export function saveLocalSession(session: LocalSession) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(sessionKey, JSON.stringify(session));
}

export function clearLocalSession() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(sessionKey);
}
