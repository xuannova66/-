// Home page copy in all seven languages (previously only Chinese and English existed, so
// Japanese, Korean, Vietnamese and Thai visitors saw an English hero).
import type { Locale } from "./site-content";

type HomeCopy = {
  eyebrow: string; headline: string; description: string; prompt: string; freeChart: string; discover: string;
  viewAll: string; showLess: string; today: string; todayLead: string; classroom: string; classroomTitle: string;
  libraryTitle: string; libraryLead: string; enter: string; viewToday: string; choose: string; free: string; report: string; ask: string;
};

export const homeCopy: Record<Locale, HomeCopy> = {
  en: {
    eyebrow: "EASTERN CULTURAL STUDIES · SEVEN LANGUAGES",
    headline: "Understand your chart,\none question at a time",
    description: "Choose a topic, enter your birth details, and explore a free chart before deciding whether to go deeper.",
    prompt: "What would you like to explore?", freeChart: "Create a free chart", discover: "Choose a question, not a technique",
    viewAll: "View all {n} study methods", showLess: "Show fewer", today: "Daily rhythm", todayLead: "Take a moment to observe today's pace.",
    classroom: "STUDY ROOM", classroomTitle: "Begin with the basics", libraryTitle: "Read the classics online",
    libraryLead: "Browse introductory notes on Eastern cultural traditions.", enter: "Open the library", viewToday: "Explore daily rhythm",
    choose: "Create a structured chart", free: "Explore the chart for free", report: "Unlock a full reading", ask: "Continue with a question",
  },
  "zh-Hans": {
    eyebrow: "东方传统文化 · 七种语言", headline: "读懂自己的命盘，\n从一个问题开始",
    description: "选择你最想了解的方向，输入出生时间，即刻生成排盘与解读。先免费查看，再决定是否深入。",
    prompt: "你想了解什么？", freeChart: "免费排盘并查看解读", discover: "按问选术，不必懂术语",
    viewAll: "查看全部 {n} 种研习方法", showLess: "收起", today: "每日节律", todayLead: "留一点时间，观察今天的节奏。",
    classroom: "研习课堂", classroomTitle: "从基础开始阅读", libraryTitle: "经典笔记，在线研读",
    libraryLead: "整理传统文化入门材料，逐篇阅读。", enter: "进入藏经阁", viewToday: "查看今日节律",
    choose: "经典规则排盘", free: "免费查看盘面", report: "解锁完整解读", ask: "有疑问，继续提问",
  },
  "zh-Hant": {
    eyebrow: "東方傳統文化 · 七種語言", headline: "讀懂自己的命盤，\n從一個問題開始",
    description: "選擇你最想了解的方向，輸入出生時間，即刻生成排盤與解讀。先免費查看，再決定是否深入。",
    prompt: "你想了解什麼？", freeChart: "免費排盤並查看解讀", discover: "按問選術，不必懂術語",
    viewAll: "查看全部 {n} 種研習方法", showLess: "收起", today: "每日節律", todayLead: "留一點時間，觀察今天的節奏。",
    classroom: "研習課堂", classroomTitle: "從基礎開始閱讀", libraryTitle: "經典筆記，線上研讀",
    libraryLead: "整理傳統文化入門材料，逐篇閱讀。", enter: "進入藏經閣", viewToday: "查看今日節律",
    choose: "經典規則排盤", free: "免費查看盤面", report: "解鎖完整解讀", ask: "有疑問，繼續提問",
  },
  ja: {
    eyebrow: "東洋の伝統文化 · 7言語", headline: "自分の命式を、\nひとつの問いから読む",
    description: "知りたいテーマを選び、生年月日時を入力すると、すぐに命式と解説を作成します。まず無料で見て、深めるかはその後で。",
    prompt: "何を知りたいですか？", freeChart: "無料で命式を作成", discover: "術ではなく、問いから選ぶ",
    viewAll: "{n}の研究方法をすべて見る", showLess: "閉じる", today: "今日のリズム", todayLead: "少し立ち止まって、今日の流れを眺めてみましょう。",
    classroom: "学びの教室", classroomTitle: "基礎から読む", libraryTitle: "古典ノートをオンラインで",
    libraryLead: "伝統文化の入門資料を一篇ずつ読めます。", enter: "蔵書へ", viewToday: "今日のリズムを見る",
    choose: "古典の規則で命式作成", free: "命式は無料で閲覧", report: "詳しい解説を解除", ask: "疑問があれば続けて質問",
  },
  ko: {
    eyebrow: "동양 전통문화 · 7개 언어", headline: "나의 명반을\n한 가지 질문에서 읽다",
    description: "알고 싶은 주제를 고르고 출생 시각을 입력하면 바로 명반과 해설을 만듭니다. 먼저 무료로 보고 더 깊이 볼지 정하세요.",
    prompt: "무엇이 궁금하신가요?", freeChart: "무료로 명반 만들기", discover: "술법이 아니라 질문으로 고르기",
    viewAll: "학습 방법 {n}가지 모두 보기", showLess: "접기", today: "오늘의 리듬", todayLead: "잠시 멈추어 오늘의 흐름을 살펴보세요.",
    classroom: "학습 교실", classroomTitle: "기초부터 읽기", libraryTitle: "고전 노트를 온라인으로",
    libraryLead: "전통문화 입문 자료를 한 편씩 읽어 보세요.", enter: "장서각 들어가기", viewToday: "오늘의 리듬 보기",
    choose: "고전 규칙으로 명반 계산", free: "명반은 무료로 보기", report: "전체 해설 열기", ask: "궁금하면 이어서 질문",
  },
  vi: {
    eyebrow: "VĂN HÓA TRUYỀN THỐNG PHƯƠNG ĐÔNG · 7 NGÔN NGỮ", headline: "Hiểu lá số của bạn,\ntừ một câu hỏi",
    description: "Chọn chủ đề, nhập ngày giờ sinh và xem lá số miễn phí trước khi quyết định có tìm hiểu sâu hơn hay không.",
    prompt: "Bạn muốn tìm hiểu điều gì?", freeChart: "Lập lá số miễn phí", discover: "Chọn theo câu hỏi, không cần biết thuật ngữ",
    viewAll: "Xem cả {n} phương pháp", showLess: "Thu gọn", today: "Nhịp ngày", todayLead: "Dành một chút thời gian quan sát nhịp hôm nay.",
    classroom: "LỚP HỌC", classroomTitle: "Bắt đầu từ cơ bản", libraryTitle: "Đọc kinh điển trực tuyến",
    libraryLead: "Tài liệu nhập môn về văn hóa truyền thống, đọc từng bài.", enter: "Vào thư viện", viewToday: "Xem nhịp hôm nay",
    choose: "Lập lá số theo quy tắc kinh điển", free: "Xem lá số miễn phí", report: "Mở bài giải đầy đủ", ask: "Còn thắc mắc thì hỏi tiếp",
  },
  th: {
    eyebrow: "วัฒนธรรมดั้งเดิมตะวันออก · 7 ภาษา", headline: "เข้าใจดวงของคุณ\nจากคำถามเดียว",
    description: "เลือกหัวข้อ ใส่วันเวลาเกิด แล้วดูผังดวงฟรีก่อน จากนั้นค่อยตัดสินใจว่าจะศึกษาลึกขึ้นหรือไม่",
    prompt: "คุณอยากรู้เรื่องอะไร?", freeChart: "สร้างผังดวงฟรี", discover: "เลือกจากคำถาม ไม่ต้องรู้ศัพท์",
    viewAll: "ดูวิธีศึกษาทั้ง {n} แบบ", showLess: "ย่อรายการ", today: "จังหวะประจำวัน", todayLead: "หยุดสักครู่เพื่อสังเกตจังหวะของวันนี้",
    classroom: "ห้องเรียน", classroomTitle: "เริ่มจากพื้นฐาน", libraryTitle: "อ่านตำราออนไลน์",
    libraryLead: "เอกสารเบื้องต้นเรื่องวัฒนธรรมดั้งเดิม อ่านทีละบท", enter: "เข้าห้องสมุด", viewToday: "ดูจังหวะวันนี้",
    choose: "คำนวณตามกฎตำรา", free: "ดูผังดวงฟรี", report: "ปลดล็อกคำอธิบายฉบับเต็ม", ask: "มีข้อสงสัยถามต่อได้",
  },
};
