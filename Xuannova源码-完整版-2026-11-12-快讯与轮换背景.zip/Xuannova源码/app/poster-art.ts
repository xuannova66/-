// Decorative layers for the share posters (canvas 2D, no images): rice paper grain, ink-wash mountains,
// irregular ink blots, an ensō brush ring, gold-foil gradients, auspicious clouds, a cinnabar seal, mist and stars.
// Everything is drawn from a seed so the same day gives the same picture.

type Ctx = CanvasRenderingContext2D;

// iOS 15 and older Android browsers have no ctx.roundRect: add a small stand-in (number or [r] radius) so posters still draw.
if (typeof CanvasRenderingContext2D !== "undefined" && !CanvasRenderingContext2D.prototype.roundRect) {
  CanvasRenderingContext2D.prototype.roundRect = function roundRect(this: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, radii?: number | DOMPointInit | Iterable<number | DOMPointInit>) {
    const first = Array.isArray(radii) ? radii[0] : radii;
    const r = Math.max(0, Math.min(typeof first === "number" ? first : 0, Math.abs(w) / 2, Math.abs(h) / 2));
    this.moveTo(x + r, y); this.lineTo(x + w - r, y); this.quadraticCurveTo(x + w, y, x + w, y + r);
    this.lineTo(x + w, y + h - r); this.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    this.lineTo(x + r, y + h); this.quadraticCurveTo(x, y + h, x, y + h - r);
    this.lineTo(x, y + r); this.quadraticCurveTo(x, y, x + r, y); this.closePath();
  };
}

/** Whether this browser can hand an image file to the system share sheet (phones yes, most desktops no). */
export function canShareImages() {
  try {
    const nav = navigator as Navigator & { canShare?: (data: { files: File[] }) => boolean };
    return typeof nav.share === "function" && Boolean(nav.canShare?.({ files: [new File([new Uint8Array(1)], "x.png", { type: "image/png" })] }));
  } catch { return false; }
}

export function seeded(seedText: string) {
  let seed = [...seedText].reduce((sum, ch) => (Math.imul(sum, 31) + ch.charCodeAt(0)) >>> 0, 2166136261);
  return () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 2 ** 32; };
}

export function hexToRgb(hex: string) {
  const value = parseInt(hex.slice(1), 16);
  return { r: (value >> 16) & 255, g: (value >> 8) & 255, b: value & 255 };
}
export const rgba = (hex: string, alpha: number) => { const { r, g, b } = hexToRgb(hex); return `rgba(${r},${g},${b},${alpha})`; };
/** Mix a colour toward white (amount > 0) or black (amount < 0). */
export function shadeHex(hex: string, amount: number) {
  const { r, g, b } = hexToRgb(hex);
  const mix = (c: number) => Math.round(amount >= 0 ? c + (255 - c) * amount : c * (1 + amount));
  return `#${[mix(r), mix(g), mix(b)].map((c) => c.toString(16).padStart(2, "0")).join("")}`;
}
const luminance = (hex: string) => { const { r, g, b } = hexToRgb(hex); return (0.299 * r + 0.587 * g + 0.114 * b) / 255; };
export const isDark = (hex: string) => luminance(hex) < 0.45;

/** Rice-paper background: a soft tinted gradient, fibres and speckles. */
export function paper(ctx: Ctx, w: number, h: number, base: string, tint: string, rand: () => number) {
  const bg = ctx.createLinearGradient(0, 0, w, h);
  bg.addColorStop(0, shadeHex(base, 0.25)); bg.addColorStop(0.55, base); bg.addColorStop(1, shadeHex(base, -0.05));
  ctx.fillStyle = bg; ctx.fillRect(0, 0, w, h);
  const wash = ctx.createRadialGradient(w * 0.5, h * 0.33, 40, w * 0.5, h * 0.33, h * 0.6);
  wash.addColorStop(0, rgba(tint, 0.16)); wash.addColorStop(1, rgba(tint, 0));
  ctx.fillStyle = wash; ctx.fillRect(0, 0, w, h);
  ctx.save();
  for (let i = 0; i < 260; i += 1) { // fibres
    ctx.strokeStyle = `rgba(120,95,60,${0.03 + rand() * 0.05})`; ctx.lineWidth = 0.6 + rand();
    const x = rand() * w, y = rand() * h, len = 12 + rand() * 50, a = rand() * Math.PI;
    ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + Math.cos(a) * len * 0.5 + rand() * 6, y + Math.sin(a) * len * 0.5, x + Math.cos(a) * len, y + Math.sin(a) * len); ctx.stroke();
  }
  for (let i = 0; i < 1600; i += 1) { ctx.fillStyle = `rgba(90,70,40,${rand() * 0.07})`; ctx.fillRect(rand() * w, rand() * h, 1.4, 1.4); }
  ctx.restore();
}

/** Layered ink-wash mountains along the bottom, fading into mist. */
export function mountains(ctx: Ctx, w: number, baseY: number, color: string, rand: () => number, layers = 3) {
  for (let layer = 0; layer < layers; layer += 1) {
    const y = baseY + layer * 70, amp = 170 - layer * 40, alpha = 0.14 + layer * 0.1;
    const grad = ctx.createLinearGradient(0, y - amp, 0, y + 260);
    grad.addColorStop(0, rgba(color, alpha)); grad.addColorStop(0.6, rgba(color, alpha * 0.45)); grad.addColorStop(1, rgba(color, 0));
    ctx.fillStyle = grad;
    ctx.beginPath(); ctx.moveTo(0, y + 300);
    let x = -40, py = y - rand() * amp * 0.4;
    ctx.lineTo(x, py);
    while (x < w + 40) {
      const step = 70 + rand() * 120;
      const peak = y - amp * (0.35 + rand() * 0.65);
      ctx.quadraticCurveTo(x + step * 0.45, peak, x + step, y - rand() * amp * 0.35);
      x += step;
    }
    ctx.lineTo(w + 40, y + 300); ctx.closePath(); ctx.fill();
    // mist band
    const mist = ctx.createLinearGradient(0, y - 20, 0, y + 90);
    mist.addColorStop(0, "rgba(255,255,255,0)"); mist.addColorStop(0.5, "rgba(255,255,255,.22)"); mist.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = mist; ctx.fillRect(0, y - 20, w, 110);
  }
}

/** An irregular ink blot: many overlapping translucent lobes, darker core, feathered edge and splashes. */
export function inkBlot(ctx: Ctx, cx: number, cy: number, r: number, color: string, rand: () => number) {
  ctx.save();
  const halo = ctx.createRadialGradient(cx, cy, r * 0.6, cx, cy, r * 1.35);
  halo.addColorStop(0, rgba(color, 0.25)); halo.addColorStop(1, rgba(color, 0));
  ctx.fillStyle = halo; ctx.beginPath(); ctx.arc(cx, cy, r * 1.35, 0, Math.PI * 2); ctx.fill();
  for (let i = 0; i < 34; i += 1) {
    const a = rand() * Math.PI * 2, d = rand() * r * 0.28, rr = r * (0.55 + rand() * 0.45);
    const x = cx + Math.cos(a) * d, y = cy + Math.sin(a) * d;
    const g = ctx.createRadialGradient(x, y, rr * 0.2, x, y, rr);
    g.addColorStop(0, rgba(color, 0.22)); g.addColorStop(0.75, rgba(color, 0.16)); g.addColorStop(1, rgba(color, 0));
    ctx.fillStyle = g; ctx.beginPath();
    for (let k = 0; k <= 28; k += 1) { const t = (k / 28) * Math.PI * 2, wob = rr * (0.9 + rand() * 0.14); ctx.lineTo(x + Math.cos(t) * wob, y + Math.sin(t) * wob); }
    ctx.fill();
  }
  // solid core so the real colour reads true
  const core = ctx.createRadialGradient(cx - r * 0.15, cy - r * 0.2, r * 0.05, cx, cy, r * 0.82);
  core.addColorStop(0, shadeHex(color, 0.18)); core.addColorStop(0.55, color); core.addColorStop(1, rgba(color, 0));
  ctx.fillStyle = core; ctx.beginPath(); ctx.arc(cx, cy, r * 0.82, 0, Math.PI * 2); ctx.fill();
  // splashes
  for (let i = 0; i < 26; i += 1) {
    const a = rand() * Math.PI * 2, d = r * (1.05 + rand() * 0.45), s = 2 + rand() * 9;
    ctx.fillStyle = rgba(color, 0.35 + rand() * 0.5); ctx.beginPath(); ctx.arc(cx + Math.cos(a) * d, cy + Math.sin(a) * d, s, 0, Math.PI * 2); ctx.fill();
  }
  // light sheen
  const sheen = ctx.createRadialGradient(cx - r * 0.35, cy - r * 0.4, 4, cx - r * 0.35, cy - r * 0.4, r * 0.55);
  sheen.addColorStop(0, "rgba(255,255,255,.28)"); sheen.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = sheen; ctx.beginPath(); ctx.arc(cx, cy, r * 0.82, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}

/** A gold-foil gradient across a box. */
export function goldFoil(ctx: Ctx, x0: number, y0: number, x1: number, y1: number) {
  const g = ctx.createLinearGradient(x0, y0, x1, y1);
  g.addColorStop(0, "#8a6424"); g.addColorStop(0.18, "#e9cd84"); g.addColorStop(0.35, "#b48a3c"); g.addColorStop(0.52, "#f7e3a8"); g.addColorStop(0.7, "#a87d32"); g.addColorStop(0.86, "#e3c070"); g.addColorStop(1, "#7d5a1f");
  return g;
}

/** An ensō: one dry-brush stroke that almost closes a circle. */
export function enso(ctx: Ctx, cx: number, cy: number, r: number, stroke: string | CanvasGradient, rand: () => number, width = 16) {
  ctx.save(); ctx.lineCap = "round"; ctx.strokeStyle = stroke;
  const start = -Math.PI * 0.62, sweep = Math.PI * 1.86;
  for (let pass = 0; pass < 7; pass += 1) {
    ctx.globalAlpha = 0.18 + rand() * 0.25;
    ctx.lineWidth = width * (0.35 + rand() * 0.7);
    ctx.beginPath();
    for (let k = 0; k <= 90; k += 1) {
      const t = k / 90, a = start + sweep * t;
      const rr = r + Math.sin(t * 9 + pass) * 3 + (pass - 3) * 1.6;
      const taper = t > 0.85 ? 1 - (t - 0.85) * 4 : 1;
      if (taper <= 0.05) break;
      const px = cx + Math.cos(a) * rr, py = cy + Math.sin(a) * rr;
      if (k === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    ctx.stroke();
  }
  ctx.restore();
}

/** A square cinnabar seal with 1–4 characters (white on red, slightly worn). */
export function seal(ctx: Ctx, x: number, y: number, size: number, text: string, rand: () => number, color = "#b8322a") {
  ctx.save();
  ctx.translate(x, y); ctx.rotate((rand() - 0.5) * 0.08);
  ctx.fillStyle = color; ctx.beginPath(); ctx.roundRect(-size / 2, -size / 2, size, size, size * 0.08); ctx.fill();
  ctx.strokeStyle = "rgba(255,240,230,.85)"; ctx.lineWidth = size * 0.035; ctx.strokeRect(-size / 2 + size * 0.08, -size / 2 + size * 0.08, size * 0.84, size * 0.84);
  ctx.fillStyle = "rgba(255,244,236,.95)"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
  const chars = [...text];
  if (chars.length <= 1) { ctx.font = `700 ${size * 0.6}px "Noto Serif SC", serif`; ctx.fillText(text, 0, size * 0.03); }
  else {
    // one column, top to bottom (2 characters), or two columns read right to left (3–4 characters)
    if (chars.length === 2) { ctx.font = `700 ${size * 0.38}px "Noto Serif SC", serif`; ctx.fillText(chars[0], 0, -size * 0.19); ctx.fillText(chars[1], 0, size * 0.21); }
    else {
      ctx.font = `700 ${size * 0.34}px "Noto Serif SC", serif`;
      const cols = [chars.slice(0, 2), chars.slice(2)];
      cols.forEach((col, ci) => col.forEach((ch, ri) => ctx.fillText(ch, (ci === 0 ? 1 : -1) * size * 0.2, (ri === 0 ? -1 : 1) * size * 0.19)));
    }
  }
  // worn spots
  ctx.globalCompositeOperation = "destination-out";
  for (let i = 0; i < 40; i += 1) { ctx.fillStyle = `rgba(0,0,0,${0.3 + rand() * 0.5})`; ctx.beginPath(); ctx.arc((rand() - 0.5) * size, (rand() - 0.5) * size, rand() * size * 0.025, 0, Math.PI * 2); ctx.fill(); }
  ctx.restore();
}

/** An auspicious cloud (祥云) motif: a curl of spirals with a tail. */
export function cloud(ctx: Ctx, x: number, y: number, s: number, stroke: string | CanvasGradient, flip = false) {
  ctx.save(); ctx.translate(x, y); ctx.scale(flip ? -s : s, s);
  ctx.strokeStyle = stroke; ctx.lineWidth = 3.2 / s * s; ctx.lineCap = "round";
  const spiral = (cx: number, cy: number, r: number, turns: number) => {
    ctx.beginPath();
    for (let k = 0; k <= 60; k += 1) { const t = k / 60, a = Math.PI + t * turns * Math.PI * 2, rr = r * (1 - t * 0.78); const px = cx + Math.cos(a) * rr, py = cy + Math.sin(a) * rr; if (k === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py); }
    ctx.stroke();
  };
  spiral(0, 0, 26, 1.2); spiral(40, -12, 20, 1.1); spiral(72, 4, 16, 1.0);
  ctx.beginPath(); ctx.moveTo(-26, 0); ctx.bezierCurveTo(-30, 30, 30, 34, 60, 22); ctx.bezierCurveTo(90, 12, 110, 26, 140, 20); ctx.stroke();
  ctx.restore();
}

/** Corner ornaments: double gold bracket lines. */
export function corners(ctx: Ctx, x: number, y: number, w: number, h: number, len: number, stroke: string | CanvasGradient, width = 3) {
  ctx.save(); ctx.strokeStyle = stroke; ctx.lineWidth = width;
  const pts: Array<[number, number, number, number]> = [[x, y, 1, 1], [x + w, y, -1, 1], [x, y + h, 1, -1], [x + w, y + h, -1, -1]];
  for (const [px, py, dx, dy] of pts) {
    for (const off of [0, 14]) {
      ctx.beginPath(); ctx.moveTo(px + dx * off, py + dy * (len + off)); ctx.lineTo(px + dx * off, py + dy * off); ctx.lineTo(px + dx * (len + off), py + dy * off); ctx.stroke();
    }
    ctx.fillStyle = stroke; ctx.beginPath(); ctx.arc(px + dx * 30, py + dy * 30, 4, 0, Math.PI * 2); ctx.fill();
  }
  ctx.restore();
}

/** A huge faint calligraphy character as a watermark. */
export function watermark(ctx: Ctx, text: string, x: number, y: number, size: number, color: string, alpha: number) {
  ctx.save(); ctx.globalAlpha = alpha; ctx.fillStyle = color; ctx.textAlign = "center"; ctx.textBaseline = "middle";
  ctx.font = `700 ${size}px "Noto Serif SC", "Songti SC", serif`; ctx.fillText(text, x, y); ctx.restore();
}

/** Glowing dust / stars. */
export function sparkles(ctx: Ctx, w: number, h: number, count: number, color: string, rand: () => number, top = 0) {
  ctx.save();
  for (let i = 0; i < count; i += 1) {
    const x = rand() * w, y = top + rand() * (h - top), r = 0.8 + rand() * 2.6;
    const g = ctx.createRadialGradient(x, y, 0, x, y, r * 4); g.addColorStop(0, rgba(color, 0.9)); g.addColorStop(1, rgba(color, 0));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r * 4, 0, Math.PI * 2); ctx.fill();
  }
  ctx.restore();
}

/** A thin ring of 24 ticks with 8 longer ones (the solar terms and the eight trigrams). */
export function tickRing(ctx: Ctx, cx: number, cy: number, r: number, stroke: string | CanvasGradient) {
  ctx.save(); ctx.strokeStyle = stroke;
  for (let i = 0; i < 72; i += 1) {
    const a = (i / 72) * Math.PI * 2, long = i % 9 === 0, mid = i % 3 === 0;
    ctx.lineWidth = long ? 3 : 1.5;
    const r0 = r - (long ? 22 : mid ? 12 : 6);
    ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0); ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r); ctx.stroke();
  }
  ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(cx, cy, r + 8, 0, Math.PI * 2); ctx.stroke();
  ctx.restore();
}
