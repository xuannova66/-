"use client";
// 分享来源统计 (browser side): remember which shared poster or link brought this visitor (first one only, 60 days),
// so a new account can be credited to it, and send anonymous daily counts of posters made, saved and shared.
export type ShareSource = "daily-card" | "action-card" | "almanac-card" | "lamp-card" | "chart-card" | "invite-link" | "flash-card";
const SOURCES: ShareSource[] = ["daily-card", "action-card", "almanac-card", "lamp-card", "chart-card", "invite-link", "flash-card"];

export function countShare(source: ShareSource, action: "made" | "saved" | "shared" | "visit") {
  try { void fetch("/api/stats/share", { method: "POST", credentials: "same-origin", keepalive: true, headers: { "content-type": "application/json" }, body: JSON.stringify({ source, action }) }).catch(() => undefined); } catch { /* offline */ }
}

/** Call once on page load. */
export function captureShareSource() {
  if (typeof window === "undefined") return;
  const value = new URLSearchParams(window.location.search).get("utm_source") ?? "";
  const source = SOURCES.find((item) => item === value);
  if (!source) return;
  if (!/(?:^|;\s*)xn_src=/.test(document.cookie)) document.cookie = `xn_src=${source}; Max-Age=${60 * 86400}; Path=/; SameSite=Lax${location.protocol === "https:" ? "; Secure" : ""}`;
  try { if (sessionStorage.getItem("xn.src.seen") === source) return; sessionStorage.setItem("xn.src.seen", source); } catch { /* storage blocked */ }
  countShare(source, "visit");
}
