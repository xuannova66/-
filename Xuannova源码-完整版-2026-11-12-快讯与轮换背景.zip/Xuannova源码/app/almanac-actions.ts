// 现代版黄历「今日行动指南」: the almanac's traditional 宜 / 忌 entries rendered as everyday modern actions in 7 languages.
// Funeral and grave entries (安葬, 入殓, 修坟 …) are left off the share card; the full almanac page still shows everything.
import type { Locale } from "./site-content";
import type { AlmanacDay } from "./almanac";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

/** Modern actions for the common almanac terms (several terms can share one action). */
const ACTIONS: Array<{ terms: string[]; text: L7 }> = [
  { terms: ["嫁娶", "纳采", "订盟", "问名", "纳婿"], text: L("Big commitments", "确定关系、重要承诺", "確定關係、重要承諾", "大切な約束・関係を決める", "중요한 약속·관계 확정", "Cam kết quan trọng", "ตัดสินใจเรื่องสำคัญ") },
  { terms: ["开市", "挂匾"], text: L("Launches & openings", "开业上线、发布新品", "開業上線、發布新品", "開業・新しいリリース", "오픈·런칭", "Khai trương, ra mắt", "เปิดตัว เปิดกิจการ") },
  { terms: ["交易", "立券"], text: L("Business talks & contracts", "商务谈判、签约", "商務談判、簽約", "商談・契約", "비즈니스 협상·계약", "Đàm phán, ký kết", "เจรจาธุรกิจ เซ็นสัญญา") },
  { terms: ["纳财", "置产"], text: L("Saving & investing plans", "理财储蓄、置办资产", "理財儲蓄、置辦資產", "貯蓄・資産づくり", "저축·자산 계획", "Tiết kiệm, đầu tư", "ออมเงิน วางแผนการเงิน") },
  { terms: ["出货财", "开仓"], text: L("Spending & shipping out", "大额支出、发货出仓", "大額支出、發貨出倉", "大きな支出・出荷", "큰 지출·출고", "Chi tiêu lớn, xuất hàng", "ใช้จ่ายก้อนใหญ่ ส่งของ") },
  { terms: ["出行", "乘船", "赴任"], text: L("Travel & new posts", "出行旅行、赴任新岗", "出行旅行、赴任新崗", "旅行・新しい赴任", "여행·새 부임", "Đi xa, nhận việc mới", "เดินทาง เริ่มงานใหม่") },
  { terms: ["入宅", "移徙"], text: L("Moving home", "搬家、入住新居", "搬家、入住新居", "引っ越し・新居入り", "이사·새집 입주", "Chuyển nhà", "ย้ายบ้าน") },
  { terms: ["动土", "破土", "修造", "起基", "盖屋", "上梁", "竖柱", "拆卸", "作梁"], text: L("Renovation & building", "装修动工、施工", "裝修動工、施工", "リフォーム・着工", "공사·리모델링", "Sửa chữa, khởi công", "ซ่อมแซม ก่อสร้าง") },
  { terms: ["安床", "合帐"], text: L("Refreshing the bedroom", "整理卧室、换床品", "整理臥室、換床品", "寝室を整える", "침실 정돈", "Sắp xếp phòng ngủ", "จัดห้องนอน") },
  { terms: ["作灶"], text: L("Kitchen projects", "厨房整理、下厨宴客", "廚房整理、下廚宴客", "キッチンの手入れ", "주방 정리", "Việc bếp núc", "จัดการครัว") },
  { terms: ["扫舍", "解除"], text: L("Decluttering & letting go", "大扫除、断舍离", "大掃除、斷捨離", "大掃除・断捨離", "대청소·정리", "Dọn dẹp, buông bỏ", "ทำความสะอาด ปล่อยวาง") },
  { terms: ["沐浴", "整手足甲"], text: L("Self-care", "沐浴放松、自我护理", "沐浴放鬆、自我護理", "セルフケア", "셀프케어", "Chăm sóc bản thân", "ดูแลตัวเอง") },
  { terms: ["理发", "冠笄", "裁衣"], text: L("Haircut & new look", "理发造型、添置新衣", "理髮造型、添置新衣", "ヘアカット・装いを新しく", "헤어·새 옷", "Cắt tóc, đổi phong cách", "ตัดผม แต่งตัวใหม่") },
  { terms: ["会亲友", "归宁"], text: L("Meeting friends & family", "会友聚会、探亲", "會友聚會、探親", "友人・家族と会う", "친구·가족 만남", "Gặp gỡ bạn bè, người thân", "พบเพื่อนและครอบครัว") },
  { terms: ["入学", "习艺"], text: L("Learning something new", "开始学习、拜师学艺", "開始學習、拜師學藝", "新しい学び", "새로운 배움", "Học điều mới", "เรียนรู้สิ่งใหม่") },
  { terms: ["祈福", "祭祀", "斋醮", "安香", "开光"], text: L("Gratitude & wishes", "感恩祈愿、静心", "感恩祈願、靜心", "感謝と祈り", "감사와 소원", "Biết ơn, cầu nguyện", "ขอบคุณและอธิษฐาน") },
  { terms: ["栽种", "纳畜", "牧养", "教牛马"], text: L("Plants & pets", "种植园艺、照顾宠物", "種植園藝、照顧寵物", "植物・ペットの世話", "식물·반려동물 돌보기", "Cây cảnh, thú cưng", "ปลูกต้นไม้ ดูแลสัตว์เลี้ยง") },
  { terms: ["治病", "求医", "针灸", "探病"], text: L("Health check-ups", "看医生、做体检", "看醫生、做體檢", "受診・健康チェック", "진료·건강검진", "Khám sức khỏe", "ตรวจสุขภาพ") },
  { terms: ["进人口", "雇佣"], text: L("Hiring & welcoming people", "招人、迎新成员", "招人、迎新成員", "採用・仲間を迎える", "채용·새 구성원 맞이", "Tuyển người, đón thành viên", "รับคนใหม่") },
  { terms: ["结网"], text: L("Networking", "拓展人脉", "拓展人脈", "人脈づくり", "인맥 넓히기", "Mở rộng quan hệ", "สร้างเครือข่าย") },
  { terms: ["词讼"], text: L("Arguments & lawsuits", "争执诉讼", "爭執訴訟", "口論・訴訟", "다툼·소송", "Tranh cãi, kiện tụng", "โต้เถียง ฟ้องร้อง") },
  { terms: ["平治道涂", "修饰垣墙", "补垣"], text: L("Fixing what's broken", "修补整理、扫清障碍", "修補整理、掃清障礙", "壊れた所を直す", "고장 난 것 고치기", "Sửa chữa, dọn chướng ngại", "ซ่อมสิ่งที่เสีย") },
  { terms: ["造车器", "安机械", "雕刻", "塑绘"], text: L("Making & tinkering", "动手制作、创作", "動手製作、創作", "ものづくり・創作", "만들기·창작", "Chế tác, sáng tạo", "ลงมือทำ สร้างสรรค์") },
  { terms: ["求嗣"], text: L("Family plans", "家庭计划", "家庭計劃", "家族の計画", "가족 계획", "Kế hoạch gia đình", "วางแผนครอบครัว") },
];
const SKIP = new Set(["安葬", "入殓", "移柩", "成服", "除服", "行丧", "修坟", "立碑", "启钻", "开生坟", "合寿木", "谢土", "破屋", "坏垣", "畋猎", "捕捉", "取渔", "断蚁", "割蜜", "无", "普渡", "归岫", "分居"]);
const lookup = new Map<string, L7>(ACTIONS.flatMap((action) => action.terms.map((term) => [term, action.text] as const)));

const REST = L("Rest and recharge", "休养生息、按部就班", "休養生息、按部就班", "休んで充電", "휴식과 재충전", "Nghỉ ngơi, nạp năng lượng", "พักผ่อน เติมพลัง");
const IMPULSE = L("Impulse decisions", "冲动决定", "衝動決定", "衝動的な決断", "충동적인 결정", "Quyết định bốc đồng", "การตัดสินใจหุนหันพลันแล่น");

/** Up to `limit` modern actions for the day's 宜 and 忌 (distinct, in the almanac's order). */
export function actionGuide(day: Pick<AlmanacDay, "yi" | "ji">, locale: Locale, limit = 3) {
  const pick = (terms: string[]) => {
    const out: string[] = [];
    for (const term of terms) {
      if (SKIP.has(term)) continue;
      const text = lookup.get(term)?.[locale];
      if (text && !out.includes(text)) out.push(text);
      if (out.length >= limit) break;
    }
    return out;
  };
  const restDay = day.yi.some((term) => term === "诸事不宜" || term === "馀事勿取" || term === "余事勿取") && pick(day.yi).length === 0;
  const suitable = restDay ? [REST[locale]] : pick(day.yi);
  const avoid = pick(day.ji.filter((term) => term !== "馀事勿取" && term !== "余事勿取" && term !== "诸事不宜"));
  return { suitable: suitable.length ? suitable : [REST[locale]], avoid: avoid.length ? avoid : [IMPULSE[locale]] };
}
