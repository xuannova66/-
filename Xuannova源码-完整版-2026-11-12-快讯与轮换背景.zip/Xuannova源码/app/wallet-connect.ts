"use client";

/**
 * Browser wallet integration for MetaMask, TokenPocket, Binance Web3 Wallet and OKX Wallet.
 *
 * Discovery uses EIP-6963 (all four wallets announce themselves) with legacy
 * `window.*` fallbacks. Payments go through the XuanyuanCreditStore contract on
 * BSC: `approve` USDT if needed, then `buy(packageId)` with the BNB platform fee.
 */
import {
  createPublicClient,
  createWalletClient,
  custom,
  http,
  type Transport,
  fallback,
  getAddress,
  type Address,
  type EIP1193Provider,
  type Hex,
} from "viem";
import { bsc, bscTestnet } from "viem/chains";
import { creditPackages, packageUsdtWei, walletProviders, type WalletProviderId } from "../worker/commerce-policy";
import { creditStoreAbi, erc20Abi, packageKey } from "../worker/wallet-chain";
import { BSC_USDC_ASSETS, BSC_V2_ROUTER, EXTRA_CHECKOUT_TOKENS, quoteUsdcPayment, type UsdcPaymentToken, type UsdcQuote } from "./usdc-payment-quote";
import { treasuryAddress, platformFeeRecipient } from "../worker/commerce-policy";

type EIP6963ProviderDetail = { info: { uuid: string; name: string; icon: string; rdns: string }; provider: EIP1193Provider };

type WindowWithWallets = Window & {
  ethereum?: EIP1193Provider & { providers?: EIP1193Provider[]; isMetaMask?: boolean; isTokenPocket?: boolean; isOkxWallet?: boolean; isBinance?: boolean };
  okxwallet?: EIP1193Provider;
  tokenpocket?: { ethereum?: EIP1193Provider };
  binancew3w?: { ethereum?: EIP1193Provider };
  BinanceChain?: EIP1193Provider;
};

export type WalletOption = { id: WalletProviderId; label: string; installed: boolean; icon?: string };

export type CheckoutConfig = {
  chainId: number;
  chainHexId: string;
  chainName: string;
  nativeSymbol: string;
  rpcUrls: string[];
  explorerUrl: string;
  testnet: boolean;
  usdtAddress: Address | null;
  contractAddress: Address | null;
  platformFeeWei: string;
  confirmations: number;
  enabled: boolean;
  usdcCheckoutAddress?: Address | null;
  usdcOnly?: boolean;
  /** Extra BNB Chain coins enabled on the server (MultiCoinCheckout). */
  checkoutTokens?: string[];
  multichainWalletLinkEnabled?: boolean;
};

const usdcCheckoutAbi = [
  { type: "function", name: "buy", stateMutability: "payable", inputs: [{ name: "id", type: "bytes32" }, { name: "token", type: "address" }, { name: "maxInput", type: "uint256" }, { name: "path", type: "address[]" }, { name: "deadline", type: "uint256" }], outputs: [] },
  ...(["usdc", "usdt", "aster", "router", "treasury", "feeRecipient"] as const).map((name) => ({ type: "function" as const, name, stateMutability: "view" as const, inputs: [], outputs: [{ name: "", type: "address" }] })),
  { type: "function", name: "feeWei", stateMutability: "view", inputs: [], outputs: [{ name: "", type: "uint256" }] },
  { type: "function", name: "allowedToken", stateMutability: "view", inputs: [{ name: "token", type: "address" }], outputs: [{ name: "", type: "bool" }] },
] as const;
const routerQuoteAbi = [{ type: "function", name: "getAmountsIn", stateMutability: "view", inputs: [{ name: "amountOut", type: "uint256" }, { name: "path", type: "address[]" }], outputs: [{ name: "amounts", type: "uint256[]" }] }] as const;

/** A quote is read-only; caller must display the maximum amount and obtain explicit confirmation before buying. */
export async function getUsdcCheckoutQuote(input: { provider?: EIP1193Provider; config: CheckoutConfig; packageId: string; token: UsdcPaymentToken }): Promise<UsdcQuote> {
  if (input.config.chainId !== 56 || !input.config.usdcCheckoutAddress) throw new WalletError("NOT_CONFIGURED", "USDC checkout is not enabled");
  const item = creditPackages.find((entry) => entry.id === input.packageId);
  if (!item) throw new WalletError("FAILED", "Unknown package");
  // The quote is a read-only call: public BSC RPCs are enough, so no wallet prompt or network switch is needed for it.
  const transports: Transport[] = input.config.rpcUrls.map((url) => http(url));
  if (input.provider) { await ensureBscNetwork(input.provider, input.config); transports.unshift(custom(input.provider)); }
  if (!transports.length) throw new WalletError("NOT_CONFIGURED", "No BSC RPC configured");
  const reader = createPublicClient({ chain: bsc, transport: fallback(transports) });
  return quoteUsdcPayment({ token: input.token, amountOut: packageUsdtWei(item.id), chainId: input.config.chainId, nowSeconds: Math.floor(Date.now() / 1000), slippageBps: 100,
    getAmountsIn: (amountOut, path) => reader.readContract({ address: BSC_V2_ROUTER, abi: routerQuoteAbi, functionName: "getAmountsIn", args: [amountOut, path] }) });
}

/** Never invoke until the displayed quote is explicitly accepted. */
export async function purchaseUsdcPackage(input: { provider: EIP1193Provider; address: Address; packageId: string; config: CheckoutConfig; quote: UsdcQuote; onStage?: (stage: PaymentStage, hash?: Hex) => void }): Promise<Hex> {
  const { provider, address, config, quote } = input;
  if (config.chainId !== 56 || !config.usdcCheckoutAddress) throw new WalletError("NOT_CONFIGURED", "USDC checkout is not enabled");
  const contract = config.usdcCheckoutAddress;
  if (!creditPackages.some((item) => item.id === input.packageId) || quote.amountOut !== packageUsdtWei(input.packageId) || quote.deadline <= BigInt(Math.floor(Date.now() / 1000))) throw new WalletError("FAILED", "Quote expired or package changed");
  await ensureBscNetwork(provider, config);
  const wallet = createWalletClient({ account: address, chain: bsc, transport: custom(provider) });
  const reader = createPublicClient({ chain: bsc, transport: fallback([custom(provider), ...config.rpcUrls.map((url) => http(url))]) });
  const [stable, tether, aster, router, treasury, feeRecipient, fee] = await Promise.all(([["usdc"], ["usdt"], ["aster"], ["router"], ["treasury"], ["feeRecipient"], ["feeWei"]] as const).map(([functionName]) => reader.readContract({ address: contract, abi: usdcCheckoutAbi, functionName })));
  if (typeof stable !== "string" || typeof tether !== "string" || typeof aster !== "string" || typeof router !== "string" || typeof treasury !== "string" || typeof feeRecipient !== "string" || typeof fee !== "bigint" || getAddress(stable) !== getAddress(BSC_USDC_ASSETS.USDC) || getAddress(tether) !== getAddress(BSC_USDC_ASSETS.USDT) || getAddress(aster) !== getAddress(BSC_USDC_ASSETS.ASTER) || getAddress(router) !== getAddress(BSC_V2_ROUTER) || getAddress(treasury) !== getAddress(treasuryAddress) || getAddress(feeRecipient) !== getAddress(platformFeeRecipient) || fee !== BigInt(config.platformFeeWei)) throw new WalletError("FAILED", "Checkout contract configuration mismatch");
  const token = quote.token === "BNB" ? "0x0000000000000000000000000000000000000000" : BSC_USDC_ASSETS[quote.token as Exclude<UsdcPaymentToken, "BNB">];
  // Extra coins need MultiCoinCheckout with the coin allowed; check before asking the wallet for anything.
  if ((EXTRA_CHECKOUT_TOKENS as readonly string[]).includes(quote.token)) {
    const allowed = await reader.readContract({ address: contract, abi: usdcCheckoutAbi, functionName: "allowedToken", args: [token] }).catch(() => false);
    if (allowed !== true) throw new WalletError("NOT_CONFIGURED", `${quote.token} is not enabled on the checkout contract`);
  }
  const native = await reader.getBalance({ address });
  const value = fee + (quote.token === "BNB" ? quote.maxInput : 0n);
  if (native < value) throw new WalletError("INSUFFICIENT_BNB", "Insufficient BNB for payment, platform fee and gas");
  if (quote.token !== "BNB") {
    const [balance, allowance] = await Promise.all([reader.readContract({ address: token, abi: erc20Abi, functionName: "balanceOf", args: [address] }), reader.readContract({ address: token, abi: erc20Abi, functionName: "allowance", args: [address, contract] })]);
    if (balance < quote.maxInput) throw new WalletError("INSUFFICIENT_TOKEN", `Insufficient ${quote.token} balance`);
    if (allowance < quote.maxInput) {
      input.onStage?.("approving");
      if (allowance > 0n) { const reset = await wallet.writeContract({ address: token, abi: erc20Abi, functionName: "approve", args: [contract, 0n] }); if ((await reader.waitForTransactionReceipt({ hash: reset })).status !== "success") throw new WalletError("FAILED", "Allowance reset failed"); }
      const approval = await wallet.writeContract({ address: token, abi: erc20Abi, functionName: "approve", args: [contract, quote.maxInput] });
      if ((await reader.waitForTransactionReceipt({ hash: approval })).status !== "success") throw new WalletError("FAILED", "Approval failed");
    }
  }
  if (quote.deadline <= BigInt(Math.floor(Date.now() / 1000))) throw new WalletError("FAILED", "Quote expired after approval; request a new quote");
  const buyArgs = [packageKey(input.packageId), token, quote.maxInput, quote.path, quote.deadline] as const;
  const gasEstimate = await reader.estimateContractGas({ account: address, address: contract, abi: usdcCheckoutAbi, functionName: "buy", args: buyArgs, value });
  input.onStage?.("paying");
  const hash = await wallet.writeContract({ address: contract, abi: usdcCheckoutAbi, functionName: "buy", args: buyArgs, value, gas: (gasEstimate * 120n + 99n) / 100n });
  input.onStage?.("confirming", hash);
  if ((await reader.waitForTransactionReceipt({ hash, confirmations: config.confirmations })).status !== "success") throw new WalletError("TX_REVERTED", "Transaction reverted");
  return hash;
}

function viemChain(config: CheckoutConfig) {
  return config.chainId === bscTestnet.id ? bscTestnet : bsc;
}

export type PaymentStage = "switching" | "approving" | "paying" | "confirming" | "verifying";

const rdnsByProvider: Record<WalletProviderId, string[]> = {
  metamask: ["io.metamask", "io.metamask.flask"],
  tokenpocket: ["pro.tokenpocket", "com.tokenpocket"],
  binance: ["com.binance.wallet", "com.binance", "com.binance.w3w"],
  okx: ["com.okex.wallet", "com.okx.wallet"],
};

const discovered = new Map<string, EIP6963ProviderDetail>();
let listening = false;

function listenForProviders() {
  if (listening || typeof window === "undefined") return;
  listening = true;
  window.addEventListener("eip6963:announceProvider", (event) => {
    const detail = (event as CustomEvent<EIP6963ProviderDetail>).detail;
    if (detail?.info?.rdns && detail.provider) discovered.set(detail.info.rdns, detail);
  });
  window.dispatchEvent(new Event("eip6963:requestProvider"));
}

/** True inside the TokenPocket app's own browser (its user agent says so, or it injects window.tokenpocket). */
export function inTokenPocket() {
  if (typeof window === "undefined") return false;
  return /TokenPocket/i.test(navigator.userAgent) || Boolean((window as WindowWithWallets).tokenpocket);
}

function legacyProvider(id: WalletProviderId): EIP1193Provider | null {
  if (typeof window === "undefined") return null;
  const w = window as WindowWithWallets;
  const candidates = w.ethereum?.providers ?? (w.ethereum ? [w.ethereum] : []);
  switch (id) {
    case "okx":
      return w.okxwallet ?? candidates.find((p) => (p as { isOkxWallet?: boolean }).isOkxWallet) ?? null;
    case "tokenpocket":
      // Inside the TokenPocket app, window.ethereum is TokenPocket's own provider even when it does not set isTokenPocket
      // (some versions only set isMetaMask). It exists only while an EVM wallet is selected in the app.
      return w.tokenpocket?.ethereum ?? candidates.find((p) => (p as { isTokenPocket?: boolean }).isTokenPocket) ?? (inTokenPocket() ? w.ethereum ?? null : null);
    case "binance":
      return w.binancew3w?.ethereum ?? w.BinanceChain ?? candidates.find((p) => (p as { isBinance?: boolean }).isBinance) ?? null;
    case "metamask":
      if (inTokenPocket()) return null;
      return candidates.find((p) => {
        const flags = p as { isMetaMask?: boolean; isTokenPocket?: boolean; isOkxWallet?: boolean; isBinance?: boolean };
        return flags.isMetaMask && !flags.isTokenPocket && !flags.isOkxWallet && !flags.isBinance;
      }) ?? null;
  }
}

export function providerFor(id: WalletProviderId): EIP1193Provider | null {
  listenForProviders();
  for (const rdns of rdnsByProvider[id]) {
    const detail = discovered.get(rdns);
    if (detail) return detail.provider;
  }
  return legacyProvider(id);
}

/** Wallets the browser exposes right now. Call again after a short delay: EIP-6963 announcements are async. */
export function availableWallets(): WalletOption[] {
  listenForProviders();
  return walletProviders.map((item) => {
    const detail = rdnsByProvider[item.id].map((rdns) => discovered.get(rdns)).find(Boolean);
    return { id: item.id, label: item.label, installed: Boolean(detail ?? legacyProvider(item.id)), icon: detail?.info.icon };
  });
}

export function walletInstallUrl(id: WalletProviderId) {
  return {
    metamask: "https://metamask.io/download/",
    tokenpocket: "https://www.tokenpocket.pro/",
    binance: "https://www.binance.com/en/web3wallet",
    okx: "https://www.okx.com/web3",
  }[id];
}

export function shortAddress(address: string) {
  return `${address.slice(0, 6)}…${address.slice(-4)}`;
}

export class WalletError extends Error {
  constructor(public code: "NOT_INSTALLED" | "REJECTED" | "WRONG_CHAIN" | "INSUFFICIENT_USDT" | "INSUFFICIENT_BNB" | "INSUFFICIENT_TOKEN" | "NOT_CONFIGURED" | "TX_REVERTED" | "FAILED", message: string) {
    super(message);
  }
}

function isRejection(cause: unknown) {
  const code = (cause as { code?: number; cause?: { code?: number } })?.code ?? (cause as { cause?: { code?: number } })?.cause?.code;
  const message = cause instanceof Error ? cause.message.toLowerCase() : "";
  return code === 4001 || message.includes("user rejected") || message.includes("user denied");
}

export async function connectWallet(id: WalletProviderId): Promise<{ address: Address; provider: EIP1193Provider }> {
  const provider = providerFor(id);
  if (!provider) throw new WalletError("NOT_INSTALLED", "Wallet not installed");
  try {
    const accounts = await provider.request({ method: "eth_requestAccounts" }) as string[];
    if (!accounts?.[0]) throw new WalletError("REJECTED", "No account returned");
    return { address: getAddress(accounts[0]), provider };
  } catch (cause) {
    if (cause instanceof WalletError) throw cause;
    throw new WalletError(isRejection(cause) ? "REJECTED" : "FAILED", cause instanceof Error ? cause.message : "Wallet connection failed");
  }
}

export async function signMessage(provider: EIP1193Provider, address: Address, message: string): Promise<Hex> {
  try {
    const client = createWalletClient({ account: address, transport: custom(provider) });
    return await client.signMessage({ account: address, message });
  } catch (cause) {
    throw new WalletError(isRejection(cause) ? "REJECTED" : "FAILED", cause instanceof Error ? cause.message : "Signature failed");
  }
}

export async function ensureBscNetwork(provider: EIP1193Provider, config: CheckoutConfig) {
  const current = await provider.request({ method: "eth_chainId" }) as string;
  if (Number.parseInt(current, 16) === config.chainId) return;
  try {
    await provider.request({ method: "wallet_switchEthereumChain", params: [{ chainId: config.chainHexId }] });
  } catch (cause) {
    const code = (cause as { code?: number })?.code;
    if (code === 4902 || code === -32603) {
      await provider.request({
        method: "wallet_addEthereumChain",
        params: [{
          chainId: config.chainHexId,
          chainName: config.chainName,
          nativeCurrency: { name: config.nativeSymbol, symbol: config.nativeSymbol, decimals: 18 },
          rpcUrls: [...config.rpcUrls],
          blockExplorerUrls: [config.explorerUrl],
        }],
      });
    } else {
      throw new WalletError(isRejection(cause) ? "REJECTED" : "WRONG_CHAIN", `Switch your wallet to ${config.chainName}`);
    }
  }
  const after = await provider.request({ method: "eth_chainId" }) as string;
  if (Number.parseInt(after, 16) !== config.chainId) throw new WalletError("WRONG_CHAIN", `Switch your wallet to ${config.chainName}`);
}

/**
 * Pay for a credit package: approve USDT (if allowance is short), call `buy`
 * with the BNB platform fee, wait for the receipt, and return the tx hash so
 * the worker can verify it.
 */
export async function purchasePackage(input: {
  provider: EIP1193Provider;
  address: Address;
  packageId: string;
  config: CheckoutConfig;
  onStage?: (stage: PaymentStage, hash?: Hex) => void;
}): Promise<Hex> {
  const { provider, address, config } = input;
  if (!config.enabled || !config.contractAddress || !config.usdtAddress) throw new WalletError("NOT_CONFIGURED", "Checkout is not configured yet");
  const usdtAddress = config.usdtAddress;
  const chain = viemChain(config);
  const item = creditPackages.find((entry) => entry.id === input.packageId);
  if (!item) throw new WalletError("FAILED", "Unknown package");
  const amount = packageUsdtWei(item.id);
  const fee = BigInt(config.platformFeeWei);

  input.onStage?.("switching");
  await ensureBscNetwork(provider, config);

  const wallet = createWalletClient({ account: address, chain, transport: custom(provider) });
  const reader = createPublicClient({ chain, transport: fallback([custom(provider), ...config.rpcUrls.map((url) => http(url))]) });

  const [usdtBalance, bnbBalance, allowance] = await Promise.all([
    reader.readContract({ address: usdtAddress, abi: erc20Abi, functionName: "balanceOf", args: [address] }),
    reader.getBalance({ address }),
    reader.readContract({ address: usdtAddress, abi: erc20Abi, functionName: "allowance", args: [address, config.contractAddress] }),
  ]);
  if (usdtBalance < amount) throw new WalletError("INSUFFICIENT_USDT", "Not enough USDT on BSC");
  if (bnbBalance < fee) throw new WalletError("INSUFFICIENT_BNB", "Not enough BNB for the platform fee and gas");

  try {
    if (allowance < amount) {
      input.onStage?.("approving");
      const approveHash = await wallet.writeContract({ address: usdtAddress, abi: erc20Abi, functionName: "approve", args: [config.contractAddress, amount] });
      await reader.waitForTransactionReceipt({ hash: approveHash });
    }
    input.onStage?.("paying");
    const hash = await wallet.writeContract({
      address: config.contractAddress,
      abi: creditStoreAbi,
      functionName: "buy",
      args: [packageKey(item.id)],
      value: fee,
    });
    input.onStage?.("confirming", hash);
    const receipt = await reader.waitForTransactionReceipt({ hash, confirmations: config.confirmations });
    if (receipt.status !== "success") throw new WalletError("TX_REVERTED", "Transaction reverted");
    return hash;
  } catch (cause) {
    if (cause instanceof WalletError) throw cause;
    throw new WalletError(isRejection(cause) ? "REJECTED" : "FAILED", cause instanceof Error ? cause.message : "Payment failed");
  }
}

export function explorerTxUrl(hash: string, config?: Pick<CheckoutConfig, "explorerUrl"> | null) {
  return `${config?.explorerUrl ?? "https://bscscan.com"}/tx/${hash}`;
}
