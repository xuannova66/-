import { Solar } from "lunar-javascript";
import type { Locale, StudyVisualKind } from "./site-content";
import type { LibraryCategory } from "./library-catalogue";

export type AppRoute =
  | "home"
  | "flash"
  | "hecan"
  | "bazi"
  | "detail"
  | "compatibility"
  | "liuyao"
  | "ziwei"
  | "qizheng"
  | "qimen"
  | "daliuren"
  | "meihua"
  | "jinkoujue"
  | "heluo"
  | "tieban"
  | "taiyi"
  | "zhuzhai"
  | "zeri"
  | "wenshi"
  | "mirror"
  | "toolkit"
  | "daily"
  | "library"
  | "courses"
  | "guide"
  | "almanac"
  | "xiangshu"
  | "cezi"
  | "membership"
  | "credits"
  | "admin";

export type FormFamily = "birth" | "pair" | "inquiry" | "mirror" | "daily";

export type RouteDefinition = {
  route: AppRoute;
  mark: string;
  title: string;
  chineseTitle: string;
  lead: string;
  form: FormFamily;
  visual: StudyVisualKind;
  group: "life" | "inquiry" | "reflect" | "rhythm";
  libraryCategory: LibraryCategory;
};

export const routeDefinitions: RouteDefinition[] = [
  { route: "hecan", mark: "参", title: "Synthesis Reading", chineseTitle: "三术合参", lead: "Three lenses, held in one study", form: "birth", visual: "comparison", group: "life", libraryCategory: "bazi" },
  { route: "bazi", mark: "命", title: "BaZi", chineseTitle: "八字排盘", lead: "Four pillars and seasonal balance", form: "birth", visual: "pillars", group: "life", libraryCategory: "bazi" },
  { route: "detail", mark: "批", title: "BaZi Deep Reading", chineseTitle: "八字详研", lead: "Layered observation of the four pillars", form: "birth", visual: "pillars", group: "life", libraryCategory: "bazi" },
  { route: "compatibility", mark: "缘", title: "Compatibility", chineseTitle: "双人合盘", lead: "Two profiles in considered dialogue", form: "pair", visual: "comparison", group: "life", libraryCategory: "bazi" },
  { route: "ziwei", mark: "紫", title: "Zi Wei", chineseTitle: "紫微斗数", lead: "Twelve houses, one quiet field", form: "birth", visual: "palaces", group: "life", libraryCategory: "ziwei" },
  { route: "qizheng", mark: "星", title: "Celestial Chart", chineseTitle: "七政四余", lead: "A twelve-sector celestial study", form: "birth", visual: "celestial", group: "life", libraryCategory: "qizheng" },
  { route: "liuyao", mark: "卦", title: "Liuyao", chineseTitle: "六爻起卦", lead: "Hold one question through six lines", form: "inquiry", visual: "hexagram", group: "inquiry", libraryCategory: "liuyao" },
  { route: "qimen", mark: "奇", title: "Qi Men", chineseTitle: "奇门遁甲", lead: "A nine-palace timing field", form: "inquiry", visual: "timing", group: "inquiry", libraryCategory: "qimen" },
  { route: "daliuren", mark: "壬", title: "Da Liu Ren", chineseTitle: "大六壬", lead: "A three-stage inquiry layout", form: "inquiry", visual: "timing", group: "inquiry", libraryCategory: "daliuren" },
  { route: "meihua", mark: "梅", title: "Plum Blossom Numerology", chineseTitle: "梅花易数", lead: "Original, mutual and changed hexagrams with body and function", form: "inquiry", visual: "hexagram", group: "inquiry", libraryCategory: "liuyao" },
  { route: "jinkoujue", mark: "金", title: "Jin Kou Jue", chineseTitle: "金口诀", lead: "Four positions from one chosen direction", form: "inquiry", visual: "timing", group: "inquiry", libraryCategory: "daliuren" },
  { route: "heluo", mark: "河", title: "He Luo Numerology", chineseTitle: "河洛理数", lead: "He Tu and Luo Shu numbers turned into a life hexagram", form: "birth", visual: "hexagram", group: "life", libraryCategory: "liuyao" },
  { route: "tieban", mark: "铁", title: "Tie Ban Numbers", chineseTitle: "铁板神数", lead: "Tai Xuan numbers and the eight quarters of the birth hour", form: "birth", visual: "pillars", group: "life", libraryCategory: "bazi" },
  { route: "taiyi", mark: "乙", title: "Tai Yi", chineseTitle: "太乙神数", lead: "The palace of Tai Yi for a given year", form: "daily", visual: "timing", group: "rhythm", libraryCategory: "qimen" },
  { route: "zhuzhai", mark: "宅", title: "Home Analysis", chineseTitle: "住宅详情分析", lead: "Personal trigram, house trigram and the year's flying stars", form: "birth", visual: "timing", group: "life", libraryCategory: "foundation" },
  { route: "zeri", mark: "择", title: "Personal Date Selection", chineseTitle: "专业择日", lead: "Good days for one purpose, checked against your chart", form: "birth", visual: "daily", group: "rhythm", libraryCategory: "foundation" },
  { route: "wenshi", mark: "断", title: "Inquiry Synthesis", chineseTitle: "问事合参", lead: "Three local inquiry lenses together", form: "inquiry", visual: "comparison", group: "inquiry", libraryCategory: "liuyao" },
  { route: "mirror", mark: "观", title: "Self-Reflection", chineseTitle: "自我观照", lead: "A structured self-observation prompt", form: "mirror", visual: "spread", group: "reflect", libraryCategory: "reflection" },
  { route: "daily", mark: "辰", title: "Daily Rhythm", chineseTitle: "每日时序", lead: "A calendar-based pause for one grounded next step", form: "daily", visual: "daily", group: "rhythm", libraryCategory: "foundation" },
];

export type StudyRoute = Exclude<AppRoute, "home" | "toolkit" | "library" | "courses" | "guide" | "almanac" | "xiangshu" | "cezi" | "membership" | "credits" | "admin">;

export const routeByKey = Object.fromEntries(routeDefinitions.map((route) => [route.route, route])) as Record<StudyRoute, RouteDefinition>;

export function getStudyRoute(route: string): RouteDefinition | undefined {
  return routeByKey[route as StudyRoute];
}

export type ToolkitKey = "time" | "elements" | "dream" | "name" | "tarot" | "iching" | "natal" | "meihua" | "fengshui";

export const toolkitItems: Array<{ key: ToolkitKey; mark: string; title: string; chineseTitle: string; description: string }> = [
  { key: "time", mark: "寻", title: "Time Calibration", chineseTitle: "寻时定盘", description: "Narrow a study window with calm, structured prompts." },
  { key: "elements", mark: "五", title: "Five Elements Quick View", chineseTitle: "五行喜忌速测", description: "Observe a local balance note from a birth moment." },
  { key: "dream", mark: "梦", title: "Dream Reflection", chineseTitle: "解梦", description: "Explore a dream through its emotional images." },
  { key: "name", mark: "名", title: "Name Study", chineseTitle: "姓名参详", description: "Look at a name through sound, form and personal intention." },
  { key: "tarot", mark: "塔", title: "Tarot Reflection", chineseTitle: "塔罗牌", description: "Use a three-card local spread to observe a present question." },
  { key: "iching", mark: "易", title: "I Ching Study", chineseTitle: "周易研习", description: "Create a simple hexagram prompt for patient reflection." },
  { key: "natal", mark: "盘", title: "Natal Chart", chineseTitle: "星盘解析", description: "View a twelve-sector chart as an orientation exercise." },
];

export const libraryArticles = [
  { id: "yin-yang", category: "foundation", title: "Yin–Yang as a living contrast", chineseTitle: "阴阳：动态的相对关系", summary: "A practical cultural introduction to paired qualities, change and attention.", body: "Yin and Yang can be studied as complementary tendencies rather than fixed labels. In an everyday reflection, notice where rest and action, openness and boundary, listening and expression are asking to be held together." },
  { id: "five-elements", category: "bazi", title: "Five Elements: observing relationship", chineseTitle: "五行：观察关系的语言", summary: "A study note on Wood, Fire, Earth, Metal and Water as relational images.", body: "The Five Elements offer a vocabulary for noticing movement, warmth, grounding, discernment and flow. They are useful as a cultural lens for pattern recognition, not as a claim that a person can be reduced to a category." },
  { id: "pillars", category: "bazi", title: "Four pillars and seasonal context", chineseTitle: "四柱与季节语境", summary: "How a four-part layout can be used for structured cultural study.", body: "A four-pillar visual organizes a birth moment into a sequence of stem-and-branch pairs. The local Xuannova version keeps the layout deterministic and invites reflection on rhythm, environments and intention." },
  { id: "hexagram", category: "liuyao", title: "Six lines: holding an inquiry", chineseTitle: "六爻：安放一个问题", summary: "A six-line form for slowing down a question before acting.", body: "A hexagram can give an inquiry a deliberate structure. Instead of seeking certainty, use each line to name conditions, movement, hesitation, relationship and the next modest action." },
  { id: "palaces", category: "ziwei", title: "Twelve houses as a map of attention", chineseTitle: "十二宫：注意力的地图", summary: "A non-deterministic way to read a twelve-house visual.", body: "Twelve-house layouts distribute palace themes around a circle. During study, a house can be used as an invitation to examine a relationship, a responsibility or a season of life with more care." },
  { id: "timing", category: "qimen", title: "Timing: the shape of a moment", chineseTitle: "时机：一个当下的形状", summary: "How timing boards help make a situation more observable.", body: "A timing board separates a moment into several positions. The usefulness lies in clarifying the question, recognizing constraints and choosing one grounded next step." },
  { id: "cosmos", category: "qizheng", title: "Celestial bodies and orientation", chineseTitle: "星体定位与方位", summary: "A cultural note on orienting with seasonal and celestial imagery.", body: "Celestial charts have long offered people a way to think about cycles and orientation. Xuannova presents them as visual study material, never as a promise about events or outcomes." },
];

export type SuiteCopy = {
  nav: { home: string; methods: string; allMethods: string; synthesis: string; toolkit: string; daily: string; library: string; membership: string; credits: string; language: string; homeLabel: string; primaryNavigation: string; openNavigation: string; mobileNavigation: string };
  hero: { eyebrow: string; primary: string; secondary: string; explore: string };
  catalogue: { eyebrow: string; title: string; lead: string; local: string; free: string };
  groups: { life: string; inquiry: string; reflect: string; rhythm: string };
  voice: { eyebrow: string; title: string; scholar: string; hermit: string; full: string; direct: string; sampleLabel: string };
  form: { back: string; birth: string; pair: string; inquiry: string; mirror: string; name: string; partner: string; gender: string; yin: string; yang: string; calendar: string; solar: string; lunar: string; pillars: string; date: string; time: string; place: string; focus: string; focusHint: string; relation: string; question: string; questionHint: string; useNow: string; advanced: string; generate: string; required: string; result: string; sourceNotes: string; regenerate: string; birthMoment: string; relationshipContext: string; inquiryFocus: string };
  routes: Record<AppRoute, string>;
  toolkit: { eyebrow: string; title: string; lead: string; open: string; prompt: string; create: string; result: string; time: string; elements: string; dream: string; name: string };
  daily: { eyebrow: string; title: string; lead: string; date: string; seasonal: string; timeWindows: string; personalNote: string };
  library: { eyebrow: string; title: string; lead: string; search: string; all: string; foundation: string; bazi: string; liuyao: string; ziwei: string; qimen: string; qizheng: string; noResults: string; read: string; close: string };
  membership: { eyebrow: string; title: string; lead: string; noAccount: string; noUploads: string; recent: string; empty: string };
  theme: { label: string; aureate: string; paper: string; nocturne: string };
  disclaimer: string;
  disclaimerLabel: string;
};

const english: SuiteCopy = {
  nav: { home: "Home", methods: "Study methods", allMethods: "All study methods", synthesis: "Synthesis", toolkit: "Toolkit", daily: "Daily rhythm", library: "Wisdom library", membership: "Membership", credits: "Buy credits", language: "Language", homeLabel: "Xuannova home", primaryNavigation: "Primary navigation", openNavigation: "Open navigation", mobileNavigation: "Mobile navigation" },
  hero: { eyebrow: "EASTERN COSMIC ENERGY STUDIES · WORLDWIDE", primary: "Start a free study", secondary: "Open a study", explore: "Explore the methods" },
  catalogue: { eyebrow: "XUANNOVA · STUDY CATALOGUE", title: "Thirteen study lenses.", lead: "Every route has its own form, visual and layered reflection.", local: "FREE CHART", free: "FREE TOOL" },
  groups: { life: "INNATE CHART STUDIES", inquiry: "INQUIRY & TIMING STUDIES", reflect: "REFLECTIVE STUDY", rhythm: "DAILY RHYTHM" },
  voice: { eyebrow: "FOUR DIMENSIONS OF READING", title: "Two voices · two depths", scholar: "Measured scholar", hermit: "Plainspoken hermit", full: "Full reflection", direct: "Direct prompt", sampleLabel: "STUDY OUTPUT · SAMPLE VOICE" },
  form: { back: "Back to Xuannova", birth: "Birth chart study", pair: "Paired chart study", inquiry: "Inquiry study", mirror: "Self-reflection", name: "Study name", partner: "Second study name", gender: "Gender", yin: "Female", yang: "Male", calendar: "Calendar input", solar: "Solar", lunar: "Lunar", pillars: "Pillars", date: "Birth date", time: "Birth time", place: "Place of birth", focus: "Reflection focus", focusHint: "For example: a decision, relationship or new beginning", relation: "Relationship context", question: "Inquiry focus", questionHint: "Describe one specific situation or question", useNow: "Use the current moment", advanced: "Advanced options", generate: "Generate study", required: "Write the question you want to ask before continuing.", result: "Study result", sourceNotes: "Source notes", regenerate: "Generate again", birthMoment: "Birth moment", relationshipContext: "Relationship context", inquiryFocus: "Inquiry focus" },
  routes: { flash: "Xuannova Flash", home: "Home", hecan: "Synthesis Reading", bazi: "BaZi", detail: "BaZi Deep Reading", compatibility: "Compatibility", liuyao: "Liuyao", ziwei: "Zi Wei", qizheng: "Celestial Chart", qimen: "Qi Men", daliuren: "Da Liu Ren", meihua: "Plum Blossom", jinkoujue: "Jin Kou Jue", heluo: "He Luo Numerology", tieban: "Tie Ban Numbers", taiyi: "Tai Yi", zhuzhai: "Home Analysis", xiangshu: "Palm & Face Reading", zeri: "Date Selection", cezi: "Character Divination", wenshi: "Inquiry Synthesis", mirror: "Self-Reflection", toolkit: "Study toolkit", daily: "Daily rhythm", library: "Wisdom library", courses: "Video courses", guide: "Beginner's guide", almanac: "Daily Almanac", membership: "Membership", credits: "Buy credits", admin: "Owner console" },
  toolkit: { eyebrow: "XUANNOVA STUDY REFERENCES", title: "Study references, always at hand.", lead: "Fix the birth hour, weigh the five elements, study a name, read a dream: the lookups used along the way are kept here.", open: "Begin study", prompt: "What would you like to explore?", create: "Create note", result: "Your note", time: "Time calibration", elements: "Five Elements quick view", dream: "Dream reflection", name: "Name study" },
  daily: { eyebrow: "DAILY RHYTHM", title: "A small seasonal pause.", lead: "Choose a day and use its rhythm note to plan one quieter next action.", date: "Study date", seasonal: "Seasonal note", timeWindows: "Time windows", personalNote: "Personal note" },
  library: { eyebrow: "Xuannova WISDOM LIBRARY", title: "Read the chart with care.", lead: "A compact original knowledge library for cultural study.", search: "Search the wisdom library", all: "All", foundation: "Foundation", bazi: "BaZi", liuyao: "Liuyao", ziwei: "Zi Wei", qimen: "Qi Men", qizheng: "Celestial", noResults: "No study notes match this search.", read: "Read note", close: "Back to library" },
  membership: { eyebrow: "CREDIT MEMBERSHIP", title: "Your study, your credits.", lead: "This preview keeps its sign-in and credit balance in the current browser. A payment channel is activated only after the owner connects a verified USDT checkout path.", noAccount: "No account required", noUploads: "No data uploads", recent: "Recent studies", empty: "Generate a study to see it listed here." },
  theme: { label: "Theme", aureate: "Aureate", paper: "Paper", nocturne: "Nocturne" },
  disclaimer: "All study outputs are cultural-learning and emotional-wellness references only. They are not fate prediction, supernatural intervention, medical advice or a guarantee of any outcome.",
  disclaimerLabel: "Disclaimer",
};

const simplified: SuiteCopy = {
  nav: { home: "首页", methods: "术数推演", allMethods: "全部研习方法", synthesis: "三术合参", toolkit: "百宝袋", daily: "每日时序", library: "藏经阁", membership: "会员入口", credits: "购买积分", language: "语言", homeLabel: "Xuannova首页", primaryNavigation: "主导航", openNavigation: "打开导航", mobileNavigation: "移动端导航" },
  hero: { eyebrow: "东方宇宙能量研习 · 面向全球", primary: "开启免费研习", secondary: "开始研习", explore: "探索诸术" },
  catalogue: { eyebrow: "Xuannova · 研习目录", title: "十三种研习方式。", lead: "每一种都有独立录入、盘面与分层解读。", local: "免费排盘", free: "免费工具" },
  groups: { life: "先天命盘研习", inquiry: "问事与时序研习", reflect: "自我观照研习", rhythm: "每日时序研习" },
  voice: { eyebrow: "四维交互", title: "两种人格 · 两种深度", scholar: "严谨学者", hermit: "轻巧隐士", full: "完整推演", direct: "直给提示", sampleLabel: "参详输出 · 文风示例" },
  form: { back: "返回Xuannova", birth: "先天命盘研习", pair: "双人合盘研习", inquiry: "问事研习", mirror: "自我观照", name: "研习称谓", partner: "对方称谓", gender: "性别", yin: "女", yang: "男", calendar: "历法输入", solar: "公历", lunar: "农历", pillars: "四柱", date: "出生日期", time: "出生时间", place: "出生地点", focus: "观察主题", focusHint: "例如：一个决定、一段关系或新的开始", relation: "关系语境", question: "所问之事", questionHint: "尽量具体地描述此刻想观察的问题", useNow: "使用当前时刻", advanced: "高级选项", generate: "起盘并生成解读", required: "请先写下你想问的事。", result: "研习结果", sourceNotes: "研习依据", regenerate: "再次起盘", birthMoment: "诞辰之候", relationshipContext: "关系语境", inquiryFocus: "所问之事" },
  routes: { flash: "Xuannova 快讯", home: "首页", hecan: "三术合参", bazi: "八字排盘", detail: "八字详研", compatibility: "双人合盘", liuyao: "六爻起卦", ziwei: "紫微斗数", qizheng: "七政四余", qimen: "奇门遁甲", daliuren: "大六壬", meihua: "梅花易数", jinkoujue: "金口诀", heluo: "河洛理数", tieban: "铁板神数", taiyi: "太乙神数", zhuzhai: "住宅详情分析", xiangshu: "手相面相", zeri: "专业择日", cezi: "测字", wenshi: "问事合参", mirror: "自我观照", toolkit: "百宝袋", daily: "每日时序", library: "藏经阁", courses: "视频课程", guide: "新手指南", almanac: "每日黄历", membership: "会员", credits: "购买积分", admin: "站主后台" },
  toolkit: { eyebrow: "Xuannova · 术数百宝", title: "术数百宝 · 研习常备", lead: "定时辰、察五行、参姓名、解梦象——研习路上常用的查询与参考，都收在这里。", open: "开始研习", prompt: "你想观察什么？", create: "生成研习卡", result: "你的研习卡", time: "寻时定盘", elements: "五行喜忌速测", dream: "解梦", name: "姓名参详" },
  daily: { eyebrow: "每日时序", title: "给当日留一段安静的空白。", lead: "选择日期，用本地时序提示安排一个更从容的下一步。", date: "研习日期", seasonal: "时序提示", timeWindows: "时段观察", personalNote: "个人提醒" },
  library: { eyebrow: "Xuannova藏经阁", title: "谨慎地阅读盘面。", lead: "为文化研习整理的原创简明知识库。", search: "搜索知识库", all: "全部", foundation: "基础", bazi: "八字", liuyao: "六爻", ziwei: "紫微", qimen: "奇门", qizheng: "星象", noResults: "没有找到相关研习笔记。", read: "阅读笔记", close: "返回藏经阁" },
  membership: { eyebrow: "积分会员", title: "你的研习，你的积分。", lead: "本地预览将登录与积分余额保存在当前浏览器；站主接入已核验的 USDT 收款路径后，支付通道才会开启。", noAccount: "无需账号", noUploads: "不上传资料", recent: "最近研习", empty: "生成一张研习盘后，记录会显示在这里。" },
  theme: { label: "主题", aureate: "华彩", paper: "素简", nocturne: "墨夜" },
  disclaimer: "全部研习结果仅供东方传统文化学习、身心觉察与情绪调节参考，不构成命运预测、神力干预、医疗建议或任何结果保证。",
  disclaimerLabel: "温馨提示",
};

const traditional: SuiteCopy = {
  ...simplified,
  nav: { home: "首頁", methods: "術數推演", allMethods: "全部研習方法", synthesis: "三術合參", toolkit: "百寶袋", daily: "每日時序", library: "藏經閣", membership: "會員入口", credits: "購買積分", language: "語言", homeLabel: "Xuannova首頁", primaryNavigation: "主導覽", openNavigation: "開啟導覽", mobileNavigation: "行動版導覽" },
  hero: { eyebrow: "東方宇宙能量研習 · 面向全球", primary: "開啟免費研習", secondary: "開始研習", explore: "探索諸術" },
  catalogue: { eyebrow: "Xuannova · 研習目錄", title: "十三種研習方式。", lead: "每一種都有獨立輸入、盤面與分層解讀。", local: "免費排盤", free: "免費工具" },
  groups: { life: "先天命盤研習", inquiry: "問事與時序研習", reflect: "自我觀照研習", rhythm: "每日時序研習" },
  voice: { eyebrow: "四維互動", title: "兩種人格 · 兩種深度", scholar: "嚴謹學者", hermit: "輕巧隱士", full: "完整推演", direct: "直給提示", sampleLabel: "參詳輸出 · 文風示例" },
  form: { ...simplified.form, back: "返回Xuannova", birth: "先天命盤研習", pair: "雙人合盤研習", inquiry: "問事研習", mirror: "自我觀照", name: "研習稱謂", partner: "對方稱謂", gender: "性別", yin: "女", yang: "男", calendar: "曆法輸入", solar: "公曆", lunar: "農曆", date: "出生日期", time: "出生時間", place: "出生地點", focus: "觀察主題", relation: "關係語境", question: "所問之事", questionHint: "盡量具體地描述此刻想觀察的問題", useNow: "使用目前時刻", advanced: "進階選項", generate: "起盤並生成解讀", required: "請先寫下你想問的事。", result: "研習結果", sourceNotes: "研習依據", regenerate: "再次起盤", birthMoment: "誕辰之候", relationshipContext: "關係語境", inquiryFocus: "所問之事" },
  routes: { flash: "Xuannova 快訊", home: "首頁", hecan: "三術合參", bazi: "八字排盤", detail: "八字詳研", compatibility: "雙人合盤", liuyao: "六爻起卦", ziwei: "紫微斗數", qizheng: "七政四餘", qimen: "奇門遁甲", daliuren: "大六壬", meihua: "梅花易數", jinkoujue: "金口訣", heluo: "河洛理數", tieban: "鐵板神數", taiyi: "太乙神數", zhuzhai: "住宅詳情分析", xiangshu: "手相面相", zeri: "專業擇日", cezi: "測字", wenshi: "問事合參", mirror: "自我觀照", toolkit: "百寶袋", daily: "每日時序", library: "藏經閣", courses: "影片課程", guide: "新手指南", almanac: "每日黃曆", membership: "會員", credits: "購買積分", admin: "站主後台" },
  toolkit: { ...simplified.toolkit, eyebrow: "Xuannova · 術數百寶", title: "術數百寶 · 研習常備", lead: "定時辰、察五行、參姓名、解夢象——研習路上常用的查詢與參考，都收在這裡。", open: "開始研習", prompt: "你想觀察什麼？", create: "生成研習卡", result: "你的研習卡", elements: "五行喜忌速測", dream: "解夢", name: "姓名參詳" },
  daily: { eyebrow: "每日時序", title: "給當日留一段安靜的空白。", lead: "選擇日期，用本地時序提示安排一個更從容的下一步。", date: "研習日期", seasonal: "時序提示", timeWindows: "時段觀察", personalNote: "個人提醒" },
  library: { ...simplified.library, eyebrow: "Xuannova藏經閣", title: "謹慎地閱讀盤面。", lead: "為文化研習整理的原創簡明知識庫。", search: "搜尋知識庫", all: "全部", foundation: "基礎", noResults: "沒有找到相關研習筆記。", read: "閱讀筆記", close: "返回藏經閣" },
  membership: { eyebrow: "積分會員", title: "你的研習，你的積分。", lead: "本地預覽將登入與積分餘額儲存在目前瀏覽器；站主接入已核驗的 USDT 收款路徑後，付款通道才會開啟。", noAccount: "無需帳號", noUploads: "不會上傳資料", recent: "最近研習", empty: "生成一張研習盤後，記錄會顯示在這裡。" },
  theme: { label: "主題", aureate: "華彩", paper: "素簡", nocturne: "墨夜" },
  disclaimer: "全部研習結果僅供東方傳統文化學習、身心覺察與情緒調節參考，不構成命運預測、神力干預、醫療建議或任何結果保證。",
  disclaimerLabel: "溫馨提示",
};

const japanese: SuiteCopy = {
  ...english,
  nav: { home: "ホーム", methods: "学習メソッド", allMethods: "すべての学習メソッド", synthesis: "統合学習", toolkit: "学習ツール", daily: "日々のリズム", library: "知恵の書庫", membership: "メンバーシップ", credits: "クレジット購入", language: "言語", homeLabel: "Xuannovaホーム", primaryNavigation: "メインナビゲーション", openNavigation: "ナビゲーションを開く", mobileNavigation: "モバイルナビゲーション" },
  hero: { eyebrow: "東洋宇宙エネルギー研究 · 世界へ", primary: "無料の研習を始める", secondary: "学習を開く", explore: "学びを探す" },
  catalogue: { eyebrow: "Xuannova · 学習目録", title: "十三の学習レンズ。", lead: "各レンズに固有の入力、チャート、段階的な考察があります。", local: "無料で作成", free: "無料ツール" },
  groups: { life: "生来のチャート学習", inquiry: "問いと時機の学習", reflect: "内省の学習", rhythm: "日々のリズム" },
  voice: { eyebrow: "四つの読み方", title: "二つの語り口 · 二つの深さ", scholar: "慎重な学者", hermit: "率直な隠者", full: "詳しい考察", direct: "簡潔なヒント", sampleLabel: "学習出力 · 文体サンプル" },
  form: { ...english.form, back: "Xuannovaに戻る", birth: "生来のチャート学習", pair: "二人のチャート学習", inquiry: "問いの学習", mirror: "自己観察", name: "学習名", partner: "二人目の学習名", gender: "性別", yin: "女性", yang: "男性", calendar: "暦の入力", solar: "太陽暦", lunar: "太陰暦", pillars: "四柱", date: "生年月日", time: "出生時刻", place: "出生地", focus: "観察テーマ", focusHint: "例：決断、関係、新しい始まり", relation: "関係の文脈", question: "問いの焦点", questionHint: "いま考えたい具体的な状況を書いてください", useNow: "現在の時刻を使う", advanced: "詳細な設定", generate: "学習を作る", required: "先に尋ねたいことを書いてください。", result: "学習結果", sourceNotes: "学習の手がかり", regenerate: "もう一度作る", birthMoment: "生まれた時", relationshipContext: "関係の文脈", inquiryFocus: "問いの焦点" },
  routes: { flash: "Xuannova 速報", home: "ホーム", hecan: "統合学習", bazi: "八字", detail: "八字詳細", compatibility: "相性学習", liuyao: "六爻", ziwei: "紫微斗数", qizheng: "天体チャート", qimen: "奇門遁甲", daliuren: "大六壬", meihua: "梅花易数", jinkoujue: "金口訣", heluo: "河洛理数", tieban: "鉄板神数", taiyi: "太乙神数", zhuzhai: "住まいの詳細分析", xiangshu: "手相・人相", zeri: "個人の日取り", cezi: "測字", wenshi: "問いの統合", mirror: "自己観察", toolkit: "学習ツール", daily: "日々のリズム", library: "知恵の書庫", courses: "動画講座", guide: "初心者ガイド", almanac: "暦・吉日", membership: "メンバーシップ", credits: "クレジット購入", admin: "運営コンソール" },
  toolkit: { eyebrow: "Xuannova · 術数百宝", title: "術数百宝・研究の常備", lead: "時刻の確認、五行、名前、夢の象――研究の途中でよく使う照会と参考をここにまとめました。", open: "研究を始める", prompt: "何を観察したいですか？", create: "ノートを作る", result: "あなたのノート", time: "時刻の調整", elements: "五行クイックビュー", dream: "夢の内省", name: "名前の学習" },
  daily: { eyebrow: "日々のリズム", title: "一日に小さな静けさを。", lead: "日付を選び、季節メモから落ち着いた次の一歩を考えます。", date: "学習日", seasonal: "季節のメモ", timeWindows: "時間帯の観察", personalNote: "自分へのメモ" },
  library: { eyebrow: "Xuannovaの知恵の書庫", title: "盤面を丁寧に読む。", lead: "文化学習のための短いオリジナル知識庫です。", search: "知恵の書庫を検索", all: "すべて", foundation: "基礎", bazi: "八字", liuyao: "六爻", ziwei: "紫微", qimen: "奇門", qizheng: "天体", noResults: "一致する学習ノートはありません。", read: "ノートを読む", close: "書庫へ戻る" },
  membership: { eyebrow: "クレジット会員", title: "学びとクレジットを、あなたの手元に。", lead: "このローカルプレビューではサインインと残高を現在のブラウザに保存します。運営者が確認済みの USDT 決済経路を接続した後にのみ、決済チャネルが有効になります。", noAccount: "アカウント不要", noUploads: "データ送信なし", recent: "最近の学習", empty: "学習を作ると、ここに表示されます。" },
  theme: { label: "テーマ", aureate: "華彩", paper: "紙墨", nocturne: "墨夜" },
  disclaimer: "すべての学習出力は、東洋文化の学び、心身の気づき、情緒的なウェルネスの参考のためだけのものです。運命の予言、超自然的介入、医療助言、結果の保証ではありません。",
  disclaimerLabel: "ご案内",
};

const korean: SuiteCopy = {
  ...english,
  nav: { home: "홈", methods: "학습 방법", allMethods: "모든 학습 방법", synthesis: "통합 학습", toolkit: "학습 도구", daily: "오늘의 리듬", library: "지혜 도서관", membership: "멤버십", credits: "크레딧 구매", language: "언어", homeLabel: "Xuannova 홈", primaryNavigation: "주 탐색", openNavigation: "탐색 열기", mobileNavigation: "모바일 탐색" },
  hero: { eyebrow: "동양 우주 에너지 연구 · 세계를 향해", primary: "무료 학습 시작하기", secondary: "학습 열기", explore: "학습 탐색" },
  catalogue: { eyebrow: "Xuannova · 학습 목록", title: "열세 가지 학습 렌즈.", lead: "각 렌즈에는 고유한 입력, 차트와 단계별 성찰이 있습니다.", local: "무료 명반", free: "무료 도구" },
  groups: { life: "타고난 차트 학습", inquiry: "질문과 타이밍 학습", reflect: "자기 관찰 학습", rhythm: "일일 리듬" },
  voice: { eyebrow: "네 가지 읽기 방식", title: "두 가지 목소리 · 두 가지 깊이", scholar: "신중한 학자", hermit: "직설적인 은자", full: "깊은 성찰", direct: "간결한 힌트", sampleLabel: "학습 결과 · 문체 예시" },
  form: { ...english.form, back: "Xuannova로 돌아가기", birth: "타고난 차트 학습", pair: "두 사람 차트 학습", inquiry: "질문 학습", mirror: "자기 관찰", name: "학습 이름", partner: "두 번째 학습 이름", gender: "성별", yin: "여성", yang: "남성", calendar: "달력 입력", solar: "양력", lunar: "음력", pillars: "사주", date: "생년월일", time: "출생 시각", place: "출생지", focus: "관찰 주제", focusHint: "예: 결정, 관계 또는 새로운 시작", relation: "관계 맥락", question: "질문의 초점", questionHint: "지금 살펴보고 싶은 구체적 상황을 적어 주세요", useNow: "현재 시각 사용", advanced: "상세 설정", generate: "학습 만들기", required: "먼저 묻고 싶은 내용을 적어 주세요.", result: "학습 결과", sourceNotes: "학습 단서", regenerate: "다시 만들기", birthMoment: "출생 순간", relationshipContext: "관계 맥락", inquiryFocus: "질문의 초점" },
  routes: { flash: "Xuannova 속보", home: "홈", hecan: "통합 학습", bazi: "사주", detail: "사주 심화", compatibility: "궁합 학습", liuyao: "육효", ziwei: "자미두수", qizheng: "천체 차트", qimen: "기문둔갑", daliuren: "대육임", meihua: "매화역수", jinkoujue: "금구결", heluo: "하락이수", tieban: "철판신수", taiyi: "태을신수", zhuzhai: "주택 상세 분석", xiangshu: "수상·관상", zeri: "개인 택일", cezi: "측자", wenshi: "질문 통합", mirror: "자기 관찰", toolkit: "학습 도구", daily: "오늘의 리듬", library: "지혜 도서관", courses: "영상 강좌", guide: "초보자 가이드", almanac: "황력·길일", membership: "멤버십", credits: "크레딧 구매", admin: "운영자 콘솔" },
  toolkit: { eyebrow: "Xuannova · 술수백보", title: "술수백보 · 학습 상비", lead: "시진 확정, 오행 살피기, 이름 참구, 꿈의 상 읽기 — 공부하며 자주 쓰는 조회와 참고를 모았습니다.", open: "학습 시작", prompt: "무엇을 관찰하고 싶나요?", create: "노트 만들기", result: "나의 노트", time: "시간 조정", elements: "오행 빠른 보기", dream: "꿈 성찰", name: "이름 학습" },
  daily: { eyebrow: "오늘의 리듬", title: "하루에 작은 고요를 남기세요.", lead: "날짜를 고르고 계절 메모로 차분한 다음 한 걸음을 생각합니다.", date: "학습 날짜", seasonal: "계절 메모", timeWindows: "시간대 관찰", personalNote: "개인 메모" },
  library: { eyebrow: "Xuannova 지혜 도서관", title: "판면을 신중하게 읽으세요.", lead: "문화 학습을 위한 짧은 오리지널 지식 도서관입니다.", search: "지혜 도서관 검색", all: "전체", foundation: "기초", bazi: "사주", liuyao: "육효", ziwei: "자미", qimen: "기문", qizheng: "천체", noResults: "일치하는 학습 노트가 없습니다.", read: "노트 읽기", close: "도서관으로 돌아가기" },
  membership: { eyebrow: "크레딧 멤버십", title: "학습과 크레딧을 내 손안에.", lead: "이 로컬 미리보기는 로그인과 잔액을 현재 브라우저에 저장합니다. 운영자가 검증된 USDT 결제 경로를 연결한 뒤에만 결제 채널이 활성화됩니다.", noAccount: "계정 불필요", noUploads: "데이터 업로드 없음", recent: "최근 학습", empty: "학습을 만들면 여기에 표시됩니다." },
  theme: { label: "테마", aureate: "화채", paper: "종이", nocturne: "묵야" },
  disclaimer: "모든 학습 결과는 동양 문화 학습, 마음챙김 및 정서적 웰빙 참고용입니다. 운명 예측, 초자연적 개입, 의료 조언 또는 결과 보장을 제공하지 않습니다.",
  disclaimerLabel: "안내",
};

const vietnamese: SuiteCopy = {
  ...english,
  nav: { home: "Trang chủ", methods: "Phương pháp", allMethods: "Tất cả phương pháp học", synthesis: "Góc nhìn tổng hợp", toolkit: "Bộ công cụ", daily: "Nhịp điệu hằng ngày", library: "Thư viện tri thức", membership: "Thành viên", credits: "Mua điểm", language: "Ngôn ngữ", homeLabel: "Trang chủ Xuannova", primaryNavigation: "Điều hướng chính", openNavigation: "Mở điều hướng", mobileNavigation: "Điều hướng di động" },
  hero: { eyebrow: "NGHIÊN CỨU NĂNG LƯỢNG VŨ TRỤ PHƯƠNG ĐÔNG · TOÀN CẦU", primary: "Bắt đầu nghiên cứu miễn phí", secondary: "Mở nghiên cứu", explore: "Khám phá phương pháp" },
  catalogue: { eyebrow: "XUANNOVA · DANH MỤC HỌC TẬP", title: "Mười ba lăng kính học tập.", lead: "Mỗi lộ trình có phần nhập, biểu đồ và suy ngẫm nhiều lớp riêng.", local: "LẬP MIỄN PHÍ", free: "CÔNG CỤ MIỄN PHÍ" },
  groups: { life: "NGHIÊN CỨU BIỂU ĐỒ BẨM SINH", inquiry: "NGHIÊN CỨU CÂU HỎI & THỜI ĐIỂM", reflect: "NGHIÊN CỨU TỰ QUAN SÁT", rhythm: "NHỊP ĐIỆU HẰNG NGÀY" },
  voice: { eyebrow: "BỐN CÁCH ĐỌC", title: "Hai giọng điệu · hai độ sâu", scholar: "Học giả điềm tĩnh", hermit: "Ẩn sĩ thẳng thắn", full: "Suy ngẫm đầy đủ", direct: "Gợi ý trực tiếp", sampleLabel: "KẾT QUẢ HỌC TẬP · MẪU VĂN PHONG" },
  form: { ...english.form, back: "Trở về Xuannova", birth: "Nghiên cứu biểu đồ bẩm sinh", pair: "Nghiên cứu biểu đồ đôi", inquiry: "Nghiên cứu câu hỏi", mirror: "Tự quan sát", name: "Tên nghiên cứu", partner: "Tên nghiên cứu thứ hai", gender: "Giới tính", yin: "Nữ", yang: "Nam", calendar: "Kiểu lịch", solar: "Dương lịch", lunar: "Âm lịch", pillars: "Tứ trụ", date: "Ngày sinh", time: "Giờ sinh", place: "Nơi sinh", focus: "Chủ đề suy ngẫm", focusHint: "Ví dụ: một quyết định, mối quan hệ hoặc khởi đầu mới", relation: "Bối cảnh mối quan hệ", question: "Trọng tâm câu hỏi", questionHint: "Mô tả một tình huống hoặc câu hỏi cụ thể", useNow: "Dùng thời điểm hiện tại", advanced: "Tùy chọn nâng cao", generate: "Tạo nghiên cứu", required: "Hãy viết điều bạn muốn hỏi trước.", result: "Kết quả nghiên cứu", sourceNotes: "Ghi chú học tập", regenerate: "Tạo lại", birthMoment: "Khoảnh khắc sinh", relationshipContext: "Bối cảnh mối quan hệ", inquiryFocus: "Trọng tâm câu hỏi" },
  routes: { flash: "Tin nhanh Xuannova", home: "Trang chủ", hecan: "Góc nhìn tổng hợp", bazi: "Bát tự", detail: "Bát tự chuyên sâu", compatibility: "Tương hợp", liuyao: "Lục hào", ziwei: "Tử vi", qizheng: "Biểu đồ thiên thể", qimen: "Kỳ Môn", daliuren: "Đại Lục Nhâm", meihua: "Mai Hoa Dịch Số", jinkoujue: "Kim Khẩu Quyết", heluo: "Hà Lạc Lý Số", tieban: "Thiết Bản Thần Số", taiyi: "Thái Ất Thần Số", zhuzhai: "Phân tích chi tiết nhà ở", xiangshu: "Xem tướng tay & mặt", zeri: "Chọn ngày theo tuổi", cezi: "Đoán chữ", wenshi: "Tổng hợp câu hỏi", mirror: "Tự quan sát", toolkit: "Bộ công cụ", daily: "Nhịp điệu hằng ngày", library: "Thư viện tri thức", courses: "Khóa học video", guide: "Hướng dẫn cho người mới", almanac: "Xem ngày tốt xấu", membership: "Thành viên", credits: "Mua điểm", admin: "Bảng điều khiển chủ sở hữu" },
  toolkit: { eyebrow: "XUANNOVA · THUẬT SỐ BÁCH BẢO", title: "Thuật số bách bảo · Tra cứu thường dùng", lead: "Định giờ sinh, xét ngũ hành, tham khảo tên, giải tượng mộng — các tra cứu thường dùng khi học đều ở đây.", open: "Bắt đầu học", prompt: "Bạn muốn quan sát điều gì?", create: "Tạo ghi chú", result: "Ghi chú của bạn", time: "Hiệu chỉnh thời điểm", elements: "Xem nhanh Ngũ Hành", dream: "Suy ngẫm về giấc mơ", name: "Nghiên cứu tên" },
  daily: { eyebrow: "NHỊP ĐIỆU HẰNG NGÀY", title: "Một khoảng dừng theo mùa.", lead: "Chọn ngày và dùng ghi chú nhịp điệu để lên kế hoạch cho bước tiếp theo nhẹ nhàng hơn.", date: "Ngày nghiên cứu", seasonal: "Ghi chú mùa", timeWindows: "Khung giờ", personalNote: "Ghi chú cá nhân" },
  library: { eyebrow: "THƯ VIỆN TRI THỨC XUANNOVA", title: "Đọc bàn cục một cách cẩn trọng.", lead: "Một thư viện tri thức nguyên bản, gọn nhẹ cho việc học văn hóa.", search: "Tìm trong thư viện tri thức", all: "Tất cả", foundation: "Nền tảng", bazi: "Bát tự", liuyao: "Lục hào", ziwei: "Tử vi", qimen: "Kỳ Môn", qizheng: "Thiên thể", noResults: "Không có ghi chú học tập phù hợp.", read: "Đọc ghi chú", close: "Trở về thư viện" },
  membership: { eyebrow: "THÀNH VIÊN ĐIỂM", title: "Hành trình học tập, điểm của bạn.", lead: "Bản xem trước cục bộ lưu đăng nhập và số dư trong trình duyệt hiện tại. Kênh thanh toán chỉ được bật khi chủ sở hữu kết nối một luồng USDT đã xác minh.", noAccount: "Không cần tài khoản", noUploads: "Không tải dữ liệu lên", recent: "Nghiên cứu gần đây", empty: "Hãy tạo một nghiên cứu để thấy nó ở đây." },
  theme: { label: "Giao diện", aureate: "Ánh đồng", paper: "Giấy mực", nocturne: "Đêm mực" },
  disclaimer: "Mọi kết quả học tập chỉ dành cho việc học văn hóa phương Đông, nhận biết thân tâm và tham khảo sức khỏe cảm xúc. Đây không phải dự đoán số mệnh, can thiệp siêu nhiên, tư vấn y tế hay bảo đảm kết quả.",
  disclaimerLabel: "Lưu ý",
};

const thai: SuiteCopy = {
  ...english,
  nav: { home: "หน้าแรก", methods: "วิธีศึกษา", allMethods: "วิธีศึกษาทั้งหมด", synthesis: "มุมมองผสาน", toolkit: "ชุดเครื่องมือ", daily: "จังหวะประจำวัน", library: "คลังความรู้", membership: "สมาชิก", credits: "ซื้อเครดิต", language: "ภาษา", homeLabel: "หน้าแรก Xuannova", primaryNavigation: "การนำทางหลัก", openNavigation: "เปิดเมนูนำทาง", mobileNavigation: "เมนูนำทางบนมือถือ" },
  hero: { eyebrow: "การศึกษาพลังจักรวาลตะวันออก · เพื่อผู้คนทั่วโลก", primary: "เริ่มศึกษาได้ฟรี", secondary: "เปิดการศึกษา", explore: "สำรวจวิธีศึกษา" },
  catalogue: { eyebrow: "Xuannova · สารบัญการศึกษา", title: "เลนส์การศึกษาสิบสามแบบ", lead: "ทุกเส้นทางมีแบบกรอก แผนภาพ และการใคร่ครวญเป็นชั้นของตัวเอง", local: "ผังฟรี", free: "เครื่องมือฟรี" },
  groups: { life: "การศึกษาแผนภาพกำเนิด", inquiry: "การศึกษาคำถามและจังหวะเวลา", reflect: "การศึกษาการสังเกตตนเอง", rhythm: "จังหวะประจำวัน" },
  voice: { eyebrow: "สี่มิติของการอ่าน", title: "สองน้ำเสียง · สองระดับความลึก", scholar: "นักวิชาการสุขุม", hermit: "นักบวชผู้ตรงไปตรงมา", full: "การใคร่ครวญเต็มรูปแบบ", direct: "คำแนะนำตรงประเด็น", sampleLabel: "ผลการศึกษา · ตัวอย่างน้ำเสียง" },
  form: { ...english.form, back: "กลับสู่ Xuannova", birth: "การศึกษาแผนภาพกำเนิด", pair: "การศึกษาแผนภาพคู่", inquiry: "การศึกษาคำถาม", mirror: "การสังเกตตนเอง", name: "ชื่อการศึกษา", partner: "ชื่อการศึกษาที่สอง", gender: "เพศ", yin: "หญิง", yang: "ชาย", calendar: "รูปแบบปฏิทิน", solar: "สุริยคติ", lunar: "จันทรคติ", pillars: "สี่เสา", date: "วันเกิด", time: "เวลาเกิด", place: "สถานที่เกิด", focus: "หัวข้อใคร่ครวญ", focusHint: "เช่น การตัดสินใจ ความสัมพันธ์ หรือการเริ่มต้นใหม่", relation: "บริบทความสัมพันธ์", question: "จุดสนใจของคำถาม", questionHint: "บรรยายสถานการณ์หรือคำถามที่เจาะจง", useNow: "ใช้เวลาปัจจุบัน", advanced: "ตัวเลือกขั้นสูง", generate: "สร้างการศึกษา", required: "โปรดเขียนสิ่งที่อยากถามก่อน", result: "ผลการศึกษา", sourceNotes: "บันทึกการศึกษา", regenerate: "สร้างอีกครั้ง", birthMoment: "ช่วงเวลาเกิด", relationshipContext: "บริบทความสัมพันธ์", inquiryFocus: "จุดสนใจของคำถาม" },
  routes: { flash: "ข่าวด่วน Xuannova", home: "หน้าแรก", hecan: "มุมมองผสาน", bazi: "ปาจื้อ", detail: "ปาจื้อเชิงลึก", compatibility: "การสอดคล้อง", liuyao: "ลิ่วเหยา", ziwei: "จื่อเวย", qizheng: "แผนภาพท้องฟ้า", qimen: "ฉีเหมิน", daliuren: "ต้าหลิ่วเริ่น", meihua: "เหมยฮวาอี้ซู่", jinkoujue: "จินโข่วเจวี๋ย", heluo: "เหอลั่วหลี่ซู่", tieban: "เถี่ยป่านเสินซู่", taiyi: "ไท่อี่เสินซู่", zhuzhai: "วิเคราะห์รายละเอียดบ้าน", xiangshu: "ลายมือและโหงวเฮ้ง", zeri: "เลือกฤกษ์เฉพาะตัว", cezi: "ทำนายอักษร", wenshi: "ผสานคำถาม", mirror: "การสังเกตตนเอง", toolkit: "ชุดเครื่องมือ", daily: "จังหวะประจำวัน", library: "คลังความรู้", courses: "คอร์สวิดีโอ", guide: "คู่มือมือใหม่", almanac: "ปฏิทินฤกษ์ดี", membership: "สมาชิก", credits: "ซื้อเครดิต", admin: "คอนโซลผู้ดูแล" },
  toolkit: { eyebrow: "Xuannova · คลังศาสตร์", title: "คลังศาสตร์ · ข้อมูลประจำการศึกษา", lead: "หาเวลาเกิด พิจารณาธาตุ ศึกษาชื่อ อ่านภาพฝัน — การค้นและข้อมูลอ้างอิงที่ใช้บ่อยระหว่างศึกษารวมไว้ที่นี่", open: "เริ่มศึกษา", prompt: "คุณอยากสังเกตอะไร?", create: "สร้างบันทึก", result: "บันทึกของคุณ", time: "ปรับเวลาศึกษา", elements: "มุมมองธาตุทั้งห้า", dream: "ใคร่ครวญความฝัน", name: "ศึกษาชื่อ" },
  daily: { eyebrow: "จังหวะประจำวัน", title: "เว้นช่วงสงบเล็ก ๆ ให้กับวัน", lead: "เลือกวันและใช้บันทึกจังหวะตามฤดูกาลเพื่อวางแผนก้าวถัดไปอย่างนุ่มนวล", date: "วันที่ศึกษา", seasonal: "บันทึกฤดูกาล", timeWindows: "ช่วงเวลา", personalNote: "บันทึกส่วนตัว" },
  library: { eyebrow: "คลังความรู้Xuannova", title: "อ่านผังอย่างรอบคอบ", lead: "คลังความรู้ต้นฉบับขนาดกระชับสำหรับการเรียนรู้วัฒนธรรม", search: "ค้นหาคลังความรู้", all: "ทั้งหมด", foundation: "พื้นฐาน", bazi: "ปาจื้อ", liuyao: "ลิ่วเหยา", ziwei: "จื่อเวย", qimen: "ฉีเหมิน", qizheng: "ท้องฟ้า", noResults: "ไม่พบบันทึกการศึกษาที่ตรงกัน", read: "อ่านบันทึก", close: "กลับสู่คลังความรู้" },
  membership: { eyebrow: "สมาชิกเครดิต", title: "การศึกษาและเครดิตของคุณ อยู่ในมือคุณ", lead: "ตัวอย่างในเครื่องจะเก็บการเข้าสู่ระบบและยอดเครดิตไว้ในเบราว์เซอร์ปัจจุบัน ช่องทางชำระเงินจะเปิดใช้เมื่อผู้ดูแลเชื่อมต่อเส้นทาง USDT ที่ยืนยันแล้วเท่านั้น", noAccount: "ไม่ต้องมีบัญชี", noUploads: "ไม่มีการอัปโหลดข้อมูล", recent: "การศึกษาล่าสุด", empty: "สร้างการศึกษาหนึ่งรายการแล้วจะแสดงที่นี่" },
  theme: { label: "ธีม", aureate: "ทองแดง", paper: "กระดาษหมึก", nocturne: "คืนหมึก" },
  disclaimer: "ผลการศึกษาทั้งหมดมีไว้เพื่อการเรียนรู้วัฒนธรรมตะวันออก การตระหนักรู้กายใจ และการอ้างอิงด้านสุขภาวะทางอารมณ์เท่านั้น ไม่ใช่การทำนายชะตา การแทรกแซงเหนือธรรมชาติ คำแนะนำทางการแพทย์ หรือการรับประกันผลลัพธ์ใด ๆ",
  disclaimerLabel: "ข้อควรทราบ",
};

export const suiteCopy: Record<Locale, SuiteCopy> = { en: english, "zh-Hans": simplified, "zh-Hant": traditional, ja: japanese, ko: korean, vi: vietnamese, th: thai };

export function routeFromHash(hash: string): AppRoute {
  const route = hash.replace(/^#\/?/, "") as AppRoute;
  return ["home", "hecan", "bazi", "detail", "compatibility", "liuyao", "ziwei", "qizheng", "qimen", "daliuren", "meihua", "jinkoujue", "heluo", "tieban", "taiyi", "zhuzhai", "zeri", "wenshi", "mirror", "toolkit", "daily", "library", "courses", "guide", "almanac", "xiangshu", "cezi", "membership", "credits", "admin"].includes(route) ? route : "home";
}

export function hashForRoute(route: AppRoute) {
  return route === "home" ? "#home" : `#${route}`;
}

export function titleForRoute(route: AppRoute, locale: Locale) {
  return suiteCopy[locale].routes[route];
}

function hash(value: string) {
  let output = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    output ^= value.charCodeAt(index);
    output = Math.imul(output, 16777619);
  }
  return Math.abs(output >>> 0);
}

export function makeToolkitResult(kind: ToolkitKey, query: string) {
  const seeds = ["Dawn window", "Gentle boundary", "Returning light", "Clear water", "Open gate", "Quiet earth", "Living wood", "Warm fire"];
  const seed = hash(`${kind}|${query}`);
  return {
    title: seeds[seed % seeds.length],
    line: query.trim() || "Begin with one small, honest observation.",
    facets: Array.from({ length: 3 }, (_, index) => seeds[(seed + index * 3) % seeds.length]),
  };
}

export function makeDailyResult(date: string) {
  const seed = hash(date);
  const notes = ["Keep the day spacious before making a large decision.", "Let one unfinished conversation become clearer through listening.", "Choose steadiness over a quick answer.", "A practical detail deserves the first ten minutes of attention.", "Make room for a small act of restoration."];
  // Window heights follow the traditional auspicious/inauspicious day-spirit of each two-hour period.
  let windows: number[] = [];
  try {
    const [y, m, d] = date.split("-").map(Number);
    windows = Solar.fromYmdHms(y, m, d, 12, 0, 0).getLunar().getTimes().slice(1).map((time: { getTianShenLuck: () => string }) => (time.getTianShenLuck() === "吉" ? 4 : 2));
  } catch {
    windows = Array.from({ length: 12 }, () => 3);
  }
  return { note: notes[seed % notes.length], windows };
}
