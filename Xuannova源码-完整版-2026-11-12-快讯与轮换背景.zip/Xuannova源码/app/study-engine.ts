import { Lunar, Solar } from "lunar-javascript";
import type { GlobalLocation } from "./geocoding";
import { calculateTrueSolarTime, civilInstantUtc, normalizeCivilTimezone } from "./solar-time";
import { luckStart, type LuckStart } from "./metaphysics/bazi-extra";
import { plumBlossomCast, plumBlossomNumberCast, plumBlossomTextCast } from "./metaphysics/liuyao";

export type StudyInput = {
  birthDate: string;
  birthTime: string;
  /** The birth time is unknown: the hour pillar is not used (birthTime then carries a nominal 12:00). */
  timeUnknown?: boolean;
  companionTimeUnknown?: boolean;
  /** The form still held the example birthday when this chart was made. */
  example?: boolean;
  calendar: "solar" | "lunar" | "pillars";
  /** Lunar input only: the month is the leap (闰) month. */
  leapMonth?: boolean;
  companionDate?: string;
  companionLeapMonth?: boolean;
  companionTime?: string;
  companionCalendar?: "solar" | "lunar" | "pillars";
  manualPillars?: string[];
  gender?: "yin" | "yang";
  companionManualPillars?: string[];
  lines?: boolean[];
  movingLines?: boolean[];
  place?: string;
  location?: GlobalLocation;
  useTrueSolar?: boolean;
  focus: string;
  name: string;
  companionName: string;
  module: string;
  version: number;
  /** House feng shui: the direction the house sits toward (its back). */
  houseSitting?: string;
  /** School options (advanced settings). Defaults: late Zi hour, luck start by days, split leap month, classic transforms. */
  ziHour?: "late" | "early";
  luckPrecision?: "days" | "minutes";
  ziweiLeap?: "split" | "current" | "next";
  ziweiTransform?: "classic" | "alt";
  /** Plum blossom casting: by the moment (default), by two numbers, or by a phrase. */
  meihuaMethod?: "time" | "numbers" | "text";
  meihuaNumbers?: [number, number];
  meihuaText?: string;
  /** 金口诀: the chosen earth position (地分), one of the twelve branches. Defaults to the hour branch. */
  difen?: string;
  /** 专业择日: purpose, first date and number of days to search. */
  zeriPurpose?: string;
  zeriStart?: string;
  zeriDays?: number;
};
export type SchoolOptions = { ziHour: "late" | "early"; luckPrecision: "days" | "minutes" };

export type StudyResult = {
  seed: number;
  module: string;
  focus: string;
  pillars: string[];
  palaces: string[];
  lines: boolean[];
  movingLines: boolean[];
  cards: string[];
  sectors: number[];
  timing: string[];
  prompts: string[];
  summary: string;
  sections: Array<{ title: string; text: string }>;
  sources: string[];
  calendar: { solar: string; lunar: string; zodiac: string; naYin: string; elements: Array<{ name: string; count: number }>; yi: string[]; ji: string[]; civilDate: string; civilTime: string; trueSolarDate?: string; trueSolarTime?: string; timeBasis: "civil" | "true-solar"; solarCorrectionMinutes?: number; location?: GlobalLocation };
  companionPillars?: string[];
  companionCalendar?: { solar: string; lunar: string; zodiac: string; naYin: string };
  /** Calendar facts used by the rule-based chart engines. */
  astro: StudyAstro;
  /** The exact input this result was computed from, so the full chart can be rebuilt identically. */
  input: StudyInput;
};

export type StudyAstro = {
  manualPillars: boolean;
  lunarYearStem: string;
  lunarYearBranch: string;
  lunarMonth: number;
  lunarDay: number;
  leapMonth: boolean;
  hourBranch: string;
  prevJieQi: string;
  prevQi: string;
  utcMs: number;
  luck?: LuckStart;
};

const palaces = ["North", "Northeast", "East", "Southeast", "South", "Southwest", "West", "Northwest", "Center"];
const cards = ["The Lantern", "Still Water", "The Gate", "The Mountain", "Open Sky", "The Thread", "Returning Light", "The Vessel", "The Garden"];
const timingMarks = ["Open", "Gather", "Observe", "Return", "Hold", "Shape", "Release", "Listen", "Align"];
const promptBank = [
  "What feels steady enough to keep as you move forward?",
  "Where could a smaller, kinder next step be more useful than certainty?",
  "What part of your environment supports the quality you want to cultivate?",
  "Which rhythm in your week is asking to be noticed rather than fixed?",
  "What can be held lightly while you gather more lived experience?",
  "Where might a clear boundary create more room to breathe?",
  "What is becoming clearer when you pause before responding?",
  "Which intention would make this next season feel more aligned?",
];

const elementForCharacter: Record<string, string> = {
  甲: "Wood", 乙: "Wood", 寅: "Wood", 卯: "Wood",
  丙: "Fire", 丁: "Fire", 巳: "Fire", 午: "Fire",
  戊: "Earth", 己: "Earth", 辰: "Earth", 戌: "Earth", 丑: "Earth", 未: "Earth",
  庚: "Metal", 辛: "Metal", 申: "Metal", 酉: "Metal",
  壬: "Water", 癸: "Water", 亥: "Water", 子: "Water",
};

function seedFrom(value: string) {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return Math.abs(hash >>> 0);
}

function pick<T>(values: T[], seed: number, offset: number) {
  return values[(seed + offset * 7919) % values.length];
}

function toDateParts(date: string, time: string) {
  const [year = "1994", month = "08", day = "18"] = date.split("-");
  const [hour = "12", minute = "00"] = time.split(":");
  return { year: Number(year), month: Number(month), day: Number(day), hour: Number(hour), minute: Number(minute) };
}

function lunarFromInput(parts: ReturnType<typeof toDateParts>, leap: boolean) {
  // Clamp the day to the length of the chosen lunar month so 30 in a 29-day month does not throw.
  try {
    return Lunar.fromYmdHms(parts.year, leap ? -parts.month : parts.month, parts.day, parts.hour, parts.minute, 0);
  } catch {
    try {
      return Lunar.fromYmdHms(parts.year, leap ? -parts.month : parts.month, Math.min(parts.day, 29), parts.hour, parts.minute, 0);
    } catch {
      return Lunar.fromYmdHms(parts.year, parts.month, Math.min(parts.day, 29), parts.hour, parts.minute, 0);
    }
  }
}

function makeCalendarData(date: string, time: string, calendar: StudyInput["calendar"], leap = false, gender: "yin" | "yang" = "yang", schools: SchoolOptions = { ziHour: "late", luckPrecision: "days" }) {
  const parts = toDateParts(date, time);
  const lunar = calendar === "lunar"
    ? lunarFromInput(parts, leap)
    : Solar.fromYmdHms(parts.year, parts.month, parts.day, parts.hour, parts.minute, 0).getLunar();
  const solar = lunar.getSolar();
  const eightChar = lunar.getEightChar();
  // Late Zi (夜子时, default): 23:00–24:00 keeps today's day pillar. Early Zi (早子时): it already counts as tomorrow.
  eightChar.setSect(schools.ziHour === "early" ? 1 : 2);
  const pillars = [eightChar.getYear(), eightChar.getMonth(), eightChar.getDay(), eightChar.getTime()];
  const counts = new Map(["Wood", "Fire", "Earth", "Metal", "Water"].map((name) => [name, 0]));
  pillars.join("").split("").forEach((character) => {
    const element = elementForCharacter[character];
    if (element) counts.set(element, (counts.get(element) ?? 0) + 1);
  });
  return {
    pillars,
    solar: solar.toYmdHms(),
    lunar: lunar.toString(),
    zodiac: lunar.getYearShengXiao(),
    naYin: lunar.getDayNaYin(),
    elements: Array.from(counts, ([name, count]) => ({ name, count })),
    yi: lunar.getDayYi().slice(0, 4),
    ji: lunar.getDayJi().slice(0, 4),
    lunarFacts: {
      lunarYearStem: lunar.getYearGan(),
      lunarYearBranch: lunar.getYearZhi(),
      lunarMonth: Math.abs(lunar.getMonth()),
      lunarDay: lunar.getDay(),
      leapMonth: lunar.getMonth() < 0,
      hourBranch: lunar.getTimeZhi(),
      prevJieQi: lunar.getPrevJieQi(false).getName(),
      prevQi: lunar.getPrevQi(false).getName(),
      luck: luckStart(eightChar, gender, schools.luckPrecision === "minutes" ? 2 : 1),
    },
  };
}

export function createStudyResult(input: StudyInput): StudyResult {
  const locationKey = input.location ? `${input.location.id}|${input.location.latitude}|${input.location.longitude}|${input.location.timezone}` : input.place ?? "";
  const lineKey = input.lines?.join("") ?? "";
  const movingLineKey = input.movingLines?.join("") ?? "";
  const seed = seedFrom(`${input.birthDate}|${input.birthTime}|${input.calendar}|${input.name}|${input.companionName}|${input.focus}|${input.module}|${locationKey}|${input.useTrueSolar ? "solar" : "civil"}|${lineKey}|${movingLineKey}|${input.ziHour ?? ""}|${input.luckPrecision ?? ""}|${input.ziweiLeap ?? ""}|${input.ziweiTransform ?? ""}|${input.meihuaMethod ?? ""}|${input.meihuaNumbers?.join(",") ?? ""}|${input.meihuaText ?? ""}|${input.difen ?? ""}`);
  const gender = input.gender ?? "yang";
  const schools: SchoolOptions = { ziHour: input.ziHour ?? "late", luckPrecision: input.luckPrecision ?? "days" };
  const civilCalendar = makeCalendarData(input.birthDate, input.birthTime, input.calendar, Boolean(input.leapMonth), gender, schools);
  const civilSolarDate = civilCalendar.solar.slice(0, 10);
  const civilSolarTime = civilCalendar.solar.slice(11, 16);
  const solarTiming = input.useTrueSolar && input.location && !input.timeUnknown
    ? calculateTrueSolarTime({ date: civilSolarDate, time: civilSolarTime, longitude: input.location.longitude, timezone: normalizeCivilTimezone(input.location.timezone, input.location.countryCode) })
    : undefined;
  const calculatedCalendar = solarTiming
    ? makeCalendarData(solarTiming.trueSolarDate, solarTiming.trueSolarTime, "solar", false, gender, schools)
    : civilCalendar;
  const { lunarFacts, ...calendarFields } = calculatedCalendar;
  const calendar = {
    ...calendarFields,
    civilDate: civilSolarDate,
    civilTime: civilSolarTime,
    ...(solarTiming ? { trueSolarDate: solarTiming.trueSolarDate, trueSolarTime: solarTiming.trueSolarTime, solarCorrectionMinutes: solarTiming.correctionMinutes } : {}),
    timeBasis: solarTiming ? "true-solar" as const : "civil" as const,
    ...(input.location ? { location: input.location } : {}),
  };
  const computedPillars = input.calendar === "pillars" && input.manualPillars?.length === 4 ? input.manualPillars : calendar.pillars;
  const companionCalendar = input.companionDate
    ? makeCalendarData(input.companionDate, input.companionTime || input.birthTime, input.companionCalendar === "pillars" ? "solar" : input.companionCalendar || (input.calendar === "pillars" ? "solar" : input.calendar), Boolean(input.companionLeapMonth))
    : undefined;
  const companionPillars = input.companionCalendar === "pillars" && input.companionManualPillars?.length === 4
    ? input.companionManualPillars
    : companionCalendar?.pillars;
  const manualPillars = input.calendar === "pillars" && input.manualPillars?.length === 4;
  const timezone = input.location?.timezone ? normalizeCivilTimezone(input.location.timezone, input.location.countryCode) : "Asia/Shanghai";
  const astro: StudyAstro = {
    manualPillars,
    lunarYearStem: lunarFacts.lunarYearStem,
    lunarYearBranch: lunarFacts.lunarYearBranch,
    lunarMonth: lunarFacts.lunarMonth,
    lunarDay: lunarFacts.lunarDay,
    leapMonth: lunarFacts.leapMonth,
    hourBranch: manualPillars ? computedPillars[3].charAt(1) : lunarFacts.hourBranch,
    prevJieQi: lunarFacts.prevJieQi,
    prevQi: lunarFacts.prevQi,
    utcMs: civilInstantUtc(civilSolarDate, civilSolarTime, timezone),
    ...(manualPillars ? {} : { luck: lunarFacts.luck }),
  };
  const palaceValues = Array.from({ length: 9 }, (_, index) => `${pick(palaces, seed, index)} · ${String((seed + index * 3) % 9 + 1).padStart(2, "0")}`);
  // Without cast lines the hexagram is raised by the plum-blossom time method from the chart moment.
  const hourNumber = "子丑寅卯辰巳午未申酉戌亥".indexOf(lunarFacts.hourBranch) + 1;
  const timeCast = input.meihuaMethod === "numbers" && input.meihuaNumbers
    ? plumBlossomNumberCast(input.meihuaNumbers[0], input.meihuaNumbers[1], hourNumber)
    : input.meihuaMethod === "text" && input.meihuaText?.trim()
      ? plumBlossomTextCast(input.meihuaText, hourNumber)
      : plumBlossomCast("子丑寅卯辰巳午未申酉戌亥".indexOf(lunarFacts.lunarYearBranch) + 1, lunarFacts.lunarMonth, lunarFacts.lunarDay, hourNumber);
  const lines = input.lines?.length === 6 ? input.lines : timeCast.lines;
  const movingLines = input.movingLines?.length === 6
    ? input.movingLines
    : input.lines?.length === 6
      ? Array.from({ length: 6 }, () => false)
      : timeCast.movingLines;
  const cardValues = Array.from({ length: 3 }, (_, index) => pick(cards, seed, index + 2));
  const sectors = Array.from({ length: 12 }, (_, index) => (seed + index * 17) % 4 + 1);
  const timing = Array.from({ length: 9 }, (_, index) => pick(timingMarks, seed, index));
  const prompts = Array.from({ length: 3 }, (_, index) => pick(promptBank, seed, index + 4));
  const pairedProfiles = input.companionName.trim()
    ? `${input.name.trim() || "the first profile"} and ${input.companionName.trim()}`
    : "";
  const summary = pairedProfiles
    ? `This local paired study places ${pairedProfiles} in a ${input.focus.trim() || "shared"} context, using the chart structure as prompts for a grounded conversation.`
    : input.focus.trim()
      ? `This study holds “${input.focus.trim()}” alongside the calculated four-pillar calendar structure.`
      : `This study uses the ${computedPillars.join(" · ")} four pillars as a structured pause for reflection.`;
  const sections = [
    { title: "Calendar", text: `Solar ${calendar.solar} · Lunar ${calendar.lunar} · ${calendar.zodiac} year.` },
    { title: "Element balance", text: calendar.elements.map((element) => `${element.name} ${element.count}`).join(" · ") || "No element count available." },
    { title: "Practice", text: `Use the date’s cultural references as study prompts: 宜 ${calendar.yi.join("、") || "—"}；忌 ${calendar.ji.join("、") || "—"}。` },
  ];
  const sources = ["Calculated solar/lunar conversion", "Four pillars: year · month · day · hour", `Day NaYin: ${calendar.naYin}`];
  if (input.location) sources.push(`Location reference: ${input.location.label} · ${input.location.latitude.toFixed(4)}°, ${input.location.longitude.toFixed(4)}° · ${input.location.timezone}`);
  else if (input.place) sources.push(`Location reference: ${input.place}`);
  if (solarTiming) sources.push(`True solar time: ${solarTiming.trueSolarDate} ${solarTiming.trueSolarTime} (${solarTiming.correctionMinutes >= 0 ? "+" : ""}${solarTiming.correctionMinutes} min from civil time).`);
  else if (input.useTrueSolar) sources.push("True solar time needs a selected worldwide city with coordinates and time zone.");
  if (companionPillars) sources.push(`Second profile: ${companionPillars.join(" · ")}`);
  return {
    seed,
    module: input.module,
    focus: input.focus,
    pillars: computedPillars,
    palaces: palaceValues,
    lines,
    movingLines,
    cards: cardValues,
    sectors,
    timing,
    prompts,
    summary,
    sections,
    sources,
    calendar,
    companionPillars,
    astro,
    input,
    companionCalendar: companionCalendar ? {
      solar: companionCalendar.solar,
      lunar: companionCalendar.lunar,
      zodiac: companionCalendar.zodiac,
      naYin: companionCalendar.naYin,
    } : undefined,
  };
}
