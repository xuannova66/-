"use client";
// Admin · Xuannova Flash: the automatic writer's switches (on/off, publish or review, how often, how many, quote of the
// day, news feeds, writing brief), "run now", the automation API details for Make.com / n8n, and the item list
// (publish / hide, pin, editor's pick, edit the Chinese and English text, delete).
// Read counts here are the real ones and cannot be edited.
import { useCallback, useEffect, useState } from "react";
import type { Locale } from "./site-content";
import type { FlashItem } from "./flash";

type Settings = { auto: boolean; publish: "auto" | "review"; intervalHours: number; perRun: number; dailyWisdom: boolean; sources: string[]; prompt: string };
type AdminItem = FlashItem & { status: "published" | "draft" | "hidden"; origin: string };
type Overview = { total: number; items: AdminItem[]; settings: Settings; state: { lastRun?: string; lastResult?: string }; ingest: boolean; ai: boolean };
type Text = { title: string; summary: string; body: string; quote: string | null; quoteSource: string | null };

const zh = (locale: Locale) => locale === "zh-Hans" || locale === "zh-Hant";
const T = (locale: Locale, cn: string, en: string) => (zh(locale) ? cn : en);

export const flashTabLabel = (locale: Locale) => T(locale, "Xuannova 快讯", "Xuannova Flash");

const SAMPLE = `{
  "category": "focus",            // focus 今日焦点 · energy 时事能量 · wisdom 国学微言
  "cta": "bazi",                  // bazi / daily / almanac / compatibility / ziwei / liuyao / zeri …
  "source_url": "https://…",      // original news link (also stops the same story twice)
  "source_name": "Reuters",
  "status": "published",          // or "draft" to check first
  "translations": {
    "zh-Hans": { "title": "…", "summary": "…", "body": "…", "quote": "上善若水…", "quote_source": "《道德经》" },
    "zh-Hant": { … }, "en": { … }, "ja": { … }, "ko": { … }, "vi": { … }, "th": { … }
  }
}`;

export function AdminFlash({ locale }: { locale: Locale }) {
  const [data, setData] = useState<Overview | null>(null);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [busy, setBusy] = useState("");
  const [note, setNote] = useState("");
  const [editing, setEditing] = useState<{ slug: string; texts: Record<string, Text> } | null>(null);
  const [draft, setDraft] = useState({ title: "", body: "", quote: "", quoteSource: "", category: "focus", cta: "bazi", sourceUrl: "" });

  const load = useCallback(async () => {
    const response = await fetch("/api/admin/flash?limit=50", { credentials: "same-origin" });
    if (!response.ok) { setNote(T(locale, "读取失败，请重新登录后台。", "Could not load; sign in again.")); return; }
    const value = await response.json() as Overview;
    setData(value); setSettings(value.settings);
  }, [locale]);
  useEffect(() => { void load(); }, [load]);

  const post = async (path: string, body: unknown, label: string) => {
    setBusy(label); setNote("");
    try {
      const response = await fetch(path, { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
      const value = await response.json().catch(() => ({})) as Record<string, unknown>;
      if (!response.ok) { setNote(String(value.error ?? response.status) + (value.detail ? ` · ${String(value.detail)}` : "")); return null; }
      return value;
    } finally { setBusy(""); }
  };

  if (!data || !settings) return <section className="admin-panel"><p>{note || "…"}</p></section>;
  const origin = typeof window === "undefined" ? "https://xuannova.com" : window.location.origin;
  const statusLabel = (status: string) => (status === "published" ? T(locale, "已发布", "Live") : status === "draft" ? T(locale, "待审核", "Draft") : T(locale, "已隐藏", "Hidden"));
  const categoryLabel = (category: string) => (category === "energy" ? T(locale, "时事能量", "Energy") : category === "wisdom" ? T(locale, "国学微言", "Wisdom") : T(locale, "今日焦点", "Focus"));

  return <section className="admin-panel admin-flash">
    <header className="admin-flash-status">
      <span className={data.ai ? "ok" : "warn"}>{data.ai ? T(locale, "✓ AI 写作已配置（DEEPSEEK_API_KEY）", "✓ Writer model configured") : T(locale, "✗ 未配置 DEEPSEEK_API_KEY，自动写作不会运行", "✗ DEEPSEEK_API_KEY missing")}</span>
      <span className={data.ingest ? "ok" : "warn"}>{data.ingest ? T(locale, "✓ 自动化接口已开启（FLASH_API_TOKEN）", "✓ Automation API on") : T(locale, "✗ 自动化接口未开启：在服务器 .env 设置 FLASH_API_TOKEN（至少 24 位随机字符）", "✗ Set FLASH_API_TOKEN (24+ chars) to enable the API")}</span>
      <span>{T(locale, "上次运行：", "Last run: ")}{data.state.lastResult ?? T(locale, "尚未运行", "never")}</span>
    </header>
    {note && <p className="admin-warning">{note}</p>}

    <form className="admin-flash-settings" onSubmit={(event) => { event.preventDefault(); void post("/api/admin/flash/settings", settings, "settings").then((value) => { if (value) { setNote(T(locale, "设置已保存。", "Saved.")); void load(); } }); }}>
      <h3>{T(locale, "自动抓取热点 + AI 国学解读", "Automatic news + AI reading")}</h3>
      <label className="check"><input type="checkbox" checked={settings.auto} onChange={(event) => setSettings({ ...settings, auto: event.target.checked })} />{T(locale, "开启自动运行", "Run automatically")}</label>
      <label className="check"><input type="checkbox" checked={settings.dailyWisdom} onChange={(event) => setSettings({ ...settings, dailyWisdom: event.target.checked })} />{T(locale, "每天早上自动发一条「国学微言 · 今日金句」", "Post a quote of the day each morning")}</label>
      <label>{T(locale, "新快讯", "New items")}<select value={settings.publish} onChange={(event) => setSettings({ ...settings, publish: event.target.value as Settings["publish"] })}><option value="auto">{T(locale, "直接发布", "Publish at once")}</option><option value="review">{T(locale, "先存为待审核，我确认后再发布", "Keep as draft for review")}</option></select></label>
      <label>{T(locale, "每隔几小时抓一次", "Every … hours")}<input type="number" min={1} max={24} value={settings.intervalHours} onChange={(event) => setSettings({ ...settings, intervalHours: Number(event.target.value) })} /></label>
      <label>{T(locale, "每次最多新增几条", "Items per run")}<input type="number" min={1} max={5} value={settings.perRun} onChange={(event) => setSettings({ ...settings, perRun: Number(event.target.value) })} /></label>
      <label className="wide">{T(locale, "新闻来源（RSS 地址，一行一个）", "News feeds (RSS, one per line)")}<textarea rows={4} value={settings.sources.join("\n")} onChange={(event) => setSettings({ ...settings, sources: event.target.value.split(/\n+/).map((line) => line.trim()).filter(Boolean) })} /></label>
      <label className="wide">{T(locale, "AI 写作提示词（安全规则和输出格式由系统自动附加，不能被这里覆盖）", "Writing brief (safety and format rules are always added)")}<textarea rows={6} value={settings.prompt} onChange={(event) => setSettings({ ...settings, prompt: event.target.value })} /></label>
      <p className="admin-flash-hint">{T(locale, "系统固定规则：只依据新闻标题与摘要，不编造；不评论真人的感情、婚姻、健康、隐私，不做真人面相；涉及伤亡、灾难、战争、犯罪、选举政治、明星八卦的新闻自动跳过；不给投资建议；每条附原文链接。浏览量只记录真实阅读，不能手动修改。", "Fixed rules: headline only, no invented facts; nothing about real people's private lives, health or faces; deaths, disasters, war, crime, elections and gossip are skipped; no investment advice; the source is linked. Reads are real and cannot be edited.")}</p>
      <aside>
        <button type="submit" className="primary-action" disabled={busy === "settings"}>{T(locale, "保存设置", "Save")}</button>
        <button type="button" className="secondary-action" disabled={busy === "run" || !data.ai} onClick={() => void post("/api/admin/flash/run", {}, "run").then((value) => { if (value) { const report = value.report as { added: string[]; skipped: number; errors: string[]; wisdom: string | null }; setNote(T(locale, `本次新增 ${report.added.length} 条${report.wisdom ? "，另有今日金句 1 条" : ""}；跳过 ${report.skipped} 条${report.errors.length ? `；问题：${report.errors.slice(0, 3).join("；")}` : ""}`, `Added ${report.added.length}${report.wisdom ? " + quote" : ""}, skipped ${report.skipped}${report.errors.length ? ` · ${report.errors.slice(0, 3).join("; ")}` : ""}`)); void load(); } })}>{busy === "run" ? T(locale, "正在抓取和写作（约 1–2 分钟）…", "Working (1–2 min)…") : T(locale, "立即抓取一次", "Run now")}</button>
      </aside>
    </form>

    <details className="admin-flash-api">
      <summary>{T(locale, "Make.com / n8n 自动化接口说明", "Make.com / n8n API")}</summary>
      <p>{T(locale, "在自动化工具里加一个 HTTP 请求：", "Add an HTTP request step:")}</p>
      <code>POST {origin}/api/flash/ingest</code>
      <code>Authorization: Bearer &lt;FLASH_API_TOKEN&gt;</code>
      <code>Content-Type: application/json</code>
      <pre>{SAMPLE}</pre>
      <p>{T(locale, "至少要有 zh-Hans 或 en；缺的语言会自动用英文或中文顶上。成功返回 201 和每种语言的链接。同一条新闻链接重复推送会返回 409。", "zh-Hans or en is required; missing languages fall back. Returns 201 with the links; the same source link twice returns 409.")}</p>
    </details>

    <form className="admin-flash-new" onSubmit={(event) => { event.preventDefault(); void post("/api/admin/flash", { category: draft.category, cta: draft.cta, source_url: draft.sourceUrl || undefined, translations: { [zh(locale) ? "zh-Hans" : "en"]: { title: draft.title, body: draft.body, quote: draft.quote, quote_source: draft.quoteSource } } }, "new").then((value) => { if (value) { setDraft({ ...draft, title: "", body: "", quote: "", quoteSource: "", sourceUrl: "" }); void load(); } }); }}>
      <h3>{T(locale, "手动发一条", "Write one by hand")}</h3>
      <label>{T(locale, "标题", "Title")}<input required maxLength={140} value={draft.title} onChange={(event) => setDraft({ ...draft, title: event.target.value })} /></label>
      <label>{T(locale, "分类", "Category")}<select value={draft.category} onChange={(event) => setDraft({ ...draft, category: event.target.value })}><option value="focus">{categoryLabel("focus")}</option><option value="energy">{categoryLabel("energy")}</option><option value="wisdom">{categoryLabel("wisdom")}</option></select></label>
      <label className="wide">{T(locale, "正文", "Body")}<textarea required rows={3} maxLength={2400} value={draft.body} onChange={(event) => setDraft({ ...draft, body: event.target.value })} /></label>
      <label>{T(locale, "经典金句", "Classic line")}<input value={draft.quote} onChange={(event) => setDraft({ ...draft, quote: event.target.value })} /></label>
      <label>{T(locale, "出处", "Source book")}<input value={draft.quoteSource} onChange={(event) => setDraft({ ...draft, quoteSource: event.target.value })} /></label>
      <label>{T(locale, "原新闻链接", "News link")}<input type="url" value={draft.sourceUrl} onChange={(event) => setDraft({ ...draft, sourceUrl: event.target.value })} /></label>
      <aside><button type="submit" className="primary-action" disabled={busy === "new"}>{T(locale, "发布", "Publish")}</button></aside>
    </form>

    <h3>{T(locale, `全部快讯（${data.total}）`, `All items (${data.total})`)}</h3>
    <div className="admin-flash-list">
      {data.items.length ? data.items.map((item) => <article key={item.slug} data-status={item.status}>
        <div>
          <b>{item.text.title}</b>
          <small>{categoryLabel(item.category)} · {statusLabel(item.status)} · {new Date(item.publishedAt).toLocaleString(locale)} · {item.origin === "auto" ? T(locale, "自动", "auto") : item.origin === "api" ? "API" : T(locale, "手动", "manual")} · {item.locales.length} {T(locale, "种语言", "languages")}</small>
          <small>{T(locale, `真实阅读 ${item.views} · 分享 ${item.shares} · 海报 ${item.posters}`, `Reads ${item.views} · shares ${item.shares} · posters ${item.posters}`)}{item.pinned ? ` · ${T(locale, "置顶", "pinned")}` : ""}{item.featured ? ` · ${T(locale, "精选", "pick")}` : ""}</small>
        </div>
        <aside>
          <a className="text-action" href={`/zh-hans/flash/${item.slug}`} target="_blank" rel="noreferrer">{T(locale, "查看", "View")}</a>
          <button type="button" className="text-action" onClick={() => void post(`/api/admin/flash/${item.slug}`, { status: item.status === "published" ? "hidden" : "published" }, item.slug).then(() => load())}>{item.status === "published" ? T(locale, "隐藏", "Hide") : T(locale, "发布", "Publish")}</button>
          <button type="button" className="text-action" onClick={() => void post(`/api/admin/flash/${item.slug}`, { pinned: !item.pinned }, item.slug).then(() => load())}>{item.pinned ? T(locale, "取消置顶", "Unpin") : T(locale, "置顶", "Pin")}</button>
          <button type="button" className="text-action" onClick={() => void post(`/api/admin/flash/${item.slug}`, { featured: !item.featured }, item.slug).then(() => load())}>{item.featured ? T(locale, "取消精选", "Unpick") : T(locale, "编辑精选", "Pick")}</button>
          <button type="button" className="text-action" onClick={() => void fetch(`/api/admin/flash/${item.slug}/texts`, { credentials: "same-origin" }).then((response) => response.json()).then((value: { texts: Array<Text & { locale: string }> }) => setEditing({ slug: item.slug, texts: Object.fromEntries(value.texts.map(({ locale: code, ...text }) => [code, text])) }))}>{T(locale, "编辑", "Edit")}</button>
          <button type="button" className="text-action danger" onClick={() => { if (window.confirm(T(locale, "确定删除这条快讯？删除后不能恢复。", "Delete this item? This cannot be undone."))) void post(`/api/admin/flash/${item.slug}/delete`, {}, item.slug).then(() => load()); }}>{T(locale, "删除", "Delete")}</button>
        </aside>
        {editing?.slug === item.slug && <form className="admin-flash-edit" onSubmit={(event) => { event.preventDefault(); void post(`/api/admin/flash/${item.slug}`, { texts: Object.fromEntries(Object.entries(editing.texts).map(([code, text]) => [code, { title: text.title, summary: text.summary, body: text.body, quote: text.quote, quote_source: text.quoteSource }])) }, "edit").then((value) => { if (value) { setEditing(null); void load(); } }); }}>
          {Object.entries(editing.texts).map(([code, text]) => <fieldset key={code}><legend>{code}</legend>
            <input value={text.title} onChange={(event) => setEditing({ ...editing, texts: { ...editing.texts, [code]: { ...text, title: event.target.value } } })} />
            <textarea rows={3} value={text.body} onChange={(event) => setEditing({ ...editing, texts: { ...editing.texts, [code]: { ...text, body: event.target.value } } })} />
          </fieldset>)}
          <aside><button type="submit" className="primary-action" disabled={busy === "edit"}>{T(locale, "保存修改", "Save")}</button><button type="button" className="text-action" onClick={() => setEditing(null)}>{T(locale, "取消", "Cancel")}</button></aside>
        </form>}
      </article>) : <p>{T(locale, "还没有快讯。配置好 DEEPSEEK_API_KEY 后点「立即抓取一次」，或用上面的接口推送。", "No items yet.")}</p>}
    </div>
  </section>;
}
