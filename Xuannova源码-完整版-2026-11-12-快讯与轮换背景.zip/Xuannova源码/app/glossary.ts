// Short explanations for common chart terms, shown when a reader hovers or taps a term in a reading.
// Each entry lists how the term is written in each language and a one-line explanation in that language.
import type { Locale } from "./site-content";
import { coreShorts, extraGlossary } from "./glossary-extra";

type Entry = { names: Record<Locale, string[]>; tip: Record<Locale, string>; short?: Record<Locale, string> };
const E = (names: Record<Locale, string[]>, tip: Record<Locale, string>): Entry => ({ names, tip });

const coreGlossary: Entry[] = [
  E({ en: ["Day Master", "day master"], "zh-Hans": ["日主", "日元"], "zh-Hant": ["日主", "日元"], ja: ["日主", "日干"], ko: ["일주", "일간"], vi: ["Nhật chủ"], th: ["เจ้าวัน"] },
    { en: "The day stem of the birth chart; it stands for the person and every other element is read in relation to it.", "zh-Hans": "日柱天干，代表命主本人，其他五行都以它为中心来看关系。", "zh-Hant": "日柱天干，代表命主本人，其他五行都以它為中心來看關係。", ja: "日柱の天干。本人を表し、他の五行はこれとの関係で読みます。", ko: "일주의 천간으로 본인을 뜻하며, 다른 오행은 이것과의 관계로 봅니다.", vi: "Thiên can của trụ ngày, đại diện cho bản thân; các hành khác được xét trong quan hệ với nó.", th: "ก้านฟ้าของเสาวัน แทนตัวเจ้าชะตา ธาตุอื่นอ่านตามความสัมพันธ์กับก้านนี้" }),
  E({ en: ["Ten Gods", "ten gods", "Ten God"], "zh-Hans": ["十神"], "zh-Hant": ["十神"], ja: ["通変星"], ko: ["십성", "십신"], vi: ["Thập thần"], th: ["สิบเทพ"] },
    { en: "Ten relationships between the day master and the other stems (support, output, wealth, authority, resource), each in a yin and a yang form.", "zh-Hans": "日主与其他天干的十种关系：比劫、食伤、财、官杀、印，各分阴阳。", "zh-Hant": "日主與其他天干的十種關係：比劫、食傷、財、官殺、印，各分陰陽。", ja: "日主と他の天干との十種類の関係（比劫・食傷・財・官殺・印、それぞれ陰陽）。", ko: "일간과 다른 천간의 열 가지 관계(비겁·식상·재·관살·인성, 각각 음양).", vi: "Mười quan hệ giữa nhật chủ và các can khác (tỷ kiếp, thực thương, tài, quan sát, ấn), mỗi loại có âm dương.", th: "ความสัมพันธ์สิบแบบระหว่างเจ้าวันกับก้านอื่น (มิตร ผลผลิต ทรัพย์ อำนาจ ผู้อุปถัมภ์) แต่ละแบบมีหยินหยาง" }),
  E({ en: ["Luck cycle", "luck cycles", "ten-year cycle", "ten-year cycles"], "zh-Hans": ["大运"], "zh-Hant": ["大運"], ja: ["大運"], ko: ["대운"], vi: ["Đại vận", "đại vận"], th: ["วัฏจักรสิบปี"] },
    { en: "Ten-year periods that follow from the month pillar; each brings a new stem and branch into the chart.", "zh-Hans": "由月柱推出的十年一步的运程，每步带来新的干支。", "zh-Hant": "由月柱推出的十年一步的運程，每步帶來新的干支。", ja: "月柱から導く十年ごとの運勢の区切り。各期に新しい干支が加わります。", ko: "월주에서 이어지는 10년 단위의 흐름으로, 매번 새 간지가 더해집니다.", vi: "Các giai đoạn mười năm suy từ trụ tháng; mỗi giai đoạn thêm một can chi mới.", th: "ช่วงละสิบปีที่ต่อจากเสาเดือน แต่ละช่วงเพิ่มก้านและกิ่งใหม่เข้าในดวง" }),
  E({ en: ["Annual cycle", "annual pillar", "year cycle"], "zh-Hans": ["流年"], "zh-Hant": ["流年"], ja: ["流年", "年運"], ko: ["유년", "세운"], vi: ["Lưu niên"], th: ["ดวงรายปี"] },
    { en: "The stem and branch of a given calendar year, read against the birth chart.", "zh-Hans": "某一年的干支，与本命盘对照来看。", "zh-Hant": "某一年的干支，與本命盤對照來看。", ja: "ある年の干支を命式と照らして読みます。", ko: "해당 연도의 간지를 본명과 대조해 봅니다.", vi: "Can chi của một năm cụ thể, đối chiếu với lá số gốc.", th: "ก้านกิ่งของปีนั้น อ่านเทียบกับดวงกำเนิด" }),
  E({ en: ["Five Elements", "five elements"], "zh-Hans": ["五行"], "zh-Hant": ["五行"], ja: ["五行"], ko: ["오행"], vi: ["Ngũ hành", "ngũ hành"], th: ["ห้าธาตุ"] },
    { en: "Wood, Fire, Earth, Metal and Water, which support and restrain one another in fixed cycles.", "zh-Hans": "木、火、土、金、水，按固定顺序相生相克。", "zh-Hant": "木、火、土、金、水，按固定順序相生相剋。", ja: "木・火・土・金・水。決まった順で互いに生じ、剋し合います。", ko: "목·화·토·금·수로, 정해진 순서로 서로 생하고 극합니다.", vi: "Mộc, Hỏa, Thổ, Kim, Thủy, tương sinh và tương khắc theo chu trình cố định.", th: "ไม้ ไฟ ดิน โลหะ น้ำ ที่ส่งเสริมและข่มกันตามลำดับตายตัว" }),
  E({ en: ["NaYin"], "zh-Hans": ["纳音"], "zh-Hant": ["納音"], ja: ["納音"], ko: ["납음"], vi: ["Nạp âm", "nạp âm"], th: ["น่ายิน"] },
    { en: "A traditional image-name given to each pair of the sixty stem-branch combinations, such as 'Sword-edge Metal'.", "zh-Hans": "六十甲子每两组配一个五行意象名，如“剑锋金”。", "zh-Hant": "六十甲子每兩組配一個五行意象名，如「劍鋒金」。", ja: "六十干支を二つずつまとめた五行のイメージ名（例：剣鋒金）。", ko: "육십갑자를 둘씩 묶어 붙인 오행 이미지 이름(예: 검봉금).", vi: "Tên hình tượng ngũ hành cho từng cặp trong sáu mươi hoa giáp, như 'Kiếm Phong Kim'.", th: "ชื่อภาพธาตุประจำคู่ของหกสิบก้านกิ่ง เช่น 'โลหะคมดาบ'" }),
  E({ en: ["Life palace", "Life Palace"], "zh-Hans": ["命宫"], "zh-Hant": ["命宮"], ja: ["命宮"], ko: ["명궁"], vi: ["Cung Mệnh", "cung Mệnh"], th: ["วังชะตา"] },
    { en: "The Zi Wei palace that describes the person as a whole; the other eleven palaces are read from it.", "zh-Hans": "紫微斗数中代表命主整体的宫位，其余十一宫由此展开。", "zh-Hant": "紫微斗數中代表命主整體的宮位，其餘十一宮由此展開。", ja: "紫微斗数で本人全体を表す宮。他の十一宮はここから展開します。", ko: "자미두수에서 본인 전체를 나타내는 궁으로, 나머지 열한 궁이 여기서 펼쳐집니다.", vi: "Cung trong Tử Vi mô tả tổng thể con người; mười một cung còn lại xếp từ đây.", th: "วังในจื่อเวยที่บอกภาพรวมของเจ้าชะตา วังอื่นอีกสิบเอ็ดวังจัดต่อจากที่นี่" }),
  E({ en: ["Four transformations", "four transformations"], "zh-Hans": ["四化"], "zh-Hant": ["四化"], ja: ["四化"], ko: ["사화"], vi: ["Tứ hóa", "tứ hóa"], th: ["สี่การแปร"] },
    { en: "Prosperity, power, fame and obstacle: four marks the year stem places on particular stars.", "zh-Hans": "化禄、化权、化科、化忌，由年干加在特定星曜上。", "zh-Hant": "化祿、化權、化科、化忌，由年干加在特定星曜上。", ja: "化禄・化権・化科・化忌。年干によって特定の星に付きます。", ko: "화록·화권·화과·화기로, 연간에 따라 특정 별에 붙습니다.", vi: "Hóa Lộc, Hóa Quyền, Hóa Khoa, Hóa Kỵ — can năm gắn vào những sao nhất định.", th: "ลาภ อำนาจ ชื่อเสียง อุปสรรค สี่เครื่องหมายที่ก้านปีมอบให้ดาวบางดวง" }),
  E({ en: ["Moving line", "moving lines", "changing line"], "zh-Hans": ["动爻"], "zh-Hant": ["動爻"], ja: ["動爻"], ko: ["동효"], vi: ["Hào động", "hào động"], th: ["เส้นเคลื่อน"] },
    { en: "A line that turns into its opposite; it shows where the situation is changing and produces the changed hexagram.", "zh-Hans": "会变为相反阴阳的爻，表示事情变化之处，并由此得出变卦。", "zh-Hant": "會變為相反陰陽的爻，表示事情變化之處，並由此得出變卦。", ja: "陰陽が反転する爻。変化の場所を示し、変卦を生みます。", ko: "음양이 바뀌는 효로, 변화가 일어나는 곳을 보여 주고 변괘를 만듭니다.", vi: "Hào đổi sang âm dương ngược lại; chỉ chỗ sự việc đang biến đổi và tạo ra quẻ biến.", th: "เส้นที่กลับหยินหยาง ชี้จุดที่สถานการณ์กำลังเปลี่ยน และให้กำเนิดกว้าแปร" }),
  E({ en: ["Changed hexagram", "transformed hexagram"], "zh-Hans": ["变卦"], "zh-Hant": ["變卦"], ja: ["変卦", "之卦"], ko: ["변괘"], vi: ["Quẻ biến", "quẻ biến"], th: ["กว้าแปร"] },
    { en: "The hexagram after the moving lines change; traditionally read as where the matter is heading.", "zh-Hans": "动爻变化后得到的卦，传统上看作事情的走向。", "zh-Hant": "動爻變化後得到的卦，傳統上看作事情的走向。", ja: "動爻が変わった後の卦。伝統的に物事の行き先とされます。", ko: "동효가 바뀐 뒤의 괘로, 전통적으로 일의 향방으로 봅니다.", vi: "Quẻ có được sau khi hào động biến; theo truyền thống chỉ hướng đi của sự việc.", th: "กว้าที่ได้หลังเส้นเคลื่อนเปลี่ยน ตามประเพณีมองเป็นทิศทางของเรื่อง" }),
  E({ en: ["Void", "void branches"], "zh-Hans": ["空亡", "旬空"], "zh-Hant": ["空亡", "旬空"], ja: ["空亡"], ko: ["공망"], vi: ["Không vong", "Tuần không"], th: ["ความว่างเปล่า"] },
    { en: "Two branches left out of the current ten-day cycle; traditionally they weaken whatever falls on them.", "zh-Hans": "当前一旬中轮空的两个地支，传统上认为落在其上的事物力量减弱。", "zh-Hant": "當前一旬中輪空的兩個地支，傳統上認為落在其上的事物力量減弱。", ja: "その旬で欠ける二つの地支。伝統的にそこに当たるものは力が弱まるとされます。", ko: "현재 순(旬)에서 빠진 두 지지로, 전통적으로 그 위의 것은 힘이 약해진다고 봅니다.", vi: "Hai địa chi bị khuyết trong tuần hiện tại; theo truyền thống làm yếu những gì rơi vào đó.", th: "กิ่งดินสองตัวที่ขาดไปในรอบสิบวัน ตามประเพณีทำให้สิ่งที่ตกอยู่ตรงนั้นอ่อนแรง" }),
  E({ en: ["Eight Gates", "eight gates"], "zh-Hans": ["八门"], "zh-Hant": ["八門"], ja: ["八門"], ko: ["팔문"], vi: ["Bát môn"], th: ["แปดประตู"] },
    { en: "In Qi Men Dun Jia, eight gates (Rest, Life, Harm, Delusion, View, Death, Fear, Open) placed in the palaces, read for human affairs.", "zh-Hans": "奇门遁甲中的休、生、伤、杜、景、死、惊、开八门，用来看人事。", "zh-Hant": "奇門遁甲中的休、生、傷、杜、景、死、驚、開八門，用來看人事。", ja: "奇門遁甲の休・生・傷・杜・景・死・驚・開の八門。人事を見るのに使います。", ko: "기문둔갑의 휴·생·상·두·경·사·경·개 팔문으로, 사람의 일을 봅니다.", vi: "Tám cửa trong Kỳ Môn (Hưu, Sinh, Thương, Đỗ, Cảnh, Tử, Kinh, Khai) dùng để xem việc người.", th: "แปดประตูในฉีเหมินตุ้นเจี่ย ใช้อ่านเรื่องของผู้คน" }),
  E({ en: ["Body and function", "body and function"], "zh-Hans": ["体用"], "zh-Hant": ["體用"], ja: ["体用"], ko: ["체용"], vi: ["Thể dụng"], th: ["กายกับการใช้"] },
    { en: "In plum blossom numerology the trigram without the moving line is the body (you) and the other is the function (the matter).", "zh-Hans": "梅花易数中不含动爻的卦为体（自己），含动爻的卦为用（所问之事）。", "zh-Hant": "梅花易數中不含動爻的卦為體（自己），含動爻的卦為用（所問之事）。", ja: "梅花易数では動爻のない卦が体（自分）、ある卦が用（事柄）です。", ko: "매화역수에서 동효가 없는 괘가 체(나), 있는 괘가 용(일)입니다.", vi: "Trong Mai Hoa, quẻ không có hào động là thể (bản thân), quẻ có hào động là dụng (sự việc).", th: "ในเหมยฮวา กว้าที่ไม่มีเส้นเคลื่อนคือกาย (ตัวเรา) อีกกว้าคือการใช้ (เรื่องที่ถาม)" }),
  E({ en: ["Solar term", "solar terms"], "zh-Hans": ["节气"], "zh-Hant": ["節氣"], ja: ["節気"], ko: ["절기"], vi: ["Tiết khí", "tiết khí"], th: ["สารท", "ฤดูกาลย่อย"] },
    { en: "The 24 points of the sun's yearly path; the month pillar changes at the 12 major ones, not on the lunar new month.", "zh-Hans": "太阳一年运行的 24 个节点；月柱在 12 个“节”交替，而不是农历初一。", "zh-Hant": "太陽一年運行的 24 個節點；月柱在 12 個「節」交替，而不是農曆初一。", ja: "太陽の一年の運行の24の区切り。月柱は旧暦の朔日ではなく12の節で替わります。", ko: "태양의 1년 운행을 24로 나눈 점으로, 월주는 음력 초하루가 아닌 12절에서 바뀝니다.", vi: "24 điểm trên đường đi của mặt trời; trụ tháng đổi ở 12 tiết chính chứ không phải mùng một âm lịch.", th: "24 จุดบนเส้นทางของดวงอาทิตย์ในหนึ่งปี เสาเดือนเปลี่ยนที่ 12 จุดหลัก ไม่ใช่วันขึ้นเดือนจันทรคติ" }),
];

/** All terms: the original list (with plain glosses added) followed by the newer terms. */
export const glossary: Entry[] = [
  ...coreGlossary.map((entry) => ({ ...entry, short: coreShorts[entry.names.en[0]] })),
  ...extraGlossary,
];

// Some term names are also everyday words; skip those uses so notes only appear on real chart terms.
const NOT_A_TERM: Array<{ name: string; before?: RegExp; after?: RegExp }> = [
  { name: "상관", after: /^(없|있|하|관|계|이 없)/ },          // 상관없이 "regardless", 상관하다 "to mind"
  { name: "지지", after: /^(하|해|했|받|자|율|층|세력|를 받)/ }, // 지지하다 "to support"
  { name: "비견", after: /^(되|될|할|하|된)/ },                 // 비견되다 "to be comparable"
  { name: "편재", after: /^(하|해|되|돼)/ },                    // 편재하다 "to be ubiquitous"
  { name: "格局", before: /(人生|眼界|思维|心胸|视野|做事|大)$/, after: /^(大|小|打开|要|更|开阔|放大|太)/ }, // 格局要大 "think big"
  { name: "比肩", before: /(可以|能够|足以|与|和|堪与|相)$/, after: /^(而|齐|于)/ },        // 可以比肩 "rival"
  { name: "比肩", after: /^(する|し|でき)/ },
];
const isLatin = (text: string) => /[A-Za-z]/.test(text);
/** Whether `name` at `index` in `text` really is the chart term (whole word for Latin script; not an everyday word). */
function isTermAt(text: string, index: number, name: string) {
  const before = text.slice(0, index), after = text.slice(index + name.length);
  if (isLatin(name) && (/\p{L}$/u.test(before) || /^\p{L}/u.test(after))) return false;
  return !NOT_A_TERM.some((rule) => rule.name === name && ((rule.before && rule.before.test(before)) || (rule.after && rule.after.test(after))));
}
function findTerm(text: string, name: string) {
  for (let index = text.indexOf(name); index >= 0; index = text.indexOf(name, index + 1)) if (isTermAt(text, index, name)) return index;
  return -1;
}

/** Split a text into plain parts and glossary terms (first occurrence of each term only). */
export function splitTerms(text: string, locale: Locale): Array<string | { term: string; tip: string; short?: string }> {
  const candidates = glossary.flatMap((entry) => entry.names[locale].map((name) => ({ name, tip: entry.tip[locale], short: entry.short?.[locale] }))).sort((a, b) => b.name.length - a.name.length);
  const out: Array<string | { term: string; tip: string; short?: string }> = [];
  const used = new Set<string>();
  let rest = text;
  while (rest) {
    let best: { index: number; name: string; tip: string; short?: string } | null = null;
    for (const candidate of candidates) {
      if (used.has(candidate.tip)) continue;
      const index = findTerm(rest, candidate.name);
      if (index >= 0 && (!best || index < best.index)) best = { index, ...candidate };
    }
    if (!best) { out.push(rest); break; }
    if (best.index > 0) out.push(rest.slice(0, best.index));
    out.push({ term: best.name, tip: best.tip, short: best.short });
    used.add(best.tip);
    rest = rest.slice(best.index + best.name.length);
  }
  return out;
}

/** Plain gloss for a chart value written in Chinese (e.g. a Ten God such as 正官), for 普通版 on the chart board. */
export function shortGloss(raw: string, locale: Locale): string | null {
  const key = raw.trim();
  const entry = glossary.find((item) => item.names["zh-Hans"].includes(key) || item.names["zh-Hant"].includes(key) || item.names.en.includes(key));
  return entry?.short?.[locale] ?? null;
}
