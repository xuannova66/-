// Names and one-line descriptions of the toolkit tools, matching what each tool now calculates.
import type { Locale } from "./site-content";
import type { ToolkitKey } from "./study-suite";

type Row = [string, string, string, string, string, string, string]; // en, zh-Hans, zh-Hant, ja, ko, vi, th
const ORDER: Locale[] = ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"];

const TITLES: Record<ToolkitKey, Row> = {
  time: ["Birth-hour finder", "寻时定盘", "尋時定盤", "生まれ時刻の確認", "출생 시각 찾기", "Tìm giờ sinh", "หาเวลาเกิด"],
  elements: ["Five Elements balance", "五行喜忌速测", "五行喜忌速測", "五行バランス", "오행 균형", "Cân bằng ngũ hành", "สมดุลห้าธาตุ"],
  dream: ["Dream images", "解梦", "解夢", "夢のイメージ", "꿈 해석", "Giải mộng", "ตีความฝัน"],
  name: ["Name study", "姓名参详", "姓名參詳", "名前の研究", "이름 연구", "Nghiên cứu tên", "ศึกษาชื่อ"],
  tarot: ["Tarot", "塔罗牌", "塔羅牌", "タロット", "타로", "Tarot", "ไพ่ทาโรต์"],
  iching: ["I Ching", "周易研习", "易經研習", "易経", "주역", "Kinh Dịch", "อี้จิง"],
  natal: ["Natal chart", "星盘解析", "星盤解析", "ネイタルチャート", "네이털 차트", "Bản đồ sao", "ดวงกำเนิด"],
  meihua: ["Plum blossom numerology", "梅花易数", "梅花易數", "梅花易数", "매화역수", "Mai Hoa Dịch Số", "เหมยฮวาอี้ซู่"],
  fengshui: ["Space & Qi", "空间气场", "空間氣場", "空間の気", "공간의 기", "Khí trường không gian", "ชี่ของพื้นที่"],
};
const DESCRIPTIONS: Record<ToolkitKey, Row> = {
  time: ["Compare the twelve possible birth hours of a date: hour pillar, ten god and relations.", "列出某日十二个候选时辰的时柱、十神与关系，帮助确认出生时辰。", "列出某日十二個候選時辰的時柱、十神與關係，幫助確認出生時辰。", "ある日の候補となる十二時辰の時柱・通変星・関係を比べます。", "하루의 후보 12시진의 시주, 십성, 관계를 비교합니다.", "So sánh mười hai giờ có thể của một ngày: trụ giờ, thập thần và quan hệ.", "เปรียบเทียบสิบสองยามที่เป็นไปได้ของวันหนึ่ง: เสายาม สิบเทพ และความสัมพันธ์"],
  elements: ["Count each element in the birth pillars, with roots and seasonal strength.", "统计出生四柱中的五行，含藏干与旺相休囚。", "統計出生四柱中的五行，含藏干與旺相休囚。", "四柱の五行を数え、蔵干と季節の強さも示します。", "사주의 오행을 장간과 계절 강약까지 함께 셉니다.", "Đếm ngũ hành trong tứ trụ, kèm tàng can và vượng suy theo mùa.", "นับธาตุในสี่เสา พร้อมก้านซ่อนและความแข็งแรงตามฤดู"],
  dream: ["Describe a dream; recognised images are matched to their traditional associations.", "描述梦境，识别其中的意象并给出传统寓意。", "描述夢境，識別其中的意象並給出傳統寓意。", "夢を書くと、イメージを見つけて伝統的な意味を示します。", "꿈을 적으면 이미지를 찾아 전통적 의미를 보여 줍니다.", "Mô tả giấc mơ; hình ảnh được nhận ra sẽ kèm ý nghĩa truyền thống.", "เล่าความฝัน แล้วระบบจะจับภาพในฝันกับความหมายตามประเพณี"],
  name: ["Read a name beside the five-element balance of the birth chart.", "把姓名与出生命盘的五行分布对照参看。", "把姓名與出生命盤的五行分布對照參看。", "名前と命式の五行バランスを並べて見ます。", "이름을 사주의 오행 분포와 함께 봅니다.", "Đọc tên cùng với cân bằng ngũ hành của lá số.", "อ่านชื่อคู่กับสมดุลห้าธาตุของดวงกำเนิด"],
  tarot: ["Draw three cards from a full 78-card deck for your question.", "从完整 78 张牌中为你的问题抽三张。", "從完整 78 張牌中為你的問題抽三張。", "78枚のデッキから質問に合わせて3枚を引きます。", "78장 전체 덱에서 질문에 맞춰 세 장을 뽑습니다.", "Rút ba lá từ bộ 78 lá đầy đủ cho câu hỏi của bạn.", "จั่วไพ่สามใบจากสำรับเต็ม 78 ใบสำหรับคำถามของคุณ"],
  iching: ["Raise a hexagram from the moment and read it with Na Jia, six relatives and six spirits.", "按时间起卦，以纳甲、六亲、六神解读。", "按時間起卦，以納甲、六親、六神解讀。", "その時刻から卦を立て、納甲・六親・六神で読みます。", "그 시각으로 괘를 세워 납갑, 육친, 육신으로 읽습니다.", "Lập quẻ theo thời điểm và đọc bằng nạp giáp, lục thân, lục thần.", "ตั้งกว้าจากช่วงเวลา แล้วอ่านด้วยน่าเจี่ย หกญาติ และหกวิญญาณ"],
  natal: ["Planets in the zodiac signs at birth, their aspects and, with a city, the ascendant.", "出生时行星所在星座、相位，选择城市后可算上升点。", "出生時行星所在星座、相位，選擇城市後可算上升點。", "出生時の惑星の星座とアスペクト、都市を選ぶとアセンダントも表示します。", "출생 시 행성의 별자리와 각도, 도시를 고르면 상승점까지 보여 줍니다.", "Vị trí hành tinh trong cung hoàng đạo lúc sinh, góc chiếu và điểm mọc khi chọn thành phố.", "ตำแหน่งดาวในราศีตอนเกิด มุมสัมพันธ์ และลัคนาเมื่อเลือกเมือง"],
  meihua: ["Plum blossom time casting: original, mutual and changed hexagrams with body and function.", "梅花易数时间起卦：本卦、互卦、变卦与体用关系。", "梅花易數時間起卦：本卦、互卦、變卦與體用關係。", "梅花易数の時間起卦：本卦・互卦・変卦と体用。", "매화역수 시간 기괘: 본괘, 호괘, 변괘와 체용 관계.", "Mai Hoa lập quẻ theo thời gian: quẻ chủ, quẻ hỗ, quẻ biến và thể dụng.", "ตั้งกว้าแบบเหมยฮวาตามเวลา: กว้าหลัก กว้าซ้อน กว้าแปร และกายกับการใช้"],
  fengshui: ["Eight Mansions directions for you and your home, with this year's flying stars.", "八宅：个人命卦与宅卦的方位，以及今年的飞星。", "八宅：個人命卦與宅卦的方位，以及今年的飛星。", "八宅：本命卦と宅卦の方位、今年の飛星。", "팔택: 본인 명괘와 집 괘의 방위, 올해의 비성.", "Bát Trạch: hướng theo mệnh quái và trạch quái, cùng phi tinh năm nay.", "แปดคฤหาสน์: ทิศตามกว้าประจำตัวและกว้าบ้าน พร้อมดาวบินปีนี้"],
};

export const toolkitName = (key: ToolkitKey, locale: Locale) => TITLES[key][ORDER.indexOf(locale)] ?? TITLES[key][0];
export const toolkitLead = (key: ToolkitKey, locale: Locale) => DESCRIPTIONS[key][ORDER.indexOf(locale)] ?? DESCRIPTIONS[key][0];

export const sittingLabel: Record<Locale, string> = { en: "House sits toward (its back)", "zh-Hans": "房屋坐向（背面朝向）", "zh-Hant": "房屋坐向（背面朝向）", ja: "家の坐向（背面の方角）", ko: "집의 좌향(뒷면 방향)", vi: "Hướng tọa của nhà (mặt sau)", th: "ทิศที่บ้านหันหลังให้" };
