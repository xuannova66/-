"use client";

// Back-office tools: member groups, exclusive credit packages, credit grants (one member, a group,
// a pasted list or every member), lecture videos (link or upload) and invitation team totals.
import { shareReportText as SR, sourceLabel } from "./share-source-labels";
import { useCallback, useEffect, useState } from "react";
import type { Locale } from "./site-content";

type Group = { id: string; name: string; note: string | null; memberCount: number; createdAt: string };
type Pkg = { id: string; name: string; credits: number; priceUsdt: string; memberEmail: string | null; groupName: string | null; active: boolean; createdAt: string };
type Grant = { id: string; target?: "single" | "all" | "list"; listSize?: number | null; memberEmail: string | null; groupName: string | null; credits: number; reason: string; status: "pending" | "approved" | "rejected"; requestedBy: string; reviewedBy: string | null; createdAt: string };

type Copy = {
  groups: string; packages: string; grants: string; name: string; note: string; members: string; membersHint: string; createGroup: string; addMembers: string; removeMembers: string; target: string; member: string; group: string;
  credits: string; price: string; createPackage: string; active: string; inactive: string; toggle: string; reason: string; requestGrant: string; approve: string; reject: string; pending: string; approved: string; rejected: string;
  requestedBy: string; reviewedBy: string; grantHint: string; packageHint: string; saved: string; missing: string; none: string; choose: string;
};
const copy: Record<Locale, Copy> = {
  en: { groups: "Member groups", packages: "Exclusive packages", grants: "Credit grants", name: "Name", note: "Note", members: "Members", membersHint: "Emails or wallet addresses, one per line", createGroup: "Create group", addMembers: "Add to group", removeMembers: "Remove from group", target: "For", member: "Member (email / wallet)", group: "Group", credits: "Credits", price: "Price (USDT)", createPackage: "Create package", active: "Active", inactive: "Hidden", toggle: "Show / hide", reason: "Reason", requestGrant: "Request grant", approve: "Approve", reject: "Reject", pending: "Pending", approved: "Approved", rejected: "Rejected", requestedBy: "Requested by", reviewedBy: "Reviewed by", grantHint: "Submit a grant, then press Approve to add the credits. Every step is recorded in the audit log.", packageHint: "Only the chosen member or group sees this package; payment is a reviewed manual transfer.", saved: "Saved.", missing: "Not found:", none: "Nothing yet.", choose: "Choose…" },
  "zh-Hans": { groups: "会员分组", packages: "专属积分包", grants: "手动加积分", name: "名称", note: "备注", members: "会员", membersHint: "每行一个邮箱或钱包地址", createGroup: "新建分组", addMembers: "加入分组", removeMembers: "移出分组", target: "适用对象", member: "会员（邮箱/钱包）", group: "分组", credits: "积分", price: "价格（USDT）", createPackage: "新建积分包", active: "上架", inactive: "已隐藏", toggle: "上架 / 隐藏", reason: "原因", requestGrant: "提交加积分申请", approve: "批准", reject: "驳回", pending: "待审批", approved: "已批准", rejected: "已驳回", requestedBy: "申请人", reviewedBy: "审批人", grantHint: "提交加积分申请后，点“批准”即到账，每一步都会记入操作日志。", packageHint: "只有指定会员或分组能看到这个积分包；付款走人工审核的转账订单。", saved: "已保存。", missing: "未找到：", none: "暂无记录。", choose: "请选择…" },
  "zh-Hant": { groups: "會員分組", packages: "專屬積分包", grants: "手動加積分", name: "名稱", note: "備註", members: "會員", membersHint: "每行一個信箱或錢包地址", createGroup: "新建分組", addMembers: "加入分組", removeMembers: "移出分組", target: "適用對象", member: "會員（信箱/錢包）", group: "分組", credits: "積分", price: "價格（USDT）", createPackage: "新建積分包", active: "上架", inactive: "已隱藏", toggle: "上架 / 隱藏", reason: "原因", requestGrant: "提交加積分申請", approve: "核准", reject: "駁回", pending: "待審批", approved: "已核准", rejected: "已駁回", requestedBy: "申請人", reviewedBy: "審批人", grantHint: "提交加積分申請後，點「核准」即入帳，每一步都會記入操作日誌。", packageHint: "只有指定會員或分組能看到這個積分包；付款走人工審核的轉帳訂單。", saved: "已儲存。", missing: "找不到：", none: "暫無紀錄。", choose: "請選擇…" },
  ja: { groups: "会員グループ", packages: "専用クレジットパック", grants: "クレジット付与", name: "名称", note: "メモ", members: "会員", membersHint: "メールまたはウォレットアドレスを1行に1件", createGroup: "グループ作成", addMembers: "グループに追加", removeMembers: "グループから外す", target: "対象", member: "会員（メール/ウォレット）", group: "グループ", credits: "クレジット", price: "価格（USDT）", createPackage: "パック作成", active: "公開", inactive: "非表示", toggle: "公開 / 非表示", reason: "理由", requestGrant: "付与を申請", approve: "承認", reject: "却下", pending: "承認待ち", approved: "承認済み", rejected: "却下済み", requestedBy: "申請者", reviewedBy: "承認者", grantHint: "申請後に「承認」を押すと付与されます。すべての操作は監査ログに記録されます。", packageHint: "指定した会員またはグループだけに表示されます。支払いは審査付きの手動送金です。", saved: "保存しました。", missing: "見つかりません：", none: "まだありません。", choose: "選択…" },
  ko: { groups: "회원 그룹", packages: "전용 크레딧 패키지", grants: "크레딧 지급", name: "이름", note: "메모", members: "회원", membersHint: "한 줄에 이메일 또는 지갑 주소 하나", createGroup: "그룹 만들기", addMembers: "그룹에 추가", removeMembers: "그룹에서 제외", target: "대상", member: "회원(이메일/지갑)", group: "그룹", credits: "크레딧", price: "가격(USDT)", createPackage: "패키지 만들기", active: "공개", inactive: "숨김", toggle: "공개 / 숨김", reason: "사유", requestGrant: "지급 요청", approve: "승인", reject: "거절", pending: "승인 대기", approved: "승인됨", rejected: "거절됨", requestedBy: "요청자", reviewedBy: "승인자", grantHint: "요청 후 '승인'을 누르면 지급됩니다. 모든 단계는 감사 기록에 남습니다.", packageHint: "지정한 회원이나 그룹에게만 보이며, 결제는 검토를 거치는 수동 송금입니다.", saved: "저장했습니다.", missing: "찾을 수 없음:", none: "아직 없습니다.", choose: "선택…" },
  vi: { groups: "Nhóm thành viên", packages: "Gói điểm riêng", grants: "Cộng điểm thủ công", name: "Tên", note: "Ghi chú", members: "Thành viên", membersHint: "Mỗi dòng một email hoặc địa chỉ ví", createGroup: "Tạo nhóm", addMembers: "Thêm vào nhóm", removeMembers: "Xóa khỏi nhóm", target: "Áp dụng cho", member: "Thành viên (email/ví)", group: "Nhóm", credits: "Điểm", price: "Giá (USDT)", createPackage: "Tạo gói", active: "Đang hiển thị", inactive: "Đã ẩn", toggle: "Hiện / ẩn", reason: "Lý do", requestGrant: "Gửi yêu cầu cộng điểm", approve: "Duyệt", reject: "Từ chối", pending: "Chờ duyệt", approved: "Đã duyệt", rejected: "Đã từ chối", requestedBy: "Người yêu cầu", reviewedBy: "Người duyệt", grantHint: "Gửi yêu cầu rồi bấm Duyệt để cộng điểm. Mọi bước đều được ghi vào nhật ký.", packageHint: "Chỉ thành viên hoặc nhóm được chọn thấy gói này; thanh toán qua chuyển khoản thủ công có kiểm duyệt.", saved: "Đã lưu.", missing: "Không tìm thấy:", none: "Chưa có.", choose: "Chọn…" },
  th: { groups: "กลุ่มสมาชิก", packages: "แพ็กเกจคะแนนเฉพาะ", grants: "เพิ่มคะแนนด้วยตนเอง", name: "ชื่อ", note: "หมายเหตุ", members: "สมาชิก", membersHint: "อีเมลหรือที่อยู่กระเป๋าเงิน บรรทัดละหนึ่งรายการ", createGroup: "สร้างกลุ่ม", addMembers: "เพิ่มเข้ากลุ่ม", removeMembers: "นำออกจากกลุ่ม", target: "สำหรับ", member: "สมาชิก (อีเมล/กระเป๋าเงิน)", group: "กลุ่ม", credits: "คะแนน", price: "ราคา (USDT)", createPackage: "สร้างแพ็กเกจ", active: "แสดงอยู่", inactive: "ซ่อนอยู่", toggle: "แสดง / ซ่อน", reason: "เหตุผล", requestGrant: "ส่งคำขอเพิ่มคะแนน", approve: "อนุมัติ", reject: "ปฏิเสธ", pending: "รออนุมัติ", approved: "อนุมัติแล้ว", rejected: "ปฏิเสธแล้ว", requestedBy: "ผู้ขอ", reviewedBy: "ผู้อนุมัติ", grantHint: "ส่งคำขอแล้วกดอนุมัติเพื่อเพิ่มคะแนน ทุกขั้นตอนถูกบันทึกในประวัติการดำเนินการ", packageHint: "เฉพาะสมาชิกหรือกลุ่มที่เลือกเห็นแพ็กเกจนี้ ชำระผ่านการโอนที่มีการตรวจสอบ", saved: "บันทึกแล้ว", missing: "ไม่พบ:", none: "ยังไม่มี", choose: "เลือก…" },
};

const LOCALES: Locale[] = ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"];
type Lecture = { id: string; title: Partial<Record<Locale, string>>; summary: Partial<Record<Locale, string>>; videoUrl: string | null; mediaFile: string | null; membersOnly: boolean; durationMinutes: number | null; sortOrder: number; published: boolean };
type LectureForm = { id: string; title: Partial<Record<Locale, string>>; summary: Partial<Record<Locale, string>>; videoUrl: string; mediaFile: string; membersOnly: boolean; duration: string; sort: string; published: boolean };
const emptyLecture: LectureForm = { id: "", title: {}, summary: {}, videoUrl: "", mediaFile: "", membersOnly: true, duration: "", sort: "0", published: true };
const T = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): Record<Locale, string> => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });
const lectureText = {
  tab: T("Lectures", "讲堂视频", "講堂影片", "講義動画", "강의 영상", "Bài giảng", "วิดีโอบรรยาย"),
  hint: T("Upload a video file (MP4, WebM or MOV), or paste a YouTube, Vimeo or https MP4 link. Members-only lessons are free for every signed-in member; visitors are asked to sign in. Fill every language title you have; missing ones fall back to English.", "上传视频文件（MP4、WebM、MOV），或粘贴 YouTube、Vimeo、https MP4 链接。“仅会员”的课程所有登录会员免费观看，未登录访客会被提示登录。尽量填写 7 种语言标题，缺少的语言显示英文。", "上傳影片檔（MP4、WebM、MOV），或貼上 YouTube、Vimeo、https MP4 連結。「僅會員」的課程所有登入會員免費觀看，未登入訪客會被提示登入。盡量填寫 7 種語言標題，缺少的語言顯示英文。", "動画ファイル（MP4・WebM・MOV）をアップロードするか、YouTube・Vimeo・https の MP4 リンクを貼り付けます。「会員限定」の講座はログインした会員なら無料で視聴でき、未ログインの方にはログインを案内します。不足する言語は英語で表示されます。", "영상 파일(MP4, WebM, MOV)을 업로드하거나 YouTube, Vimeo, https MP4 링크를 붙여 넣으세요. '회원 전용' 강좌는 로그인한 회원 모두 무료로 보며, 비회원에게는 로그인을 안내합니다. 비어 있는 언어는 영어로 표시됩니다.", "Tải lên tệp video (MP4, WebM, MOV) hoặc dán liên kết YouTube, Vimeo, MP4 https. Bài học “chỉ thành viên” miễn phí cho mọi thành viên đã đăng nhập; khách sẽ được mời đăng nhập. Ngôn ngữ còn thiếu sẽ hiển thị tiếng Anh.", "อัปโหลดไฟล์วิดีโอ (MP4, WebM, MOV) หรือวางลิงก์ YouTube, Vimeo, MP4 แบบ https บทเรียน \"เฉพาะสมาชิก\" สมาชิกที่เข้าสู่ระบบดูฟรีทุกคน ผู้เยี่ยมชมจะได้รับคำแนะนำให้เข้าสู่ระบบ ภาษาที่ไม่ได้กรอกจะแสดงเป็นภาษาอังกฤษ"),
  title: T("Title", "标题", "標題", "タイトル", "제목", "Tiêu đề", "ชื่อ"),
  summary: T("Summary", "简介", "簡介", "概要", "소개", "Tóm tắt", "สรุป"),
  url: T("Video link", "视频链接", "影片連結", "動画リンク", "영상 링크", "Liên kết video", "ลิงก์วิดีโอ"),
  duration: T("Minutes", "时长（分钟）", "時長（分鐘）", "長さ（分）", "길이(분)", "Thời lượng (phút)", "ความยาว (นาที)"),
  sort: T("Order", "排序", "排序", "並び順", "순서", "Thứ tự", "ลำดับ"),
  published: T("Published", "已发布", "已發布", "公開中", "게시됨", "Đã đăng", "เผยแพร่แล้ว"),
  draft: T("Draft", "草稿", "草稿", "下書き", "초안", "Bản nháp", "ฉบับร่าง"),
  create: T("Add lecture", "添加视频", "新增影片", "動画を追加", "영상 추가", "Thêm bài giảng", "เพิ่มวิดีโอ"),
  update: T("Save changes", "保存修改", "儲存修改", "変更を保存", "변경 저장", "Lưu thay đổi", "บันทึกการแก้ไข"),
  edit: T("Edit", "编辑", "編輯", "編集", "편집", "Sửa", "แก้ไข"),
  upload: T("Upload a video file", "上传视频文件", "上傳影片檔", "動画ファイルをアップロード", "영상 파일 업로드", "Tải lên tệp video", "อัปโหลดไฟล์วิดีโอ"),
  uploading: T("Uploading", "正在上传", "正在上傳", "アップロード中", "업로드 중", "Đang tải lên", "กำลังอัปโหลด"),
  uploaded: T("Uploaded file", "已上传文件", "已上傳檔案", "アップロード済み", "업로드된 파일", "Tệp đã tải lên", "ไฟล์ที่อัปโหลดแล้ว"),
  removeFile: T("Remove file", "移除文件", "移除檔案", "ファイルを外す", "파일 제거", "Gỡ tệp", "นำไฟล์ออก"),
  or: T("or paste a link", "或粘贴链接", "或貼上連結", "またはリンクを貼り付け", "또는 링크 붙여넣기", "hoặc dán liên kết", "หรือวางลิงก์"),
  membersOnly: T("Members only (free for every signed-in member)", "仅会员（所有登录会员免费观看）", "僅會員（所有登入會員免費觀看）", "会員限定（ログインした会員は無料）", "회원 전용(로그인 회원 모두 무료)", "Chỉ thành viên (miễn phí cho mọi thành viên đã đăng nhập)", "เฉพาะสมาชิก (สมาชิกที่เข้าสู่ระบบดูฟรี)"),
  openAll: T("Open to all", "公开课", "公開課", "どなたでも", "누구나 시청", "Mở cho mọi người", "เปิดให้ทุกคน"),
  membersTag: T("Members", "会员", "會員", "会員", "회원", "Thành viên", "สมาชิก"),
  needVideo: T("Upload a video or enter a link first.", "请先上传视频或填写链接。", "請先上傳影片或填寫連結。", "先に動画をアップロードするかリンクを入力してください。", "먼저 영상을 업로드하거나 링크를 입력하세요.", "Hãy tải video lên hoặc nhập liên kết trước.", "โปรดอัปโหลดวิดีโอหรือใส่ลิงก์ก่อน"),
};
const airdropText = {
  all: T("All members (airdrop)", "全部会员（空投）", "全部會員（空投）", "全会員（エアドロップ）", "전체 회원(에어드롭)", "Tất cả thành viên (airdrop)", "สมาชิกทั้งหมด (แอร์ดรอป)"),
  list: T("A list of members", "指定名单", "指定名單", "会員リスト", "회원 목록", "Danh sách thành viên", "รายชื่อสมาชิก"),
  listHint: T("Emails or wallet addresses, one per line (up to 2,000)", "每行一个邮箱或钱包地址（最多 2000 个）", "每行一個信箱或錢包地址（最多 2000 個）", "メールまたはウォレットアドレスを1行に1件（最大 2,000 件）", "한 줄에 이메일 또는 지갑 주소 하나(최대 2,000개)", "Mỗi dòng một email hoặc địa chỉ ví (tối đa 2.000)", "อีเมลหรือที่อยู่กระเป๋าเงิน บรรทัดละหนึ่งรายการ (สูงสุด 2,000)"),
  hint: T("Airdrops work the same way: after approval every listed member receives the credits once, with a ledger entry.", "空投同样先提交再批准；批准后名单内每位会员各到账一次，并记入积分明细。", "空投同樣先提交再核准；核准後名單內每位會員各入帳一次，並記入積分明細。", "エアドロップも申請してから承認します。承認後、対象の会員それぞれに1回だけ付与され、履歴に記録されます。", "에어드롭도 요청 후 승인합니다. 승인되면 대상 회원마다 한 번씩 지급되고 내역에 기록됩니다.", "Airdrop cũng gửi rồi duyệt; sau đó mỗi thành viên trong danh sách nhận điểm một lần, có ghi vào lịch sử.", "แอร์ดรอปก็ส่งคำขอแล้วอนุมัติเช่นกัน จากนั้นสมาชิกแต่ละคนได้รับคะแนนครั้งเดียวและบันทึกในประวัติ"),
  credited: T("members credited", "位会员已到账", "位會員已入帳", "人に付与", "명에게 지급", "thành viên đã nhận", "สมาชิกได้รับแล้ว"),
};
const teamText = {
  tab: T("Teams", "团队业绩", "團隊業績", "チーム実績", "팀 실적", "Đội nhóm", "ผลงานทีม"),
  hint: T("Members who invited others: how many joined with their code, how many of those bought, and the total they paid (approved USDT orders and paid card orders).", "邀请过他人的会员：通过其邀请码加入的人数、其中购买过的人数，以及这些人的消费总额（已通过的 USDT 订单和已支付的银行卡订单）。", "邀請過他人的會員：透過其邀請碼加入的人數、其中購買過的人數，以及這些人的消費總額（已核准的 USDT 訂單和已付款的信用卡訂單）。", "他の人を招待した会員：コードで参加した人数、そのうち購入した人数、その合計購入額（承認済み USDT 注文と支払済みカード注文）。", "다른 사람을 초대한 회원: 코드로 가입한 인원, 그중 구매한 인원, 그리고 총 결제액(승인된 USDT 주문과 결제된 카드 주문).", "Thành viên đã mời người khác: số người tham gia bằng mã, số người đã mua và tổng chi tiêu (đơn USDT đã duyệt và đơn thẻ đã thanh toán).", "สมาชิกที่เชิญผู้อื่น: จำนวนผู้เข้าร่วมด้วยรหัส จำนวนที่ซื้อ และยอดรวมที่ชำระ (คำสั่งซื้อ USDT ที่อนุมัติและคำสั่งซื้อบัตรที่ชำระแล้ว)"),
  inviter: T("Inviter", "邀请人", "邀請人", "招待者", "초대자", "Người mời", "ผู้เชิญ"),
  invited: T("Invited", "邀请人数", "邀請人數", "招待数", "초대 수", "Đã mời", "เชิญแล้ว"),
  purchasers: T("Buyers", "购买人数", "購買人數", "購入者", "구매자", "Người mua", "ผู้ซื้อ"),
  total: T("Team total (USD)", "团队总业绩（美元）", "團隊總業績（美元）", "チーム合計（USD）", "팀 합계(USD)", "Tổng đội (USD)", "ยอดรวมทีม (USD)"),
  credits: T("Team study credits", "团队研习总积分", "團隊研習總積分", "チームの学習クレジット合計", "팀 학습 크레딧 합계", "Tổng điểm học của đội", "เครดิตการศึกษารวมของทีม"),
  search: T("Search email", "搜索邮箱", "搜尋信箱", "メールで検索", "이메일 검색", "Tìm email", "ค้นหาอีเมล"),
  sum: T("All teams", "全部团队合计", "全部團隊合計", "全チーム合計", "전체 팀 합계", "Tổng tất cả", "รวมทุกทีม"),
};
type Team = { memberId: string; email: string | null; invited: number; purchasers: number; totalUsd: string; totalCredits?: number };

async function call<T>(path: string, body?: unknown): Promise<T> {
  const response = await fetch(path, { method: body === undefined ? "GET" : "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) });
  const payload = await response.json() as T & { error?: string };
  if (!response.ok) throw new Error(payload.error ?? "Request failed");
  return payload;
}
const lines = (value: string) => value.split(/[\n,;]+/).map((item) => item.trim()).filter(Boolean);

/** Uploads a video with progress (XMLHttpRequest reports upload progress; fetch does not). */
function uploadVideo(file: File, onProgress: (percent: number) => void): Promise<string> {
  return new Promise((resolve, reject) => {
    const request = new XMLHttpRequest();
    request.open("POST", "/api/admin/lectures/upload");
    request.withCredentials = true;
    request.setRequestHeader("x-file-name", file.name);
    request.setRequestHeader("content-type", file.type || "application/octet-stream");
    request.upload.onprogress = (event) => { if (event.lengthComputable) onProgress(Math.round((event.loaded / event.total) * 100)); };
    request.onload = () => {
      let payload: { file?: string; error?: string } = {};
      try { payload = JSON.parse(request.responseText) as typeof payload; } catch { /* not JSON */ }
      if (request.status >= 200 && request.status < 300 && payload.file) resolve(payload.file);
      else reject(new Error(payload.error ?? `Upload failed (${request.status})`));
    };
    request.onerror = () => reject(new Error("Upload failed"));
    request.send(file);
  });
}

export function AdminGrowthTools({ locale, view }: { locale: Locale; view: "groups" | "packages" | "grants" | "lectures" | "teams" }) {
  const text = copy[locale] ?? copy.en;
  const [groups, setGroups] = useState<Group[]>([]);
  const [packages, setPackages] = useState<Pkg[]>([]);
  const [grants, setGrants] = useState<Grant[]>([]);
  const [lectures, setLectures] = useState<Lecture[]>([]);
  const [lecture, setLecture] = useState<LectureForm>(emptyLecture);
  const [progress, setProgress] = useState<number | null>(null);
  const [teams, setTeams] = useState<Team[]>([]);
  const [shareRows, setShareRows] = useState<Array<{ source: string; made: number; saved: number; shared: number; visits: number; signups: number; invitedSignups: number; buyers: number }>>([]);
  const [teamQuery, setTeamQuery] = useState("");
  const [notice, setNotice] = useState("");
  const [form, setForm] = useState({ name: "", note: "", members: "", groupId: "", member: "", credits: "", price: "", reason: "", targetType: "member" as "member" | "group" | "all" | "list" });
  const load = useCallback(async () => {
    try {
      const [g, p, r] = await Promise.all([call<{ groups: Group[] }>("/api/admin/groups"), call<{ packages: Pkg[] }>("/api/admin/packages"), call<{ grants: Grant[] }>("/api/admin/grants")]);
      setGroups(g.groups); setPackages(p.packages); setGrants(r.grants);
      setLectures((await call<{ lectures: Lecture[] }>("/api/admin/lectures")).lectures);
      setTeams((await call<{ teams: Team[] }>("/api/admin/teams")).teams);
      try { setShareRows((await call<{ rows: typeof shareRows }>("/api/admin/share-report?days=30")).rows); } catch { setShareRows([]); }
    } catch (cause) { setNotice(cause instanceof Error ? cause.message : "Request failed"); }
  }, []);
  useEffect(() => { const timer = window.setTimeout(() => { void load(); }, 0); return () => window.clearTimeout(timer); }, [load]);
  const run = async (action: () => Promise<unknown>) => {
    setNotice("");
    try {
      const result = await action() as { missing?: string[]; membersCredited?: number };
      setNotice(result?.missing?.length ? `${text.missing} ${result.missing.join(", ")}` : typeof result?.membersCredited === "number" ? `${text.saved} ${result.membersCredited} ${airdropText.credited[locale]}` : text.saved);
      await load();
    } catch (cause) { setNotice(cause instanceof Error ? cause.message : "Request failed"); }
  };
  const target = () => (form.targetType === "member" ? { member: form.member } : form.targetType === "all" ? { target: "all" } : form.targetType === "list" ? { members: lines(form.members) } : { groupId: form.groupId });
  const targetFields = (airdrop = false) => <fieldset className="admin-target"><legend>{text.target}</legend>
    <label><input type="radio" checked={form.targetType === "member"} onChange={() => setForm({ ...form, targetType: "member" })} />{text.member}</label>
    <label><input type="radio" checked={form.targetType === "group"} onChange={() => setForm({ ...form, targetType: "group" })} />{text.group}</label>
    {airdrop && <label><input type="radio" checked={form.targetType === "list"} onChange={() => setForm({ ...form, targetType: "list" })} />{airdropText.list[locale]}</label>}
    {airdrop && <label><input type="radio" checked={form.targetType === "all"} onChange={() => setForm({ ...form, targetType: "all" })} />{airdropText.all[locale]}</label>}
    {form.targetType === "all" ? null : form.targetType === "list" ? <textarea value={form.members} onChange={(event) => setForm({ ...form, members: event.target.value })} placeholder={airdropText.listHint[locale]} aria-label={airdropText.list[locale]} />
      : form.targetType === "member" ? <input value={form.member} onChange={(event) => setForm({ ...form, member: event.target.value })} placeholder={text.member} aria-label={text.member} />
      : <select value={form.groupId} onChange={(event) => setForm({ ...form, groupId: event.target.value })} aria-label={text.group}><option value="">{text.choose}</option>{groups.map((group) => <option key={group.id} value={group.id}>{group.name} ({group.memberCount})</option>)}</select>}
  </fieldset>;
  const statusLabel = (status: Grant["status"]) => (status === "pending" ? text.pending : status === "approved" ? text.approved : text.rejected);

  return <section className="admin-panel admin-growth" data-view={view}>
    {view === "groups" && <>
      <form onSubmit={(event) => { event.preventDefault(); void run(() => call("/api/admin/groups", { name: form.name, note: form.note, add: lines(form.members) })); }}>
        <label>{text.name}<input value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} required minLength={2} /></label>
        <label>{text.note}<input value={form.note} onChange={(event) => setForm({ ...form, note: event.target.value })} /></label>
        <label>{text.members}<textarea value={form.members} onChange={(event) => setForm({ ...form, members: event.target.value })} placeholder={text.membersHint} /></label>
        <button type="submit" className="primary-action">{text.createGroup}</button>
      </form>
      <div className="admin-list">{groups.length ? groups.map((group) => <article key={group.id}><b>{group.name}</b><small>{group.memberCount} · {group.note ?? ""}</small>
        <div><button type="button" className="text-action" onClick={() => void run(() => call("/api/admin/groups", { groupId: group.id, add: lines(form.members) }))}>{text.addMembers}</button>
          <button type="button" className="text-action" onClick={() => void run(() => call("/api/admin/groups", { groupId: group.id, remove: lines(form.members) }))}>{text.removeMembers}</button></div></article>) : <p>{text.none}</p>}</div>
    </>}
    {view === "packages" && <>
      <p className="admin-hint">{text.packageHint}</p>
      <form onSubmit={(event) => { event.preventDefault(); void run(() => call("/api/admin/packages", { name: form.name, credits: Number(form.credits), priceUsdt: form.price, note: form.note, ...target() })); }}>
        <label>{text.name}<input value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} required /></label>
        <label>{text.credits}<input type="number" min={1} step={1} value={form.credits} onChange={(event) => setForm({ ...form, credits: event.target.value })} required /></label>
        <label>{text.price}<input inputMode="decimal" value={form.price} onChange={(event) => setForm({ ...form, price: event.target.value })} required /></label>
        {targetFields()}
        <button type="submit" className="primary-action">{text.createPackage}</button>
      </form>
      <div className="admin-list">{packages.length ? packages.map((pkg) => <article key={pkg.id}><b>{pkg.name}</b><small>{pkg.credits} · {pkg.priceUsdt} USDT · {pkg.memberEmail ?? pkg.groupName ?? ""} · {pkg.active ? text.active : text.inactive}</small>
        <button type="button" className="text-action" onClick={() => void run(() => call("/api/admin/packages", { id: pkg.id, active: !pkg.active }))}>{text.toggle}</button></article>) : <p>{text.none}</p>}</div>
    </>}
    {view === "grants" && <ResetLinkTool locale={locale} />}
    {view === "grants" && <>
      <p className="admin-hint">{text.grantHint} {airdropText.hint[locale]}</p>
      <form onSubmit={(event) => { event.preventDefault(); void run(() => call("/api/admin/grants", { credits: Number(form.credits), reason: form.reason, ...target() })); }}>
        <label>{text.credits}<input type="number" min={1} step={1} value={form.credits} onChange={(event) => setForm({ ...form, credits: event.target.value })} required /></label>
        <label>{text.reason}<input value={form.reason} onChange={(event) => setForm({ ...form, reason: event.target.value })} required minLength={3} /></label>
        {targetFields(true)}
        <button type="submit" className="primary-action">{text.requestGrant}</button>
      </form>
      <div className="admin-list">{grants.length ? grants.map((grant) => <article key={grant.id} data-status={grant.status}><b>{grant.target === "all" ? airdropText.all[locale] : grant.target === "list" ? `${airdropText.list[locale]} (${grant.listSize ?? 0})` : grant.memberEmail ?? grant.groupName} · +{grant.credits}</b>
        <small>{grant.reason} · {text.requestedBy} {grant.requestedBy}{grant.reviewedBy ? ` · ${text.reviewedBy} ${grant.reviewedBy}` : ""} · {statusLabel(grant.status)}</small>
        {grant.status === "pending" && <div><button type="button" className="text-action" onClick={() => void run(() => call(`/api/admin/grants/${grant.id}/decision`, { decision: "approve" }))}>{text.approve}</button>
          <button type="button" className="text-action" onClick={() => void run(() => call(`/api/admin/grants/${grant.id}/decision`, { decision: "reject" }))}>{text.reject}</button></div>}</article>) : <p>{text.none}</p>}</div>
    </>}
    {view === "lectures" && <>
      <p className="admin-hint">{lectureText.hint[locale]}</p>
      <form onSubmit={(event) => { event.preventDefault(); if (!lecture.mediaFile && !lecture.videoUrl.trim()) { setNotice(lectureText.needVideo[locale]); return; } void run(async () => { const result = await call("/api/admin/lectures", { id: lecture.id || undefined, title: lecture.title, summary: lecture.summary, videoUrl: lecture.mediaFile ? undefined : lecture.videoUrl.trim(), mediaFile: lecture.mediaFile || undefined, membersOnly: lecture.membersOnly, durationMinutes: Number(lecture.duration) || undefined, sortOrder: Number(lecture.sort) || 0, published: lecture.published }); setLecture(emptyLecture); return result; }); }}>
        {LOCALES.map((code) => <label key={`t-${code}`}>{lectureText.title[locale]} · {code}<input value={lecture.title[code] ?? ""} onChange={(event) => setLecture({ ...lecture, title: { ...lecture.title, [code]: event.target.value } })} /></label>)}
        {LOCALES.map((code) => <label key={`s-${code}`}>{lectureText.summary[locale]} · {code}<input value={lecture.summary[code] ?? ""} onChange={(event) => setLecture({ ...lecture, summary: { ...lecture.summary, [code]: event.target.value } })} /></label>)}
        <div className="admin-upload">
          {lecture.mediaFile
            ? <p>{lectureText.uploaded[locale]}: <code>{lecture.mediaFile}</code> <button type="button" className="text-action" onClick={() => setLecture({ ...lecture, mediaFile: "" })}>{lectureText.removeFile[locale]}</button></p>
            : <label>{lectureText.upload[locale]}<input type="file" accept="video/mp4,video/webm,video/quicktime,.mp4,.m4v,.webm,.mov" disabled={progress !== null} onChange={(event) => {
                const file = event.target.files?.[0];
                event.target.value = "";
                if (!file) return;
                setNotice(""); setProgress(0);
                uploadVideo(file, setProgress).then((name) => { setLecture((current) => ({ ...current, mediaFile: name, videoUrl: "" })); setNotice(text.saved); }).catch((cause: Error) => setNotice(cause.message)).finally(() => setProgress(null));
              }} /></label>}
          {progress !== null && <p role="status">{lectureText.uploading[locale]} {progress}%<progress max={100} value={progress} /></p>}
        </div>
        {!lecture.mediaFile && <label>{lectureText.or[locale]} · {lectureText.url[locale]}<input type="url" value={lecture.videoUrl} onChange={(event) => setLecture({ ...lecture, videoUrl: event.target.value })} placeholder="https://www.youtube.com/watch?v=…" /></label>}
        <label>{lectureText.duration[locale]}<input type="number" min={1} value={lecture.duration} onChange={(event) => setLecture({ ...lecture, duration: event.target.value })} /></label>
        <label>{lectureText.sort[locale]}<input type="number" value={lecture.sort} onChange={(event) => setLecture({ ...lecture, sort: event.target.value })} /></label>
        <label className="admin-check"><input type="checkbox" checked={lecture.membersOnly} onChange={(event) => setLecture({ ...lecture, membersOnly: event.target.checked })} />{lectureText.membersOnly[locale]}</label>
        <label className="admin-check"><input type="checkbox" checked={lecture.published} onChange={(event) => setLecture({ ...lecture, published: event.target.checked })} />{lectureText.published[locale]}</label>
        <button type="submit" className="primary-action" disabled={progress !== null}>{lecture.id ? lectureText.update[locale] : lectureText.create[locale]}</button>
      </form>
      <div className="admin-list">{lectures.length ? lectures.map((item) => <article key={item.id}><b>{item.title[locale] ?? item.title.en ?? item.title["zh-Hans"]}</b><small>{item.mediaFile ? `${lectureText.uploaded[locale]} · ${item.mediaFile}` : item.videoUrl} · {item.membersOnly ? lectureText.membersTag[locale] : lectureText.openAll[locale]} · {item.published ? lectureText.published[locale] : lectureText.draft[locale]}</small>
        <button type="button" className="text-action" onClick={() => setLecture({ id: item.id, title: item.title, summary: item.summary, videoUrl: item.videoUrl ?? "", mediaFile: item.mediaFile ?? "", membersOnly: item.membersOnly, duration: String(item.durationMinutes ?? ""), sort: String(item.sortOrder), published: item.published })}>{lectureText.edit[locale]}</button></article>) : <p>{text.none}</p>}</div>
    </>}
    {view === "teams" && (() => {
      const shown = teams.filter((team) => !teamQuery.trim() || (team.email ?? "").toLowerCase().includes(teamQuery.trim().toLowerCase()));
      const sum = teams.reduce((total, team) => total + Number(team.totalUsd), 0);
      return <>
        <section className="admin-share-report"><h4>{SR.title[locale]}</h4><p className="admin-hint">{SR.hint[locale]}</p>
          <div className="admin-table-wrap"><table className="admin-team-table"><thead><tr><th>{SR.source[locale]}</th><th>{SR.made[locale]}</th><th>{SR.saved[locale]}</th><th>{SR.shared[locale]}</th><th>{SR.visits[locale]}</th><th>{SR.signups[locale]}</th><th>{SR.invited[locale]}</th><th>{SR.buyers[locale]}</th></tr></thead>
            <tbody>{shareRows.map((row) => <tr key={row.source}><td>{sourceLabel(row.source, locale)}</td><td>{row.made}</td><td>{row.saved}</td><td>{row.shared}</td><td>{row.visits}</td><td><b>{row.signups}</b></td><td>{row.invitedSignups}</td><td>{row.buyers}</td></tr>)}</tbody></table></div></section>
        <p className="admin-hint">{teamText.hint[locale]}</p>
        <p className="admin-team-sum"><b>{teamText.sum[locale]}</b> {teams.reduce((n, team) => n + team.invited, 0)} · {teams.reduce((n, team) => n + team.purchasers, 0)} · ${sum.toFixed(2)} · {teams.reduce((n, team) => n + (team.totalCredits ?? 0), 0).toLocaleString()}</p>
        <input className="admin-team-search" value={teamQuery} onChange={(event) => setTeamQuery(event.target.value)} placeholder={teamText.search[locale]} aria-label={teamText.search[locale]} />
        {shown.length ? <div className="admin-table-wrap"><table className="admin-team-table"><thead><tr><th>{teamText.inviter[locale]}</th><th>{teamText.invited[locale]}</th><th>{teamText.purchasers[locale]}</th><th>{teamText.total[locale]}</th><th>{teamText.credits[locale]}</th></tr></thead>
          <tbody>{shown.map((team) => <tr key={team.memberId}><td>{team.email ?? team.memberId}</td><td>{team.invited}</td><td>{team.purchasers}</td><td>${team.totalUsd}</td><td>{(team.totalCredits ?? 0).toLocaleString()}</td></tr>)}</tbody></table></div> : <p>{text.none}</p>}
      </>;
    })()}
    {notice && <p className="commerce-notice" role="status">{notice}</p>}
  </section>;
}

export const adminGrowthTabLabels = (locale: Locale) => {
  const text = copy[locale] ?? copy.en;
  return { groups: text.groups, packages: text.packages, grants: text.grants, lectures: lectureText.tab[locale], teams: teamText.tab[locale] };
};

const resetText: Record<Locale, { title: string; member: string; make: string; hint: string }> = {
  en: { title: "Password reset link", member: "Member email or ID", make: "Create link", hint: "Send this link to the member after confirming the request came from the account email. It works once, for 30 minutes." },
  "zh-Hans": { title: "密码重置链接", member: "会员邮箱或 ID", make: "生成链接", hint: "确认请求来自该账户邮箱后，把链接发给会员。链接 30 分钟内有效，只能使用一次。" },
  "zh-Hant": { title: "密碼重設連結", member: "會員信箱或 ID", make: "產生連結", hint: "確認請求來自該帳戶信箱後，把連結寄給會員。連結 30 分鐘內有效，只能使用一次。" },
  ja: { title: "パスワード再設定リンク", member: "会員のメールアドレスまたは ID", make: "リンクを作成", hint: "依頼がアカウントのメールアドレスから届いたことを確認してから送ってください。有効期限は 30 分、1 回のみ使えます。" },
  ko: { title: "비밀번호 재설정 링크", member: "회원 이메일 또는 ID", make: "링크 만들기", hint: "요청이 계정 이메일에서 온 것을 확인한 뒤 회원에게 보내세요. 30분 동안 한 번만 사용할 수 있습니다." },
  vi: { title: "Liên kết đặt lại mật khẩu", member: "Email hoặc ID thành viên", make: "Tạo liên kết", hint: "Chỉ gửi sau khi xác nhận yêu cầu đến từ email tài khoản. Dùng được một lần trong 30 phút." },
  th: { title: "ลิงก์รีเซ็ตรหัสผ่าน", member: "อีเมลหรือ ID สมาชิก", make: "สร้างลิงก์", hint: "ส่งให้สมาชิกหลังยืนยันว่าคำขอมาจากอีเมลบัญชี ใช้ได้ครั้งเดียวภายใน 30 นาที" },
};

function ResetLinkTool({ locale }: { locale: Locale }) {
  const text = resetText[locale];
  const [member, setMember] = useState("");
  const [link, setLink] = useState("");
  const [notice, setNotice] = useState("");
  return <form className="admin-reset-link" onSubmit={(event) => { event.preventDefault(); setNotice(""); setLink(""); void call<{ link: string }>("/api/admin/reset-link", { member, locale }).then((result) => setLink(result.link)).catch((cause: Error) => setNotice(cause.message)); }}>
    <h3>{text.title}</h3>
    <label>{text.member}<input value={member} onChange={(event) => setMember(event.target.value)} required /></label>
    <button type="submit" className="primary-action">{text.make}</button>
    <p className="admin-hint">{text.hint}</p>
    {link && <code>{link}</code>}
    {notice && <p className="commerce-notice" role="status">{notice}</p>}
  </form>;
}
