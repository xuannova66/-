/** Local-only Ethereum checkout transaction preparation and submission.
 * Not wired to the live site. Config must come from trusted server deployment,
 * and approved token/route identity must be independently verified. Never
 * automatically retry an ambiguous wallet/RPC submission error.
 */
import { encodeFunctionData, getAddress, keccak256, parseAbi, toBytes, type Address, type Hex } from "viem";
import { assertEvmSession, type EvmProvider, type EvmSession } from "./evm-wallet-session.draft";
import { packageSettlement } from "../worker/multichain-policy";

const checkoutAbi=parseAbi(["function buy(bytes32 id,address token,uint256 maxInput,address[] path,uint256 deadline,bytes32 orderReference) payable"]);
const tokenAbi=parseAbi(["function allowance(address owner,address spender) view returns (uint256)"]);
const ZERO="0x0000000000000000000000000000000000000000" as Address;
type Order={id:string;packageId:string;buyer:Address;reference:Hex};
type Config={checkout:Address;settlement:Address;wrappedNative:Address;allowedAssets:readonly Address[];intermediates:readonly Address[]};
type Quote={asset:Address;inputUnits:bigint;maxInputUnits:bigint;outputUnits:bigint;path:readonly Address[];expiresAt:number};

export async function submitEthereumDraftCheckout(input:{provider:EvmProvider;session:EvmSession;order:Order;config:Config;quote:Quote;clock:()=>number;onHash:(hash:Hex)=>Promise<void>}) {
  if(input.session.network!=="ethereum") throw new Error("WRONG_CHAIN");
  await assertEvmSession(input.provider,input.session);
  const {order,config,quote}=input, checkout=getAddress(config.checkout), settlement=getAddress(config.settlement), asset=getAddress(quote.asset);
  if(getAddress(order.buyer)!==input.session.address || !/^[a-zA-Z0-9_-]{1,128}$/.test(order.id) || !/^0x[0-9a-fA-F]{64}$/.test(order.reference) || /^0x0{64}$/i.test(order.reference)) throw new Error("INVALID_ORDER");
  const now=input.clock();
  if(checkout===ZERO || settlement===ZERO || !Number.isSafeInteger(now) || !Number.isSafeInteger(quote.expiresAt) || quote.expiresAt<=now || quote.expiresAt>now+120) throw new Error("INVALID_QUOTE");
  const terms=packageSettlement("ethereum",order.packageId);
  if(quote.outputUnits!==terms.amountUnits || typeof quote.inputUnits!=="bigint" || typeof quote.maxInputUnits!=="bigint" || quote.inputUnits<=0n || quote.maxInputUnits<quote.inputUnits || quote.maxInputUnits*10000n>quote.inputUnits*10100n+9999n) throw new Error("INVALID_QUOTE");
  const path=quote.path.map(getAddress), wrapped=getAddress(config.wrappedNative);
  if(asset===settlement) {
    if(path.length!==0 || quote.inputUnits!==terms.amountUnits || quote.maxInputUnits!==terms.amountUnits) throw new Error("INVALID_DIRECT_PAYMENT");
  } else {
    const start=asset===ZERO?wrapped:asset;
    const intermediate=new Set(config.intermediates.map(getAddress));
    if(asset!==ZERO && !config.allowedAssets.map(getAddress).includes(asset)) throw new Error("UNSUPPORTED_ASSET");
    if(path.length<2 || path.length>3 || path[0]!==start || path[path.length-1]!==settlement || new Set(path).size!==path.length || (path.length===3 && !intermediate.has(path[1]))) throw new Error("INVALID_ROUTE");
  }
  if(asset!==ZERO) {
    const encoded=encodeFunctionData({abi:tokenAbi,functionName:"allowance",args:[input.session.address,checkout]});
    const result=await input.provider.request({method:"eth_call",params:[{to:asset,data:encoded},"latest"]});
    if(typeof result!=="string" || !/^0x[0-9a-fA-F]{64}$/.test(result) || BigInt(result)<quote.maxInputUnits) throw new Error("ALLOWANCE_REQUIRED");
  }
  await assertEvmSession(input.provider,input.session);
  const data=encodeFunctionData({abi:checkoutAbi,functionName:"buy",args:[keccak256(toBytes(order.packageId)),asset,quote.maxInputUnits,path,BigInt(quote.expiresAt),order.reference]});
  const tx={from:input.session.address,to:checkout,data,value:`0x${(asset===ZERO?quote.maxInputUnits:0n).toString(16)}`};
  const estimated=await input.provider.request({method:"eth_estimateGas",params:[tx]});
  if(typeof estimated!=="string" || !/^0x[0-9a-fA-F]+$/.test(estimated) || BigInt(estimated)<=0n || BigInt(estimated)>25_000_000n) throw new Error("GAS_ESTIMATE_UNAVAILABLE");
  const gas=(BigInt(estimated)*120n+99n)/100n;
  await assertEvmSession(input.provider,input.session);
  const beforeSend=input.clock();
  if(!Number.isSafeInteger(beforeSend) || beforeSend<now || beforeSend>=quote.expiresAt) throw new Error("INVALID_QUOTE");
  let hash:unknown;
  try {hash=await input.provider.request({method:"eth_sendTransaction",params:[{...tx,gas:`0x${gas.toString(16)}`}]});}
  catch(error) {
    if(error && typeof error==="object" && "code" in error && error.code===4001)throw new Error("WALLET_REQUEST_REJECTED");
    throw new Error("SUBMISSION_OUTCOME_UNKNOWN_CHECK_WALLET");
  }
  if(typeof hash!=="string" || !/^0x[0-9a-fA-F]{64}$/.test(hash)) throw new Error("SUBMISSION_OUTCOME_UNKNOWN_CHECK_WALLET");
  // The callback should persist the hash immediately; even if it fails the
  // caller receives the hash and must not attempt another payment blindly.
  try {await input.onHash(hash as Hex);return {hash:hash as Hex,recoveryRecorded:true};}
  catch {return {hash:hash as Hex,recoveryRecorded:false};}
}
