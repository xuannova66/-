// 研习殿 sounds, all synthesised in the browser (no recordings): the wooden fish (木鱼), the bronze bell (钟), a bead
// click (念珠), a soft chime for joined palms, and an optional quiet ambience of wind with a far bell now and then.
// Nothing plays until the visitor taps a button (browsers require a gesture).
let context: AudioContext | null = null;
let master: GainNode | null = null;

function audio() {
  if (typeof window === "undefined") return null;
  if (!context) {
    const Ctor = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    context = new Ctor();
    master = context.createGain(); master.gain.value = 0.8; master.connect(context.destination);
  }
  if (context.state === "suspended") void context.resume();
  return context;
}

function tone(freq: number, start: number, duration: number, peak: number, type: OscillatorType = "sine", destination?: AudioNode) {
  const ctx = audio(); if (!ctx || !master) return;
  const osc = ctx.createOscillator(), gain = ctx.createGain();
  osc.type = type; osc.frequency.setValueAtTime(freq, start);
  gain.gain.setValueAtTime(0.0001, start);
  gain.gain.exponentialRampToValueAtTime(peak, start + 0.006);
  gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
  osc.connect(gain); gain.connect(destination ?? master);
  osc.start(start); osc.stop(start + duration + 0.05);
}

/** Hollow wooden knock: a quick pitch drop through a band-pass, plus a short noise tap. */
export function woodFish() {
  const ctx = audio(); if (!ctx || !master) return;
  const now = ctx.currentTime;
  const filter = ctx.createBiquadFilter(); filter.type = "bandpass"; filter.frequency.value = 900; filter.Q.value = 6; filter.connect(master);
  const osc = ctx.createOscillator(), gain = ctx.createGain();
  osc.type = "triangle"; osc.frequency.setValueAtTime(820, now); osc.frequency.exponentialRampToValueAtTime(520, now + 0.08);
  gain.gain.setValueAtTime(0.0001, now); gain.gain.exponentialRampToValueAtTime(0.9, now + 0.004); gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.22);
  osc.connect(gain); gain.connect(filter); osc.start(now); osc.stop(now + 0.3);
  tone(1650, now, 0.05, 0.12, "square", filter);
}

/** Bronze bell: inharmonic partials with a long fade. `far` makes it quiet and dull (for the ambience). */
export function bell(far = false) {
  const ctx = audio(); if (!ctx || !master) return;
  const now = ctx.currentTime;
  const base = far ? 138 : 164;
  const level = far ? 0.05 : 0.32;
  [[1, 1, 7], [2.0, 0.55, 5], [2.76, 0.35, 4], [3.97, 0.22, 3], [5.4, 0.12, 2]].forEach(([ratio, amp, length]) => tone(base * ratio, now, length * (far ? 0.8 : 1), level * amp));
}

export function bead() { const ctx = audio(); if (!ctx) return; const now = ctx.currentTime; tone(2400, now, 0.06, 0.12, "triangle"); tone(3100, now + 0.01, 0.05, 0.06, "sine"); }
export function chime() { const ctx = audio(); if (!ctx) return; const now = ctx.currentTime; [880, 1320, 1760].forEach((freq, index) => tone(freq, now + index * 0.09, 1.6, 0.08)); }

let ambience: { stop: () => void } | null = null;
/** Soft wind (filtered noise, slowly swelling) and a distant bell every 20–40 s. */
export function setAmbience(on: boolean) {
  if (!on) { ambience?.stop(); ambience = null; return; }
  if (ambience) return;
  const ctx = audio(); if (!ctx || !master) return;
  const buffer = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
  const data = buffer.getChannelData(0); let last = 0;
  for (let i = 0; i < data.length; i += 1) { last = (last + 0.02 * (Math.random() * 2 - 1)) / 1.02; data[i] = last * 3.5; }
  const noise = ctx.createBufferSource(); noise.buffer = buffer; noise.loop = true;
  const filter = ctx.createBiquadFilter(); filter.type = "lowpass"; filter.frequency.value = 520;
  const gain = ctx.createGain(); gain.gain.value = 0.0001; gain.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + 2);
  const swell = ctx.createOscillator(), swellDepth = ctx.createGain(); swell.frequency.value = 0.07; swellDepth.gain.value = 0.08; swell.connect(swellDepth); swellDepth.connect(gain.gain);
  noise.connect(filter); filter.connect(gain); gain.connect(master); noise.start(); swell.start();
  let timer = window.setTimeout(function ring() { bell(true); timer = window.setTimeout(ring, 20_000 + Math.random() * 20_000); }, 6000);
  ambience = { stop: () => { window.clearTimeout(timer); gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.8); window.setTimeout(() => { noise.stop(); swell.stop(); }, 900); } };
}
