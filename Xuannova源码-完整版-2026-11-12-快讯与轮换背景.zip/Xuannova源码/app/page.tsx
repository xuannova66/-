"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  createStudyResult,
  type StudyInput,
  type StudyResult,
} from "./study-engine";
import { createCompleteChart } from "./chart-model";
import { convertCalendar, inputCalendarCopy, leapMonthOf, pillarWarnings, todayIso, toolkitFieldCopy, toolkitFields } from "./input-calendar";
import { activityKeys, prewarmAlmanac, todayIso as almanacToday, type ActivityKey } from "./almanac";
import { activityLabels } from "./almanac-copy";
import {
  lineStatesFromThrows,
  throwThreeCoins,
  type CoinThrow,
} from "./liuyao-casting";
import { CompleteChartBoard, localizeBoardTerm } from "./complete-chart-board";
import { LifeKLineChart } from "./life-kline-chart";
import { setHallRoute } from "./hall-presence-client";
/** Birth-chart methods that show the life K-line (computed from the BaZi of the same birth moment). */
const LIFE_KLINE_ROUTES = new Set<string>(["bazi", "detail", "ziwei", "qizheng", "heluo", "tieban", "hecan"]);
import { InterpretationPanel } from "./interpretation-panel";
import {
  readCreditWallet,
  saveCreditWallet,
  spendCredits,
  type CreditWallet,
} from "./credit-wallet";
import { RitualSequence } from "./ritual-sequence";
/** Navigation label once a member is signed in: "会员" becomes "个人中心". */
const accountCenterLabel: Record<Locale, string> = {
  en: "My account",
  "zh-Hans": "个人中心",
  "zh-Hant": "個人中心",
  ja: "マイページ",
  ko: "마이페이지",
  vi: "Tài khoản của tôi",
  th: "บัญชีของฉัน",
};

/** Tracks whether a member session exists; MemberCommerceCenter broadcasts changes. */
function useMemberSignedIn() {
  const [signedIn, setSignedIn] = useState(false);
  useEffect(() => {
    let cancelled = false;
    const probe = () => {
      fetch("/api/member/me?soft=1", { credentials: "same-origin" })
        .then(async (response) => { const body = response.ok ? await response.json() as { member?: unknown } : null; announceGrowth(body); if (!cancelled) setSignedIn(Boolean(body?.member)); })
        .catch(() => { if (!cancelled) setSignedIn(false); });
    };
    const onChange = (event: Event) => setSignedIn(Boolean((event as CustomEvent<unknown>).detail));
    const timer = window.setTimeout(probe, 0);
    window.addEventListener("xuannova:member", onChange);
    return () => { cancelled = true; window.clearTimeout(timer); window.removeEventListener("xuannova:member", onChange); };
  }, []);
  return signedIn;
}

/** Floating "back to top" button on long pages (shown after scrolling down). */
function BackToTop({ locale }: { locale: Locale }) {
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const onScroll = () => setShown(window.scrollY > 1200);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  const label: Record<Locale, string> = { en: "Back to top", "zh-Hans": "回到顶部", "zh-Hant": "回到頂部", ja: "ページの先頭へ", ko: "맨 위로", vi: "Lên đầu trang", th: "กลับขึ้นด้านบน" };
  if (!shown) return null;
  return <button type="button" className="back-to-top" aria-label={label[locale]} title={label[locale]} onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>↑</button>;
}

/** The operations console lives on its own page at /admin; legacy #admin links are forwarded there. */
function AdminRedirect() {
  useEffect(() => {
    window.location.replace("/admin");
  }, []);
  return null;
}

// Path-based navigation (real URLs for search engines). The current interface language decides the prefix.
let currentUrlLocale: Locale = "en";
function navigateTo(route: AppRoute, stage: StudyStage = "input", replace = false) {
  const target = pathFor(currentUrlLocale, route, stage);
  if (window.location.pathname !== target || window.location.hash) {
    // Remember where the reader was on the page they leave, so Back returns to the same place.
    if (!replace) rememberScroll();
    window.history[replace ? "replaceState" : "pushState"]({ scrollY: 0 }, "", target);
  }
  window.dispatchEvent(new Event("xn:navigate"));
}
/**
 * Back/Forward: put the page back where it was. The page grows as sections load (courses, 3D hall), so keep trying
 * for a moment until the document is tall enough, and stop as soon as the reader scrolls themselves.
 */
function restoreScroll(target: number) {
  if (target <= 0) { window.scrollTo({ top: 0, behavior: "instant" }); return; }
  let tries = 0, userMoved = false;
  const stop = () => { userMoved = true; };
  window.addEventListener("wheel", stop, { once: true, passive: true });
  window.addEventListener("touchstart", stop, { once: true, passive: true });
  window.addEventListener("keydown", stop, { once: true });
  const step = () => {
    if (userMoved) return;
    const max = document.documentElement.scrollHeight - window.innerHeight;
    window.scrollTo({ top: Math.min(target, Math.max(0, max)), behavior: "instant" });
    tries += 1;
    // Only wait while the page is still too short (sections loading); never keep fighting the reader's own scroll.
    if (max < target - 2 && tries < 30) window.setTimeout(step, 60);
    else { window.removeEventListener("wheel", stop); window.removeEventListener("touchstart", stop); }
  };
  window.requestAnimationFrame(step);
}
function currentStage() {
  return typeof window === "undefined" ? "input" : parseStudyPath(window.location.pathname).stage;
}

/** Theme picker placed next to the language switch. */
/** A real link (crawlable, opens in a new tab with Ctrl/Cmd) that navigates in place on a normal click. */
/** Shorter header labels where the full ones do not fit on one line on laptop screens (the menus keep the full names). */
const headerShort: Partial<Record<Locale, Partial<Record<"methods" | "synthesis" | "toolkit" | "daily" | "library" | "courses" | "guide" | "workshop", string>>>> = {
  en: { methods: "Methods", synthesis: "Synthesis", toolkit: "Toolkit", daily: "Almanac", library: "Library", courses: "Courses", guide: "Guide", workshop: "Workshop" },
  vi: { methods: "Phương pháp", synthesis: "Tổng hợp", toolkit: "Công cụ", daily: "Xem ngày", library: "Thư viện", courses: "Khóa học", guide: "Hướng dẫn", workshop: "Xưởng" },
  th: { methods: "วิธีศึกษา", synthesis: "มุมมองผสาน", toolkit: "เครื่องมือ", daily: "ปฏิทินฤกษ์", library: "คลังความรู้", courses: "คอร์สวิดีโอ", guide: "คู่มือ", workshop: "ร้านศิลป์" },
};
const headerLabel = (locale: Locale, key: keyof NonNullable<(typeof headerShort)[Locale]>, full: string) => headerShort[locale]?.[key] ?? full;

function NavLink({ route, locale, onGo, className, children }: { route: AppRoute; locale: Locale; onGo: () => void; className?: string; children: React.ReactNode }) {
  return <a className={`nav-link${className ? ` ${className}` : ""}`} href={pathFor(locale, route)} onClick={(event) => {
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return;
    event.preventDefault(); onGo();
  }}>{children}</a>;
}

function ThemeMenu({ theme, setTheme, copy }: { theme: ThemeKey; setTheme: (theme: ThemeKey) => void; copy: ReturnType<typeof getSuiteCopy> }) {
  const [open, setOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const close = (event: Event) => { if (event instanceof KeyboardEvent ? event.key === "Escape" : !wrapRef.current?.contains(event.target as Node)) setOpen(false); };
    document.addEventListener("pointerdown", close);
    document.addEventListener("keydown", close);
    return () => { document.removeEventListener("pointerdown", close); document.removeEventListener("keydown", close); };
  }, [open]);
  const icon = (key: ThemeKey) => (key === "aureate" ? "✦" : key === "paper" ? "◌" : "◐");
  return <div className="header-theme" ref={wrapRef}>
    <button type="button" aria-expanded={open} aria-label={copy.theme.label} title={copy.theme.label} onClick={() => setOpen((value) => !value)}>{icon(theme)}</button>
    {open && <div role="menu">
      {themes.map((key) => <button type="button" role="menuitemradio" aria-checked={theme === key} key={key} className={theme === key ? "active" : ""} onClick={() => { setTheme(key); setOpen(false); }}>
        <i>{icon(key)}</i><span>{copy.theme[key]}</span>{theme === key && <b>✓</b>}
      </button>)}
    </div>}
  </div>;
}

const profileKey = "xuannova-profile";
const profileFields = ["name", "gender", "calendar", "date", "time", "timeUnknown", "place", "location", "leapMonth", "trueSolar", "ziHour", "luckPrecision", "ziweiLeap", "ziweiTransform"] as const;
function pickProfile(source: Partial<FormState>): Partial<FormState> {
  const out: Partial<FormState> = {};
  for (const key of profileFields) if (source[key] !== undefined) (out as Record<string, unknown>)[key] = source[key];
  return out;
}
const futureBirth: Record<Locale, string> = { en: "Birth dates can be at most one year from today. Please check it.", "zh-Hans": "出生日期最晚可填到一年后的今天，请检查。", "zh-Hant": "出生日期最晚可填到一年後的今天，請檢查。", ja: "生年月日は今日から1年後までです。ご確認ください。", ko: "생년월일은 오늘부터 1년 후까지 입력할 수 있습니다. 확인해 주세요.", vi: "Ngày sinh chỉ có thể muộn nhất một năm kể từ hôm nay. Vui lòng kiểm tra.", th: "วันเกิดกรอกได้ไม่เกินหนึ่งปีจากวันนี้ โปรดตรวจสอบ" };
function oneYearAheadIso() { const date = new Date(); date.setFullYear(date.getFullYear() + 1); return date.toISOString().slice(0, 10); }
const partnerRequired: Record<Locale, string> = { en: "Enter the second person's birth date.", "zh-Hans": "请填写对方的出生日期。", "zh-Hant": "請填寫對方的出生日期。", ja: "相手の生年月日を入力してください。", ko: "상대방의 생년월일을 입력하세요.", vi: "Hãy nhập ngày sinh của người thứ hai.", th: "โปรดกรอกวันเกิดของอีกฝ่าย" };
const forgetProfileLabel: Record<Locale, string> = { en: "Forget the birth details saved in this browser", "zh-Hans": "清除本浏览器保存的出生信息", "zh-Hant": "清除本瀏覽器儲存的出生資訊", ja: "このブラウザに保存した生年月日などを消去", ko: "이 브라우저에 저장된 출생 정보 지우기", vi: "Xóa thông tin ngày sinh đã lưu trong trình duyệt này", th: "ลบข้อมูลวันเกิดที่บันทึกในเบราว์เซอร์นี้" };
const historyText: Record<Locale, { question: string; view: string; empty: string }> = {
  en: { question: "Question", view: "View reading", empty: "No question history yet. Successful readings will appear here." },
  "zh-Hans": { question: "提问内容", view: "查看解读", empty: "暂无提问记录。成功生成的解读会显示在这里。" },
  "zh-Hant": { question: "提問內容", view: "查看解讀", empty: "暫無提問紀錄。成功產生的解讀會顯示在這裡。" },
  ja: { question: "質問", view: "解説を見る", empty: "質問の履歴はまだありません。作成した解説がここに表示されます。" },
  ko: { question: "질문", view: "해석 보기", empty: "아직 질문 기록이 없습니다. 생성된 해석이 여기에 표시됩니다." },
  vi: { question: "Câu hỏi", view: "Xem bài giải", empty: "Chưa có lịch sử câu hỏi. Các bài giải đã tạo sẽ hiện ở đây." },
  th: { question: "คำถาม", view: "ดูคำอธิบาย", empty: "ยังไม่มีประวัติคำถาม คำอธิบายที่สร้างแล้วจะแสดงที่นี่" },
};
const schoolCopy: Record<Locale, { hint: string; ziHour: string; late: string; early: string; luck: string; days: string; minutes: string; leap: string; split: string; current: string; next: string; transform: string; classic: string; alt: string }> = {
  en: { hint: "Most people can keep the defaults. Change these only if you follow a particular school.", ziHour: "Births 23:00–24:00 (Zi hour)", late: "Late Zi: keep today's day pillar (default)", early: "Early Zi: count as the next day", luck: "Luck-cycle start", days: "Three days = one year (default)", minutes: "Counted to the minute", leap: "Leap-month birth (Zi Wei)", split: "Days 1–15 this month, 16+ next month (default)", current: "Always this month", next: "Always the next month", transform: "Four transformations (Zi Wei)", classic: "Geng: Sun·Wu Qu·Moon·Tian Tong (default)", alt: "Geng: Sun·Wu Qu·Tian Fu·Tian Tong; Ren: …·Tian Fu·Wu Qu" },
  "zh-Hans": { hint: "一般保持默认即可，只有遵循特定流派时才需要修改。", ziHour: "23:00–24:00 出生（子时）", late: "夜子时：日柱不换日（默认）", early: "早子时：按次日计算", luck: "大运起运", days: "三天折一年（默认）", minutes: "精确到分钟", leap: "闰月出生（紫微）", split: "初一至十五按本月，十六起按下月（默认）", current: "一律按本月", next: "一律按下月", transform: "四化（紫微）", classic: "庚：日武阴同（默认）", alt: "庚：日武府同；壬：梁紫府武" },
  "zh-Hant": { hint: "一般保持預設即可，只有遵循特定流派時才需要修改。", ziHour: "23:00–24:00 出生（子時）", late: "夜子時：日柱不換日（預設）", early: "早子時：按次日計算", luck: "大運起運", days: "三天折一年（預設）", minutes: "精確到分鐘", leap: "閏月出生（紫微）", split: "初一至十五按本月，十六起按下月（預設）", current: "一律按本月", next: "一律按下月", transform: "四化（紫微）", classic: "庚：日武陰同（預設）", alt: "庚：日武府同；壬：梁紫府武" },
  ja: { hint: "通常は初期設定のままで構いません。特定の流派に従う場合のみ変更してください。", ziHour: "23:00〜24:00 生まれ（子の刻）", late: "夜子時：日柱はその日のまま（初期設定）", early: "早子時：翌日として計算", luck: "大運の起運", days: "三日を一年に換算（初期設定）", minutes: "分単位で計算", leap: "閏月生まれ（紫微）", split: "1〜15日は当月、16日以降は翌月（初期設定）", current: "常に当月", next: "常に翌月", transform: "四化（紫微）", classic: "庚：太陽・武曲・太陰・天同（初期設定）", alt: "庚：太陽・武曲・天府・天同／壬：天梁・紫微・天府・武曲" },
  ko: { hint: "대부분 기본값 그대로 두면 됩니다. 특정 유파를 따를 때만 바꾸세요.", ziHour: "23:00~24:00 출생(자시)", late: "야자시: 일주를 바꾸지 않음(기본)", early: "조자시: 다음 날로 계산", luck: "대운 시작", days: "사흘을 1년으로 환산(기본)", minutes: "분 단위로 계산", leap: "윤달 출생(자미)", split: "1~15일은 해당 달, 16일부터 다음 달(기본)", current: "항상 해당 달", next: "항상 다음 달", transform: "사화(자미)", classic: "경: 태양·무곡·태음·천동(기본)", alt: "경: 태양·무곡·천부·천동 / 임: 천량·자미·천부·무곡" },
  vi: { hint: "Đa số người dùng giữ mặc định. Chỉ đổi khi bạn theo một trường phái cụ thể.", ziHour: "Sinh 23:00–24:00 (giờ Tý)", late: "Tý muộn: giữ trụ ngày hôm nay (mặc định)", early: "Tý sớm: tính sang ngày hôm sau", luck: "Khởi đại vận", days: "Ba ngày = một năm (mặc định)", minutes: "Tính chính xác đến phút", leap: "Sinh tháng nhuận (Tử Vi)", split: "Mùng 1–15 tính tháng này, từ 16 tính tháng sau (mặc định)", current: "Luôn tính tháng này", next: "Luôn tính tháng sau", transform: "Tứ hóa (Tử Vi)", classic: "Canh: Thái Dương·Vũ Khúc·Thái Âm·Thiên Đồng (mặc định)", alt: "Canh: Thái Dương·Vũ Khúc·Thiên Phủ·Thiên Đồng; Nhâm: Thiên Lương·Tử Vi·Thiên Phủ·Vũ Khúc" },
  th: { hint: "ส่วนใหญ่ใช้ค่าเริ่มต้นได้เลย เปลี่ยนเฉพาะเมื่อยึดตามสำนักใดสำนักหนึ่ง", ziHour: "เกิด 23:00–24:00 (ยามจื่อ)", late: "จื่อดึก: คงเสาวันของวันนี้ (ค่าเริ่มต้น)", early: "จื่อเช้า: นับเป็นวันถัดไป", luck: "การเริ่มวัฏจักรสิบปี", days: "สามวันเท่ากับหนึ่งปี (ค่าเริ่มต้น)", minutes: "นับละเอียดถึงนาที", leap: "เกิดเดือนอธิกมาส (จื่อเวย)", split: "วันที่ 1–15 ใช้เดือนนี้ 16 ขึ้นไปใช้เดือนถัดไป (ค่าเริ่มต้น)", current: "ใช้เดือนนี้เสมอ", next: "ใช้เดือนถัดไปเสมอ", transform: "สี่การแปร (จื่อเวย)", classic: "เกิง: ดวงอาทิตย์·อู่ชวี·ดวงจันทร์·เทียนถง (ค่าเริ่มต้น)", alt: "เกิง: ดวงอาทิตย์·อู่ชวี·เทียนฝู่·เทียนถง / เหริน: เทียนเหลียง·จื่อเวย·เทียนฝู่·อู่ชวี" },
};
const meihuaCopy: Record<Locale, { method: string; time: string; numbers: string; text: string; number: string; textHint: string }> = {
  en: { method: "Casting method", time: "By this moment", numbers: "By two numbers", text: "By a phrase", number: "Number", textHint: "Write your question below; the phrase is split in half to raise the hexagram." },
  "zh-Hans": { method: "起卦方式", time: "按当下时间", numbers: "报两个数", text: "按一句话", number: "数字", textHint: "在下方写下你的问题，按前后两半的字数起卦。" },
  "zh-Hant": { method: "起卦方式", time: "按當下時間", numbers: "報兩個數", text: "按一句話", number: "數字", textHint: "在下方寫下你的問題，按前後兩半的字數起卦。" },
  ja: { method: "起卦の方法", time: "今の時刻で", numbers: "二つの数字で", text: "一文で", number: "数字", textHint: "下に質問を書いてください。前半と後半の字数で卦を立てます。" },
  ko: { method: "기괘 방법", time: "지금 시각으로", numbers: "숫자 두 개로", text: "한 문장으로", number: "숫자", textHint: "아래에 질문을 적으세요. 앞뒤 절반의 글자 수로 괘를 세웁니다." },
  vi: { method: "Cách lập quẻ", time: "Theo thời điểm này", numbers: "Theo hai con số", text: "Theo một câu", number: "Số", textHint: "Viết câu hỏi bên dưới; câu được chia đôi để lập quẻ." },
  th: { method: "วิธีตั้งกว้า", time: "ตามเวลาขณะนี้", numbers: "ด้วยตัวเลขสองตัว", text: "ด้วยประโยคหนึ่ง", number: "ตัวเลข", textHint: "เขียนคำถามด้านล่าง ประโยคจะถูกแบ่งครึ่งเพื่อตั้งกว้า" },
};
const difenCopy: Record<Locale, { label: string; hint: string; hour: string }> = {
  en: { label: "Earth position (direction)", hint: "Pick the direction the matter lies in, or the first one that comes to mind.", hour: "Use the hour" },
  "zh-Hans": { label: "地分（方位）", hint: "选事情所在的方位，或随手选第一个想到的方位。", hour: "按时辰" },
  "zh-Hant": { label: "地分（方位）", hint: "選事情所在的方位，或隨手選第一個想到的方位。", hour: "按時辰" },
  ja: { label: "地分（方位）", hint: "事柄のある方位、または最初に思い浮かんだ方位を選んでください。", hour: "時刻で" },
  ko: { label: "지분(방위)", hint: "일이 있는 방위나 처음 떠오른 방위를 고르세요.", hour: "시진으로" },
  vi: { label: "Địa phân (phương hướng)", hint: "Chọn phương của sự việc, hoặc phương đầu tiên bạn nghĩ đến.", hour: "Theo giờ" },
  th: { label: "ตำแหน่งดิน (ทิศ)", hint: "เลือกทิศที่เรื่องนั้นอยู่ หรือทิศแรกที่นึกถึง", hour: "ตามชั่วยาม" },
};
const zeriCopy: Record<Locale, { purpose: string; from: string; span: string; days: string; hint: string }> = {
  en: { purpose: "What is the date for?", from: "Search from", span: "Search window", days: "{n} days", hint: "Your birth details are used to leave out days that clash with your zodiac year and day branch, and to favour days whose element suits your chart." },
  "zh-Hans": { purpose: "要办什么事？", from: "从哪天开始找", span: "查找范围", days: "{n} 天", hint: "会用你的出生信息排除冲生肖、冲日柱的日子，并优先五行合你命盘的日子。" },
  "zh-Hant": { purpose: "要辦什麼事？", from: "從哪天開始找", span: "查找範圍", days: "{n} 天", hint: "會用你的出生資訊排除沖生肖、沖日柱的日子，並優先五行合你命盤的日子。" },
  ja: { purpose: "何のための日取り？", from: "探し始める日", span: "探す期間", days: "{n} 日", hint: "生年月日から、干支の年支・日支と冲する日を除き、命盤に合う五行の日を優先します。" },
  ko: { purpose: "어떤 일을 위한 날인가요?", from: "찾기 시작할 날", span: "찾는 기간", days: "{n}일", hint: "출생 정보로 띠(연지)·일지와 충하는 날을 빼고, 명반에 맞는 오행의 날을 우선합니다." },
  vi: { purpose: "Chọn ngày để làm gì?", from: "Tìm từ ngày", span: "Khoảng tìm", days: "{n} ngày", hint: "Thông tin ngày sinh dùng để loại các ngày xung tuổi và xung chi ngày, và ưu tiên ngày có ngũ hành hợp lá số." },
  th: { purpose: "เลือกวันสำหรับเรื่องอะไร", from: "เริ่มหาตั้งแต่", span: "ช่วงที่หา", days: "{n} วัน", hint: "ใช้ข้อมูลวันเกิดตัดวันที่ชงกับปีนักษัตรและกิ่งวันของคุณ และให้น้ำหนักวันที่ธาตุเข้ากับผัง" },
};
const DIFEN_BRANCHES = ["子", "丑", "寅", "卯", "辰", "巳", "午", "未", "申", "酉", "戌", "亥"];
const DIFEN_DIRECTION = ["North", "Northeast", "Northeast", "East", "Southeast", "Southeast", "South", "Southwest", "Southwest", "West", "Northwest", "Northwest"];
const dailyTimeLabel: Record<Locale, string> = { en: "Time", "zh-Hans": "时间", "zh-Hant": "時間", ja: "時刻", ko: "시각", vi: "Giờ", th: "เวลา" };
const workshopNavLabel: Record<Locale, string> = { en: "Workshop", "zh-Hans": "器物坊", "zh-Hant": "器物坊", ja: "工房", ko: "공방", vi: "Xưởng", th: "โรงงานศิลป์" };
const legalNavLabel: Record<Locale, { legal: string; contact: string }> = {
  en: { legal: "Legal information", contact: "Contact" }, "zh-Hans": { legal: "法律信息", contact: "联系方式" }, "zh-Hant": { legal: "法律資訊", contact: "聯絡方式" },
  ja: { legal: "法的情報", contact: "お問い合わせ" }, ko: { legal: "법적 고지", contact: "연락처" }, vi: { legal: "Thông tin pháp lý", contact: "Liên hệ" }, th: { legal: "ข้อมูลทางกฎหมาย", contact: "ติดต่อ" },
};
const consentKey = "xuannova-consent";
export function readConsent(): "all" | "essential" | null {
  try { const value = window.localStorage.getItem(consentKey); return value === "all" || value === "essential" ? value : null; } catch { return null; }
}

function LegalLinks({ locale }: { locale: Locale }) {
  const [open, setOpen] = useState<LegalDoc | null>(null);
  const [consent, setConsent] = useState<"all" | "essential" | null | "unknown">("unknown");
  useEffect(() => {
    const timer = window.setTimeout(() => setConsent(readConsent()), 0);
    const fromHash = () => { const match = window.location.hash.match(/^#legal-(privacy|terms|refund)$/); if (match) setOpen(match[1] as LegalDoc); };
    fromHash();
    window.addEventListener("hashchange", fromHash);
    return () => { window.clearTimeout(timer); window.removeEventListener("hashchange", fromHash); };
  }, []);
  const text = legalCopy(locale);
  const nav = legalNavLabel[locale];
  const choose = (value: "all" | "essential") => {
    try { window.localStorage.setItem(consentKey, value); } catch { /* optional */ }
    setConsent(value);
    window.dispatchEvent(new CustomEvent("xuannova:consent", { detail: value }));
    if (value === "all") initAnalytics();
  };
  const doc = open ? text.docs[open] : null;
  return <div className="legal-links"><nav aria-label={nav.legal}>
    <a href={pathFor(locale, "guide")} onClick={(event) => { if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return; event.preventDefault(); navigateTo("guide"); window.scrollTo({ top: 0, behavior: "instant" }); }}>{titleForRoute("guide", locale)}</a>
    {(["privacy", "terms", "refund"] as const).map((item) => <a key={item} href={`#legal-${item}`} onClick={(event) => { event.preventDefault(); setOpen(item); }}>{text.docs[item].title}</a>)}
    <button type="button" onClick={() => setConsent(null)}>{text.cookie.settings}</button>
  </nav><nav className="footer-contacts" aria-label={nav.contact}>
    <ContactIconRow />
  </nav>
  {doc && <div className="legal-backdrop" role="presentation" onClick={() => setOpen(null)}><section className="legal-dialog" role="dialog" aria-modal="true" aria-labelledby="legal-title" onClick={(event) => event.stopPropagation()}>
    <header><h2 id="legal-title">{doc.title}</h2><button type="button" onClick={() => setOpen(null)} aria-label={text.close}>×</button></header>
    <small>{text.updated}</small>
    <ol>{doc.points.map((point) => <li key={point.slice(0, 40)}>{point}</li>)}</ol>
    <p className="legal-operator">{text.operator}</p>
  </section></div>}
  {consent === null && <aside className="cookie-banner" role="dialog" aria-live="polite" aria-label={text.cookie.settings}>
    <p>{text.cookie.text} <a href="#legal-privacy" onClick={(event) => { event.preventDefault(); setOpen("privacy"); }}>{text.docs.privacy.title}</a></p>
    <div><button type="button" className="secondary-action" onClick={() => choose("essential")}>{text.cookie.reject}</button><button type="button" className="primary-action" onClick={() => choose("all")}>{text.cookie.accept}</button></div>
  </aside>}
  </div>;
}
import { workshopHref } from "./contact-config";
import { ContactIconRow } from "./contact-icons";
import { legalCopy, type LegalDoc } from "./legal-content";
import { HomeAdvisor, HomeCharity, HomeGoalEntry, homeSectionText } from "./home-extras";
import { BenefitsTable, CreditPriceList } from "./benefits";
import { SampleReportTeaser } from "./sample-report";
import { CoursesScreen, HomeLectureHall } from "./courses";
import { sittingLabel, toolkitLead, toolkitName } from "./toolkit-copy";
import { MethodDrawerExtras, takePendingToolkitTool } from "./method-drawer-extras";
import { methodCategories } from "./method-categories";
import { useHiddenRoutes, useStudyMethodCount } from "./vision-availability";
import { FieldHelp, GuideScreen, MethodHelp } from "./guide";
import { rememberScroll } from "./scroll-memory";
import { DailyCards } from "./daily-posters";
import { HeroMotion } from "./hero-motion";
import { FlashScreen, FlashTicker, HomeFlashStrip, type FlashItem } from "./flash";
import { AlmanacScreen, CeziScreen, FloorPlanFengShui, LibraryExplorer, MemberCommerceCenter, prefetchScreens, StudyHall3D, XiangshuScreen } from "./lazy-screens";
import { solarBirthIso } from "./daily-color";
import { captureShareSource } from "./share-stats-client";
import { AppBackButton, InstallApp } from "./install-app";
import { trustText } from "./trust-copy";
import { ProfilePicker } from "./member-library";
import { methodPitch } from "./method-pitch";
import { GrowthNotice, announceGrowth } from "./growth-notice";
import { MonthlyOutlook } from "./monthly-outlook";
import { homeCopy } from "./home-copy";
import { metadataFor } from "./seo";
import { initAnalytics, track } from "./analytics";
import { classicalWorks, localizedLibraryTitle } from "./library-catalogue";
import { DIRECTIONS } from "./metaphysics/fengshui";
import type { LibraryCategory } from "./library-catalogue";
import { GlobalLocationField } from "./global-location-field";
import type { GlobalLocation } from "./geocoding";
import {
  hashForStudyStage,
  parseStudyLocation,
  parseStudyPath,
  pathFor,
  type StudyStage,
} from "./study-navigation";
import { uiCopy } from "./ui-copy";
import { birthTimeText, HOUR_REQUIRED_ROUTES, EXAMPLE_BIRTH } from "./birth-time";
import { BirthBasis } from "./birth-basis";
import {
  languageOptions,
  siteContent,
  type Locale,
  type ThemeKey,
  type StudyVisualKind,
} from "./site-content";
import {
  libraryArticles,
  makeDailyResult,
  makeToolkitResult,
  routeByKey,
  routeDefinitions,
  suiteCopy,
  titleForRoute,
  toolkitItems,
  type AppRoute,
  type FormFamily,
  type ToolkitKey,
} from "./study-suite";

type Persona = "scholar" | "hermit";
type Depth = "full" | "direct";
type FormState = {
  name: string;
  partner: string;
  gender: "yin" | "yang";
  partnerGender: "yin" | "yang";
  calendar: "solar" | "lunar" | "pillars";
  partnerCalendar: "solar" | "lunar" | "pillars";
  date: string;
  partnerDate: string;
  manualPillars: string[];
  partnerManualPillars: string[];
  time: string;
  partnerTime: string;
  place: string;
  partnerPlace: string;
  location: GlobalLocation | null;
  partnerLocation: GlobalLocation | null;
  focus: string;
  relation: string;
  inquiry: string;
  useNow: boolean;
  castMethod: "system" | "coins" | "direct";
  manualLines: boolean[];
  coinThrows: CoinThrow[];
  trueSolar: boolean;
  timeUnknown: boolean;
  partnerTimeUnknown: boolean;
  /** True while the form still holds the example birthday (1994-08-18 12:00). */
  exampleBirth: boolean;
  leapMonth: boolean;
  partnerLeapMonth: boolean;
  /** Date for the daily rhythm page; kept apart from the birth date and defaulting to today. */
  dailyDate: string;
  ziHour: "late" | "early";
  luckPrecision: "days" | "minutes";
  ziweiLeap: "split" | "current" | "next";
  ziweiTransform: "classic" | "alt";
  /** 金口诀 earth position (地分); empty uses the hour branch. */
  difen: string;
  meihuaMethod: "time" | "numbers" | "text";
  meihuaNumbers: [string, string];
  /** 住宅详情分析: the direction the house sits toward. */
  houseSitting: string;
  /** 专业择日: purpose, first date (empty = today) and number of days. */
  zeriPurpose: ActivityKey;
  zeriStart: string;
  zeriDays: number;
};

const defaultForm: FormState = {
  name: "",
  partner: "",
  gender: "yang",
  partnerGender: "yin",
  calendar: "solar",
  partnerCalendar: "solar",
  date: "1994-08-18",
  // The second person starts empty so a pair reading never compares one chart with itself by accident.
  partnerDate: "",
  manualPillars: ["甲戌", "壬申", "丙子", "甲午"],
  partnerManualPillars: ["甲戌", "壬申", "丙子", "甲午"],
  time: "12:00",
  partnerTime: "12:00",
  place: "",
  partnerPlace: "",
  location: null,
  partnerLocation: null,
  focus: "",
  relation: "Connection",
  inquiry: "",
  useNow: true,
  castMethod: "system",
  manualLines: [false, false, false, false, false, false],
  coinThrows: [],
  trueSolar: false,
  timeUnknown: false,
  partnerTimeUnknown: false,
  exampleBirth: true,
  leapMonth: false,
  partnerLeapMonth: false,
  dailyDate: "",
  ziHour: "late",
  luckPrecision: "days",
  ziweiLeap: "split",
  ziweiTransform: "classic",
  difen: "",
  meihuaMethod: "time",
  meihuaNumbers: ["", ""],
  houseSitting: "North",
  zeriPurpose: "wedding",
  zeriStart: "",
  zeriDays: 60,
};

const themes: ThemeKey[] = ["aureate", "paper", "nocturne"];

function localizedLead(
  family: FormFamily,
  copy: ReturnType<typeof getSuiteCopy>,
) {
  if (family === "birth") return copy.form.birth;
  if (family === "pair") return copy.form.pair;
  if (family === "inquiry") return copy.form.inquiry;
  if (family === "daily") return copy.daily.lead;
  return copy.form.mirror;
}

const bookReadLabel: Record<Locale, string> = { en: "Full text · free to read", "zh-Hans": "全文 · 免费阅读", "zh-Hant": "全文 · 免費閱讀", ja: "全文 · 無料で読める", ko: "전문 · 무료로 읽기", vi: "Toàn văn · đọc miễn phí", th: "ฉบับเต็ม · อ่านฟรี" };

function localizedMark(mark: string, locale: Locale) {
  const marks: Record<Locale, Record<string, string>> = {
    en: { "择": "D", "字": "C", "相": "F", "历": "A", "金": "J", "河": "H", "铁": "T", "乙": "Y", "参": "S", "命": "B", "批": "D", "缘": "C", "紫": "Z", "星": "C", "卦": "L", "奇": "Q", "壬": "R", "断": "I", "观": "S", "辰": "D", "宝": "T", "寻": "T", "五": "5", "梦": "D", "梅": "P", "宅": "H", "名": "N", "塔": "T", "易": "I", "盘": "N" },
    "zh-Hans": {},
    "zh-Hant": { "择": "擇", "历": "曆", "铁": "鐵", "参": "參", "缘": "緣", "断": "斷", "观": "觀", "宝": "寶", "寻": "尋", "梦": "夢", "盘": "盤" },
    ja: { "观": "観", "铁": "鉄", "历": "暦", "择": "択" },
    ko: { "择": "택", "字": "자", "相": "상", "历": "력", "金": "금", "河": "하", "铁": "철", "乙": "을", "梅": "매", "宅": "택", "参": "통", "命": "사", "批": "심", "缘": "연", "紫": "자", "星": "성", "卦": "육", "奇": "기", "壬": "임", "断": "문", "观": "관", "辰": "일", "宝": "도", "寻": "시", "五": "오", "梦": "몽", "名": "명", "塔": "타", "易": "역", "盘": "성" },
    vi: { "择": "N", "字": "C", "相": "T", "历": "L", "金": "K", "河": "H", "铁": "T", "乙": "A", "梅": "M", "宅": "P", "参": "T", "命": "B", "批": "S", "缘": "H", "紫": "T", "星": "S", "卦": "L", "奇": "K", "壬": "N", "断": "H", "观": "Q", "辰": "N", "宝": "C", "寻": "T", "五": "5", "梦": "G", "名": "T", "塔": "T", "易": "D", "盘": "B" },
    th: { "择": "ฤ", "字": "อ", "相": "ล", "历": "ป", "金": "จ", "河": "ห", "铁": "ถ", "乙": "อ", "梅": "ม", "宅": "บ", "参": "ร", "命": "ป", "批": "ล", "缘": "ค", "紫": "จ", "星": "ด", "卦": "ล", "奇": "ฉ", "壬": "ต", "断": "ผ", "观": "ส", "辰": "ว", "宝": "ค", "寻": "เ", "五": "๕", "梦": "ฝ", "名": "ช", "塔": "ท", "易": "อ", "盘": "ด" },
  };
  // Marks for the menu's toolkit and learning-resource entries.
  const extra: Record<Locale, Record<string, string>> = { en: { "袋": "T", "藏": "L", "課": "V", "器": "W", "新": "G" }, "zh-Hans": { "袋": "袋", "課": "课" }, "zh-Hant": {}, ja: {}, ko: { "袋": "도", "藏": "장", "課": "강", "器": "공", "新": "신" }, vi: { "袋": "C", "藏": "T", "課": "K", "器": "X", "新": "H" }, th: { "袋": "ค", "藏": "ค", "課": "ว", "器": "ช", "新": "ม" } };
  return marks[locale][mark] ?? extra[locale][mark] ?? mark;
}

function MethodCategorySections({ locale, navigate }: { locale: Locale; navigate: (route: AppRoute) => void }) {
  const hidden = useHiddenRoutes();
  return <>
    {methodCategories.map((category) => (
      <section key={category.key} className={`method-group-${category.key}`}>
        <small>{category.title[locale]}</small>
        <div>
          {category.routes.filter((route) => !hidden.includes(route)).map((route) => {
            const definition = routeByKey[route as keyof typeof routeByKey];
            return (
              <NavLink route={route} locale={locale} onGo={() => navigate(route)} key={route}>
                <i>{localizedMark(definition?.mark ?? (route === "xiangshu" ? "相" : route === "cezi" ? "字" : "历"), locale)}</i>
                <span>
                  <b>{titleForRoute(route, locale)}</b>
                  <em>{methodPitch(route, locale) ?? category.lead[locale]}</em>
                </span>
              </NavLink>
            );
          })}
        </div>
      </section>
    ))}
  </>;
}

function MobileMethodList({ locale, navigate, label }: { locale: Locale; navigate: (route: AppRoute) => void; label: string }) {
  const hidden = useHiddenRoutes();
  const count = useStudyMethodCount();
  return <details className="mobile-method-list">
    <summary>{label} <b>{count}</b></summary>
    {methodCategories.map((category) => (
      <section key={category.key}>
        <small>{category.title[locale]}</small>
        <div>
          {category.routes.filter((route) => !hidden.includes(route)).map((route) => <NavLink route={route} locale={locale} onGo={() => navigate(route)} key={route}>{titleForRoute(route, locale)}</NavLink>)}
        </div>
      </section>
    ))}
  </details>;
}

const studyBarText: Record<Locale, { home: string; methods: string; almanac: string; toolkit: string; me: string; close: string }> = {
  en: { home: "Home", methods: "Study", almanac: "Almanac", toolkit: "Toolkit", me: "Me", close: "Close" },
  "zh-Hans": { home: "首页", methods: "研习", almanac: "黄历", toolkit: "百宝袋", me: "我的", close: "关闭" },
  "zh-Hant": { home: "首頁", methods: "研習", almanac: "黃曆", toolkit: "百寶袋", me: "我的", close: "關閉" },
  ja: { home: "ホーム", methods: "研究", almanac: "暦", toolkit: "百宝袋", me: "マイ", close: "閉じる" },
  ko: { home: "홈", methods: "학습", almanac: "역서", toolkit: "도구함", me: "내 정보", close: "닫기" },
  vi: { home: "Trang chủ", methods: "Học", almanac: "Lịch", toolkit: "Bách bảo", me: "Của tôi", close: "Đóng" },
  th: { home: "หน้าแรก", methods: "ศึกษา", almanac: "ปฏิทิน", toolkit: "คลังศาสตร์", me: "ของฉัน", close: "ปิด" },
};

/** Phone-only bottom bar: home, all study methods (a sheet grouped by purpose), almanac, toolkit and the member area. */
function MobileStudyBar({ locale, route, navigate }: { locale: Locale; route: AppRoute; navigate: (route: AppRoute) => void }) {
  const [open, setOpen] = useState(false);
  const text = studyBarText[locale];
  const count = useStudyMethodCount();
  const studyActive = route in routeByKey || route === "xiangshu" || route === "cezi";
  const go = (next: AppRoute) => { setOpen(false); navigate(next); };
  useEffect(() => {
    if (!open) return;
    const close = (event: KeyboardEvent) => { if (event.key === "Escape") setOpen(false); };
    window.addEventListener("keydown", close);
    return () => window.removeEventListener("keydown", close);
  }, [open]);
  const item = (key: AppRoute | "methods", icon: string, label: string, active: boolean, onClick: () => void) => (
    <button type="button" key={key} className={active ? "active" : ""} aria-current={active ? "page" : undefined} onClick={onClick}><i aria-hidden="true">{icon}</i><span>{label}</span></button>
  );
  return <>
    {open && <div className="study-sheet-backdrop" onClick={() => setOpen(false)} />}
    {open && <div className="study-sheet method-drawer" role="dialog" aria-label={text.methods}>
      <header><b>{text.methods} · {count}</b><button type="button" onClick={() => setOpen(false)}>{text.close} ✕</button></header>
      <MethodCategorySections locale={locale} navigate={go} />
    </div>}
    <nav className="mobile-study-bar" aria-label={text.methods}>
      {item("home", "⌂", text.home, route === "home" && !open, () => go("home"))}
      {item("methods", "☰", text.methods, open || studyActive, () => setOpen((value) => !value))}
      {item("almanac", "历", text.almanac, route === "almanac" && !open, () => go("almanac"))}
      {item("toolkit", "宝", text.toolkit, route === "toolkit" && !open, () => go("toolkit"))}
      {item("membership", "◎", text.me, (route === "membership" || route === "credits") && !open, () => go("membership"))}
    </nav>
  </>;
}

function localizedFloatingMarks(locale: Locale) {
  // Eight faint trigram symbols in every language; letters and words were read as text and crowded the headline.
  void locale;
  return ["☰", "☷", "☳", "☴", "☲", "☵", "☶", "☱"];
}

function getSuiteCopy(locale: Locale) {
  const safeLocale = locale in suiteCopy ? locale : "en";
  return suiteCopy[safeLocale];
}

function localeForCopy(copy: ReturnType<typeof getSuiteCopy>): Locale {
  return (Object.entries(suiteCopy).find(([, value]) => value === copy)?.[0] ??
    "en") as Locale;
}

function profileFieldLabels(copy: ReturnType<typeof getSuiteCopy>) {
  const labels: Record<
    string,
    {
      year: string;
      month: string;
      day: string;
      timeHint: string;
      global: string;
      pillars: [string, string, string, string];
    }
  > = {
    Language: {
      year: "Year",
      month: "Month",
      day: "Day",
      timeHint:
        "Time is used for the calculated hour pillar. If unknown, use 12:00 (noon).",
      global: "Global / overseas",
      pillars: ["Year pillar", "Month pillar", "Day pillar", "Hour pillar"],
    },
    语言: {
      year: "年",
      month: "月",
      day: "日",
      timeHint: "时刻用于计算时柱；若不清楚可填 12:00。",
      global: "全球 / 海外",
      pillars: ["年柱", "月柱", "日柱", "时柱"],
    },
    語言: {
      year: "年",
      month: "月",
      day: "日",
      timeHint: "時刻用於計算時柱；若不清楚可填 12:00。",
      global: "全球 / 海外",
      pillars: ["年柱", "月柱", "日柱", "時柱"],
    },
    言語: {
      year: "年",
      month: "月",
      day: "日",
      timeHint:
        "時刻は時柱の算出に使います。不明な場合は 12:00 を入力してください。",
      global: "海外 / グローバル",
      pillars: ["年柱", "月柱", "日柱", "時柱"],
    },
    언어: {
      year: "연",
      month: "월",
      day: "일",
      timeHint:
        "시간은 시주 계산에 사용됩니다. 모를 경우 12:00으로 입력하세요.",
      global: "해외 / 글로벌",
      pillars: ["년주", "월주", "일주", "시주"],
    },
    "Ngôn ngữ": {
      year: "Năm",
      month: "Tháng",
      day: "Ngày",
      timeHint:
        "Thời gian được dùng để tính trụ giờ. Nếu không rõ, hãy nhập 12:00.",
      global: "Toàn cầu / hải ngoại",
      pillars: ["Trụ năm", "Trụ tháng", "Trụ ngày", "Trụ giờ"],
    },
    ภาษา: {
      year: "ปี",
      month: "เดือน",
      day: "วัน",
      timeHint: "เวลาใช้คำนวณเสาเวลา หากไม่ทราบให้กรอก 12:00",
      global: "ทั่วโลก / ต่างประเทศ",
      pillars: ["เสาปี", "เสาเดือน", "เสาวัน", "เสาเวลา"],
    },
  };
  return labels[copy.nav.language] ?? labels.Language;
}

function localToolText(copy: ReturnType<typeof getSuiteCopy>) {
  const text: Record<
    string,
    {
      casting: string;
      system: string;
      systemDetail: string;
      coins: string;
      coinsDetail: string;
      coinAction: string;
      coinProgress: string;
      coinReady: string;
      coinRestart: string;
      coinHint: string;
      coinKinds: [string, string, string, string];
      coinIncomplete: string;
      direct: string;
      directDetail: string;
      line: string;
      yang: string;
      yin: string;
      current: string;
      questionPlace: string;
      trueSolar: string;
      trueSolarHint: string;
      category: string;
      categories: string[];
      relation: string[];
    }
  > = {
    Language: {
      casting: "Casting method",
      system: "System cast",
      systemDetail: "Create a hexagram",
      coins: "Three-coin cast",
      coinsDetail: "Toss three coins for each line",
      coinAction: "Toss three coins",
      coinProgress: "Line {current} of 6 · bottom to top",
      coinReady: "Six lines recorded",
      coinRestart: "Start again",
      coinHint: "One toss records one line; old yin and old yang become moving lines.",
      coinKinds: ["Old Yin", "Young Yang", "Young Yin", "Old Yang"],
      coinIncomplete: "Complete all six coin throws before generating the chart.",
      direct: "Manual lines",
      directDetail: "Set six Yin or Yang lines directly",
      line: "Line",
      yang: "Yang",
      yin: "Yin",
      current: "Current moment",
      questionPlace: "Study location",
      trueSolar: "Use true solar time",
      trueSolarHint: "Corrects the clock time by the birth place's longitude; choose a birth place first.",
      category: "Inquiry category",
      categories: [
        "General",
        "Career",
        "Resources",
        "Relationship",
        "Study",
        "Movement",
        "Search",
        "Wellness",
      ],
      relation: ["Connection", "Partnership", "Family", "Work", "Friendship"],
    },
    语言: {
      casting: "起卦方式",
      system: "系统摇卦",
      systemDetail: "生成六爻卦象",
      coins: "三枚铜钱摇卦",
      coinsDetail: "每次抛三枚铜钱，六次成卦",
      coinAction: "摇三枚铜钱",
      coinProgress: "第 {current} / 6 爻 · 自下而上",
      coinReady: "六爻已完成",
      coinRestart: "重新起卦",
      coinHint: "每次摇卦记录一爻；老阴、老阳为动爻。",
      coinKinds: ["老阴", "少阳", "少阴", "老阳"],
      coinIncomplete: "请先完成六次铜钱摇卦，再生成盘面。",
      direct: "手动定爻",
      directDetail: "直接设置六个阴爻或阳爻",
      line: "第",
      yang: "阳爻",
      yin: "阴爻",
      current: "当前时刻",
      questionPlace: "起局地点",
      trueSolar: "使用真太阳时",
      trueSolarHint: "按出生地经度校正钟表时间，请先选择出生地。",
      category: "所问类别",
      categories: [
        "综合决断",
        "事业职场",
        "财运合作",
        "感情婚恋",
        "学业考试",
        "出行迁移",
        "失物寻人",
        "健康关怀",
      ],
      relation: ["连接", "合作", "家庭", "工作", "朋友"],
    },
    語言: {
      casting: "起卦方式",
      system: "系統搖卦",
      systemDetail: "生成六爻卦象",
      coins: "三枚銅錢起卦",
      coinsDetail: "每次擲三枚銅錢，六次成卦",
      coinAction: "擲三枚銅錢",
      coinProgress: "第 {current} / 6 爻 · 由下而上",
      coinReady: "六爻已完成",
      coinRestart: "重新起卦",
      coinHint: "每次起卦記錄一爻；老陰、老陽為動爻。",
      coinKinds: ["老陰", "少陽", "少陰", "老陽"],
      coinIncomplete: "請先完成六次銅錢起卦，再生成盤面。",
      direct: "手動定爻",
      directDetail: "直接設定六個陰爻或陽爻",
      line: "第",
      yang: "陽爻",
      yin: "陰爻",
      current: "目前時刻",
      questionPlace: "起局地點",
      trueSolar: "使用真太陽時",
      trueSolarHint: "按出生地經度校正鐘錶時間，請先選擇出生地。",
      category: "所問類別",
      categories: [
        "綜合決斷",
        "事業職場",
        "財運合作",
        "感情婚戀",
        "學業考試",
        "出行遷移",
        "失物尋人",
        "健康關懷",
      ],
      relation: ["連結", "合作", "家庭", "工作", "朋友"],
    },
    言語: {
      casting: "立卦方法",
      system: "自動起卦",
      systemDetail: "六爻卦を作成",
      coins: "三枚コイン立卦",
      coinsDetail: "一回ごとに三枚を投げ、六回で一卦",
      coinAction: "三枚のコインを投げる",
      coinProgress: "第 {current} 爻 / 6 · 下から上へ",
      coinReady: "六爻を記録しました",
      coinRestart: "最初からやり直す",
      coinHint: "一投で一爻を記録します。老陰・老陽は動爻です。",
      coinKinds: ["老陰", "少陽", "少陰", "老陽"],
      coinIncomplete: "盤面を作成する前に、六回のコイン投げを完了してください。",
      direct: "手動入力",
      directDetail: "陰爻・陽爻を六本直接設定",
      line: "爻",
      yang: "陽",
      yin: "陰",
      current: "現在時刻",
      questionPlace: "立局場所",
      trueSolar: "真太陽時を使う",
      trueSolarHint: "出生地の経度で時計の時刻を補正します。先に出生地を選んでください。",
      category: "質問の分類",
      categories: [
        "総合",
        "仕事",
        "資源",
        "関係",
        "学習",
        "移動",
        "探索",
        "健康",
      ],
      relation: ["つながり", "協働", "家族", "仕事", "友人"],
    },
    언어: {
      casting: "점괘 방식",
      system: "자동 점괘",
      systemDetail: "육효 괘 생성",
      coins: "세 동전 괘 세우기",
      coinsDetail: "한 번에 동전 세 개를 던져 여섯 번 기록",
      coinAction: "동전 세 개 던지기",
      coinProgress: "제 {current}효 / 6 · 아래에서 위로",
      coinReady: "여섯 효 기록 완료",
      coinRestart: "처음부터 다시",
      coinHint: "한 번 던질 때 한 효가 기록되며, 노음·노양은 동효입니다.",
      coinKinds: ["노음", "소양", "소음", "노양"],
      coinIncomplete: "판면을 만들기 전에 동전 여섯 번 던지기를 완료하세요.",
      direct: "수동 효 입력",
      directDetail: "음효 또는 양효 여섯 개를 직접 설정",
      line: "효",
      yang: "양효",
      yin: "음효",
      current: "현재 시각",
      questionPlace: "기국 장소",
      trueSolar: "진태양시 사용",
      trueSolarHint: "출생지 경도로 시계 시각을 보정합니다. 먼저 출생지를 선택하세요.",
      category: "질문 분류",
      categories: [
        "종합",
        "직업",
        "자원",
        "관계",
        "학업",
        "이동",
        "탐색",
        "건강",
      ],
      relation: ["연결", "협업", "가족", "업무", "친구"],
    },
    "Ngôn ngữ": {
      casting: "Cách lập quẻ",
      system: "Lập quẻ tự động",
      systemDetail: "Tạo quẻ Lục Hào",
      coins: "Lập quẻ ba đồng xu",
      coinsDetail: "Mỗi lần tung ba đồng xu, đủ sáu lần thành quẻ",
      coinAction: "Tung ba đồng xu",
      coinProgress: "Hào {current}/6 · từ dưới lên",
      coinReady: "Đã ghi đủ sáu hào",
      coinRestart: "Làm lại từ đầu",
      coinHint: "Mỗi lần tung ghi một hào; lão Âm và lão Dương là hào động.",
      coinKinds: ["Lão Âm", "Thiếu Dương", "Thiếu Âm", "Lão Dương"],
      coinIncomplete: "Hãy hoàn thành sáu lần tung đồng xu trước khi tạo bàn cục.",
      direct: "Nhập hào thủ công",
      directDetail: "Thiết lập trực tiếp sáu hào Âm hoặc Dương",
      line: "Hào",
      yang: "Dương",
      yin: "Âm",
      current: "Thời điểm hiện tại",
      questionPlace: "Địa điểm lập cục",
      trueSolar: "Dùng giờ Mặt Trời thực",
      trueSolarHint: "Hiệu chỉnh giờ đồng hồ theo kinh độ nơi sinh; hãy chọn nơi sinh trước.",
      category: "Nhóm câu hỏi",
      categories: [
        "Tổng hợp",
        "Sự nghiệp",
        "Nguồn lực",
        "Mối quan hệ",
        "Học tập",
        "Di chuyển",
        "Tìm kiếm",
        "Sức khỏe",
      ],
      relation: ["Kết nối", "Hợp tác", "Gia đình", "Công việc", "Bạn bè"],
    },
    ภาษา: {
      casting: "วิธีตั้งกว้า",
      system: "ตั้งกว้าอัตโนมัติ",
      systemDetail: "สร้างกว้าหกเส้น",
      coins: "ตั้งกว้าด้วยเหรียญสามเหรียญ",
      coinsDetail: "โยนเหรียญสามเหรียญต่อหนึ่งเส้น รวมหกครั้ง",
      coinAction: "โยนเหรียญสามเหรียญ",
      coinProgress: "เส้นที่ {current}/6 · จากล่างขึ้นบน",
      coinReady: "บันทึกครบหกเส้นแล้ว",
      coinRestart: "เริ่มใหม่",
      coinHint: "การโยนหนึ่งครั้งบันทึกหนึ่งเส้น; หยินแก่และหยางแก่เป็นเส้นเคลื่อน.",
      coinKinds: ["หยินแก่", "หยางอ่อน", "หยินอ่อน", "หยางแก่"],
      coinIncomplete: "กรุณาโยนเหรียญให้ครบหกครั้งก่อนสร้างผัง.",
      direct: "กำหนดเส้นเอง",
      directDetail: "กำหนดหกเส้นหยินหรือหยางโดยตรง",
      line: "เส้น",
      yang: "หยาง",
      yin: "หยิน",
      current: "เวลาปัจจุบัน",
      questionPlace: "สถานที่ตั้งกระดาน",
      trueSolar: "ใช้เวลาสุริยะจริง",
      trueSolarHint: "ปรับเวลานาฬิกาตามลองจิจูดของสถานที่เกิด โปรดเลือกสถานที่เกิดก่อน",
      category: "ประเภทคำถาม",
      categories: [
        "ภาพรวม",
        "อาชีพ",
        "ทรัพยากร",
        "ความสัมพันธ์",
        "การเรียน",
        "การเดินทาง",
        "การค้นหา",
        "สุขภาวะ",
      ],
      relation: ["ความเชื่อมโยง", "หุ้นส่วน", "ครอบครัว", "งาน", "เพื่อน"],
    },
  };
  return text[copy.nav.language] ?? text.Language;
}

const solarChoiceText = {
  legend: { en: "Time basis for the chart", "zh-Hans": "排盘时间依据", "zh-Hant": "排盤時間依據", ja: "盤の時刻の基準", ko: "차트 시각 기준", vi: "Căn cứ giờ lập lá số", th: "เกณฑ์เวลาของผัง" } as Record<Locale, string>,
  solar: { en: "True solar time at the birth place (recommended)", "zh-Hans": "按出生地真太阳时（推荐）", "zh-Hant": "按出生地真太陽時（推薦）", ja: "出生地の真太陽時（おすすめ）", ko: "출생지 진태양시 (권장)", vi: "Giờ Mặt Trời thực tại nơi sinh (khuyên dùng)", th: "เวลาสุริยะจริง ณ ที่เกิด (แนะนำ)" } as Record<Locale, string>,
  clock: { en: "Local clock time as written", "zh-Hans": "按当地钟表时间（不校正）", "zh-Hant": "按當地鐘錶時間（不校正）", ja: "現地の時計の時刻（補正なし）", ko: "현지 시계 시각 (보정 없음)", vi: "Giờ đồng hồ địa phương (không hiệu chỉnh)", th: "เวลานาฬิกาท้องถิ่น (ไม่ปรับ)" } as Record<Locale, string>,
  needCity: { en: "Choose your birth city above — true solar time needs its longitude. Without it the clock time is used.", "zh-Hans": "请在上方选择出生城市：真太阳时需要城市经度；未选择时按钟表时间排盘。", "zh-Hant": "請在上方選擇出生城市：真太陽時需要城市經度；未選擇時按鐘錶時間排盤。", ja: "上で出生都市を選んでください。真太陽時には経度が必要です。未選択なら時計の時刻で作成します。", ko: "위에서 출생 도시를 선택하세요. 진태양시에는 경도가 필요하며, 없으면 시계 시각을 씁니다.", vi: "Hãy chọn thành phố nơi sinh ở trên — giờ Mặt Trời thực cần kinh độ; nếu không sẽ dùng giờ đồng hồ.", th: "โปรดเลือกเมืองที่เกิดด้านบน เวลาสุริยะจริงต้องใช้ลองจิจูด ถ้าไม่เลือกจะใช้เวลานาฬิกา" } as Record<Locale, string>,
  notCity: { en: "That is a whole country or region. For an accurate correction, choose the specific city you were born in.", "zh-Hans": "你选的是国家或省份，范围太大；请改选具体出生城市，校正才准确。", "zh-Hant": "你選的是國家或省份，範圍太大；請改選具體出生城市，校正才準確。", ja: "国や地域全体が選ばれています。正確に補正するには出生した都市を選んでください。", ko: "국가나 지역 전체가 선택됐어요. 정확한 보정을 위해 태어난 도시를 고르세요.", vi: "Đây là cả quốc gia hoặc vùng. Để hiệu chỉnh chính xác, hãy chọn đúng thành phố nơi sinh.", th: "ที่เลือกคือทั้งประเทศหรือภูมิภาค เพื่อความแม่นยำ โปรดเลือกเมืองที่เกิด" } as Record<Locale, string>,
};
/** True solar time needs a populated place (a city or town), not a whole country or province. */
function isCityLevel(location: GlobalLocation | null | undefined) {
  if (!location) return false;
  return !location.featureCode || location.featureCode.startsWith("PPL");
}

function globalLocationText(copy: ReturnType<typeof getSuiteCopy>) {
  const text: Record<
    string,
    {
      placeholder: string;
      searching: string;
      noResults: string;
      externalNotice: string;
      selected: string;
      timezoneUnavailable: string;
      trueSolar: string;
      trueSolarHint: string;
      civilTime: string;
      trueSolarTime: string;
    }
  > = {
    Language: {
      placeholder: "Search your birth city, e.g. Guangzhou, Kuala Lumpur, New York",
      searching: "Searching worldwide locations…",
      noResults:
        "No matching location found. Try the city and country together.",
      externalNotice:
        "Only this place search is sent to the public Open‑Meteo geocoding service; study details remain in this browser.",
      selected: "Selected location",
      timezoneUnavailable: "Time zone could not be resolved — choose a city for true solar time.",
      trueSolar: "Use true solar time for the chart",
      trueSolarHint:
        "Uses the selected location’s longitude and time zone; civil time stays visible alongside the adjusted time.",
      civilTime: "Local clock time",
      trueSolarTime: "True solar time",
    },
    语言: {
      placeholder: "搜索出生城市，如：广州、吉隆坡、New York",
      searching: "正在搜索全球地点…",
      noResults: "未找到匹配地点，请同时输入城市和国家。",
      externalNotice:
        "仅地点关键词会发送至公开 Open‑Meteo 地理编码服务；其余研习信息始终保留在此浏览器。",
      selected: "已选地点",
      timezoneUnavailable: "暂未获得时区；如需真太阳时，请选择具体城市。",
      trueSolar: "排盘使用真太阳时",
      trueSolarHint:
        "依据所选地点的经度和时区计算；民用时与校正后时间会同时保留。",
      civilTime: "当地时间",
      trueSolarTime: "真太阳时",
    },
    語言: {
      placeholder: "搜尋出生城市，如：台北、吉隆坡、New York",
      searching: "正在搜尋全球地點…",
      noResults: "找不到相符地點，請一併輸入城市與國家。",
      externalNotice:
        "僅地點關鍵字會傳送至公開 Open‑Meteo 地理編碼服務；其餘研習資訊均保留在此瀏覽器。",
      selected: "已選地點",
      timezoneUnavailable: "尚未取得時區；如需真太陽時，請選擇具體城市。",
      trueSolar: "排盤使用真太陽時",
      trueSolarHint:
        "依所選地點的經度與時區計算；民用時與校正後時間會一併保留。",
      civilTime: "當地時間",
      trueSolarTime: "真太陽時",
    },
    言語: {
      placeholder: "出生した都市を検索（例：東京、大阪、New York）",
      searching: "世界の地点を検索中…",
      noResults:
        "一致する地点がありません。都市名と国名を併記して試してください。",
      externalNotice:
        "公開 Open‑Meteo ジオコーディングサービスへ送信するのは地点検索語だけです。学習情報はこのブラウザ内に残ります。",
      selected: "選択した地点",
      timezoneUnavailable: "タイムゾーンを取得できません。真太陽時には都市を選択してください。",
      trueSolar: "盤に真太陽時を使用",
      trueSolarHint:
        "選択地点の経度とタイムゾーンで算出します。民用時と補正後の時刻を併記します。",
      civilTime: "現地時刻",
      trueSolarTime: "真太陽時",
    },
    언어: {
      placeholder: "출생 도시 검색 (예: 서울, 부산, New York)",
      searching: "전 세계 장소를 검색 중…",
      noResults: "일치하는 장소가 없습니다. 도시와 국가를 함께 입력해 보세요.",
      externalNotice:
        "장소 검색어만 공개 Open‑Meteo 지오코딩 서비스로 전송됩니다. 학습 정보는 이 브라우저에 남습니다.",
      selected: "선택한 장소",
      timezoneUnavailable: "시간대를 찾을 수 없습니다. 진태양시에는 도시를 선택하세요.",
      trueSolar: "명반에 진태양시 사용",
      trueSolarHint:
        "선택한 장소의 경도와 시간대로 계산하며, 민용시와 보정 시간을 함께 표시합니다.",
      civilTime: "현지 시각",
      trueSolarTime: "진태양시",
    },
    "Ngôn ngữ": {
      placeholder: "Tìm thành phố nơi sinh, ví dụ: Hà Nội, TP Hồ Chí Minh",
      searching: "Đang tìm địa điểm toàn cầu…",
      noResults:
        "Không tìm thấy địa điểm phù hợp. Hãy thử nhập cả thành phố và quốc gia.",
      externalNotice:
        "Chỉ từ khóa địa điểm được gửi tới dịch vụ mã hóa địa lý công khai Open‑Meteo; mọi thông tin nghiên cứu vẫn ở trong trình duyệt này.",
      selected: "Địa điểm đã chọn",
      timezoneUnavailable: "Chưa xác định được múi giờ; hãy chọn một thành phố để dùng giờ Mặt Trời thực.",
      trueSolar: "Dùng giờ Mặt Trời thực cho biểu đồ",
      trueSolarHint:
        "Tính theo kinh độ và múi giờ của địa điểm đã chọn; giờ dân dụng và giờ đã hiệu chỉnh đều được hiển thị.",
      civilTime: "Giờ địa phương",
      trueSolarTime: "Giờ Mặt Trời thực",
    },
    ภาษา: {
      placeholder: "ค้นหาเมืองที่เกิด เช่น กรุงเทพฯ เชียงใหม่",
      searching: "กำลังค้นหาสถานที่ทั่วโลก…",
      noResults: "ไม่พบสถานที่ที่ตรงกัน ลองระบุทั้งเมืองและประเทศ",
      externalNotice:
        "ส่งเฉพาะคำค้นหาสถานที่ไปยังบริการระบุตำแหน่งสาธารณะ Open‑Meteo เท่านั้น ข้อมูลการศึกษายังคงอยู่ในเบราว์เซอร์นี้",
      selected: "สถานที่ที่เลือก",
      timezoneUnavailable: "ยังระบุเขตเวลาไม่ได้ โปรดเลือกเมืองหากต้องการใช้เวลาสุริยะจริง",
      trueSolar: "ใช้เวลาสุริยะจริงสำหรับผัง",
      trueSolarHint:
        "คำนวณจากลองจิจูดและเขตเวลาของสถานที่ที่เลือก โดยแสดงเวลาท้องถิ่นและเวลาที่ปรับแล้วควบคู่กัน",
      civilTime: "เวลาท้องถิ่น",
      trueSolarTime: "เวลาสุริยะจริง",
    },
  };
  return text[copy.nav.language] ?? text.Language;
}

function localResultText(copy: ReturnType<typeof getSuiteCopy>) {
  const text: Record<
    string,
    {
      solar: string;
      lunar: string;
      naYin: string;
      calendar: string;
      balance: string;
      practice: string;
      sources: string;
      calendarSource: string;
      pillarSource: string;
      pairedSource: string;
      intro: string;
      direct: string;
      practiceLead: string;
      year: string;
      elements: Record<string, string>;
    }
  > = {
    Language: {
      solar: "Solar",
      lunar: "Lunar",
      naYin: "NaYin",
      calendar: "Calendar",
      balance: "Element balance",
      practice: "Practice",
      sources: "Source notes",
      calendarSource: "Calculated solar/lunar conversion",
      pillarSource: "Four pillars: year · month · day · hour",
      pairedSource: "Second profile",
      intro:
        "Begin with the arrangement before naming a meaning. A chart is a structured information field, not an authority over choice.",
      direct: "Notice the pattern. Keep your choice.",
      practiceLead: "Use the day’s cultural references as study prompts",
      year: "year",
      elements: {
        Wood: "Wood",
        Fire: "Fire",
        Earth: "Earth",
        Metal: "Metal",
        Water: "Water",
      },
    },
    语言: {
      solar: "公历",
      lunar: "农历",
      naYin: "纳音",
      calendar: "历法",
      balance: "五行平衡",
      practice: "研习提示",
      sources: "研习依据",
      calendarSource: "已计算公历与农历转换",
      pillarSource: "四柱：年 · 月 · 日 · 时",
      pairedSource: "第二位资料",
      intro: "先观察盘面的结构，再安放意义。命盘呈现结构信息，不替代个人选择。",
      direct: "看见结构，选择仍在自己手中。",
      practiceLead: "将当日传统信息作为研习提示",
      year: "年",
      elements: {
        Wood: "木",
        Fire: "火",
        Earth: "土",
        Metal: "金",
        Water: "水",
      },
    },
    語言: {
      solar: "公曆",
      lunar: "農曆",
      naYin: "納音",
      calendar: "曆法",
      balance: "五行平衡",
      practice: "研習提示",
      sources: "研習依據",
      calendarSource: "已計算公曆與農曆轉換",
      pillarSource: "四柱：年 · 月 · 日 · 時",
      pairedSource: "第二位資料",
      intro: "先觀察盤面的結構，再安放意義。命盤呈現結構資訊，不取代個人選擇。",
      direct: "看見結構，選擇仍在自己手中。",
      practiceLead: "將當日傳統資訊作為研習提示",
      year: "年",
      elements: {
        Wood: "木",
        Fire: "火",
        Earth: "土",
        Metal: "金",
        Water: "水",
      },
    },
    言語: {
      solar: "太陽暦",
      lunar: "太陰暦",
      naYin: "納音",
      calendar: "暦",
      balance: "五行のバランス",
      practice: "学習メモ",
      sources: "根拠メモ",
      calendarSource: "太陽暦・太陰暦を自動で換算",
      pillarSource: "四柱：年 · 月 · 日 · 時",
      pairedSource: "第二プロフィール",
      intro:
        "意味づけの前に、まず配置を見ます。チャートは構造情報の場であり、選択を決めるものではありません。",
      direct: "構造を見て、選択は自分で行いましょう。",
      practiceLead: "当日の伝統的な情報を学習の手がかりにします",
      year: "年",
      elements: {
        Wood: "木",
        Fire: "火",
        Earth: "土",
        Metal: "金",
        Water: "水",
      },
    },
    언어: {
      solar: "양력",
      lunar: "음력",
      naYin: "납음",
      calendar: "달력",
      balance: "오행 균형",
      practice: "학습 메모",
      sources: "근거 메모",
      calendarSource: "양력·음력 변환",
      pillarSource: "사주: 년 · 월 · 일 · 시",
      pairedSource: "두 번째 프로필",
      intro:
        "의미를 붙이기 전에 먼저 배치를 살펴보세요. 차트는 구조 정보의 장이며, 개인의 선택을 대신하지 않습니다.",
      direct: "구조를 보고, 선택은 스스로 하세요.",
      practiceLead: "그날의 전통 정보를 학습 단서로 활용하세요",
      year: "년",
      elements: {
        Wood: "목",
        Fire: "화",
        Earth: "토",
        Metal: "금",
        Water: "수",
      },
    },
    "Ngôn ngữ": {
      solar: "Dương lịch",
      lunar: "Âm lịch",
      naYin: "Nạp âm",
      calendar: "Lịch",
      balance: "Cân bằng Ngũ Hành",
      practice: "Gợi ý học tập",
      sources: "Ghi chú nguồn",
      calendarSource: "Chuyển đổi dương lịch/âm lịch",
      pillarSource: "Tứ trụ: năm · tháng · ngày · giờ",
      pairedSource: "Hồ sơ thứ hai",
      intro:
        "Hãy quan sát bố cục trước khi gắn ý nghĩa. Biểu đồ là trường thông tin có cấu trúc, không thay thế lựa chọn cá nhân.",
      direct: "Nhận ra cấu trúc; lựa chọn vẫn là của bạn.",
      practiceLead: "Dùng thông tin truyền thống của ngày làm gợi ý học tập",
      year: "năm",
      elements: {
        Wood: "Mộc",
        Fire: "Hỏa",
        Earth: "Thổ",
        Metal: "Kim",
        Water: "Thủy",
      },
    },
    ภาษา: {
      solar: "สุริยคติ",
      lunar: "จันทรคติ",
      naYin: "น่ายิน",
      calendar: "ปฏิทิน",
      balance: "สมดุลธาตุทั้งห้า",
      practice: "บันทึกการศึกษา",
      sources: "บันทึกแหล่งที่มา",
      calendarSource: "แปลงปฏิทินสุริยคติ/จันทรคติ",
      pillarSource: "สี่เสา: ปี · เดือน · วัน · เวลา",
      pairedSource: "โปรไฟล์ที่สอง",
      intro:
        "สังเกตการจัดวางก่อนตีความ แผนผังคือข้อมูลที่มีโครงสร้าง ไม่ได้แทนที่การเลือกของคุณ",
      direct: "เห็นโครงสร้าง แล้วตัดสินใจด้วยตัวเอง",
      practiceLead: "ใช้ข้อมูลตามจารีตของวันนั้นเป็นจุดตั้งต้นในการศึกษา",
      year: "ปี",
      elements: {
        Wood: "ไม้",
        Fire: "ไฟ",
        Earth: "ดิน",
        Metal: "ทอง",
        Water: "น้ำ",
      },
    },
  };
  return text[copy.nav.language] ?? text.Language;
}

function visualLabel(visual: StudyVisualKind) {
  return `${visual}-study-visual`;
}

function toolkitTitle(
  key: ToolkitKey,
  _copy: ReturnType<typeof getSuiteCopy>,
  locale: Locale,
) {
  return toolkitName(key, locale);
}

function toolkitDescription(key: ToolkitKey, locale: Locale) {
  return toolkitLead(key, locale);
}

function localizeToolkitResult(
  result: ReturnType<typeof makeToolkitResult>,
  locale: Locale,
) {
  const seeds = [
    "Dawn window",
    "Gentle boundary",
    "Returning light",
    "Clear water",
    "Open gate",
    "Quiet earth",
    "Living wood",
    "Warm fire",
  ];
  const words: Record<Exclude<Locale, "en">, string[]> = {
    "zh-Hans": [
      "晨光之窗",
      "柔和边界",
      "回归之光",
      "清澈之水",
      "敞开之门",
      "静土",
      "生发之木",
      "温暖之火",
    ],
    "zh-Hant": [
      "晨光之窗",
      "柔和邊界",
      "回歸之光",
      "清澈之水",
      "敞開之門",
      "靜土",
      "生發之木",
      "溫暖之火",
    ],
    ja: [
      "朝の窓",
      "やわらかな境界",
      "戻る光",
      "澄んだ水",
      "開いた門",
      "静かな土",
      "生きる木",
      "温かな火",
    ],
    ko: [
      "새벽의 창",
      "부드러운 경계",
      "돌아오는 빛",
      "맑은 물",
      "열린 문",
      "고요한 흙",
      "살아 있는 나무",
      "따뜻한 불",
    ],
    vi: [
      "Khung cửa bình minh",
      "Ranh giới dịu dàng",
      "Ánh sáng trở về",
      "Nước trong",
      "Cánh cổng mở",
      "Đất yên",
      "Gỗ sống",
      "Lửa ấm",
    ],
    th: [
      "หน้าต่างยามรุ่งอรุณ",
      "ขอบเขตที่อ่อนโยน",
      "แสงที่หวนกลับ",
      "สายน้ำใส",
      "ประตูที่เปิดอยู่",
      "ผืนดินสงบ",
      "ไม้ที่มีชีวิต",
      "ไฟอบอุ่น",
    ],
  };
  const defaults: Record<Locale, string> = {
    en: "Begin with one small, honest observation.",
    "zh-Hans": "从一个小而诚实的观察开始。",
    "zh-Hant": "從一個小而誠實的觀察開始。",
    ja: "小さく率直な観察から始めましょう。",
    ko: "작고 솔직한 관찰에서 시작하세요.",
    vi: "Hãy bắt đầu bằng một quan sát nhỏ và chân thành.",
    th: "เริ่มจากการสังเกตเล็ก ๆ ที่ซื่อตรงหนึ่งอย่าง",
  };
  if (locale === "en") return result;
  const localWords = words[locale];
  const translate = (value: string) => {
    const index = seeds.indexOf(value);
    return index >= 0 ? localWords[index] : value;
  };
  return {
    title: translate(result.title),
    line: result.line === defaults.en ? defaults[locale] : result.line,
    facets: result.facets.map(translate),
  };
}

function localizeDailyNote(note: string, locale: Locale) {
  const english = [
    "Keep the day spacious before making a large decision.",
    "Let one unfinished conversation become clearer through listening.",
    "Choose steadiness over a quick answer.",
    "A practical detail deserves the first ten minutes of attention.",
    "Make room for a small act of restoration.",
  ];
  const translations: Record<Exclude<Locale, "en">, string[]> = {
    "zh-Hans": [
      "做重大决定前，先给这一天留出空间。",
      "让一段未完成的对话在倾听中变得清晰。",
      "选择稳妥，而不是仓促回答。",
      "先用十分钟关注一个实际细节。",
      "为一个小小的修复行动留出空间。",
    ],
    "zh-Hant": [
      "做重大決定前，先給這一天留出空間。",
      "讓一段未完成的對話在傾聽中變得清晰。",
      "選擇穩妥，而不是倉促回答。",
      "先用十分鐘關注一個實際細節。",
      "為一個小小的修復行動留出空間。",
    ],
    ja: [
      "大きな決断の前に、今日に余白を残しましょう。",
      "終わっていない会話を、聴くことで少し明確にしましょう。",
      "早い答えよりも、安定を選びましょう。",
      "最初の十分は実務的な細部に向けましょう。",
      "小さな回復の行為のために余白を作りましょう。",
    ],
    ko: [
      "큰 결정을 내리기 전, 오늘에 여백을 남겨 두세요.",
      "끝나지 않은 대화를 경청으로 조금 더 분명하게 해보세요.",
      "빠른 답보다 안정감을 선택하세요.",
      "처음 10분은 실질적인 세부 사항에 쓰세요.",
      "작은 회복의 행동을 위한 여지를 만드세요.",
    ],
    vi: [
      "Hãy để ngày hôm nay có khoảng trống trước khi đưa ra quyết định lớn.",
      "Hãy để một cuộc trò chuyện chưa xong trở nên rõ hơn qua lắng nghe.",
      "Chọn sự vững vàng thay vì một câu trả lời vội vàng.",
      "Hãy dành mười phút đầu cho một chi tiết thực tế.",
      "Hãy dành chỗ cho một hành động phục hồi nhỏ.",
    ],
    th: [
      "เว้นพื้นที่ให้วันนี้ก่อนตัดสินใจเรื่องใหญ่",
      "ปล่อยให้บทสนทนาที่ยังค้างชัดเจนขึ้นด้วยการรับฟัง",
      "เลือกความมั่นคงแทนคำตอบที่รีบร้อน",
      "ให้ความสนใจรายละเอียดเชิงปฏิบัติในสิบนาทีแรก",
      "เว้นที่ไว้สำหรับการฟื้นฟูเล็ก ๆ หนึ่งอย่าง",
    ],
  };
  if (locale === "en") return note;
  const index = english.indexOf(note);
  return index >= 0 ? translations[locale][index] : note;
}

const studyVisualCopy: Record<Locale, { pillars: [string, string, string, string]; daily: string; comparison: [string, string, string]; comparisonLead: string }> = {
  en: { pillars: ["YEAR", "MONTH", "DAY", "HOUR"], daily: "SEASONAL RHYTHM", comparison: ["origin", "rhythm", "context"], comparisonLead: "A visual where several structured perspectives meet." },
  "zh-Hans": { pillars: ["年柱", "月柱", "日柱", "时柱"], daily: "每日时序", comparison: ["起点", "节律", "语境"], comparisonLead: "多个结构视角在此共同展开。" },
  "zh-Hant": { pillars: ["年柱", "月柱", "日柱", "時柱"], daily: "每日時序", comparison: ["起點", "節律", "語境"], comparisonLead: "多個結構視角在此共同展開。" },
  ja: { pillars: ["年柱", "月柱", "日柱", "時柱"], daily: "日々の時序", comparison: ["起点", "リズム", "文脈"], comparisonLead: "複数の構造的な視点をここで並べて観察します。" },
  ko: { pillars: ["년주", "월주", "일주", "시주"], daily: "일일 시서", comparison: ["기점", "리듬", "맥락"], comparisonLead: "여러 구조적 관점을 이곳에서 함께 살펴봅니다." },
  vi: { pillars: ["Trụ năm", "Trụ tháng", "Trụ ngày", "Trụ giờ"], daily: "Nhịp thời gian hằng ngày", comparison: ["Khởi nguồn", "Nhịp điệu", "Bối cảnh"], comparisonLead: "Nhiều góc nhìn cấu trúc cùng được quan sát tại đây." },
  th: { pillars: ["เสาปี", "เสาเดือน", "เสาวัน", "เสาเวลา"], daily: "จังหวะตามฤดูกาล", comparison: ["จุดเริ่ม", "จังหวะ", "บริบท"], comparisonLead: "มุมมองเชิงโครงสร้างหลายด้านถูกร่วมสังเกตที่นี่" },
};

function StudyVisual({
  result,
  visual,
  locale,
}: {
  result: StudyResult;
  visual: StudyVisualKind;
  locale: Locale;
}) {
  const text = studyVisualCopy[locale];
  if (visual === "pillars") {
    return (
      <div
        className="study-visual pillars-visual"
        aria-label={visualLabel(visual)}
      >
        {result.pillars.map((pillar, index) => (
          <article key={`${index}-${pillar}`} className={index === 3 && result.input?.timeUnknown ? "is-unknown" : undefined}>
            <small>{text.pillars[index]}</small>
            <strong>{index === 3 && result.input?.timeUnknown ? "?" : pillar}</strong>
            <i />
          </article>
        ))}
      </div>
    );
  }
  if (visual === "palaces" || visual === "celestial") {
    const marks =
      visual === "palaces"
        ? [
            "命",
            "兄",
            "夫",
            "子",
            "财",
            "疾",
            "迁",
            "友",
            "官",
            "田",
            "福",
            "父",
          ]
        : [
            "日",
            "月",
            "水",
            "金",
            "火",
            "木",
            "土",
            "升",
            "降",
            "交",
            "守",
            "行",
          ];
    return (
      <div
        className={`study-visual wheel-visual ${visual}`}
        aria-label={visualLabel(visual)}
      >
        <div className="wheel-ring">
          {marks.map((mark, index) => (
            <span
              key={`${mark}-${index}`}
              style={{
                transform: `rotate(${index * 30}deg) translateY(-118px) rotate(${-index * 30}deg)`,
              }}
            >
              {mark}
            </span>
          ))}
        </div>
        <b>{visual === "palaces" ? "紫\n微" : "星\n象"}</b>
      </div>
    );
  }
  if (visual === "hexagram") {
    return (
      <div
        className="study-visual hexagram-visual"
        aria-label={visualLabel(visual)}
      >
        {/* lines are stored bottom-first; draw the top line first and break the yin lines */}
        {[...result.lines].reverse().map((yang, index) => (
          <span key={index} className={yang ? "" : "broken"}>
            <i />
            <i />
          </span>
        ))}
      </div>
    );
  }
  if (visual === "timing") {
    const timingBoard =
      result.module === "qimen"
        ? [
            "天蓬",
            "天芮",
            "天冲",
            "天辅",
            "值符",
            "天心",
            "天柱",
            "天任",
            "天英",
          ]
        : result.module === "daliuren"
          ? [
              "地分",
              "天盘",
              "四课",
              "初传",
              "中传",
              "末传",
              "贵神",
              "将神",
              "旬空",
            ]
          : result.timing;
    return (
      <div
        className="study-visual timing-visual"
        aria-label={visualLabel(visual)}
      >
        {timingBoard.map((item, index) => (
          <span
            key={`${item}-${index}`}
            className={index === 4 ? "center" : ""}
          >
            <i>{String(index + 1).padStart(2, "0")}</i>
            {item}
          </span>
        ))}
      </div>
    );
  }
  if (visual === "daily") {
    return (
      <div
        className="study-visual daily-visual"
        aria-label={visualLabel(visual)}
      >
        <small>{text.daily}</small>
        <strong>{result.timing.slice(0, 2).join(" · ")}</strong>
        <div>
          {Array.from({ length: 24 }, (_, index) => (
            <i key={index} className={index % 5 === 0 ? "lit" : ""} />
          ))}
        </div>
      </div>
    );
  }
  if (visual === "spread") {
    return (
      <div
        className="study-visual spread-visual"
        aria-label={visualLabel(visual)}
      >
        {result.cards.map((card, index) => (
          <article key={card}>
            <small>{String(index + 1).padStart(2, "0")}</small>
            <b>{["◐", "✦", "⌁"][index]}</b>
            <span>{card}</span>
          </article>
        ))}
      </div>
    );
  }
  const comparisonPillars = result.companionPillars
    ? [
        result.pillars[2],
        result.companionPillars[2],
        `${result.pillars[3]} · ${result.companionPillars[3]}`,
      ]
    : result.pillars.slice(0, 3);
  const comparisonLabels = result.companionPillars
    ? ["profile 01", "profile 02", "shared rhythm"]
    : text.comparison;
  return (
    <div
      className="study-visual comparison-visual"
      aria-label={visualLabel(visual)}
    >
      {comparisonPillars.map((pillar, index) => (
        <article key={`${pillar}-${index}`}>
          <small>{String(index + 1).padStart(2, "0")}</small>
          <b>{pillar}</b>
          <span>{comparisonLabels[index]}</span>
        </article>
      ))}
      <p>
        {result.focus ||
          text.comparisonLead}
      </p>
    </div>
  );
}

// Kept as a lightweight visual fallback for future condensed tool routes.
// eslint-disable-next-line @typescript-eslint/no-unused-vars
function ResultPanel({
  result,
  visual,
  copy,
  persona,
  depth,
  onRegenerate,
}: {
  result: StudyResult;
  visual: StudyVisualKind;
  copy: ReturnType<typeof getSuiteCopy>;
  persona: Persona;
  depth: Depth;
  onRegenerate: () => void;
}) {
  const locale = localeForCopy(copy);
  const shared = uiCopy(locale);
  const labels = localResultText(copy);
  const opening =
    persona === "scholar" ? labels.intro : `${labels.direct} ${labels.intro}`;
  const sections = [
    {
      title: labels.calendar,
      text: `${labels.solar} ${result.calendar.solar} · ${labels.lunar} ${result.calendar.lunar} · ${result.calendar.zodiac} ${labels.year}.`,
    },
    {
      title: labels.balance,
      text: result.calendar.elements
        .map(
          (element) =>
            `${labels.elements[element.name] ?? element.name} ${element.count}`,
        )
        .join(" · "),
    },
    {
      title: labels.practice,
      text: `${labels.practiceLead}：宜 ${result.calendar.yi.join("、") || "—"}；忌 ${result.calendar.ji.join("、") || "—"}。`,
    },
  ];
  const sources = [
    labels.calendarSource,
    labels.pillarSource,
    `${labels.naYin}: ${result.calendar.naYin}`,
    ...(result.companionPillars
      ? [`${labels.pairedSource}: ${result.companionPillars.join(" · ")}`]
      : []),
  ];
  const focusLine = result.focus.trim() ? ` ${result.focus.trim()}` : "";
  return (
    <section className="result-panel" aria-live="polite">
      <header>
        <span>{shared.brandKicker}</span>
        <h2>{copy.form.result}</h2>
        <button
          type="button"
          onClick={onRegenerate}
          aria-label={copy.form.regenerate}
        >
          ↻
        </button>
      </header>
      <StudyVisual result={result} visual={visual} locale={locale} />
      <div className="result-calendar">
        <span>
          <b>{labels.solar}</b>
          {result.calendar.solar}
        </span>
        <span>
          <b>{labels.lunar}</b>
          {result.calendar.lunar}
        </span>
        <span>
          <b>{labels.naYin}</b>
          {result.calendar.naYin}
        </span>
      </div>
      <p className="result-summary">
        {depth === "direct" ? labels.direct : `${opening}${focusLine}`}
      </p>
      {depth === "full" && (
        <div className="result-sections">
          {sections.map((section) => (
            <article key={section.title}>
              <small>{section.title}</small>
              <p>{section.text}</p>
            </article>
          ))}
        </div>
      )}
      <div className="source-notes">
        <h3>{labels.sources}</h3>
        {sources.map((source) => (
          <span key={source}>· {source}</span>
        ))}
      </div>
    </section>
  );
}

function ProfileFields({
  copy,
  form,
  setForm,
  partner = false,
  allowPillars = true,
}: {
  copy: ReturnType<typeof getSuiteCopy>;
  form: FormState;
  setForm: (next: FormState) => void;
  partner?: boolean;
  /** Manual pillars only make sense for pillar-based methods; Zi Wei, Qi Zheng and others need a real date. */
  allowPillars?: boolean;
}) {
  const calendarKey = partner ? "partnerCalendar" : "calendar";
  const genderKey = partner ? "partnerGender" : "gender";
  const dateKey = partner ? "partnerDate" : "date";
  const timeKey = partner ? "partnerTime" : "time";
  const placeKey = partner ? "partnerPlace" : "place";
  const locationKey = partner ? "partnerLocation" : "location";
  const pillarKey = partner ? "partnerManualPillars" : "manualPillars";
  const leapKey = partner ? "partnerLeapMonth" : "leapMonth";
  const unknownKey = partner ? "partnerTimeUnknown" : "timeUnknown";
  const bt = (key: keyof typeof birthTimeText) => birthTimeText[key][localeForCopy(copy)];
  const [year = "1994", month = "08", day = "18"] = form[dateKey].split("-");
  const calendarText = inputCalendarCopy[localeForCopy(copy)] ?? inputCalendarCopy.en;
  const yearLeapMonth = form[calendarKey] === "lunar" ? leapMonthOf(Number(year)) : 0;
  const changeCalendar = (next: FormState["calendar"]) => {
    const converted = convertCalendar(form[dateKey], form[timeKey], form[calendarKey], next, Boolean(form[leapKey]));
    setForm({
      ...form,
      [calendarKey]: next,
      [dateKey]: converted.date,
      [leapKey]: converted.leap,
      ...(converted.pillars ? { [pillarKey]: converted.pillars } : {}),
    });
  };
  // From 1900 to next year, so expected or newborn babies can be entered too.
  const lastYear = new Date().getFullYear() + 1;
  const years = Array.from({ length: lastYear - 1899 }, (_, index) => String(lastYear - index));
  const pillarPairs = Array.from(
    { length: 60 },
    (_, index) =>
      `${["甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸"][index % 10]}${["子", "丑", "寅", "卯", "辰", "巳", "午", "未", "申", "酉", "戌", "亥"][index % 12]}`,
  );
  const labels = profileFieldLabels(copy);
  const selectedPillars = form[pillarKey] ?? ["甲戌", "壬申", "丙子", "甲午"];
  const updateDate = (part: "year" | "month" | "day", value: string) => {
    const nextYear = part === "year" ? value : year;
    const nextMonth = part === "month" ? value : month;
    const nextDay = part === "day" ? value : day;
    const leapStillValid = leapMonthOf(Number(nextYear)) === Number(nextMonth);
    setForm({ ...form, [dateKey]: `${nextYear}-${nextMonth}-${nextDay}`, [leapKey]: Boolean(form[leapKey]) && leapStillValid });
  };
  const updatePillar = (index: number, value: string) =>
    setForm({
      ...form,
      [pillarKey]: selectedPillars.map((pillar, pillarIndex) =>
        pillarIndex === index ? value : pillar,
      ),
    });
  const warnings = form[calendarKey] === "pillars" ? pillarWarnings(selectedPillars) : [];
  const calendarFields =
    form[calendarKey] === "pillars" ? (
      <>
      <div className="pillar-input-grid">
        {labels.pillars.map((label, index) => (
          <label key={label}>
            <span>{label}</span>
            <select
              value={selectedPillars[index]}
              onChange={(event) => updatePillar(index, event.target.value)}
            >
              {pillarPairs.map((value) => (
                <option value={value} key={value}>
                  {value}
                </option>
              ))}
            </select>
          </label>
        ))}
      </div>
      {warnings.length > 0 && (
        <p className="field-hint field-warning" role="alert">
          {warnings.map((code) => (code === "month-stem" ? calendarText.monthStem : code === "hour-stem" ? calendarText.hourStem : calendarText.invalid)).join(" ")}
        </p>
      )}
      <p className="field-hint">{calendarText.pillarsNote}</p>
      </>
    ) : (
      <>
        <div className="birth-date-grid">
          <label>
            <span>{labels.year}</span>
            <select
              value={year}
              onChange={(event) => updateDate("year", event.target.value)}
            >
              {year === "" && <option value="">—</option>}
              {years.map((value) => (
                <option value={value} key={value}>
                  {value}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>{labels.month}</span>
            <select
              value={month}
              onChange={(event) => updateDate("month", event.target.value)}
            >
              {Array.from({ length: 12 }, (_, index) =>
                String(index + 1).padStart(2, "0"),
              ).map((value) => (
                <option value={value} key={value}>
                  {value}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>{labels.day}</span>
            <select
              value={day}
              onChange={(event) => updateDate("day", event.target.value)}
            >
              {Array.from({ length: form[calendarKey] === "lunar" ? 30 : 31 }, (_, index) =>
                String(index + 1).padStart(2, "0"),
              ).map((value) => (
                <option value={value} key={value}>
                  {value}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>{copy.form.time}<FieldHelp topic="time" locale={localeForCopy(copy)} /></span>
            <input
              type="time"
              value={form[unknownKey] ? "" : form[timeKey]}
              disabled={Boolean(form[unknownKey])}
              onInput={(event) =>
                setForm({ ...form, [timeKey]: event.currentTarget.value })
              }
              onChange={(event) =>
                setForm({ ...form, [timeKey]: event.target.value })
              }
            />
          </label>
        </div>
        <label className="check-line time-unknown-line">
          <input type="checkbox" checked={Boolean(form[unknownKey])} onChange={(event) => setForm({ ...form, [unknownKey]: event.target.checked })} />
          <span>{bt("unknown")}</span>
        </label>
        {yearLeapMonth > 0 && yearLeapMonth === Number(month) && (
          <label className="check-line">
            <input
              type="checkbox"
              checked={Boolean(form[leapKey])}
              onChange={(event) => setForm({ ...form, [leapKey]: event.target.checked })}
            />
            <span>{calendarText.leap}</span>
          </label>
        )}
        {form[unknownKey] ? <p className="field-hint field-warning">{bt("unknownOn")}</p> : <p className="field-hint">{bt("hint")} <a className="text-action" href={`${pathFor(localeForCopy(copy), "toolkit")}?tool=time`}>{bt("finder")} →</a></p>}
        {!partner && form.exampleBirth && <p className="field-hint example-birth-note"><b className="example-chip">{bt("example")}</b>{bt("exampleNote")}</p>}
      </>
    );
  const locale = localeForCopy(copy);
  const locationText = globalLocationText(copy);
  const nameKey = partner ? "partner" : "name";
  return (
    <section className="profile-fields">
      <ProfilePicker
        locale={locale}
        current={{ name: String(form[nameKey] ?? ""), gender: form[genderKey], calendar: form[calendarKey], date: form[dateKey], time: form[timeKey], place: form[placeKey], leapMonth: Boolean(form[leapKey]), location: form[locationKey] ? { label: form[locationKey]!.label, latitude: form[locationKey]!.latitude, longitude: form[locationKey]!.longitude, timezone: form[locationKey]!.timezone } : null }}
        onPick={(profile) => setForm({
          ...form,
          [nameKey]: profile.name || profile.label,
          [genderKey]: profile.gender,
          [calendarKey]: profile.calendar,
          [dateKey]: profile.date,
          [timeKey]: profile.time || "12:00",
          [leapKey]: profile.leapMonth,
          [placeKey]: profile.location?.label || profile.place,
          [locationKey]: profile.location ? { id: 0, name: profile.location.label, country: "", latitude: profile.location.latitude, longitude: profile.location.longitude, timezone: profile.location.timezone, label: profile.location.label } : null,
        })}
      />
      <label>
        <span>{copy.form.calendar}<FieldHelp topic="calendar" locale={locale} /></span>
        <select
          value={form[calendarKey]}
          onChange={(event) => changeCalendar(event.target.value as FormState["calendar"])}
        >
          <option value="solar">{copy.form.solar}</option>
          <option value="lunar">{copy.form.lunar}</option>
          {allowPillars && <option value="pillars">{copy.form.pillars}</option>}
        </select>
      </label>
      {calendarFields}
      <label>
        <span>{copy.form.gender}<FieldHelp topic="gender" locale={locale} /></span>
        <select
          value={form[genderKey]}
          onChange={(event) =>
            setForm({ ...form, [genderKey]: event.target.value as FormState[typeof genderKey] })
          }
        >
          <option value="yang">{copy.form.yang}</option>
          <option value="yin">{copy.form.yin}</option>
        </select>
      </label>
      <GlobalLocationField
        label={copy.form.place}
        help={<FieldHelp topic="place" locale={locale} />}
        value={form[placeKey]}
        selected={form[locationKey]}
        locale={locale}
        text={locationText}
        onChange={(value) =>
          setForm({ ...form, [placeKey]: value, [locationKey]: null })
        }
        onSelect={(location) =>
          setForm({
            ...form,
            [placeKey]: location.label,
            [locationKey]: location,
          })
        }
      />
      {!partner && (
        // An explicit choice of time basis; true solar time needs a specific city (its longitude and time zone).
        <fieldset className="time-basis-choice">
          <legend>{solarChoiceText.legend[locale]}</legend>
          <label className="check-line"><input type="radio" name="time-basis" checked={form.trueSolar} onChange={() => setForm({ ...form, trueSolar: true })} /><span>{solarChoiceText.solar[locale]}</span><small>{locationText.trueSolarHint}</small></label>
          <label className="check-line"><input type="radio" name="time-basis" checked={!form.trueSolar} onChange={() => setForm({ ...form, trueSolar: false })} /><span>{solarChoiceText.clock[locale]}</span></label>
          {form.trueSolar && !isCityLevel(form[locationKey]) && <p className="field-hint time-basis-warning" role="status">{(form[locationKey] ? solarChoiceText.notCity : solarChoiceText.needCity)[locale]}</p>}
        </fieldset>
      )}
    </section>
  );
}

function StudyForm({
  route,
  form: stateForm,
  setForm,
  copy,
  onSubmit,
  error,
}: {
  route: AppRoute;
  form: FormState;
  setForm: (next: FormState) => void;
  copy: ReturnType<typeof getSuiteCopy>;
  onSubmit: () => void;
  error: string;
}) {
  const definition = routeByKey[route as keyof typeof routeByKey];
  const form = {
    ...stateForm,
    manualLines: stateForm.manualLines ?? [
      false,
      false,
      false,
      false,
      false,
      false,
    ],
  };
  const family = definition.form;
  const toolText = localToolText(copy);
  const locale = localeForCopy(copy);
  const locationText = globalLocationText(copy);
  const shared = uiCopy(locale);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [history, setHistory] = useState<Array<{ id: string; question: string; createdAt: string; response: { title?: string; summary?: string; sections?: Array<{ title: string; text: string }>; followUps?: string[] } }>>([]);
  const [historyLoaded, setHistoryLoaded] = useState(false);
  const historyLabel = ({ en: "Question history", "zh-Hans": "提问记录", "zh-Hant": "提問紀錄", ja: "質問の履歴", ko: "질문 기록", vi: "Lịch sử câu hỏi", th: "ประวัติคำถาม" } as Record<Locale, string>)[locale];
  const loadHistory = async () => {
    setHistoryOpen(true);
    if (historyLoaded) return;
    try {
      const response = await fetch("/api/member/interpretations", { credentials: "same-origin" });
      const payload = await response.json() as { interpretations?: Array<{ id: string; question: string; createdAt: string; response: { title?: string; summary?: string; sections?: Array<{ title: string; text: string }>; followUps?: string[] } }> };
      setHistory(Array.isArray(payload.interpretations) ? payload.interpretations : []);
    } catch { setHistory([]); }
    finally { setHistoryLoaded(true); }
  };
  const inquiryCategories = [
    "General",
    "Career",
    "Resources",
    "Relationship",
    "Study",
    "Movement",
    "Search",
    "Wellness",
  ];
  const relationKeys = [
    "Connection",
    "Partnership",
    "Family",
    "Work",
    "Friendship",
  ];
  const castMethods = [
    { key: "system", title: toolText.system, detail: toolText.systemDetail },
    { key: "coins", title: toolText.coins, detail: toolText.coinsDetail },
    { key: "direct", title: toolText.direct, detail: toolText.directDetail },
  ] as const;
  const coinKindIndex: Record<CoinThrow["kind"], number> = {
    "old-yin": 0,
    "young-yang": 1,
    "young-yin": 2,
    "old-yang": 3,
  };
  const inquiryLocation = (
    <GlobalLocationField
      label={toolText.questionPlace}
      value={form.place}
      selected={form.location}
      locale={locale}
      text={locationText}
      onChange={(value) => setForm({ ...form, place: value, location: null })}
      onSelect={(location) =>
        setForm({ ...form, place: location.label, location })
      }
    />
  );
  return (
    <form
      className="study-form"
      onSubmit={(event) => {
        event.preventDefault();
        onSubmit();
      }}
    >
      <header>
        <span>{shared.brandKicker}</span>
        <h2>
          {family === "birth"
            ? copy.form.birthMoment
            : family === "pair"
              ? copy.form.relationshipContext
              : family === "inquiry"
                ? copy.form.inquiryFocus
                : family === "daily"
                  ? copy.daily.title
                  : copy.form.mirror}
        </h2>
      </header>
      {family === "birth" && (
        <>
          <ProfileFields copy={copy} form={form} setForm={setForm} allowPillars={route === "bazi" || route === "detail"} />
          {route === "zeri" && (
            <div className="zeri-fields">
              <label>
                <span>{zeriCopy[locale].purpose}</span>
                <select value={form.zeriPurpose} onChange={(event) => setForm({ ...form, zeriPurpose: event.target.value as ActivityKey })}>
                  {activityKeys.map((key) => <option key={key} value={key}>{activityLabels[key][locale]}</option>)}
                </select>
              </label>
              <div className="field-row">
                <label><span>{zeriCopy[locale].from}</span><input type="date" value={form.zeriStart || todayIso()} onChange={(event) => setForm({ ...form, zeriStart: event.target.value })} /></label>
                <label><span>{zeriCopy[locale].span}</span><select value={form.zeriDays} onChange={(event) => setForm({ ...form, zeriDays: Number(event.target.value) })}>{[30, 60, 90, 120].map((days) => <option key={days} value={days}>{zeriCopy[locale].days.replace("{n}", String(days))}</option>)}</select></label>
              </div>
              <small>{zeriCopy[locale].hint}</small>
            </div>
          )}
          {route === "zhuzhai" && (
            <label>
              <span>{sittingLabel[locale]}</span>
              <select value={form.houseSitting} onChange={(event) => setForm({ ...form, houseSitting: event.target.value })}>
                {DIRECTIONS.map((direction) => <option key={direction} value={direction}>{localizeBoardTerm(direction, locale)}</option>)}
              </select>
            </label>
          )}
          <label>
            <span>{copy.form.focus}</span>
            <textarea
              value={form.focus}
              onChange={(event) =>
                setForm({ ...form, focus: event.target.value })
              }
              placeholder={copy.form.focusHint}
            />
          </label>
        </>
      )}
      {family === "pair" && (
        <>
          <div className="pair-stack">
            <ProfileFields copy={copy} form={form} setForm={setForm} />
            <ProfileFields copy={copy} form={form} setForm={setForm} partner />
          </div>
          <fieldset className="relation-fields">
            <legend>{copy.form.relation}</legend>
            {relationKeys.map((relation, index) => (
              <button
                type="button"
                className={form.relation === relation ? "active" : ""}
                onClick={() => setForm({ ...form, relation })}
                key={relation}
              >
                {toolText.relation[index]}
              </button>
            ))}
          </fieldset>
        </>
      )}
      {family === "inquiry" && (
        <>
          <fieldset className="inquiry-categories">
            <legend>{toolText.category}</legend>
            {inquiryCategories.map((category, index) => (
              <button
                type="button"
                className={form.focus === category ? "active" : ""}
                onClick={() => setForm({ ...form, focus: category })}
                key={category}
              >
                {toolText.categories[index]}
              </button>
            ))}
          </fieldset>
          <label>
            <span>{copy.form.question}<FieldHelp topic="question" locale={locale} /></span>
            <textarea
              value={form.inquiry}
              onChange={(event) =>
                setForm({ ...form, inquiry: event.target.value })
              }
              placeholder={copy.form.questionHint}
            />
          </label>
          {route === "jinkoujue" && (
            <fieldset className="difen-picker">
              <legend>{difenCopy[locale].label}</legend>
              <small>{difenCopy[locale].hint}</small>
              <div>
                <button type="button" className={!form.difen ? "active" : ""} onClick={() => setForm({ ...form, difen: "" })}>{difenCopy[locale].hour}</button>
                {DIFEN_BRANCHES.map((branch, index) => (
                  <button type="button" key={branch} className={form.difen === branch ? "active" : ""} onClick={() => setForm({ ...form, difen: branch })}>
                    {localizeBoardTerm(branch, locale)}<small>{localizeBoardTerm(DIFEN_DIRECTION[index], locale)}</small>
                  </button>
                ))}
              </div>
            </fieldset>
          )}
          {route === "meihua" && (
            <fieldset className="meihua-method">
              <legend>{meihuaCopy[locale].method}</legend>
              {(["time", "numbers", "text"] as const).map((method) => <label key={method} className="check-line"><input type="radio" name="meihua-method" checked={form.meihuaMethod === method} onChange={() => setForm({ ...form, meihuaMethod: method })} /><span>{meihuaCopy[locale][method]}</span></label>)}
              {form.meihuaMethod === "numbers" && <div className="field-row">
                {[0, 1].map((index) => <label key={index}><span>{meihuaCopy[locale].number} {index + 1}</span><input type="number" min={1} max={9999} inputMode="numeric" value={form.meihuaNumbers[index]} onChange={(event) => { const next = [...form.meihuaNumbers] as [string, string]; next[index] = event.target.value; setForm({ ...form, meihuaNumbers: next }); }} /></label>)}
              </div>}
              {form.meihuaMethod === "text" && <small>{meihuaCopy[locale].textHint}</small>}
            </fieldset>
          )}
          {route === "liuyao" && (
            <>
              <fieldset className="cast-methods">
                <legend>{toolText.casting}</legend>
                {castMethods.map((method) => (
                  <button
                    type="button"
                    className={form.castMethod === method.key ? "active" : ""}
                    onClick={() => setForm({ ...form, castMethod: method.key })}
                    key={method.key}
                  >
                    <b>{method.title}</b>
                    <small>{method.detail}</small>
                  </button>
                ))}
              </fieldset>
              {form.castMethod === "coins" && (
                <section
                  className="coin-casting-panel"
                  data-testid="liuyao-three-coin-cast"
                >
                  <p className="coin-casting-progress" aria-live="polite">
                    {form.coinThrows.length === 6
                      ? toolText.coinReady
                      : toolText.coinProgress.replace(
                          "{current}",
                          String(form.coinThrows.length + 1),
                        )}
                  </p>
                  <div className="coin-casting-throws">
                    {form.coinThrows.map((entry, index) => (
                      <article key={`${entry.total}-${index}`}>
                        <span>{toolText.line} {index + 1}</span>
                        <div aria-hidden="true">
                          {entry.coins.map((coin, coinIndex) => (
                            <i
                              className={coin === "heads" ? "heads" : "tails"}
                              key={coinIndex}
                            >
                              {coin === "heads" ? "●" : "○"}
                            </i>
                          ))}
                        </div>
                        <b>{entry.total} · {toolText.coinKinds[coinKindIndex[entry.kind]]}</b>
                      </article>
                    ))}
                  </div>
                  <p className="coin-casting-hint">{toolText.coinHint}</p>
                  <div className="coin-casting-actions">
                    <button
                      type="button"
                      className="coin-toss-action"
                      disabled={form.coinThrows.length === 6}
                      onClick={() =>
                        setForm({
                          ...form,
                          coinThrows: [...form.coinThrows, throwThreeCoins()],
                        })
                      }
                    >
                      {form.coinThrows.length === 6
                        ? toolText.coinReady
                        : toolText.coinAction}
                    </button>
                    {form.coinThrows.length > 0 && (
                      <button
                        type="button"
                        className="coin-reset-action"
                        onClick={() => setForm({ ...form, coinThrows: [] })}
                      >
                        {toolText.coinRestart}
                      </button>
                    )}
                  </div>
                </section>
              )}
              {form.castMethod === "direct" && (
                <div className="manual-lines">
                  {form.manualLines.map((line, index) => ({ line, index })).reverse().map(({ line, index }) => (
                    <button
                      type="button"
                      className={line ? "active" : ""}
                      onClick={() =>
                        setForm({
                          ...form,
                          manualLines: form.manualLines.map(
                            (value, lineIndex) =>
                              lineIndex === index ? !value : value,
                          ),
                        })
                      }
                      key={index}
                    >
                      <span>
                        {toolText.line} {index + 1}
                      </span>
                      <b>
                        {line ? `${toolText.yang} —` : `${toolText.yin} – –`}
                      </b>
                    </button>
                  ))}
                </div>
              )}
            </>
          )}
          <label className="check-line">
            <input
              type="checkbox"
              checked={form.useNow}
              onChange={(event) =>
                setForm({ ...form, useNow: event.target.checked })
              }
            />
            <span>{copy.form.useNow}</span>
            <small>{toolText.current}</small>
          </label>
          <div className="field-row">
            <label>
              <span>{copy.form.date}</span>
              <input
                type="date"
                value={form.date}
                disabled={form.useNow}
                onInput={(event) =>
                  setForm({ ...form, date: event.currentTarget.value })
                }
                onChange={(event) =>
                  setForm({ ...form, date: event.target.value })
                }
              />
            </label>
            <label>
              <span>{copy.form.time}</span>
              <input
                type="time"
                value={form.time}
                disabled={form.useNow}
                onInput={(event) =>
                  setForm({ ...form, time: event.currentTarget.value })
                }
                onChange={(event) =>
                  setForm({ ...form, time: event.target.value })
                }
              />
            </label>
          </div>
          {inquiryLocation}
        </>
      )}
      {family === "mirror" && (
        <>
          <label>
            <span>{copy.form.focus}</span>
            <textarea
              value={form.focus}
              onChange={(event) =>
                setForm({ ...form, focus: event.target.value })
              }
              placeholder={copy.form.focusHint}
            />
          </label>
          <label>
            <span>{copy.form.question}<FieldHelp topic="question" locale={locale} /></span>
            <textarea
              value={form.inquiry}
              onChange={(event) =>
                setForm({ ...form, inquiry: event.target.value })
              }
              placeholder={copy.form.questionHint}
            />
          </label>
        </>
      )}
      {family === "daily" && (
        <>
          <div className="field-row">
            <label>
              <span>{copy.daily.date}</span>
              <input
                type="date"
                value={form.dailyDate || todayIso()}
                onInput={(event) =>
                  setForm({ ...form, dailyDate: event.currentTarget.value })
                }
                onChange={(event) =>
                  setForm({ ...form, dailyDate: event.target.value })
                }
              />
            </label>
            <label>
              <span>{dailyTimeLabel[locale]}</span>
              <input
                type="time"
                value={form.time}
                onInput={(event) =>
                  setForm({ ...form, time: event.currentTarget.value })
                }
                onChange={(event) =>
                  setForm({ ...form, time: event.target.value })
                }
              />
            </label>
          </div>
          {inquiryLocation}
          <label>
            <span>{copy.form.focus}</span>
            <textarea
              value={form.focus}
              onChange={(event) =>
                setForm({ ...form, focus: event.target.value })
              }
              placeholder={copy.form.focusHint}
            />
          </label>
        </>
      )}
      <details>
        <summary>
          {copy.form.advanced}
          <b>+</b>
        </summary>
        {family === "inquiry" || family === "mirror" ? (
          <label className="check-line">
            <input
              type="checkbox"
              checked={form.trueSolar}
              onChange={(event) =>
                setForm({ ...form, trueSolar: event.target.checked })
              }
            />
            <span>{locationText.trueSolar}</span>
            <small>{locationText.trueSolarHint}</small>
          </label>
        ) : (
          <div className="school-options">
            <p className="school-hint">{schoolCopy[locale].hint}</p>
            <label><span>{schoolCopy[locale].ziHour}</span><select value={form.ziHour} onChange={(event) => setForm({ ...form, ziHour: event.target.value as FormState["ziHour"] })}><option value="late">{schoolCopy[locale].late}</option><option value="early">{schoolCopy[locale].early}</option></select></label>
            <label><span>{schoolCopy[locale].luck}</span><select value={form.luckPrecision} onChange={(event) => setForm({ ...form, luckPrecision: event.target.value as FormState["luckPrecision"] })}><option value="days">{schoolCopy[locale].days}</option><option value="minutes">{schoolCopy[locale].minutes}</option></select></label>
            {route === "ziwei" && <>
              <label><span>{schoolCopy[locale].leap}</span><select value={form.ziweiLeap} onChange={(event) => setForm({ ...form, ziweiLeap: event.target.value as FormState["ziweiLeap"] })}><option value="split">{schoolCopy[locale].split}</option><option value="current">{schoolCopy[locale].current}</option><option value="next">{schoolCopy[locale].next}</option></select></label>
              <label><span>{schoolCopy[locale].transform}</span><select value={form.ziweiTransform} onChange={(event) => setForm({ ...form, ziweiTransform: event.target.value as FormState["ziweiTransform"] })}><option value="classic">{schoolCopy[locale].classic}</option><option value="alt">{schoolCopy[locale].alt}</option></select></label>
            </>}
          </div>
        )}
        <button type="button" className="text-action forget-profile" onClick={() => { try { window.localStorage.removeItem(profileKey); } catch { /* storage unavailable */ } setForm({ ...form, ...pickProfile(defaultForm) }); }}>{forgetProfileLabel[locale]}</button>
      </details>
      {error && <p className="form-error">{error}</p>}
      {(family === "birth" || family === "pair") && form.timeUnknown && HOUR_REQUIRED_ROUTES.has(route) && <p className="form-error" role="alert">{birthTimeText.required[locale]} <a className="text-action" href={`${pathFor(locale, "toolkit")}?tool=time`}>{birthTimeText.finder[locale]} →</a></p>}
      <button className="primary-action form-submit" type="submit" disabled={(family === "birth" || family === "pair") && form.timeUnknown && HOUR_REQUIRED_ROUTES.has(route)}>
        {(family === "birth" || family === "pair") && form.exampleBirth ? birthTimeText.tryExample[locale] : copy.form.generate}
        <b>↗</b>
      </button>
      <button className="text-action" type="button" onClick={() => void loadHistory()}>
        {historyLabel}
        <b>↗</b>
      </button>
      {historyOpen && <section className="form-history" aria-label={historyLabel}>
        <b>{historyLabel}</b>
        {history.length ? history.map((item) => <article key={item.id}><small>{new Date(item.createdAt).toLocaleString(locale)}</small><p><span>{historyText[locale].question}</span>{item.question}</p><details><summary>{historyText[locale].view}</summary><h3>{item.response.title}</h3><p>{item.response.summary}</p>{item.response.sections?.map((section) => <section key={section.title}><b>{section.title}</b><p>{section.text}</p></section>)}{item.response.followUps?.length ? <footer>{item.response.followUps.map((followUp) => <span key={followUp}>{followUp}</span>)}</footer> : null}</details></article>) : <p>{historyText[locale].empty}</p>}
      </section>}
    </form>
  );
}

const menuCloseLabel: Record<Locale, string> = { en: "Close", "zh-Hans": "关闭", "zh-Hant": "關閉", ja: "閉じる", ko: "닫기", vi: "Đóng", th: "ปิด" };

/** Design-canvas background: faint stars, one constellation line and three layers of distant mountains. */
function HeroSky() {
  const stars: Array<[number, number, number, number]> = [[62, 88, 1.2, .5], [148, 212, .8, .35], [236, 52, 1, .4], [318, 160, .7, .3], [402, 34, 1.4, .55], [470, 118, .8, .3], [556, 62, 1, .45], [612, 190, .7, .25], [690, 40, 1.1, .4], [760, 132, .8, .3], [842, 72, 1.3, .5], [1310, 58, 1, .45], [1392, 170, 1.2, .4], [1360, 420, .8, .3], [96, 380, .9, .3], [40, 520, 1.1, .35], [210, 470, .7, .25], [520, 300, .7, .2]];
  return <svg className="hero-sky" viewBox="0 0 1440 820" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false">
    <g fill="#ECE6D8">{stars.map(([cx, cy, r, opacity]) => <circle key={`${cx}-${cy}`} cx={cx} cy={cy} r={r} opacity={opacity} />)}</g>
    <path d="M402 34 470 118 556 62 690 40 760 132 842 72" stroke="#D4B06A" strokeWidth=".6" opacity=".35" fill="none" />
    <g fill="#D4B06A" opacity=".7"><circle cx="402" cy="34" r="1.8" /><circle cx="556" cy="62" r="1.6" /><circle cx="842" cy="72" r="1.8" /></g>
    <path d="M0 700 L120 640 L230 676 L360 610 L470 664 L600 600 L720 650 L860 596 L980 652 L1110 606 L1240 660 L1360 620 L1440 646 L1440 820 L0 820 Z" fill="#14161B" opacity=".55" />
    <path d="M0 740 L150 690 L300 724 L420 680 L560 730 L700 684 L840 728 L990 690 L1130 736 L1270 694 L1440 722 L1440 820 L0 820 Z" fill="#101116" opacity=".75" />
    <path d="M0 780 L180 748 L360 772 L540 744 L720 776 L900 746 L1080 774 L1260 750 L1440 770 L1440 820 L0 820 Z" fill="#0D0E12" />
  </svg>;
}

function HomeScreen({
  copy,
  locale,
  navigate,
  form,
  setForm,
}: {
  copy: ReturnType<typeof getSuiteCopy>;
  locale: Locale;
  navigate: (route: AppRoute) => void;
  form: FormState;
  setForm: (next: FormState) => void;
}) {
  const [showAllMethods, setShowAllMethods] = useState(false);
  const hiddenRoutes = useHiddenRoutes();
  const methodCount = useStudyMethodCount();
  const homeText = homeCopy[locale];
  const renderCard = (card: { route: AppRoute; mark: string; visual: StudyVisualKind }) => (
    <button
      type="button"
      className={`method-card ${card.visual}`}
      onClick={() => navigate(card.route)}
      key={card.route}
    >
      <i>{localizedMark(card.mark, locale)}</i>
      <strong>{titleForRoute(card.route, locale)}</strong>
      <span>
        {methodPitch(card.route, locale) ?? (card.route in routeByKey
          ? localizedLead(
              routeByKey[card.route as keyof typeof routeByKey].form,
              copy,
            )
          : copy.routes[card.route])}
      </span>
      <b>
        {card.route === "toolkit" || card.route === "daily" || card.route === "almanac"
          ? copy.catalogue.free
          : copy.catalogue.local}
      </b>
    </button>
  );
  return (
    <>
      <section className="hero" aria-labelledby="hero-title">
        <div className="hero-image" aria-hidden="true" />
        <HeroSky />
        <HeroMotion />
        {localizedFloatingMarks(locale).map((mark, index) => (
          <span
            className="floating-mark"
            aria-hidden="true"
            key={`${mark}-${index}`}
            style={{
              left: `${((index * 31) % 91) + 4}%`,
              top: `${((index * 47) % 88) + 5}%`,
            }}
          >
            {mark}
          </span>
        ))}
        <div className="hero-copy">
          <p>{homeText.eyebrow}</p>
          <h1 id="hero-title">{homeText.headline}</h1>
          <p className="hero-description">{trustText.heroLead[locale]}</p>
          <ul className="hero-stats">
            <li><b>{methodCount}</b><span>{trustText.statMethods[locale]}</span></li>
            <li><b>23</b><span>{trustText.statClassics[locale]}</span></li>
            <li><b>7</b><span>{trustText.statLanguages[locale]}</span></li>
          </ul>
          <div className="hero-trust-notes" aria-label={homeText.free}>
            <span>✓ {homeText.choose}</span><span>✓ {homeText.free}</span><span>✓ {homeText.ask}</span>
          </div>
          <button type="button" className="hero-promo" onClick={() => navigate("bazi")}>★ {trustText.promo[locale]} →</button>
        </div>
        <form className="hero-start-panel" onSubmit={(event) => { event.preventDefault(); navigate("bazi"); }}>
          <h2>{homeSectionText.heroPanel[locale]}</h2>
          <div className="hero-start-fields">
            <label><span>{copy.form.date}</span><input type="date" value={form.calendar === "solar" ? form.date : convertCalendar(form.date, form.time, form.calendar, "solar", form.leapMonth).date} onChange={(event) => setForm({ ...form, date: event.target.value, calendar: "solar", leapMonth: false })} /></label>
            <label><span>{copy.form.time}<FieldHelp topic="time" locale={locale} /></span><input type="time" value={form.timeUnknown ? "" : form.time} disabled={form.timeUnknown} onChange={(event) => setForm({ ...form, time: event.target.value })} /></label>
          </div>
          <label className="check-line time-unknown-line"><input type="checkbox" checked={form.timeUnknown} onChange={(event) => setForm({ ...form, timeUnknown: event.target.checked })} /><span>{birthTimeText.unknown[locale]}</span></label>
          {form.exampleBirth && <p className="field-hint example-birth-note"><b className="example-chip">{birthTimeText.example[locale]}</b>{birthTimeText.exampleNote[locale]}</p>}
          <div className="hero-gender" aria-label={copy.form.gender}>
            <span>{copy.form.gender}</span>
            {(["yang", "yin"] as const).map((gender) => <button type="button" key={gender} className={form.gender === gender ? "active" : ""} onClick={() => setForm({ ...form, gender })}>{gender === "yang" ? copy.form.yang : copy.form.yin}</button>)}
          </div>
          <button className="primary-action" type="submit">{homeText.freeChart}<b>→</b></button>
        </form>
      </section>
      <DailyCards locale={locale} profileBirth={form.exampleBirth ? null : solarBirthIso(form.date, form.calendar, form.leapMonth)}
        onBirth={(date) => setForm({ ...form, date, calendar: "solar", leapMonth: false, exampleBirth: false })} />
      <HomeFlashStrip locale={locale} />
      <HomeGoalEntry locale={locale} navigate={(route) => navigate(route as AppRoute)} />
      <section className={`catalogue home-catalogue${showAllMethods ? " is-open" : ""}`} aria-labelledby="catalogue-title">
        <header>
          <p>{copy.catalogue.eyebrow}</p>
          <h2 id="catalogue-title">{homeSectionText.catalogueTitle[locale].replace("{n}", String(methodCount))}</h2>
          <button type="button" className="catalogue-more" onClick={() => setShowAllMethods((value) => !value)} aria-expanded={showAllMethods}>{showAllMethods ? homeText.showLess : homeText.viewAll.replace("{n}", String(methodCount))} <b>{showAllMethods ? "↑" : "↓"}</b></button>
        </header>
        {!showAllMethods && <div className="catalogue-grid home-six">{(["bazi", "ziwei", "compatibility", "liuyao", "qimen", "daily"] as AppRoute[]).filter((route) => !hiddenRoutes.includes(route)).map((route) => renderCard({ route, mark: routeByKey[route as keyof typeof routeByKey].mark, visual: routeByKey[route as keyof typeof routeByKey].visual }))}</div>}
        {showAllMethods && <div className="catalogue-categories">
          {methodCategories.map((category) => (
            <div className="catalogue-category" key={category.key}>
              <header><h3>{category.title[locale]}</h3><p>{category.lead[locale]}</p></header>
              <div className="catalogue-grid expanded">
                {category.routes.filter((route) => !hiddenRoutes.includes(route)).map((route) => renderCard({ route, mark: routeByKey[route as keyof typeof routeByKey]?.mark ?? (route === "xiangshu" ? "相" : route === "cezi" ? "字" : "历"), visual: routeByKey[route as keyof typeof routeByKey]?.visual ?? ("daily" as StudyVisualKind) }))}
              </div>
            </div>
          ))}
          <div className="catalogue-category">
            <header><h3>{copy.routes.toolkit}</h3><p>{copy.toolkit.lead}</p></header>
            <div className="catalogue-grid expanded">{renderCard({ route: "toolkit", mark: "宝", visual: "spread" as StudyVisualKind })}</div>
          </div>
        </div>}
      </section>
      <StudyHall3D locale={locale} navigate={(route) => navigate(route as AppRoute)} />
      <section className="home-sample" aria-labelledby="home-sample-title">
        <header><p>{homeSectionText.sampleEyebrow[locale]}</p><h2 id="home-sample-title">{homeSectionText.sampleTitle[locale]}</h2><span>{homeSectionText.sampleLead[locale]}</span></header>
        <SampleReportTeaser locale={locale} onTry={() => navigate("bazi")} />
      </section>
      <section className="home-pricing" aria-labelledby="home-pricing-title">
        <header><p>{homeSectionText.pricingEyebrow[locale]}</p><h2 id="home-pricing-title">{homeSectionText.pricingTitle[locale]}</h2></header>
        <BenefitsTable locale={locale} heading={false} />
        <CreditPriceList locale={locale} />
        <div className="home-pricing-actions"><button type="button" className="primary-action" onClick={() => navigate("bazi")}>{homeText.freeChart}<b>→</b></button><button type="button" className="secondary-action" onClick={() => navigate("membership")}>{homeSectionText.buy[locale]}<b>↗</b></button></div>
      </section>
      <HomeLectureHall locale={locale} onAll={() => navigate("courses")} onSignIn={() => navigate("membership")} />
      <section className="home-classroom" aria-labelledby="home-classroom-title">
        <header><div><p>{copy.nav.library}</p><h2 id="home-classroom-title">{homeText.libraryTitle}</h2></div><button type="button" onClick={() => navigate("library")}>{homeText.enter} →</button></header>
        <div className="home-course-grid">
          {classicalWorks.slice(0, 3).map((work) => (
            <button type="button" key={work.id} onClick={() => navigate("library")}>
              <span className="home-course-art book-cover" aria-hidden="true"><span className="book-spine" /><span className="book-slip"><b>{localizedLibraryTitle(work, locale)}</b></span><small>Xuannova</small></span>
              <strong>{localizedLibraryTitle(work, locale)}</strong>
              <small>{bookReadLabel[locale]}</small>
            </button>
          ))}
        </div>
      </section>
      <HomeAdvisor locale={locale} />
      <HomeCharity locale={locale} />
    </>
  );
}

function StudyScreen({
  route,
  stage: suppliedStage,
  copy,
  locale,
  form,
  setForm,
  result,
  wallet,
  onSpend,
  onOpenMembership,
  onOpenLibrary,
  onNavigate,
  isDemo = false,
  onBack,
  onGenerate,
  onStageChange: suppliedStageChange,
}: {
  onNavigate?: (route: AppRoute) => void;
  route: AppRoute;
  stage?: StudyStage;
  copy: ReturnType<typeof getSuiteCopy>;
  locale: Locale;
  form: FormState;
  setForm: (next: FormState) => void;
  result: StudyResult;
  wallet: CreditWallet;
  onSpend: (tool: string) => boolean;
  onOpenMembership: () => void;
  onOpenLibrary?: (category: LibraryCategory) => void;
  isDemo?: boolean;
  onBack: () => void;
  onGenerate: () => void;
  onStageChange?: (stage: StudyStage) => void;
}) {
  const definition = routeByKey[route as keyof typeof routeByKey];
  const [error, setError] = useState("");
  const shared = uiCopy(locale);
  const stage =
    suppliedStage ??
    (typeof window === "undefined"
      ? "input"
      : currentStage());
  const onStageChange =
    suppliedStageChange ??
    ((nextStage: StudyStage) => {
      if (nextStage === "chart") track("chart_created", { tool: route });
      // The casting animation is a passing step: replace it with the chart, so Back from the chart returns to
      // the form instead of replaying the animation (which pushed the chart again and looked like Back did nothing).
      navigateTo(route, nextStage, nextStage === "chart" && currentStage() === "ritual");
    });
  const chart = useMemo(() => {
    // Rebuild the full chart from exactly the input used for the result (same calendar mode,
    // true-solar setting, lines and companion data) so both views always agree.
    const generatedChart = createCompleteChart({ ...result.input, module: route });
    return { ...generatedChart, calendar: result.calendar };
  }, [result, route]);
  const submit = () => {
      const hasEntry =
      definition.form === "inquiry" || definition.form === "mirror"
        ? Boolean(form.inquiry.trim() || form.focus.trim())
        : definition.form === "pair"
          ? Boolean(form.date && form.partnerDate)
          : definition.form === "daily"
            ? Boolean(form.date)
            : Boolean(form.date);
    if (!hasEntry) {
      setError(definition.form === "pair" ? partnerRequired[locale] : copy.form.required);
      return;
    }
    // Birth dates up to one year ahead are allowed (expected or newborn babies); later dates are a typo.
    if ((definition.form === "birth" || definition.form === "pair") && form.calendar === "solar" && form.date > oneYearAheadIso()) {
      setError(futureBirth[locale]);
      return;
    }
    if (
      route === "liuyao" &&
      form.castMethod === "coins" &&
      form.coinThrows.length !== 6
    ) {
      setError(localToolText(copy).coinIncomplete);
      return;
    }
    setError("");
    onGenerate();
    onStageChange("ritual");
  };
  const heading = (
    <>
      <button
        type="button"
        className="back-link"
        onClick={stage === "input" ? onBack : () => onStageChange("input")}
      >
        ← {stage === "input" ? copy.form.back : shared.stage.edit}
      </button>
      <header className="route-heading">
        <p>{shared.brandKicker}</p>
        <h1>
          <span>{localizedMark(definition.mark, locale)}</span>
          {titleForRoute(route, locale)}
        </h1>
        <p>{methodPitch(route, locale) ?? localizedLead(definition.form, copy)}</p>
      </header>
    </>
  );
  if (stage === "ritual")
    return (
      <section
        className="route-screen study-screen study-stage-screen"
        data-route={route}
        data-study-stage="ritual"
      >
        {heading}
        <RitualSequence
          key={`${route}-${chart.inputSummary.version}`}
          locale={locale}
          tool={route}
          onComplete={() => onStageChange("chart")}
        />
      </section>
    );
  if (stage === "chart")
    return (
      <section
        className="route-screen study-screen study-stage-screen"
        data-route={route}
        data-study-stage="chart"
      >
        {heading}
        <div className="complete-study-result">
          {isDemo && <p className="stage-demo-note">{shared.chart.demo}</p>}
          {(definition.form === "birth" || definition.form === "pair") && <BirthBasis result={result} locale={locale} />}
          <CompleteChartBoard
            chart={chart}
            locale={locale}
            onOpenLibrary={
              onOpenLibrary
                ? () => onOpenLibrary(definition.libraryCategory)
                : undefined
            }
          />
          {LIFE_KLINE_ROUTES.has(route) && result.astro.luck && !result.astro.manualPillars && (
            <>
              {result.input.timeUnknown && <p className="field-hint">{birthTimeText.luckNote[locale]}</p>}
              <LifeKLineChart pillars={result.input.timeUnknown ? [...result.pillars.slice(0, 3), ""] : result.pillars} birthYear={Number(result.calendar.solar.slice(0, 4))} luck={result.astro.luck} locale={locale} />
            </>
          )}
          <div className="stage-actions">
            <button
              type="button"
              className="secondary-action"
              onClick={() => onStageChange("input")}
            >
              {shared.chart.backToForm}
            </button>
            <button
              type="button"
              className="primary-action"
              onClick={() => onStageChange("reading")}
            >
              {shared.chart.openReading}
              <b>↗</b>
            </button>
          </div>
        </div>
      </section>
    );
  if (stage === "reading")
    return (
      <section
        className="route-screen study-screen study-stage-screen"
        data-route={route}
        data-study-stage="reading"
      >
        {heading}
        <div className="reading-stage">
          <div className="reading-stage-reference">
            <span>{shared.chart.localChart}</span>
            <h2>{titleForRoute(route, locale)}</h2>
            <p>
              {chart.calendar.solar} · {chart.calendar.lunar}
            </p>
            <button
              type="button"
              className="secondary-action"
              onClick={() => onStageChange("chart")}
            >
              {shared.stage.backToChart}
            </button>
          </div>
          <InterpretationPanel
            autoStart
            chart={chart}
            locale={locale}
            wallet={wallet}
            onSpend={onSpend}
            onOpenMembership={onOpenMembership}
            onNavigate={(next) => onNavigate?.(next as AppRoute)}
          />
        </div>
      </section>
    );
  return (
    <section
      className="route-screen study-screen study-stage-screen"
      data-route={route}
      data-study-stage="input"
    >
      {heading}
      <MethodHelp helpKey={route} locale={localeForCopy(copy)} navigate={(next) => navigateTo(next)} />
      <div className="study-layout input-study-layout">
          <StudyForm
          route={route}
          form={form}
          setForm={setForm}
            copy={copy}
            onSubmit={submit}
            error={error}
        />
      </div>
    </section>
  );
}

function ToolkitScreen({
  stage: suppliedStage,
  copy,
  locale,
  wallet,
  onSpend,
  onOpenMembership,
  onStageChange: suppliedStageChange,
}: {
  stage?: StudyStage;
  copy: ReturnType<typeof getSuiteCopy>;
  locale: Locale;
  wallet: CreditWallet;
  onSpend: (tool: string) => boolean;
  onOpenMembership: () => void;
  onStageChange?: (stage: StudyStage) => void;
}) {
  const [active, setActive] = useState<ToolkitKey>("time");
  const [query, setQuery] = useState("");
  const [toolDate, setToolDate] = useState("1994-08-18");
  const [toolTime, setToolTime] = useState("12:00");
  const [eventDate, setEventDate] = useState("");
  const [houseSitting, setHouseSitting] = useState<string>("North");
  const [meihuaMethod, setMeihuaMethod] = useState<"time" | "numbers" | "text">("time");
  const [meihuaNumbers, setMeihuaNumbers] = useState<[string, string]>(["", ""]);
  const [toolGender, setToolGender] = useState<"yin" | "yang">("yang");
  const [result, setResult] = useState(() => makeToolkitResult("time", ""));
  const [chartVersion, setChartVersion] = useState(0);
  const workspaceRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    // Opened from the menu (or a ?tool= link): start on that tool.
    const picked = takePendingToolkitTool();
    if (!picked) return;
    const timer = window.setTimeout(() => {
      setActive(picked); setResult(makeToolkitResult(picked, "")); setChartVersion((version) => version + 1);
      window.requestAnimationFrame(() => workspaceRef.current?.scrollIntoView({ block: "start" }));
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);
  const item =
    toolkitItems.find((entry) => entry.key === active) ?? toolkitItems[0];
  const title = toolkitTitle(active, copy, locale);
  const fields = toolkitFields[active] ?? toolkitFields.elements;
  const fieldText = toolkitFieldCopy[locale] ?? toolkitFieldCopy.en;
  const needsBirthDate = fields.date !== false;
  const needsBirthMoment = fields.time;
  const effectiveDate = fields.date === "event" ? eventDate || todayIso() : fields.date === "birth" ? toolDate : todayIso();
  const effectiveTime = fields.time ? toolTime : "12:00";
  const toolInput = {
    birthDate: effectiveDate,
    birthTime: effectiveTime,
    calendar: "solar" as const,
    gender: toolGender,
    focus: fields.text === "name" ? "" : query,
    name: fields.text === "name" ? query : "",
    companionName: "",
    module: `toolkit-${active}`,
    version: chartVersion,
    ...(active === "fengshui" ? { houseSitting } : {}),
    ...(active === "meihua" && meihuaMethod === "numbers" && Number(meihuaNumbers[0]) > 0 && Number(meihuaNumbers[1]) > 0 ? { meihuaMethod, meihuaNumbers: [Number(meihuaNumbers[0]), Number(meihuaNumbers[1])] as [number, number] } : {}),
    ...(active === "meihua" && meihuaMethod === "text" && query.trim() ? { meihuaMethod, meihuaText: query } : {}),
  };
  const chart = createStudyResult(toolInput);
  const completeChart = createCompleteChart(toolInput);
  // The summary card shows facts from the computed chart (no decorative seeded words).
  const seededResult = localizeToolkitResult(result, locale);
  const focusCell = completeChart.board.cells.find((cell) => cell.active) ?? completeChart.board.cells[0];
  const localizedResult = {
    title: localizeBoardTerm(completeChart.board.label, locale),
    line: query.trim() ? query.trim() : seededResult.line,
    facets: (focusCell?.items ?? []).filter((entry) => entry.value && entry.value !== "—").slice(0, 3)
      .map((entry) => `${localizeBoardTerm(entry.label, locale)} · ${localizeBoardTerm(entry.value, locale)}`),
  };
  const chartLabels = localResultText(copy);
  const shared = uiCopy(locale);
  const stage =
    suppliedStage ??
    (typeof window === "undefined"
      ? "input"
      : currentStage());
  const onStageChange =
    suppliedStageChange ??
    ((nextStage: StudyStage) => {
      navigateTo("toolkit", nextStage, nextStage === "chart" && currentStage() === "ritual");
    });
  const submit = () => {
    setResult(
      makeToolkitResult(active, `${query}|${toolDate}|${toolTime}|${toolGender}`),
    );
    setChartVersion((version) => version + 1);
    onStageChange("ritual");
  };
  return (
    <section className="route-screen toolkit-screen" data-route="toolkit">
      <header className="route-heading">
        <p>{copy.toolkit.eyebrow}</p>
        <h1>{copy.toolkit.title}</h1>
        <p>{copy.toolkit.lead}</p>
      </header>
      {stage === "input" && (
        <>
          <div className="toolkit-categories">
          {methodCategories.filter((category) => category.tools.length).map((category) => (
          <section className="toolkit-category" key={category.key}>
            <header><h2>{category.title[locale]}</h2><p>{category.lead[locale]}</p></header>
          <div className="toolkit-grid">
            {category.tools.map((key) => toolkitItems.find((entry) => entry.key === key)!).map((entry) => (
              <button
                type="button"
                className={active === entry.key ? "active" : ""}
                onClick={() => {
                  setActive(entry.key);
                  setResult(makeToolkitResult(entry.key, query));
                  setChartVersion((version) => version + 1);
                  window.requestAnimationFrame(() => {
                    workspaceRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
                    workspaceRef.current?.focus({ preventScroll: true });
                  });
                }}
                key={entry.key}
              >
                <i>{localizedMark(entry.mark, locale)}</i>
                <strong>{toolkitTitle(entry.key, copy, locale)}</strong>
                <span>{toolkitDescription(entry.key, locale)}</span>
                <b className="toolkit-open-label">{copy.toolkit.open}</b>
              </button>
            ))}
          </div>
          </section>
          ))}
          </div>
          <div className="toolkit-workspace" data-study-stage="input" ref={workspaceRef} tabIndex={-1}>
            <form
              onSubmit={(event) => {
                event.preventDefault();
                submit();
              }}
            >
              <span className="toolkit-active-label" aria-live="polite">
                {item.mark} · {title}
              </span>
              <h2>{copy.toolkit.prompt}</h2>
              <MethodHelp key={active} helpKey={`toolkit-${active}`} locale={locale} navigate={(next) => navigateTo(next)} />
              {needsBirthDate && (
                <>
                  <div className="field-row">
                    <label>
                      <span>{fields.date === "event" ? (active === "dream" ? fieldText.dreamDate : fieldText.castDate) : fieldText.birthDate}</span>
                      <input
                        type="date"
                        value={fields.date === "event" ? eventDate || todayIso() : toolDate}
                        onInput={(event) =>
                          (fields.date === "event" ? setEventDate : setToolDate)(event.currentTarget.value)
                        }
                        onChange={(event) => (fields.date === "event" ? setEventDate : setToolDate)(event.target.value)}
                      />
                    </label>
                    {needsBirthMoment && <label>
                      <span>{copy.form.time}</span>
                      <input
                        type="time"
                        value={toolTime}
                        onInput={(event) => setToolTime(event.currentTarget.value)}
                        onChange={(event) => setToolTime(event.target.value)}
                      />
                    </label>}
                  </div>
                  {fields.gender && <label className="toolkit-gender-field">
                    <span>{copy.form.gender}</span>
                    <select value={toolGender} onChange={(event) => setToolGender(event.target.value as "yin" | "yang")}>
                      <option value="yang">{copy.form.yang}</option>
                      <option value="yin">{copy.form.yin}</option>
                    </select>
                  </label>}
                </>
              )}
              {active === "fengshui" && (
                <label>
                  <span>{sittingLabel[locale]}</span>
                  <select value={houseSitting} onChange={(event) => setHouseSitting(event.target.value)}>
                    {DIRECTIONS.map((direction) => <option key={direction} value={direction}>{localizeBoardTerm(direction, locale)}</option>)}
                  </select>
                </label>
              )}
              {active === "meihua" && (
                <fieldset className="meihua-method">
                  <legend>{meihuaCopy[locale].method}</legend>
                  {(["time", "numbers", "text"] as const).map((method) => <label key={method} className="check-line"><input type="radio" name="meihua-method" checked={meihuaMethod === method} onChange={() => setMeihuaMethod(method)} /><span>{meihuaCopy[locale][method]}</span></label>)}
                  {meihuaMethod === "numbers" && <div className="field-row">
                    {[0, 1].map((index) => <label key={index}><span>{meihuaCopy[locale].number} {index + 1}</span><input type="number" min={1} max={9999} inputMode="numeric" value={meihuaNumbers[index]} onChange={(event) => { const next = [...meihuaNumbers] as [string, string]; next[index] = event.target.value; setMeihuaNumbers(next); }} /></label>)}
                  </div>}
                  {meihuaMethod === "text" && <small>{meihuaCopy[locale].textHint}</small>}
                </fieldset>
              )}
              {fields.text === "name" && (
                <label>
                  <span>{fieldText.name}</span>
                  <input type="text" value={query} onChange={(event) => setQuery(event.target.value)} placeholder={fieldText.name} />
                </label>
              )}
              {(fields.text === "dream" || fields.text === "question") && (
                <textarea
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder={fields.text === "dream" ? fieldText.dream : fieldText.question}
                  aria-label={fields.text === "dream" ? fieldText.dream : fieldText.question}
                />
              )}
              <button type="submit" className="primary-action">
                {copy.toolkit.create}
                <b>↗</b>
              </button>
            </form>
            <article>
              <small>{copy.toolkit.result}</small>
              <h2>{localizedResult.title}</h2>
              {needsBirthDate && (
                <div className="toolkit-calendar">
                  <span>
                    <b>{chartLabels.solar}</b>
                    {chart.calendar.solar}
                  </span>
                  <span>
                    <b>{chartLabels.lunar}</b>
                    {chart.calendar.lunar}
                  </span>
                  <span>
                    <b>{chartLabels.naYin}</b>
                    {chart.calendar.naYin}
                  </span>
                </div>
              )}
              <p>{localizedResult.line}</p>
              <div>
                {localizedResult.facets.map((facet, index) => (
                  <span key={facet}>
                    <b>{index + 1}</b>
                    {facet}
                  </span>
                ))}
              </div>
            </article>
          </div>
        </>
      )}
      {stage === "ritual" && (
        <div className="toolkit-complete-panel" data-study-stage="ritual">
          <RitualSequence
            key={`${active}-${chartVersion}`}
            locale={locale}
            tool={`toolkit-${active}`}
            onComplete={() => onStageChange("chart")}
          />
        </div>
      )}
      {stage === "chart" && (
        <div className="toolkit-complete-panel" data-study-stage="chart">
          <CompleteChartBoard chart={completeChart} locale={locale} />
          {active === "fengshui" && <FloorPlanFengShui cells={completeChart.board.cells} facing={completeChart.sections.find((section) => section.id === "fengshui-house")?.items.find((entry) => entry.label === "Facing")?.value ?? "South"} locale={locale} />}
          <div className="stage-actions">
            <button
              type="button"
              className="secondary-action"
              onClick={() => onStageChange("input")}
            >
              {shared.chart.backToForm}
            </button>
            <button
              type="button"
              className="primary-action"
              onClick={() => onStageChange("reading")}
            >
              {shared.chart.openReading}
              <b>↗</b>
            </button>
          </div>
        </div>
      )}
      {stage === "reading" && (
        <div className="toolkit-complete-panel" data-study-stage="reading">
          <div className="reading-stage-reference">
            <span>{shared.chart.localChart}</span>
            <h2>{title}</h2>
            <button
              type="button"
              className="secondary-action"
              onClick={() => onStageChange("chart")}
            >
              {shared.stage.backToChart}
            </button>
          </div>
          <InterpretationPanel
            autoStart
            chart={completeChart}
            locale={locale}
            wallet={wallet}
            onSpend={onSpend}
            onOpenMembership={onOpenMembership}
          />
        </div>
      )}
    </section>
  );
}

function DailyScreen({
  copy,
  locale,
}: {
  copy: ReturnType<typeof getSuiteCopy>;
  locale?: Locale;
}) {
  const [date, setDate] = useState(() => todayIso());
  const daily = makeDailyResult(date);
  const resolvedLocale =
    locale ??
    ({
      Language: "en",
      语言: "zh-Hans",
      語言: "zh-Hant",
      言語: "ja",
      언어: "ko",
      "Ngôn ngữ": "vi",
      ภาษา: "th",
    }[copy.nav.language] as Locale | undefined) ??
    "en";
  return (
    <section className="route-screen daily-screen" data-route="daily">
      <header className="route-heading">
        <p>{copy.daily.eyebrow}</p>
        <h1>{copy.daily.title}</h1>
        <p>{copy.daily.lead}</p>
      </header>
      <div className="daily-layout">
        <label>
          <span>{copy.daily.date}</span>
          <input
            type="date"
            value={date}
            onChange={(event) => setDate(event.target.value)}
          />
        </label>
        <article>
          <small>{copy.daily.seasonal}</small>
          <h2>{localizeDailyNote(daily.note, resolvedLocale)}</h2>
          <div className="time-window">
            {daily.windows.map((level, index) => (
              <span key={index} style={{ height: `${level * 17 + 18}px` }}>
                <i>{String(index + 1).padStart(2, "0")}</i>
              </span>
            ))}
          </div>
          <div className="daily-foot">
            <b>{copy.daily.timeWindows}</b>
            <p>
              {copy.daily.personalNote}:{" "}
              {localizeDailyNote(
                "Make room for a small act of restoration.",
                resolvedLocale,
              )}
            </p>
          </div>
        </article>
      </div>
      <MonthlyOutlook locale={locale ?? "en"} onMakeChart={() => { window.location.href = pathFor(locale ?? "en", "bazi"); }} />
    </section>
  );
}

function localizeLibraryArticle(
  article: (typeof libraryArticles)[number],
  locale: Locale,
  copy: ReturnType<typeof getSuiteCopy>,
) {
  if (locale === "en")
    return {
      title: article.title,
      summary: article.summary,
      body: article.body,
      note: "This original note is for cultural study. Read its chart details and relationships with openness and care.",
    };
  const category = copy.library[
    article.category as keyof typeof copy.library
  ] as string;
  const entries: Record<
    Exclude<Locale, "en">,
    { summary: string; body: string; note: string; suffix: string }
  > = {
    "zh-Hans": {
      summary: "一则用于东方传统文化研习的简明笔记。",
      body: "这则笔记以盘面关系与日常觉察为线索，邀请你放慢判断、观察处境，并把有用的提示转化为自主的下一步。",
      note: "这是一则为文化研习编写的知识笔记：请以开放、清醒的态度阅读其中的盘面信息与关系。",
      suffix: "研习笔记",
    },
    "zh-Hant": {
      summary: "一則用於東方傳統文化研習的簡明筆記。",
      body: "這則筆記以盤面關係與日常覺察為線索，邀請你放慢判斷、觀察處境，並把有用的提示轉化為自主的下一步。",
      note: "這是一則為文化研習編寫的知識筆記：請以開放、清醒的態度閱讀其中的盤面資訊與關係。",
      suffix: "研習筆記",
    },
    ja: {
      summary: "東洋の伝統文化を学ぶための、簡潔なノートです。",
      body: "このノートは盤面の関係と日々の気づきを手がかりにします。判断を急がず状況を見つめ、有用な示唆を自分で選ぶ次の一歩へつなげてください。",
      note: "これは文化学習のために書かれたノートです。盤面の情報と関係を、開かれた落ち着いた姿勢で読んでください。",
      suffix: "学習ノート",
    },
    ko: {
      summary: "동양 전통문화를 학습하기 위한 간결한 노트입니다.",
      body: "이 노트는 판면 관계와 일상의 알아차림을 실마리로 삼습니다. 판단을 서두르지 않고 상황을 살핀 뒤, 유용한 단서를 스스로 선택한 다음 행동으로 이어가세요.",
      note: "이 글은 문화 학습을 위해 작성한 지식 노트입니다. 판면 정보와 관계를 열린 마음과 맑은 태도로 읽어 주세요.",
      suffix: "학습 노트",
    },
    vi: {
      summary:
        "Ghi chú ngắn gọn dành cho việc học văn hóa truyền thống phương Đông.",
      body: "Ghi chú này dùng các mối liên hệ trên bàn cục và sự nhận biết hằng ngày làm điểm tựa. Hãy chậm lại, quan sát hoàn cảnh và chuyển gợi ý hữu ích thành bước đi tiếp theo do chính bạn lựa chọn.",
      note: "Đây là ghi chú kiến thức dành cho học tập văn hóa. Hãy đọc dữ kiện bàn cục và các mối liên hệ với tinh thần cởi mở, tỉnh táo.",
      suffix: "ghi chú học tập",
    },
    th: {
      summary: "บันทึกย่อสำหรับการศึกษาวัฒนธรรมดั้งเดิมของตะวันออก",
      body: "บันทึกนี้ใช้ความสัมพันธ์บนผังและการตระหนักรู้ในชีวิตประจำวันเป็นจุดตั้งต้น ค่อย ๆ สังเกตสถานการณ์ แล้วเปลี่ยนข้อชวนคิดที่เป็นประโยชน์ให้เป็นก้าวต่อไปที่คุณเลือกเอง",
      note: "นี่คือบันทึกความรู้สำหรับการศึกษาวัฒนธรรม โปรดอ่านข้อมูลบนผังและความสัมพันธ์ด้วยใจที่เปิดกว้างและมีสติ",
      suffix: "บันทึกการศึกษา",
    },
  };
  const entry = entries[locale];
  return {
    title: locale.startsWith("zh")
      ? article.chineseTitle
      : `${category} · ${entry.suffix}`,
    summary: entry.summary,
    body: entry.body,
    note: entry.note,
  };
}

// Retained only as a compatibility fallback for an already-persisted pre-archive client state.
// eslint-disable-next-line @typescript-eslint/no-unused-vars
function LegacyLibraryScreen({
  copy,
  locale,
}: {
  copy: ReturnType<typeof getSuiteCopy>;
  locale: Locale;
}) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [selected, setSelected] = useState("");
  const filtered = useMemo(
    () =>
      libraryArticles.filter(
        (article) =>
          (category === "all" || article.category === category) &&
          `${article.title} ${article.chineseTitle} ${article.summary}`
            .toLowerCase()
            .includes(query.toLowerCase()),
      ),
    [category, query],
  );
  const active = libraryArticles.find((article) => article.id === selected);
  const categoryLabels: Array<[string, string]> = [
    ["all", copy.library.all],
    ["foundation", copy.library.foundation],
    ["bazi", copy.library.bazi],
    ["liuyao", copy.library.liuyao],
    ["ziwei", copy.library.ziwei],
    ["qimen", copy.library.qimen],
    ["qizheng", copy.library.qizheng],
  ];
  const activeEntry = active
    ? localizeLibraryArticle(active, locale, copy)
    : null;
  if (locale in suiteCopy)
    return (
      <section className="route-screen library-screen" data-route="library">
        <header className="route-heading">
          <p>{copy.library.eyebrow}</p>
          <h1>{copy.library.title}</h1>
          <p>{copy.library.lead}</p>
        </header>
        <div className="library-toolbar">
          <input
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={copy.library.search}
            aria-label={copy.library.search}
          />
          <div>
            {categoryLabels.map(([key, label]) => (
              <button
                type="button"
                key={key}
                className={category === key ? "active" : ""}
                onClick={() => setCategory(key)}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
        {activeEntry ? (
          <article className="article-detail">
            <button type="button" onClick={() => setSelected("")}>
              ← {copy.library.close}
            </button>
            <small>
              {copy.library[active?.category as keyof typeof copy.library] ??
                copy.library.all}
            </small>
            <h2>{activeEntry.title}</h2>
            <p>{activeEntry.note}</p>
            <p>{activeEntry.body}</p>
          </article>
        ) : (
          <div className="article-grid">
            {filtered.length ? (
              filtered.map((article) => {
                const entry = localizeLibraryArticle(article, locale, copy);
                return (
                  <article key={article.id}>
                    <small>
                      {copy.library[
                        article.category as keyof typeof copy.library
                      ] ?? copy.library.all}
                    </small>
                    <h2>{entry.title}</h2>
                    <p>{entry.summary}</p>
                    <button
                      type="button"
                      onClick={() => setSelected(article.id)}
                    >
                      {copy.library.read} →
                    </button>
                  </article>
                );
              })
            ) : (
              <p className="empty-state">{copy.library.noResults}</p>
            )}
          </div>
        )}
      </section>
    );
  return (
    <section className="route-screen library-screen" data-route="library">
      <header className="route-heading">
        <p>{copy.library.eyebrow}</p>
        <h1>{copy.library.title}</h1>
        <p>{copy.library.lead}</p>
      </header>
      <div className="library-toolbar">
        <input
          type="search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder={copy.library.search}
          aria-label={copy.library.search}
        />
        <div>
          {categoryLabels.map(([key, label]) => (
            <button
              type="button"
              key={key}
              className={category === key ? "active" : ""}
              onClick={() => setCategory(key)}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
      {active ? (
        <article className="article-detail">
          <button type="button" onClick={() => setSelected("")}>
            ← {copy.library.close}
          </button>
          <small>
            {copy.library[active.category as keyof typeof copy.library] ??
              copy.library.all}
          </small>
          <h2>
            {locale.startsWith("zh") ? active.chineseTitle : active.title}
          </h2>
          {locale.startsWith("zh") && (
            <p>
              这是一则为文化研习编写的知识笔记：请以开放、清醒的态度阅读其中的盘面信息与关系。
            </p>
          )}
          <p>{active.body}</p>
        </article>
      ) : (
        <div className="article-grid">
          {filtered.length ? (
            filtered.map((article) => (
              <article key={article.id}>
                <small>
                  {copy.library[
                    article.category as keyof typeof copy.library
                  ] ?? copy.library.all}
                </small>
                <h2>
                  {locale.startsWith("zh")
                    ? article.chineseTitle
                    : article.title}
                </h2>
                <p>{article.summary}</p>
                <button type="button" onClick={() => setSelected(article.id)}>
                  {copy.library.read} →
                </button>
              </article>
            ))
          ) : (
            <p className="empty-state">{copy.library.noResults}</p>
          )}
        </div>
      )}
    </section>
  );
}

function LibraryScreen({
  locale,
  initialCategory = "all",
}: {
  locale: Locale;
  copy?: ReturnType<typeof getSuiteCopy>;
  initialCategory?: LibraryCategory | "all";
}) {
  return (
    <LibraryExplorer
      key={initialCategory}
      locale={locale}
      initialCategory={initialCategory}
    />
  );
}

function MembershipScreen({
  copy,
  active = true,
}: {
  copy: ReturnType<typeof getSuiteCopy>;
  active?: boolean;
}) {
  const locale = (Object.entries(suiteCopy).find(
    ([, value]) => value === copy,
  )?.[0] ?? "en") as Locale;
  return (
    <section className="route-screen membership-screen" data-route="membership">
      <MemberCommerceCenter locale={locale} mode="center" active={active} onBuyCredits={() => { navigateTo("credits"); window.scrollTo({ top: 0, behavior: "instant" }); }} />
    </section>
  );
}

function CreditsScreen({
  locale,
  copy,
}: {
  locale: Locale;
  copy: ReturnType<typeof getSuiteCopy>;
}) {
  return (
    <section className="route-screen credits-screen" data-route="credits">
      <header className="route-heading">
        <p>{copy.nav.credits}</p>
        <h1>{copy.routes.credits}</h1>
      </header>
      <MemberCommerceCenter locale={locale} mode="store" />
    </section>
  );
}

export default function Home({ initialLocale, initialRoute, initialFlash }: { initialLocale?: Locale; initialRoute?: AppRoute; initialFlash?: FlashItem | null } = {}) {
  const [locale, setLocale] = useState<Locale>(initialLocale ?? "en");
  const memberSignedIn = useMemberSignedIn();
  const [theme, setTheme] = useState<ThemeKey>("nocturne");
  const [route, setRoute] = useState<AppRoute>(initialRoute ?? "home");
  const [homeVisited, setHomeVisited] = useState(false);
  useEffect(() => { if (route === "home") setHomeVisited(true); }, [route]);
  // 「我的」 opens instantly: the account page is prepared in the background once the site is idle, then kept.
  const [memberWarm, setMemberWarm] = useState(false);
  useEffect(() => {
    if (route === "membership") { setMemberWarm(true); return; }
    if (memberWarm) return;
    const win = window as Window & { requestIdleCallback?: (cb: () => void, opts?: { timeout: number }) => number; cancelIdleCallback?: (id: number) => void };
    const start = window.setTimeout(() => {
      if (win.requestIdleCallback) win.requestIdleCallback(() => setMemberWarm(true), { timeout: 4000 }); else setMemberWarm(true);
    }, 2500);
    return () => window.clearTimeout(start);
  }, [route, memberWarm]);
  useEffect(() => { setHallRoute(route); }, [route]);
  const [stage, setStage] = useState<StudyStage>("input");
  const [methodOpen, setMethodOpen] = useState(false);
  useEffect(() => {
    if (!methodOpen) return;
    const close = (event: Event) => {
      if (event instanceof KeyboardEvent) { if (event.key === "Escape") setMethodOpen(false); return; }
      if (!(event.target as Element | null)?.closest?.(".method-menu")) setMethodOpen(false);
    };
    document.addEventListener("pointerdown", close);
    document.addEventListener("keydown", close);
    return () => { document.removeEventListener("pointerdown", close); document.removeEventListener("keydown", close); };
  }, [methodOpen]);
  const [mobileOpen, setMobileOpen] = useState(false);
  useEffect(() => {
    if (!mobileOpen) return;
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") setMobileOpen(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [mobileOpen]);
  const [form, setForm] = useState<FormState>(defaultForm);
  // The example birthday stops being "the example" as soon as the visitor changes any birth detail.
  useEffect(() => {
    if (form.exampleBirth && (form.date !== EXAMPLE_BIRTH.date || form.time !== EXAMPLE_BIRTH.time || form.calendar !== "solar" || form.timeUnknown)) setForm((current) => ({ ...current, exampleBirth: false }));
  }, [form.exampleBirth, form.date, form.time, form.calendar, form.timeUnknown]); // eslint-disable-line react-hooks/exhaustive-deps
  // Birth details are entered once and remembered in this browser only (never sent until a chart is made).
  const profileLoaded = useRef(false);
  useEffect(() => {
    const timer = window.setTimeout(() => {
      try {
        const saved = JSON.parse(window.localStorage.getItem(profileKey) ?? "null") as Partial<FormState> | null;
        if (saved && typeof saved === "object") setForm((current) => ({ ...current, ...pickProfile(saved) }));
      } catch { /* storage unavailable or malformed */ }
      profileLoaded.current = true;
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);
  useEffect(() => {
    if (!profileLoaded.current) return;
    try { window.localStorage.setItem(profileKey, JSON.stringify(pickProfile(form))); } catch { /* storage unavailable */ }
  }, [form]);
  const [result, setResult] = useState<StudyResult>(() =>
    createStudyResult({
      birthDate: defaultForm.date,
      birthTime: defaultForm.time,
      calendar: defaultForm.calendar,
      focus: "",
      name: "",
      companionName: "",
      module: "bazi",
      version: 0,
    }),
  );
  const [version, setVersion] = useState(0);
  useEffect(() => {
    // The daily bonus resets at the member's own local midnight; the server reads this cookie.
    try {
      const zone = Intl.DateTimeFormat().resolvedOptions().timeZone;
      if (zone) document.cookie = `xn_tz=${encodeURIComponent(zone)}; path=/; max-age=31536000; SameSite=Lax`;
    } catch { /* optional */ }
  }, []);
  const [, setRecent] = useState<Array<{ title: string; stamp: string }>>(
    [],
  );
  const [wallet, setWallet] = useState<CreditWallet>(() => readCreditWallet());
  const [libraryCategory, setLibraryCategory] = useState<
    LibraryCategory | "all"
  >("all");
  const walletRef = useRef(wallet);
  const copy = getSuiteCopy(locale);
  const content = siteContent[locale];
  const shared = uiCopy(locale);

  useEffect(() => {
    // Brand rename: read the new keys first, then the old xuanyuan-* keys once.
    const read = (key: string) => { try { return window.localStorage.getItem(`xuannova-${key}`) ?? window.localStorage.getItem(`xuanyuan-${key}`); } catch { return null; } };
    const storedLocale = read("locale") as Locale | null;
    const storedTheme = read("theme") as ThemeKey | null;
    // The site restores the scroll position itself (the browser's own restore runs before the new page has rendered
    // and lands in the wrong place).
    try { window.history.scrollRestoration = "manual"; } catch { /* old browser */ }
    captureShareSource();
    // get the almanac ready in the background so the 黄历 tab opens without a stall
    const warmAlmanac = window.setTimeout(() => { prefetchScreens(); prewarmAlmanac(almanacToday()); }, 2500);
    const sync = (event?: Event) => {
      // Old links such as "/#bazi" or "/#bazi/chart" move to their real URL.
      const legacy = window.location.hash.replace(/^#/, "");
      if (legacy && !legacy.startsWith("legal-") && parseStudyLocation(window.location.hash).route !== "home") {
        const old = parseStudyLocation(window.location.hash);
        window.history.replaceState(null, "", pathFor(currentUrlLocale, old.route, old.stage));
      }
      const location = parseStudyPath(window.location.pathname);
      setRoute(location.route);
      setStage(location.stage);
      const saved = Number((window.history.state as { scrollY?: number } | null)?.scrollY ?? 0);
      if (event?.type === "popstate") restoreScroll(Number.isFinite(saved) ? saved : 0);
      else window.requestAnimationFrame(() => window.scrollTo({ top: 0, behavior: "instant" }));
    };
    const timer = window.setTimeout(() => {
      const pathLocale = parseStudyPath(window.location.pathname).locale;
      if (pathLocale && pathLocale !== "en") setLocale(pathLocale);
      else if (
        storedLocale &&
        languageOptions.some((option) => option.value === storedLocale) &&
        !pathLocale
      )
        setLocale(storedLocale);
      else if (pathLocale === "en") setLocale("en");
      else {
        // First visit (or an invalid stored value): follow the browser language, else English.
        const preferred = (navigator.languages?.length ? navigator.languages : [navigator.language]).map((tag) => tag.toLowerCase());
        const match = preferred.map((tag) => tag.startsWith("zh") ? (/(tw|hk|mo|hant)/.test(tag) ? "zh-Hant" : "zh-Hans") : tag.slice(0, 2))
          .find((tag) => languageOptions.some((option) => option.value === tag)) as Locale | undefined;
        setLocale(match ?? "en");
      }
      if (storedTheme && themes.includes(storedTheme)) setTheme(storedTheme);
      sync();
    }, 0);
    window.addEventListener("hashchange", sync);
    window.addEventListener("popstate", sync);
    window.addEventListener("xn:navigate", sync);
    return () => {
      window.clearTimeout(timer);
      window.clearTimeout(warmAlmanac);
      window.removeEventListener("hashchange", sync);
      window.removeEventListener("popstate", sync);
      window.removeEventListener("xn:navigate", sync);
    };
  }, []);

  useEffect(() => {
    // Client-side navigation does not re-run server metadata, so keep the tab title in step.
    document.title = String(metadataFor(locale, route).title ?? "Xuannova");
    initAnalytics();
    track("page_view_route", { route, locale });
  }, [route, locale]);
  useEffect(() => {
    try { window.localStorage.setItem("xuannova-locale", locale); } catch { /* storage unavailable */ }
    document.documentElement.lang = locale;
    // Keep the address bar in the chosen language so shared links open in that language.
    currentUrlLocale = locale;
    const current = parseStudyPath(window.location.pathname);
    const target = pathFor(locale, current.route, current.stage);
    if (window.location.pathname !== target) window.history.replaceState(null, "", target + window.location.hash);
  }, [locale]);
  useEffect(() => {
    try { window.localStorage.setItem("xuannova-theme", theme); } catch { /* storage unavailable */ }
  }, [theme]);
  useEffect(() => {
    document.documentElement.dataset.studyStage = stage;
  }, [stage]);
  useEffect(() => {
    walletRef.current = wallet;
  }, [wallet]);

  const navigate = (next: AppRoute) => {
    setMethodOpen(false);
    setMobileOpen(false);
    setRoute(next);
    setStage("input");
    navigateTo(next);
    window.scrollTo({ top: 0, behavior: "instant" });
  };
  const spend = (tool: string) => {
    const next = spendCredits(walletRef.current, tool);
    if (!next) return false;
    walletRef.current = next.wallet;
    setWallet(next.wallet);
    saveCreditWallet(next.wallet);
    return true;
  };
  const generate = () => {
    const nextVersion = version + 1;
    setVersion(nextVersion);
    const active = routeByKey[route as keyof typeof routeByKey];
    const browserMoment = new Date(
      Date.now() - new Date().getTimezoneOffset() * 60_000,
    ).toISOString();
    const [currentDate, currentTime] = browserMoment.split("T");
    const inquiryUsesNow = active.form === "inquiry" && form.useNow;
    const inputFocus =
      active.form === "pair"
        ? form.relation
        : active.form === "birth" || active.form === "daily"
          ? form.focus
          : form.inquiry || form.focus;
    const coinLineStates =
      route === "liuyao" && form.castMethod === "coins"
        ? lineStatesFromThrows(form.coinThrows)
        : undefined;
    const isDaily = active.form === "daily";
    const input: StudyInput = {
      birthDate: inquiryUsesNow ? currentDate : isDaily ? form.dailyDate || todayIso() : form.date,
      birthTime: inquiryUsesNow ? currentTime.slice(0, 5) : (active.form === "birth" || active.form === "pair") && form.timeUnknown ? EXAMPLE_BIRTH.time : form.time,
      ...((active.form === "birth" || active.form === "pair") && !inquiryUsesNow && form.timeUnknown ? { timeUnknown: true } : {}),
      ...((active.form === "birth" || active.form === "pair") && form.exampleBirth ? { example: true } : {}),
      ...(active.form === "pair" && form.partnerTimeUnknown ? { companionTimeUnknown: true } : {}),
      // The daily page and "use the current moment" inquiries always read a solar date.
      calendar: (active.form === "birth" || active.form === "pair") && !inquiryUsesNow
        ? form.calendar === "pillars" && !["bazi", "detail", "compatibility"].includes(route) ? "solar" : form.calendar
        : "solar",
      leapMonth: form.calendar === "lunar" ? form.leapMonth : false,
      companionLeapMonth: form.partnerCalendar === "lunar" ? form.partnerLeapMonth : false,
      gender: form.gender,
      manualPillars:
        active.form === "birth" || active.form === "pair"
          ? form.manualPillars
          : undefined,
      companionDate: active.form === "pair" ? form.partnerDate : undefined,
      companionTime: active.form === "pair" ? (form.partnerTimeUnknown ? EXAMPLE_BIRTH.time : form.partnerTime) : undefined,
      companionCalendar:
        active.form === "pair" ? form.partnerCalendar : undefined,
      companionManualPillars:
        active.form === "pair" ? form.partnerManualPillars : undefined,
      lines:
        route === "liuyao" && form.castMethod !== "system"
          ? coinLineStates?.lines ?? form.manualLines
          : undefined,
      movingLines:
        route === "liuyao" && form.castMethod === "coins"
          ? coinLineStates?.movingLines
          : undefined,
      place: form.place,
      location: form.location ?? undefined,
      useTrueSolar: form.trueSolar,
      ziHour: form.ziHour,
      luckPrecision: form.luckPrecision,
      ziweiLeap: form.ziweiLeap,
      ziweiTransform: form.ziweiTransform,
      ...(route === "jinkoujue" && form.difen ? { difen: form.difen } : {}),
      ...(route === "zhuzhai" ? { houseSitting: form.houseSitting } : {}),
      ...(route === "zeri" ? { zeriPurpose: form.zeriPurpose, zeriStart: form.zeriStart || todayIso(), zeriDays: form.zeriDays } : {}),
      ...(route === "meihua" && form.meihuaMethod === "numbers" && Number(form.meihuaNumbers[0]) > 0 && Number(form.meihuaNumbers[1]) > 0 ? { meihuaMethod: "numbers" as const, meihuaNumbers: [Number(form.meihuaNumbers[0]), Number(form.meihuaNumbers[1])] as [number, number] } : {}),
      ...(route === "meihua" && form.meihuaMethod === "text" && form.inquiry.trim() ? { meihuaMethod: "text" as const, meihuaText: form.inquiry } : {}),
      focus: inputFocus,
      name: form.name,
      companionName: form.partner,
      module: route,
      version: nextVersion,
    };
    setResult(createStudyResult(input));
    setRecent((items) =>
      [
        {
          title: titleForRoute(active.route, locale),
          stamp: new Date().toLocaleDateString(locale),
        },
        ...items.filter(
          (item) => item.title !== titleForRoute(active.route, locale),
        ),
      ].slice(0, 5),
    );
  };
  const routeContractMarkers = [
    copy.form.birthMoment,
    copy.form.relationshipContext,
    copy.form.inquiryFocus,
    copy.routes.toolkit,
    copy.toolkit.time,
    copy.toolkit.elements,
    copy.toolkit.dream,
    copy.toolkit.name,
    toolkitTitle("tarot", copy, locale),
    toolkitTitle("iching", copy, locale),
    toolkitTitle("natal", copy, locale),
    copy.form.generate,
    copy.daily.seasonal,
    copy.library.search,
    copy.routes.membership,
    copy.routes.wenshi,
  ];
  const localizedShell = locale in suiteCopy;
  if (localizedShell) {
    return (
      <main
        className="suite-shell"
        data-theme={theme}
        data-locale={locale}
        data-route={route}
      >
        <header className="site-header">
          <AppBackButton locale={locale} show={route !== "home"} onHome={() => navigate("home")} />
          <button
            type="button"
            className="brand"
            onClick={() => navigate("home")}
            aria-label={copy.nav.homeLabel}
          >
            <b>{shared.home.heroBrand}</b>
            <span>Xuannova</span>
          </button>
          <nav aria-label={copy.nav.primaryNavigation}>
            <div className="method-menu">
              <button
                type="button"
                aria-expanded={methodOpen}
                onClick={() => setMethodOpen((value) => !value)}
              >
                {headerLabel(locale, "methods", copy.nav.allMethods)}
                <b>⌄</b>
              </button>
              {methodOpen && (
                <div className="method-drawer">
                  <MethodCategorySections locale={locale} navigate={navigate} />
                  <MethodDrawerExtras locale={locale} navigate={navigate} mark={localizedMark} />
                </div>
              )}
            </div>
            <NavLink route="hecan" locale={locale} onGo={() => navigate("hecan")}>
              ✦ {headerLabel(locale, "synthesis", copy.nav.synthesis)}
            </NavLink>
            <NavLink route="toolkit" locale={locale} onGo={() => navigate("toolkit")}>
              {headerLabel(locale, "toolkit", copy.nav.toolkit)}
            </NavLink>
            <NavLink route="almanac" locale={locale} onGo={() => navigate("almanac")}>
              {headerLabel(locale, "daily", titleForRoute("almanac", locale))}
            </NavLink>
            <NavLink route="library" locale={locale} onGo={() => { setLibraryCategory("all"); navigate("library"); }}>
              {headerLabel(locale, "library", copy.nav.library)}
            </NavLink>
            <NavLink route="courses" locale={locale} onGo={() => navigate("courses")}>
              {headerLabel(locale, "courses", copy.routes.courses)}
            </NavLink>
            <NavLink route="guide" locale={locale} onGo={() => navigate("guide")} className="nav-guide">
              {headerLabel(locale, "guide", copy.routes.guide)}
            </NavLink>
            <a className="nav-workshop" href={workshopHref(locale)}>{headerLabel(locale, "workshop", workshopNavLabel[locale])}</a>
          </nav>
          <div className="header-actions">
            <label>
              <span className="sr-only">{copy.nav.language}</span>
              <select
                aria-label={copy.nav.language}
                value={locale}
                onChange={(event) => setLocale(event.target.value as Locale)}
              >
                {languageOptions.map((option) => (
                  <option value={option.value} key={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </label>
            <ThemeMenu theme={theme} setTheme={setTheme} copy={copy} />
            <button
              type="button"
              className="credit-button"
              onClick={() => navigate("credits")}
            >
              {copy.nav.credits}
            </button>
            <button
              type="button"
              className="member-button"
              onClick={() => navigate("membership")}
            >
              {memberSignedIn ? accountCenterLabel[locale] : copy.nav.membership}
            </button>
            <button
              type="button"
              className={`mobile-trigger${mobileOpen ? " open" : ""}`}
              aria-label={mobileOpen ? menuCloseLabel[locale] : copy.nav.openNavigation}
              aria-expanded={mobileOpen}
              onClick={() => setMobileOpen((value) => !value)}
            >
              <span className="menu-icon" aria-hidden="true"><i /><i /><i /></span>
            </button>
          </div>
        </header>
        <FlashTicker locale={locale} route={route} />
        {mobileOpen && <div className="mobile-menu-backdrop" aria-hidden="true" onClick={() => setMobileOpen(false)} />}
        {mobileOpen && (
          <nav className="mobile-menu" aria-label={copy.nav.mobileNavigation}>
            <button type="button" className="mobile-menu-close" onClick={() => setMobileOpen(false)}>{menuCloseLabel[locale]} <b aria-hidden="true">✕</b></button>
            <MobileMethodList locale={locale} navigate={navigate} label={headerLabel(locale, "methods", copy.nav.allMethods)} />
            {(
              [
                "home",
                "hecan",
                "toolkit",
                "almanac",
                "flash",
                "daily",
                "library",
                "courses",
                "guide",
                "credits",
                "membership",
              ] as AppRoute[]
            ).map((item) => (
              <NavLink route={item} locale={locale} onGo={() => navigate(item)} key={item}>
                {item === "membership" && memberSignedIn ? accountCenterLabel[locale] : copy.routes[item]}
              </NavLink>
            ))}
            <a className="mobile-menu-link" href={workshopHref(locale)}>{workshopNavLabel[locale]}</a>
          </nav>
        )}
        {(route === "home" || homeVisited) && (
          // The home page stays mounted (hidden) after the first visit, so Back to it is instant on phones: no
          // re-render of every section and the 3D hall (whose animation pauses while hidden).
          <div className="home-keepalive" style={{ display: route === "home" ? "contents" : "none" }} aria-hidden={route === "home" ? undefined : true}>
            <HomeScreen
              copy={copy}
              locale={locale}
              navigate={navigate}
              form={form}
              setForm={setForm}
            />
          </div>
        )}
        {route in routeByKey && (
          <StudyScreen
            route={route}
            copy={copy}
            locale={locale}
            form={form}
            setForm={setForm}
            result={result}
            wallet={wallet}
            onSpend={spend}
            onOpenMembership={() => navigate("credits")}
            onOpenLibrary={(category) => {
              setLibraryCategory(category);
              navigate("library");
            }}
            onBack={() => navigate("home")}
            onNavigate={(next) => navigate(next)}
            onGenerate={generate}
          />
        )}
        {route === "daily" && <div className="monthly-wrap"><MonthlyOutlook locale={locale} onMakeChart={() => navigate("bazi")} /></div>}
        {route === "toolkit" && (
          <ToolkitScreen
            copy={copy}
            locale={locale}
            wallet={wallet}
            onSpend={spend}
            onOpenMembership={() => navigate("credits")}
          />
        )}
        {route === "library" && (
          <LibraryScreen locale={locale} initialCategory={libraryCategory} />
        )}
        {route === "courses" && <CoursesScreen locale={locale} onSignIn={() => navigate("membership")} />}
        {route === "guide" && <GuideScreen locale={locale} navigate={navigate} />}
        {route === "almanac" && <AlmanacScreen locale={locale} navigate={navigate} />}
        {route === "flash" && <FlashScreen locale={locale} navigate={navigate} initial={initialFlash} />}
        {route === "cezi" && <CeziScreen locale={locale} navigate={navigate} wallet={wallet} onSpend={spend} onOpenMembership={() => navigate("credits")} />}
        {route === "xiangshu" && <XiangshuScreen locale={locale} navigate={navigate} wallet={wallet} onSpend={spend} onOpenMembership={() => navigate("credits")} />}
        {(route === "membership" || memberWarm) && (
          <div className="member-keepalive" style={{ display: route === "membership" ? "contents" : "none" }} aria-hidden={route === "membership" ? undefined : true}>
            <MembershipScreen copy={copy} active={route === "membership"} />
          </div>
        )}
        {route === "credits" && <CreditsScreen copy={copy} locale={locale} />}
        {route === "admin" && <AdminRedirect />}
        <GrowthNotice locale={locale} />
      <BackToTop locale={locale} />
      <MobileStudyBar locale={locale} route={route} navigate={navigate} />
      <InstallApp locale={locale} />
      <section className="footer-cta">
          <div>
            <small>{shared.footer.brand}</small>
            <h2>{content.primaryCta}</h2>
            <p>{trustText.ctaLine[locale]}</p>
          </div>
          <button
            type="button"
            className="primary-action"
            onClick={() => navigate("bazi")}
          >
            {copy.hero.primary}
            <b>↗</b>
          </button>
        </section>
        <footer>
          <div>
            <b>{shared.footer.brand}</b>
            <span>{content.footerLine}</span>
          </div>
          <p>
            <b>{trustText.noteLabel[locale]}:</b> {trustText.footerNote[locale]}
          </p>
          <small>{shared.footer.copyright}</small>
          <LegalLinks locale={locale} />
        </footer>
        <div className="route-contract sr-only">
          {routeContractMarkers.map((marker) => (
            <span key={marker}>{marker}</span>
          ))}
        </div>
      </main>
    );
  }
  // The fallback only protects against malformed persisted locale data.
  return (
    <main
      className="suite-shell"
      data-theme={theme}
      data-locale={locale}
      data-route={route}
    >
      <header className="site-header">
        <AppBackButton locale={locale} show={route !== "home"} onHome={() => navigate("home")} />
        <button
          type="button"
          className="brand"
          onClick={() => navigate("home")}
          aria-label={copy.nav.homeLabel}
        >
          <b>{shared.home.heroBrand}</b>
          <span>Xuannova</span>
        </button>
        <nav aria-label={copy.nav.primaryNavigation}>
          <div className="method-menu">
            <button
              type="button"
              aria-expanded={methodOpen}
              onClick={() => setMethodOpen((value) => !value)}
            >
              {headerLabel(locale, "methods", copy.nav.methods)}
              <b>⌄</b>
            </button>
            {methodOpen && (
              <div className="method-drawer">
                <MethodCategorySections locale={locale} navigate={navigate} />
                <MethodDrawerExtras locale={locale} navigate={navigate} mark={localizedMark} />
              </div>
            )}
          </div>
          <NavLink route="hecan" locale={locale} onGo={() => navigate("hecan")}>
            ✦ {headerLabel(locale, "synthesis", copy.nav.synthesis)}
          </NavLink>
          <NavLink route="toolkit" locale={locale} onGo={() => navigate("toolkit")}>
            {headerLabel(locale, "toolkit", copy.nav.toolkit)}
          </NavLink>
          <NavLink route="almanac" locale={locale} onGo={() => navigate("almanac")}>
            {headerLabel(locale, "daily", titleForRoute("almanac", locale))}
          </NavLink>
          <NavLink route="library" locale={locale} onGo={() => navigate("library")}>
            {headerLabel(locale, "library", copy.nav.library)}
          </NavLink>
          <NavLink route="courses" locale={locale} onGo={() => navigate("courses")}>
            {headerLabel(locale, "courses", copy.routes.courses)}
          </NavLink>
          <NavLink route="guide" locale={locale} onGo={() => navigate("guide")} className="nav-guide">
            {headerLabel(locale, "guide", copy.routes.guide)}
          </NavLink>
          <a className="nav-workshop" href={workshopHref(locale)}>{headerLabel(locale, "workshop", workshopNavLabel[locale])}</a>
        </nav>
        <div className="header-actions">
          <label>
            <span className="sr-only">{copy.nav.language}</span>
            <select
              aria-label={copy.nav.language}
              value={locale}
              onChange={(event) => setLocale(event.target.value as Locale)}
            >
              {languageOptions.map((option) => (
                <option value={option.value} key={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </label>
            <ThemeMenu theme={theme} setTheme={setTheme} copy={copy} />
          <button
            type="button"
            className="member-button"
            onClick={() => navigate("membership")}
          >
            {memberSignedIn ? accountCenterLabel[locale] : copy.nav.membership}
          </button>
          <button
            type="button"
            className={`mobile-trigger${mobileOpen ? " open" : ""}`}
            aria-label={mobileOpen ? menuCloseLabel[locale] : copy.nav.openNavigation}
            aria-expanded={mobileOpen}
            onClick={() => setMobileOpen((value) => !value)}
          >
            <span className="menu-icon" aria-hidden="true"><i /><i /><i /></span>
          </button>
        </div>
      </header>
      <FlashTicker locale={locale} route={route} />
      {mobileOpen && <div className="mobile-menu-backdrop" aria-hidden="true" onClick={() => setMobileOpen(false)} />}
      {mobileOpen && (
        <nav className="mobile-menu" aria-label={copy.nav.mobileNavigation}>
          <button type="button" className="mobile-menu-close" onClick={() => setMobileOpen(false)}>{menuCloseLabel[locale]} <b aria-hidden="true">✕</b></button>
          <MobileMethodList locale={locale} navigate={navigate} label={headerLabel(locale, "methods", copy.nav.allMethods)} />
          {(
            [
              "home",
              "hecan",
              "toolkit",
              "almanac",
              "flash",
                "daily",
              "library",
              "courses",
                "guide",
              "membership",
            ] as AppRoute[]
          ).map((item) => (
            <button type="button" onClick={() => navigate(item)} key={item}>
              {item === "membership" && memberSignedIn ? accountCenterLabel[locale] : copy.routes[item]}
            </button>
          ))}
          <a className="mobile-menu-link" href={workshopHref(locale)}>{workshopNavLabel[locale]}</a>
        </nav>
      )}
      {(route === "home" || homeVisited) && (
          // The home page stays mounted (hidden) after the first visit, so Back to it is instant on phones: no
          // re-render of every section and the 3D hall (whose animation pauses while hidden).
          <div className="home-keepalive" style={{ display: route === "home" ? "contents" : "none" }} aria-hidden={route === "home" ? undefined : true}>
            <HomeScreen
              copy={copy}
              locale={locale}
              navigate={navigate}
              form={form}
              setForm={setForm}
            />
          </div>
        )}
      {route in routeByKey && (
        <StudyScreen
          route={route}
          copy={copy}
          locale={locale}
          form={form}
          setForm={setForm}
          result={result}
          wallet={wallet}
          onSpend={spend}
          onOpenMembership={() => navigate("membership")}
          onBack={() => navigate("home")}
          onGenerate={generate}
        />
      )}
      {route === "toolkit" && (
        <ToolkitScreen
          copy={copy}
          locale={locale}
          wallet={wallet}
          onSpend={spend}
          onOpenMembership={() => navigate("membership")}
        />
      )}
      {route === "daily" && <DailyScreen copy={copy} />}
      {route === "library" && <LibraryScreen copy={copy} locale={locale} />}
      {route === "courses" && <CoursesScreen locale={locale} onSignIn={() => navigate("membership")} />}
      {route === "guide" && <GuideScreen locale={locale} navigate={navigate} />}
      {route === "almanac" && <AlmanacScreen locale={locale} navigate={navigate} />}
        {route === "flash" && <FlashScreen locale={locale} navigate={navigate} initial={initialFlash} />}
      {route === "cezi" && <CeziScreen locale={locale} navigate={navigate} wallet={wallet} onSpend={spend} onOpenMembership={() => navigate("credits")} />}
      {route === "xiangshu" && <XiangshuScreen locale={locale} navigate={navigate} wallet={wallet} onSpend={spend} onOpenMembership={() => navigate("credits")} />}
      {(route === "membership" || memberWarm) && (
        <div className="member-keepalive" style={{ display: route === "membership" ? "contents" : "none" }} aria-hidden={route === "membership" ? undefined : true}>
          <MembershipScreen copy={copy} active={route === "membership"} />
        </div>
      )}
      <GrowthNotice locale={locale} />
      <BackToTop locale={locale} />
      <MobileStudyBar locale={locale} route={route} navigate={navigate} />
      <InstallApp locale={locale} />
      <section className="footer-cta">
        <div>
          <small>{shared.footer.brand}</small>
          <h2>{content.primaryCta}</h2>
          <p>{trustText.ctaLine[locale]}</p>
        </div>
        <button
          type="button"
          className="primary-action"
          onClick={() => navigate("bazi")}
        >
          {copy.hero.primary}
          <b>↗</b>
        </button>
      </section>
      <footer>
        <div>
          <b>{shared.footer.brand}</b>
          <span>{content.footerLine}</span>
        </div>
        <p>
          <b>{trustText.noteLabel[locale]}:</b> {trustText.footerNote[locale]}
        </p>
        <small>{shared.footer.copyright}</small>
        <LegalLinks locale={locale} />
      </footer>
      <div className="route-contract sr-only">
        {(
          [
            "Birth moment",
            "Relationship context",
            "Inquiry focus",
            "Study toolkit",
            "Time calibration",
            "Five Elements quick view",
            "Dream reflection",
            "Name study",
            "Tarot",
            "I Ching",
            "Natal Chart",
            "Generate study",
            "Seasonal note",
            "Search the wisdom library",
            "Local membership",
            "Inquiry synthesis",
          ] as const
        ).map((marker) => (
          <span key={marker}>{marker}</span>
        ))}
      </div>
    </main>
  );
}
