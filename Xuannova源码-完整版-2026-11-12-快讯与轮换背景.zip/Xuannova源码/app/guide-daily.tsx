"use client";
// 新手指南 · 每日纳福，好运常伴: the daily colour card, action guide, study hall (walking), prayer lamps, sharing with
// an invitation code, and adding the site to the phone's home screen.
import type { Locale } from "./site-content";
import type { AppRoute } from "./study-suite";
import { InstallAppButton } from "./install-app";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

export const guideDailyTitle = L("Invite good fortune every day", "每日纳福，好运常伴", "每日納福，好運常伴", "毎日、福を招く", "매일 복을 부르는 습관", "Mỗi ngày đón phúc lành", "รับสิริมงคลทุกวัน");
const lead = L("The ancients believed that good fortune follows a respectful heart and a life in step with heaven's timing. Give it one minute a day: wear today's lucky colour, plan your day by the almanac, light a lamp for the people you love — and carry a good intention with you.", "古人相信：心存敬意、顺应天时，福气自然来。每天花一分钟：穿上今天的幸运色，照着宜忌安排一天，为家人点一盏祈福灯，把好的心念带在身边。", "古人相信：心存敬意、順應天時，福氣自然來。每天花一分鐘：穿上今天的幸運色，照著宜忌安排一天，為家人點一盞祈福燈，把好的心念帶在身邊。", "古人は、敬う心を持ち天の時に従えば福は自ずと訪れると考えました。一日一分だけ：今日のラッキーカラーを身に着け、暦の宜忌で一日を組み立て、大切な人のために灯をともし、良い心を携えて過ごしましょう。", "옛사람들은 공경하는 마음으로 하늘의 때를 따르면 복이 저절로 온다고 믿었어요. 하루 1분이면 충분해요. 오늘의 행운 색을 입고, 역서의 의·기로 하루를 계획하고, 소중한 사람을 위해 등을 밝히며 좋은 마음을 지니세요.", "Người xưa tin rằng lòng thành kính và thuận theo thiên thời thì phúc lành tự đến. Mỗi ngày một phút: mặc màu may mắn hôm nay, sắp xếp ngày theo điều nên/kiêng, thắp một ngọn đèn cho người thân — và mang theo một tâm niệm tốt.", "คนโบราณเชื่อว่า ใจที่นอบน้อมและการดำเนินตามจังหวะฟ้า จะนำสิริมงคลมาเอง ใช้เวลาวันละหนึ่งนาที สวมสีมงคลของวันนี้ วางแผนวันตามสิ่งควร/ไม่ควร จุดโคมให้คนที่รัก และพกความตั้งใจดีติดตัวไว้");

type Item = { icon: string; title: L7; body: L7; go?: { target: "today" | "hall" | AppRoute; label: L7; tab?: string } };
const open = L("Open", "去看看", "去看看", "開く", "열기", "Mở", "เปิด");
const items: Item[] = [
  { icon: "色", title: L("Daily lucky colour card", "今日幸运色 · 专属日签", "今日幸運色 · 專屬日籤", "今日のラッキーカラー・日めくりカード", "오늘의 행운 색 · 데일리 카드", "Màu may mắn hôm nay · thiệp riêng", "สีมงคลวันนี้ · การ์ดประจำวัน"),
    body: L("On the home page, under “Invite good fortune today”, enter your birth date and tap “See today's colour”. You get today's lucky colour with the reason and a classical line; tap “Generate Daily Card” to make a poster you can save or share.", "首页「今日纳福，好运随身」里输入生日，点「查看今日幸运色」，就能看到今天适合穿的颜色、原因和一句国学金句。点【生成专属日签】可以生成海报，保存到相册或直接分享。", "首頁「今日納福，好運隨身」裡輸入生日，點「查看今日幸運色」，就能看到今天適合穿的顏色、原因和一句國學金句。點【產生專屬日籤】可以產生海報，儲存到相簿或直接分享。", "ホームの「今日、福を招く」で生年月日を入れ「今日の色を見る」をタップ。今日のラッキーカラーと理由、古典の一句が出ます。「日めくりカードを作る」でポスターを保存・シェアできます。", "홈의 '오늘, 복을 부르세요'에서 생일을 입력하고 '오늘의 색 보기'를 누르면 오늘의 행운 색과 이유, 고전 한 구절이 나와요. '나만의 데일리 카드 만들기'로 포스터를 저장·공유할 수 있어요.", "Ở trang chủ, mục “Đón phúc hôm nay, may mắn theo bạn”, nhập ngày sinh rồi chạm “Xem màu hôm nay”: bạn có màu may mắn, lý do và một câu cổ văn. Chạm “Tạo thiệp hằng ngày” để lưu hoặc chia sẻ ảnh.", "ที่หน้าแรก ส่วน “รับสิริมงคลวันนี้ โชคดีติดตัว” ใส่วันเกิดแล้วแตะ “ดูสีวันนี้” จะเห็นสีมงคล เหตุผล และวลีคลาสสิก แตะ “สร้างการ์ดประจำวัน” เพื่อบันทึกหรือแชร์"),
    go: { target: "today", label: open } },
  { icon: "宜", title: L("Today's action guide", "今日行动指南", "今日行動指南", "今日の行動ガイド", "오늘의 행동 가이드", "Hướng dẫn hành động hôm nay", "คู่มือการกระทำวันนี้"),
    body: L("The almanac's “good for / avoid” in everyday words, e.g. “Business talks & contracts”. It is on the home page and under every day of the Almanac; tap “Generate action card” for a calendar-style poster.", "把黄历的宜与忌换成现代说法，比如「商务谈判、签约」。在首页和黄历页的每一天下面都有，点「生成黄历海报」可以生成日历风格的海报。", "把黃曆的宜與忌換成現代說法，例如「商務談判、簽約」。在首頁和黃曆頁的每一天下面都有，點「產生黃曆海報」可以產生日曆風格的海報。", "暦の「宜・忌」を「商談・契約」のような今の言葉に。ホームと暦ページの各日にあり、「行動ガイドカードを作る」でカレンダー風ポスターに。", "역서의 의·기를 '비즈니스 협상·계약'처럼 요즘 말로 바꿨어요. 홈과 역서의 매일 카드 아래에 있고, '행동 가이드 카드 만들기'로 달력 포스터를 만들 수 있어요.", "Điều nên/kiêng của lịch được nói bằng lời hiện đại, ví dụ “Đàm phán, ký kết”. Có ở trang chủ và dưới mỗi ngày trong Lịch; chạm “Tạo thiệp hướng dẫn” để có ảnh kiểu lịch.", "สิ่งควร/ไม่ควรจากปฏิทิน ในภาษาวันนี้ เช่น “เจรจาธุรกิจ เซ็นสัญญา” มีที่หน้าแรกและใต้ทุกวันในปฏิทิน แตะ “สร้างการ์ดคู่มือ” เพื่อทำโปสเตอร์"),
    go: { target: "almanac", label: open } },
  { icon: "殿", title: L("The study hall — walk around", "研习殿 · 在殿中走动", "研習殿 · 在殿中走動", "研習殿・殿内を歩く", "연습전 · 전각 거닐기", "Điện tu học · dạo quanh điện", "หอศึกษา · เดินในหอ"),
    body: L("Lower on the home page. You sit in the hall in a golden robe among fellow practitioners. Tap the floor and you get up and walk there; tap “Back to my seat” to return. Drag left or right to look around. You can choose your own Taoist name.", "在首页下方。你穿金色道袍，和道友们一起坐在殿中。点殿内地面，你就会起身走过去；点「回到座位」就走回来。左右拖动可以环顾殿内，也可以「自己起道号」。", "在首頁下方。你穿金色道袍，和道友們一起坐在殿中。點殿內地面，你就會起身走過去；點「回到座位」就走回來。左右拖動可以環顧殿內，也可以「自己起道號」。", "ホームの下のほう。金色の衣のあなたが道友と殿内に座っています。床をタップするとそこまで歩き、「席に戻る」で戻ります。左右ドラッグで見回せ、道号も自分で付けられます。", "홈 아래쪽에 있어요. 금색 도포를 입은 당신이 도우들과 함께 앉아 있어요. 바닥을 누르면 걸어가고, '자리로 돌아가기'로 돌아와요. 좌우로 드래그해 둘러보고, 도호도 직접 지을 수 있어요.", "Ở phía dưới trang chủ. Bạn mặc áo vàng, ngồi cùng các đạo hữu. Chạm sàn để đứng dậy đi tới đó; chạm “Về chỗ ngồi” để quay lại. Kéo trái phải để nhìn quanh; bạn có thể tự đặt đạo hiệu.", "อยู่ด้านล่างของหน้าแรก คุณสวมชุดสีทองนั่งร่วมกับเพื่อนร่วมทาง แตะพื้นเพื่อลุกเดินไป แตะ “กลับที่นั่ง” เพื่อกลับ ลากซ้ายขวาเพื่อมองรอบ ๆ และตั้งฉายาเองได้"),
    go: { target: "hall", label: open } },
  { icon: "灯", title: L("Light a prayer lamp", "点亮祈福灯", "點亮祈福燈", "祈りの灯をともす", "기원등 밝히기", "Thắp đèn cầu phúc", "จุดโคมอธิษฐาน"),
    body: L("Under the study hall: choose a theme (peace, studies, health…), write a short wish if you like, and light it. Your lantern rises into the hall and glows for 24 hours. Free for now (sign in first, up to 5 a day). You can keep the wish private and make a share poster.", "在研习殿下方：选一个心意（平安、学业、健康……），可以写一句心愿，然后点亮。你的灯会升到殿顶，亮 24 小时。现在免费（需要先登录，每天最多 5 盏）。心愿可以不公开，也能生成分享海报。", "在研習殿下方：選一個心意（平安、學業、健康……），可以寫一句心願，然後點亮。你的燈會升到殿頂，亮 24 小時。現在免費（需要先登入，每天最多 5 盞）。心願可以不公開，也能產生分享海報。", "研習殿の下で、テーマ（平安・学業・健康…）を選び、願いを一言書いてともします。灯は殿内に昇り24時間輝きます。今は無料（要サインイン、1日5灯まで）。願いは非公開にもでき、ポスターも作れます。", "연습전 아래에서 뜻(평안·학업·건강…)을 고르고, 원하면 소원을 적어 밝히세요. 등이 전각 위로 올라가 24시간 빛나요. 지금은 무료(로그인 필요, 하루 5개까지). 소원은 비공개도 되고 공유 포스터도 만들 수 있어요.", "Dưới điện tu học: chọn ý nguyện (bình an, học hành, sức khỏe…), viết một lời nguyện nếu muốn rồi thắp. Đèn bay lên điện và sáng 24 giờ. Hiện miễn phí (cần đăng nhập, tối đa 5 đèn/ngày). Có thể giữ kín lời nguyện và tạo ảnh chia sẻ.", "ใต้หอศึกษา เลือกความตั้งใจ (สงบสุข การเรียน สุขภาพ…) เขียนคำอธิษฐานสั้น ๆ แล้วจุด โคมจะลอยขึ้นและสว่าง 24 ชั่วโมง ตอนนี้ฟรี (ต้องเข้าสู่ระบบ วันละไม่เกิน 5 โคม) เก็บคำอธิษฐานเป็นส่วนตัวได้ และสร้างโปสเตอร์แชร์ได้"),
    go: { target: "hall", label: open } },
  { icon: "邀", title: L("Share and invite", "分享与邀请", "分享與邀請", "シェアと招待", "공유와 초대", "Chia sẻ và mời", "แชร์และเชิญ"),
    body: L("Every poster carries a QR code. When you are signed in it includes your invitation code: when a friend joins with it and makes a first purchase, you both get 5 credits. In My account → Invitations you can see how many joined and which poster or link brought them.", "每张海报都有二维码，登录后会带上你的邀请码。朋友用它注册并首次购买后，你们各得 5 积分。在「我的 → 邀请」里可以看到邀请了多少人，以及他们是从哪张海报或链接来的。", "每張海報都有二維碼，登入後會帶上你的邀請碼。朋友用它註冊並首次購買後，你們各得 5 積分。在「我的 → 邀請」裡可以看到邀請了多少人，以及他們是從哪張海報或連結來的。", "どのポスターにも QR コードがあり、サインイン中は招待コード付きです。友だちが登録して初めて購入すると、お二人に5クレジット。「マイページ → 招待」で人数と、どのポスター／リンクから来たかがわかります。", "모든 포스터에 QR 코드가 있고, 로그인하면 내 초대 코드가 들어가요. 친구가 가입해 첫 구매를 하면 둘 다 5크레딧. '내 계정 → 초대'에서 몇 명이 왔는지, 어떤 포스터·링크로 왔는지 볼 수 있어요.", "Mỗi ảnh đều có mã QR; khi đăng nhập sẽ kèm mã mời của bạn. Bạn bè đăng ký và mua lần đầu thì mỗi người nhận 5 điểm. Trong “Tài khoản → Mời bạn” bạn xem được bao nhiêu người đã tham gia và họ đến từ ảnh/liên kết nào.", "ทุกโปสเตอร์มี QR โค้ด เมื่อเข้าสู่ระบบจะมีรหัสเชิญของคุณ เพื่อนสมัครและซื้อครั้งแรก ทั้งคู่รับ 5 เครดิต ใน “บัญชีของฉัน → เชิญ” ดูได้ว่ามีกี่คนและมาจากโปสเตอร์/ลิงก์ไหน"),
    go: { target: "membership", label: open, tab: "invite" } },
  { icon: "屏", title: L("Add it to your phone's home screen", "添加到手机桌面", "加到手機主畫面", "スマホのホーム画面に追加", "휴대폰 홈 화면에 추가", "Thêm vào màn hình chính điện thoại", "เพิ่มไว้ที่หน้าจอโฮมของมือถือ"),
    body: L("Xuannova then opens full-screen like an app, with shortcuts to the daily card, almanac and study hall. On Android tap “Add to home screen” (or the browser menu ⋮ → Install app); on iPhone use Safari's Share button → Add to Home Screen.", "添加后像 App 一样全屏打开，长按图标还有日签、黄历、研习殿的快捷入口。安卓点「添加到桌面」（或浏览器菜单 ⋮ →「安装应用」）；iPhone 用 Safari 的「分享」→「添加到主屏幕」。", "加入後像 App 一樣全螢幕開啟，長按圖示還有日籤、黃曆、研習殿的捷徑。安卓點「加到主畫面」（或瀏覽器選單 ⋮ →「安裝應用程式」）；iPhone 用 Safari 的「分享」→「加入主畫面」。", "追加するとアプリのように全画面で開き、アイコン長押しで日めくり・暦・研習殿へのショートカットも。Android は「ホーム画面に追加」（またはメニュー ⋮ → アプリをインストール）、iPhone は Safari の共有 → ホーム画面に追加。", "추가하면 앱처럼 전체 화면으로 열리고, 아이콘을 길게 누르면 데일리 카드·역서·연습전 바로가기도 있어요. 안드로이드는 '홈 화면에 추가'(또는 메뉴 ⋮ → 앱 설치), 아이폰은 Safari 공유 → 홈 화면에 추가.", "Sau đó Xuannova mở toàn màn hình như ứng dụng, giữ biểu tượng có lối tắt tới thiệp, lịch và điện học. Android: chạm “Thêm vào màn hình chính” (hoặc menu ⋮ → Cài đặt ứng dụng); iPhone: nút Chia sẻ của Safari → Thêm vào MH chính.", "จากนั้น Xuannova จะเปิดเต็มจอเหมือนแอป กดค้างที่ไอคอนมีทางลัดไปการ์ด ปฏิทิน และหอศึกษา Android แตะ “เพิ่มไปที่หน้าจอโฮม” (หรือเมนู ⋮ → ติดตั้งแอป) iPhone ใช้ปุ่มแชร์ของ Safari → เพิ่มไปยังหน้าจอโฮม") },
];

export function GuideDaily({ locale, navigate }: { locale: Locale; navigate: (route: AppRoute) => void }) {
  const go = (target: Item["go"]) => {
    if (!target) return;
    if (target.target === "today" || target.target === "hall") {
      const id = target.target;
      navigate("home");
      // The home page is kept alive, so the section is usually there at once; try a few times while it renders.
      let tries = 0;
      const find = () => { const element = document.getElementById(id); if (element) element.scrollIntoView({ behavior: "instant" as ScrollBehavior, block: "start" }); else if ((tries += 1) < 20) window.setTimeout(find, 100); };
      window.setTimeout(find, 60);
    } else {
      navigate(target.target);
      if (target.tab) { const tab = target.tab; for (const delay of [0, 350]) window.setTimeout(() => window.dispatchEvent(new CustomEvent("xn:member-tab", { detail: tab })), delay); }
    }
  };
  return <article id="guide-daily" className="guide-block">
    <h2>{guideDailyTitle[locale]}</h2>
    <p>{lead[locale]}</p>
    <ul className="guide-daily">{items.map((item) => <li key={item.icon}>
      <i aria-hidden="true">{item.icon}</i>
      <div><strong>{item.title[locale]}</strong><span>{item.body[locale]}</span>
        {item.go && <button type="button" className="text-action" onClick={() => go(item.go)}>{item.go.label[locale]} →</button>}
        {item.icon === "屏" && <InstallAppButton locale={locale} />}
      </div>
    </li>)}</ul>
  </article>;
}
