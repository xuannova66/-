import type { Metadata } from "next";
import "./globals.css";
import { metadataFor, structuredDataFor } from "./seo";
import "./mobile-polish.css";
import "./archive-cover-mobile.css";
import "./chart-detail.css";

const homeMetadata = metadataFor("en", "home");

export const metadata: Metadata = {
  metadataBase: new URL("https://xuannova.com"),
  alternates: homeMetadata.alternates,
  title: homeMetadata.title,
  description: homeMetadata.description,
  openGraph: {
    title: homeMetadata.title ?? undefined,
    description: homeMetadata.description ?? undefined,
    images: [{ url: "https://xuannova.com/xuannova-og.jpg", width: 1730, height: 909, alt: "Xuannova Taiji study instrument" }],
  },
  twitter: {
    card: "summary_large_image",
    images: ["https://xuannova.com/xuannova-og.jpg"],
  },
  // Taiji-bagua icon: SVG for modern browsers, PNG/ICO fallbacks, and the apple-touch icon that iOS Safari uses
  // for bookmarks, history and the home screen (without it iOS shows a generic placeholder).
  icons: {
    icon: [
      { url: "/favicon.svg", type: "image/svg+xml" },
      { url: "/favicon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/icon-192.png", sizes: "192x192", type: "image/png" },
    ],
    shortcut: "/favicon.ico",
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
  manifest: "/site.webmanifest",
  // Opened from the home screen it runs full-screen like an app (iOS reads these; Android reads the manifest).
  appleWebApp: { capable: true, title: "Xuannova", statusBarStyle: "black-translucent" },
  applicationName: "Xuannova",
};

// vinext renders only width / scale / theme colour, so viewport-fit rides along in the width value.
export const viewport = { width: "device-width, viewport-fit=cover", initialScale: 1, themeColor: "#15120e" };

// [css width, css height, pixel ratio] of iPhones that get their own launch picture (public/splash/)
const IOS_LAUNCH: Array<[number, number, number]> = [[440, 956, 3], [430, 932, 3], [428, 926, 3], [414, 896, 3], [402, 874, 3], [393, 852, 3], [390, 844, 3], [375, 812, 3], [414, 896, 2], [375, 667, 2]];

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        {/* Paint the theme colour at once (no white flash), and on the home-screen app show the logo until the app is ready. */}
        <script dangerouslySetInnerHTML={{ __html: `(function(){var t;try{t=localStorage.getItem("xuannova-theme")||localStorage.getItem("xuanyuan-theme")}catch(e){}var p=t==="paper",d=document.documentElement;d.style.background=p?"#e8e2d2":"#111516";d.style.colorScheme=p?"light":"dark";d.style.setProperty("--boot-bg",p?"#e8e2d2":"#111516")})()` }} />
        <style dangerouslySetInnerHTML={{ __html: `#boot-splash{display:none}@media (display-mode: standalone){#boot-splash{position:fixed;inset:0;z-index:9999;display:grid;place-items:center;background:var(--boot-bg,#111516);transition:opacity .25s ease;animation:boot-out .3s ease 4s forwards}#boot-splash img{width:84px;height:84px;border-radius:20px;box-shadow:0 0 40px rgba(212,168,92,.35)}html[data-booted] #boot-splash{opacity:0;pointer-events:none}}@keyframes boot-out{to{opacity:0;visibility:hidden}}` }} />
        <div id="boot-splash" aria-hidden="true"><img src="/icon-192.png" alt="" /></div>
        {/* React hoists this into <head>: older iOS needs it to open the home-screen icon full-screen. */}
        <meta name="apple-mobile-web-app-capable" content="yes" />
        {/* iPhone home-screen launch pictures: without them iOS shows a plain white screen while the app starts. */}
        {IOS_LAUNCH.map(([w, h, ratio]) => <link key={`${w}x${h}@${ratio}`} rel="apple-touch-startup-image" href={`/splash/launch-${w * ratio}x${h * ratio}.png`} media={`(device-width: ${w}px) and (device-height: ${h}px) and (-webkit-device-pixel-ratio: ${ratio}) and (orientation: portrait)`} />)}
        {/* Set the document language from the URL prefix before anything renders (/ja/…, /zh-hans/…). */}
        <script dangerouslySetInnerHTML={{ __html: `(function(){var m=location.pathname.split("/")[1]||"";var map={"zh-hans":"zh-Hans","zh-hant":"zh-Hant","ja":"ja","ko":"ko","vi":"vi","th":"th"};document.documentElement.lang=map[m.toLowerCase()]||"en";})();` }} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredDataFor("en", "home")).replace(/</g, "\\u003c") }} />
        {children}
      </body>
    </html>
  );
}
