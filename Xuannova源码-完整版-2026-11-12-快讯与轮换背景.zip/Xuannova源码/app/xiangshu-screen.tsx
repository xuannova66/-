"use client";
// 手相面相 (/xiangshu): a palm or face photo is described by a vision model (visible features only), then read
// through the normal interpretation flow (first half free). The photo is resized in the browser, sent once,
// and never stored by Xuannova.
import { useMemo, useState, type ChangeEvent } from "react";
import type { Locale } from "./site-content";
import type { AppRoute } from "./study-suite";
import type { CompleteChart } from "./chart-model";
import { createStudyResult } from "./study-engine";
import { InterpretationPanel } from "./interpretation-panel";
import type { CreditWallet } from "./credit-wallet";
import { useVisionAvailable } from "./vision-availability";
import { MethodHelp } from "./guide";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

const t = {
  kicker: L("XUANNOVA · STUDY", "Xuannova · 研习", "Xuannova · 研習", "Xuannova · 研究", "Xuannova · 학습", "XUANNOVA · NGHIÊN CỨU", "Xuannova · ศึกษา"),
  title: L("Palm & Face Reading", "手相面相", "手相面相", "手相・人相", "수상 · 관상", "Xem tướng tay & mặt", "ลายมือและโหงวเฮ้ง"),
  lead: L("Upload one clear photo: the visible lines and features are described first, then read by the classical rules.", "上传一张清晰照片：先描述看得见的纹线与五官，再按传统相法解读。", "上傳一張清晰照片：先描述看得見的紋線與五官，再按傳統相法解讀。", "鮮明な写真を一枚：まず見える線や顔立ちを記述し、伝統的な相法で読みます。", "선명한 사진 한 장: 먼저 보이는 손금과 이목구비를 기술하고, 전통 상법으로 해석합니다.", "Tải lên một ảnh rõ: trước hết mô tả các đường chỉ và nét mặt nhìn thấy được, rồi luận theo tướng pháp truyền thống.", "อัปโหลดรูปที่ชัดหนึ่งรูป: อธิบายเส้นและลักษณะที่มองเห็นก่อน แล้วอ่านตามหลักโหงวเฮ้งดั้งเดิม"),
  palm: L("Palm", "手相", "手相", "手相", "수상", "Tướng tay", "ลายมือ"),
  face: L("Face", "面相", "面相", "人相", "관상", "Tướng mặt", "โหงวเฮ้ง"),
  hand: L("Which hand", "哪只手", "哪隻手", "どちらの手", "어느 손", "Tay nào", "มือข้างไหน"),
  left: L("Left", "左手", "左手", "左手", "왼손", "Tay trái", "มือซ้าย"),
  right: L("Right", "右手", "右手", "右手", "오른손", "Tay phải", "มือขวา"),
  handTip: L("Traditionally: the left hand shows what you were born with, the right hand what you have made of it.", "传统说法：左手看先天，右手看后天。", "傳統說法：左手看先天，右手看後天。", "伝統的に、左手は生まれ持ったもの、右手は後に築いたものを表すとされます。", "전통적으로 왼손은 타고난 것, 오른손은 살아오며 만든 것을 본다고 합니다.", "Theo truyền thống: tay trái xem tiên thiên, tay phải xem hậu thiên.", "ตามตำรา มือซ้ายดูสิ่งที่ติดตัวมา มือขวาดูสิ่งที่สร้างขึ้นภายหลัง"),
  tipsPalm: L("Open palm facing the camera, fingers together, good daylight, the whole palm and wrist in frame.", "手掌张开正对镜头，手指并拢，光线充足，整个手掌和手腕都在画面里。", "手掌張開正對鏡頭，手指併攏，光線充足，整個手掌和手腕都在畫面裡。", "手のひらを開いてカメラに向け、指をそろえ、明るい場所で手首まで入れて撮影。", "손바닥을 펴서 카메라를 향하고 손가락을 모은 채, 밝은 곳에서 손목까지 나오게 찍으세요.", "Mở lòng bàn tay hướng vào máy, khép ngón, đủ sáng, cả bàn tay và cổ tay trong khung.", "แบมือหันเข้ากล้อง นิ้วชิดกัน แสงพอ ให้เห็นทั้งฝ่ามือและข้อมือ"),
  tipsFace: L("Face the camera straight on, no glasses or filters, hair off the forehead, even light.", "正面看镜头，不戴眼镜、不开美颜，额头露出，光线均匀。", "正面看鏡頭，不戴眼鏡、不開美顏，額頭露出，光線均勻。", "正面を向き、眼鏡やフィルターなし、額を出して均一な光で。", "정면을 보고, 안경·필터 없이, 이마를 드러내고 고른 빛에서 찍으세요.", "Nhìn thẳng vào máy, không đeo kính, không bộ lọc, để lộ trán, ánh sáng đều.", "มองตรงเข้ากล้อง ไม่ใส่แว่น ไม่ใช้ฟิลเตอร์ เปิดหน้าผาก แสงสม่ำเสมอ"),
  choose: L("Choose a photo", "选择照片", "選擇照片", "写真を選ぶ", "사진 선택", "Chọn ảnh", "เลือกรูป"),
  change: L("Change photo", "换一张", "換一張", "写真を変える", "사진 바꾸기", "Đổi ảnh", "เปลี่ยนรูป"),
  consent: L("I agree that this photo is sent once to an image-recognition service to describe the visible features. It is not stored by Xuannova and is discarded after the analysis. Only upload your own photo, or one you have permission to use.", "我同意这张照片发送给识图服务做一次特征描述。Xuannova 不保存照片，分析完即丢弃。只上传本人照片，或已获得本人同意的照片。", "我同意這張照片傳送給識圖服務做一次特徵描述。Xuannova 不保存照片，分析完即丟棄。只上傳本人照片，或已取得本人同意的照片。", "この写真を画像認識サービスに一度だけ送り、見える特徴を記述することに同意します。Xuannova は写真を保存せず、分析後に破棄します。ご本人の写真、または許可を得た写真のみアップロードしてください。", "이 사진을 이미지 인식 서비스로 한 번 보내 보이는 특징을 기술하는 데 동의합니다. Xuannova는 사진을 저장하지 않으며 분석 후 폐기합니다. 본인 사진이나 동의를 받은 사진만 올려 주세요.", "Tôi đồng ý gửi ảnh này một lần tới dịch vụ nhận dạng ảnh để mô tả các đặc điểm nhìn thấy. Xuannova không lưu ảnh và xóa ngay sau khi phân tích. Chỉ tải ảnh của chính bạn hoặc ảnh đã được cho phép.", "ฉันยินยอมให้ส่งรูปนี้หนึ่งครั้งไปยังบริการจดจำภาพเพื่ออธิบายลักษณะที่มองเห็น Xuannova ไม่เก็บรูปและทิ้งหลังวิเคราะห์ อัปโหลดเฉพาะรูปของตนเองหรือรูปที่ได้รับอนุญาต"),
  analyze: L("Describe the photo", "开始观察", "開始觀察", "観察を始める", "관찰 시작", "Bắt đầu quan sát", "เริ่มสังเกต"),
  analyzing: L("Looking at the photo…", "正在观察照片…", "正在觀察照片…", "写真を観察しています…", "사진을 살펴보는 중…", "Đang quan sát ảnh…", "กำลังดูรูป…"),
  observed: L("What the photo shows", "照片所见", "照片所見", "写真から見えること", "사진에서 보이는 것", "Những gì thấy trong ảnh", "สิ่งที่เห็นในรูป"),
  observedNote: L("Described from one photo; light and angle can change what is visible.", "根据一张照片描述，光线和角度会影响能看到的细节。", "根據一張照片描述，光線和角度會影響能看到的細節。", "一枚の写真からの記述です。光や角度で見え方は変わります。", "사진 한 장으로 기술한 것이며, 빛과 각도에 따라 보이는 것이 달라질 수 있습니다.", "Mô tả từ một ảnh; ánh sáng và góc chụp có thể làm khác chi tiết.", "อธิบายจากรูปเดียว แสงและมุมอาจทำให้รายละเอียดต่างไป"),
  invalid: L("This photo could not be used", "这张照片用不了", "這張照片用不了", "この写真は使えませんでした", "이 사진은 사용할 수 없습니다", "Không dùng được ảnh này", "ใช้รูปนี้ไม่ได้"),
  signIn: L("Please sign in as a member to use photo reading.", "请先登录会员，再使用照片观察。", "請先登入會員，再使用照片觀察。", "写真の観察は会員ログイン後に使えます。", "사진 관찰은 회원 로그인 후 이용할 수 있습니다.", "Vui lòng đăng nhập thành viên để dùng tính năng này.", "กรุณาเข้าสู่ระบบสมาชิกก่อนใช้การดูรูป"),
  signInAction: L("Sign in", "登录会员", "登入會員", "ログイン", "로그인", "Đăng nhập", "เข้าสู่ระบบ"),
  limit: L("You have used today's photo analyses. Please try again tomorrow.", "今天的照片观察次数已用完，请明天再试。", "今天的照片觀察次數已用完，請明天再試。", "本日の写真観察の回数を使い切りました。明日またお試しください。", "오늘의 사진 관찰 횟수를 모두 사용했습니다. 내일 다시 시도해 주세요.", "Bạn đã dùng hết lượt hôm nay. Vui lòng thử lại vào ngày mai.", "ใช้สิทธิ์ดูรูปของวันนี้หมดแล้ว กรุณาลองใหม่พรุ่งนี้"),
  authFailed: L("Photo reading is not working on our side right now (service key problem). We have been notified; please try again later.", "识图服务在站方这边出了问题（服务密钥无效），我们会尽快处理，请稍后再试。", "識圖服務在站方這邊出了問題（服務金鑰無效），我們會盡快處理，請稍後再試。", "現在サイト側の画像サービスに問題があります（サービスキーの問題）。対応中ですので、しばらくしてからお試しください。", "지금 사이트 쪽 이미지 서비스에 문제가 있습니다(서비스 키 문제). 처리 중이니 잠시 후 다시 시도해 주세요.", "Dịch vụ ảnh đang gặp sự cố phía chúng tôi (khóa dịch vụ không hợp lệ). Chúng tôi đang xử lý, vui lòng thử lại sau.", "บริการภาพมีปัญหาจากฝั่งเรา (คีย์บริการไม่ถูกต้อง) กำลังแก้ไข โปรดลองใหม่ภายหลัง"),
  timeout: L("The photo took too long to read. Please try a smaller, clearer photo.", "识图超时，请换一张更小、更清晰的照片再试。", "識圖逾時，請換一張更小、更清晰的照片再試。", "読み取りに時間がかかりすぎました。小さく鮮明な写真でお試しください。", "인식 시간이 초과되었습니다. 더 작고 선명한 사진으로 다시 시도해 주세요.", "Đọc ảnh quá lâu. Hãy thử ảnh nhỏ và rõ hơn.", "อ่านภาพนานเกินไป โปรดลองภาพที่เล็กและชัดขึ้น"),
  errorCode: L("Error code", "错误代码", "錯誤代碼", "エラーコード", "오류 코드", "Mã lỗi", "รหัสข้อผิดพลาด"),
  failed: L("The photo service is busy. Please try again in a moment.", "识图服务暂时繁忙，请稍后再试。", "識圖服務暫時繁忙，請稍後再試。", "画像サービスが混み合っています。しばらくしてからお試しください。", "이미지 서비스가 혼잡합니다. 잠시 후 다시 시도해 주세요.", "Dịch vụ ảnh đang bận. Vui lòng thử lại sau.", "บริการภาพไม่ว่าง กรุณาลองใหม่อีกครั้ง"),
  unavailable: L("Palm and face reading opens very soon. Photo upload will be available here shortly.", "手相面相即将开通，很快就可以在这里上传照片研习，敬请期待。", "手相面相即將開通，很快就可以在這裡上傳照片研習，敬請期待。", "手相・人相はまもなく公開します。近日中にここで写真をアップロードできます。", "수상·관상이 곧 열립니다. 잠시 후 이곳에서 사진을 올릴 수 있어요.", "Xem tướng tay và mặt sắp mở. Bạn sẽ sớm tải ảnh lên tại đây.", "ลายมือและโหงวเฮ้งใกล้เปิดแล้ว อีกไม่นานจะอัปโหลดรูปได้ที่นี่"),
  badFile: L("Please choose a photo (JPEG, PNG or WebP).", "请选择照片文件（JPEG、PNG 或 WebP）。", "請選擇照片檔案（JPEG、PNG 或 WebP）。", "写真ファイル（JPEG・PNG・WebP）を選んでください。", "사진 파일(JPEG, PNG, WebP)을 선택해 주세요.", "Vui lòng chọn ảnh (JPEG, PNG hoặc WebP).", "กรุณาเลือกไฟล์รูป (JPEG, PNG หรือ WebP)"),
  again: L("Try another photo", "换张照片再看", "換張照片再看", "別の写真で見る", "다른 사진으로 보기", "Thử ảnh khác", "ลองรูปอื่น"),
};

const featureLabels: Record<string, [string, L7]> = {
  handShape: ["Hand shape", L("Hand shape", "手型", "手型", "手の型", "손 모양", "Dáng tay", "รูปมือ")],
  palmFingerRatio: ["Palm and finger proportion", L("Palm and finger proportion", "掌指比例", "掌指比例", "掌と指の比率", "손바닥과 손가락 비율", "Tỷ lệ bàn tay và ngón", "สัดส่วนฝ่ามือกับนิ้ว")],
  lifeLine: ["Life line", L("Life line", "生命线", "生命線", "生命線", "생명선", "Đường sinh đạo", "เส้นชีวิต")],
  headLine: ["Head line", L("Head line", "智慧线", "智慧線", "頭脳線", "두뇌선", "Đường trí đạo", "เส้นสมอง")],
  heartLine: ["Heart line", L("Heart line", "感情线", "感情線", "感情線", "감정선", "Đường tâm đạo", "เส้นหัวใจ")],
  fateLine: ["Fate line", L("Fate line", "事业线", "事業線", "運命線", "운명선", "Đường sự nghiệp", "เส้นวาสนา")],
  sunLine: ["Sun line", L("Sun line", "太阳线", "太陽線", "太陽線", "태양선", "Đường thái dương", "เส้นอาทิตย์")],
  marriageLines: ["Marriage lines", L("Marriage lines", "婚姻线", "婚姻線", "結婚線", "결혼선", "Đường hôn nhân", "เส้นคู่ครอง")],
  thumb: ["Thumb", L("Thumb", "拇指", "拇指", "親指", "엄지", "Ngón cái", "นิ้วโป้ง")],
  fingers: ["Fingers", L("Fingers", "手指", "手指", "指", "손가락", "Các ngón", "นิ้วมือ")],
  mounts: ["Mounts", L("Mounts", "掌丘", "掌丘", "丘", "구(丘)", "Các gò", "เนินฝ่ามือ")],
  specialMarks: ["Special marks", L("Special marks", "特殊纹", "特殊紋", "特殊な紋", "특수 문양", "Dấu đặc biệt", "เครื่องหมายพิเศษ")],
  faceShape: ["Face shape", L("Face shape", "脸型", "臉型", "顔の型", "얼굴형", "Dáng mặt", "รูปหน้า")],
  threeCourts: ["Three courts", L("Three courts", "三停", "三停", "三停", "삼정", "Tam đình", "สามส่วนของใบหน้า")],
  forehead: ["Forehead", L("Forehead", "额头", "額頭", "額", "이마", "Trán", "หน้าผาก")],
  eyebrows: ["Eyebrows", L("Eyebrows", "眉", "眉", "眉", "눈썹", "Lông mày", "คิ้ว")],
  eyes: ["Eyes", L("Eyes", "眼", "眼", "目", "눈", "Mắt", "ตา")],
  nose: ["Nose", L("Nose", "鼻", "鼻", "鼻", "코", "Mũi", "จมูก")],
  cheekbones: ["Cheekbones", L("Cheekbones", "颧骨", "顴骨", "頬骨", "광대뼈", "Gò má", "โหนกแก้ม")],
  mouth: ["Mouth", L("Mouth", "口唇", "口唇", "口", "입", "Miệng", "ปาก")],
  ears: ["Ears", L("Ears", "耳", "耳", "耳", "귀", "Tai", "หู")],
  chin: ["Chin", L("Chin", "地阁（下巴）", "地閣（下巴）", "顎", "턱", "Cằm", "คาง")],
};

type Observation = { key: string; value: string };

/** Resize in the browser to at most 1024 px on the long side, as JPEG. */
async function resizeImage(file: File): Promise<string> {
  const url = URL.createObjectURL(file);
  try {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => {
      const element = new Image();
      element.onload = () => resolve(element);
      element.onerror = reject;
      element.src = url;
    });
    const scale = Math.min(1, 1024 / Math.max(image.naturalWidth, image.naturalHeight));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
    canvas.getContext("2d")!.drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", 0.85);
  } finally {
    URL.revokeObjectURL(url);
  }
}

function todayIso() {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

export function XiangshuScreen({ locale, wallet, onSpend, onOpenMembership, navigate }: { locale: Locale; wallet: CreditWallet; onSpend: (tool: string) => boolean; onOpenMembership: () => void; navigate: (route: AppRoute) => void }) {
  const available = useVisionAvailable();
  const [kind, setKind] = useState<"palm" | "face">("palm");
  const [hand, setHand] = useState<"left" | "right">("left");
  const [photo, setPhoto] = useState<string | null>(null);
  const [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ text: string; signIn?: boolean } | null>(null);
  const [observations, setObservations] = useState<Observation[] | null>(null);
  const [version, setVersion] = useState(0);

  const pick = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (!/^image\/(jpeg|png|webp|heic|heif)$/.test(file.type) && !/\.(jpe?g|png|webp|heic|heif)$/i.test(file.name)) { setMessage({ text: t.badFile[locale] }); return; }
    try {
      setPhoto(await resizeImage(file));
      setObservations(null);
      setMessage(null);
    } catch {
      setMessage({ text: t.badFile[locale] });
    }
  };

  const analyze = async () => {
    if (!photo || !consent || busy) return;
    setBusy(true);
    setMessage(null);
    try {
      const response = await fetch("/api/vision/observe", { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify({ kind, hand, image: photo, consent: true, locale }) });
      const payload = await response.json().catch(() => ({})) as { valid?: boolean; reason?: string; observations?: Observation[]; code?: string; detail?: string };
      if (response.status === 401) { setMessage({ text: t.signIn[locale], signIn: true }); return; }
      if (payload.code === "VISION_LIMIT") { setMessage({ text: t.limit[locale] }); return; }
      if (payload.code === "VISION_NOT_CONFIGURED") { setMessage({ text: t.unavailable[locale] }); return; }
      if (!response.ok) {
        // Show the provider's status code too, so a screenshot tells the site owner what went wrong.
        const reason = payload.code === "VISION_AUTH_FAILED" ? t.authFailed[locale] : payload.code === "VISION_TIMEOUT" ? t.timeout[locale] : t.failed[locale];
        const code = [payload.code, payload.detail].filter(Boolean).join(" · ") || String(response.status);
        setMessage({ text: `${reason}（${t.errorCode[locale]}：${code}）` });
        return;
      }
      if (payload.valid === false) { setMessage({ text: `${t.invalid[locale]}${payload.reason ? `: ${payload.reason}` : ""}` }); return; }
      setObservations(payload.observations ?? []);
      setVersion((value) => value + 1);
      // The photo is no longer needed once it has been described.
      setPhoto(null);
      setConsent(false);
    } catch {
      setMessage({ text: t.failed[locale] });
    } finally {
      setBusy(false);
    }
  };

  const chart = useMemo<CompleteChart | null>(() => {
    if (!observations?.length) return null;
    const base = createStudyResult({ birthDate: todayIso(), birthTime: "12:00", calendar: "solar", focus: "", name: "", companionName: "", module: "xiangshu", version });
    const english = (key: string) => featureLabels[key]?.[0] ?? key;
    const label = kind === "palm" ? "Palm reading observations" : "Face reading observations";
    return {
      tool: "xiangshu",
      calendar: base.calendar,
      pillars: [],
      board: { kind: "spread", label, cells: observations.map((entry, index) => ({ id: `feature-${index + 1}`, title: english(entry.key), subtitle: entry.value, items: [{ label: english(entry.key), value: entry.value }] })) },
      sections: [
        { id: "photo-observations", title: label, lead: kind === "palm" ? `Visible features of the ${hand} palm, described from one photo` : "Visible facial features, described from one front-facing photo", items: observations.map((entry) => ({ label: english(entry.key), value: entry.value })) },
        { id: "photo-context", title: "Photo context", lead: "What was photographed", items: [{ label: "Subject", value: kind === "palm" ? `${hand === "left" ? "Left" : "Right"} palm` : "Face" }, { label: "Observations", value: String(observations.length) }] },
      ],
      sourceFacts: ["Features described by an image model from one photo; the photo was not stored.", kind === "palm" ? "Palmistry tradition: lines, mounts and hand shape (five-element types)." : "Face reading tradition: three courts, five organs and five-element face types."],
      inputSummary: { focus: "", place: "—", version },
    };
  }, [observations, kind, hand, version]);

  return <section className="route-screen xiangshu-screen" data-route="xiangshu">
    <header className="route-heading">
      <p>{t.kicker[locale]}</p>
      <h1><span>相</span>{t.title[locale]}</h1>
      <p>{t.lead[locale]}</p>
    </header>
    {available === false ? <><p className="xiangshu-closed">{t.unavailable[locale]}</p><MethodHelp helpKey="xiangshu" locale={locale} navigate={navigate} /></> : <>
      <MethodHelp helpKey="xiangshu" locale={locale} navigate={navigate} />
      <div className="xiangshu-layout">
        <div className="xiangshu-form">
          <div className="xiangshu-kind" role="tablist">
            {(["palm", "face"] as const).map((value) => <button type="button" role="tab" aria-selected={kind === value} key={value} className={kind === value ? "active" : ""} onClick={() => { setKind(value); setObservations(null); }}>{t[value][locale]}</button>)}
          </div>
          {kind === "palm" && <fieldset className="xiangshu-hand">
            <legend>{t.hand[locale]}</legend>
            {(["left", "right"] as const).map((value) => <button type="button" key={value} className={hand === value ? "active" : ""} onClick={() => setHand(value)}>{t[value][locale]}</button>)}
            <small>{t.handTip[locale]}</small>
          </fieldset>}
          <p className="xiangshu-tips">{kind === "palm" ? t.tipsPalm[locale] : t.tipsFace[locale]}</p>
          <label className="xiangshu-upload">
            {photo ? <img src={photo} alt="" /> : <span aria-hidden="true">{kind === "palm" ? "✋" : "☺"}</span>}
            <b>{photo ? t.change[locale] : t.choose[locale]}</b>
            <input type="file" accept="image/*" onChange={pick} />
          </label>
          <label className="check-line xiangshu-consent"><input type="checkbox" checked={consent} onChange={(event) => setConsent(event.target.checked)} /><span>{t.consent[locale]}</span></label>
          <button type="button" className="primary-action" disabled={!photo || !consent || busy} onClick={analyze}>{busy ? t.analyzing[locale] : t.analyze[locale]}<b>→</b></button>
          {message && <p className="form-error" role="alert">{message.text}{message.signIn && <> <button type="button" className="text-action" onClick={() => navigate("membership")}>{t.signInAction[locale]} →</button></>}</p>}
        </div>
        <div className="xiangshu-result">
          {observations?.length ? <>
            <h2>{t.observed[locale]}</h2>
            <dl>{observations.map((entry) => <div key={entry.key}><dt>{featureLabels[entry.key]?.[1][locale] ?? entry.key}</dt><dd>{entry.value}</dd></div>)}</dl>
            <small>{t.observedNote[locale]}</small>
            <button type="button" className="text-action" onClick={() => setObservations(null)}>{t.again[locale]} →</button>
          </> : <div className="xiangshu-placeholder" aria-hidden="true">{kind === "palm" ? "掌" : "面"}</div>}
        </div>
      </div>
      {chart && <div className="xiangshu-reading">
        <InterpretationPanel key={version} autoStart chart={chart} locale={locale} wallet={wallet} onSpend={onSpend} onOpenMembership={onOpenMembership} onNavigate={(next) => navigate(next as AppRoute)} />
      </div>}
    </>}
  </section>;
}
