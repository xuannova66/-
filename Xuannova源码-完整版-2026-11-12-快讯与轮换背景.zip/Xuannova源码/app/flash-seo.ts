// Server side of the Xuannova Flash detail page (/{lang}/flash/{slug}): reads the item from the database so the page
// is rendered with its text, title, description, canonical, hreflang for each language it exists in, Open Graph
// "article" tags and NewsArticle structured data.
import type { Metadata } from "next";
import type { FlashItem } from "./flash";
import { SITE_URL } from "./seo";
import { pathFor, type UrlLocale } from "./study-navigation";

export type FlashPageData = { item: FlashItem; locales: UrlLocale[] } | null | "unavailable";

const flashPath = (locale: UrlLocale, slug: string) => `${pathFor(locale, "flash")}/${slug}`;

/** null = no such item; "unavailable" = the database could not be read (the page then loads it in the browser). */
export async function loadFlashPage(slug: string, locale: UrlLocale): Promise<FlashPageData> {
  try {
    const [{ sharedDatabase }, flash] = await Promise.all([import("../server/sqlite-db"), import("../worker/flash")]);
    const db = sharedDatabase() as unknown as import("../worker/flash").FlashDatabase;
    const item = await flash.getFlash(db, slug, locale);
    if (!item) return null;
    return { item: item as unknown as FlashItem, locales: item.locales as UrlLocale[] };
  } catch {
    return "unavailable";
  }
}

export function flashMetadata(data: { item: FlashItem; locales: UrlLocale[] }, locale: UrlLocale): Metadata {
  const { item } = data;
  const title = `${item.text.title} · Xuannova`;
  const description = item.text.summary.slice(0, 160);
  const url = `${SITE_URL}${flashPath(locale, item.slug)}`;
  const languages = Object.fromEntries(data.locales.map((code) => [code, `${SITE_URL}${flashPath(code, item.slug)}`]));
  const image = item.coverUrl ?? `${SITE_URL}/xuannova-og.jpg`;
  return {
    title, description,
    alternates: { canonical: url, languages: { ...languages, "x-default": `${SITE_URL}${flashPath(data.locales.includes("en") ? "en" : data.locales[0] ?? "en", item.slug)}` } },
    openGraph: { type: "article", title: item.text.title, description, url, siteName: "Xuannova", locale, publishedTime: item.publishedAt, modifiedTime: item.updatedAt, images: [{ url: image, alt: item.text.title }] },
    twitter: { card: "summary_large_image", title: item.text.title, description, images: [image] },
  };
}

export function flashStructuredData(item: FlashItem, locale: UrlLocale) {
  const url = `${SITE_URL}${flashPath(locale, item.slug)}`;
  return {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "NewsArticle", headline: item.text.title.slice(0, 110), description: item.text.summary, articleBody: [item.text.body, item.text.quote ? `${item.text.quote} — ${item.text.quoteSource ?? ""}` : ""].filter(Boolean).join("\n"),
        inLanguage: item.locale, datePublished: item.publishedAt, dateModified: item.updatedAt, url, mainEntityOfPage: url,
        image: [item.coverUrl ?? `${SITE_URL}/xuannova-og.jpg`],
        author: { "@type": "Organization", name: "Xuannova", url: SITE_URL },
        publisher: { "@type": "Organization", name: "Xuannova", logo: { "@type": "ImageObject", url: `${SITE_URL}/icon-512.png` } },
        ...(item.sourceUrl ? { isBasedOn: item.sourceUrl } : {}),
      },
      { "@type": "BreadcrumbList", itemListElement: [
        { "@type": "ListItem", position: 1, name: "Xuannova", item: `${SITE_URL}${pathFor(locale, "home")}` },
        { "@type": "ListItem", position: 2, name: "Xuannova Flash", item: `${SITE_URL}${pathFor(locale, "flash")}` },
        { "@type": "ListItem", position: 3, name: item.text.title, item: url },
      ] },
    ],
  };
}
