// After a reading, suggest related methods (cross-method study rather than repeat purchases of the same tool).
import type { Locale } from "./site-content";

type Label = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): Label => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

const LABELS: Record<string, Label> = {
  bazi: L("BaZi chart", "八字排盘", "八字排盤", "四柱推命", "사주팔자", "Bát Tự", "ปาจื้อ"),
  ziwei: L("Zi Wei chart", "紫微斗数", "紫微斗數", "紫微斗数", "자미두수", "Tử Vi", "จื่อเวย"),
  daily: L("Today's rhythm", "每日时序", "每日時序", "今日のリズム", "오늘의 리듬", "Nhịp hôm nay", "จังหวะวันนี้"),
  compatibility: L("Compatibility", "合盘", "合盤", "相性", "궁합", "Hợp tuổi", "ดวงคู่"),
  liuyao: L("Six-line inquiry", "六爻问事", "六爻問事", "六爻占", "육효", "Lục Hào", "ลิ่วเหยา"),
  qimen: L("Qi Men", "奇门遁甲", "奇門遁甲", "奇門遁甲", "기문둔갑", "Kỳ Môn", "ฉีเหมิน"),
  meihua: L("Plum blossom", "梅花易数", "梅花易數", "梅花易数", "매화역수", "Mai Hoa", "เหมยฮวา"),
  jinkoujue: L("Jin Kou Jue", "金口诀", "金口訣", "金口訣", "금구결", "Kim Khẩu Quyết", "จินโข่วเจวี๋ย"),
  heluo: L("He Luo numerology", "河洛理数", "河洛理數", "河洛理数", "하락이수", "Hà Lạc Lý Số", "เหอลั่วหลี่ซู่"),
  taiyi: L("Tai Yi", "太乙神数", "太乙神數", "太乙神数", "태을신수", "Thái Ất", "ไท่อี่"),
  hecan: L("Combined reading", "合参", "合參", "総合鑑定", "종합", "Hợp tham", "อ่านรวม"),
};
const NEXT: Record<string, string[]> = {
  bazi: ["ziwei", "daily", "compatibility"], detail: ["ziwei", "daily", "compatibility"], ziwei: ["bazi", "hecan", "daily"],
  qizheng: ["ziwei", "bazi"], liuyao: ["qimen", "daily"], qimen: ["liuyao", "daily"], daliuren: ["liuyao", "qimen"],
  compatibility: ["bazi", "hecan"], hecan: ["bazi", "ziwei"], wenshi: ["liuyao", "qimen"], mirror: ["daily", "liuyao"], daily: ["bazi", "liuyao"],
  meihua: ["liuyao", "jinkoujue"], jinkoujue: ["daliuren", "meihua"], heluo: ["bazi", "ziwei"], tieban: ["bazi", "heluo"], taiyi: ["qimen", "daily"], zhuzhai: ["bazi", "daily"],
};

export function nextStepRoutes(tool: string) {
  return (NEXT[tool] ?? ["bazi", "daily"]).filter((route) => LABELS[route]).map((route) => ({ route, label: LABELS[route] }));
}
