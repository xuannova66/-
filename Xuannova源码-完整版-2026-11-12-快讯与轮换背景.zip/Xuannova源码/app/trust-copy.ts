// Credibility statements and the short "traditional-culture study" notes, in 7 languages.
// Team facts confirmed by the operator: the founding team has 26 years in Eastern metaphysics and the I Ching;
// 58 mentors take part in content review and in teaching the video courses.
import type { Locale } from "./site-content";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

export const trustText = {
  /** Home hero: professional statement under the headline. */
  heroLead: L(
    "Every chart follows the rules of the classical texts: months set by the solar terms, and time corrected to true solar time when you give your birthplace. Our founding team has spent 26 years in Eastern metaphysics and the I Ching, and 58 mentors review the content and teach the courses.",
    "每一张命盘都严格按典籍规则计算：以节气定月份；填写出生地并选择真太阳时，即按出生地校正时间。创始团队深耕东方命理与易学 26 年，58 位导师参与内容审校与课程讲授。",
    "每一張命盤都嚴格按典籍規則計算：以節氣定月份；填寫出生地並選擇真太陽時，即按出生地校正時間。創始團隊深耕東方命理與易學 26 年，58 位導師參與內容審校與課程講授。",
    "すべての命盤は古典の規則どおりに計算します。月は節気で区切り、出生地を入力して真太陽時を選べば出生地の時刻に補正します。創業チームは東洋の命理と易学に26年携わり、58名の講師が内容の監修と講座を担当しています。",
    "모든 명반은 고전의 규칙대로 계산합니다. 달은 절기로 나누고, 출생지를 입력해 진태양시를 선택하면 출생지 기준으로 시간을 보정합니다. 창립 팀은 동양 명리와 역학에 26년간 매진해 왔으며, 58명의 강사가 콘텐츠 감수와 강의를 맡고 있습니다.",
    "Mỗi lá số đều được tính đúng theo quy tắc kinh điển: tháng theo tiết khí; khi bạn nhập nơi sinh và chọn giờ mặt trời thực, giờ được hiệu chỉnh theo nơi sinh. Đội ngũ sáng lập có 26 năm gắn bó với mệnh lý và Dịch học phương Đông, cùng 58 người hướng dẫn tham gia thẩm định nội dung và giảng dạy.",
    "ทุกผังคำนวณตามกฎของตำราคลาสสิกอย่างเคร่งครัด: แบ่งเดือนตามสารท และเมื่อกรอกสถานที่เกิดพร้อมเลือกเวลาสุริยะจริง จะปรับเวลาตามสถานที่เกิด ทีมผู้ก่อตั้งศึกษาศาสตร์ตะวันออกและอี้จิงมา 26 ปี และมีผู้สอน 58 ท่านร่วมตรวจทานเนื้อหาและสอนคอร์ส",
  ),
  statMethods: L("study methods", "种研习方法", "種研習方法", "の研究方法", "가지 학습 방법", "phương pháp", "วิธีศึกษา"),
  statClassics: L("classics, full text", "部典籍全文", "部典籍全文", "冊の古典全文", "권 고전 전문", "kinh điển toàn văn", "ตำราฉบับเต็ม"),
  statLanguages: L("languages", "种语言", "種語言", "言語", "개 언어", "ngôn ngữ", "ภาษา"),
  /** Footer line (kept short; full terms are in the Terms of Service). */
  footerNote: L(
    "All content on Xuannova is traditional-culture study content, for learning and entertainment.",
    "Xuannova 全部内容为东方传统文化研习内容，供学习与娱乐参考。",
    "Xuannova 全部內容為東方傳統文化研習內容，供學習與娛樂參考。",
    "Xuannova のすべての内容は東洋の伝統文化の研究コンテンツで、学びと楽しみのためのものです。",
    "Xuannova의 모든 콘텐츠는 동양 전통문화 학습 콘텐츠로, 배움과 즐거움을 위한 것입니다.",
    "Toàn bộ nội dung trên Xuannova là nội dung học hỏi văn hóa truyền thống phương Đông, dành cho việc học và giải trí.",
    "เนื้อหาทั้งหมดใน Xuannova เป็นเนื้อหาศึกษาวัฒนธรรมดั้งเดิมตะวันออก เพื่อการเรียนรู้และความบันเทิง",
  ),
  /** One small line under each reading. */
  readingNote: L(
    "This reading is traditional-culture study content.",
    "以上为东方传统文化研习内容。",
    "以上為東方傳統文化研習內容。",
    "以上は東洋の伝統文化の研究コンテンツです。",
    "위 내용은 동양 전통문화 학습 콘텐츠입니다.",
    "Nội dung trên là nội dung học hỏi văn hóa truyền thống phương Đông.",
    "เนื้อหาข้างต้นเป็นเนื้อหาศึกษาวัฒนธรรมดั้งเดิมตะวันออก",
  ),
  /** Footer call to action, replacing the disclaimer that used to sit there. */
  ctaLine: L(
    "Charts calculated by the classical rules, in seven languages. The chart and the first half of every reading are free.",
    "按典籍规则排盘，七种语言。命盘和每份解读的前半部分免费看。",
    "按典籍規則排盤，七種語言。命盤和每份解讀的前半部分免費看。",
    "古典の規則で命盤を作成、7つの言語に対応。命盤と各解説の前半は無料です。",
    "고전의 규칙으로 명반을 만들고 7개 언어를 지원합니다. 명반과 해설 앞부분은 무료입니다.",
    "Lập lá số theo quy tắc kinh điển, bảy ngôn ngữ. Lá số và nửa đầu mỗi bài giải đều miễn phí.",
    "สร้างผังตามกฎตำราคลาสสิก รองรับ 7 ภาษา ผังและครึ่งแรกของทุกคำอธิบายดูฟรี",
  ),
  /** Free full BaZi reading for members (once per account). */
  promo: L("Sign up and read your first full BaZi reading free.", "会员福利：注册即可免费看 1 份完整八字解读。", "會員福利：註冊即可免費看 1 份完整八字解讀。", "会員特典：登録すると八字の完全版解説を1回無料で読めます。", "회원 혜택: 가입하면 사주 전체 해설 1회를 무료로 볼 수 있습니다.", "Ưu đãi thành viên: đăng ký là được xem miễn phí 1 bài giải Bát tự đầy đủ.", "สิทธิ์สมาชิก: สมัครแล้วอ่านคำอธิบายปาจื้อฉบับเต็มฟรี 1 ฉบับ"),
  freeToday: L("Free", "免费", "免費", "無料", "무료", "Miễn phí", "ฟรี"),
  freeFullAction: L("Read the full reading free (member gift)", "免费看完整解读（会员福利）", "免費看完整解讀（會員福利）", "完全版を無料で読む（会員特典）", "전체 해설 무료로 보기(회원 혜택)", "Xem miễn phí bài giải đầy đủ (ưu đãi thành viên)", "อ่านฉบับเต็มฟรี (สิทธิ์สมาชิก)"),
  freeFullBadge: L("Free full reading", "免费完整解读", "免費完整解讀", "無料の完全版", "무료 전체 해설", "Bài giải đầy đủ miễn phí", "ฉบับเต็มฟรี"),
  signUpForFull: L("Sign up as a member to read this full BaZi reading free (once per account).", "注册会员即可免费看这份完整八字解读（每个账号 1 份）。", "註冊會員即可免費看這份完整八字解讀（每個帳號 1 份）。", "会員登録すると、この八字の完全版を無料で読めます（1アカウント1回）。", "회원 가입하면 이 사주 전체 해설을 무료로 볼 수 있습니다(계정당 1회).", "Đăng ký thành viên để xem miễn phí bài giải Bát tự đầy đủ này (mỗi tài khoản 1 lần).", "สมัครสมาชิกเพื่ออ่านคำอธิบายปาจื้อฉบับเต็มนี้ฟรี (บัญชีละ 1 ครั้ง)"),
  noteLabel: L("Note", "说明", "說明", "ご案内", "안내", "Lưu ý", "หมายเหตุ"),
};
