/** Save the current scroll position on the current history entry, so Back can return to it (see restoreScroll in page.tsx). */
export function rememberScroll() {
  if (typeof window === "undefined") return;
  try { window.history.replaceState({ ...(window.history.state ?? {}), scrollY: Math.round(window.scrollY) }, "", window.location.href); } catch { /* ignore */ }
}
