// lunar-javascript ships without type declarations.
declare module "lunar-javascript";
