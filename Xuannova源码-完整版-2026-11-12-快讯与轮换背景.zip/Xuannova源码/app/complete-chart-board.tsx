"use client";

import { ReadingModeToggle } from "./reading-mode";
import { ChartTerm } from "./chart-term";
import { useState, type KeyboardEvent } from "react";
import { createCompleteChart, type CompleteChart } from "./chart-model";
import { lookupChartTerm, translateChartText } from "./metaphysics/terms";
import { lookupChartLabel } from "./metaphysics/labels";
import { formatGlobalLocation } from "./geocoding";
import type { Locale } from "./site-content";
import { uiCopy } from "./ui-copy";

type BoardCopy = { board: string; layers: string; timeline: string; sources: string; unfold: string; close: string; calendar: string; place: string; focus: string; timeBasis: string; civilTime: string; trueSolarTime: string; studyShelf: string; baziMatrix: string; ziweiMatrix: string };

const copy: Record<Locale, BoardCopy> = {
  en: { board: "Complete chart board", layers: "Chart layers", timeline: "Study timeline", sources: "Source facts", unfold: "Open", close: "Close", calendar: "Calendar context", place: "Place", focus: "Focus", timeBasis: "Chart time", civilTime: "Local clock time", trueSolarTime: "True solar time", studyShelf: "Open study shelf", baziMatrix: "BaZi four-pillar chart", ziweiMatrix: "Zi Wei twelve-palace chart" },
  "zh-Hans": { board: "完整盘面", layers: "盘面层级", timeline: "研习时序", sources: "起盘依据", unfold: "展开", close: "收起", calendar: "历法语境", place: "地点", focus: "主题", timeBasis: "排盘时间", civilTime: "当地时间", trueSolarTime: "真太阳时", studyShelf: "查看关联典籍", baziMatrix: "八字四柱盘", ziweiMatrix: "紫微斗数十二宫盘" },
  "zh-Hant": { board: "完整盤面", layers: "盤面層級", timeline: "研習時序", sources: "起盤依據", unfold: "展開", close: "收起", calendar: "曆法語境", place: "地點", focus: "主題", timeBasis: "排盤時間", civilTime: "當地時間", trueSolarTime: "真太陽時", studyShelf: "查看關聯典籍", baziMatrix: "八字四柱盤", ziweiMatrix: "紫微斗數十二宮盤" },
  ja: { board: "完全な盤面", layers: "盤面レイヤー", timeline: "学習の時序", sources: "立局の根拠", unfold: "開く", close: "閉じる", calendar: "暦の文脈", place: "場所", focus: "テーマ", timeBasis: "盤の時刻", civilTime: "現地時刻", trueSolarTime: "真太陽時", studyShelf: "関連する書庫を開く", baziMatrix: "八字四柱盤", ziweiMatrix: "紫微斗数十二宮盤" },
  ko: { board: "완전한 판면", layers: "판면 레이어", timeline: "학습 시점", sources: "기국 근거", unfold: "열기", close: "닫기", calendar: "달력 맥락", place: "장소", focus: "주제", timeBasis: "명반 시각", civilTime: "현지 시각", trueSolarTime: "진태양시", studyShelf: "연결된 서고 열기", baziMatrix: "사주팔자 명반", ziweiMatrix: "자미두수 십이궁 판면" },
  vi: { board: "Bàn hoàn chỉnh", layers: "Lớp bàn cục", timeline: "Nhịp học tập", sources: "Dữ kiện lập cục", unfold: "Mở", close: "Đóng", calendar: "Ngữ cảnh lịch", place: "Địa điểm", focus: "Chủ đề", timeBasis: "Thời gian lập bàn", civilTime: "Giờ địa phương", trueSolarTime: "Giờ Mặt Trời thực", studyShelf: "Mở tủ sách liên quan", baziMatrix: "Bàn Bát Tự Tứ Trụ", ziweiMatrix: "Bàn Tử Vi mười hai cung" },
  th: { board: "กระดานแบบสมบูรณ์", layers: "ชั้นของกระดาน", timeline: "จังหวะการศึกษา", sources: "ข้อมูลอ้างอิงในการตั้งกระดาน", unfold: "เปิด", close: "ปิด", calendar: "บริบทปฏิทิน", place: "สถานที่", focus: "หัวข้อ", timeBasis: "เวลาตั้งผัง", civilTime: "เวลาท้องถิ่น", trueSolarTime: "เวลาสุริยะจริง", studyShelf: "เปิดชั้นหนังสือที่เกี่ยวข้อง", baziMatrix: "ผังปาจื้อสี่เสา", ziweiMatrix: "ผังจื่อเวยสิบสองวัง" },
};

const boardNames: Record<Locale, Record<CompleteChart["board"]["kind"], string>> = {
  en: { pillars: "Four Pillars complete board", "twelve-palace": "Twelve-sector complete board", "nine-palace": "Nine-palace complete board", hexagram: "Six-line complete board", "six-ren": "Heaven-and-earth complete board", spread: "Three-card reflection spread", comparison: "Synthesis study map" },
  "zh-Hans": { pillars: "四柱完整盘", "twelve-palace": "十二宫完整盘", "nine-palace": "九宫完整盘", hexagram: "六爻完整盘", "six-ren": "天地盘完整盘", spread: "三张反思牌阵", comparison: "综合研习图" },
  "zh-Hant": { pillars: "四柱完整盤", "twelve-palace": "十二宮完整盤", "nine-palace": "九宮完整盤", hexagram: "六爻完整盤", "six-ren": "天地盤完整盤", spread: "三張反思牌陣", comparison: "綜合研習圖" },
  ja: { pillars: "四柱の完全盤", "twelve-palace": "十二宮の完全盤", "nine-palace": "九宮の完全盤", hexagram: "六爻の完全盤", "six-ren": "天地盤の完全盤", spread: "三枚の内省スプレッド", comparison: "統合学習マップ" },
  ko: { pillars: "사주 완성 판면", "twelve-palace": "십이궁 완성 판면", "nine-palace": "구궁 완성 판면", hexagram: "육효 완성 판면", "six-ren": "천지반 완성 판면", spread: "세 장 성찰 스프레드", comparison: "통합 학습 지도" },
  vi: { pillars: "Bàn Tứ Trụ hoàn chỉnh", "twelve-palace": "Bàn mười hai cung hoàn chỉnh", "nine-palace": "Bàn chín cung hoàn chỉnh", hexagram: "Bàn sáu hào hoàn chỉnh", "six-ren": "Bàn trời-đất hoàn chỉnh", spread: "Trải bài phản chiếu ba lá", comparison: "Bản đồ học tập tổng hợp" },
  th: { pillars: "กระดานสี่เสาแบบสมบูรณ์", "twelve-palace": "กระดานสิบสองเรือนแบบสมบูรณ์", "nine-palace": "กระดานเก้าวังแบบสมบูรณ์", hexagram: "กระดานหกเส้นแบบสมบูรณ์", "six-ren": "กระดานฟ้า-ดินแบบสมบูรณ์", spread: "ผังไพ่สะท้อนสามใบ", comparison: "แผนผังการศึกษาสังเคราะห์" },
};

const chartLabels: Record<Locale, Record<string, string>> = {
  en: {},
  "zh-Hans": { "Time calibration board": "寻时定盘", "Five Elements balance board": "五行平衡盘", "Dream reflection board": "梦象观照盘", "Name study board": "姓名参详盘", "Compatibility study map": "合盘研习图", "Inquiry synthesis board": "问事研习盘", "Synthesis study map": "综合研习图", "Daily rhythm study field": "每日时序研习场" },
  "zh-Hant": { "Time calibration board": "尋時定盤", "Five Elements balance board": "五行平衡盤", "Dream reflection board": "夢象觀照盤", "Name study board": "姓名參詳盤", "Compatibility study map": "合盤研習圖", "Inquiry synthesis board": "問事研習盤", "Synthesis study map": "綜合研習圖", "Daily rhythm study field": "每日時序研習場" },
  ja: { "Time calibration board": "時刻調整の盤", "Five Elements balance board": "五行バランス盤", "Dream reflection board": "夢の内省盤", "Name study board": "名前の学習盤", "Compatibility study map": "相性学習マップ", "Inquiry synthesis board": "問いの学習盤", "Synthesis study map": "統合学習マップ", "Daily rhythm study field": "日々のリズム学習フィールド" },
  ko: { "Time calibration board": "시간 조정 판면", "Five Elements balance board": "오행 균형 판면", "Dream reflection board": "꿈 성찰 판면", "Name study board": "이름 학습 판면", "Compatibility study map": "궁합 학습 지도", "Inquiry synthesis board": "질문 학습 판면", "Synthesis study map": "통합 학습 지도", "Daily rhythm study field": "일일 리듬 학습 필드" },
  vi: { "Time calibration board": "Bàn hiệu chỉnh thời điểm", "Five Elements balance board": "Bàn cân bằng Ngũ Hành", "Dream reflection board": "Bàn chiêm nghiệm giấc mơ", "Name study board": "Bàn nghiên cứu tên", "Compatibility study map": "Bản đồ nghiên cứu tương hợp", "Inquiry synthesis board": "Bàn nghiên cứu câu hỏi", "Synthesis study map": "Bản đồ học tập tổng hợp", "Daily rhythm study field": "Không gian học nhịp điệu hằng ngày" },
  th: { "Time calibration board": "ผังปรับเวลา", "Five Elements balance board": "ผังสมดุลธาตุทั้งห้า", "Dream reflection board": "ผังใคร่ครวญความฝัน", "Name study board": "ผังศึกษาชื่อ", "Compatibility study map": "แผนผังศึกษาความสอดคล้อง", "Inquiry synthesis board": "ผังศึกษาคำถาม", "Synthesis study map": "แผนผังการศึกษาสังเคราะห์", "Daily rhythm study field": "พื้นที่ศึกษาจังหวะประจำวัน" },
};

const generatedChartLocales = ["zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"] as const;

const generatedChartTermRows: Array<[string, string, string, string, string, string, string]> = [
  ["Four Pillars complete board", "四柱完整盘", "四柱完整盤", "四柱の完全盤", "사주 완성 판면", "Bàn Tứ Trụ hoàn chỉnh", "กระดานสี่เสาแบบสมบูรณ์"],
  ["Twelve-sector celestial board", "十二宫星体盘", "十二宮星體盤", "十二宮の天体盤", "십이궁 천체 판면", "Bàn thiên thể mười hai cung", "ผังดวงดาวสิบสองเรือน"],
  ["Twelve-palace Zi Wei board", "紫微十二宫盘", "紫微十二宮盤", "紫微斗数十二宮盤", "자미두수 십이궁 판면", "Bàn Tử Vi mười hai cung", "ผังจื่อเวยสิบสองวัง"],
  ["Qi Men nine-palace board", "奇门九宫盘", "奇門九宮盤", "奇門遁甲・九宮盤", "기문둔갑 구궁 판면", "Bàn Kỳ Môn chín cung", "ผังฉีเหมินเก้าวัง"],
  ["Liuyao original and transformed hexagram", "六爻本卦变卦盘", "六爻本卦變卦盤", "六爻・本卦と変卦", "육효 본괘·변괘 판면", "Bàn Lục Hào quẻ gốc và quẻ biến", "ผังลิ่วเหยาเหยาเดิมและเหยาแปร"],
  ["Da Liu Ren heaven and earth plates", "大六壬天地盘", "大六壬天地盤", "大六壬・天地盤", "대육임 천지반", "Bàn Thiên Địa Đại Lục Nhâm", "ผังฟ้า-ดินต้าลิ่วเหริน"],
  ["Time calibration board", "寻时定盘", "尋時定盤", "時刻調整の盤", "시간 조정 판면", "Bàn hiệu chỉnh thời điểm", "ผังปรับเวลา"],
  ["Five Elements balance board", "五行平衡盘", "五行平衡盤", "五行バランス盤", "오행 균형 판면", "Bàn cân bằng Ngũ Hành", "ผังสมดุลธาตุทั้งห้า"],
  ["Dream reflection board", "梦象观照盘", "夢象觀照盤", "夢の内省盤", "꿈 성찰 판면", "Bàn chiêm nghiệm giấc mơ", "ผังใคร่ครวญความฝัน"],
  ["Name study board", "姓名参详盘", "姓名參詳盤", "名前の学習盤", "이름 학습 판면", "Bàn nghiên cứu tên", "ผังศึกษาชื่อ"],
  ["Mirror reflection spread", "镜观反思牌阵", "鏡觀反思牌陣", "鏡の内省スプレッド", "거울 성찰 스프레드", "Trải bài phản chiếu gương", "ผังไพ่สะท้อนตน"],
  ["Compatibility study map", "合盘研习图", "合盤研習圖", "相性学習マップ", "궁합 학습 지도", "Bản đồ nghiên cứu tương hợp", "แผนผังศึกษาความสอดคล้อง"],
  ["Inquiry synthesis board", "问事研习盘", "問事研習盤", "問いの学習盤", "질문 학습 판면", "Bàn nghiên cứu câu hỏi", "ผังศึกษาคำถาม"],
  ["Synthesis study map", "综合研习图", "綜合研習圖", "統合学習マップ", "통합 학습 지도", "Bản đồ học tập tổng hợp", "แผนผังการศึกษาสังเคราะห์"],
  ["Daily rhythm study field", "每日时序研习场", "每日時序研習場", "日々のリズム学習フィールド", "일일 리듬 학습 필드", "Không gian học nhịp điệu hằng ngày", "พื้นที่ศึกษาจังหวะประจำวัน"],
  ["Auxiliary star", "辅助星", "輔助星", "補助星", "보조성", "Sao phụ trợ", "ดาวเสริม"],
  ["Auxiliary stars", "辅助星曜", "輔助星曜", "補助星", "보조성", "Các sao phụ trợ", "ดาวเสริม"],
  ["Supplementary stars arranged by pillar", "按柱位列示的辅助星曜", "按柱位列示的輔助星曜", "柱ごとの補助星", "기둥별 보조성", "Các sao phụ trợ theo trụ", "ดาวเสริมตามเสา"],
  ["Twelve pillar shen-sha markers", "十二项柱位神煞", "十二項柱位神煞", "十二の柱別神煞", "열두 항목의 주신살", "Mười hai thần sát theo trụ", "เสินซาสิบสองรายการตามเสา"],
  ["Twelve-stage seasonal sequence", "十二长生时序", "十二長生時序", "十二運の時序", "십이운성 시서", "Trình tự mười hai giai đoạn", "ลำดับสิบสองช่วงชีวิต"],
  ["Four visible branches and their relation map", "四柱地支关系图", "四柱地支關係圖", "四柱地支の関係図", "네 지지 관계도", "Sơ đồ quan hệ bốn Địa Chi", "แผนผังความสัมพันธ์ของสี่กิ่งดิน"],
  ["Planet placement by sector", "十二宫星体落位", "十二宮星體落位", "十二宮の天体配置", "십이궁 천체 배치", "Vị trí thiên thể theo cung", "การวางเทห์ฟ้าตามเรือน"],
  ["Aspect relationship layer", "相位关系层", "相位關係層", "アスペクト関係レイヤー", "상 관계 레이어", "Lớp quan hệ góc", "ชั้นความสัมพันธ์มุมดาว"],
  ["Planetary condition notes", "星体状态记录", "星體狀態記錄", "天体状態の記録", "천체 상태 기록", "Ghi chú trạng thái thiên thể", "บันทึกสภาวะเทห์ฟ้า"],
  ["Support-star and minor-star placement", "辅星与杂曜落位", "輔星與雜曜落位", "補助星・副星の配置", "보조성·부성 배치", "Vị trí phụ tinh và sao phụ", "การวางดาวเสริมและดาวรอง"],
  ["Eight-deity distribution layer", "八神布列层", "八神布列層", "八神の配置レイヤー", "팔신 배치 레이어", "Lớp phân bố Bát Thần", "ชั้นการวางแปดเทพ"],
  ["Gate, star and deity combinations by palace", "九宫门星神组合", "九宮門星神組合", "九宮ごとの門・星・神の組合せ", "구궁별 문·성·신 조합", "Tổ hợp cửa, sao và thần theo cung", "ชุดประตู ดาว และเทพตามวัง"],
  ["Gate and stem pairs across the nine-palace board", "九宫门与天地干配对", "九宮門與天地干配對", "九宮の門と天地干の組合せ", "구궁 문과 천지간 조합", "Cặp cửa và can trên bàn chín cung", "คู่ประตูและก้านฟ้า-ดินบนผังเก้าวัง"],
  ["Six-spirit condition layer", "六神状态层", "六神狀態層", "六神の状態レイヤー", "육신 상태 레이어", "Lớp trạng thái Lục Thần", "ชั้นสภาวะหกวิญญาณ"],
  ["Noble and general distribution layer", "贵人与天将分布层", "貴人與天將分布層", "貴人・天将の配置レイヤー", "귀인·천장 배치 레이어", "Lớp phân bố quý nhân và thiên tướng", "ชั้นการวางผู้สูงศักดิ์และแม่ทัพฟ้า"],
  ["Five-element texture for each dream image", "梦境意象五行层", "夢境意象五行層", "夢のイメージごとの五行", "꿈 이미지별 오행", "Ngũ hành cho từng hình ảnh giấc mơ", "ห้าธาตุของภาพในฝันแต่ละภาพ"],
  ["Five-element associations for name structure", "姓名结构五行关系", "姓名結構五行關係", "名前の構造と五行の関係", "이름 구조와 오행 관계", "Liên hệ Ngũ Hành của cấu trúc tên", "ความสัมพันธ์ห้าธาตุของโครงสร้างชื่อ"],
  ["Five-element layer for the three-card spread", "三张牌阵五行层", "三張牌陣五行層", "三枚スプレッドの五行レイヤー", "세 장 스프레드 오행 레이어", "Lớp Ngũ Hành cho trải bài ba lá", "ชั้นห้าธาตุสำหรับผังไพ่สามใบ"],
  ["Three cards in spread order", "三张牌阵位顺序", "三張牌陣位順序", "三枚スプレッドの配置順", "세 장 스프레드 순서", "Thứ tự ba lá bài", "ลำดับไพ่สามใบ"],
  ["Four-pillar moment retained as the chart anchor", "四柱时刻作为起盘锚点保留", "四柱時刻作為起盤錨點保留", "四柱の時刻を立局の基点として保持", "사주 시각을 명반 기준점으로 유지", "Giữ thời điểm Tứ Trụ làm mốc lập bàn", "เก็บช่วงเวลาสี่เสาเป็นจุดยึดของการตั้งผัง"],
  ["Character form and sound structure held side by side", "字形与音律结构并列呈现", "字形與音律結構並列呈現", "文字の形と音律構造を並べて表示", "글자 형태와 음률 구조를 나란히 표시", "Trình bày song song hình thể chữ và cấu trúc âm", "แสดงรูปอักษรและโครงสร้างเสียงเคียงกัน"],
  ["Visible stem/branch count", "天干地支显见计数", "天干地支顯見計數", "天干・地支の可視数", "천간·지지 가시 수", "Số Can Chi hiển lộ", "จำนวนก้านฟ้าและกิ่งดินที่ปรากฏ"],
  ["Lu · Quan · Ke · Ji study layer", "禄权科忌研习层", "祿權科忌研習層", "禄・権・科・忌の学習レイヤー", "녹·권·과·기 학습 레이어", "Lớp học Lộc Quyền Khoa Kỵ", "ชั้นศึกษาลก ฉวน เคอ จี้"],
  ["Initial · middle · final movement", "初中末传动势", "初中末傳動勢", "初・中・末伝の動き", "초·중·말전의 흐름", "Chuyển động Sơ Trung Mạt truyền", "การเคลื่อนของส่งต้น กลาง ท้าย"],
  ["Origin · present · next gesture", "起点 · 当下 · 下一动作", "起點 · 當下 · 下一動作", "起点・現在・次の所作", "기점·현재·다음 동작", "Khởi nguồn · hiện tại · cử chỉ tiếp theo", "จุดเริ่ม · ปัจจุบัน · การกระทำถัดไป"],
  ["Pillars", "四柱", "四柱", "四柱", "사주", "Tứ Trụ", "สี่เสา"],
  ["Elements", "五行", "五行", "五行", "오행", "Ngũ Hành", "ธาตุทั้งห้า"],
  ["Focus", "主题", "主題", "テーマ", "주제", "Chủ đề", "หัวข้อ"],
  ["Reference", "参照", "參照", "参照", "참고", "Tham chiếu", "ข้อมูลอ้างอิง"],
  ["Method", "方法", "方法", "方法", "방법", "Phương pháp", "วิธี"],
  ["Signal", "信号", "訊號", "兆し", "신호", "Tín hiệu", "สัญญาณ"],
  ["Question anchor", "问题锚点", "問題錨點", "問いの軸", "질문의 기준점", "Trục câu hỏi", "จุดยึดคำถาม"],
  ["Birth structure", "先天结构", "先天結構", "生来の構造", "선천 구조", "Cấu trúc bẩm sinh", "โครงสร้างกำเนิด"],
  ["Palace relationship", "宫位关系", "宮位關係", "宮位の関係", "궁 관계", "Quan hệ cung", "ความสัมพันธ์ของวัง"],
  ["Timing condition", "时序状态", "時序狀態", "時刻の状態", "시점 상태", "Trạng thái thời điểm", "สภาวะเวลา"],
  ["Dialogue map", "对话图谱", "對話圖譜", "対話マップ", "대화 지도", "Bản đồ đối thoại", "แผนผังบทสนทนา"],
  ["Study timeline", "研习时序", "研習時序", "学習の時系列", "학습 시간선", "Dòng thời gian học tập", "ลำดับเวลาการศึกษา"],
  ["Name", "命名", "命名", "名づけ", "이름", "Tên gọi", "ชื่อ"],
  ["Choose", "选择", "選擇", "選ぶ", "선택", "Chọn", "เลือก"],
  ["Three-way reference", "三向参照", "三向參照", "三方向の参照", "삼방향 참고", "Tham chiếu ba chiều", "ข้อมูลอ้างอิงสามทาง"],
  ["Primary", "主线", "主線", "主軸", "주요", "Chính", "หลัก"],
  ["Supporting", "辅助", "輔助", "補助", "보조", "Hỗ trợ", "เสริม"],
  ["Cross-check", "交叉校验", "交叉校驗", "照合", "교차 확인", "Đối chiếu", "ตรวจทาน"],
  ["Alignment", "协调", "協調", "調和", "조화", "Cân chỉnh", "การปรับให้สอดคล้อง"],
  ["Tension", "张力", "張力", "緊張", "긴장", "Căng thẳng", "ความตึง"],
  ["Resource", "资源", "資源", "資源", "자원", "Nguồn lực", "ทรัพยากร"],
  ["Boundary", "边界", "邊界", "境界", "경계", "Ranh giới", "ขอบเขต"],
  ["Transition", "转换", "轉換", "移行", "전환", "Chuyển đổi", "การเปลี่ยนผ่าน"],
  ["Pair context", "双人语境", "雙人語境", "二人の文脈", "두 사람의 맥락", "Bối cảnh cặp đôi", "บริบทของคู่"],
  ["Context", "语境", "語境", "文脈", "맥락", "Bối cảnh", "บริบท"],
  ["Communication", "沟通", "溝通", "対話", "소통", "Giao tiếp", "การสื่อสาร"],
  ["Rhythm", "节律", "節律", "リズム", "리듬", "Nhịp điệu", "จังหวะ"],
  ["Next step", "下一步", "下一步", "次の一歩", "다음 단계", "Bước tiếp theo", "ก้าวถัดไป"],
  ["Month command", "月令", "月令", "月令", "월령", "Nguyệt lệnh", "เดือนบัญชา"],
  ["Yin", "阴", "陰", "陰", "음", "Âm", "หยิน"],
  ["Yang", "阳", "陽", "陽", "양", "Dương", "หยาง"],
  ["Parents", "父母", "父母", "父母", "부모", "Phụ Mẫu", "บิดามารดา"],
  ["Children", "子孙", "子孫", "子孫", "자손", "Tử Tôn", "บุตรหลาน"],
  ["Siblings", "兄弟", "兄弟", "兄弟", "형제", "Huynh Đệ", "พี่น้อง"],
  ["Officials", "官鬼", "官鬼", "官鬼", "관귀", "Quan Quỷ", "ขุนนางและภูต"],
  ["Wealth", "妻财", "妻財", "妻財", "처재", "Thê Tài", "ทรัพย์"],
  ["Self", "世", "世", "世", "세응의 세", "Thế", "โลก"],
  ["Response", "应", "應", "応", "응", "Ứng", "คู่ตอบ"],
  ["Azure Dragon", "青龙", "青龍", "青龍", "청룡", "Thanh Long", "มังกรฟ้า"],
  ["Vermilion Bird", "朱雀", "朱雀", "朱雀", "주작", "Chu Tước", "วิหคชาด"],
  ["Gou Chen", "勾陈", "勾陳", "勾陳", "구진", "Câu Trần", "โกวเฉิน"],
  ["Teng She", "螣蛇", "螣蛇", "螣蛇", "등사", "Đằng Xà", "เถิงเสอ"],
  ["White Tiger", "白虎", "白虎", "白虎", "백호", "Bạch Hổ", "พยัคฆ์ขาว"],
  ["Black Tortoise", "玄武", "玄武", "玄武", "현무", "Huyền Vũ", "เต่าดำ"],
  ["Still", "静", "靜", "静", "고요", "Tĩnh", "นิ่ง"],
  ["Moving", "动", "動", "動", "움직임", "Động", "เคลื่อน"],
  ["Carries through", "承接", "承接", "受け継ぐ", "이어짐", "Tiếp nối", "สืบต่อ"],
  ["From moving line", "动爻所化", "動爻所化", "動爻からの変化", "동효에서 변함", "Từ hào động", "จากเส้นเคลื่อน"],
  ["Change focus", "变动焦点", "變動焦點", "変化の焦点", "변화의 초점", "Trọng tâm biến đổi", "จุดเน้นการเปลี่ยน"],
  ["Inquiry relationship layer", "问事关系层", "問事關係層", "問いの関係レイヤー", "질문의 관계 레이어", "Lớp quan hệ câu hỏi", "ชั้นความสัมพันธ์ของคำถาม"],
  ["Six-spirit condition layer", "六神状态层", "六神狀態層", "六神の状態レイヤー", "육신 상태 레이어", "Lớp trạng thái Lục Thần", "ชั้นสภาวะหกวิญญาณ"],
  ["Void and response", "空亡与应位", "空亡與應位", "空亡と応位", "공망과 응위", "Không vong và Ứng", "ว่างและคู่ตอบ"],
  ["Timing reference", "本地时序参照", "本地時序參照", "現地時刻の参照", "현지 시점 참고", "Tham chiếu thời điểm địa phương", "ข้อมูลอ้างอิงเวลาในพื้นที่"],
  ["Travel", "迁移", "遷移", "遷移", "천이", "Thiên Di", "การย้ายถิ่น"],
  ["Allies", "交友", "交友", "交友", "교우", "Nô Bộc", "มิตรสหาย"],
  ["Partnership", "夫妻", "夫妻", "夫妻", "부처", "Phu Thê", "คู่ครอง"],
  ["Career", "官禄", "官祿", "官禄", "관록", "Quan Lộc", "การงาน"],
  ["Property", "田宅", "田宅", "田宅", "전택", "Điền Trạch", "อสังหาริมทรัพย์"],
  ["Fortune", "福德", "福德", "福徳", "복덕", "Phúc Đức", "บุญวาสนา"],
  ["Health", "疾厄", "疾厄", "疾厄", "질액", "Tật Ách", "สุขภาพ"],
  ["Quan", "权", "權", "権", "권", "Quyền", "ฉวน"],
  ["Ke", "科", "科", "科", "과", "Khoa", "เคอ"],
  ["Ji", "忌", "忌", "忌", "기", "Kỵ", "จี้"],
  ["Lu", "禄", "祿", "禄", "녹", "Lộc", "ลก"],
  ["Duty chief", "值符", "值符", "直符", "직부", "Trực Phù", "จื่อฝู"],
  ["Time stem", "时干", "時干", "時干", "시간 천간", "Can giờ", "ก้านเวลา"],
  ["Initial", "初传", "初傳", "初伝", "초전", "Sơ truyền", "การส่งต้น"],
  ["Middle", "中传", "中傳", "中伝", "중전", "Trung truyền", "การส่งกลาง"],
  ["Final", "末传", "末傳", "末伝", "말전", "Mạt truyền", "การส่งท้าย"],
  ["Nobles and generals", "贵人与将神", "貴人與將神", "貴人と将神", "귀인과 장신", "Quý nhân và tướng thần", "ผู้สูงศักดิ์และแม่ทัพ"],
  ["Noble branch", "贵人地支", "貴人地支", "貴人の地支", "귀인 지지", "Chi của quý nhân", "กิ่งดินของผู้สูงศักดิ์"],
  ["Year", "年", "年", "年", "년", "Năm", "ปี"],
  ["Month", "月", "月", "月", "월", "Tháng", "เดือน"],
  ["Day", "日", "日", "日", "일", "Ngày", "วัน"],
  ["Hour", "时", "時", "時", "시", "Giờ", "ยาม"],
  ["Question", "问题", "問題", "問い", "질문", "Câu hỏi", "คำถาม"],
  ["Line set", "爻组", "爻組", "爻の組", "효 구성", "Tập hào", "ชุดเส้น"],
  ["Choice", "选择", "選擇", "選択", "선택", "Lựa chọn", "ทางเลือก"],
  ["Constraint", "约束", "約束", "制約", "제약", "Ràng buộc", "ข้อจำกัด"],
  ["Describe", "描述", "描述", "記述", "묘사", "Mô tả", "บรรยาย"],
  ["Revisit", "回看", "回看", "振り返る", "되돌아보기", "Xem lại", "ทบทวน"],
  ["Prompt", "提示", "提示", "問いかけ", "질문", "Gợi ý", "คำชวนคิด"],
  ["Position", "位置", "位置", "位置", "위치", "Vị trí", "ตำแหน่ง"],
  ["Axis", "轴线", "軸線", "軸", "축", "Trục", "แกน"],
  ["Inner", "内在", "內在", "内側", "내면", "Bên trong", "ภายใน"],
  ["Outer", "外在", "外在", "外側", "외면", "Bên ngoài", "ภายนอก"],
  ["Study key", "研习要点", "研習要點", "学習の鍵", "학습 핵심", "Điểm học tập", "หัวใจการศึกษา"],
  ["Present", "当下", "當下", "現在", "현재", "Hiện tại", "ปัจจุบัน"],
  ["Next gesture", "下一动作", "下一動作", "次の所作", "다음 동작", "Cử chỉ tiếp theo", "การกระทำถัดไป"],
  ["Still Water", "静水", "靜水", "静かな水", "고요한 물", "Nước tĩnh", "น้ำนิ่ง"],
  ["The Lantern", "明灯", "明燈", "灯火", "등불", "Ngọn đèn", "โคมไฟ"],
  ["The Garden", "花园", "花園", "庭園", "정원", "Khu vườn", "สวน"],
  ["The Mountain", "山岳", "山嶽", "山", "산", "Ngọn núi", "ภูเขา"],
  ["The Gate", "门扉", "門扉", "門", "문", "Cánh cổng", "ประตู"],
  ["The Vessel", "器皿", "器皿", "器", "그릇", "Chiếc bình", "ภาชนะ"],
  ["Threshold", "门槛", "門檻", "敷居", "문턱", "Ngưỡng cửa", "ธรณี"],
  ["Returning Light", "归光", "歸光", "戻る光", "되돌아오는 빛", "Ánh sáng trở về", "แสงหวนกลับ"],
  ["The Thread", "线索", "線索", "糸", "실마리", "Sợi chỉ", "เส้นด้าย"],
  ["Alert", "警觉", "警覺", "注意", "경계", "Cảnh giác", "ตื่นรู้"],
  ["Figure", "人物", "人物", "人物", "인물", "Hình tượng", "บุคคล"],
  ["Write", "书写", "書寫", "書く", "쓰기", "Viết", "เขียน"],
  ["Tender", "柔和", "柔和", "やわらかさ", "부드러움", "Dịu dàng", "อ่อนโยน"],
  ["Wood", "木", "木", "木", "목", "Mộc", "ไม้"],
  ["Fire", "火", "火", "火", "화", "Hỏa", "ไฟ"],
  ["Earth", "土", "土", "土", "토", "Thổ", "ดิน"],
  ["Metal", "金", "金", "金", "금", "Kim", "โลหะ"],
  ["Water", "水", "水", "水", "수", "Thủy", "น้ำ"],
  ["Express", "表达", "表達", "表現", "표현", "Biểu đạt", "แสดงออก"],
  ["Ground", "安定", "安定", "安定", "안정", "Ổn định", "ตั้งหลัก"],
  ["Refine", "精炼", "精煉", "磨く", "다듬기", "Tinh luyện", "กลั่นเกลา"],
  ["Clear", "清明", "清明", "明晰", "명료", "Rõ sáng", "ชัดเจน"],
  ["Reframe", "重构", "重構", "捉え直す", "재구성", "Định khung lại", "ปรับกรอบใหม่"],
  ["Move", "行动", "行動", "動く", "움직이기", "Hành động", "เคลื่อนไป"],
  ["Sustain", "延续", "延續", "保つ", "유지", "Duy trì", "คงไว้"],
  ["Structure", "结构", "結構", "構造", "구조", "Cấu trúc", "โครงสร้าง"],
  ["Begin", "开始", "開始", "始める", "시작", "Bắt đầu", "เริ่มต้น"],
  ["Balance", "平衡", "平衡", "均衡", "균형", "Cân bằng", "สมดุล"],
  ["Measured", "有度", "有度", "節度", "절제", "Chừng mực", "พอดี"],
  ["Connect", "连接", "連接", "つなぐ", "연결", "Kết nối", "เชื่อมโยง"],
  ["Soft", "柔和", "柔和", "やわらかい", "부드러움", "Mềm mại", "อ่อนโยน"],
  ["Sun", "太阳", "太陽", "太陽", "태양", "Mặt Trời", "ดวงอาทิตย์"],
  ["Moon", "月亮", "月亮", "月", "달", "Mặt Trăng", "ดวงจันทร์"],
  ["Mercury", "水星", "水星", "水星", "수성", "Thủy Tinh", "ดาวพุธ"],
  ["Venus", "金星", "金星", "金星", "금성", "Kim Tinh", "ดาวศุกร์"],
  ["Mars", "火星", "火星", "火星", "화성", "Hỏa Tinh", "ดาวอังคาร"],
  ["Jupiter", "木星", "木星", "木星", "목성", "Mộc Tinh", "ดาวพฤหัสบดี"],
  ["Saturn", "土星", "土星", "土星", "토성", "Thổ Tinh", "ดาวเสาร์"],
  ["Rahu", "罗睺", "羅睺", "ラーフ", "라후", "La Hầu", "ราหู"],
  ["Ketu", "计都", "計都", "ケートゥ", "케ตุ", "Kế Đô", "เกตุ"],
  ["Ascendant", "上升点", "上升點", "アセンダント", "상승점", "Điểm Mọc", "ลัคนา"],
  ["Midheaven", "天顶", "天頂", "天頂", "천정", "Thiên Đỉnh", "จุดกึ่งฟ้า"],
  ["Node", "交点", "交點", "交点", "교점", "Nút Giao", "จุดตัด"],
  ["Air", "风", "風", "風", "풍", "Khí", "ลม"],
  ["Conjoin", "合相", "合相", "合", "합", "Hợp", "กุม"],
  ["Rising", "上升", "上升", "上昇", "상승", "Đi lên", "กำลังขึ้น"],
  ["Culminating", "高点", "高點", "頂点", "정점", "Cao điểm", "จุดสูงสุด"],
  ["Setting", "落下", "落下", "沈む", "하강", "Lặn", "กำลังตก"],
  ["Deepening", "深化", "深化", "深まる", "심화", "Đi sâu", "ลึกขึ้น"],
  ["Harmonizing", "调和", "調和", "調和", "조화", "Hòa hợp", "กลมกลืน"],
  ["Retreating", "退行", "退行", "後退", "후퇴", "Lùi lại", "ถอย"],
  ["Dawn", "黎明", "黎明", "夜明け", "새벽", "Bình minh", "รุ่งอรุณ"],
  ["Noon", "正午", "正午", "正午", "정오", "Buổi trưa", "เที่ยง"],
  ["Dusk", "黄昏", "黃昏", "夕暮れ", "황혼", "Hoàng hôn", "ยามเย็น"],
  ["Midnight", "子夜", "子夜", "真夜中", "자정", "Nửa đêm", "เที่ยงคืน"],
];

const generatedNarrativeTermRows: Array<[string, string, string, string, string, string, string]> = [
  ["A simple rhythm layer for reflective name study", "用于姓名研习的简明节律层", "用於姓名研習的簡明節律層", "名前を省みるための簡潔なリズム層", "이름 성찰을 위한 간단한 리듬 레이어", "Lớp nhịp điệu đơn giản để chiêm nghiệm tên", "ชั้นจังหวะอย่างง่ายเพื่อศึกษาชื่อ"],
  ["Add a second profile to extend this layer.", "添加第二份资料以展开本层。", "新增第二份資料以展開本層。", "2人目のプロフィールを追加するとこの層が展開します。", "두 번째 프로필을 추가하면 이 레이어가 확장됩니다.", "Thêm hồ sơ thứ hai để mở rộng lớp này.", "เพิ่มโปรไฟล์ที่สองเพื่อขยายชั้นนี้"],
  ["An original comparison of structure, condition and timing", "结构、状态与时序的合参", "結構、狀態與時序的合參", "構造・状態・時序の比較", "구조·상태·시점의 비교", "So sánh về cấu trúc, trạng thái và thời điểm", "การเปรียบเทียบโครงสร้าง สภาวะ และจังหวะเวลา"],
  ["Civil time, solar reference and hour branch held together", "民用时、真太阳时与时支并列", "民用時、真太陽時與時支並列", "民用時・太陽時・時支を並記", "민용시·태양시·시지를 함께 표시", "Giờ dân dụng, giờ mặt trời và chi giờ đặt cạnh nhau", "เวลาราชการ เวลาสุริยะ และกิ่งชั่วโมงวางคู่กัน"],
  ["Day and night noble locations on the twelve-position field", "昼夜贵人在十二地分的位置", "晝夜貴人在十二地分的位置", "十二位置における昼夜の貴人", "12위치의 주야 귀인 위치", "Vị trí quý nhân ngày và đêm trên mười hai địa phận", "ตำแหน่งผู้สูงศักดิ์กลางวันและกลางคืนในสิบสองตำแหน่ง"],
  ["Deity distribution across the complete palace board", "八神在全盘的分布", "八神在全盤的分布", "盤全体の八神配置", "전체 판면의 팔신 배치", "Phân bố Bát thần trên toàn bàn", "การกระจายของแปดเทพทั่วทั้งผัง"],
  ["Fire, earth, air and water reference across twelve sectors", "十二分区的火、土、风、水参照", "十二分區的火、土、風、水參照", "十二区分の火・地・風・水", "12구역의 불·흙·공기·물 참조", "Tham chiếu Hỏa, Thổ, Khí, Thủy trên mười hai khu", "อ้างอิงธาตุไฟ ดิน ลม น้ำ ในสิบสองส่วน"],
  ["Four attention lanes held alongside the selected name", "围绕所选姓名的四条观察线", "圍繞所選姓名的四條觀察線", "選んだ名前に沿う四つの観察軸", "선택한 이름에 따른 네 가지 관찰 축", "Bốn hướng quan sát quanh tên đã chọn", "สี่แนวสังเกตรอบชื่อที่เลือก"],
  ["Four intentional axes for a grounded paired reflection", "用于双人回顾的四条意向轴", "用於雙人回顧的四條意向軸", "二人の振り返りのための四つの軸", "두 사람의 성찰을 위한 네 가지 축", "Bốn trục ý định cho chiêm nghiệm cặp đôi", "สี่แกนเจตนาสำหรับการทบทวนแบบคู่"],
  ["Four lessons connected to the active earth-heaven plate positions", "与天地盘对应的四课", "與天地盤對應的四課", "天地盤に対応する四課", "천지반에 대응하는 사과", "Tứ khóa gắn với vị trí thiên địa bàn", "สี่บทที่เชื่อมกับตำแหน่งแผ่นฟ้าดิน"],
  ["Four public three-harmony group references across the twelve palaces", "十二宫的四组三合参照", "十二宮的四組三合參照", "十二宮の三合四組", "12궁의 삼합 네 조", "Bốn nhóm tam hợp trên mười hai cung", "สี่กลุ่มสามประสานในสิบสองวัง"],
  ["Four-pillar, element and timing references held in one comparison", "四柱、五行与时序的合并对照", "四柱、五行與時序的合併對照", "四柱・五行・時序をひとつに比較", "사주·오행·시점을 하나로 비교", "Tứ Trụ, Ngũ Hành và thời điểm trong một so sánh", "สี่เสา ธาตุ และจังหวะเวลาในการเปรียบเทียบเดียว"],
  ["General layer around the local heaven-and-earth plates", "围绕天地盘的天将层", "圍繞天地盤的天將層", "天地盤を囲む天将の層", "천지반을 둘러싼 천장 레이어", "Lớp thiên tướng quanh thiên địa bàn", "ชั้นแม่ทัพฟ้ารอบแผ่นฟ้าดิน"],
  ["Board stem pairing", "盘干支配对", "盤干支配對", "盤の干支の組み合わせ", "판면의 간지 짝", "Ghép can chi trên bàn", "การจับคู่ก้านฟ้าบนผัง"],
  ["Calendar reference for the inquiry moment", "起卦时刻的历法参照", "起卦時刻的曆法參照", "問いの時刻の暦参照", "질문 시점의 달력 참조", "Tham chiếu lịch tại thời điểm hỏi", "อ้างอิงปฏิทิน ณ เวลาที่ตั้งคำถาม"],
  ["Local condition notes across the twelve palace field", "十二宫的状态记录", "十二宮的狀態記錄", "十二宮の状態メモ", "12궁의 상태 메모", "Ghi chú trạng thái trên mười hai cung", "บันทึกสภาวะในสิบสองวัง"],
  ["Local duty-chief, duty-gate and time markers", "值符、值使与时序标记", "值符、值使與時序標記", "値符・値使・時のマーカー", "치부·치사·시간 표식", "Trực phù, trực sử và dấu thời gian", "ผู้ดูแล ประตูดูแล และเครื่องหมายเวลา"],
  ["Timing reference for observing ten-year cycles", "用于观察大运的时序参照", "用於觀察大運的時序參照", "大運を観察するための時序参照", "대운 관찰을 위한 시점 참조", "Tham chiếu thời điểm để quan sát đại vận", "อ้างอิงเวลาเพื่อสังเกตรอบสิบปี"],
  ["Month, day and hour branches used as a local inquiry frame", "以月、日、时支作为起卦框架", "以月、日、時支作為起卦框架", "月支・日支・時支を問いの枠組みに", "월·일·시지를 질문 틀로 사용", "Chi tháng, ngày, giờ làm khung hỏi", "กิ่งเดือน วัน ชั่วโมง เป็นกรอบการถาม"],
  ["Nine timing marks for a deliberate next step", "九个时序标记，用于审慎的下一步", "九個時序標記，用於審慎的下一步", "次の一歩のための九つの時のマーク", "신중한 다음 단계를 위한 아홉 가지 시점 표식", "Chín dấu thời điểm cho bước tiếp theo", "เก้าเครื่องหมายเวลาสำหรับก้าวต่อไป"],
  ["Nine palace position, direction, branch and element", "九宫位置、方位、地支与五行", "九宮位置、方位、地支與五行", "九宮の位置・方位・地支・五行", "구궁 위치·방위·지지·오행", "Vị trí Cửu cung, phương hướng, địa chi và ngũ hành", "ตำแหน่งเก้าวัง ทิศ กิ่งดิน และธาตุ"],
  ["Nine-star distribution across the complete palace board", "九星在全盘的分布", "九星在全盤的分布", "盤全体の九星配置", "전체 판면의 구성 배치", "Phân bố Cửu tinh trên toàn bàn", "การกระจายของเก้าดาวทั่วทั้งผัง"],
  ["Observe, describe, choose and revisit without treating the result as fixed", "观察、描述、选择、回顾，不把结果当作定论", "觀察、描述、選擇、回顧，不把結果當作定論", "観察・記述・選択・再訪、結果を固定しない", "관찰·서술·선택·재방문, 결과를 고정하지 않기", "Quan sát, mô tả, lựa chọn, xem lại — không coi kết quả là cố định", "สังเกต บรรยาย เลือก และทบทวน โดยไม่ถือผลเป็นที่สิ้นสุด"],
  ["Open, gather, observe and return as a study rhythm", "开启、收集、观察、回归的研习节律", "開啟、收集、觀察、回歸的研習節律", "開く・集める・観察する・戻るという学習リズム", "열기·모으기·관찰·돌아오기의 학습 리듬", "Mở ra, thu thập, quan sát và trở về như một nhịp học", "เปิด รวบรวม สังเกต และกลับมา เป็นจังหวะการศึกษา"],
  ["Personal reflection prompts, not a fixed judgment", "个人回顾提示，而非定论", "個人回顧提示，而非定論", "個人的な振り返りの問い、断定ではない", "개인 성찰 질문, 확정 판단 아님", "Gợi ý chiêm nghiệm cá nhân, không phải phán quyết", "คำถามชวนคิดส่วนตัว ไม่ใช่คำตัดสิน"],
  ["Question, timing and line references remain distinct before reflection", "问题、时序与爻位在回顾前分别记录", "問題、時序與爻位在回顧前分別記錄", "問い・時序・爻を分けて記録してから振り返る", "질문·시점·효를 구분한 뒤 성찰", "Câu hỏi, thời điểm và hào được tách riêng trước khi chiêm nghiệm", "แยกคำถาม เวลา และเส้นกว้าก่อนทบทวน"],
  ["Questions that connect images with current experience", "把意象与当下经验连接起来的问题", "把意象與當下經驗連接起來的問題", "イメージと今の経験をつなぐ問い", "이미지와 현재 경험을 잇는 질문", "Những câu hỏi nối hình ảnh với trải nghiệm hiện tại", "คำถามที่เชื่อมภาพกับประสบการณ์ปัจจุบัน"],
  ["Questions that connect the three positions without a fixed forecast", "连接三个位置的问题，不作固定预测", "連接三個位置的問題，不作固定預測", "三つの位置をつなぐ問い、予測は固定しない", "세 위치를 잇는 질문, 고정된 예측 없음", "Câu hỏi nối ba vị trí mà không dự báo cố định", "คำถามที่เชื่อมสามตำแหน่งโดยไม่ทำนายตายตัว"],
  ["Resting", "休整", "休整", "休息", "휴식", "Nghỉ ngơi", "พักผ่อน"],
  ["Share", "分享", "分享", "共有", "공유", "Chia sẻ", "แบ่งปัน"],
  ["Seasonal status carried across the five-element board", "五行盘上的旺相休囚状态", "五行盤上的旺相休囚狀態", "五行盤に反映した季節の旺相休囚", "오행 판면의 계절 왕상휴수", "Trạng thái vượng tướng hưu tù trên bàn ngũ hành", "สถานะตามฤดูกาลบนผังห้าธาตุ"],
  ["Seasonal term references around the selected moment", "所选时刻前后的节气参照", "所選時刻前後的節氣參照", "選んだ時刻前後の節気", "선택한 시점 전후의 절기", "Tiết khí quanh thời điểm đã chọn", "อ้างอิงฤดูกาลย่อยรอบเวลาที่เลือก"],
  ["Six hidden-spirit references paired with the original line set", "与本卦六爻对应的六神", "與本卦六爻對應的六神", "本卦の六爻に対応する六神", "본괘 여섯 효에 대응하는 육신", "Lục thần gắn với sáu hào quẻ gốc", "หกเทพซ่อนที่จับคู่กับเส้นกว้าเดิม"],
  ["Six line positions are retained with their yin-yang state and calendar frame", "六爻及其阴阳与历法框架完整保留", "六爻及其陰陽與曆法框架完整保留", "六爻の陰陽と暦の枠組みを保持", "여섯 효의 음양과 달력 틀 유지", "Sáu hào giữ nguyên trạng thái âm dương và khung lịch", "คงหกเส้นพร้อมสถานะหยินหยางและกรอบปฏิทิน"],
  ["Six local line positions after moving-line transformation", "动爻变化后的六爻", "動爻變化後的六爻", "動爻変化後の六爻", "동효 변화 후의 여섯 효", "Sáu hào sau khi hào động biến", "หกเส้นหลังการแปรของเส้นเคลื่อน"],
  ["Six local line positions before transformation", "变化前的六爻", "變化前的六爻", "変化前の六爻", "변화 전의 여섯 효", "Sáu hào trước khi biến", "หกเส้นก่อนการแปร"],
  ["Six opposing-sector pairs held as an orientation frame", "六组对宫作为定向框架", "六組對宮作為定向框架", "六組の対向セクターを方位の枠に", "여섯 쌍의 대궁을 방향 틀로", "Sáu cặp khu đối diện làm khung định hướng", "หกคู่ส่วนตรงข้ามเป็นกรอบทิศทาง"],
  ["Six paired palace axes for comparative observation", "用于对照观察的六组宫位轴线", "用於對照觀察的六組宮位軸線", "比較観察のための六つの宮の軸", "비교 관찰을 위한 여섯 궁 축", "Sáu trục cung ghép đôi để quan sát đối chiếu", "หกแกนวังคู่เพื่อสังเกตเปรียบเทียบ"],
  ["Small grounded gestures, not predictive instructions", "细微务实的行动，而非预测指令", "細微務實的行動，而非預測指令", "小さく着実な行動、予言的な指示ではない", "작고 현실적인 행동, 예측 지시 아님", "Những hành động nhỏ thiết thực, không phải chỉ dẫn tiên đoán", "การกระทำเล็ก ๆ ที่ติดดิน ไม่ใช่คำสั่งทำนาย"],
  ["Solar, lunar, day branch and hour branch details", "公历、农历、日支与时支", "公曆、農曆、日支與時支", "太陽暦・太陰暦・日支・時支", "양력·음력·일지·시지", "Dương lịch, âm lịch, chi ngày và chi giờ", "สุริยคติ จันทรคติ กิ่งวัน และกิ่งชั่วโมง"],
  ["Solar-lunar calendar context retained alongside the sector field", "分区图旁保留的公历农历语境", "分區圖旁保留的公曆農曆語境", "セクター図とともに保持する暦の文脈", "구역도와 함께 유지되는 양·음력 문맥", "Ngữ cảnh dương-âm lịch giữ cạnh bản đồ khu", "บริบทปฏิทินสุริย-จันทร์ที่คงไว้ข้างผังส่วน"],
  ["Stem and branch references for each elemental lane", "各五行对应的干支参照", "各五行對應的干支參照", "各五行に対応する干支", "각 오행에 해당하는 간지", "Can chi tương ứng với từng hành", "ก้านฟ้ากิ่งดินของแต่ละธาตุ"],
  ["Support and minor stars", "辅星与杂曜", "輔星與雜曜", "補助星と雑曜", "보조성과 잡요", "Sao phụ trợ và sao thứ", "ดาวเสริมและดาวรอง"],
  ["The observed situation is separated into context, choice and next action", "将所观察的处境分为背景、选择与下一步", "將所觀察的處境分為背景、選擇與下一步", "状況を文脈・選択・次の行動に分ける", "상황을 맥락·선택·다음 행동으로 나눔", "Tình huống được tách thành bối cảnh, lựa chọn và bước tiếp", "แยกสถานการณ์เป็นบริบท ทางเลือก และก้าวถัดไป"],
  ["The selected focus stays visible throughout the reflection", "所选主题在整个回顾中保持可见", "所選主題在整個回顧中保持可見", "選んだテーマは振り返りの間ずっと表示", "선택한 주제가 성찰 내내 표시됨", "Chủ đề đã chọn luôn hiển thị trong suốt chiêm nghiệm", "หัวข้อที่เลือกจะแสดงตลอดการทบทวน"],
  ["The three positions are read in order, then returned to the original question", "依次阅读三个位置，再回到最初的问题", "依次閱讀三個位置，再回到最初的問題", "三つの位置を順に読み、元の問いに戻る", "세 위치를 차례로 읽고 원래 질문으로 돌아감", "Đọc ba vị trí theo thứ tự rồi trở về câu hỏi ban đầu", "อ่านสามตำแหน่งตามลำดับแล้วกลับสู่คำถามเดิม"],
  ["The two profiles remain distinguishable at every pillar position", "两份资料在每一柱都可区分", "兩份資料在每一柱都可區分", "二人のプロフィールは各柱で区別できる", "두 프로필은 각 기둥에서 구분됨", "Hai hồ sơ luôn phân biệt được ở mỗi trụ", "สองโปรไฟล์แยกแยะได้ในทุกเสา"],
  ["Three image anchors for a non-deterministic reflection", "用于开放式回顾的三个意象锚点", "用於開放式回顧的三個意象錨點", "断定しない振り返りのための三つのイメージ", "열린 성찰을 위한 세 가지 이미지 기준점", "Ba hình ảnh neo cho chiêm nghiệm mở", "สามภาพยึดสำหรับการทบทวนแบบเปิด"],
  ["Timing and condition layer", "时序与状态层", "時序與狀態層", "時序と状態の層", "시점과 상태 레이어", "Lớp thời điểm và trạng thái", "ชั้นจังหวะเวลาและสภาวะ"],
  ["Twelve branch interaction references around the earth and heaven plates", "天地盘上十二地支的互动参照", "天地盤上十二地支的互動參照", "天地盤における十二支の相互作用", "천지반의 십이지 상호작용", "Tương tác mười hai địa chi trên thiên địa bàn", "ปฏิสัมพันธ์สิบสองกิ่งดินบนแผ่นฟ้าดิน"],
  ["Twelve palace branch references", "十二宫地支", "十二宮地支", "十二宮の地支", "12궁 지지", "Địa chi mười hai cung", "กิ่งดินสิบสองวัง"],
  ["Twelve palace stem references", "十二宫天干", "十二宮天干", "十二宮の天干", "12궁 천간", "Thiên can mười hai cung", "ก้านฟ้าสิบสองวัง"],
  ["Twelve-palace local ten-year rhythm table", "十二宫大限表", "十二宮大限表", "十二宮の大限表", "12궁 대한표", "Bảng đại hạn mười hai cung", "ตารางรอบสิบปีสิบสองวัง"],
  ["Twenty-eight-mansion cultural reference layer", "二十八宿文化参照层", "二十八宿文化參照層", "二十八宿の文化参照層", "이십팔수 문화 참조 레이어", "Lớp tham chiếu văn hóa Nhị thập bát tú", "ชั้นอ้างอิงวัฒนธรรมยี่สิบแปดนักษัตร"],
  ["Upper and lower trigram references for the original and changed hexagrams", "本卦与变卦的上下卦", "本卦與變卦的上下卦", "本卦・変卦の上卦と下卦", "본괘·변괘의 상괘와 하괘", "Thượng quái và hạ quái của quẻ gốc và quẻ biến", "ตรีลักษณ์บนและล่างของกว้าเดิมและกว้าแปร"],
  ["Visible element counts and branch roots held side by side", "五行数量与地支根气并列", "五行數量與地支根氣並列", "五行の数と地支の根気を並記", "오행 개수와 지지 뿌리를 나란히", "Số lượng ngũ hành và gốc khí địa chi đặt cạnh nhau", "จำนวนธาตุและรากกิ่งดินวางเคียงกัน"],
  ["Visible five-element distribution from the calendar", "由历法推得的五行分布", "由曆法推得的五行分布", "暦から得た五行分布", "달력에서 얻은 오행 분포", "Phân bố ngũ hành từ lịch", "การกระจายห้าธาตุจากปฏิทิน"],
  ["Where could a smaller, kinder next step be more useful than certainty?", "在哪里，一个更小、更温和的下一步比确定性更有用？", "在哪裡，一個更小、更溫和的下一步比確定性更有用？", "確信よりも、小さく優しい一歩が役立つのはどこですか？", "확신보다 더 작고 다정한 한 걸음이 유용한 곳은 어디인가요?", "Ở đâu một bước nhỏ và dịu dàng hơn sẽ hữu ích hơn sự chắc chắn?", "ตรงไหนที่ก้าวเล็ก ๆ อ่อนโยนกว่า มีประโยชน์กว่าความแน่นอน"],
  ["Year, month, day and hour references kept visible before comparison", "比较前保留年、月、日、时参照", "比較前保留年、月、日、時參照", "比較の前に年月日時を表示", "비교 전 연·월·일·시 참조 유지", "Giữ tham chiếu năm, tháng, ngày, giờ trước khi so sánh", "คงอ้างอิงปี เดือน วัน ชั่วโมงก่อนเปรียบเทียบ"],
  ["Yin or Yang bureau, term and central palace framing", "阴阳遁、节气与中宫框架", "陰陽遁、節氣與中宮框架", "陰遁・陽遁、節気、中宮の枠組み", "음둔·양둔, 절기, 중궁 틀", "Âm độn hay dương độn, tiết khí và khung trung cung", "กรอบยินหยาง ฤดูกาลย่อย และวังกลาง"],
  ["Origin", "起点", "起點", "起点", "기원", "Khởi nguồn", "จุดเริ่มต้น"],
  ["Timing", "时序", "時序", "時機", "시점", "Thời điểm", "จังหวะเวลา"],
  ["Exchange", "交流", "交流", "交流", "교류", "Trao đổi", "การแลกเปลี่ยน"],
  ["Contrast", "对照", "對照", "対比", "대조", "Đối chiếu", "การเทียบเคียง"],
  ["Converge", "汇合", "匯合", "収束", "수렴", "Hội tụ", "การบรรจบ"],
  ["Relationship", "关系", "關係", "関係", "관계", "Mối quan hệ", "ความสัมพันธ์"],
  ["Calendar", "历法", "曆法", "暦", "달력", "Lịch", "ปฏิทิน"],
  ["Phase", "相位", "相位", "位相", "위상", "Pha", "เฟส"],
  ["Breathe", "呼吸", "呼吸", "呼吸", "호흡", "Hít thở", "หายใจ"],
  ["Curious", "好奇", "好奇", "好奇心", "호기심", "Tò mò", "ใคร่รู้"],
  ["Open Sky", "开阔天空", "開闊天空", "広い空", "열린 하늘", "Bầu trời rộng mở", "ท้องฟ้าเปิดกว้าง"],
  ["Next action", "下一步行动", "下一步行動", "次の行動", "다음 행동", "Hành động tiếp theo", "การกระทำถัดไป"],
  ["Elemental tone", "五行基调", "五行基調", "五行の基調", "오행 기조", "Sắc thái Ngũ Hành", "โทนธาตุ"],
  ["Spread positions", "牌阵位置", "牌陣位置", "スプレッドの位置", "스프레드 위치", "Vị trí trải bài", "ตำแหน่งการวางไพ่"],
  ["Reflection actions", "回顾行动", "回顧行動", "振り返りの行動", "성찰 행동", "Hành động chiêm nghiệm", "การกระทำเพื่อทบทวน"],
  ["A three-step practice", "三步练习", "三步練習", "三段階の練習", "3단계 연습", "Bài thực hành ba bước", "แบบฝึกสามขั้นตอน"],
  ["Three lenses held together", "三种视角并置观察", "三種視角並置觀察", "三つの視点を並べて観察", "세 가지 관점을 함께 관찰", "Ba góc nhìn được đặt cạnh nhau", "สามมุมมองที่วางเคียงกัน"],
  ["Non-deterministic points for conversation", "用于对话的开放议题，不作定论", "用於對話的開放議題，不作定論", "結論ではなく対話のための論点", "결론이 아닌 대화를 위한 논점", "Điểm gợi mở để trò chuyện, không phải kết luận", "ประเด็นเปิดสำหรับการสนทนา ไม่ใช่ข้อสรุป"],
  ["Palace placement", "宫位排布", "宮位排布", "宮位配置", "궁위 배치", "Bố trí cung", "การวางวัง"],
  ["Four Transformations", "四化", "四化", "四化", "사화", "Tứ Hóa", "สี่การแปรเปลี่ยน"],
  ["Limit timeline", "大限时序", "大限時序", "大限のタイムライン", "대한 타임라인", "Dòng thời gian Đại hạn", "ไทม์ไลน์ช่วงใหญ่"],
  ["Twelve-stage reflective sequence", "十二阶段回顾序列", "十二階段回顧序列", "十二段階の振り返り", "12단계 성찰 순서", "Chuỗi chiêm nghiệm mười hai giai đoạn", "ลำดับทบทวนสิบสองขั้น"],
  ["An annual-reference layer", "流年参照层", "流年參照層", "流年参照レイヤー", "유년 참조 레이어", "Lớp tham chiếu lưu niên", "ชั้นอ้างอิงรายปี"],
  ["Study framing", "研习框架", "研習框架", "学習フレーム", "학습 틀", "Khung học tập", "กรอบการศึกษา"],
  ["Celestial bodies", "星体", "星體", "天体", "천체", "Thiên thể", "วัตถุท้องฟ้า"],
  ["Aspect map", "相位图", "相位圖", "アスペクト図", "상위 지도", "Bản đồ góc chiếu", "แผนที่มุมสัมพันธ์"],
  ["Lunar mansions", "二十八宿", "二十八宿", "二十八宿", "이십팔수", "Nhị thập bát tú", "ยี่สิบแปดนักษัตร"],
  ["Planetary dignities", "行星庙旺", "行星廟旺", "惑星の品位", "행성 품위", "Phẩm vị hành tinh", "ศักดิ์ของดาวเคราะห์"],
  ["Celestial timing", "天象时序", "天象時序", "天象の時序", "천상 시점", "Thời điểm thiên tượng", "จังหวะท้องฟ้า"],
  ["Twelve-sector phase progression", "十二分区相位推移", "十二分區相位推移", "十二区分の位相推移", "12구역 위상 진행", "Tiến trình pha mười hai khu", "การเคลื่อนของเฟสสิบสองส่วน"],
  ["Gate distribution with the central duty held in the same field", "八门分布与中宫值符并置", "八門分布與中宮值符並置", "八門の配置と中宮の値符を同じ盤に", "팔문 배치와 중궁 치부를 함께 표시", "Phân bố Bát môn cùng trực phù trung cung", "การวางแปดประตูพร้อมผู้ดูแลกลาง"],
  ["Earth division", "地分", "地分", "地分", "지분", "Địa phận", "การแบ่งพื้นดิน"],
  ["Four linked inquiry positions", "四课", "四課", "四課", "사과", "Tứ khóa", "สี่ตำแหน่งสอบถาม"],
  ["Local motion and absence reference", "动静与空亡参照", "動靜與空亡參照", "動静と空亡の参照", "동정·공망 참조", "Tham chiếu động tĩnh và không vong", "อ้างอิงการเคลื่อนไหวและช่องว่าง"],
  ["Twelve general and officer references held alongside the heaven plate", "十二天将与天盘并列参照", "十二天將與天盤並列參照", "十二天将を天盤と並べて参照", "십이천장과 천반을 함께 참조", "Mười hai thiên tướng đối chiếu cùng thiên bàn", "สิบสองแม่ทัพฟ้าเทียบกับแผ่นฟ้า"],
  ["Yin – –", "阴 – –", "陰 – –", "陰 – –", "음 – –", "Âm – –", "หยิน – –"],
  ["Yang —", "阳 —", "陽 —", "陽 —", "양 —", "Dương —", "หยาง —"],
  ["Original to transformed study points", "本卦到变卦的研习要点", "本卦到變卦的研習要點", "本卦から変卦への学習ポイント", "본괘에서 변괘로의 학습 요점", "Điểm học từ quẻ gốc đến quẻ biến", "จุดศึกษาจากกว้าเดิมสู่กว้าแปร"],
  ["Wood feeds Fire", "木生火", "木生火", "木は火を生む", "목생화", "Mộc sinh Hỏa", "ไม้ก่อไฟ"],
  ["Fire forms Earth", "火生土", "火生土", "火は土を生む", "화생토", "Hỏa sinh Thổ", "ไฟก่อดิน"],
  ["Earth bears Metal", "土生金", "土生金", "土は金を生む", "토생금", "Thổ sinh Kim", "ดินก่อโลหะ"],
  ["Metal gathers Water", "金生水", "金生水", "金は水を生む", "금생수", "Kim sinh Thủy", "โลหะก่อน้ำ"],
  ["Water nourishes Wood", "水生木", "水生木", "水は木を生む", "수생목", "Thủy sinh Mộc", "น้ำหล่อเลี้ยงไม้"],
  ["Five-phase generating cycle as a study reference", "五行相生循环参照", "五行相生循環參照", "五行相生の循環参照", "오행 상생 순환 참조", "Vòng tương sinh Ngũ Hành để tham khảo", "วงจรก่อเกิดห้าธาตุเพื่ออ้างอิง"],
  ["Setting, figure and threshold held apart before interpreting", "先分别记录场景、人物与门槛，再作解读", "先分別記錄場景、人物與門檻，再作解讀", "解釈の前に場面・人物・境界を分けて記録", "해석 전에 장면·인물·문턱을 나누어 기록", "Tách bối cảnh, nhân vật và ngưỡng cửa trước khi diễn giải", "แยกฉาก บุคคล และธรณีประตูก่อนตีความ"],
  ["What can be held lightly while you gather more lived experience?", "在积累更多经验之前，哪些事可以先放轻？", "在累積更多經驗之前，哪些事可以先放輕？", "経験を重ねる間、軽く持てるものは何ですか？", "경험을 더 쌓는 동안 가볍게 둘 수 있는 것은 무엇인가요?", "Điều gì có thể giữ nhẹ nhàng trong khi bạn tích lũy thêm trải nghiệm?", "สิ่งใดที่ถือไว้เบา ๆ ได้ระหว่างสั่งสมประสบการณ์"],
  ["Which rhythm in your week is asking to be noticed rather than fixed?", "本周哪种节奏需要被留意，而非被修正？", "本週哪種節奏需要被留意，而非被修正？", "今週、直すより気づくべきリズムは何ですか？", "이번 주 고치기보다 알아차려야 할 리듬은 무엇인가요?", "Nhịp nào trong tuần cần được nhận ra thay vì sửa chữa?", "จังหวะใดในสัปดาห์นี้ที่ควรสังเกตมากกว่าจะแก้ไข"],
  ["What part of your environment supports the quality you want to cultivate?", "环境中哪一部分支持你想培养的品质？", "環境中哪一部分支持你想培養的品質？", "育てたい資質を支えている環境は何ですか？", "기르고 싶은 자질을 뒷받침하는 환경은 무엇인가요?", "Phần nào trong môi trường hỗ trợ phẩm chất bạn muốn nuôi dưỡng?", "ส่วนใดของสภาพแวดล้อมที่สนับสนุนคุณสมบัติที่คุณอยากบ่มเพาะ"],
  ["What is becoming clearer when you pause before responding?", "在回应之前停一下，什么变得更清楚了？", "在回應之前停一下，什麼變得更清楚了？", "応じる前に間を置くと、何が明確になりますか？", "응답하기 전 잠시 멈추면 무엇이 더 분명해지나요?", "Điều gì trở nên rõ hơn khi bạn dừng lại trước khi đáp lời?", "เมื่อหยุดก่อนตอบ สิ่งใดชัดเจนขึ้น"],
  ["Where might a clear boundary create more room to breathe?", "哪里设一条清晰的边界，能让你更有喘息空间？", "哪裡設一條清晰的邊界，能讓你更有喘息空間？", "明確な境界を置くと、どこに余白が生まれますか？", "분명한 경계가 어디에서 숨 쉴 여유를 만들까요?", "Ranh giới rõ ràng ở đâu sẽ tạo thêm khoảng thở?", "ขอบเขตที่ชัดเจนตรงไหนจะช่วยให้มีพื้นที่หายใจมากขึ้น"],
  ["What feels steady enough to keep as you move forward?", "向前走时，哪些事足够稳定、值得保留？", "向前走時，哪些事足夠穩定、值得保留？", "前に進むとき、保ち続けられるほど安定しているものは？", "앞으로 나아가며 계속 지닐 만큼 안정적인 것은 무엇인가요?", "Điều gì đủ vững để giữ lại khi bạn tiến về phía trước?", "สิ่งใดมั่นคงพอที่จะเก็บไว้เมื่อก้าวต่อไป"],
  ["Which intention would make this next season feel more aligned?", "带着怎样的意图，下一季会更契合？", "帶著怎樣的意圖，下一季會更契合？", "どんな意図があれば次の季節はより調和しますか？", "어떤 의도가 다음 계절을 더 조화롭게 할까요?", "Ý định nào sẽ khiến mùa tới cảm thấy hài hòa hơn?", "เจตนาใดจะทำให้ฤดูกาลถัดไปสอดคล้องยิ่งขึ้น"],
  ["A grounded gesture after recording a dream", "记录梦境后，以呼吸、身体感受与一件可执行小事回到当下", "記錄夢境後，以呼吸、身體感受與一件可執行小事回到當下", "夢を記した後、呼吸・身体感覚・小さな行動で現在に戻る", "꿈을 기록한 뒤 호흡·몸의 감각·작은 실천으로 현재로 돌아옵니다", "Sau khi ghi giấc mơ, trở về hiện tại bằng hơi thở, cảm nhận cơ thể và một việc nhỏ có thể làm", "หลังบันทึกความฝัน ให้กลับมาอยู่กับปัจจุบันผ่านลมหายใจ ความรู้สึกของร่างกาย และการลงมือทำเล็ก ๆ"],
  ["Day pillar shen-sha reference lane", "日柱神煞：以日干日支为轴呈现常用神煞标记", "日柱神煞：以日干日支為軸呈現常用神煞標記", "日柱の神煞：日干と日支を軸に主要な神煞を表示", "일주의 신살: 일간과 일지를 축으로 주요 신살을 표시", "Thần sát của trụ ngày: hiển thị các dấu hiệu thường dùng theo can chi ngày", "เสินซาของเสาวัน: แสดงเครื่องหมายเสินซาที่ใช้บ่อยโดยยึดก้านฟ้าและกิ่งดินของวัน"],
  ["Month pillar shen-sha reference lane", "月柱神煞：结合月令呈现常用神煞标记", "月柱神煞：結合月令呈現常用神煞標記", "月柱の神煞：月令と合わせて主要な神煞を表示", "월주의 신살: 월령과 함께 주요 신살을 표시", "Thần sát của trụ tháng: hiển thị các dấu hiệu thường dùng cùng lệnh tháng", "เสินซาของเสาเดือน: แสดงเครื่องหมายเสินซาที่ใช้บ่อยร่วมกับคำสั่งเดือน"],
  ["Year pillar shen-sha reference lane", "年柱神煞：以年干年支呈现常用神煞标记", "年柱神煞：以年干年支呈現常用神煞標記", "年柱の神煞：年干と年支から主要な神煞を表示", "년주의 신살: 연간과 연지를 기준으로 주요 신살을 표시", "Thần sát của trụ năm: hiển thị các dấu hiệu thường dùng theo can chi năm", "เสินซาของเสาปี: แสดงเครื่องหมายเสินซาที่ใช้บ่อยโดยยึดก้านฟ้าและกิ่งดินของปี"],
  ["Hour pillar shen-sha reference lane", "时柱神煞：结合时支呈现常用神煞标记", "時柱神煞：結合時支呈現常用神煞標記", "時柱の神煞：時支と合わせて主要な神煞を表示", "시주의 신살: 시지와 함께 주요 신살을 표시", "Thần sát của trụ giờ: hiển thị các dấu hiệu thường dùng cùng chi giờ", "เสินซาของเสายาม: แสดงเครื่องหมายเสินซาที่ใช้บ่อยร่วมกับกิ่งดินของยาม"],
  ["Core, support and minor stars held in one comparative layer", "主星、辅星与杂曜分层列示，便于查看同宫关系", "主星、輔星與雜曜分層列示，便於查看同宮關係", "主星・補助星・雑曜を層別に表示し、同宮の関係を確認", "주성·보조성·잡성을 층별로 표시해 동궁 관계를 확인", "Sao chính, sao phụ và tạp diệu được xếp theo lớp để xem quan hệ đồng cung", "แสดงดาวหลัก ดาวเสริม และดาวรองเป็นชั้นเพื่อดูความสัมพันธ์ร่วมวัง"],
  ["Life palace and body palace held as two observation anchors", "命宫与身宫并列显示，区分先天结构与身心落点", "命宮與身宮並列顯示，區分先天結構與身心落點", "命宮と身宮を並べ、先天的な構造と身体側の焦点を分けて表示", "명궁과 신궁을 나란히 보여 선천 구조와 신체적 초점을 구분", "Cung Mệnh và Cung Thân được đặt cạnh nhau để phân biệt cấu trúc bẩm sinh và điểm đặt thân tâm", "แสดงวังชีวิตและวังกายคู่กันเพื่อแยกโครงสร้างพื้นฐานกับจุดเน้นของกายใจ"],
  ["Duty chief and duty gate positions across the nine palace field", "九宫中同时标出值符与值使，显示所在宫位与对应门位", "九宮中同時標出值符與值使，顯示所在宮位與對應門位", "九宮内の値符と値使を同時に示し、宮位と門の対応を表示", "구궁 안의 직부와 직사를 함께 표시해 궁위와 문의 대응을 보여 줌", "Đánh dấu đồng thời Trực Phù và Trực Sử trong cửu cung, kèm cung vị và cửa tương ứng", "ทำเครื่องหมายจื้อฝูและจื้อสื่อพร้อมกันในเก้าวัง พร้อมวังและประตูที่สอดคล้อง"],
  ["Earth plate and heaven plate pairings across the twelve positions", "十二位逐格列出地盘与天盘干的配对关系", "十二位逐格列出地盤與天盤干的配對關係", "12の位置ごとに地盤干と天盤干の組み合わせを表示", "열두 자리마다 지반간과 천반간의 짝을 표시", "Liệt kê cặp can địa bàn và thiên bàn tại từng trong mười hai vị trí", "แสดงคู่ก้านฟ้าของผังดินและผังฟ้าในแต่ละตำแหน่งทั้งสิบสอง"],
  ["Original and transformed line pairs held side by side", "本卦与变卦的对应爻位并列呈现，便于观察动爻前后", "本卦與變卦的對應爻位並列呈現，便於觀察動爻前後", "本卦と変卦の対応する爻位を並べ、動爻の前後を確認", "본괘와 변괘의 대응 효를 나란히 보여 동효 전후를 확인", "Đặt cạnh nhau các hào tương ứng của quẻ gốc và quẻ biến để quan sát trước sau của hào động", "วางเส้นที่สอดคล้องของกว้าเดิมและกว้าแปรข้างกันเพื่อดูช่วงก่อนและหลังเส้นเคลื่อน"],
  ["Body, aspect and dignity held in a single comparative layer", "将星体、相位与尊贵状态放在同一层，便于横向比对", "將星體、相位與尊貴狀態放在同一層，便於橫向比對", "天体・アスペクト・ディグニティを同じ層に置き、横断的に比較", "천체·애스펙트·디그니티를 한 층에 두어 가로로 비교", "Đặt thiên thể, góc hợp và phẩm vị trên cùng một lớp để đối chiếu", "วางดาว มุมสัมพันธ์ และสถานะศักดิ์ไว้ในชั้นเดียวเพื่อเทียบเคียง"],
  ["Calendar, civil time and chosen time basis kept separate", "历法、民用时与选定的排盘时间分别记录，避免混用", "曆法、民用時與選定的排盤時間分別記錄，避免混用", "暦・民用時・選択した盤時刻を分けて記録し、混同を避ける", "달력·민용시·선택한 명반 시각을 구분해 기록하여 혼용을 피함", "Lịch, giờ dân dụng và chuẩn giờ lập bàn được ghi riêng để tránh lẫn lộn", "บันทึกปฏิทิน เวลาท้องถิ่น และฐานเวลาที่เลือกแยกกันเพื่อป้องกันการปะปน"],
  ["Five-element references are a vocabulary for conversation, not a score", "五行分布用于描述结构与关系，不作为优劣评分", "五行分布用於描述結構與關係，不作為優劣評分", "五行の分布は構造と関係を説明するためのもので、優劣の採点ではない", "오행 분포는 구조와 관계를 설명하기 위한 것이며 좋고 나쁨의 점수가 아님", "Phân bố Ngũ Hành dùng để mô tả cấu trúc và mối liên hệ, không phải để chấm điểm tốt xấu", "การกระจายธาตุทั้งห้าใช้บรรยายโครงสร้างและความสัมพันธ์ ไม่ใช่คะแนนดีหรือร้าย"],
  ["Two profiles are compared as a conversation aid, never as a fixed outcome", "两组资料按结构、五行与时序并列，用于展开对话而非下定论", "兩組資料按結構、五行與時序並列，用於展開對話而非下定論", "2つの情報を構造・五行・時序で並べ、結論の固定ではなく対話の補助にする", "두 정보를 구조·오행·시점으로 나란히 두어 단정이 아닌 대화를 돕습니다", "Hai hồ sơ được đặt cạnh nhau theo cấu trúc, Ngũ Hành và thời điểm để hỗ trợ đối thoại, không kết luận cố định", "วางข้อมูลสองชุดคู่กันตามโครงสร้าง ธาตุทั้งห้า และเวลา เพื่อช่วยการสนทนา ไม่ใช่เพื่อสรุปตายตัว"],
];

const generatedChartTerms: Record<Locale, Record<string, string>> = { en: {}, "zh-Hans": {}, "zh-Hant": {}, ja: {}, ko: {}, vi: {}, th: {} };
const generatedChartTermsInsensitive: Record<Locale, Record<string, string>> = { en: {}, "zh-Hans": {}, "zh-Hant": {}, ja: {}, ko: {}, vi: {}, th: {} };
for (const [source, ...translations] of [...generatedChartTermRows, ...generatedNarrativeTermRows]) {
  generatedChartLocales.forEach((locale, index) => {
    generatedChartTerms[locale][source] = translations[index] ?? source;
    generatedChartTermsInsensitive[locale][source.toLowerCase()] = translations[index] ?? source;
  });
}

function collectGeneratedChartTerms() {
  const terms = new Set<string>();
  const modules = ["bazi", "detail", "compatibility", "liuyao", "ziwei", "qizheng", "qimen", "daliuren", "wenshi", "mirror", "toolkit-time", "toolkit-elements", "toolkit-dream", "toolkit-name", "toolkit-tarot", "toolkit-iching", "toolkit-natal", "toolkit-meihua", "toolkit-fengshui", "meihua", "jinkoujue", "heluo", "tieban", "taiyi", "zhuzhai", "hecan", "daily"];
  for (let day = 1; day <= 1; day += 3) { // labels no longer depend on the date: one pass keeps page start-up fast
    for (const tool of modules) {
      const chart = createCompleteChart({ birthDate: `1994-08-${String(day).padStart(2, "0")}`, birthTime: "12:00", calendar: "solar", focus: "__generated_focus__", name: "__generated_name__", companionName: "__generated_companion__", module: tool, version: 1, place: "Global" });
      const values = [chart.board.label, ...chart.board.cells.flatMap((cell) => [cell.title, cell.subtitle, ...cell.items.flatMap((item) => [item.label, item.value])]), ...chart.sections.flatMap((section) => [section.title, section.lead, ...section.items.flatMap((item) => [item.label, item.value])])];
      for (const value of values) if (typeof value === "string" && !value.includes("__generated_")) terms.add(value);
    }
  }
  return terms;
}

const knownGeneratedChartTerms = collectGeneratedChartTerms();

function localizeGeneratedChartFallback(value: string, locale: Locale) {
  if (locale === "en" || !knownGeneratedChartTerms.has(value) || !/[A-Za-z]/.test(value)) return undefined;
  const direct = generatedChartTerms[locale][value] ?? generatedChartTermsInsensitive[locale][value.toLowerCase()];
  if (direct) return direct;
  // Untranslated generated text: keep the original wording rather than a
  // generic placeholder, so the cell still shows real chart information.
  return value;
}

const specialistBoardNames: Record<Locale, { bazi: string; ziwei: string }> = {
  en: { bazi: "BaZi four-pillar matrix", ziwei: "Zi Wei twelve-palace chart" },
  "zh-Hans": { bazi: "八字四柱矩阵盘", ziwei: "紫微斗数十二宫盘" },
  "zh-Hant": { bazi: "八字四柱矩陣盤", ziwei: "紫微斗數十二宮盤" },
  ja: { bazi: "八字・四柱マトリクス", ziwei: "紫微斗数・十二宮盤" },
  ko: { bazi: "사주팔자 행렬", ziwei: "자미두수 십이궁 판면" },
  vi: { bazi: "Ma trận Tứ Trụ BaZi", ziwei: "Bàn Tử Vi mười hai cung" },
  th: { bazi: "ตารางสี่เสาแบบปาจื้อ", ziwei: "ผังสิบสองวังของจื่อเวย" },
};

const ziweiPalaceTerms: Record<Locale, Record<string, string>> = {
  en: {},
  "zh-Hans": { Life: "命宫", Siblings: "兄弟宫", Partnership: "夫妻宫", Children: "子女宫", Wealth: "财帛宫", Health: "疾厄宫", Travel: "迁移宫", Allies: "交友宫", Career: "官禄宫", Property: "田宅宫", Fortune: "福德宫", Parents: "父母宫" },
  "zh-Hant": { Life: "命宮", Siblings: "兄弟宮", Partnership: "夫妻宮", Children: "子女宮", Wealth: "財帛宮", Health: "疾厄宮", Travel: "遷移宮", Allies: "交友宮", Career: "官祿宮", Property: "田宅宮", Fortune: "福德宮", Parents: "父母宮" },
  ja: { Life: "命宮", Siblings: "兄弟宮", Partnership: "夫妻宮", Children: "子女宮", Wealth: "財帛宮", Health: "疾厄宮", Travel: "遷移宮", Allies: "交友宮", Career: "官禄宮", Property: "田宅宮", Fortune: "福徳宮", Parents: "父母宮" },
  ko: { Life: "명궁", Siblings: "형제궁", Partnership: "부처궁", Children: "자녀궁", Wealth: "재백궁", Health: "질액궁", Travel: "천이궁", Allies: "교우궁", Career: "관록궁", Property: "전택궁", Fortune: "복덕궁", Parents: "부모궁" },
  vi: { Life: "Cung Mệnh", Siblings: "Cung Huynh Đệ", Partnership: "Cung Phu Thê", Children: "Cung Tử Tức", Wealth: "Cung Tài Bạch", Health: "Cung Tật Ách", Travel: "Cung Thiên Di", Allies: "Cung Nô Bộc", Career: "Cung Quan Lộc", Property: "Cung Điền Trạch", Fortune: "Cung Phúc Đức", Parents: "Cung Phụ Mẫu" },
  th: { Life: "วังมิ่ง", Siblings: "วังพี่น้อง", Partnership: "วังคู่ครอง", Children: "วังบุตร", Wealth: "วังทรัพย์", Health: "วังสุขภาพ", Travel: "วังเคลื่อนย้าย", Allies: "วังมิตร", Career: "วังการงาน", Property: "วังที่ดิน", Fortune: "วังบุญวาสนา", Parents: "วังบิดามารดา" },
};

const ziweiTransformationTerms: Record<Locale, Record<string, string>> = {
  en: {},
  "zh-Hans": { Lu: "禄", Quan: "权", Ke: "科", Ji: "忌" },
  "zh-Hant": { Lu: "祿", Quan: "權", Ke: "科", Ji: "忌" },
  ja: { Lu: "禄", Quan: "権", Ke: "科", Ji: "忌" },
  ko: { Lu: "녹", Quan: "권", Ke: "과", Ji: "기" },
  vi: { Lu: "Lộc", Quan: "Quyền", Ke: "Khoa", Ji: "Kỵ" },
  th: { Lu: "ลก", Quan: "ฉวน", Ke: "เคอ", Ji: "จี้" },
};

const independentMethodTerms: Record<Locale, Record<string, string>> = {
  en: {},
  "zh-Hans": {
    Gather: "汇聚", Observe: "观照", Hold: "守持", Shape: "成形", Release: "舒展", Listen: "聆听", Align: "校准", "Civil reference": "民用时参照",
    "Timing layers": "寻时层级", "Day windows": "日内时窗", "Seasonal frame": "节气框架", "Calendar reference": "历法参照", "Action cadence": "行动节律", "Timing mark": "时序标记", "Favourable reference": "宜事参照", "Caution reference": "慎事参照", Solar: "公历", Lunar: "农历", "Four Pillars": "四柱", "Four-pillar study matrix": "四柱研习矩阵", Pillar: "柱位", "Element balance": "五行平衡", "Calendar context": "历法语境", "Twelve-palace Zi Wei board": "紫微十二宫盘", "Bureau element": "局五行",
    "Element count": "五行计数", "Visible roots": "显见根气", "Cycle map": "生化循环", "Seasonal balance": "时令平衡", "Adjustment notes": "调和提示", "Visible count": "显见数量", "Cycle role": "循环角色", "Stem reference": "天干参照", "Branch reference": "地支参照", "Seasonal status": "时令状态", "Study gesture": "观照动作",
    "Dream images": "梦境图像", "Image positions": "意象位置", "Reflection threads": "观照线索", "Return practice": "回归练习", "Dream image": "梦境图像", "Image layer": "意象层", "Emotion tone": "情绪质地", "Reflection thread": "观照线索", "Return gesture": "回归动作", Image: "意象", Feeling: "感受", Return: "回归",
    "Character form": "字形参照", "Sound rhythm": "音律节奏", "Element reference": "五行参照", "Intention map": "意图图谱", "Name reflection": "姓名观照", "Character reference": "字形参照", "Form cue": "结构提示", "Intention thread": "意图线索", "Reflection prompt": "观照提示", Form: "形", Sound: "音", Element: "五行", Intention: "意图",
    "Archetype links": "原型关联", "Spread dialogue": "牌阵对话", "Sequence map": "顺序图谱", "Question frame": "问题框架", "Pillar cross-check": "四柱交叉参照", "Profile structure": "命式结构", "Element correspondence": "五行对应", "Timing correspondence": "时序对应", "Pair resonance": "双人共振", "Two-profile frame": "双人结构", "Element dialogue": "五行对话", "Relationship axes": "关系轴线", "Inquiry triangulation": "问事三角参照", "Question structure": "问题结构", "Line context": "爻位语境", "Reflection path": "观照路径", "Celestial axes": "星体轴线", "Elemental field": "元素场", "Planetary crosslinks": "星体关联", "Seasonal sky frame": "时令星空框架",
  },
  "zh-Hant": {
    Gather: "匯聚", Observe: "觀照", Hold: "守持", Shape: "成形", Release: "舒展", Listen: "聆聽", Align: "校準", "Civil reference": "民用時參照",
    "Timing layers": "尋時層級", "Day windows": "日內時窗", "Seasonal frame": "節氣框架", "Calendar reference": "曆法參照", "Action cadence": "行動節律", "Timing mark": "時序標記", "Favourable reference": "宜事參照", "Caution reference": "慎事參照", Solar: "公曆", Lunar: "農曆", "Four Pillars": "四柱", "Four-pillar study matrix": "四柱研習矩陣", Pillar: "柱位", "Element balance": "五行平衡", "Calendar context": "曆法語境", "Twelve-palace Zi Wei board": "紫微十二宮盤", "Bureau element": "局五行",
    "Element count": "五行計數", "Visible roots": "顯見根氣", "Cycle map": "生化循環", "Seasonal balance": "時令平衡", "Adjustment notes": "調和提示", "Visible count": "顯見數量", "Cycle role": "循環角色", "Stem reference": "天干參照", "Branch reference": "地支參照", "Seasonal status": "時令狀態", "Study gesture": "觀照動作",
    "Dream images": "夢境圖像", "Image positions": "意象位置", "Reflection threads": "觀照線索", "Return practice": "回歸練習", "Dream image": "夢境圖像", "Image layer": "意象層", "Emotion tone": "情緒質地", "Reflection thread": "觀照線索", "Return gesture": "回歸動作", Image: "意象", Feeling: "感受", Return: "回歸",
    "Character form": "字形參照", "Sound rhythm": "音律節奏", "Element reference": "五行參照", "Intention map": "意圖圖譜", "Name reflection": "姓名觀照", "Character reference": "字形參照", "Form cue": "結構提示", "Intention thread": "意圖線索", "Reflection prompt": "觀照提示", Form: "形", Sound: "音", Element: "五行", Intention: "意圖",
    "Archetype links": "原型關聯", "Spread dialogue": "牌陣對話", "Sequence map": "順序圖譜", "Question frame": "問題框架", "Pillar cross-check": "四柱交叉參照", "Profile structure": "命式結構", "Element correspondence": "五行對應", "Timing correspondence": "時序對應", "Pair resonance": "雙人共振", "Two-profile frame": "雙人結構", "Element dialogue": "五行對話", "Relationship axes": "關係軸線", "Inquiry triangulation": "問事三角參照", "Question structure": "問題結構", "Line context": "爻位語境", "Reflection path": "觀照路徑", "Celestial axes": "星體軸線", "Elemental field": "元素場", "Planetary crosslinks": "星體關聯", "Seasonal sky frame": "時令星空框架",
  },
  ja: {
    Gather: "集める", Observe: "観る", Hold: "保つ", Shape: "形づくる", Release: "手放す", Listen: "聴く", Align: "整える", "Civil reference": "民用時の参照",
    "Timing layers": "時刻のレイヤー", "Day windows": "一日の時間帯", "Seasonal frame": "季節の枠組み", "Calendar reference": "暦の参照", "Action cadence": "行動のリズム", "Timing mark": "時刻の目印", "Favourable reference": "適した参照", "Caution reference": "注意の参照", Solar: "太陽暦", Lunar: "太陰暦", "Four Pillars": "四柱", "Four-pillar study matrix": "四柱学習マトリクス", Pillar: "柱", "Element balance": "五行バランス", "Calendar context": "暦の文脈", "Twelve-palace Zi Wei board": "紫微斗数・十二宮盤", "Bureau element": "局の五行",
    "Element count": "五行の数", "Visible roots": "見える根の参照", "Cycle map": "循環マップ", "Seasonal balance": "季節のバランス", "Adjustment notes": "調整の手がかり", "Visible count": "見える数", "Cycle role": "循環での役割", "Stem reference": "天干の参照", "Branch reference": "地支の参照", "Seasonal status": "季節の状態", "Study gesture": "内省の行為",
    "Dream images": "夢のイメージ", "Image positions": "イメージの位置", "Reflection threads": "内省の手がかり", "Return practice": "戻るための実践", "Dream image": "夢のイメージ", "Image layer": "イメージの層", "Emotion tone": "感情のトーン", "Reflection thread": "内省の手がかり", "Return gesture": "戻るための行為", Image: "イメージ", Feeling: "感覚", Return: "戻る",
    "Character form": "文字の形", "Sound rhythm": "音のリズム", "Element reference": "五行の参照", "Intention map": "意図のマップ", "Name reflection": "名前の内省", "Character reference": "文字の参照", "Form cue": "形の手がかり", "Intention thread": "意図の手がかり", "Reflection prompt": "内省の問い", Form: "形", Sound: "音", Element: "五行", Intention: "意図",
    "Archetype links": "元型のつながり", "Spread dialogue": "スプレッドの対話", "Sequence map": "順序マップ", "Question frame": "問いの枠組み", "Pillar cross-check": "四柱の照合", "Profile structure": "プロフィール構造", "Element correspondence": "五行の対応", "Timing correspondence": "時刻の対応", "Pair resonance": "二人の共鳴", "Two-profile frame": "二人の枠組み", "Element dialogue": "五行の対話", "Relationship axes": "関係の軸", "Inquiry triangulation": "問いの三角参照", "Question structure": "問いの構造", "Line context": "爻の文脈", "Reflection path": "内省の道筋", "Celestial axes": "天体の軸", "Elemental field": "元素の場", "Planetary crosslinks": "天体の関連", "Seasonal sky frame": "季節と空の枠組み",
  },
  ko: {
    Gather: "모으기", Observe: "관찰", Hold: "지키기", Shape: "형성", Release: "놓아주기", Listen: "듣기", Align: "정렬", "Civil reference": "민용시 참조",
    "Timing layers": "시간 레이어", "Day windows": "하루 시간대", "Seasonal frame": "계절 프레임", "Calendar reference": "달력 참조", "Action cadence": "행동 리듬", "Timing mark": "시간 표식", "Favourable reference": "적합한 참조", "Caution reference": "주의 참조", Solar: "양력", Lunar: "음력", "Four Pillars": "사주", "Four-pillar study matrix": "사주 학습 행렬", Pillar: "기둥", "Element balance": "오행 균형", "Calendar context": "달력 맥락", "Twelve-palace Zi Wei board": "자미두수 십이궁 판면", "Bureau element": "국의 오행",
    "Element count": "오행 수", "Visible roots": "드러난 뿌리 참조", "Cycle map": "순환 지도", "Seasonal balance": "계절 균형", "Adjustment notes": "조정 단서", "Visible count": "드러난 수", "Cycle role": "순환 역할", "Stem reference": "천간 참조", "Branch reference": "지지 참조", "Seasonal status": "계절 상태", "Study gesture": "성찰 행동",
    "Dream images": "꿈 이미지", "Image positions": "이미지 위치", "Reflection threads": "성찰 단서", "Return practice": "되돌아오기 실천", "Dream image": "꿈 이미지", "Image layer": "이미지 층", "Emotion tone": "감정 톤", "Reflection thread": "성찰 단서", "Return gesture": "되돌아오기 행동", Image: "이미지", Feeling: "느낌", Return: "되돌아오기",
    "Character form": "글자 형태", "Sound rhythm": "소리 리듬", "Element reference": "오행 참조", "Intention map": "의도 지도", "Name reflection": "이름 성찰", "Character reference": "글자 참조", "Form cue": "형태 단서", "Intention thread": "의도 단서", "Reflection prompt": "성찰 질문", Form: "형", Sound: "음", Element: "오행", Intention: "의도",
    "Archetype links": "원형 연결", "Spread dialogue": "스프레드 대화", "Sequence map": "순서 지도", "Question frame": "질문 프레임", "Pillar cross-check": "사주 교차 확인", "Profile structure": "프로필 구조", "Element correspondence": "오행 대응", "Timing correspondence": "시점 대응", "Pair resonance": "두 사람 공명", "Two-profile frame": "두 프로필 프레임", "Element dialogue": "오행 대화", "Relationship axes": "관계 축", "Inquiry triangulation": "질문 삼각 참조", "Question structure": "질문 구조", "Line context": "효 맥락", "Reflection path": "성찰 경로", "Celestial axes": "천체 축", "Elemental field": "원소 장", "Planetary crosslinks": "행성 연결", "Seasonal sky frame": "계절 하늘 프레임",
  },
  vi: {
    Gather: "Gom lại", Observe: "Quan sát", Hold: "Giữ", Shape: "Tạo hình", Release: "Thả", Listen: "Lắng nghe", Align: "Căn chỉnh", "Civil reference": "Tham chiếu giờ dân dụng",
    "Timing layers": "Các lớp thời điểm", "Day windows": "Khung giờ trong ngày", "Seasonal frame": "Khung mùa", "Calendar reference": "Tham chiếu lịch", "Action cadence": "Nhịp hành động", "Timing mark": "Mốc thời điểm", "Favourable reference": "Tham chiếu phù hợp", "Caution reference": "Tham chiếu cần lưu ý", Solar: "Dương lịch", Lunar: "Âm lịch", "Four Pillars": "Tứ Trụ", "Four-pillar study matrix": "Ma trận nghiên cứu Tứ Trụ", Pillar: "Trụ", "Element balance": "Cân bằng Ngũ Hành", "Calendar context": "Ngữ cảnh lịch", "Twelve-palace Zi Wei board": "Bàn Tử Vi mười hai cung", "Bureau element": "Ngũ Hành của cục",
    "Element count": "Số lượng Ngũ Hành", "Visible roots": "Tham chiếu gốc hiển lộ", "Cycle map": "Bản đồ chu trình", "Seasonal balance": "Cân bằng theo mùa", "Adjustment notes": "Gợi ý điều chỉnh", "Visible count": "Số hiển lộ", "Cycle role": "Vai trò trong chu trình", "Stem reference": "Tham chiếu thiên can", "Branch reference": "Tham chiếu địa chi", "Seasonal status": "Trạng thái theo mùa", "Study gesture": "Thao tác chiêm nghiệm",
    "Dream images": "Hình ảnh giấc mơ", "Image positions": "Vị trí hình ảnh", "Reflection threads": "Mạch chiêm nghiệm", "Return practice": "Thực hành trở về", "Dream image": "Hình ảnh giấc mơ", "Image layer": "Lớp hình ảnh", "Emotion tone": "Sắc thái cảm xúc", "Reflection thread": "Mạch chiêm nghiệm", "Return gesture": "Thao tác trở về", Image: "Hình ảnh", Feeling: "Cảm nhận", Return: "Trở về",
    "Character form": "Hình thể chữ", "Sound rhythm": "Nhịp âm", "Element reference": "Tham chiếu Ngũ Hành", "Intention map": "Bản đồ ý định", "Name reflection": "Chiêm nghiệm tên", "Character reference": "Tham chiếu chữ", "Form cue": "Gợi ý hình thể", "Intention thread": "Mạch ý định", "Reflection prompt": "Câu gợi mở", Form: "Hình", Sound: "Âm", Element: "Ngũ Hành", Intention: "Ý định",
    "Archetype links": "Liên kết nguyên mẫu", "Spread dialogue": "Đối thoại trải bài", "Sequence map": "Bản đồ trình tự", "Question frame": "Khung câu hỏi", "Pillar cross-check": "Đối chiếu Tứ Trụ", "Profile structure": "Cấu trúc hồ sơ", "Element correspondence": "Tương ứng Ngũ Hành", "Timing correspondence": "Tương ứng thời điểm", "Pair resonance": "Cộng hưởng đôi", "Two-profile frame": "Khung hai hồ sơ", "Element dialogue": "Đối thoại Ngũ Hành", "Relationship axes": "Trục quan hệ", "Inquiry triangulation": "Tam giác tham chiếu câu hỏi", "Question structure": "Cấu trúc câu hỏi", "Line context": "Ngữ cảnh hào", "Reflection path": "Lộ trình chiêm nghiệm", "Celestial axes": "Trục thiên thể", "Elemental field": "Trường nguyên tố", "Planetary crosslinks": "Liên kết thiên thể", "Seasonal sky frame": "Khung bầu trời theo mùa",
  },
  th: {
    Gather: "รวบรวม", Observe: "สังเกต", Hold: "ประคอง", Shape: "ก่อรูป", Release: "ปล่อย", Listen: "รับฟัง", Align: "ปรับให้สอดคล้อง", "Civil reference": "ข้อมูลอ้างอิงเวลาท้องถิ่น",
    "Timing layers": "ชั้นของเวลา", "Day windows": "ช่วงเวลาในวัน", "Seasonal frame": "กรอบฤดูกาล", "Calendar reference": "ข้อมูลอ้างอิงปฏิทิน", "Action cadence": "จังหวะการลงมือทำ", "Timing mark": "จุดกำกับเวลา", "Favourable reference": "ข้อมูลอ้างอิงที่เหมาะสม", "Caution reference": "ข้อมูลอ้างอิงที่ควรระวัง", Solar: "ปฏิทินสุริยคติ", Lunar: "ปฏิทินจันทรคติ", "Four Pillars": "สี่เสา", "Four-pillar study matrix": "ตารางศึกษาแบบสี่เสา", Pillar: "เสา", "Element balance": "สมดุลธาตุทั้งห้า", "Calendar context": "บริบทปฏิทิน", "Twelve-palace Zi Wei board": "ผังสิบสองวังของจื่อเวย", "Bureau element": "ธาตุของผัง",
    "Element count": "จำนวนธาตุทั้งห้า", "Visible roots": "ข้อมูลอ้างอิงรากที่ปรากฏ", "Cycle map": "แผนผังวัฏจักร", "Seasonal balance": "สมดุลตามฤดูกาล", "Adjustment notes": "ข้อสังเกตเพื่อปรับสมดุล", "Visible count": "จำนวนที่ปรากฏ", "Cycle role": "บทบาทในวัฏจักร", "Stem reference": "ข้อมูลอ้างอิงก้านฟ้า", "Branch reference": "ข้อมูลอ้างอิงกิ่งดิน", "Seasonal status": "สภาวะตามฤดูกาล", "Study gesture": "การใคร่ครวญ",
    "Dream images": "ภาพในฝัน", "Image positions": "ตำแหน่งของภาพ", "Reflection threads": "แนวใคร่ครวญ", "Return practice": "การปฏิบัติเพื่อกลับมา", "Dream image": "ภาพในฝัน", "Image layer": "ชั้นของภาพ", "Emotion tone": "น้ำหนักทางอารมณ์", "Reflection thread": "แนวใคร่ครวญ", "Return gesture": "การกระทำเพื่อกลับมา", Image: "ภาพ", Feeling: "ความรู้สึก", Return: "กลับมา",
    "Character form": "รูปอักษร", "Sound rhythm": "จังหวะเสียง", "Element reference": "ข้อมูลอ้างอิงธาตุทั้งห้า", "Intention map": "แผนผังเจตนา", "Name reflection": "การใคร่ครวญชื่อ", "Character reference": "ข้อมูลอ้างอิงอักษร", "Form cue": "จุดสังเกตรูปแบบ", "Intention thread": "แนวเจตนา", "Reflection prompt": "คำชวนใคร่ครวญ", Form: "รูป", Sound: "เสียง", Element: "ธาตุทั้งห้า", Intention: "เจตนา",
    "Archetype links": "ความเชื่อมโยงต้นแบบ", "Spread dialogue": "บทสนทนาของผังไพ่", "Sequence map": "แผนผังลำดับ", "Question frame": "กรอบคำถาม", "Pillar cross-check": "การเทียบเคียงสี่เสา", "Profile structure": "โครงสร้างข้อมูล", "Element correspondence": "ความสอดคล้องของธาตุ", "Timing correspondence": "ความสอดคล้องของเวลา", "Pair resonance": "การสั่นพ้องของคู่", "Two-profile frame": "กรอบข้อมูลสองชุด", "Element dialogue": "บทสนทนาธาตุ", "Relationship axes": "แกนความสัมพันธ์", "Inquiry triangulation": "การอ้างอิงสามด้านของคำถาม", "Question structure": "โครงสร้างคำถาม", "Line context": "บริบทของเส้น", "Reflection path": "เส้นทางการใคร่ครวญ", "Celestial axes": "แกนท้องฟ้า", "Elemental field": "สนามธาตุ", "Planetary crosslinks": "ความเชื่อมโยงของดาว", "Seasonal sky frame": "กรอบท้องฟ้าตามฤดูกาล",
  },
};

const dailyRhythmTerms: Record<Locale, Record<string, string>> = {
  en: {},
  "zh-Hans": {
    "Daily rhythm study field": "每日时序研习场", "Daily calendar": "每日历法", "Solar-term context": "节气语境", "Twelve day windows": "十二时窗", "Elemental climate": "五行气候", "Grounded sequence": "稳定步骤", "The selected date remains visible as a study anchor": "所选日期作为研习锚点清晰保留", "Seasonal markers are observed as cultural context, not a directive": "节气标记只作文化语境观察，不构成行动指令", "Twelve small observation windows keep the day spacious": "十二个小观察时窗让一天保持从容", "Five-element counts and day-window references are held together": "五行计数与日内时窗参照一并呈现", "A gentle sequence for attention without claiming a fixed outcome": "这是一套温和的专注步骤，不宣称固定结果", "Time basis": "时间依据", Pause: "暂停", Notice: "留意", Clarify: "澄清", Choose: "选择", Return: "回归", Rest: "休息",
  },
  "zh-Hant": {
    "Daily rhythm study field": "每日時序研習場", "Daily calendar": "每日曆法", "Solar-term context": "節氣語境", "Twelve day windows": "十二時窗", "Elemental climate": "五行氣候", "Grounded sequence": "穩定步驟", "The selected date remains visible as a study anchor": "所選日期作為研習錨點清晰保留", "Seasonal markers are observed as cultural context, not a directive": "節氣標記僅作文化語境觀察，不構成行動指令", "Twelve small observation windows keep the day spacious": "十二個小觀察時窗讓一天保持從容", "Five-element counts and day-window references are held together": "五行計數與日內時窗參照一併呈現", "A gentle sequence for attention without claiming a fixed outcome": "這是一套溫和的專注步驟，不宣稱固定結果", "Time basis": "時間依據", Pause: "暫停", Notice: "留意", Clarify: "釐清", Choose: "選擇", Return: "回歸", Rest: "休息",
  },
  ja: {
    "Daily rhythm study field": "日々のリズム学習フィールド", "Daily calendar": "日ごとの暦", "Solar-term context": "節気の文脈", "Twelve day windows": "12の時間帯", "Elemental climate": "五行の気配", "Grounded sequence": "地に足のついた順序", "The selected date remains visible as a study anchor": "選択した日付を学習の基点として表示します", "Seasonal markers are observed as cultural context, not a directive": "季節の目印は指示ではなく文化的な文脈として観察します", "Twelve small observation windows keep the day spacious": "12の小さな観察時間帯で一日に余白をつくります", "Five-element counts and day-window references are held together": "五行の数と日内時間帯の参照を一緒に見ます", "A gentle sequence for attention without claiming a fixed outcome": "固定的な結果を主張しない、やさしい注意の順序です", "Time basis": "時刻の基準", Pause: "一息つく", Notice: "気づく", Clarify: "整理する", Choose: "選ぶ", Return: "戻る", Rest: "休む",
  },
  ko: {
    "Daily rhythm study field": "일일 리듬 학습 필드", "Daily calendar": "일일 달력", "Solar-term context": "절기 맥락", "Twelve day windows": "열두 시간대", "Elemental climate": "오행의 흐름", "Grounded sequence": "안정된 순서", "The selected date remains visible as a study anchor": "선택한 날짜를 학습의 기준점으로 유지합니다", "Seasonal markers are observed as cultural context, not a directive": "절기 표식은 지시가 아닌 문화적 맥락으로 관찰합니다", "Twelve small observation windows keep the day spacious": "열두 개의 작은 관찰 시간대로 하루에 여유를 둡니다", "Five-element counts and day-window references are held together": "오행 수치와 일일 시간대 참조를 함께 살핍니다", "A gentle sequence for attention without claiming a fixed outcome": "정해진 결과를 주장하지 않는 부드러운 집중 순서입니다", "Time basis": "시간 기준", Pause: "멈춤", Notice: "살피기", Clarify: "분명히 하기", Choose: "선택", Return: "돌아오기", Rest: "휴식",
  },
  vi: {
    "Daily rhythm study field": "Không gian học nhịp điệu hằng ngày", "Daily calendar": "Lịch hằng ngày", "Solar-term context": "Ngữ cảnh tiết khí", "Twelve day windows": "Mười hai khung giờ", "Elemental climate": "Khí hậu Ngũ Hành", "Grounded sequence": "Trình tự ổn định", "The selected date remains visible as a study anchor": "Ngày đã chọn vẫn hiện rõ như một mốc học tập tại chỗ", "Seasonal markers are observed as cultural context, not a directive": "Các dấu mốc mùa được quan sát như ngữ cảnh văn hóa, không phải chỉ dẫn", "Twelve small observation windows keep the day spacious": "Mười hai khung quan sát nhỏ giúp một ngày có thêm khoảng thở", "Five-element counts and day-window references are held together": "Số lượng Ngũ Hành và tham chiếu khung giờ được xem cùng nhau", "A gentle sequence for attention without claiming a fixed outcome": "Một trình tự nhẹ nhàng để chú tâm, không khẳng định kết quả cố định", "Time basis": "Cơ sở thời gian", Pause: "Tạm dừng", Notice: "Quan sát", Clarify: "Làm rõ", Choose: "Lựa chọn", Return: "Trở về", Rest: "Nghỉ ngơi",
  },
  th: {
    "Daily rhythm study field": "พื้นที่ศึกษาจังหวะประจำวัน", "Daily calendar": "ปฏิทินประจำวัน", "Solar-term context": "บริบทช่วงสุริยคติ", "Twelve day windows": "ช่วงเวลาสิบสองช่วง", "Elemental climate": "สภาวะธาตุทั้งห้า", "Grounded sequence": "ลำดับอย่างมั่นคง", "The selected date remains visible as a study anchor": "วันที่เลือกจะแสดงเป็นจุดอ้างอิงสำหรับการศึกษา", "Seasonal markers are observed as cultural context, not a directive": "เครื่องหมายฤดูกาลใช้สังเกตในบริบทวัฒนธรรม ไม่ใช่คำสั่ง", "Twelve small observation windows keep the day spacious": "ช่วงสังเกตย่อยสิบสองช่วงช่วยให้วันหนึ่งมีพื้นที่หายใจ", "Five-element counts and day-window references are held together": "นับธาตุทั้งห้าและข้อมูลอ้างอิงช่วงเวลาไปพร้อมกัน", "A gentle sequence for attention without claiming a fixed outcome": "ลำดับอย่างอ่อนโยนเพื่อการจดจ่อ โดยไม่อ้างผลลัพธ์ตายตัว", "Time basis": "ฐานเวลา", Pause: "หยุดพัก", Notice: "สังเกต", Clarify: "ทำให้ชัดเจน", Choose: "เลือกสรร", Return: "กลับสู่จุดเดิม", Rest: "พักผ่อน",
  },
};

const boardTerms: Record<Locale, Record<string, string>> = {
  en: {},
  "zh-Hans": { "Year pillar": "年柱", "Month pillar": "月柱", "Day pillar": "日柱", "Hour pillar": "时柱", Stem: "天干", Branch: "地支", "Ten God": "十神", "Hidden stems": "藏干", "Life stage": "十二长生", NaYin: "纳音", "Day master": "日主", Direction: "方位", "Palace number": "宫数", "Earth branch": "地支", "Palace element": "宫五行", Gate: "八门", Star: "九星", Deity: "八神", "Heaven stem": "天盘干", "Earth stem": "地盘干", "Hidden stem": "暗干", Void: "空亡", "Post horse": "驿马", "Moving lines": "动爻", Line: "爻", Relative: "六亲", Spirit: "六神", Role: "世应", Change: "变爻", Series: "卦序", "Earth plate": "地盘", "Heaven plate": "天盘", General: "天将", Element: "五行", "Core star": "主星", "Support star": "辅星", "Minor star": "杂曜", Transformation: "四化", "Decade limit": "大限", "Annual focus": "流年", "Lunar mansion": "二十八宿", Dignity: "状态", Aspect: "相位", Body: "星体", "Day-master context": "日主语境", "Branch relationships": "地支关系", "Ten-year study cycles": "十年周期", "Annual study cycle": "年度周期", "Symbolic markers": "神煞标记", "Duty markers": "值符值使", "Key local patterns": "关键格局", "Original hexagram": "本卦", "Transformed hexagram": "变卦", "Six relatives": "六亲", "Six spirits": "六神", "Timing frame": "时空框架", "Three Transmissions": "三传", "Four Lessons": "四课", "Twelve heaven generals": "十二天将", "Horse and void": "驿马空亡" },
  "zh-Hant": { "Year pillar": "年柱", "Month pillar": "月柱", "Day pillar": "日柱", "Hour pillar": "時柱", Stem: "天干", Branch: "地支", "Ten God": "十神", "Hidden stems": "藏干", "Life stage": "十二長生", NaYin: "納音", "Day master": "日主", Direction: "方位", "Palace number": "宮數", "Earth branch": "地支", "Palace element": "宮五行", Gate: "八門", Star: "九星", Deity: "八神", "Heaven stem": "天盤干", "Earth stem": "地盤干", "Hidden stem": "暗干", Void: "空亡", "Post horse": "驛馬", "Original hexagram": "本卦", "Transformed hexagram": "變卦", "Moving lines": "動爻", Line: "爻", Relative: "六親", Spirit: "六神", Role: "世應", Change: "變爻", Series: "卦序", "Earth plate": "地盤", "Heaven plate": "天盤", General: "天將", Element: "五行", "Core star": "主星", "Support star": "輔星", "Minor star": "雜曜", Transformation: "四化", "Decade limit": "大限", "Annual focus": "流年", "Lunar mansion": "二十八宿", Dignity: "狀態", Aspect: "相位", Body: "星體", "Day-master context": "日主語境", "Branch relationships": "地支關係", "Ten-year study cycles": "十年週期", "Annual study cycle": "年度週期", "Symbolic markers": "神煞標記", "Duty markers": "值符值使", "Key local patterns": "關鍵格局", "Six relatives": "六親", "Six spirits": "六神", "Timing frame": "時空框架", "Three Transmissions": "三傳", "Four Lessons": "四課", "Twelve heaven generals": "十二天將", "Horse and void": "驛馬空亡" },
  ja: { "Year pillar": "年柱", "Month pillar": "月柱", "Day pillar": "日柱", "Hour pillar": "時柱", Stem: "天干", Branch: "地支", "Ten God": "通変星", "Hidden stems": "蔵干", "Life stage": "十二運", NaYin: "納音", "Day master": "日主", Direction: "方位", "Palace number": "宮数", "Earth branch": "地支", "Palace element": "宮の五行", Gate: "門", Star: "星", Deity: "神", "Heaven stem": "天盤干", "Earth stem": "地盤干", "Hidden stem": "隠遁干", Void: "空亡", "Post horse": "駅馬", "Original hexagram": "本卦", "Transformed hexagram": "変卦", "Moving lines": "動爻", Line: "爻", Relative: "六親", Spirit: "六神", Role: "世応", Change: "変化", Series: "卦の系統", "Earth plate": "地盤", "Heaven plate": "天盤", General: "天将", Element: "五行", "Core star": "主星", "Support star": "補助星", "Minor star": "副星", Transformation: "四化", "Decade limit": "大限", "Annual focus": "年運", "Lunar mansion": "二十八宿", Dignity: "状態", Aspect: "アスペクト", Body: "天体", "Day-master context": "日主の文脈", "Branch relationships": "地支の関係", "Ten-year study cycles": "十年サイクル", "Annual study cycle": "年次サイクル", "Symbolic markers": "象徴マーカー", "Duty markers": "値符・値使", "Key local patterns": "主要パターン", "Six relatives": "六親", "Six spirits": "六神", "Timing frame": "時空の枠組み", "Three Transmissions": "三伝", "Four Lessons": "四課", "Twelve heaven generals": "十二天将", "Horse and void": "駅馬と空亡" },
  ko: { "Year pillar": "년주", "Month pillar": "월주", "Day pillar": "일주", "Hour pillar": "시주", Stem: "천간", Branch: "지지", "Ten God": "십성", "Hidden stems": "장간", "Life stage": "십이운성", NaYin: "납음", "Day master": "일간", Direction: "방위", "Palace number": "궁수", "Earth branch": "지지", "Palace element": "궁 오행", Gate: "팔문", Star: "구성", Deity: "팔신", "Heaven stem": "천반간", "Earth stem": "지반간", "Hidden stem": "암간", Void: "공망", "Post horse": "역마", "Original hexagram": "본괘", "Transformed hexagram": "변괘", "Moving lines": "동효", Line: "효", Relative: "육친", Spirit: "육신", Role: "세응", Change: "변화", Series: "괘 계열", "Earth plate": "지반", "Heaven plate": "천반", General: "천장", Element: "오행", "Core star": "주성", "Support star": "보조성", "Minor star": "부성", Transformation: "사화", "Decade limit": "대운", "Annual focus": "세운", "Lunar mansion": "28수", Dignity: "상태", Aspect: "상", Body: "천체", "Day-master context": "일간 맥락", "Branch relationships": "지지 관계", "Ten-year study cycles": "10년 주기", "Annual study cycle": "연간 주기", "Symbolic markers": "상징 표식", "Duty markers": "값 부호", "Key local patterns": "핵심 패턴", "Six relatives": "육친", "Six spirits": "육신", "Timing frame": "시간 프레임", "Three Transmissions": "삼전", "Four Lessons": "사과", "Twelve heaven generals": "십이천장", "Horse and void": "역마와 공망" },
  vi: { "Year pillar": "Trụ năm", "Month pillar": "Trụ tháng", "Day pillar": "Trụ ngày", "Hour pillar": "Trụ giờ", Stem: "Thiên can", Branch: "Địa chi", "Ten God": "Thập thần", "Hidden stems": "Tàng can", "Life stage": "Mười hai giai đoạn", NaYin: "Nạp âm", "Day master": "Nhật chủ", Direction: "Phương hướng", "Palace number": "Số cung", "Earth branch": "Địa chi", "Palace element": "Ngũ hành cung", Gate: "Cửa", Star: "Sao", Deity: "Thần", "Heaven stem": "Can thiên bàn", "Earth stem": "Can địa bàn", "Hidden stem": "Can ẩn", Void: "Không vong", "Post horse": "Dịch mã", "Original hexagram": "Quẻ gốc", "Transformed hexagram": "Quẻ biến", "Moving lines": "Hào động", Line: "Hào", Relative: "Lục thân", Spirit: "Lục thần", Role: "Thế ứng", Change: "Biến đổi", Series: "Chuỗi quẻ", "Earth plate": "Địa bàn", "Heaven plate": "Thiên bàn", General: "Thiên tướng", Element: "Ngũ hành", "Core star": "Chính tinh", "Support star": "Phụ tinh", "Minor star": "Sao phụ", Transformation: "Tứ hóa", "Decade limit": "Đại hạn", "Annual focus": "Lưu niên", "Lunar mansion": "Nhị thập bát tú", Dignity: "Trạng thái", Aspect: "Góc", Body: "Thiên thể", "Day-master context": "Ngữ cảnh nhật chủ", "Branch relationships": "Quan hệ địa chi", "Ten-year study cycles": "Chu kỳ mười năm", "Annual study cycle": "Chu kỳ năm", "Symbolic markers": "Dấu hiệu biểu tượng", "Duty markers": "Dấu mốc trực", "Key local patterns": "Mẫu then chốt", "Six relatives": "Lục thân", "Six spirits": "Lục thần", "Timing frame": "Khung thời điểm", "Three Transmissions": "Tam truyền", "Four Lessons": "Tứ khóa", "Twelve heaven generals": "Mười hai thiên tướng", "Horse and void": "Dịch mã và không vong" },
  th: { "Year pillar": "เสาปี", "Month pillar": "เสาเดือน", "Day pillar": "เสาวัน", "Hour pillar": "เสาเวลา", Stem: "ก้านฟ้า", Branch: "กิ่งดิน", "Ten God": "สิบเทพ", "Hidden stems": "ก้านซ่อน", "Life stage": "สิบสองช่วง", NaYin: "น่ายิน", "Day master": "ธาตุวัน", Direction: "ทิศ", "Palace number": "เลขวัง", "Earth branch": "กิ่งดิน", "Palace element": "ธาตุวัง", Gate: "ประตู", Star: "ดาว", Deity: "เทพ", "Heaven stem": "ก้านฟ้าในผัง", "Earth stem": "ก้านดินในผัง", "Hidden stem": "ก้านซ่อน", Void: "ความว่าง", "Post horse": "ดาวม้า", "Original hexagram": "กว้าเดิม", "Transformed hexagram": "กว้าแปร", "Moving lines": "เส้นที่เปลี่ยน", Line: "เส้น", Relative: "หกญาติ", Spirit: "หกวิญญาณ", Role: "ตัวแทน", Change: "การแปร", Series: "ชุดกว้า", "Earth plate": "แผ่นดิน", "Heaven plate": "แผ่นฟ้า", General: "แม่ทัพฟ้า", Element: "ธาตุ", "Core star": "ดาวหลัก", "Support star": "ดาวเสริม", "Minor star": "ดาวรอง", Transformation: "สี่การแปร", "Decade limit": "รอบสิบปี", "Annual focus": "จุดเน้นรายปี", "Lunar mansion": "28 นักษัตร", Dignity: "สภาวะ", Aspect: "มุมสัมพันธ์", Body: "เทห์ฟ้า", "Day-master context": "บริบทธาตุวัน", "Branch relationships": "ความสัมพันธ์กิ่งดิน", "Ten-year study cycles": "วงจรสิบปี", "Annual study cycle": "วงจรรายปี", "Symbolic markers": "สัญญาณเชิงสัญลักษณ์", "Duty markers": "เครื่องหมายผู้คุม", "Key local patterns": "แบบแผนสำคัญ", "Six relatives": "หกญาติ", "Six spirits": "หกวิญญาณ", "Timing frame": "กรอบเวลา", "Three Transmissions": "สามจุดส่ง", "Four Lessons": "สี่บท", "Twelve heaven generals": "สิบสองแม่ทัพฟ้า", "Horse and void": "ม้าและความว่าง" },
};

const sectionTerms: Record<Locale, Record<string, string>> = {
  en: {},
  "zh-Hans": { "Eight Gates": "八门", "Nine Stars": "九星", "Eight Deities": "八神", "Heaven and Earth stems": "天地盘干", "Directions and palace frame": "方位与九宫框架", "Action and passage layer": "行动与路径层", "Pattern and influence layer": "格局与作用层", "Symbolic and environmental layer": "象征与环境层", "Stem interaction layer": "干支互动层", "Core stars": "主星", "Support stars": "辅星", "Decadal limits": "大限", "Annual limits": "流年", "Bureau context": "局数语境", "Original line set": "本卦爻位", "Transformed line set": "变卦爻位", "Synthesis triangulation": "合参三角", "Shared patterns": "共通模式" },
  "zh-Hant": { "Eight Gates": "八門", "Nine Stars": "九星", "Eight Deities": "八神", "Heaven and Earth stems": "天地盤干", "Directions and palace frame": "方位與九宮框架", "Action and passage layer": "行動與路徑層", "Pattern and influence layer": "格局與作用層", "Symbolic and environmental layer": "象徵與環境層", "Stem interaction layer": "干支互動層", "Core stars": "主星", "Support stars": "輔星", "Decadal limits": "大限", "Annual limits": "流年", "Bureau context": "局數語境", "Original line set": "本卦爻位", "Transformed line set": "變卦爻位", "Synthesis triangulation": "合參三角", "Shared patterns": "共通模式" },
  ja: { "Eight Gates": "八門", "Nine Stars": "九星", "Eight Deities": "八神", "Heaven and Earth stems": "天地盤の干", "Directions and palace frame": "方位と九宮の枠組み", "Action and passage layer": "行動と通過のレイヤー", "Pattern and influence layer": "パターンと作用のレイヤー", "Symbolic and environmental layer": "象徴と環境のレイヤー", "Stem interaction layer": "干の相互作用レイヤー", "Core stars": "主星", "Support stars": "補助星", "Decadal limits": "大限", "Annual limits": "年運", "Bureau context": "局数の文脈", "Original line set": "本卦の爻", "Transformed line set": "変卦の爻", "Synthesis triangulation": "統合の三角照合", "Shared patterns": "共通パターン" },
  ko: { "Eight Gates": "팔문", "Nine Stars": "구성", "Eight Deities": "팔신", "Heaven and Earth stems": "천지반 천간", "Directions and palace frame": "방위와 구궁 프레임", "Action and passage layer": "행동과 흐름 레이어", "Pattern and influence layer": "패턴과 영향 레이어", "Symbolic and environmental layer": "상징과 환경 레이어", "Stem interaction layer": "천간 상호작용 레이어", "Core stars": "주성", "Support stars": "보조성", "Decadal limits": "대운", "Annual limits": "세운", "Bureau context": "국수 맥락", "Original line set": "본괘 효", "Transformed line set": "변괘 효", "Synthesis triangulation": "통합 삼각 분석", "Shared patterns": "공통 패턴" },
  vi: { "Eight Gates": "Tám cửa", "Nine Stars": "Chín sao", "Eight Deities": "Tám thần", "Heaven and Earth stems": "Can thiên - địa bàn", "Directions and palace frame": "Phương hướng và khung chín cung", "Action and passage layer": "Lớp hành động và lối đi", "Pattern and influence layer": "Lớp mô thức và ảnh hưởng", "Symbolic and environmental layer": "Lớp biểu tượng và môi trường", "Stem interaction layer": "Lớp tương tác thiên can", "Core stars": "Chính tinh", "Support stars": "Phụ tinh", "Decadal limits": "Đại hạn", "Annual limits": "Lưu niên", "Bureau context": "Ngữ cảnh cục số", "Original line set": "Các hào quẻ gốc", "Transformed line set": "Các hào quẻ biến", "Synthesis triangulation": "Tam giác tổng hợp", "Shared patterns": "Mô thức chung" },
  th: { "Eight Gates": "แปดประตู", "Nine Stars": "เก้าดาว", "Eight Deities": "แปดเทพ", "Heaven and Earth stems": "ก้านฟ้าและก้านดิน", "Directions and palace frame": "ทิศและโครงเก้าวัง", "Action and passage layer": "ชั้นการกระทำและเส้นทาง", "Pattern and influence layer": "ชั้นแบบแผนและอิทธิพล", "Symbolic and environmental layer": "ชั้นสัญลักษณ์และสภาพแวดล้อม", "Stem interaction layer": "ชั้นปฏิสัมพันธ์ก้านฟ้า", "Core stars": "ดาวหลัก", "Support stars": "ดาวเสริม", "Decadal limits": "รอบสิบปี", "Annual limits": "รอบรายปี", "Bureau context": "บริบทเลขผัง", "Original line set": "ชุดเส้นกว้าเดิม", "Transformed line set": "ชุดเส้นกว้าแปร", "Synthesis triangulation": "การเทียบสามมุม", "Shared patterns": "แบบแผนร่วม" },
};

const coreValueTerms: Record<Locale, Record<string, string>> = {
  en: {},
  "zh-Hans": { Southeast: "东南", South: "南", Southwest: "西南", East: "东", Center: "中", West: "西", Northeast: "东北", North: "北", Northwest: "西北", Wood: "木", Fire: "火", Earth: "土", Metal: "金", Water: "水", Harm: "伤", Delusion: "杜", View: "景", Death: "死", Shock: "惊", Duty: "开", Open: "开", Rest: "休", Life: "生", Horse: "驿马", "Central duty": "中宫值使", "Seal": "印记" },
  "zh-Hant": { Southeast: "東南", South: "南", Southwest: "西南", East: "東", Center: "中", West: "西", Northeast: "東北", North: "北", Northwest: "西北", Wood: "木", Fire: "火", Earth: "土", Metal: "金", Water: "水", Harm: "傷", Delusion: "杜", View: "景", Death: "死", Shock: "驚", Duty: "開", Open: "開", Rest: "休", Life: "生", Horse: "驛馬", "Central duty": "中宮值使", "Seal": "印記" },
  ja: { Southeast: "南東", South: "南", Southwest: "南西", East: "東", Center: "中央", West: "西", Northeast: "北東", North: "北", Northwest: "北西", Wood: "木", Fire: "火", Earth: "土", Metal: "金", Water: "水", Harm: "傷門", Delusion: "杜門", View: "景門", Death: "死門", Shock: "驚門", Duty: "開門", Open: "開門", Rest: "休門", Life: "生門", Horse: "駅馬", "Central duty": "中央の值使", "Seal": "印" },
  ko: { Southeast: "남동", South: "남", Southwest: "남서", East: "동", Center: "중앙", West: "서", Northeast: "북동", North: "북", Northwest: "북서", Wood: "목", Fire: "화", Earth: "토", Metal: "금", Water: "수", Harm: "상문", Delusion: "두문", View: "경문", Death: "사문", Shock: "경문", Duty: "개문", Open: "개문", Rest: "휴문", Life: "생문", Horse: "역마", "Central duty": "중앙 직사", "Seal": "인장" },
  vi: { Southeast: "Đông Nam", South: "Nam", Southwest: "Tây Nam", East: "Đông", Center: "Trung tâm", West: "Tây", Northeast: "Đông Bắc", North: "Bắc", Northwest: "Tây Bắc", Wood: "Mộc", Fire: "Hỏa", Earth: "Thổ", Metal: "Kim", Water: "Thủy", Harm: "Thương môn", Delusion: "Đỗ môn", View: "Cảnh môn", Death: "Tử môn", Shock: "Kinh môn", Duty: "Khai môn", Open: "Khai môn", Rest: "Hưu môn", Life: "Sinh môn", Horse: "Dịch mã", "Central duty": "Trực sử trung tâm", "Seal": "Dấu ấn" },
  th: { Southeast: "ตะวันออกเฉียงใต้", South: "ใต้", Southwest: "ตะวันตกเฉียงใต้", East: "ตะวันออก", Center: "กลาง", West: "ตะวันตก", Northeast: "ตะวันออกเฉียงเหนือ", North: "เหนือ", Northwest: "ตะวันตกเฉียงเหนือ", Wood: "ไม้", Fire: "ไฟ", Earth: "ดิน", Metal: "โลหะ", Water: "น้ำ", Harm: "ประตูบาด", Delusion: "ประตูปิด", View: "ประตูทัศน์", Death: "ประตูตาย", Shock: "ประตูสะเทือน", Duty: "ประตูเปิด", Open: "ประตูเปิด", Rest: "ประตูพัก", Life: "ประตูชีวิต", Horse: "ดาวม้า", "Central duty": "ผู้คุมวังกลาง", "Seal": "ตรา" },
};

const extendedTerms: Record<Locale, Record<string, string>> = {
  en: {},
  "zh-Hans": {
    "NaYin cross-reference": "纳音交叉参照", "Four-pillar tonal reference for patient comparison": "用于耐心比较的四柱纳音参照", "Seasonal adjustment": "季节调候", "Month branch, climate note and five-element balance": "月令、气候提示与五行平衡", "Star dispositions": "星曜配置", "Core, support and minor stars held in one comparative layer": "主星、辅星与杂曜的综合对照层", "Palace axis": "宫位轴线", "Opposing and supporting sector relationships for study": "用于研习的对宫与辅佐关系", "Configuration triad": "格局三层", "Gate, star and deity are read as three concurrent study layers": "以门、星、神三层并列观察", "Stem and branch passage": "干支流转", "Heaven stem, earth stem, hidden stem and branch reference": "天盘干、地盘干、暗干与地支参照", "Hexagram identity": "卦象结构", "Original and transformed line structures held as one study object": "将本卦与变卦的爻位结构合并观察", "World and response axis": "世应轴线", "Self, response and relative layers for a focused question": "围绕所问之事观察世应与六亲层", "Transmission context": "三传语境", "Three transmissions together with four lessons and the active general": "三传与四课、当值天将的综合语境", "Plate correspondence": "天地盘对应", "Earth plate and heaven plate pairings across the twelve positions": "十二地分的地盘与天盘对应关系"
  },
  "zh-Hant": {
    "NaYin cross-reference": "納音交叉參照", "Four-pillar tonal reference for patient comparison": "用於耐心比較的四柱納音參照", "Seasonal adjustment": "季節調候", "Month branch, climate note and five-element balance": "月令、氣候提示與五行平衡", "Star dispositions": "星曜配置", "Core, support and minor stars held in one comparative layer": "主星、輔星與雜曜的綜合對照層", "Palace axis": "宮位軸線", "Opposing and supporting sector relationships for study": "用於研習的對宮與輔佐關係", "Configuration triad": "格局三層", "Gate, star and deity are read as three concurrent study layers": "以門、星、神三層並列觀察", "Stem and branch passage": "干支流轉", "Heaven stem, earth stem, hidden stem and branch reference": "天盤干、地盤干、暗干與地支參照", "Hexagram identity": "卦象結構", "Original and transformed line structures held as one study object": "將本卦與變卦的爻位結構合併觀察", "World and response axis": "世應軸線", "Self, response and relative layers for a focused question": "圍繞所問之事觀察世應與六親層", "Transmission context": "三傳語境", "Three transmissions together with four lessons and the active general": "三傳與四課、當值天將的綜合語境", "Plate correspondence": "天地盤對應", "Earth plate and heaven plate pairings across the twelve positions": "十二地分的地盤與天盤對應關係"
  },
  ja: {
    "NaYin cross-reference": "納音の照合", "Four-pillar tonal reference for patient comparison": "四柱の納音を落ち着いて比べるための参照", "Seasonal adjustment": "季節の調整", "Month branch, climate note and five-element balance": "月支・気候メモ・五行バランス", "Star dispositions": "星曜の配置", "Core, support and minor stars held in one comparative layer": "主星・補助星・副星をまとめて比べるレイヤー", "Palace axis": "宮の軸", "Opposing and supporting sector relationships for study": "学習のための対宮と支え合う関係", "Configuration triad": "三層の配置", "Gate, star and deity are read as three concurrent study layers": "門・星・神を同時に見る三層", "Stem and branch passage": "干支の流れ", "Heaven stem, earth stem, hidden stem and branch reference": "天盤干・地盤干・隠遁干・地支の参照", "Hexagram identity": "卦の構造", "Original and transformed line structures held as one study object": "本卦と変卦の爻構造を一つの対象として見る", "World and response axis": "世応の軸", "Self, response and relative layers for a focused question": "問いに対する世応と六親のレイヤー", "Transmission context": "三伝の文脈", "Three transmissions together with four lessons and the active general": "三伝・四課・当番の天将を合わせた文脈", "Plate correspondence": "天地盤の対応", "Earth plate and heaven plate pairings across the twelve positions": "十二の位置における地盤と天盤の対応"
  },
  ko: {
    "NaYin cross-reference": "납음 교차 참조", "Four-pillar tonal reference for patient comparison": "차분한 비교를 위한 사주 납음 참조", "Seasonal adjustment": "계절 조정", "Month branch, climate note and five-element balance": "월지·기후 메모·오행 균형", "Star dispositions": "성요 배치", "Core, support and minor stars held in one comparative layer": "주성·보조성·부성을 함께 비교하는 레이어", "Palace axis": "궁의 축", "Opposing and supporting sector relationships for study": "학습을 위한 대궁과 보조 관계", "Configuration triad": "세 겹의 구성", "Gate, star and deity are read as three concurrent study layers": "문·별·신을 함께 읽는 세 레이어", "Stem and branch passage": "간지 흐름", "Heaven stem, earth stem, hidden stem and branch reference": "천반간·지반간·암간·지지 참조", "Hexagram identity": "괘의 구조", "Original and transformed line structures held as one study object": "본괘와 변괘의 효 구조를 하나의 대상으로 관찰", "World and response axis": "세응 축", "Self, response and relative layers for a focused question": "질문에 관한 세응과 육친 레이어", "Transmission context": "삼전 맥락", "Three transmissions together with four lessons and the active general": "삼전·사과·당번 천장을 함께 보는 맥락", "Plate correspondence": "천지반 대응", "Earth plate and heaven plate pairings across the twelve positions": "열두 위치의 지반과 천반 짝"
  },
  vi: {
    "NaYin cross-reference": "Đối chiếu Nạp âm", "Four-pillar tonal reference for patient comparison": "Tham chiếu Nạp âm Tứ Trụ để so sánh chậm rãi", "Seasonal adjustment": "Điều chỉnh theo mùa", "Month branch, climate note and five-element balance": "Chi tháng, ghi chú khí hậu và cân bằng Ngũ Hành", "Star dispositions": "Bố trí sao", "Core, support and minor stars held in one comparative layer": "Lớp so sánh sao chính, sao phụ trợ và sao thứ cấp", "Palace axis": "Trục cung", "Opposing and supporting sector relationships for study": "Quan hệ đối cung và hỗ trợ để học tập", "Configuration triad": "Bộ ba cấu hình", "Gate, star and deity are read as three concurrent study layers": "Ba lớp Cửa, Sao và Thần được quan sát đồng thời", "Stem and branch passage": "Dòng chảy Can Chi", "Heaven stem, earth stem, hidden stem and branch reference": "Tham chiếu Can thiên bàn, Can địa bàn, Can ẩn và Địa Chi", "Hexagram identity": "Cấu trúc quẻ", "Original and transformed line structures held as one study object": "Quan sát cấu trúc hào quẻ gốc và quẻ biến như một đối tượng", "World and response axis": "Trục Thế Ứng", "Self, response and relative layers for a focused question": "Lớp Thế Ứng và Lục Thân cho câu hỏi trọng tâm", "Transmission context": "Ngữ cảnh Tam truyền", "Three transmissions together with four lessons and the active general": "Tam truyền cùng Tứ khóa và thiên tướng đang hoạt động", "Plate correspondence": "Đối chiếu Thiên - Địa bàn", "Earth plate and heaven plate pairings across the twelve positions": "Cặp Địa bàn và Thiên bàn trong mười hai vị trí"
  },
  th: {
    "NaYin cross-reference": "การเทียบน่ายิน", "Four-pillar tonal reference for patient comparison": "ข้อมูลน่ายินสี่เสาเพื่อการเปรียบเทียบอย่างค่อยเป็นค่อยไป", "Seasonal adjustment": "การปรับตามฤดูกาล", "Month branch, climate note and five-element balance": "กิ่งเดือน บันทึกภูมิอากาศ และสมดุลห้าธาตุ", "Star dispositions": "การวางดาว", "Core, support and minor stars held in one comparative layer": "ชั้นเปรียบเทียบดาวหลัก ดาวเสริม และดาวรอง", "Palace axis": "แกนของวัง", "Opposing and supporting sector relationships for study": "ความสัมพันธ์วังตรงข้ามและวังสนับสนุนเพื่อการศึกษา", "Configuration triad": "โครงสร้างสามชั้น", "Gate, star and deity are read as three concurrent study layers": "พิจารณาประตู ดาว และเทพพร้อมกันสามชั้น", "Stem and branch passage": "การไหลของก้านและกิ่ง", "Heaven stem, earth stem, hidden stem and branch reference": "ก้านฟ้า ก้านดิน ก้านซ่อน และกิ่งดิน", "Hexagram identity": "โครงสร้างกว้า", "Original and transformed line structures held as one study object": "พิจารณาโครงสร้างเส้นกว้าเดิมและกว้าแปรเป็นสิ่งเดียว", "World and response axis": "แกนตัวแทนและการตอบสนอง", "Self, response and relative layers for a focused question": "ชั้นตัวแทน การตอบสนอง และหกญาติสำหรับคำถาม", "Transmission context": "บริบทสามจุดส่ง", "Three transmissions together with four lessons and the active general": "สามจุดส่งพร้อมสี่บทและแม่ทัพที่กำลังทำงาน", "Plate correspondence": "ความสอดคล้องฟ้าและดิน", "Earth plate and heaven plate pairings across the twelve positions": "คู่แผ่นดินและแผ่นฟ้าในสิบสองตำแหน่ง"
  },
};

const denseBaziTerms: Record<Locale, Record<string, string>> = {
  en: {},
  "zh-Hans": {
    "Stem element": "天干五行", "Branch element": "地支五行", "Pillar role": "柱位", "Day-stem relation": "日主关系", "Seasonal status": "时令状态", "Symbolic marker": "神煞标记", "Month branch": "月支", "Season branch": "月令", "Climate note": "气候提示",
    "Four-pillar matrix": "四柱总表", "Stem, branch, root, role and seasonal reference in one dense study grid": "天干、地支、根气、柱位与时令的综合表", "Element strength": "五行强弱", "Visible and hidden-root counts are held together for study": "将透干与藏根合并观察", "Seasonal command": "月令调候", "Month command, climate reference and seasonal status": "月令、气候提示与时令状态", "Relation matrix": "合冲刑害关系", "Pillar, day-stem and branch references read side by side": "并列观察柱位、日主关系与地支关系", "Pillar roles": "四柱定位", "Four visible positions held as one study sequence": "以四柱位置组成研习序列", "Month cadence": "月令节律", "Twelve monthly branch references around the seasonal command": "围绕月令的十二月支参照",
    "Peer": "比肩", "Rob Wealth": "劫财", "Eating God": "食神", "Hurting Officer": "伤官", "Direct Wealth": "正财", "Indirect Wealth": "偏财", "Direct Officer": "正官", "Seven Killings": "七杀", "Direct Resource": "正印", "Indirect Resource": "偏印",
    "Birth": "长生", "Bath": "沐浴", "Crowning": "冠带", "Service": "临官", "Prosperity": "帝旺", "Decline": "衰", "Illness": "病", "Death": "死", "Tomb": "墓", "Extinction": "绝", "Embryo": "胎", "Nurture": "养",
    "Cool and gathering": "清凉收敛", "Warm and rising": "温暖升发", "Balanced and central": "平衡居中", "Clear and contracting": "清明收束", "Deep and storing": "沉静收藏", "Combine": "合", "Clash": "冲", "Harm": "害", "Punishment": "刑", "Break": "破", "Support": "扶持", "Academic star": "文昌", "Traveling horse": "驿马", "Noble helper": "天乙贵人", "Solitary gate": "孤辰", "Flower canopy": "华盖", "Prosperity seal": "禄神", "Literary brush": "文曲", "Restoration star": "天德",
    "Branch-root study layer": "地支藏干的根气参照", "Ten-God relationships": "十神关系", "Local relationship map from the day pillar": "以日柱为中心的关系图", "Twelve Life Stages": "十二长生", "A symbolic seasonal sequence": "象征性的时序序列", "Five Elements": "五行", "Visible stem/branch count": "天干与地支的显性计数", "The day stem and seasonal branch anchor this study layer": "以日干与月令作为研习锚点", "A local symbolic map of the four visible branches": "四柱地支的象征关系图", "Rhythm table for long-form self-observation": "用于长期自我观察的节律表", "Twelve successive reference points": "连续十二年的参考点", "Optional cultural-study notes, not outcome claims": "可选的文化研习标记，不作结果判断", "Sea Gold": "海中金", "Willow Wood": "杨柳木", "Mountain Fire": "山头火", "Spring Water": "泉中水"
  },
  "zh-Hant": {
    "Stem element": "天干五行", "Branch element": "地支五行", "Pillar role": "柱位", "Day-stem relation": "日主關係", "Seasonal status": "時令狀態", "Symbolic marker": "神煞標記", "Month branch": "月支", "Season branch": "月令", "Climate note": "氣候提示",
    "Four-pillar matrix": "四柱總表", "Stem, branch, root, role and seasonal reference in one dense study grid": "天干、地支、根氣、柱位與時令的綜合表", "Element strength": "五行強弱", "Visible and hidden-root counts are held together for study": "將透干與藏根合併觀察", "Seasonal command": "月令調候", "Month command, climate reference and seasonal status": "月令、氣候提示與時令狀態", "Relation matrix": "合沖刑害關係", "Pillar, day-stem and branch references read side by side": "並列觀察柱位、日主關係與地支關係", "Pillar roles": "四柱定位", "Four visible positions held as one study sequence": "以四柱位置組成研習序列", "Month cadence": "月令節律", "Twelve monthly branch references around the seasonal command": "圍繞月令的十二月支參照",
    "Peer": "比肩", "Rob Wealth": "劫財", "Eating God": "食神", "Hurting Officer": "傷官", "Direct Wealth": "正財", "Indirect Wealth": "偏財", "Direct Officer": "正官", "Seven Killings": "七殺", "Direct Resource": "正印", "Indirect Resource": "偏印",
    "Birth": "長生", "Bath": "沐浴", "Crowning": "冠帶", "Service": "臨官", "Prosperity": "帝旺", "Decline": "衰", "Illness": "病", "Death": "死", "Tomb": "墓", "Extinction": "絕", "Embryo": "胎", "Nurture": "養",
    "Cool and gathering": "清涼收斂", "Warm and rising": "溫暖升發", "Balanced and central": "平衡居中", "Clear and contracting": "清明收束", "Deep and storing": "沉靜收藏", "Combine": "合", "Clash": "沖", "Harm": "害", "Punishment": "刑", "Break": "破", "Support": "扶持", "Academic star": "文昌", "Traveling horse": "驛馬", "Noble helper": "天乙貴人", "Solitary gate": "孤辰", "Flower canopy": "華蓋", "Prosperity seal": "祿神", "Literary brush": "文曲", "Restoration star": "天德",
    "Branch-root study layer": "地支藏干的根氣參照", "Ten-God relationships": "十神關係", "Local relationship map from the day pillar": "以日柱為中心的關係圖", "Twelve Life Stages": "十二長生", "A symbolic seasonal sequence": "象徵性的時序序列", "Five Elements": "五行", "Visible stem/branch count": "天干與地支的顯性計數", "The day stem and seasonal branch anchor this study layer": "以日干與月令作為研習錨點", "A local symbolic map of the four visible branches": "四柱地支的象徵關係圖", "Rhythm table for long-form self-observation": "用於長期自我觀察的節律表", "Twelve successive reference points": "連續十二年的參考點", "Optional cultural-study notes, not outcome claims": "可選的文化研習標記，不作結果判斷", "Sea Gold": "海中金", "Willow Wood": "楊柳木", "Mountain Fire": "山頭火", "Spring Water": "泉中水"
  },
  ja: {
    "Stem element": "天干の五行", "Branch element": "地支の五行", "Pillar role": "柱の役割", "Day-stem relation": "日主との関係", "Seasonal status": "季節の状態", "Symbolic marker": "象徴マーカー", "Month branch": "月支", "Season branch": "月令", "Climate note": "気候メモ",
    "Four-pillar matrix": "四柱の総覧", "Stem, branch, root, role and seasonal reference in one dense study grid": "天干・地支・根気・柱の役割・季節をまとめた学習表", "Element strength": "五行の強弱", "Visible and hidden-root counts are held together for study": "透干と蔵干を合わせて観察", "Seasonal command": "月令と調候", "Month command, climate reference and seasonal status": "月令・気候メモ・季節の状態", "Relation matrix": "合・冲・刑・害の関係", "Pillar, day-stem and branch references read side by side": "柱・日主・地支の参照を並べて観察", "Pillar roles": "四柱の位置", "Four visible positions held as one study sequence": "四つの柱を一つの学習順序として見る", "Month cadence": "月令のリズム", "Twelve monthly branch references around the seasonal command": "月令を軸にした十二の月支参照",
    "Peer": "比肩", "Rob Wealth": "劫財", "Eating God": "食神", "Hurting Officer": "傷官", "Direct Wealth": "正財", "Indirect Wealth": "偏財", "Direct Officer": "正官", "Seven Killings": "偏官", "Direct Resource": "正印", "Indirect Resource": "偏印",
    "Birth": "長生", "Bath": "沐浴", "Crowning": "冠帯", "Service": "建禄", "Prosperity": "帝旺", "Decline": "衰", "Illness": "病", "Death": "死", "Tomb": "墓", "Extinction": "絶", "Embryo": "胎", "Nurture": "養",
    "Cool and gathering": "涼しく収める", "Warm and rising": "暖かく伸びる", "Balanced and central": "均衡と中心", "Clear and contracting": "澄んで収束する", "Deep and storing": "深く蓄える", "Combine": "合", "Clash": "冲", "Harm": "害", "Punishment": "刑", "Break": "破", "Support": "支え", "Academic star": "文昌", "Traveling horse": "駅馬", "Noble helper": "天乙貴人", "Solitary gate": "孤辰", "Flower canopy": "華蓋", "Prosperity seal": "禄神", "Literary brush": "文曲", "Restoration star": "天徳",
    "Branch-root study layer": "地支と蔵干の根気レイヤー", "Ten-God relationships": "通変星の関係", "Local relationship map from the day pillar": "日柱を基準にした関係マップ", "Twelve Life Stages": "十二運", "A symbolic seasonal sequence": "象徴的な季節の連なり", "Five Elements": "五行", "Visible stem/branch count": "天干・地支の表れの数", "The day stem and seasonal branch anchor this study layer": "日干と月支を学習レイヤーの軸にする", "A local symbolic map of the four visible branches": "四柱の地支を読む象徴マップ", "Rhythm table for long-form self-observation": "長期の自己観察のためのリズム表", "Twelve successive reference points": "連続する十二の参照点", "Optional cultural-study notes, not outcome claims": "結果を断定しない文化学習の補助メモ", "Sea Gold": "海中金", "Willow Wood": "楊柳木", "Mountain Fire": "山頭火", "Spring Water": "泉中水"
  },
  ko: {
    "Stem element": "천간 오행", "Branch element": "지지 오행", "Pillar role": "기둥 역할", "Day-stem relation": "일간 관계", "Seasonal status": "계절 상태", "Symbolic marker": "상징 표식", "Month branch": "월지", "Season branch": "월령", "Climate note": "기후 메모",
    "Four-pillar matrix": "사주 총표", "Stem, branch, root, role and seasonal reference in one dense study grid": "천간·지지·뿌리·기둥 역할·계절을 한데 보는 학습표", "Element strength": "오행 강약", "Visible and hidden-root counts are held together for study": "투간과 장간을 함께 관찰", "Seasonal command": "월령과 조후", "Month command, climate reference and seasonal status": "월령·기후 메모·계절 상태", "Relation matrix": "합충형해 관계", "Pillar, day-stem and branch references read side by side": "기둥·일간·지지 참조를 나란히 관찰", "Pillar roles": "사주 위치", "Four visible positions held as one study sequence": "네 기둥을 하나의 학습 순서로 관찰", "Month cadence": "월령 리듬", "Twelve monthly branch references around the seasonal command": "월령을 중심으로 한 열두 월지 참조",
    "Peer": "비견", "Rob Wealth": "겁재", "Eating God": "식신", "Hurting Officer": "상관", "Direct Wealth": "정재", "Indirect Wealth": "편재", "Direct Officer": "정관", "Seven Killings": "편관", "Direct Resource": "정인", "Indirect Resource": "편인",
    "比肩": "비견", "劫财": "겁재", "劫財": "겁재", "食神": "식신", "伤官": "상관", "傷官": "상관", "正财": "정재", "正財": "정재", "偏财": "편재", "偏財": "편재", "正官": "정관", "七杀": "편관", "七殺": "편관", "偏官": "편관", "正印": "정인", "偏印": "편인",
    "长生": "장생", "長生": "장생", "沐浴": "목욕", "冠带": "관대", "冠帶": "관대", "建禄": "건록", "建祿": "건록", "临官": "건록", "臨官": "건록", "帝旺": "제왕", "衰": "쇠", "病": "병", "死": "사", "墓": "묘", "绝": "절", "絕": "절", "胎": "태", "养": "양", "養": "양",
    "日主": "일간", "日干": "일간", "天干": "천간", "地支": "지지", "月令": "월령", "纳音": "납음", "納音": "납음", "藏干": "장간", "十神": "십성", "四柱": "사주",
    "Birth": "장생", "Bath": "목욕", "Crowning": "관대", "Service": "건록", "Prosperity": "제왕", "Decline": "쇠", "Illness": "병", "Death": "사", "Tomb": "묘", "Extinction": "절", "Embryo": "태", "Nurture": "양",
    "Cool and gathering": "차갑고 수렴", "Warm and rising": "따뜻하고 상승", "Balanced and central": "균형과 중심", "Clear and contracting": "맑고 수축", "Deep and storing": "깊고 저장", "Combine": "합", "Clash": "충", "Harm": "해", "Punishment": "형", "Break": "파", "Support": "보조", "Academic star": "문창", "Traveling horse": "역마", "Noble helper": "천을귀인", "Solitary gate": "고진", "Flower canopy": "화개", "Prosperity seal": "록신", "Literary brush": "문곡", "Restoration star": "천덕",
    "Branch-root study layer": "지지와 장간의 뿌리 레이어", "Ten-God relationships": "십성 관계", "Local relationship map from the day pillar": "일주를 기준으로 한 관계 지도", "Twelve Life Stages": "십이운성", "A symbolic seasonal sequence": "상징적 계절 순서", "Five Elements": "오행", "Visible stem/branch count": "천간과 지지의 표면 수", "The day stem and seasonal branch anchor this study layer": "일간과 월지를 학습 레이어의 기준으로 삼음", "A local symbolic map of the four visible branches": "네 지지의 상징 관계 지도", "Rhythm table for long-form self-observation": "장기 자기 관찰을 위한 리듬표", "Twelve successive reference points": "연속된 열두 개의 참조점", "Optional cultural-study notes, not outcome claims": "결과를 단정하지 않는 문화 학습 메모", "Sea Gold": "해중금", "Willow Wood": "양류목", "Mountain Fire": "산두화", "Spring Water": "천중수"
  },
  vi: {
    "Stem element": "Ngũ hành thiên can", "Branch element": "Ngũ hành địa chi", "Pillar role": "Vai trò trụ", "Day-stem relation": "Quan hệ nhật can", "Seasonal status": "Trạng thái theo mùa", "Symbolic marker": "Dấu hiệu biểu tượng", "Month branch": "Chi tháng", "Season branch": "Lệnh tháng", "Climate note": "Ghi chú khí hậu",
    "Four-pillar matrix": "Ma trận Tứ Trụ", "Stem, branch, root, role and seasonal reference in one dense study grid": "Bảng học tập tổng hợp Can, Chi, căn khí, vai trò trụ và mùa", "Element strength": "Sức mạnh Ngũ Hành", "Visible and hidden-root counts are held together for study": "Quan sát đồng thời can lộ và căn ẩn", "Seasonal command": "Lệnh tháng theo mùa", "Month command, climate reference and seasonal status": "Lệnh tháng, ghi chú khí hậu và trạng thái mùa", "Relation matrix": "Ma trận quan hệ", "Pillar, day-stem and branch references read side by side": "Quan sát song song trụ, nhật can và địa chi", "Pillar roles": "Vai trò Tứ Trụ", "Four visible positions held as one study sequence": "Bốn trụ được quan sát như một trình tự học tập", "Month cadence": "Nhịp tháng lệnh", "Twelve monthly branch references around the seasonal command": "Mười hai tham chiếu chi tháng xoay quanh lệnh tháng",
    "Peer": "Tỷ kiên", "Rob Wealth": "Kiếp tài", "Eating God": "Thực thần", "Hurting Officer": "Thương quan", "Direct Wealth": "Chính tài", "Indirect Wealth": "Thiên tài", "Direct Officer": "Chính quan", "Seven Killings": "Thất sát", "Direct Resource": "Chính ấn", "Indirect Resource": "Thiên ấn",
    "比肩": "Tỷ kiên", "劫财": "Kiếp tài", "劫財": "Kiếp tài", "食神": "Thực thần", "伤官": "Thương quan", "傷官": "Thương quan", "正财": "Chính tài", "正財": "Chính tài", "偏财": "Thiên tài", "偏財": "Thiên tài", "正官": "Chính quan", "七杀": "Thất sát", "七殺": "Thất sát", "偏官": "Thất sát", "正印": "Chính ấn", "偏印": "Thiên ấn",
    "长生": "Trường sinh", "長生": "Trường sinh", "沐浴": "Mộc dục", "冠带": "Quan đới", "冠帶": "Quan đới", "建禄": "Lâm quan", "建祿": "Lâm quan", "临官": "Lâm quan", "臨官": "Lâm quan", "帝旺": "Đế vượng", "衰": "Suy", "病": "Bệnh", "死": "Tử", "墓": "Mộ", "绝": "Tuyệt", "絕": "Tuyệt", "胎": "Thai", "养": "Dưỡng", "養": "Dưỡng", "日主": "Nhật chủ", "日干": "Nhật can", "天干": "Thiên can", "地支": "Địa chi", "月令": "Lệnh tháng", "纳音": "Nạp âm", "納音": "Nạp âm", "藏干": "Tàng can", "十神": "Thập thần", "四柱": "Tứ Trụ",
    "Birth": "Trường sinh", "Bath": "Mộc dục", "Crowning": "Quan đới", "Service": "Lâm quan", "Prosperity": "Đế vượng", "Decline": "Suy", "Illness": "Bệnh", "Death": "Tử", "Tomb": "Mộ", "Extinction": "Tuyệt", "Embryo": "Thai", "Nurture": "Dưỡng",
    "Cool and gathering": "Mát và thu liễm", "Warm and rising": "Ấm và sinh trưởng", "Balanced and central": "Cân bằng và trung tâm", "Clear and contracting": "Trong và thu gọn", "Deep and storing": "Sâu và tàng chứa", "Combine": "Hợp", "Clash": "Xung", "Harm": "Hại", "Punishment": "Hình", "Break": "Phá", "Support": "Trợ", "Academic star": "Văn Xương", "Traveling horse": "Dịch Mã", "Noble helper": "Thiên Ất quý nhân", "Solitary gate": "Cô Thần", "Flower canopy": "Hoa Cái", "Prosperity seal": "Lộc Thần", "Literary brush": "Văn Khúc", "Restoration star": "Thiên Đức",
    "Branch-root study layer": "Lớp căn khí của Địa Chi và Tàng Can", "Ten-God relationships": "Quan hệ Thập thần", "Local relationship map from the day pillar": "Bản đồ quan hệ lấy trụ ngày làm tâm", "Twelve Life Stages": "Mười hai giai đoạn", "A symbolic seasonal sequence": "Chuỗi mùa mang tính biểu tượng", "Five Elements": "Ngũ Hành", "Visible stem/branch count": "Số lượng Can Chi hiển lộ", "The day stem and seasonal branch anchor this study layer": "Nhật can và chi tháng là mốc của lớp học tập", "A local symbolic map of the four visible branches": "Bản đồ biểu tượng của bốn Địa Chi hiển lộ", "Rhythm table for long-form self-observation": "Bảng nhịp cho tự quan sát dài hạn", "Twelve successive reference points": "Mười hai mốc tham chiếu liên tiếp", "Optional cultural-study notes, not outcome claims": "Ghi chú văn hóa để học tập, không khẳng định kết quả", "Sea Gold": "Kim trong biển", "Willow Wood": "Gỗ dương liễu", "Mountain Fire": "Lửa trên núi", "Spring Water": "Nước suối"
  },
  th: {
    "Stem element": "ธาตุก้านฟ้า", "Branch element": "ธาตุกิ่งดิน", "Pillar role": "บทบาทเสา", "Day-stem relation": "ความสัมพันธ์ธาตุวัน", "Seasonal status": "สถานะตามฤดูกาล", "Symbolic marker": "เครื่องหมายสัญลักษณ์", "Month branch": "กิ่งเดือน", "Season branch": "คำสั่งเดือน", "Climate note": "บันทึกภูมิอากาศ",
    "Four-pillar matrix": "ตารางสี่เสา", "Stem, branch, root, role and seasonal reference in one dense study grid": "ตารางศึกษาแบบรวมก้าน กิ่ง ราก บทบาทเสา และฤดูกาล", "Element strength": "ความเข้มของห้าธาตุ", "Visible and hidden-root counts are held together for study": "พิจารณาก้านที่ปรากฏและรากซ่อนพร้อมกัน", "Seasonal command": "คำสั่งฤดูกาล", "Month command, climate reference and seasonal status": "คำสั่งเดือน บันทึกภูมิอากาศ และสถานะฤดูกาล", "Relation matrix": "ตารางความสัมพันธ์", "Pillar, day-stem and branch references read side by side": "พิจารณาเสา ธาตุวัน และกิ่งดินเคียงกัน", "Pillar roles": "บทบาทสี่เสา", "Four visible positions held as one study sequence": "พิจารณาสี่เสาเป็นลำดับการศึกษาเดียว", "Month cadence": "จังหวะเดือน", "Twelve monthly branch references around the seasonal command": "ข้อมูลกิ่งเดือนทั้งสิบสองรอบคำสั่งเดือน",
    "Peer": "เทียบเคียง", "Rob Wealth": "แย่งทรัพย์", "Eating God": "เทพอาหาร", "Hurting Officer": "ทำลายขุนนาง", "Direct Wealth": "ทรัพย์ตรง", "Indirect Wealth": "ทรัพย์รอง", "Direct Officer": "ขุนนางตรง", "Seven Killings": "เจ็ดพิฆาต", "Direct Resource": "ตราประทับตรง", "Indirect Resource": "ตราประทับรอง",
    "比肩": "เทียบเคียง", "劫财": "แย่งทรัพย์", "劫財": "แย่งทรัพย์", "食神": "เทพอาหาร", "伤官": "ทำลายขุนนาง", "傷官": "ทำลายขุนนาง", "正财": "ทรัพย์ตรง", "正財": "ทรัพย์ตรง", "偏财": "ทรัพย์รอง", "偏財": "ทรัพย์รอง", "正官": "ขุนนางตรง", "七杀": "เจ็ดพิฆาต", "七殺": "เจ็ดพิฆาต", "偏官": "เจ็ดพิฆาต", "正印": "ตราประทับตรง", "偏印": "ตราประทับรอง",
    "长生": "กำเนิด", "長生": "กำเนิด", "沐浴": "ชำระ", "冠带": "สวมมงกุฎ", "冠帶": "สวมมงกุฎ", "建禄": "รับราชการ", "建祿": "รับราชการ", "临官": "รับราชการ", "臨官": "รับราชการ", "帝旺": "รุ่งเรือง", "衰": "เสื่อม", "病": "เจ็บป่วย", "死": "ตาย", "墓": "สุสาน", "绝": "ดับสิ้น", "絕": "ดับสิ้น", "胎": "ครรภ์", "养": "บำรุง", "養": "บำรุง", "日主": "ธาตุวัน", "日干": "ก้านวัน", "天干": "ก้านฟ้า", "地支": "กิ่งดิน", "月令": "คำสั่งเดือน", "纳音": "น่ายิน", "納音": "น่ายิน", "藏干": "ก้านซ่อน", "十神": "สิบเทพ", "四柱": "สี่เสา",
    "Birth": "กำเนิด", "Bath": "ชำระ", "Crowning": "สวมมงกุฎ", "Service": "รับราชการ", "Prosperity": "รุ่งเรือง", "Decline": "เสื่อม", "Illness": "เจ็บป่วย", "Death": "ตาย", "Tomb": "สุสาน", "Extinction": "ดับสิ้น", "Embryo": "ครรภ์", "Nurture": "บำรุง",
    "Cool and gathering": "เย็นและเก็บรวม", "Warm and rising": "อุ่นและเติบโต", "Balanced and central": "สมดุลและศูนย์กลาง", "Clear and contracting": "ชัดและหดตัว", "Deep and storing": "ลึกและสะสม", "Combine": "ประสาน", "Clash": "ปะทะ", "Harm": "กระทบ", "Punishment": "ลงทัณฑ์", "Break": "แตก", "Support": "เกื้อหนุน", "Academic star": "ดาววิชาการ", "Traveling horse": "ดาวม้า", "Noble helper": "ผู้ช่วยสูงศักดิ์", "Solitary gate": "ประตูสันโดษ", "Flower canopy": "หลังคาดอกไม้", "Prosperity seal": "ตราความรุ่งเรือง", "Literary brush": "พู่กันวรรณศิลป์", "Restoration star": "ดาวฟื้นฟู",
    "Branch-root study layer": "ชั้นรากของกิ่งดินและก้านซ่อน", "Ten-God relationships": "ความสัมพันธ์สิบเทพ", "Local relationship map from the day pillar": "แผนผังความสัมพันธ์โดยมีเสาวันเป็นศูนย์กลาง", "Twelve Life Stages": "สิบสองช่วงชีวิต", "A symbolic seasonal sequence": "ลำดับฤดูกาลเชิงสัญลักษณ์", "Five Elements": "ห้าธาตุ", "Visible stem/branch count": "จำนวนก้านและกิ่งที่ปรากฏ", "The day stem and seasonal branch anchor this study layer": "ใช้ธาตุวันและกิ่งเดือนเป็นหลักของชั้นการศึกษา", "A local symbolic map of the four visible branches": "แผนผังสัญลักษณ์ของกิ่งดินทั้งสี่", "Rhythm table for long-form self-observation": "ตารางจังหวะเพื่อการสังเกตตนเองระยะยาว", "Twelve successive reference points": "จุดอ้างอิงต่อเนื่องสิบสองจุด", "Optional cultural-study notes, not outcome claims": "บันทึกเพื่อการเรียนรู้วัฒนธรรม ไม่ใช่การยืนยันผลลัพธ์", "Sea Gold": "ทองในทะเล", "Willow Wood": "ไม้หลิว", "Mountain Fire": "ไฟบนภูเขา", "Spring Water": "น้ำพุ"
  },
};

const methodTerms: Record<Locale, Record<string, string>> = {
  en: {},
  "zh-Hans": {
    "Pillar shen-sha": "柱神煞", "Shen-sha register": "神煞总表", "Year-pillar markers": "年柱神煞", "Month-pillar markers": "月柱神煞", "Day-pillar markers": "日柱神煞", "Hour-pillar markers": "时柱神煞", "Luck-cycle start": "起运参考", Orientation: "行运方向", "Start age": "起运年龄", "First cycle": "首轮大运", Forward: "顺行", Backward: "逆行",
    "Palace branch": "宫位地支", "Palace stem": "宫位天干", "Palace condition": "宫位状态", "Life-body marker": "命身标记", "Opposing palace": "对宫", "Three-harmony group": "三合局", "Palace stems": "宫干", "Palace branches": "宫支", "Life and body axis": "命身轴", "Three harmony groups": "三合局分组", "Opposing axes": "对宫轴", "Palace conditions": "宫位状态", "Life palace": "命宫", "Body palace": "身宫", "Palace reference": "宫位参照", Temple: "庙", Prosper: "旺", Balanced: "平", Rest: "休", Quiet: "闲", Observe: "观",
    "Bureau frame": "局式框架", Bureau: "局数", Polarity: "阴阳遁", "Yang bureau": "阳遁局", "Yin bureau": "阴遁局", "Seasonal term": "节气", "Central palace": "中宫", "Day stem": "日干", "Hour stem": "时干", "Duty locations": "值符值使定位", "Duty chief palace": "值符宫", "Duty chief deity": "值符神", "Duty gate palace": "值使门宫", "Duty gate": "值使门", "Horse palace": "驿马宫", "Void palace": "空亡宫", "Eight-door trajectory": "八门布列", "Nine-star field": "九星布列", "Eight-deity field": "八神布列", "Palace interactions": "宫位互动",
    Trigram: "八卦", "Hidden spirit": "伏神", "Line correspondence": "爻位对应", "Hidden spirits": "伏神", "Trigram frame": "上下卦框架", "Original lower trigram": "本卦下卦", "Original upper trigram": "本卦上卦", "Changed lower trigram": "变卦下卦", "Changed upper trigram": "变卦上卦", "Month and day frame": "月日时框架", "Day branch": "日支", "Hour branch": "时支", "Void branch": "空亡地支",
    "Twelve officer": "十二建除", "Day-night noble": "昼夜贵人", "Branch interaction": "地支互动", "Day noble": "昼贵", "Night noble": "夜贵", "Plate reference": "盘位参照", "General relations": "天将关系", "Branch interactions": "地支关系", "Lesson and plate links": "四课盘位关联", "True solar time": "真太阳时", "Civil time": "民用时", "Chart time": "排盘时间",
  },
  "zh-Hant": {
    "Pillar shen-sha": "柱神煞", "Shen-sha register": "神煞總表", "Year-pillar markers": "年柱神煞", "Month-pillar markers": "月柱神煞", "Day-pillar markers": "日柱神煞", "Hour-pillar markers": "時柱神煞", "Luck-cycle start": "起運參考", Orientation: "行運方向", "Start age": "起運年齡", "First cycle": "首輪大運", Forward: "順行", Backward: "逆行",
    "Palace branch": "宮位地支", "Palace stem": "宮位天干", "Palace condition": "宮位狀態", "Life-body marker": "命身標記", "Opposing palace": "對宮", "Three-harmony group": "三合局", "Palace stems": "宮干", "Palace branches": "宮支", "Life and body axis": "命身軸", "Three harmony groups": "三合局分組", "Opposing axes": "對宮軸", "Palace conditions": "宮位狀態", "Life palace": "命宮", "Body palace": "身宮", "Palace reference": "宮位參照", Temple: "廟", Prosper: "旺", Balanced: "平", Rest: "休", Quiet: "閒", Observe: "觀",
    "Bureau frame": "局式框架", Bureau: "局數", Polarity: "陰陽遁", "Yang bureau": "陽遁局", "Yin bureau": "陰遁局", "Seasonal term": "節氣", "Central palace": "中宮", "Day stem": "日干", "Hour stem": "時干", "Duty locations": "值符值使定位", "Duty chief palace": "值符宮", "Duty chief deity": "值符神", "Duty gate palace": "值使門宮", "Duty gate": "值使門", "Horse palace": "驛馬宮", "Void palace": "空亡宮", "Eight-door trajectory": "八門布列", "Nine-star field": "九星布列", "Eight-deity field": "八神布列", "Palace interactions": "宮位互動",
    Trigram: "八卦", "Hidden spirit": "伏神", "Line correspondence": "爻位對應", "Hidden spirits": "伏神", "Trigram frame": "上下卦框架", "Original lower trigram": "本卦下卦", "Original upper trigram": "本卦上卦", "Changed lower trigram": "變卦下卦", "Changed upper trigram": "變卦上卦", "Month and day frame": "月日時框架", "Day branch": "日支", "Hour branch": "時支", "Void branch": "空亡地支",
    "Twelve officer": "十二建除", "Day-night noble": "晝夜貴人", "Branch interaction": "地支互動", "Day noble": "晝貴", "Night noble": "夜貴", "Plate reference": "盤位參照", "General relations": "天將關係", "Branch interactions": "地支關係", "Lesson and plate links": "四課盤位關聯", "True solar time": "真太陽時", "Civil time": "民用時", "Chart time": "排盤時間",
  },
  ja: {
    "Pillar shen-sha": "柱の神煞", "Shen-sha register": "神煞一覧", "Year-pillar markers": "年柱の神煞", "Month-pillar markers": "月柱の神煞", "Day-pillar markers": "日柱の神煞", "Hour-pillar markers": "時柱の神煞", "Luck-cycle start": "大運開始の参照", Orientation: "運行方向", "Start age": "開始年齢", "First cycle": "最初の大運", Forward: "順行", Backward: "逆行",
    "Palace branch": "宮の地支", "Palace stem": "宮の天干", "Palace condition": "宮の状態", "Life-body marker": "命身の標識", "Opposing palace": "対宮", "Three-harmony group": "三合局", "Palace stems": "宮干", "Palace branches": "宮支", "Life and body axis": "命身軸", "Three harmony groups": "三合局グループ", "Opposing axes": "対宮軸", "Palace conditions": "宮の状態", "Life palace": "命宮", "Body palace": "身宮", "Palace reference": "宮の参照", Temple: "廟", Prosper: "旺", Balanced: "平", Rest: "休", Quiet: "閑", Observe: "観",
    "Bureau frame": "局式フレーム", Bureau: "局数", Polarity: "陰陽遁", "Yang bureau": "陽遁局", "Yin bureau": "陰遁局", "Seasonal term": "節気", "Central palace": "中宮", "Day stem": "日干", "Hour stem": "時干", "Duty locations": "値符・値使の配置", "Duty chief palace": "値符の宮", "Duty chief deity": "値符の神", "Duty gate palace": "値使門の宮", "Duty gate": "値使門", "Horse palace": "駅馬の宮", "Void palace": "空亡の宮", "Eight-door trajectory": "八門の配置", "Nine-star field": "九星の配置", "Eight-deity field": "八神の配置", "Palace interactions": "宮の相互関係",
    Trigram: "八卦", "Hidden spirit": "伏神", "Line correspondence": "爻の対応", "Hidden spirits": "伏神", "Trigram frame": "上下卦の枠組み", "Original lower trigram": "本卦の下卦", "Original upper trigram": "本卦の上卦", "Changed lower trigram": "変卦の下卦", "Changed upper trigram": "変卦の上卦", "Month and day frame": "月日・時の枠組み", "Day branch": "日支", "Hour branch": "時支", "Void branch": "空亡の地支",
    "Twelve officer": "十二直", "Day-night noble": "昼夜貴人", "Branch interaction": "地支の作用", "Day noble": "昼の貴人", "Night noble": "夜の貴人", "Plate reference": "盤位の参照", "General relations": "天将の関係", "Branch interactions": "地支の関係", "Lesson and plate links": "四課と盤位の連結", "True solar time": "真太陽時", "Civil time": "民用時", "Chart time": "盤の時刻",
  },
  ko: {
    "Pillar shen-sha": "주신살", "Shen-sha register": "신살 목록", "Year-pillar markers": "년주 신살", "Month-pillar markers": "월주 신살", "Day-pillar markers": "일주 신살", "Hour-pillar markers": "시주 신살", "Luck-cycle start": "대운 시작 참고", Orientation: "운행 방향", "Start age": "시작 나이", "First cycle": "첫 대운", Forward: "순행", Backward: "역행",
    "Palace branch": "궁 지지", "Palace stem": "궁 천간", "Palace condition": "궁 상태", "Life-body marker": "명신 표식", "Opposing palace": "대궁", "Three-harmony group": "삼합국", "Palace stems": "궁간", "Palace branches": "궁지", "Life and body axis": "명신축", "Three harmony groups": "삼합국 그룹", "Opposing axes": "대궁 축", "Palace conditions": "궁 상태", "Life palace": "명궁", "Body palace": "신궁", "Palace reference": "궁 참조", Temple: "묘", Prosper: "왕", Balanced: "평", Rest: "휴", Quiet: "한", Observe: "관",
    "Bureau frame": "국식 프레임", Bureau: "국수", Polarity: "음양둔", "Yang bureau": "양둔국", "Yin bureau": "음둔국", "Seasonal term": "절기", "Central palace": "중궁", "Day stem": "일간", "Hour stem": "시간", "Duty locations": "직부·직사 위치", "Duty chief palace": "직부궁", "Duty chief deity": "직부신", "Duty gate palace": "직사문궁", "Duty gate": "직사문", "Horse palace": "역마궁", "Void palace": "공망궁", "Eight-door trajectory": "팔문 배치", "Nine-star field": "구성 배치", "Eight-deity field": "팔신 배치", "Palace interactions": "궁 상호작용",
    Trigram: "팔괘", "Hidden spirit": "복신", "Line correspondence": "효 대응", "Hidden spirits": "복신", "Trigram frame": "상하괘 프레임", "Original lower trigram": "본괘 하괘", "Original upper trigram": "본괘 상괘", "Changed lower trigram": "변괘 하괘", "Changed upper trigram": "변괘 상괘", "Month and day frame": "월일시 프레임", "Day branch": "일지", "Hour branch": "시지", "Void branch": "공망 지지",
    "Twelve officer": "십이직", "Day-night noble": "주야 귀인", "Branch interaction": "지지 상호작용", "Day noble": "주간 귀인", "Night noble": "야간 귀인", "Plate reference": "반위 참조", "General relations": "천장 관계", "Branch interactions": "지지 관계", "Lesson and plate links": "사과와 반위 연결", "True solar time": "진태양시", "Civil time": "민용시", "Chart time": "명반 시각",
  },
  vi: {
    "Pillar shen-sha": "Thần sát theo trụ", "Shen-sha register": "Bảng thần sát", "Year-pillar markers": "Thần sát trụ năm", "Month-pillar markers": "Thần sát trụ tháng", "Day-pillar markers": "Thần sát trụ ngày", "Hour-pillar markers": "Thần sát trụ giờ", "Luck-cycle start": "Mốc mở vận", Orientation: "Hướng vận hành", "Start age": "Tuổi khởi vận", "First cycle": "Đại vận đầu", Forward: "Thuận hành", Backward: "Nghịch hành",
    "Palace branch": "Địa chi cung", "Palace stem": "Thiên can cung", "Palace condition": "Trạng thái cung", "Life-body marker": "Dấu mệnh-thân", "Opposing palace": "Cung đối", "Three-harmony group": "Nhóm tam hợp", "Palace stems": "Can cung", "Palace branches": "Chi cung", "Life and body axis": "Trục mệnh-thân", "Three harmony groups": "Các nhóm tam hợp", "Opposing axes": "Trục cung đối", "Palace conditions": "Trạng thái cung", "Life palace": "Cung Mệnh", "Body palace": "Cung Thân", "Palace reference": "Tham chiếu cung", Temple: "Miếu", Prosper: "Vượng", Balanced: "Bình", Rest: "Hưu", Quiet: "Nhàn", Observe: "Quan",
    "Bureau frame": "Khung cục", Bureau: "Số cục", Polarity: "Âm Dương độn", "Yang bureau": "Cục Dương Độn", "Yin bureau": "Cục Âm Độn", "Seasonal term": "Tiết khí", "Central palace": "Trung cung", "Day stem": "Can ngày", "Hour stem": "Can giờ", "Duty locations": "Vị trí Trực Phù - Trực Sử", "Duty chief palace": "Cung Trực Phù", "Duty chief deity": "Thần Trực Phù", "Duty gate palace": "Cung cửa Trực Sử", "Duty gate": "Cửa Trực Sử", "Horse palace": "Cung Dịch Mã", "Void palace": "Cung Không Vong", "Eight-door trajectory": "Phân bố Bát Môn", "Nine-star field": "Phân bố Cửu Tinh", "Eight-deity field": "Phân bố Bát Thần", "Palace interactions": "Tương tác cung",
    Trigram: "Bát quái", "Hidden spirit": "Phục thần", "Line correspondence": "Đối ứng hào", "Hidden spirits": "Phục thần", "Trigram frame": "Khung thượng hạ quái", "Original lower trigram": "Hạ quái gốc", "Original upper trigram": "Thượng quái gốc", "Changed lower trigram": "Hạ quái biến", "Changed upper trigram": "Thượng quái biến", "Month and day frame": "Khung tháng-ngày-giờ", "Day branch": "Chi ngày", "Hour branch": "Chi giờ", "Void branch": "Địa chi Không Vong",
    "Twelve officer": "Thập nhị trực", "Day-night noble": "Quý nhân ngày đêm", "Branch interaction": "Tương tác địa chi", "Day noble": "Quý nhân ngày", "Night noble": "Quý nhân đêm", "Plate reference": "Tham chiếu bàn", "General relations": "Quan hệ thiên tướng", "Branch interactions": "Quan hệ địa chi", "Lesson and plate links": "Liên kết tứ khóa - bàn", "True solar time": "Giờ Mặt Trời thực", "Civil time": "Giờ dân dụng", "Chart time": "Thời gian lập bàn",
  },
  th: {
    "Pillar shen-sha": "เสินซาตามเสา", "Shen-sha register": "ทะเบียนเสินซา", "Year-pillar markers": "เสินซาเสาปี", "Month-pillar markers": "เสินซาเสาเดือน", "Day-pillar markers": "เสินซาเสาวัน", "Hour-pillar markers": "เสินซาเสาเวลา", "Luck-cycle start": "จุดเริ่มวัฏจักร", Orientation: "ทิศทางวัฏจักร", "Start age": "อายุเริ่มต้น", "First cycle": "รอบแรก", Forward: "เดินหน้า", Backward: "ถอยหลัง",
    "Palace branch": "กิ่งดินของวัง", "Palace stem": "ก้านฟ้าของวัง", "Palace condition": "สภาวะของวัง", "Life-body marker": "ตำแหน่งมิ่ง-กาย", "Opposing palace": "วังตรงข้าม", "Three-harmony group": "กลุ่มสามประสาน", "Palace stems": "ก้านฟ้าวัง", "Palace branches": "กิ่งดินวัง", "Life and body axis": "แกนมิ่ง-กาย", "Three harmony groups": "กลุ่มสามประสาน", "Opposing axes": "แกนวังตรงข้าม", "Palace conditions": "สภาวะของวัง", "Life palace": "วังมิ่ง", "Body palace": "วังกาย", "Palace reference": "ข้อมูลอ้างอิงวัง", Temple: "เกษตร", Prosper: "รุ่งเรือง", Balanced: "สมดุล", Rest: "พัก", Quiet: "สงบ", Observe: "สังเกต",
    "Bureau frame": "กรอบผัง", Bureau: "เลขผัง", Polarity: "หยินหยางตุ้น", "Yang bureau": "ผังหยางตุ้น", "Yin bureau": "ผังหยินตุ้น", "Seasonal term": "ช่วงสุริยคติ", "Central palace": "วังกลาง", "Day stem": "ก้านวัน", "Hour stem": "ก้านเวลา", "Duty locations": "ตำแหน่งจื่อฝูและจื่อสื่อ", "Duty chief palace": "วังจื่อฝู", "Duty chief deity": "เทพจื่อฝู", "Duty gate palace": "วังประตูจื่อสื่อ", "Duty gate": "ประตูจื่อสื่อ", "Horse palace": "วังดาวม้า", "Void palace": "วังว่าง", "Eight-door trajectory": "การวางแปดประตู", "Nine-star field": "การวางเก้าดาว", "Eight-deity field": "การวางแปดเทพ", "Palace interactions": "ปฏิสัมพันธ์ของวัง",
    Trigram: "แปดกว้า", "Hidden spirit": "เทพซ่อน", "Line correspondence": "ความสอดคล้องของเส้น", "Hidden spirits": "เทพซ่อน", "Trigram frame": "กรอบกว้าบน-ล่าง", "Original lower trigram": "กว้าล่างเดิม", "Original upper trigram": "กว้าบนเดิม", "Changed lower trigram": "กว้าล่างแปร", "Changed upper trigram": "กว้าบนแปร", "Month and day frame": "กรอบเดือน-วัน-เวลา", "Day branch": "กิ่งวัน", "Hour branch": "กิ่งเวลา", "Void branch": "กิ่งความว่าง",
    "Twelve officer": "สิบสองผู้คุม", "Day-night noble": "ผู้สูงศักดิ์กลางวัน-กลางคืน", "Branch interaction": "ปฏิสัมพันธ์กิ่งดิน", "Day noble": "ผู้สูงศักดิ์กลางวัน", "Night noble": "ผู้สูงศักดิ์กลางคืน", "Plate reference": "ข้อมูลอ้างอิงผัง", "General relations": "ความสัมพันธ์แม่ทัพฟ้า", "Branch interactions": "ความสัมพันธ์กิ่งดิน", "Lesson and plate links": "การเชื่อมสี่บทกับผัง", "True solar time": "เวลาสุริยะจริง", "Civil time": "เวลาท้องถิ่น", "Chart time": "เวลาตั้งผัง",
  },
};

const placeTerms: Record<Locale, Record<string, string>> = {
  en: { Global: "Global", "East Asia": "East Asia", "Southeast Asia": "Southeast Asia", Europe: "Europe", Americas: "Americas" },
  "zh-Hans": { Global: "全球", "East Asia": "东亚", "Southeast Asia": "东南亚", Europe: "欧洲", Americas: "美洲" },
  "zh-Hant": { Global: "全球", "East Asia": "東亞", "Southeast Asia": "東南亞", Europe: "歐洲", Americas: "美洲" },
  ja: { Global: "グローバル", "East Asia": "東アジア", "Southeast Asia": "東南アジア", Europe: "ヨーロッパ", Americas: "アメリカ大陸" },
  ko: { Global: "전 세계", "East Asia": "동아시아", "Southeast Asia": "동남아시아", Europe: "유럽", Americas: "아메리카" },
  vi: { Global: "Toàn cầu", "East Asia": "Đông Á", "Southeast Asia": "Đông Nam Á", Europe: "Châu Âu", Americas: "Châu Mỹ" },
  th: { Global: "ทั่วโลก", "East Asia": "เอเชียตะวันออก", "Southeast Asia": "เอเชียตะวันออกเฉียงใต้", Europe: "ยุโรป", Americas: "ทวีปอเมริกา" },
};

function localizePlace(value: string, locale: Locale) {
  return placeTerms[locale][value] ?? value;
}

const seasonalTermNames: Record<Locale, Record<string, string>> = {
  en: {},
  "zh-Hans": { "Start of Spring": "立春", "Vernal Equinox": "春分", "Start of Summer": "立夏", "Summer Solstice": "夏至", "Start of Autumn": "立秋", "Autumnal Equinox": "秋分", "Start of Winter": "立冬", "Winter Solstice": "冬至" },
  "zh-Hant": { "Start of Spring": "立春", "Vernal Equinox": "春分", "Start of Summer": "立夏", "Summer Solstice": "夏至", "Start of Autumn": "立秋", "Autumnal Equinox": "秋分", "Start of Winter": "立冬", "Winter Solstice": "冬至" },
  ja: { "Start of Spring": "立春", "Vernal Equinox": "春分", "Start of Summer": "立夏", "Summer Solstice": "夏至", "Start of Autumn": "立秋", "Autumnal Equinox": "秋分", "Start of Winter": "立冬", "Winter Solstice": "冬至" },
  ko: { "Start of Spring": "입춘", "Vernal Equinox": "춘분", "Start of Summer": "입하", "Summer Solstice": "하지", "Start of Autumn": "입추", "Autumnal Equinox": "추분", "Start of Winter": "입동", "Winter Solstice": "동지" },
  vi: { "Start of Spring": "Lập Xuân", "Vernal Equinox": "Xuân Phân", "Start of Summer": "Lập Hạ", "Summer Solstice": "Hạ Chí", "Start of Autumn": "Lập Thu", "Autumnal Equinox": "Thu Phân", "Start of Winter": "Lập Đông", "Winter Solstice": "Đông Chí" },
  th: { "Start of Spring": "เริ่มวสันต์", "Vernal Equinox": "วสันตวิษุวัต", "Start of Summer": "เริ่มคิมหันต์", "Summer Solstice": "ครีษมายัน", "Start of Autumn": "เริ่มสารท", "Autumnal Equinox": "ศารทวิษุวัต", "Start of Winter": "เริ่มเหมันต์", "Winter Solstice": "เหมายัน" },
};

const classicalTermNames: Record<Locale, Record<string, string>> = {
  en: {},
  "zh-Hans": {},
  "zh-Hant": { "天乙贵人": "天乙貴人", "天德贵人": "天德貴人", "月德贵人": "月德貴人", "文昌贵人": "文昌貴人", "华盖": "華蓋", "将星": "將星", "禄神": "祿神", "孤辰": "孤辰", "驿马": "驛馬" },
  ja: { "天乙贵人": "天乙貴人", "天德贵人": "天徳貴人", "月德贵人": "月徳貴人", "文昌贵人": "文昌貴人", "文曲": "文曲", "驿马": "駅馬", "桃花": "桃花", "华盖": "華蓋", "将星": "将星", "羊刃": "羊刃", "禄神": "禄神", "孤辰": "孤辰" },
  ko: { "天乙贵人": "천을귀인", "天德贵人": "천덕귀인", "月德贵人": "월덕귀인", "文昌贵人": "문창귀인", "文曲": "문곡", "驿马": "역마", "桃花": "도화", "华盖": "화개", "将星": "장성", "羊刃": "양인", "禄神": "록신", "孤辰": "고진" },
  vi: { "天乙贵人": "Thiên Ất quý nhân", "天德贵人": "Thiên Đức quý nhân", "月德贵人": "Nguyệt Đức quý nhân", "文昌贵人": "Văn Xương quý nhân", "文曲": "Văn Khúc", "驿马": "Dịch Mã", "桃花": "Đào Hoa", "华盖": "Hoa Cái", "将星": "Tướng Tinh", "羊刃": "Dương Nhận", "禄神": "Lộc Thần", "孤辰": "Cô Thần" },
  th: { "天乙贵人": "เทียนอี่กุ้ยเหริน", "天德贵人": "เทียนเต๋อกุ้ยเหริน", "月德贵人": "เยว่เต๋อกุ้ยเหริน", "文昌贵人": "เหวินชางกุ้ยเหริน", "文曲": "เหวินฉวี่", "驿马": "อี้หม่า", "桃花": "เถาฮวา", "华盖": "ฮวาไก่", "将星": "เจียงซิง", "羊刃": "หยางเริ่น", "禄神": "ลู่เสิน", "孤辰": "กูเฉิน" },
};

const referenceFreeTerms: Record<Locale, Record<string, string>> = {
  en: { "Symbolic markers": "Traditional markers", "Symbolic marker": "Traditional marker", "Symbolic and environmental layer": "Context and environment layer", "A symbolic seasonal sequence": "A twelve-stage seasonal sequence", "A local symbolic map of the four visible branches": "A local relationship map of the four visible branches" },
  "zh-Hans": { "Symbolic markers": "传统标记", "Symbolic marker": "传统标记", "Symbolic and environmental layer": "语境与环境层", "A symbolic seasonal sequence": "十二阶段时序", "A local symbolic map of the four visible branches": "四柱地支关系图" },
  "zh-Hant": { "Symbolic markers": "傳統標記", "Symbolic marker": "傳統標記", "Symbolic and environmental layer": "語境與環境層", "A symbolic seasonal sequence": "十二階段時序", "A local symbolic map of the four visible branches": "四柱地支關係圖" },
  ja: { "Symbolic markers": "伝統マーカー", "Symbolic marker": "伝統マーカー", "Symbolic and environmental layer": "文脈と環境のレイヤー", "A symbolic seasonal sequence": "十二段階の季節連鎖", "A local symbolic map of the four visible branches": "四つの地支の関係マップ" },
  ko: { "Symbolic markers": "전통 표식", "Symbolic marker": "전통 표식", "Symbolic and environmental layer": "맥락과 환경 레이어", "A symbolic seasonal sequence": "열두 단계 계절 순서", "A local symbolic map of the four visible branches": "네 지지 관계 지도" },
  vi: { "Symbolic markers": "Dấu hiệu truyền thống", "Symbolic marker": "Dấu hiệu truyền thống", "Symbolic and environmental layer": "Lớp ngữ cảnh và môi trường", "A symbolic seasonal sequence": "Chuỗi mùa mười hai giai đoạn", "A local symbolic map of the four visible branches": "Bản đồ quan hệ bốn Địa Chi" },
  th: { "Symbolic markers": "เครื่องหมายดั้งเดิม", "Symbolic marker": "เครื่องหมายดั้งเดิม", "Symbolic and environmental layer": "ชั้นบริบทและสภาพแวดล้อม", "A symbolic seasonal sequence": "ลำดับฤดูกาลสิบสองช่วง", "A local symbolic map of the four visible branches": "แผนผังความสัมพันธ์ของกิ่งดินทั้งสี่" },
};

const naYinKeys = ["海中金", "炉中火", "大林木", "路旁土", "剑锋金", "山头火", "涧下水", "城头土", "白蜡金", "杨柳木", "泉中水", "屋上土", "霹雳火", "松柏木", "长流水", "沙中金", "山下火", "平地木", "壁上土", "金箔金", "覆灯火", "天河水", "大驿土", "钗钏金", "桑柘木", "大溪水", "沙中土", "天上火", "石榴木", "大海水"];
const naYinTranslations: Record<Locale, string[]> = {
  en: ["Sea Gold", "Furnace Fire", "Great Forest Wood", "Roadside Earth", "Sword-Edge Gold", "Mountain Fire", "Stream Water", "City-Wall Earth", "White-Wax Gold", "Willow Wood", "Spring Water", "Roof-Tile Earth", "Thunderbolt Fire", "Pine-Cypress Wood", "Long-Flowing Water", "Sand Gold", "Mountain-Foot Fire", "Plain Wood", "Wall Earth", "Gold-Foil Gold", "Lamp Fire", "Heavenly-River Water", "Great-Post Earth", "Hairpin Gold", "Mulberry Wood", "Great-Stream Water", "Sand Earth", "Heavenly Fire", "Pomegranate Wood", "Great-Ocean Water"],
  "zh-Hans": naYinKeys,
  "zh-Hant": ["海中金", "爐中火", "大林木", "路旁土", "劍鋒金", "山頭火", "澗下水", "城頭土", "白蠟金", "楊柳木", "泉中水", "屋上土", "霹靂火", "松柏木", "長流水", "沙中金", "山下火", "平地木", "壁上土", "金箔金", "覆燈火", "天河水", "大驛土", "釵釧金", "桑柘木", "大溪水", "沙中土", "天上火", "石榴木", "大海水"],
  ja: ["海中金", "炉中火", "大林木", "路傍土", "剣鋒金", "山頭火", "澗下水", "城頭土", "白蝋金", "楊柳木", "泉中水", "屋上土", "霹靂火", "松柏木", "長流水", "砂中金", "山下火", "平地木", "壁上土", "金箔金", "覆灯火", "天河水", "大駅土", "釵釧金", "桑柘木", "大渓水", "砂中土", "天上火", "石榴木", "大海水"],
  ko: ["해중금", "노중화", "대림목", "노방토", "검봉금", "산두화", "간하수", "성두토", "백랍금", "양류목", "천중수", "옥상토", "벽력화", "송백목", "장류수", "사중금", "산하화", "평지목", "벽상토", "금박금", "복등화", "천하수", "대역토", "차천금", "상자목", "대계수", "사중토", "천상화", "석류목", "대해수"],
  vi: ["Hải Trung Kim", "Lư Trung Hỏa", "Đại Lâm Mộc", "Lộ Bàng Thổ", "Kiếm Phong Kim", "Sơn Đầu Hỏa", "Giản Hạ Thủy", "Thành Đầu Thổ", "Bạch Lạp Kim", "Dương Liễu Mộc", "Tuyền Trung Thủy", "Ốc Thượng Thổ", "Tích Lịch Hỏa", "Tùng Bách Mộc", "Trường Lưu Thủy", "Sa Trung Kim", "Sơn Hạ Hỏa", "Bình Địa Mộc", "Bích Thượng Thổ", "Kim Bạch Kim", "Phúc Đăng Hỏa", "Thiên Hà Thủy", "Đại Dịch Thổ", "Thoa Xuyến Kim", "Tang Đố Mộc", "Đại Khê Thủy", "Sa Trung Thổ", "Thiên Thượng Hỏa", "Thạch Lựu Mộc", "Đại Hải Thủy"],
  th: ["ทองในทะเล", "ไฟในเตา", "ไม้ป่าใหญ่", "ดินริมทาง", "ทองคมดาบ", "ไฟยอดเขา", "น้ำใต้ลำธาร", "ดินบนกำแพงเมือง", "ทองขี้ผึ้งขาว", "ไม้หลิว", "น้ำพุ", "ดินบนหลังคา", "ไฟสายฟ้า", "ไม้สน", "น้ำไหลยาว", "ทองในทราย", "ไฟใต้เขา", "ไม้บนพื้นราบ", "ดินบนกำแพง", "แผ่นทอง", "ไฟตะเกียง", "น้ำแม่น้ำสวรรค์", "ดินสถานีใหญ่", "ทองปิ่น", "ไม้หม่อน", "น้ำลำธารใหญ่", "ดินในทราย", "ไฟบนฟ้า", "ไม้ทับทิม", "น้ำทะเลใหญ่"],
};

function localizeNaYin(value: string, locale: Locale) {
  const index = naYinKeys.indexOf(value);
  return index >= 0 ? naYinTranslations[locale][index] : undefined;
}

const lunarDigits: Record<string, number> = { "〇": 0, "零": 0, "一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9 };

function lunarNumber(value: string) {
  const normalized = value.replace("初", "").replace("正", "一").replace("冬", "十一").replace("腊", "十二");
  if (normalized === "十") return 10;
  if (normalized.startsWith("廿")) return 20 + (lunarDigits[normalized[1]] ?? 0);
  if (normalized.startsWith("卅")) return 30 + (lunarDigits[normalized[1]] ?? 0);
  if (normalized.includes("十")) {
    const [tens, ones] = normalized.split("十");
    return (tens ? (lunarDigits[tens] ?? 1) : 1) * 10 + (ones ? (lunarDigits[ones] ?? 0) : 0);
  }
  return Number([...normalized].map((character) => lunarDigits[character] ?? character).join(""));
}

export function localizeLunarDate(value: string, locale: Locale) {
  if (locale === "zh-Hans") return value;
  if (locale === "zh-Hant") return value.replaceAll("闰", "閏");
  const match = value.match(/^(闰)?(.+?)年(闰)?(.+?)月(.+)$/);
  if (!match) return value;
  const [, yearLeap, rawYear, monthLeap, rawMonth, rawDay] = match;
  const year = Number([...rawYear].map((character) => lunarDigits[character] ?? character).join(""));
  const month = lunarNumber(rawMonth);
  const day = lunarNumber(rawDay);
  if (![year, month, day].every(Number.isFinite)) return value;
  const leap = Boolean(yearLeap || monthLeap);
  const padded = `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
  if (locale === "en") return `Lunar ${padded}${leap ? " (leap month)" : ""}`;
  if (locale === "ja") return `旧暦 ${year}年${month}月${day}日${leap ? "（閏月）" : ""}`;
  if (locale === "ko") return `음력 ${year}년 ${month}월 ${day}일${leap ? " (윤달)" : ""}`;
  if (locale === "vi") return `Âm lịch ${String(day).padStart(2, "0")}/${String(month).padStart(2, "0")}/${year}${leap ? " (tháng nhuận)" : ""}`;
  return `จันทรคติ ${String(day).padStart(2, "0")}/${String(month).padStart(2, "0")}/${year}${leap ? " (เดือนอธิกมาส)" : ""}`;
}

const presentationCleanup: Record<Locale, Array<[RegExp, string]>> = {
  en: [
    [/\bcross-reference\b/gi, "cross-check"],
    [/\bsymbolic\b/gi, "structural"],
    [/\breferences\b/gi, "details"],
    [/\breference\b/gi, "detail"],
  ],
  "zh-Hans": [
    [/交叉参照/g, "交叉校验"],
    [/象征性的/g, "结构化的"],
    [/象征/g, "结构"],
    [/参照/g, "信息"],
    [/参考/g, "信息"],
  ],
  "zh-Hant": [
    [/交叉參照/g, "交叉校驗"],
    [/象徵性的/g, "結構化的"],
    [/象徵/g, "結構"],
    [/參照/g, "資訊"],
    [/參考/g, "資訊"],
  ],
  ja: [
    [/交差参照/g, "照合"],
    [/象徴的な/g, "構造的な"],
    [/象徴/g, "構造"],
    [/参照/g, "情報"],
    [/参考/g, "情報"],
  ],
  ko: [
    [/상호 참조/g, "상호 비교"],
    [/상징적인/g, "구조적인"],
    [/상징/g, "구조"],
    [/참조/g, "정보"],
    [/참고/g, "정보"],
  ],
  vi: [
    [/đối chiếu chéo/gi, "so sánh chéo"],
    [/mang tính biểu tượng/gi, "có cấu trúc"],
    [/biểu tượng/gi, "cấu trúc"],
    [/tham chiếu/gi, "thông tin"],
  ],
  th: [
    [/ข้อมูลอ้างอิง/g, "ข้อมูล"],
    [/เชิงสัญลักษณ์/g, "เชิงโครงสร้าง"],
    [/สัญลักษณ์/g, "โครงสร้าง"],
    [/อ้างอิง/g, "ข้อมูล"],
  ],
};

/** Removes generic presentation filler from labels while retaining the chart's real fields. */
export function cleanVisibleBoardText(value: string, locale: Locale) {
  return presentationCleanup[locale].reduce((text, [pattern, replacement]) => text.replace(pattern, replacement), value)
    .replace(/\s{2,}/g, " ")
    .replace(/\s+([,.;:])/g, "$1")
    .trim();
}

function localizeSourceFact(value: string, locale: Locale) {
  const labels: Record<Locale, { conversion: string; pillars: string; naYin: string; location: string; trueSolar: string; second: string }> = {
    en: { conversion: "Calculated solar/lunar conversion", pillars: "Four pillars: year · month · day · hour", naYin: "Day NaYin", location: "Location reference", trueSolar: "True solar time", second: "Second profile" },
    "zh-Hans": { conversion: "公历农历换算", pillars: "四柱：年 · 月 · 日 · 时", naYin: "日纳音", location: "地点参考", trueSolar: "真太阳时", second: "第二命盘" },
    "zh-Hant": { conversion: "公曆農曆換算", pillars: "四柱：年 · 月 · 日 · 時", naYin: "日納音", location: "地點參考", trueSolar: "真太陽時", second: "第二命盤" },
    ja: { conversion: "太陽暦・太陰暦の換算", pillars: "四柱：年・月・日・時", naYin: "日柱の納音", location: "場所の参照", trueSolar: "真太陽時", second: "二人目のプロフィール" },
    ko: { conversion: "양력·음력 환산", pillars: "사주: 년 · 월 · 일 · 시", naYin: "일주 납음", location: "장소 참조", trueSolar: "진태양시", second: "두 번째 프로필" },
    vi: { conversion: "Chuyển đổi dương lịch/âm lịch", pillars: "Tứ Trụ: năm · tháng · ngày · giờ", naYin: "Nạp âm ngày", location: "Tham chiếu địa điểm", trueSolar: "Giờ mặt trời thực", second: "Hồ sơ thứ hai" },
    th: { conversion: "แปลงปฏิทินสุริยคติ/จันทรคติ", pillars: "สี่เสา: ปี · เดือน · วัน · เวลา", naYin: "น่ายินของวัน", location: "ข้อมูลอ้างอิงสถานที่", trueSolar: "เวลาสุริยะจริง", second: "โปรไฟล์ที่สอง" },
  };
  const text = labels[locale];
  if (value === "Calculated solar/lunar conversion") return cleanVisibleBoardText(text.conversion, locale);
  if (value === "Four pillars: year · month · day · hour") return cleanVisibleBoardText(text.pillars, locale);
  if (value.startsWith("Day NaYin: ")) return cleanVisibleBoardText(`${text.naYin}: ${localizeBoardTerm(value.slice(11), locale)}`, locale);
  if (value.startsWith("Location reference: ")) return cleanVisibleBoardText(`${text.location}: ${value.slice(20)}`, locale);
  if (value.startsWith("True solar time: ")) return cleanVisibleBoardText(`${text.trueSolar}: ${value.slice(17)}`, locale);
  if (value.startsWith("Second profile: ")) return cleanVisibleBoardText(`${text.second}: ${value.slice(17)}`, locale);
  return localizeBoardTerm(value, locale);
}

const heavenlyStems = "甲乙丙丁戊己庚辛壬癸";
const earthlyBranches = "子丑寅卯辰巳午未申酉戌亥";

const classicalTokenTranslations: Partial<Record<Locale, Record<string, string>>> = {
  en: {
    "甲": "Jia", "乙": "Yi", "丙": "Bing", "丁": "Ding", "戊": "Wu", "己": "Ji", "庚": "Geng", "辛": "Xin", "壬": "Ren", "癸": "Gui",
    "子": "Zi", "丑": "Chou", "寅": "Yin", "卯": "Mao", "辰": "Chen", "巳": "Si", "午": "Wu", "未": "Wei", "申": "Shen", "酉": "You", "戌": "Xu", "亥": "Hai",
    "乾": "Qian", "兑": "Dui", "离": "Li", "震": "Zhen", "巽": "Xun", "坎": "Kan", "艮": "Gen", "坤": "Kun",
    "狗": "Dog", "嫁娶": "Marriage", "纳采": "Betrothal", "订盟": "Alliance", "祭祀": "Rites", "开市": "Market opening", "立券": "Contracting", "置产": "Property acquisition", "作灶": "Hearth setting",
    "紫微": "Zi Wei", "天机": "Tian Ji", "太阳": "Tai Yang", "武曲": "Wu Qu", "天同": "Tian Tong", "廉贞": "Lian Zhen", "天府": "Tian Fu", "太阴": "Tai Yin", "贪狼": "Tan Lang", "巨门": "Ju Men", "天相": "Tian Xiang", "天梁": "Tian Liang", "七杀": "Qi Sha", "破军": "Po Jun",
    "值符": "Duty Chief", "九天": "Nine Heavens", "九地": "Nine Earths", "禽": "Bird", "芮": "Rui", "英": "Ying", "蓬": "Peng", "任": "Ren", "辅": "Assistant", "冲": "Clash",
    "青龙": "Azure Dragon", "朱雀": "Vermilion Bird", "勾陈": "Gou Chen", "螣蛇": "Teng She", "白虎": "White Tiger", "玄武": "Black Tortoise", "六合": "Six Harmonies", "贵人": "Noble Helper", "天后": "Heavenly Empress", "太常": "Grand Constant", "天空": "Heavenly Void",
    "建": "Establish", "除": "Remove", "满": "Full", "平": "Balance", "定": "Settle", "执": "Hold", "破": "Break", "危": "Risk", "成": "Complete", "收": "Receive", "开": "Open", "闭": "Close", "旬": "Ten-day cycle", "柱": "Pillar",
    "井": "Well", "亢": "Neck", "氐": "Root", "房": "Room", "心": "Heart", "尾": "Tail", "箕": "Winnowing Basket", "斗": "Dipper", "室": "Chamber", "壁": "Wall", "奎": "Legs", "娄": "Bond", "胃": "Stomach", "参": "Three Stars", "鬼": "Ghost", "柳": "Willow", "星": "Star", "张": "Net", "涧下水": "Stream Water",
  },
  ko: {
    "甲": "갑", "乙": "을", "丙": "병", "丁": "정", "戊": "무", "己": "기", "庚": "경", "辛": "신", "壬": "임", "癸": "계",
    "子": "자", "丑": "축", "寅": "인", "卯": "묘", "辰": "진", "巳": "사", "午": "오", "未": "미", "申": "신", "酉": "유", "戌": "술", "亥": "해",
    "乾": "건", "兑": "태", "离": "리", "震": "진", "巽": "손", "坎": "감", "艮": "간", "坤": "곤",
    "狗": "개", "嫁娶": "혼인", "纳采": "납채", "订盟": "혼약", "祭祀": "제사", "开市": "개시", "立券": "계약", "置产": "재산 취득", "作灶": "부엌 설치",
    "紫微": "자미", "天机": "천기", "太阳": "태양", "武曲": "무곡", "天同": "천동", "廉贞": "염정", "天府": "천부", "太阴": "태음", "贪狼": "탐랑", "巨门": "거문", "天相": "천상", "天梁": "천량", "七杀": "칠살", "破军": "파군",
    "值符": "직부", "九天": "구천", "九地": "구지", "禽": "금", "芮": "예", "英": "영", "蓬": "봉", "任": "임", "辅": "보", "冲": "충",
    "青龙": "청룡", "朱雀": "주작", "勾陈": "구진", "螣蛇": "등사", "白虎": "백호", "玄武": "현무", "六合": "육합", "贵人": "귀인", "天后": "천후", "太常": "태상", "天空": "천공",
    "建": "건", "除": "제", "满": "만", "平": "평", "定": "정", "执": "집", "破": "파", "危": "위", "成": "성", "收": "수", "开": "개", "闭": "폐", "旬": "순", "柱": "주",
    "井": "정", "亢": "항", "氐": "저", "房": "방", "心": "심", "尾": "미", "箕": "기", "斗": "두", "室": "실", "壁": "벽", "奎": "규", "娄": "루", "胃": "위", "参": "삼", "鬼": "귀", "柳": "류", "星": "성", "张": "장", "涧下水": "간하수",
  },
  vi: {
    "甲": "Giáp", "乙": "Ất", "丙": "Bính", "丁": "Đinh", "戊": "Mậu", "己": "Kỷ", "庚": "Canh", "辛": "Tân", "壬": "Nhâm", "癸": "Quý",
    "子": "Tý", "丑": "Sửu", "寅": "Dần", "卯": "Mão", "辰": "Thìn", "巳": "Tỵ", "午": "Ngọ", "未": "Mùi", "申": "Thân", "酉": "Dậu", "戌": "Tuất", "亥": "Hợi",
    "乾": "Càn", "兑": "Đoài", "离": "Ly", "震": "Chấn", "巽": "Tốn", "坎": "Khảm", "艮": "Cấn", "坤": "Khôn",
    "狗": "Chó", "嫁娶": "Hôn nhân", "纳采": "Nạp sính", "订盟": "Đính ước", "祭祀": "Tế lễ", "开市": "Khai trương", "立券": "Lập khế", "置产": "Tạo sản", "作灶": "Đặt bếp",
    "紫微": "Tử Vi", "天机": "Thiên Cơ", "太阳": "Thái Dương", "武曲": "Vũ Khúc", "天同": "Thiên Đồng", "廉贞": "Liêm Trinh", "天府": "Thiên Phủ", "太阴": "Thái Âm", "贪狼": "Tham Lang", "巨门": "Cự Môn", "天相": "Thiên Tướng", "天梁": "Thiên Lương", "七杀": "Thất Sát", "破军": "Phá Quân",
    "值符": "Trực Phù", "九天": "Cửu Thiên", "九地": "Cửu Địa", "禽": "Cầm", "芮": "Nhuế", "英": "Anh", "蓬": "Bồng", "任": "Nhậm", "辅": "Phụ", "冲": "Xung",
    "青龙": "Thanh Long", "朱雀": "Chu Tước", "勾陈": "Câu Trần", "螣蛇": "Đằng Xà", "白虎": "Bạch Hổ", "玄武": "Huyền Vũ", "六合": "Lục Hợp", "贵人": "Quý Nhân", "天后": "Thiên Hậu", "太常": "Thái Thường", "天空": "Thiên Không",
    "建": "Kiến", "除": "Trừ", "满": "Mãn", "平": "Bình", "定": "Định", "执": "Chấp", "破": "Phá", "危": "Nguy", "成": "Thành", "收": "Thu", "开": "Khai", "闭": "Bế", "旬": "Tuần", "柱": "Trụ",
    "井": "Tỉnh", "亢": "Kháng", "氐": "Đê", "房": "Phòng", "心": "Tâm", "尾": "Vĩ", "箕": "Cơ", "斗": "Đẩu", "室": "Thất", "壁": "Bích", "奎": "Khuê", "娄": "Lâu", "胃": "Vị", "参": "Sâm", "鬼": "Quỷ", "柳": "Liễu", "星": "Tinh", "张": "Trương", "涧下水": "Giản Hạ Thủy",
  },
  th: {
    "甲": "เจี่ย", "乙": "อี่", "丙": "ปิ่ง", "丁": "ติง", "戊": "อู้", "己": "จี๋", "庚": "เกิง", "辛": "ซิน", "壬": "เหริน", "癸": "กุ่ย",
    "子": "จื่อ", "丑": "โฉ่ว", "寅": "อิ๋น", "卯": "เหม่า", "辰": "เฉิน", "巳": "ซื่อ", "午": "อู่", "未": "เว่ย", "申": "เซิน", "酉": "โหย่ว", "戌": "ซวี", "亥": "ไห่",
    "乾": "เฉียน", "兑": "ตุ้ย", "离": "หลี", "震": "เจิ้น", "巽": "ซวิ่น", "坎": "ข่าน", "艮": "เกิ้น", "坤": "คุน",
    "狗": "สุนัข", "嫁娶": "สมรส", "纳采": "หมั้นหมาย", "订盟": "ทำสัญญา", "祭祀": "พิธีบูชา", "开市": "เปิดกิจการ", "立券": "ทำสัญญา", "置产": "ได้มาซึ่งทรัพย์สิน", "作灶": "ตั้งเตา",
    "紫微": "จื่อเวย", "天机": "เทียนจี", "太阳": "ไท่หยาง", "武曲": "อู่ฉวี่", "天同": "เทียนถง", "廉贞": "เหลียนเจิน", "天府": "เทียนฝู่", "太阴": "ไท่อิน", "贪狼": "ทานหลาง", "巨门": "จวี้เหมิน", "天相": "เทียนเซี่ยง", "天梁": "เทียนเหลียง", "七杀": "ชีซา", "破军": "พั่วจวิน",
    "值符": "จื่อฝู", "九天": "เก้าสวรรค์", "九地": "เก้าปฐพี", "禽": "ฉิน", "芮": "รุ่ย", "英": "อิง", "蓬": "เผิง", "任": "เริ่น", "辅": "ผู้ช่วย", "冲": "ปะทะ",
    "青龙": "มังกรฟ้า", "朱雀": "วิหคชาด", "勾陈": "โกวเฉิน", "螣蛇": "เถิงเสอ", "白虎": "พยัคฆ์ขาว", "玄武": "เต่าดำ", "六合": "หกประสาน", "贵人": "ผู้เกื้อหนุน", "天后": "เทียนโฮ่ว", "太常": "ไท่ฉาง", "天空": "ท้องฟ้าว่าง",
    "建": "ก่อ", "除": "กำจัด", "满": "เต็ม", "平": "สมดุล", "定": "กำหนด", "执": "ยึด", "破": "แตก", "危": "เสี่ยง", "成": "สำเร็จ", "收": "รับ", "开": "เปิด", "闭": "ปิด", "旬": "รอบสิบวัน", "柱": "เสา",
    "井": "จิ่ง", "亢": "คั่ง", "氐": "ตี้", "房": "ฝาง", "心": "ซิน", "尾": "เหว่ย", "箕": "จี", "斗": "โต่ว", "室": "ซื่อ", "壁": "ปี้", "奎": "ขุย", "娄": "โหลว", "胃": "เว่ย", "参": "เซิน", "鬼": "กุ่ย", "柳": "หลิ่ว", "星": "ซิง", "张": "จาง", "涧下水": "น้ำใต้ลำธาร",
  },
};

function localizeClassicalChartText(value: string, locale: Locale) {
  const tokens = classicalTokenTranslations[locale];
  if (!tokens || !/[\u3400-\u9fff]/.test(value)) return value;
  const lunar = localizeLunarDate(value, locale);
  if (lunar !== value) return lunar;

  const stemBranch = new RegExp(`([${heavenlyStems}])([${earthlyBranches}])`, "g");
  const branchSequence = new RegExp(`[${earthlyBranches}]{2,}`, "g");
  let output = value
    .replace(stemBranch, (_, stem: string, branch: string) => `${tokens[stem] ?? stem}${locale === "ko" ? "" : " "}${tokens[branch] ?? branch}`)
    .replace(branchSequence, (sequence: string) => [...sequence].map((branch) => tokens[branch] ?? branch).join(" · "));

  for (const [source, translated] of Object.entries(tokens).sort(([left], [right]) => right.length - left.length)) {
    output = output.replaceAll(source, translated);
  }
  return output;
}

/** Labels of the BaZi deep-reading sections (luck cycles in depth, day-master strength). */
const detailTerms: Record<Locale, Record<string, string>> = {
  en: {},
  "zh-Hans": { "Luck cycles in depth": "大运详解", "Each ten-year cycle with the Ten Gods of its stem and branch; the current cycle is marked": "每步大运的天干与地支十神，标出当前所在大运", "Day-master strength": "日主强弱参考", "Supporting and draining forces counted from stems, hidden stems and the season; one common method, schools differ": "按天干、藏干与月令统计生扶与克泄的力量；为常见算法之一，各流派判断不同", "Supporting forces": "生扶力量", "Draining forces": "克泄耗力量", "Support share": "生扶占比", "Season supports the day master": "月令是否生扶日主", "Strength reference": "强弱参考", "Leaning strong": "偏强", "Balanced": "中和", "Leaning weak": "偏弱", "Yes": "是", "No": "否", "Current": "当前" },
  "zh-Hant": { "Luck cycles in depth": "大運詳解", "Each ten-year cycle with the Ten Gods of its stem and branch; the current cycle is marked": "每步大運的天干與地支十神，標出目前所在大運", "Day-master strength": "日主強弱參考", "Supporting and draining forces counted from stems, hidden stems and the season; one common method, schools differ": "按天干、藏干與月令統計生扶與剋洩的力量；為常見演算法之一，各流派判斷不同", "Supporting forces": "生扶力量", "Draining forces": "剋洩耗力量", "Support share": "生扶佔比", "Season supports the day master": "月令是否生扶日主", "Strength reference": "強弱參考", "Leaning strong": "偏強", "Balanced": "中和", "Leaning weak": "偏弱", "Yes": "是", "No": "否", "Current": "目前" },
  "ja": { "Luck cycles in depth": "大運の詳細", "Each ten-year cycle with the Ten Gods of its stem and branch; the current cycle is marked": "各大運の天干・地支の通変星。現在の大運に印を付けています", "Day-master strength": "日主の強弱", "Supporting and draining forces counted from stems, hidden stems and the season; one common method, schools differ": "天干・蔵干・月令から助ける力と弱める力を数えます。一般的な方法の一つで、流派により判断は異なります", "Supporting forces": "助ける力", "Draining forces": "弱める力", "Support share": "助ける力の割合", "Season supports the day master": "月令が日主を助けるか", "Strength reference": "強弱の目安", "Leaning strong": "やや強い", "Balanced": "中和", "Leaning weak": "やや弱い", "Yes": "はい", "No": "いいえ", "Current": "現在" },
  "ko": { "Luck cycles in depth": "대운 상세", "Each ten-year cycle with the Ten Gods of its stem and branch; the current cycle is marked": "각 대운의 천간·지지 십성, 현재 대운 표시", "Day-master strength": "일간 강약", "Supporting and draining forces counted from stems, hidden stems and the season; one common method, schools differ": "천간·장간·월령에서 돕는 힘과 빼는 힘을 셉니다. 일반적인 방법 중 하나이며 유파마다 다릅니다", "Supporting forces": "돕는 힘", "Draining forces": "빼는 힘", "Support share": "돕는 힘 비율", "Season supports the day master": "월령이 일간을 돕는지", "Strength reference": "강약 참고", "Leaning strong": "다소 강함", "Balanced": "중화", "Leaning weak": "다소 약함", "Yes": "예", "No": "아니요", "Current": "현재" },
  "vi": { "Luck cycles in depth": "Đại vận chi tiết", "Each ten-year cycle with the Ten Gods of its stem and branch; the current cycle is marked": "Thập thần của can và chi mỗi đại vận; đánh dấu đại vận hiện tại", "Day-master strength": "Mạnh yếu của nhật chủ", "Supporting and draining forces counted from stems, hidden stems and the season; one common method, schools differ": "Đếm lực sinh phù và khắc tiết từ can, tàng can và lệnh tháng; một cách tính phổ biến, các trường phái khác nhau", "Supporting forces": "Lực sinh phù", "Draining forces": "Lực khắc tiết hao", "Support share": "Tỷ lệ sinh phù", "Season supports the day master": "Lệnh tháng có sinh phù nhật chủ", "Strength reference": "Tham khảo mạnh yếu", "Leaning strong": "Thiên mạnh", "Balanced": "Trung hòa", "Leaning weak": "Thiên yếu", "Yes": "Có", "No": "Không", "Current": "Hiện tại" },
  "th": { "Luck cycles in depth": "วัฏจักรสิบปีโดยละเอียด", "Each ten-year cycle with the Ten Gods of its stem and branch; the current cycle is marked": "สิบเทพของก้านและกิ่งในแต่ละวัฏจักร พร้อมทำเครื่องหมายช่วงปัจจุบัน", "Day-master strength": "ความแข็งแรงของเจ้าวัน", "Supporting and draining forces counted from stems, hidden stems and the season; one common method, schools differ": "นับแรงสนับสนุนและแรงบั่นทอนจากก้าน ก้านซ่อน และฤดูกาล เป็นวิธีหนึ่งที่ใช้กันทั่วไป แต่ละสำนักต่างกัน", "Supporting forces": "แรงสนับสนุน", "Draining forces": "แรงบั่นทอน", "Support share": "สัดส่วนแรงสนับสนุน", "Season supports the day master": "ฤดูกาลสนับสนุนเจ้าวันหรือไม่", "Strength reference": "ระดับความแข็งแรง", "Leaning strong": "ค่อนข้างแข็ง", "Balanced": "สมดุล", "Leaning weak": "ค่อนข้างอ่อน", "Yes": "ใช่", "No": "ไม่", "Current": "ปัจจุบัน" },
};

function localizeBoardTermRaw(value: string, locale: Locale): string {
  const deepTerm = detailTerms[locale][value];
  if (deepTerm) return deepTerm;
  const engineLabel = lookupChartLabel(value, locale);
  if (engineLabel !== undefined) return engineLabel;
  const engineTerm = lookupChartTerm(value, locale);
  if (engineTerm) return engineTerm;
  const referenceFree = referenceFreeTerms[locale][value];
  if (referenceFree) return referenceFree;
  const normalizedValue = value.replaceAll(" · ", " ").replace(/\bpalace\b/g, "Palace").replace(/\bsector\b/g, "Sector").replace(/\boriginal line\b/g, "Original line").replace(/\bchanged line\b/g, "Changed line");
  const directGenerated = chartLabels[locale][value];
  if (directGenerated) return directGenerated;
  const naYin = localizeNaYin(value, locale);
  if (naYin) return naYin;
  const elementCountMatch = value.match(/^(Wood|Fire|Earth|Metal|Water)\s+(\d+)$/);
  if (elementCountMatch && locale !== "en") return `${localizeBoardTerm(elementCountMatch[1], locale)} ${elementCountMatch[2]}`;
  const branchPositionMatch = value.match(/^(.+?) position$/i);
  if (branchPositionMatch && locale !== "en" && !/[A-Za-z]/.test(branchPositionMatch[1])) {
    const labels: Record<Locale, string> = { en: "position", "zh-Hans": "位", "zh-Hant": "位", ja: "位", ko: "위", vi: "vị", th: "ตำแหน่ง" };
    return `${localizeBoardTerm(branchPositionMatch[1], locale)} ${labels[locale]}`;
  }
  const pillarMatch = normalizedValue.match(/^pillar (\d+)$/i);
  if (pillarMatch && locale !== "en") {
    const labels: Record<Locale, string> = { en: "Pillar", "zh-Hans": "四柱", "zh-Hant": "四柱", ja: "四柱", ko: "사주", vi: "Tứ Trụ", th: "สี่เสา" };
    return `${labels[locale]} ${String(Number(pillarMatch[1]) + 1).padStart(2, "0")}`;
  }
  const yearMatch = normalizedValue.match(/^Year \+(\d+)$/);
  if (yearMatch && locale !== "en") {
    const labels: Record<Locale, string> = { en: "Year +", "zh-Hans": "流年 +", "zh-Hant": "流年 +", ja: "年＋", ko: "연도 +", vi: "Năm +", th: "ปี +" };
    return `${labels[locale]}${yearMatch[1]}`;
  }
  const bureauMatch = value.match(/^(Yang|Yin) (\d+) Bureau$/);
  if (bureauMatch && locale !== "en") {
    const polarity: Record<Locale, Record<string, string>> = { en: { Yang: "Yang", Yin: "Yin" }, "zh-Hans": { Yang: "阳遁", Yin: "阴遁" }, "zh-Hant": { Yang: "陽遁", Yin: "陰遁" }, ja: { Yang: "陽遁", Yin: "陰遁" }, ko: { Yang: "양둔", Yin: "음둔" }, vi: { Yang: "Dương Độn", Yin: "Âm Độn" }, th: { Yang: "หยางตุ้น", Yin: "หยินตุ้น" } };
    const bureau: Record<Locale, string> = { en: "Bureau", "zh-Hans": "局", "zh-Hant": "局", ja: "局", ko: "국", vi: "Cục", th: "ผัง" };
    return `${polarity[locale][bureauMatch[1]]} ${bureauMatch[2]} ${bureau[locale]}`;
  }
  const groupMatch = value.match(/^Group (\d+)$/);
  if (groupMatch && locale !== "en") {
    const group: Record<Locale, string> = { en: "Group", "zh-Hans": "分组", "zh-Hant": "分組", ja: "グループ", ko: "그룹", vi: "Nhóm", th: "กลุ่ม" };
    return `${group[locale]} ${groupMatch[1]}`;
  }
  const windowMatch = normalizedValue.match(/^Window (\d+)$/);
  if (windowMatch && locale !== "en") {
    const labels: Record<Locale, string> = { en: "Window", "zh-Hans": "时窗", "zh-Hant": "時窗", ja: "時間帯", ko: "시간대", vi: "Khung giờ", th: "ช่วงเวลา" };
    return `${labels[locale]} ${windowMatch[1]}`;
  }
  const dayWindowMatch = normalizedValue.match(/^Day window (\d+)$/i);
  if (dayWindowMatch && locale !== "en") {
    const labels: Record<Locale, string> = { en: "Day window", "zh-Hans": "时段", "zh-Hant": "時段", ja: "時間帯", ko: "시간대", vi: "Khung giờ", th: "ช่วงเวลา" };
    return `${labels[locale]} ${dayWindowMatch[1]}`;
  }
  const match = normalizedValue.match(/^(Palace|Sector|Original line|Changed line|Line|Cycle|Year \+|Stage|Lesson|Pattern|Marker|Signal|Position|Prompt|Step) (\d+)$/);
  if (match && locale !== "en") {
    const stems: Record<Locale, Record<string, string>> = {
      en: {}, "zh-Hans": { Palace: "宫位", Sector: "分区", "Original line": "本卦第", "Changed line": "变卦第", Line: "第", Cycle: "周期", "Year +": "第", Stage: "阶段", Lesson: "课", Pattern: "格局", Marker: "标记", Signal: "信号", Position: "位置", Prompt: "提示", Step: "步骤" }, "zh-Hant": { Palace: "宮位", Sector: "分區", "Original line": "本卦第", "Changed line": "變卦第", Line: "第", Cycle: "週期", "Year +": "第", Stage: "階段", Lesson: "課", Pattern: "格局", Marker: "標記", Signal: "訊號", Position: "位置", Prompt: "提示", Step: "步驟" }, ja: { Palace: "宮", Sector: "セクター", "Original line": "本卦・", "Changed line": "変卦・", Line: "爻", Cycle: "サイクル", "Year +": "年＋", Stage: "段階", Lesson: "課", Pattern: "パターン", Marker: "マーカー", Signal: "シグナル", Position: "位置", Prompt: "プロンプト", Step: "手順" }, ko: { Palace: "궁", Sector: "섹터", "Original line": "본괘 ", "Changed line": "변괘 ", Line: "효", Cycle: "주기", "Year +": "년 +", Stage: "단계", Lesson: "과", Pattern: "패턴", Marker: "표식", Signal: "신호", Position: "위치", Prompt: "질문", Step: "단계" }, vi: { Palace: "Cung", Sector: "Khu", "Original line": "Hào gốc ", "Changed line": "Hào biến ", Line: "Hào", Cycle: "Chu kỳ", "Year +": "Năm +", Stage: "Giai đoạn", Lesson: "Khóa", Pattern: "Mẫu", Marker: "Dấu", Signal: "Tín hiệu", Position: "Vị trí", Prompt: "Gợi ý", Step: "Bước" }, th: { Palace: "วัง", Sector: "ส่วน", "Original line": "เส้นกว้าเดิม ", "Changed line": "เส้นกว้าแปร ", Line: "เส้น", Cycle: "รอบ", "Year +": "ปี +", Stage: "ช่วง", Lesson: "บท", Pattern: "แบบแผน", Marker: "เครื่องหมาย", Signal: "สัญญาณ", Position: "ตำแหน่ง", Prompt: "คำชวนคิด", Step: "ขั้น" } };
    return `${stems[locale][match[1]] ?? match[1]} ${match[2]}`.trim();
  }
  const translated = chartLabels[locale][value] ?? dailyRhythmTerms[locale][value] ?? independentMethodTerms[locale][value] ?? classicalTermNames[locale][value] ?? seasonalTermNames[locale][value] ?? methodTerms[locale][value] ?? denseBaziTerms[locale][value] ?? extendedTerms[locale][value] ?? sectionTerms[locale][value] ?? boardTerms[locale][value] ?? coreValueTerms[locale][value];
  if (translated) return translated;
  const generatedTerm = generatedChartTerms[locale][value] ?? generatedChartTermsInsensitive[locale][value.toLowerCase()];
  if (generatedTerm) return generatedTerm;
  if (value.includes(" → ")) return value.split(" → ").map((part) => localizeBoardTerm(part, locale)).join(" → ");
  if (value.includes(" / ")) return value.split(" / ").map((part) => localizeBoardTerm(part, locale)).join(" / ");
  if (value.includes("/") && !value.includes("://")) return value.split("/").map((part) => localizeBoardTerm(part, locale)).join("/");
  if (value.includes(" · ")) return value.split(" · ").map((part) => localizeBoardTerm(part, locale)).join(" · ");
  const generatedFallback = localizeGeneratedChartFallback(value, locale);
  if (generatedFallback) return generatedFallback;
  const segmented = translateChartText(value, locale);
  if (segmented !== undefined) return segmented;
  return localizeClassicalChartText(value, locale);
}

export function localizeBoardTerm(value: string, locale: Locale): string {
  return cleanVisibleBoardText(localizeBoardTermRaw(value, locale), locale);
}

type ChartCell = CompleteChart["board"]["cells"][number];

function selectFromKeyboard(event: KeyboardEvent<HTMLElement>, select: () => void) {
  if (event.key === "Enter" || event.key === " ") {
    event.preventDefault();
    select();
  }
}

function ChartCellInspector({ cell, locale }: { cell: ChartCell; locale: Locale }) {
  return <aside className="chart-cell-inspector" aria-live="polite" data-testid="chart-cell-inspector">
    <header><span>{copy[locale].layers}</span><h3>{localizeBoardTerm(cell.title, locale)}</h3>{cell.subtitle && <b>{localizeBoardTerm(cell.subtitle, locale)}</b>}</header>
    <dl>{cell.items.map((item) => <div key={`${item.label}-${item.value}`}><dt><ChartTerm raw={item.label} locale={locale}>{localizeBoardTerm(item.label, locale)}</ChartTerm></dt><dd>{localizeBoardTerm(item.value, locale)}</dd></div>)}</dl>
  </aside>;
}

export function localizeZiWeiPalace(value: string, locale: Locale) {
  return ziweiPalaceTerms[locale][value] ?? localizeBoardTerm(value, locale);
}

function localizeZiWeiTransformation(value: string, locale: Locale) {
  return ziweiTransformationTerms[locale][value] ?? localizeBoardTerm(value, locale);
}

function cellValue(cell: ChartCell | undefined, label: string) {
  return cell?.items.find((item) => item.label === label)?.value ?? "—";
}

function ProfessionalBaZiBoard({ chart, locale, onSelectCell }: { chart: CompleteChart; locale: Locale; onSelectCell: (id: string) => void }) {
  const rows = ["Stem", "Stem element", "Branch", "Branch element", "Ten God", "Hidden stems", "Pillar role", "Day-stem relation", "Seasonal status", "NaYin", "Life stage", "Auxiliary star", "Pillar shen-sha"];
  const cells = chart.board.cells.slice(0, 4);
  const cycles = chart.sections.find((section) => section.id === "luck-cycles")?.items.slice(0, 6) ?? [];
  const annual = chart.sections.find((section) => section.id === "annual-cycle")?.items.slice(0, 6) ?? [];
  const context = [
    { label: "Day master", value: cellValue(cells[2], "Stem") },
    { label: "Month branch", value: cellValue(cells[1], "Branch") },
    { label: "Element balance", value: chart.calendar.elements.map((entry) => `${entry.name} ${entry.count}`).join(" · ") },
    { label: "Chart time", value: chart.calendar.timeBasis === "true-solar" ? chart.calendar.trueSolarTime ?? chart.calendar.civilTime : chart.calendar.civilTime },
  ];
  return <section className="professional-bazi-board" aria-label={copy[locale].baziMatrix}>
    <div className="bazi-professional-main">
      <div className="bazi-matrix-heading"><span><ChartTerm raw={"Four Pillars"} locale={locale}>{localizeBoardTerm("Four Pillars", locale)}</ChartTerm></span><b>{localizeBoardTerm("Four-pillar study matrix", locale)}</b></div>
      <div className="bazi-matrix">
        <div className="bazi-corner">{localizeBoardTerm("Pillar", locale)}</div>
        {cells.map((cell) => <header key={cell.id} role="button" tabIndex={0} onClick={() => onSelectCell(cell.id)} onKeyDown={(event) => selectFromKeyboard(event, () => onSelectCell(cell.id))}><small>{localizeBoardTerm(cell.title, locale)}</small><b>{localizeBoardTerm(cell.subtitle ?? "—", locale)}</b></header>)}
        {rows.map((row) => <div className="bazi-row" key={row}>
          <strong><ChartTerm raw={row} locale={locale}>{localizeBoardTerm(row, locale)}</ChartTerm></strong>
          {cells.map((cell) => <span key={`${row}-${cell.id}`}>{row === "Ten God" ? <ChartTerm raw={cellValue(cell, row)} locale={locale}>{localizeBoardTerm(cellValue(cell, row), locale)}</ChartTerm> : localizeBoardTerm(cellValue(cell, row), locale)}</span>)}
        </div>)}
      </div>
      <div className="bazi-cycle-strip">
        <article><header><span><ChartTerm raw={"Ten-year study cycles"} locale={locale}>{localizeBoardTerm("Ten-year study cycles", locale)}</ChartTerm></span><b>{String(cycles.length).padStart(2, "0")}</b></header><div>{cycles.map((item) => <p key={item.label}><small>{localizeBoardTerm(item.label, locale)}</small><b>{localizeBoardTerm(item.value, locale)}</b></p>)}</div></article>
        <article><header><span><ChartTerm raw={"Annual study cycle"} locale={locale}>{localizeBoardTerm("Annual study cycle", locale)}</ChartTerm></span><b>{String(annual.length).padStart(2, "0")}</b></header><div>{annual.map((item) => <p key={item.label}><small>{localizeBoardTerm(item.label, locale)}</small><b>{localizeBoardTerm(item.value, locale)}</b></p>)}</div></article>
      </div>
    </div>
    <aside className="bazi-context-rail">
      <header><span>{localizeBoardTerm("Calendar context", locale)}</span><b>{localizeBoardTerm("Four Pillars", locale)}</b></header>
      <dl>{context.map((item) => <div key={item.label}><dt><ChartTerm raw={item.label} locale={locale}>{localizeBoardTerm(item.label, locale)}</ChartTerm></dt><dd>{localizeBoardTerm(item.value, locale)}</dd></div>)}</dl>
      <footer><span>{localizeBoardTerm("Solar", locale)}</span><b>{chart.calendar.solar}</b><span>{localizeBoardTerm("Lunar", locale)}</span><b>{localizeLunarDate(chart.calendar.lunar, locale)}</b></footer>
    </aside>
  </section>;
}

function ZiWeiPalace({ cell, locale, onSelectCell }: { cell: ChartCell; locale: Locale; onSelectCell: (id: string) => void }) {
  return <article className={`ziwei-palace ${cell.active ? "active" : ""}`} role="button" tabIndex={0} onClick={() => onSelectCell(cell.id)} onKeyDown={(event) => selectFromKeyboard(event, () => onSelectCell(cell.id))}>
    <header><span>{localizeBoardTerm(cellValue(cell, "Palace branch"), locale)} · {localizeBoardTerm(cellValue(cell, "Palace stem"), locale)}</span><h3>{localizeZiWeiPalace(cell.title, locale)}</h3><b>{localizeBoardTerm(cellValue(cell, "Core star"), locale)}</b></header>
    <dl>
      <div><dt>{localizeBoardTerm("Support star", locale)}</dt><dd>{localizeBoardTerm(cellValue(cell, "Support star"), locale)}</dd></div>
      <div><dt>{localizeBoardTerm("Minor star", locale)}</dt><dd>{localizeBoardTerm(cellValue(cell, "Minor star"), locale)}</dd></div>
      <div><dt>{localizeBoardTerm("Transformation", locale)}</dt><dd>{localizeZiWeiTransformation(cellValue(cell, "Transformation"), locale)}</dd></div>
      <div><dt>{localizeBoardTerm("Palace condition", locale)}</dt><dd>{localizeBoardTerm(cellValue(cell, "Palace condition"), locale)}</dd></div>
      <div><dt>{localizeBoardTerm("Life-body marker", locale)}</dt><dd>{localizeBoardTerm(cellValue(cell, "Life-body marker"), locale)}</dd></div>
      <div><dt>{localizeBoardTerm("Opposing palace", locale)}</dt><dd>{localizeZiWeiPalace(cellValue(cell, "Opposing palace"), locale)}</dd></div>
      <div><dt>{localizeBoardTerm("Three-harmony group", locale)}</dt><dd>{localizeBoardTerm(cellValue(cell, "Three-harmony group"), locale)}</dd></div>
    </dl>
    <footer><span>{localizeBoardTerm("Decade limit", locale)} {localizeBoardTerm(cellValue(cell, "Decade limit"), locale)}</span><b>{localizeBoardTerm("Annual focus", locale)} · {localizeBoardTerm(cellValue(cell, "Annual focus"), locale)}</b></footer>
  </article>;
}

function ProfessionalZiWeiBoard({ chart, locale, onSelectCell }: { chart: CompleteChart; locale: Locale; onSelectCell: (id: string) => void }) {
  const cells = chart.board.cells;
  const life = cells.find((cell) => cellValue(cell, "Life-body marker").includes("Life palace")) ?? cells[0];
  const body = cells.find((cell) => cellValue(cell, "Life-body marker").includes("Body palace")) ?? life;
  const bureau = chart.sections.find((section) => section.id === "bureau-context")?.items.find((entry) => entry.label === "Bureau element")?.value ?? "—";
  const perimeter = [cells[0], cells[1], cells[2], cells[3], cells[11], cells[4], cells[10], cells[5], cells[9], cells[8], cells[7], cells[6]].filter(Boolean) as ChartCell[];
  return <section className="professional-ziwei-board" aria-label={copy[locale].ziweiMatrix}>
    {perimeter.slice(0, 5).map((cell) => <ZiWeiPalace cell={cell} locale={locale} onSelectCell={onSelectCell} key={cell.id} />)}
    <aside className="ziwei-centre-well">
      <span>{localizeBoardTerm("Twelve-palace Zi Wei board", locale)}</span>
      <b>{localizeBoardTerm("Life palace", locale)} · {localizeZiWeiPalace(life?.title ?? "—", locale)}</b>
      <strong>{localizeBoardTerm("Body palace", locale)} · {localizeZiWeiPalace(body?.title ?? "—", locale)}</strong>
      <dl>
        <div><dt>{localizeBoardTerm("Core star", locale)}</dt><dd>{localizeBoardTerm(cellValue(life, "Core star"), locale)}</dd></div>
        <div><dt>{localizeBoardTerm("Transformation", locale)}</dt><dd>{localizeZiWeiTransformation(cellValue(life, "Transformation"), locale)}</dd></div>
        <div><dt>{localizeBoardTerm("Bureau element", locale)}</dt><dd>{localizeBoardTerm(bureau, locale)}</dd></div>
        <div><dt>{localizeBoardTerm("Chart time", locale)}</dt><dd>{chart.calendar.timeBasis === "true-solar" ? chart.calendar.trueSolarTime : chart.calendar.civilTime}</dd></div>
      </dl>
      <footer>{chart.calendar.solar} · {localizeLunarDate(chart.calendar.lunar, locale)}</footer>
    </aside>
    {perimeter.slice(5).map((cell) => <ZiWeiPalace cell={cell} locale={locale} onSelectCell={onSelectCell} key={cell.id} />)}
  </section>;
}

const overviewCopy: Record<Locale, { glance: string; elements: string; pillars: [string, string, string, string]; dayMaster: string; details: string }> = {
  en: { glance: "At a glance", elements: "Element balance", pillars: ["Year", "Month", "Day", "Hour"], dayMaster: "Day master", details: "All chart layers" },
  "zh-Hans": { glance: "一屏总览", elements: "五行分布", pillars: ["年柱", "月柱", "日柱", "时柱"], dayMaster: "日主", details: "全部盘面层级" },
  "zh-Hant": { glance: "一屏總覽", elements: "五行分布", pillars: ["年柱", "月柱", "日柱", "時柱"], dayMaster: "日主", details: "全部盤面層級" },
  ja: { glance: "ひと目で", elements: "五行のバランス", pillars: ["年柱", "月柱", "日柱", "時柱"], dayMaster: "日主", details: "すべての盤面レイヤー" },
  ko: { glance: "한눈에 보기", elements: "오행 분포", pillars: ["연주", "월주", "일주", "시주"], dayMaster: "일간", details: "모든 판면 층위" },
  vi: { glance: "Tổng quan", elements: "Cân bằng ngũ hành", pillars: ["Năm", "Tháng", "Ngày", "Giờ"], dayMaster: "Nhật chủ", details: "Tất cả các lớp lá số" },
  th: { glance: "ภาพรวม", elements: "สมดุลห้าธาตุ", pillars: ["ปี", "เดือน", "วัน", "ยาม"], dayMaster: "เจ้าวัน", details: "ทุกชั้นของผัง" },
};
const ELEMENT_COLOR: Record<string, string> = { Wood: "#7DB3A3", Fire: "#D9785F", Earth: "#C9A86A", Metal: "#C9CED6", Water: "#6E95C9" };

/** One-screen overview above the detailed board: four pillars as cards, element balance and three key facts. */
function ChartOverview({ chart, locale }: { chart: CompleteChart; locale: Locale }) {
  const text = overviewCopy[locale];
  const showPillars = chart.pillars.length === 4 && chart.pillars.every((pillar) => /^[甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥]$/.test(pillar));
  const total = chart.calendar.elements.reduce((sum, element) => sum + element.count, 0) || 1;
  const facts = (chart.sections[0]?.items ?? []).filter((item) => item.value && item.value !== "—").slice(0, 3);
  return <section className="chart-overview" aria-label={text.glance}>
    <h3>{text.glance}</h3>
    {showPillars && <div className="chart-overview-pillars">{chart.pillars.map((pillar, index) => <article key={index} className={index === 2 ? "is-day" : ""}><small>{text.pillars[index]}{index === 2 ? ` · ${text.dayMaster}` : ""}</small><b>{localizeBoardTerm(pillar, locale)}</b></article>)}</div>}
    <div className="chart-overview-elements" aria-label={text.elements}><small>{text.elements}</small>{chart.calendar.elements.map((element) => <span key={element.name} title={`${localizeBoardTerm(element.name, locale)} ${element.count}`}><i style={{ width: `${Math.round((element.count / total) * 100)}%`, background: ELEMENT_COLOR[element.name] ?? "var(--accent)" }} /><em>{localizeBoardTerm(element.name, locale)} {element.count}</em></span>)}</div>
    {facts.length > 0 && <ul className="chart-overview-facts">{facts.map((item) => <li key={`${item.label}-${item.value}`}><span>{localizeBoardTerm(item.label, locale)}</span><b>{localizeBoardTerm(item.value, locale)}</b></li>)}</ul>}
  </section>;
}

export function CompleteChartBoard({ chart, locale, onOpenLibrary }: { chart: CompleteChart; locale: Locale; onOpenLibrary?: () => void }) {
  const [view, setView] = useState<"board" | "layers" | "timeline">("board");
  const [openSection, setOpenSection] = useState(chart.sections[0]?.id ?? "");
  const [selectedCellId, setSelectedCellId] = useState(chart.board.cells.find((cell) => cell.active)?.id ?? chart.board.cells[0]?.id ?? "");
  const text = copy[locale];
  const shared = uiCopy(locale);
  const isBazi = chart.tool === "bazi" || chart.tool === "detail";
  const isZiWei = chart.tool === "ziwei";
  const boardName = isBazi ? specialistBoardNames[locale].bazi : isZiWei ? specialistBoardNames[locale].ziwei : chartLabels[locale][chart.board.label] ?? lookupChartLabel(chart.board.label, locale) ?? boardNames[locale][chart.board.kind];
  const keySections = chart.sections;
  const displayTime = chart.calendar.timeBasis === "true-solar" ? chart.calendar.trueSolarTime : chart.calendar.civilTime;
  const selectedCell = chart.board.cells.find((cell) => cell.id === selectedCellId) ?? chart.board.cells[0];
  return <section className="complete-chart" aria-label={text.board} data-testid="complete-chart-board">
    <header className="complete-chart-heading"><div><span>{shared.brandKicker}</span><h2>{boardName}</h2><p>{chart.calendar.solar} · {localizeLunarDate(chart.calendar.lunar, locale)}</p></div><aside><span>{text.place}</span><b>{chart.calendar.location ? formatGlobalLocation(chart.calendar.location, locale) : localizePlace(chart.inputSummary.place, locale) || "—"}</b><span>{text.timeBasis}</span><b>{chart.calendar.timeBasis === "true-solar" ? text.trueSolarTime : text.civilTime} · {displayTime}</b><span>{text.focus}</span><b>{chart.inputSummary.focus || "—"}</b></aside></header>
    <ReadingModeToggle locale={locale} />
    {view === "board" && <ChartOverview chart={chart} locale={locale} />}
    <nav className="chart-view-switcher" aria-label={text.layers}><button type="button" className={view === "board" ? "active" : ""} onClick={() => setView("board")}>{text.board}</button><button type="button" className={view === "layers" ? "active" : ""} onClick={() => setView("layers")}>{text.layers}</button><button type="button" className={view === "timeline" ? "active" : ""} onClick={() => setView("timeline")}>{text.timeline}</button>{onOpenLibrary && <button type="button" className="chart-shelf-link" onClick={onOpenLibrary}>{text.studyShelf}</button>}</nav>
    {view === "board" && isBazi && <ProfessionalBaZiBoard chart={chart} locale={locale} onSelectCell={setSelectedCellId} />}
    {view === "board" && isZiWei && <ProfessionalZiWeiBoard chart={chart} locale={locale} onSelectCell={setSelectedCellId} />}
    {view === "board" && !isBazi && !isZiWei && <div className={`complete-board ${chart.board.kind}`}>{chart.board.cells.map((cell) => <article key={cell.id} className={`${cell.active ? "active " : ""}${cell.tone ?? ""}`} role="button" tabIndex={0} aria-pressed={selectedCell.id === cell.id} onClick={() => setSelectedCellId(cell.id)} onKeyDown={(event) => selectFromKeyboard(event, () => setSelectedCellId(cell.id))}><header><small>{localizeBoardTerm(cell.id.replaceAll("-", " "), locale)}</small><h3>{localizeBoardTerm(cell.title, locale)}</h3>{cell.subtitle && <strong>{localizeBoardTerm(cell.subtitle, locale)}</strong>}</header><dl>{cell.items.map((item) => <div key={`${item.label}-${item.value}`} className={item.tone ?? ""}><dt>{localizeBoardTerm(item.label, locale)}</dt><dd>{localizeBoardTerm(item.value, locale)}</dd></div>)}</dl></article>)}</div>}
    {view === "board" && selectedCell && <ChartCellInspector cell={selectedCell} locale={locale} />}
    {view === "board" && <details className="chart-reference-toggle"><summary>{overviewCopy[locale].details}<b>+</b></summary><section className={`chart-reference-deck ${chart.board.kind}`} aria-label={text.layers}>{keySections.map((section) => <article key={section.id}><header><span><ChartTerm raw={section.title} locale={locale}>{localizeBoardTerm(section.title, locale)}</ChartTerm></span><b>{String(section.items.length).padStart(2, "0")}</b></header><p>{localizeBoardTerm(section.lead, locale)}</p><dl>{section.items.map((item) => <div key={`${item.label}-${item.value}`}><dt><ChartTerm raw={item.label} locale={locale}>{localizeBoardTerm(item.label, locale)}</ChartTerm></dt><dd>{localizeBoardTerm(item.value, locale)}</dd></div>)}</dl></article>)}</section></details>}
    {view === "layers" && <div className="chart-sections">{chart.sections.map((section) => <article key={section.id} className={openSection === section.id ? "open" : ""}><button type="button" onClick={() => setOpenSection((current) => current === section.id ? "" : section.id)} aria-expanded={openSection === section.id}><span>{localizeBoardTerm(section.title, locale)}</span><i>{openSection === section.id ? "−" : "+"}</i></button>{openSection === section.id && <div><p>{localizeBoardTerm(section.lead, locale)}</p><dl>{section.items.map((item) => <div key={`${item.label}-${item.value}`}><dt>{localizeBoardTerm(item.label, locale)}</dt><dd>{localizeBoardTerm(item.value, locale)}</dd></div>)}</dl></div>}</article>)}</div>}
    {view === "timeline" && <div className="chart-timeline"><article><span>{text.calendar}</span><b>{localizeBoardTerm(chart.calendar.zodiac, locale)} · {localizeBoardTerm(chart.calendar.naYin, locale)}</b><p>{shared.chart.favourable} {chart.calendar.yi.map((item) => localizeBoardTerm(item, locale)).join("、") || "—"} · {shared.chart.avoid} {chart.calendar.ji.map((item) => localizeBoardTerm(item, locale)).join("、") || "—"}</p></article><article><span>{text.sources}</span>{chart.sourceFacts.map((fact) => <p key={fact}>· {localizeSourceFact(fact, locale)}</p>)}</article></div>}
  </section>;
}
