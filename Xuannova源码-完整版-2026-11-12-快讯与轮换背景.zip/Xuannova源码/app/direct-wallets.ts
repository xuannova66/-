"use client";
// Four wallets per network for direct payment, the same idea as the BNB Chain checkout:
//   Ethereum: MetaMask, OKX Wallet, Binance Wallet, TokenPocket (EIP-6963 / EIP-1193, same discovery as BSC)
//   Solana:   Phantom, OKX Wallet, Binance Wallet, TokenPocket (Wallet Standard; Phantom's own API as a fallback)
//   TRON:     TronLink, OKX Wallet, TokenPocket, Bitget Wallet (the injected tronWeb of each wallet)
// Each wallet only signs one transfer prepared by the server; no keys or seed phrases pass through the site.
import { inTokenPocket, providerFor } from "./wallet-connect";
import { base58Encode, solanaTransferMessage } from "./chain-lite";

export type DirectChain = "ethereum" | "solana" | "tron";
export type DirectOrder = Record<string, string>;
export type DirectWallet = {
  id: string; label: string; icon?: string;
  installed: boolean;
  installUrl: string;
  /** Inside this wallet's own app, but the network's wallet is not the selected one (TokenPocket injects one chain at a time). */
  switchInApp?: boolean;
  /** Link that opens this page inside the wallet app's browser (phones). */
  appLink?: (url: string) => string;
  connect(): Promise<string>;
  pay(order: DirectOrder, address: string): Promise<string>;
};

export class DirectWalletError extends Error {
  constructor(public readonly code: "REJECTED" | "NOT_INSTALLED" | "WRONG_CHAIN" | "UNSUPPORTED" | "FAILED", message: string = code) { super(message); }
}
const rejected = (cause: unknown) => {
  const code = (cause as { code?: number })?.code;
  const message = cause instanceof Error ? cause.message : String(cause ?? "");
  return code === 4001 || /reject|denied|cancel|declined|closed/i.test(message);
};
const wrap = async <T,>(run: () => Promise<T>) => {
  try { return await run(); } catch (cause) {
    if (cause instanceof DirectWalletError) throw cause;
    throw new DirectWalletError(rejected(cause) ? "REJECTED" : "FAILED", cause instanceof Error ? cause.message : String(cause));
  }
};
const tpLink = (url: string, chain: string) => `tpoutside://pull.activity?param=${encodeURIComponent(JSON.stringify({ url, chain, source: "Xuannova" }))}`;
const okxLink = (url: string) => `okx://wallet/dapp/url?dappUrl=${encodeURIComponent(url)}`;

// ---- Ethereum ---------------------------------------------------------------------------------------------------
type Eip1193 = { request(args: { method: string; params?: unknown[] }): Promise<unknown> };
const evmWallets: Array<{ id: "metamask" | "okx" | "binance" | "tokenpocket"; label: string; installUrl: string; appLink?: (url: string) => string }> = [
  { id: "metamask", label: "MetaMask", installUrl: "https://metamask.io/download/", appLink: (url) => `https://metamask.app.link/dapp/${url.replace(/^https?:\/\//, "")}` },
  { id: "okx", label: "OKX Wallet", installUrl: "https://www.okx.com/web3", appLink: okxLink },
  { id: "binance", label: "Binance Wallet", installUrl: "https://www.binance.com/en/web3wallet" },
  { id: "tokenpocket", label: "TokenPocket", installUrl: "https://www.tokenpocket.pro/", appLink: (url) => tpLink(url, "ETH") },
];

async function ensureEthereumMainnet(provider: Eip1193) {
  const current = await provider.request({ method: "eth_chainId" }) as string;
  if (Number.parseInt(current, 16) === 1) return;
  try { await provider.request({ method: "wallet_switchEthereumChain", params: [{ chainId: "0x1" }] }); }
  catch (cause) { if (rejected(cause)) throw new DirectWalletError("REJECTED"); throw new DirectWalletError("WRONG_CHAIN"); }
  if (Number.parseInt(await provider.request({ method: "eth_chainId" }) as string, 16) !== 1) throw new DirectWalletError("WRONG_CHAIN");
}

function ethereumWallets(): DirectWallet[] {
  return evmWallets.map((wallet) => {
    const provider = () => providerFor(wallet.id) as Eip1193 | null;
    const installed = Boolean(provider());
    return {
      ...wallet,
      installed,
      switchInApp: !installed && wallet.id === "tokenpocket" && inTokenPocket(),
      connect: () => wrap(async () => {
        const p = provider(); if (!p) throw new DirectWalletError("NOT_INSTALLED");
        const accounts = await p.request({ method: "eth_requestAccounts" }) as string[];
        if (!accounts?.[0]) throw new DirectWalletError("REJECTED");
        await ensureEthereumMainnet(p);
        return accounts[0];
      }),
      pay: (order, address) => wrap(async () => {
        const p = provider(); if (!p) throw new DirectWalletError("NOT_INSTALLED");
        await ensureEthereumMainnet(p);
        return await p.request({ method: "eth_sendTransaction", params: [{ from: address, to: order.token, value: "0x0", data: order.data }] }) as string;
      }),
    };
  });
}

// ---- Solana (Wallet Standard) -----------------------------------------------------------------------------------
type StandardAccount = { address: string; chains?: readonly string[] };
type StandardWallet = {
  name: string; icon?: string; chains: readonly string[]; accounts: readonly StandardAccount[];
  features: Record<string, unknown> & {
    "standard:connect"?: { connect(input?: { silent?: boolean }): Promise<{ accounts: readonly StandardAccount[] }> };
    "solana:signAndSendTransaction"?: { signAndSendTransaction(...inputs: Array<{ account: StandardAccount; chain: string; transaction: Uint8Array }>): Promise<Array<{ signature: Uint8Array }>> };
  };
};
const standardWallets = new Set<StandardWallet>();
let standardListening = false;
function listenForStandardWallets() {
  if (standardListening || typeof window === "undefined") return;
  standardListening = true;
  const api = { register: (...wallets: StandardWallet[]) => { wallets.forEach((wallet) => standardWallets.add(wallet)); return () => wallets.forEach((wallet) => standardWallets.delete(wallet)); } };
  window.addEventListener("wallet-standard:register-wallet", (event) => { try { (event as CustomEvent<(api: unknown) => void>).detail(api); } catch { /* ignore a broken wallet */ } });
  try { window.dispatchEvent(new CustomEvent("wallet-standard:app-ready", { detail: api })); } catch { /* old browser */ }
}
/** Call early so wallets have time to announce themselves. */
export function prepareDirectWallets() { listenForStandardWallets(); }

const solanaChoices: Array<{ id: string; label: string; match: RegExp; installUrl: string; appLink?: (url: string) => string }> = [
  { id: "phantom", label: "Phantom", match: /phantom/i, installUrl: "https://phantom.com/download", appLink: (url) => `https://phantom.app/ul/browse/${encodeURIComponent(url)}?ref=${encodeURIComponent(new URL(url).origin)}` },
  { id: "okx", label: "OKX Wallet", match: /okx/i, installUrl: "https://www.okx.com/web3", appLink: okxLink },
  { id: "binance", label: "Binance Wallet", match: /binance/i, installUrl: "https://www.binance.com/en/web3wallet" },
  { id: "tokenpocket", label: "TokenPocket", match: /tokenpocket/i, installUrl: "https://www.tokenpocket.pro/", appLink: (url) => tpLink(url, "SOL") },
];
type PhantomLegacy = { isPhantom?: boolean; connect(): Promise<{ publicKey: { toString(): string } }>; request?(args: { method: string; params?: unknown }): Promise<{ signature: string }>; signAndSendTransaction?(transaction: unknown): Promise<{ signature: string | Uint8Array } | string> };

/** A stand-in for a web3.js Transaction for injected providers that expect one (they serialise it and sign the message). */
function transactionLike(message: Uint8Array) {
  const wire = unsignedSolanaTransaction(message);
  return { serialize: () => wire, serializeMessage: () => message, signatures: [], instructions: [], feePayer: undefined, recentBlockhash: undefined };
}

/** A legacy wire transaction with one empty signature slot: what Wallet Standard wallets sign and send. */
export const unsignedSolanaTransaction = (message: Uint8Array) => new Uint8Array([1, ...new Uint8Array(64), ...message]);

function solanaWallets(): DirectWallet[] {
  listenForStandardWallets();
  return solanaChoices.map((choice) => {
    const standard = () => [...standardWallets].find((wallet) => choice.match.test(wallet.name) && wallet.chains.some((chain) => chain.startsWith("solana:")) && wallet.features["solana:signAndSendTransaction"]);
    const legacy = () => {
      if (typeof window === "undefined") return undefined;
      const w = window as Window & { phantom?: { solana?: PhantomLegacy }; solana?: PhantomLegacy; tokenpocket?: { solana?: PhantomLegacy } };
      if (choice.id === "tokenpocket") return w.tokenpocket?.solana ?? (inTokenPocket() && w.solana && !w.solana.isPhantom ? w.solana : undefined);
      if (choice.id !== "phantom") return undefined;
      return w.phantom?.solana ?? (w.solana?.isPhantom ? w.solana : undefined);
    };
    let account: StandardAccount | undefined;
    const found = standard();
    return {
      id: choice.id, label: choice.label, icon: found?.icon, installUrl: choice.installUrl, appLink: choice.appLink,
      installed: Boolean(found || legacy()),
      switchInApp: !found && !legacy() && choice.id === "tokenpocket" && inTokenPocket(),
      connect: () => wrap(async () => {
        const wallet = standard();
        if (wallet?.features["standard:connect"]) {
          const result = await wallet.features["standard:connect"].connect();
          account = result.accounts.find((item) => !item.chains || item.chains.some((chain) => chain.startsWith("solana:"))) ?? result.accounts[0];
          if (!account) throw new DirectWalletError("REJECTED");
          return account.address;
        }
        const old = legacy(); if (!old) throw new DirectWalletError("NOT_INSTALLED");
        return (await old.connect()).publicKey.toString();
      }),
      pay: (order, address) => wrap(async () => {
        const message = solanaTransferMessage({ buyer: address, source: order.source, destination: order.destination, mint: order.mint, amount: BigInt(order.amountUnits), decimals: Number(order.decimals), memo: order.reference, recentBlockhash: order.recentBlockhash });
        const wallet = standard();
        const feature = wallet?.features["solana:signAndSendTransaction"];
        if (wallet && feature) {
          const signer = account ?? wallet.accounts.find((item) => item.address === address);
          if (!signer) throw new DirectWalletError("REJECTED");
          const [result] = await feature.signAndSendTransaction({ account: signer, chain: "solana:mainnet", transaction: unsignedSolanaTransaction(message) });
          if (!result?.signature) throw new DirectWalletError("FAILED");
          return base58Encode(result.signature);
        }
        const old = legacy(); if (!old) throw new DirectWalletError("NOT_INSTALLED");
        if (old.request) {
          try { return (await old.request({ method: "signAndSendTransaction", params: { message: base58Encode(message) } })).signature; }
          catch (cause) { if (rejected(cause) || !old.signAndSendTransaction) throw cause; }
        }
        if (!old.signAndSendTransaction) throw new DirectWalletError("UNSUPPORTED");
        const sent = await old.signAndSendTransaction(transactionLike(message));
        const sig = typeof sent === "string" ? sent : sent?.signature;
        if (!sig) throw new DirectWalletError("FAILED");
        return typeof sig === "string" ? sig : base58Encode(sig);
      }),
    };
  });
}

// ---- TRON -------------------------------------------------------------------------------------------------------
type TronWeb = {
  defaultAddress?: { base58?: string | false };
  transactionBuilder: {
    triggerSmartContract(contract: string, fn: string, options: Record<string, unknown>, params: Array<{ type: string; value: string }>, issuer: string): Promise<{ result?: { result?: boolean }; transaction?: Record<string, unknown> }>;
    addUpdateData(tx: Record<string, unknown>, data: string, format: string): Promise<Record<string, unknown>> | Record<string, unknown>;
  };
  trx: { sign(tx: Record<string, unknown>): Promise<Record<string, unknown>>; sendRawTransaction(tx: Record<string, unknown>): Promise<{ result?: boolean; txid?: string; code?: string }> };
};
type TronLinkLike = { request?(args: { method: string }): Promise<unknown>; tronWeb?: TronWeb | false };
type TronWindow = Window & { tronLink?: TronLinkLike; tronWeb?: TronWeb; okxwallet?: { tronLink?: TronLinkLike }; bitkeep?: { tronLink?: TronLinkLike; tronWeb?: TronWeb }; tokenpocket?: unknown; isTokenPocket?: boolean };

const tronChoices: Array<{ id: string; label: string; installUrl: string; appLink?: (url: string) => string; link: (w: TronWindow) => TronLinkLike | undefined }> = [
  { id: "tronlink", label: "TronLink", installUrl: "https://www.tronlink.org/", appLink: (url) => `tronlinkoutside://pull.activity?param=${encodeURIComponent(JSON.stringify({ url, action: "open", protocol: "tronlink", version: "1.0" }))}`, link: (w) => inTokenPocket() ? undefined : w.tronLink ?? (w.tronWeb && !w.okxwallet && !w.bitkeep ? { tronWeb: w.tronWeb } : undefined) },
  { id: "okx", label: "OKX Wallet", installUrl: "https://www.okx.com/web3", appLink: okxLink, link: (w) => w.okxwallet?.tronLink },
  { id: "tokenpocket", label: "TokenPocket", installUrl: "https://www.tokenpocket.pro/", appLink: (url) => tpLink(url, "TRX"), link: (w) => inTokenPocket() ? (w.tronLink ?? (w.tronWeb ? { tronWeb: w.tronWeb } : undefined)) : undefined },
  { id: "bitget", label: "Bitget Wallet", installUrl: "https://web3.bitget.com/", appLink: (url) => `bitkeep://bkconnect?action=dapp&url=${encodeURIComponent(url)}`, link: (w) => w.bitkeep?.tronLink ?? (w.bitkeep?.tronWeb ? { tronWeb: w.bitkeep.tronWeb } : undefined) },
];

function tronWallets(): DirectWallet[] {
  const w = (typeof window === "undefined" ? {} : window) as TronWindow;
  return tronChoices.map((choice) => {
    const link = () => choice.link(window as TronWindow);
    const tronWeb = () => { const value = link()?.tronWeb; return value || undefined; };
    return {
      id: choice.id, label: choice.label, installUrl: choice.installUrl, appLink: choice.appLink,
      installed: typeof window !== "undefined" && Boolean(choice.link(w)),
      switchInApp: choice.id === "tokenpocket" && inTokenPocket() && !choice.link(w),
      connect: () => wrap(async () => {
        const current = link(); if (!current) throw new DirectWalletError("NOT_INSTALLED");
        if (current.request) {
          const answer = await current.request({ method: "tron_requestAccounts" }) as { code?: number } | undefined;
          if (answer && typeof answer === "object" && answer.code !== undefined && answer.code !== 200) throw new DirectWalletError("REJECTED");
        }
        // tronWeb fills in the address a moment after the wallet is unlocked or authorised.
        let address = tronWeb()?.defaultAddress?.base58;
        for (let tries = 0; !address && tries < 15; tries += 1) { await new Promise((resolve) => setTimeout(resolve, 200)); address = tronWeb()?.defaultAddress?.base58; }
        if (!address) throw new DirectWalletError("REJECTED", "Unlock the wallet and try again");
        return address;
      }),
      pay: (order, address) => wrap(async () => {
        const tw = tronWeb(); if (!tw) throw new DirectWalletError("NOT_INSTALLED");
        const built = await tw.transactionBuilder.triggerSmartContract(order.token, "transfer(address,uint256)", { feeLimit: 100_000_000, callValue: 0 }, [{ type: "address", value: order.recipient }, { type: "uint256", value: order.amountUnits }], address);
        if (!built.result?.result || !built.transaction) throw new DirectWalletError("FAILED", "Could not prepare the transfer");
        const tagged = await tw.transactionBuilder.addUpdateData(built.transaction, order.reference, "hex");
        const signed = await tw.trx.sign(tagged);
        const sent = await tw.trx.sendRawTransaction(signed);
        if (!sent.result || !sent.txid) throw new DirectWalletError("FAILED", sent.code ?? "Broadcast failed");
        return sent.txid;
      }),
    };
  });
}

export function directWallets(chain: DirectChain): DirectWallet[] {
  if (typeof window === "undefined") return [];
  return chain === "ethereum" ? ethereumWallets() : chain === "solana" ? solanaWallets() : tronWallets();
}


/** What the browser exposes, for support: open the credits page with ?walletcheck=1 inside a wallet app and screenshot it. */
export function walletDiagnostics() {
  if (typeof window === "undefined") return [] as Array<[string, string]>;
  const w = window as unknown as Record<string, unknown> & { ethereum?: Record<string, unknown>; solana?: Record<string, unknown>; tronWeb?: { defaultAddress?: { base58?: string | false }; ready?: boolean }; tronLink?: unknown; tokenpocket?: Record<string, unknown> };
  listenForStandardWallets();
  const flag = (value: unknown) => (value ? "yes" : "no");
  return [
    ["userAgent", navigator.userAgent],
    ["TokenPocket app", flag(inTokenPocket())],
    ["TokenPocket bridge", flag((w as Record<string, unknown>).TPJSBrigeClient || (w as { webkit?: { messageHandlers?: { getWallet?: unknown } } }).webkit?.messageHandlers?.getWallet)],
    ["window.tokenpocket", w.tokenpocket ? Object.keys(w.tokenpocket).join(", ") || "yes" : "no"],
    ["window.ethereum", w.ethereum ? ["isTokenPocket", "isMetaMask", "isOkxWallet", "isBinance"].filter((key) => w.ethereum?.[key]).join(", ") || "yes" : "no"],
    ["window.solana", w.solana ? ["isPhantom", "isTokenPocket"].filter((key) => w.solana?.[key]).join(", ") || "yes" : "no"],
    ["window.tronWeb", w.tronWeb ? `ready=${flag(w.tronWeb.ready)} address=${w.tronWeb.defaultAddress?.base58 ? "yes" : "no"}` : "no"],
    ["window.tronLink", flag(w.tronLink)],
    ["Solana Wallet Standard", [...standardWallets].map((item) => item.name).join(", ") || "none"],
  ] as Array<[string, string]>;
}
