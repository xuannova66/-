// Calendar-mode conversion for the birth form: switching solar ⇄ lunar converts the date the
// person already entered (instead of keeping the same numbers), and switching to four pillars
// pre-fills the pillars of that moment so they never disagree with the visible date.
import { Lunar, LunarYear, Solar } from "lunar-javascript";
import { validatePillars } from "./metaphysics/bazi-extra";
import type { Locale } from "./site-content";

type CalendarMode = "solar" | "lunar" | "pillars";
const pad = (value: number) => String(value).padStart(2, "0");

function parts(date: string, time: string) {
  const [y = 1994, m = 1, d = 1] = date.split("-").map(Number);
  const [hh = 12, mm = 0] = time.split(":").map(Number);
  return { y, m, d, hh, mm };
}

function toLunarSafe(y: number, m: number, d: number, leap: boolean, hh: number, mm: number) {
  for (const day of [d, 30, 29]) {
    try { return Lunar.fromYmdHms(y, leap ? -m : m, Math.min(d, day), hh, mm, 0); } catch { /* try a shorter month */ }
  }
  return Lunar.fromYmdHms(y, m, 1, hh, mm, 0);
}

/** The solar moment currently described by the form fields. */
export function solarMomentOf(date: string, time: string, mode: CalendarMode, leap: boolean) {
  const p = parts(date, time);
  if (mode === "lunar") return toLunarSafe(p.y, p.m, p.d, leap, p.hh, p.mm).getSolar();
  return Solar.fromYmdHms(p.y, p.m, Math.min(p.d, 31), p.hh, p.mm, 0);
}

export function convertCalendar(
  date: string, time: string, from: CalendarMode, to: CalendarMode, leap: boolean,
): { date: string; leap: boolean; pillars?: string[] } {
  if (from === to) return { date, leap };
  const solar = solarMomentOf(date, time, from === "pillars" ? "solar" : from, leap);
  if (to === "lunar") {
    const lunar = solar.getLunar();
    return { date: `${lunar.getYear()}-${pad(Math.abs(lunar.getMonth()))}-${pad(lunar.getDay())}`, leap: lunar.getMonth() < 0 };
  }
  const solarDate = `${solar.getYear()}-${pad(solar.getMonth())}-${pad(solar.getDay())}`;
  if (to === "pillars") {
    const eightChar = solar.getLunar().getEightChar();
    return { date: solarDate, leap: false, pillars: [eightChar.getYear(), eightChar.getMonth(), eightChar.getDay(), eightChar.getTime()] };
  }
  return { date: solarDate, leap: false };
}

/** Leap month number of a lunar year (0 when the year has none). */
export function leapMonthOf(year: number) {
  try { return LunarYear.fromYear(year).getLeapMonth(); } catch { return 0; }
}

export function todayIso() {
  const now = new Date();
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
}

export function pillarWarnings(pillars: string[]) {
  return validatePillars(pillars);
}

export const inputCalendarCopy: Record<Locale, { leap: string; monthStem: string; hourStem: string; invalid: string; pillarsNote: string }> = {
  en: { leap: "Leap month", monthStem: "The month stem does not match the year pillar (five-tiger rule).", hourStem: "The hour stem does not match the day pillar (five-rat rule).", invalid: "Choose four valid stem-branch pillars.", pillarsNote: "Manual pillars have no birth moment, so the luck-cycle start age is not calculated." },
  "zh-Hans": { leap: "闰月", monthStem: "月柱天干与年柱不符（五虎遁）。", hourStem: "时柱天干与日柱不符（五鼠遁）。", invalid: "请选择有效的四柱干支。", pillarsNote: "手动四柱没有出生时刻，因此不计算起运年龄。" },
  "zh-Hant": { leap: "閏月", monthStem: "月柱天干與年柱不符（五虎遁）。", hourStem: "時柱天干與日柱不符（五鼠遁）。", invalid: "請選擇有效的四柱干支。", pillarsNote: "手動四柱沒有出生時刻，因此不計算起運年齡。" },
  ja: { leap: "閏月", monthStem: "月柱の天干が年柱と一致しません（五虎遁）。", hourStem: "時柱の天干が日柱と一致しません（五鼠遁）。", invalid: "有効な四柱の干支を選んでください。", pillarsNote: "手入力の四柱には出生時刻がないため、立運の年齢は計算しません。" },
  ko: { leap: "윤달", monthStem: "월주 천간이 연주와 맞지 않습니다(오호둔).", hourStem: "시주 천간이 일주와 맞지 않습니다(오서둔).", invalid: "올바른 사주 간지를 선택하세요.", pillarsNote: "직접 입력한 사주에는 출생 시각이 없어 대운 시작 나이를 계산하지 않습니다." },
  vi: { leap: "Tháng nhuận", monthStem: "Can tháng không khớp với trụ năm (quy tắc Ngũ Hổ Độn).", hourStem: "Can giờ không khớp với trụ ngày (quy tắc Ngũ Thử Độn).", invalid: "Hãy chọn bốn trụ can chi hợp lệ.", pillarsNote: "Tứ trụ nhập tay không có thời điểm sinh nên không tính tuổi khởi vận." },
  th: { leap: "เดือนอธิกมาส", monthStem: "ก้านของเสาเดือนไม่ตรงกับเสาปี (กฎห้าเสือ)", hourStem: "ก้านของเสายามไม่ตรงกับเสาวัน (กฎห้าหนู)", invalid: "โปรดเลือกสี่เสาที่ถูกต้อง", pillarsNote: "สี่เสาที่ป้อนเองไม่มีเวลาเกิด จึงไม่คำนวณอายุเริ่มวัฏจักร" },
};

// Per-tool input fields for the toolkit: each tool asks only for what its method uses.
export type ToolkitFieldSpec = { date: "birth" | "event" | false; time: boolean; gender: boolean; text: "dream" | "name" | "question" | false };
export const toolkitFields: Record<string, ToolkitFieldSpec> = {
  time: { date: "birth", time: false, gender: false, text: false },
  elements: { date: "birth", time: true, gender: true, text: false },
  dream: { date: "event", time: false, gender: false, text: "dream" },
  name: { date: "birth", time: true, gender: true, text: "name" },
  tarot: { date: false, time: false, gender: false, text: "question" },
  iching: { date: "event", time: true, gender: false, text: "question" },
  natal: { date: "birth", time: true, gender: false, text: false },
  meihua: { date: "event", time: true, gender: false, text: "question" },
  fengshui: { date: "birth", time: false, gender: true, text: false },
};

export const toolkitFieldCopy: Record<Locale, { birthDate: string; eventDate: string; dream: string; name: string; question: string; dreamDate: string; castDate: string }> = {
  en: { birthDate: "Birth date", eventDate: "Date", dream: "Describe the dream: the people, places, animals or objects you remember", name: "Full name", question: "Write the question you are holding", dreamDate: "Date of the dream", castDate: "Casting moment" },
  "zh-Hans": { birthDate: "出生日期", eventDate: "日期", dream: "描述梦境：记得的人物、地点、动物或物品", name: "姓名", question: "写下你想问的问题", dreamDate: "做梦日期", castDate: "起卦时间" },
  "zh-Hant": { birthDate: "出生日期", eventDate: "日期", dream: "描述夢境：記得的人物、地點、動物或物品", name: "姓名", question: "寫下你想問的問題", dreamDate: "做夢日期", castDate: "起卦時間" },
  ja: { birthDate: "生年月日", eventDate: "日付", dream: "夢の内容：覚えている人物・場所・動物・物を書いてください", name: "氏名", question: "知りたい問いを書いてください", dreamDate: "夢を見た日", castDate: "起卦の時刻" },
  ko: { birthDate: "생년월일", eventDate: "날짜", dream: "꿈 내용: 기억나는 사람, 장소, 동물, 물건을 적어 주세요", name: "이름", question: "묻고 싶은 질문을 적어 주세요", dreamDate: "꿈꾼 날짜", castDate: "괘를 세우는 시각" },
  vi: { birthDate: "Ngày sinh", eventDate: "Ngày", dream: "Mô tả giấc mơ: người, nơi chốn, con vật hay đồ vật bạn nhớ", name: "Họ tên", question: "Viết câu hỏi bạn đang mang", dreamDate: "Ngày mơ", castDate: "Thời điểm lập quẻ" },
  th: { birthDate: "วันเกิด", eventDate: "วันที่", dream: "เล่าความฝัน: บุคคล สถานที่ สัตว์ หรือสิ่งของที่จำได้", name: "ชื่อ-นามสกุล", question: "เขียนคำถามที่คุณอยากรู้", dreamDate: "วันที่ฝัน", castDate: "เวลาตั้งกว้า" },
};
