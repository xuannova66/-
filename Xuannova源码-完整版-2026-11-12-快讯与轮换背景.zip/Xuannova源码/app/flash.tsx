"use client";
// Xuannova 快讯 · Xuannova Flash, the reader side:
//   FlashTicker   slim live band under the header, headlines rolling every 5 s (never covers the page)
//   HomeFlashStrip latest three on the home page
//   FlashScreen   /flash timeline (left time axis, cards) and /flash/<slug> detail page
//   ShareSheet    system share, copy link, WeChat (QR + poster), X, Facebook, LINE, WhatsApp, Telegram, Weibo
//   poster        1080×1920 image: headline, reading, classic line, logo and QR code to the item
// No read counts are shown to visitors (the admin page has the real numbers); cards say "new" or "trending".
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Locale } from "./site-content";
import type { AppRoute } from "./study-suite";
import { pathFor } from "./study-navigation";
import { drawFooter, drawQr, invitedUrl, loadLogo, PosterPreview, usePoster } from "./daily-posters";
import { fontFor, wrap } from "./share-card";
import { cloud, enso, goldFoil, mountains, seeded, sparkles } from "./poster-art";
import { countShare } from "./share-stats-client";
import { track } from "./analytics";
import { ContactIcon } from "./contact-icons";

export type FlashCategory = "focus" | "energy" | "wisdom";
export type FlashItem = {
  id: string; slug: string; category: FlashCategory; pinned: boolean; featured: boolean; cta: string;
  sourceUrl: string | null; sourceName: string | null; coverUrl: string | null;
  views: number; shares: number; posters: number; publishedAt: string; updatedAt: string; locale: string;
  text: { title: string; summary: string; body: string; quote: string | null; quoteSource: string | null };
  locales: string[];
};

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

export const flashText = {
  name: L("Xuannova Flash", "Xuannova 快讯", "Xuannova 快訊", "Xuannova 速報", "Xuannova 속보", "Tin nhanh Xuannova", "ข่าวด่วน Xuannova"),
  eyebrow: L("NEWS · READ THROUGH EASTERN WISDOM", "热点 · 国学解析", "熱點 · 國學解析", "ニュース · 東洋の知恵で読む", "뉴스 · 동양 지혜로 읽기", "TIN NÓNG · GÓC NHÌN PHƯƠNG ĐÔNG", "ข่าว · มองผ่านปัญญาตะวันออก"),
  lead: L("Today's news, read through the five elements, the I Ching and the seasons — with a line from the classics.", "把今天的热点放进五行、易经与节气里看一看，再配一句经典。", "把今天的熱點放進五行、易經與節氣裡看一看，再配一句經典。", "今日のニュースを五行・易経・節気の目で読み、古典の一句を添えて。", "오늘의 뉴스를 오행·주역·절기의 눈으로 읽고 고전 한 구절을 더합니다.", "Tin tức hôm nay qua lăng kính ngũ hành, Kinh Dịch và tiết khí — kèm một câu kinh điển.", "ข่าววันนี้ผ่านมุมมองห้าธาตุ อี้จิง และฤดูกาล พร้อมวลีจากคัมภีร์"),
  short: L("News", "快讯", "快訊", "速報", "속보", "Tin", "ข่าว"),
  live: L("LIVE", "LIVE", "LIVE", "LIVE", "LIVE", "LIVE", "LIVE"),
  all: L("All news", "全部快讯", "全部快訊", "すべて", "전체 보기", "Tất cả", "ทั้งหมด"),
  readMore: L("Read more", "阅读全文", "閱讀全文", "全文を読む", "전문 보기", "Đọc thêm", "อ่านต่อ"),
  poster: L("Make poster", "生成海报", "生成海報", "ポスター作成", "포스터 만들기", "Tạo poster", "สร้างโปสเตอร์"),
  share: L("Share", "分享", "分享", "シェア", "공유", "Chia sẻ", "แชร์"),
  focus: L("Focus", "今日焦点", "今日焦點", "今日の焦点", "오늘의 초점", "Tiêu điểm", "ประเด็นวันนี้"),
  energy: L("Energy of the times", "时事能量", "時事能量", "時の気", "시대의 기운", "Năng lượng thời cuộc", "พลังแห่งกาล"),
  wisdom: L("Wisdom of the day", "国学微言", "國學微言", "今日の一句", "오늘의 한 구절", "Lời hay mỗi ngày", "ปัญญาประจำวัน"),
  filterAll: L("All", "全部", "全部", "すべて", "전체", "Tất cả", "ทั้งหมด"),
  fresh: L("New", "新发布", "新發布", "新着", "새 글", "Mới", "ใหม่"),
  trending: L("Trending", "今日热读", "今日熱讀", "話題", "인기", "Đang hot", "มาแรง"),
  featured: L("Editor's pick", "编辑精选", "編輯精選", "編集部おすすめ", "에디터 추천", "Biên tập chọn", "บรรณาธิการเลือก"),
  pinned: L("Pinned", "置顶", "置頂", "固定", "고정", "Ghim", "ปักหมุด"),
  read: L("{n} reads", "{n} 人看过", "{n} 人看過", "{n} 人が閲覧", "{n}명 읽음", "{n} lượt đọc", "อ่านแล้ว {n} คน"),
  loadMore: L("Load more", "加载更多", "載入更多", "もっと見る", "더 보기", "Xem thêm", "โหลดเพิ่ม"),
  gone: L("This item is no longer available.", "这条快讯已下架或不存在。", "這條快訊已下架或不存在。", "この速報は公開を終了しました。", "이 소식은 내려갔거나 없습니다.", "Tin này không còn nữa.", "ข่าวนี้ไม่มีแล้ว"),
  empty: L("The first items are on their way.", "第一批快讯正在路上。", "第一批快訊正在路上。", "最初の速報を準備中です。", "첫 소식을 준비하고 있습니다.", "Những tin đầu tiên đang đến.", "ข่าวชุดแรกกำลังมา"),
  back: L("All news", "返回快讯", "返回快訊", "速報一覧へ", "속보 목록", "Về danh sách", "กลับไปหน้าข่าว"),
  source: L("Original report", "原文来源", "原文來源", "元の記事", "원문 출처", "Nguồn tin", "แหล่งข่าวต้นฉบับ"),
  related: L("More news", "更多快讯", "更多快訊", "ほかの速報", "다른 소식", "Tin khác", "ข่าวอื่น"),
  collapse: L("Hide", "收起", "收起", "閉じる", "접기", "Thu gọn", "ซ่อน"),
  open: L("Open Xuannova Flash", "打开 Xuannova 快讯", "打開 Xuannova 快訊", "Xuannova 速報を開く", "Xuannova 속보 열기", "Mở tin nhanh", "เปิดข่าวด่วน"),
  close: L("Close", "关闭", "關閉", "閉じる", "닫기", "Đóng", "ปิด"),
  shareTitle: L("Share this news", "转发这条快讯", "轉發這條快訊", "この速報をシェア", "이 소식 공유", "Chia sẻ tin này", "แชร์ข่าวนี้"),
  system: L("Share…", "系统分享", "系統分享", "共有…", "공유…", "Chia sẻ…", "แชร์…"),
  copy: L("Copy link", "复制链接", "複製連結", "リンクをコピー", "링크 복사", "Sao chép liên kết", "คัดลอกลิงก์"),
  copied: L("Link copied", "链接已复制", "連結已複製", "コピーしました", "복사됨", "Đã sao chép", "คัดลอกแล้ว"),
  wechat: L("WeChat / Moments", "微信 / 朋友圈", "微信 / 朋友圈", "WeChat", "위챗", "WeChat", "WeChat"),
  wechatTip: L("Scan with WeChat, then tap ··· to send to a chat or Moments. Or save the poster and post it.", "用微信扫一扫打开，点右上角「···」即可发给朋友或分享到朋友圈；也可以保存海报后发朋友圈。", "用微信掃一掃打開，點右上角「···」即可發給朋友或分享到朋友圈；也可以儲存海報後發朋友圈。", "WeChatでスキャンし、右上の「···」から友だちやモーメンツへ。ポスターを保存して投稿することもできます。", "위챗으로 스캔한 뒤 오른쪽 위 「···」에서 친구나 모멘트로 보내세요. 포스터를 저장해 올려도 됩니다.", "Quét bằng WeChat rồi bấm «···» để gửi bạn bè hoặc đăng Moments. Hoặc lưu poster rồi đăng.", "สแกนด้วย WeChat แล้วแตะ «···» เพื่อส่งให้เพื่อนหรือโพสต์ Moments หรือบันทึกโปสเตอร์แล้วโพสต์"),
  scan: L("Scan to read the full story", "扫码阅读这条快讯全文", "掃碼閱讀這條快訊全文", "スキャンして全文を読む", "스캔해서 전문 읽기", "Quét mã để đọc toàn bài", "สแกนเพื่ออ่านข่าวเต็ม"),
  posterTitle: L("Today's news · read through Eastern wisdom", "热点 · 国学解析", "熱點 · 國學解析", "ニュースを東洋の知恵で", "뉴스를 동양 지혜로", "Tin nóng · góc nhìn phương Đông", "ข่าวผ่านปัญญาตะวันออก"),
  ago: L("{t}", "{t}", "{t}", "{t}", "{t}", "{t}", "{t}"),
};

const CTA: Record<string, L7> = {
  bazi: L("Your five elements: free chart →", "测一测：你的五行喜忌是什么？→", "測一測：你的五行喜忌是什麼？→", "あなたの五行は？無料で見る →", "나의 오행은? 무료로 보기 →", "Ngũ hành của bạn: xem miễn phí →", "ธาตุของคุณคืออะไร ดูฟรี →"),
  daily: L("Today's hours and rhythm →", "看看今天的时辰与节律 →", "看看今天的時辰與節律 →", "今日の時刻とリズム →", "오늘의 시진과 리듬 →", "Giờ tốt và nhịp điệu hôm nay →", "ยามดีและจังหวะวันนี้ →"),
  almanac: L("Is today a good day? →", "查看今日黄历宜忌 →", "查看今日黃曆宜忌 →", "今日の暦を見る →", "오늘의 황력 보기 →", "Hôm nay tốt hay xấu? →", "วันนี้ดีไหม →"),
  compatibility: L("How well do you two match? →", "测测你们的缘分 →", "測測你們的緣分 →", "二人の相性を見る →", "두 사람의 궁합 보기 →", "Hai bạn hợp nhau thế nào? →", "ดูความเข้ากันของสองคน →"),
  ziwei: L("See your Zi Wei chart →", "看看你的紫微命盘 →", "看看你的紫微命盤 →", "紫微斗数を見る →", "자미두수 명반 보기 →", "Xem lá số Tử Vi →", "ดูผังจื่อเวย →"),
  liuyao: L("Something on your mind? Cast a hexagram →", "心里有事？起一卦 →", "心裡有事？起一卦 →", "気になることを一卦で →", "고민이 있다면 한 괘 →", "Có điều băn khoăn? Gieo một quẻ →", "มีเรื่องในใจ? ตั้งกว้าดู →"),
  meihua: L("Plum blossom reading for this moment →", "此刻起一卦梅花易数 →", "此刻起一卦梅花易數 →", "今この時の梅花易数 →", "지금 이 순간의 매화역수 →", "Mai Hoa cho khoảnh khắc này →", "เหมยฮวาสำหรับตอนนี้ →"),
  qimen: L("Timing a decision? Qi Men →", "要做决定？看看奇门时机 →", "要做決定？看看奇門時機 →", "決断のタイミングを奇門で →", "결정의 때를 기문으로 →", "Chọn thời điểm với Kỳ Môn →", "จังหวะตัดสินใจด้วยฉีเหมิน →"),
  zeri: L("Pick a good day →", "挑个好日子 →", "挑個好日子 →", "良い日を選ぶ →", "좋은 날 고르기 →", "Chọn ngày tốt →", "เลือกวันดี →"),
  toolkit: L("Open the study toolkit →", "打开百宝袋 →", "打開百寶袋 →", "学習ツールを開く →", "학습 도구 열기 →", "Mở bộ công cụ →", "เปิดชุดเครื่องมือ →"),
};
const ctaLabel = (cta: string, locale: Locale) => (CTA[cta] ?? CTA.bazi)[locale];
const CATEGORY_DOT: Record<FlashCategory, string> = { focus: "#e2483d", energy: "#e7b23c", wisdom: "#4b8fe0" };
const TRENDING_AT = 30;

export const flashPath = (locale: Locale, slug?: string) => `${pathFor(locale, "flash")}${slug ? `/${slug}` : ""}`;
export const flashUrl = (locale: Locale, slug: string) => `https://xuannova.com${flashPath(locale, slug)}`;

function timeAgo(iso: string, locale: Locale, now = Date.now()) {
  const seconds = Math.round((Date.parse(iso) - now) / 1000);
  const rtf = new Intl.RelativeTimeFormat(locale, { numeric: "auto" });
  const abs = Math.abs(seconds);
  if (abs < 60) return rtf.format(0, "minute");
  if (abs < 3600) return rtf.format(Math.round(seconds / 60), "minute");
  if (abs < 86_400) return rtf.format(Math.round(seconds / 3600), "hour");
  if (abs < 7 * 86_400) return rtf.format(Math.round(seconds / 86_400), "day");
  return new Date(iso).toLocaleDateString(locale, { year: "numeric", month: "short", day: "numeric" });
}
const dayKey = (iso: string, locale: Locale) => new Date(iso).toLocaleDateString(locale, { month: "long", day: "numeric", weekday: "short" });

// --------------------------------------------------------------------------- shared feed with live refresh
type Feed = { items: FlashItem[]; next: string | null; version: string; loaded: boolean };
const feeds = new Map<string, Feed>();
const listeners = new Set<() => void>();
const inflight = new Map<string, Promise<void>>();
const emit = () => listeners.forEach((listener) => listener());

async function loadFeed(locale: Locale) {
  const running = inflight.get(locale);
  if (running) return running;
  const job = (async () => {
    try {
      const response = await fetch(`/api/flash?locale=${encodeURIComponent(locale)}&limit=12`, { credentials: "same-origin" });
      if (!response.ok) throw new Error(String(response.status));
      const data = await response.json() as { items?: FlashItem[]; next?: string | null; version?: string };
      feeds.set(locale, { items: data.items ?? [], next: data.next ?? null, version: data.version ?? "", loaded: true });
    } catch {
      if (!feeds.has(locale)) feeds.set(locale, { items: [], next: null, version: "", loaded: true });
    } finally { inflight.delete(locale); emit(); }
  })();
  inflight.set(locale, job);
  return job;
}

let poller: number | null = null;
let pollLocale: Locale | null = null;
function startPolling(locale: Locale) {
  pollLocale = locale;
  if (poller !== null || typeof window === "undefined") return;
  const check = async () => {
    if (document.hidden || !pollLocale) return;
    try {
      const response = await fetch("/api/flash/version", { credentials: "same-origin" });
      const { version } = await response.json() as { version?: string };
      const current = feeds.get(pollLocale);
      if (version && current && version !== current.version) await loadFeed(pollLocale);
    } catch { /* offline */ }
  };
  poller = window.setInterval(() => void check(), 15_000);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) void check(); });
}

/** Latest items in the reader's language, kept fresh: a tiny version check every 15 s brings new items in. */
export function useFlashFeed(locale: Locale, enabled = true) {
  const [, setTick] = useState(0);
  useEffect(() => {
    if (!enabled) return;
    const listener = () => setTick((value) => value + 1);
    listeners.add(listener);
    if (!feeds.has(locale)) void loadFeed(locale);
    startPolling(locale);
    return () => { listeners.delete(listener); };
  }, [locale, enabled]);
  return feeds.get(locale) ?? { items: [], next: null, version: "", loaded: false };
}

// --------------------------------------------------------------------------- small pieces
function CategoryTag({ category, locale }: { category: FlashCategory; locale: Locale }) {
  return <span className={`flash-tag flash-tag-${category}`}><i style={{ background: CATEGORY_DOT[category] }} aria-hidden="true" />{flashText[category][locale]}</span>;
}

/** No read counts on the page (only the admin sees them). A first-day item says "new"; one that many people
 *  really opened today says "trending". */
function ReadBadge({ item, locale }: { item: FlashItem; locale: Locale }) {
  const young = Date.now() - Date.parse(item.publishedAt) < 24 * 3_600_000;
  if (young && item.views >= TRENDING_AT * 3) return <span className="flash-views flash-hot"><b aria-hidden="true">🔥</b> {flashText.trending[locale]}</span>;
  return young ? <span className="flash-views flash-fresh"><b aria-hidden="true">✦</b> {flashText.fresh[locale]}</span> : <span className="flash-views" />;
}

function Badges({ item, locale }: { item: FlashItem; locale: Locale }) {
  return <>{item.pinned && <span className="flash-badge">{flashText.pinned[locale]}</span>}{item.featured && <span className="flash-badge gold">{flashText.featured[locale]}</span>}</>;
}

export function openFlash(locale: Locale, slug?: string) {
  const target = flashPath(locale, slug);
  if (window.location.pathname !== target) window.history.pushState({ scrollY: 0 }, "", target);
  window.dispatchEvent(new Event("xn:navigate"));
  window.scrollTo({ top: 0 });
}

// --------------------------------------------------------------------------- poster
const PW = 1080, PH = 1920;
export async function drawFlashPoster(canvas: HTMLCanvasElement, options: { locale: Locale; item: FlashItem; link: string }) {
  const { locale, item, link } = options;
  canvas.width = PW; canvas.height = PH;
  const ctx = canvas.getContext("2d")!;
  const font = fontFor(locale);
  const serif = locale === "zh-Hans" || locale === "zh-Hant" || locale === "ja" ? '"Noto Serif SC", "Songti SC", Georgia, serif' : font;
  const rand = seeded(`flash|${item.slug}`);
  const icon = await loadLogo();
  const bg = ctx.createLinearGradient(0, 0, PW * 0.3, PH);
  bg.addColorStop(0, "#0d0f14"); bg.addColorStop(0.55, "#16161a"); bg.addColorStop(1, "#231b10");
  ctx.fillStyle = bg; ctx.fillRect(0, 0, PW, PH);
  const glow = ctx.createRadialGradient(PW * 0.78, 300, 20, PW * 0.78, 300, 760); glow.addColorStop(0, "rgba(232,196,128,.22)"); glow.addColorStop(1, "rgba(232,196,128,0)");
  ctx.fillStyle = glow; ctx.fillRect(0, 0, PW, PH);
  sparkles(ctx, PW, PH * 0.6, 70, "#f0d79a", rand);
  const foil = goldFoil(ctx, 0, 0, PW, PH);
  ctx.globalAlpha = 0.5; enso(ctx, PW - 210, 250, 150, foil, rand, 12); ctx.globalAlpha = 1;
  ctx.globalAlpha = 0.28; cloud(ctx, 30, 1270, 1.1, foil); cloud(ctx, PW - 30, 1200, 0.9, foil, true); ctx.globalAlpha = 1;
  mountains(ctx, PW, 1430, "#0b0b0d", rand, 3);
  // header: LIVE dot, brand, category and date
  ctx.textAlign = "left";
  ctx.fillStyle = "#e2483d"; ctx.beginPath(); ctx.arc(104, 152, 13, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = "rgba(226,72,61,.25)"; ctx.beginPath(); ctx.arc(104, 152, 26, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = foil; ctx.font = `700 46px ${serif}`; ctx.fillText(flashText.name[locale], 146, 168);
  ctx.fillStyle = "rgba(240,226,196,.72)"; ctx.font = `400 30px ${font}`; ctx.fillText(flashText.posterTitle[locale], 92, 230);
  const date = new Date(item.publishedAt).toLocaleDateString(locale, { year: "numeric", month: "long", day: "numeric" });
  ctx.fillStyle = CATEGORY_DOT[item.category]; ctx.beginPath(); ctx.roundRect(92, 290, 16, 52, 4); ctx.fill();
  ctx.fillStyle = "#f3e9d2"; ctx.font = `600 34px ${font}`; ctx.fillText(`${flashText[item.category][locale]}  ·  ${date}`, 128, 328);
  // headline
  ctx.fillStyle = "#fbf3e2"; ctx.font = `700 76px ${serif}`;
  let y = 470;
  for (const line of wrap(ctx, item.text.title, PW - 184, locale, 4)) { ctx.fillText(line, 92, y); y += 96; }
  ctx.strokeStyle = foil; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(92, y - 30); ctx.lineTo(300, y - 30); ctx.stroke();
  // reading
  ctx.fillStyle = "rgba(244,236,220,.9)"; ctx.font = `400 40px ${font}`;
  y += 40;
  for (const line of wrap(ctx, item.text.body, PW - 184, locale, 8)) { ctx.fillText(line, 92, y); y += 60; }
  // classic line in a gold-edged card
  if (item.text.quote) {
    ctx.font = `600 42px ${serif}`;
    const lines = wrap(ctx, item.text.quote, PW - 330, locale, 3);
    const boxH = 150 + lines.length * 56;
    const top = Math.min(y + 30, 1420 - boxH);
    ctx.save(); ctx.fillStyle = "rgba(255,248,232,.06)"; ctx.beginPath(); ctx.roundRect(72, top, PW - 144, boxH, 24); ctx.fill(); ctx.restore();
    ctx.strokeStyle = foil; ctx.lineWidth = 2; ctx.beginPath(); ctx.roundRect(72, top, PW - 144, boxH, 24); ctx.stroke();
    ctx.fillStyle = foil; ctx.font = `700 110px Georgia, serif`; ctx.fillText("“", 96, top + 100);
    ctx.fillStyle = "#f6e7c4"; ctx.font = `600 42px ${serif}`;
    let qy = top + 92;
    for (const line of lines) { ctx.fillText(line, 190, qy); qy += 56; }
    if (item.text.quoteSource) { ctx.textAlign = "right"; ctx.fillStyle = "rgba(240,215,154,.85)"; ctx.font = `400 30px ${font}`; ctx.fillText(`— ${item.text.quoteSource}`, PW - 110, top + boxH - 28); ctx.textAlign = "left"; }
  }
  drawFooter(ctx, { locale, link, ink: "#1f1b16", soft: "#6f665a", accent: "#94652f", icon, panel: "rgba(251,246,234,.96)", scan: flashText.scan[locale] });
}

// --------------------------------------------------------------------------- share sheet
const NETWORKS: Array<{ key: string; label: string; href: (url: string, title: string) => string; color: string }> = [
  { key: "x", label: "X", color: "#000", href: (url, title) => `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}` },
  { key: "facebook", label: "Facebook", color: "#1877f2", href: (url) => `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}` },
  { key: "line", label: "LINE", color: "#06c755", href: (url, title) => `https://social-plugins.line.me/lineit/share?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}` },
  { key: "whatsapp", label: "WhatsApp", color: "#25d366", href: (url, title) => `https://wa.me/?text=${encodeURIComponent(`${title} ${url}`)}` },
  { key: "telegram", label: "Telegram", color: "#229ed9", href: (url, title) => `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}` },
  { key: "weibo", label: "微博", color: "#e6162d", href: (url, title) => `https://service.weibo.com/share/share.php?url=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}` },
];

// Platform icons: X, Telegram, WhatsApp and LINE use the icons the site already shows in its footer. For WeChat,
// Weibo and Facebook put the platform's official icon file (from its brand-resources page) at
// public/share-icons/<key>.svg — it is picked up automatically; until then a plain letter badge is shown.
const SITE_ICONS: Record<string, string> = { x: "X", telegram: "Telegram", whatsapp: "WhatsApp", line: "LINE" };
function NetworkIcon({ name, letter }: { name: string; letter: string }) {
  const [missing, setMissing] = useState(false);
  if (SITE_ICONS[name]) return <ContactIcon label={SITE_ICONS[name]} />;
  // eslint-disable-next-line @next/next/no-img-element
  if (!missing) return <img src={`/share-icons/${name}.svg`} alt="" onError={() => setMissing(true)} />;
  return <>{letter}</>;
}

function QrBox({ link }: { link: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current; if (!canvas) return;
    canvas.width = canvas.height = 220;
    const ctx = canvas.getContext("2d"); if (!ctx) return;
    ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, 220, 220);
    drawQr(ctx, link, 16, 16, 188, "#1b1611");
  }, [link]);
  return <canvas ref={ref} className="flash-qr" aria-label="QR" />;
}

function ShareSheet({ locale, item, onClose, onPoster }: { locale: Locale; item: FlashItem; onClose: () => void; onPoster: () => void }) {
  const t = flashText;
  const [url, setUrl] = useState(flashUrl(locale, item.slug));
  const [copied, setCopied] = useState(false);
  const [wechat, setWechat] = useState(false);
  useEffect(() => { let alive = true; void invitedUrl(flashPath(locale, item.slug), "flash-card").then((value) => { if (alive) setUrl(value); }); return () => { alive = false; }; }, [locale, item.slug]);
  useEffect(() => { const key = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); }; window.addEventListener("keydown", key); return () => window.removeEventListener("keydown", key); }, [onClose]);
  const counted = (method: string) => { track("share", { method, tool: "flash" }); countShare("flash-card", "shared"); void fetch(`/api/flash/item/${item.slug}/share`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ kind: "share" }) }).catch(() => undefined); };
  const system = async () => { try { await navigator.share({ title: item.text.title, text: item.text.summary, url }); counted("native"); } catch { /* cancelled */ } };
  const copy = async () => { try { await navigator.clipboard.writeText(`${item.text.title}\n${url}`); setCopied(true); counted("copy"); setTimeout(() => setCopied(false), 1800); } catch { /* blocked */ } };
  return <div className="flash-share-backdrop" role="presentation" onClick={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <div className="flash-share" role="dialog" aria-modal="true" aria-label={t.shareTitle[locale]}>
      <header><b>{t.shareTitle[locale]}</b><button type="button" className="flash-x" onClick={onClose} aria-label={t.close[locale]}>✕</button></header>
      <p className="flash-share-title">{item.text.title}</p>
      <div className="flash-share-grid">
        {typeof navigator !== "undefined" && "share" in navigator && <button type="button" onClick={() => void system()}><i style={{ background: "#d9b876", color: "#1b1611" }}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v12M7 8l5-5 5 5M5 13v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg></i><span>{t.system[locale]}</span></button>}
        <button type="button" onClick={() => setWechat((value) => !value)} aria-expanded={wechat}><i style={{ background: "#07c160" }}><NetworkIcon name="wechat" letter="微" /></i><span>{t.wechat[locale]}</span></button>
        <button type="button" onClick={() => { onPoster(); }}><i style={{ background: "linear-gradient(135deg, #e3c27c, #a87a36)" }}><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="3" width="16" height="18" rx="2.5" fill="none" stroke="currentColor" strokeWidth="1.8" /><circle cx="9" cy="9" r="1.8" fill="currentColor" /><path d="m5 18 5-5 3 3 2-2 4 4" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" /></svg></i><span>{t.poster[locale]}</span></button>
        {NETWORKS.map((network) => <a key={network.key} href={network.href(url, item.text.title)} target="_blank" rel="noopener noreferrer" onClick={() => counted(network.key)}><i style={{ background: network.color }}><NetworkIcon name={network.key} letter={network.label.slice(0, 1)} /></i><span>{network.label}</span></a>)}
        <button type="button" onClick={() => void copy()}><i style={{ background: "#3a3f48" }}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></svg></i><span>{copied ? t.copied[locale] : t.copy[locale]}</span></button>
      </div>
      {wechat && <div className="flash-wechat"><QrBox link={url} /><p>{t.wechatTip[locale]}</p></div>}
    </div>
  </div>;
}

/** Share + poster controls for one item (sheet, poster preview), used on cards, the widget and the detail page. */
function useShareTools(locale: Locale) {
  const poster = usePoster();
  const [sharing, setSharing] = useState<FlashItem | null>(null);
  const makePoster = useCallback(async (item: FlashItem) => {
    const link = await invitedUrl(flashPath(locale, item.slug), "flash-card");
    await poster.make((canvas) => drawFlashPoster(canvas, { locale, item, link }), "flash-card");
    void fetch(`/api/flash/item/${item.slug}/share`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ kind: "poster" }) }).catch(() => undefined);
  }, [locale, poster]);
  const ui = <>
    {sharing && <ShareSheet locale={locale} item={sharing} onClose={() => setSharing(null)} onPoster={() => { const item = sharing; setSharing(null); void makePoster(item); }} />}
    {poster.image && <PosterPreview locale={locale} image={poster.image} onClose={poster.clear} name="xuannova-flash.png" source="flash-card" />}
  </>;
  return { share: setSharing, makePoster, busy: poster.busy, ui };
}

// --------------------------------------------------------------------------- news ticker under the header
// A slim band right under the site header (in the page flow, so it never covers anything): LIVE dot, the newest
// headlines rolling up one at a time every 5 s, and Read / Poster / All. Shown on the everyday pages, not inside
// the chart and reading tools.
const TICKER_ROUTES: AppRoute[] = ["home", "almanac", "daily", "library", "courses", "guide", "toolkit"];

export function FlashTicker({ locale, route }: { locale: Locale; route: AppRoute }) {
  const visible = TICKER_ROUTES.includes(route);
  const feed = useFlashFeed(locale, visible);
  const items = feed.items.slice(0, 10);
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const tools = useShareTools(locale);
  useEffect(() => {
    if (!visible || paused || items.length < 2) return;
    const timer = window.setInterval(() => setIndex((value) => (value + 1) % items.length), 5000);
    return () => window.clearInterval(timer);
  }, [visible, paused, items.length]);
  useEffect(() => { if (index >= items.length) setIndex(0); }, [index, items.length]);
  if (!visible || !items.length) return tools.ui;
  const t = flashText;
  const current = items[Math.min(index, items.length - 1)];
  return <>
    <div className="flash-ticker" role="region" aria-label={t.name[locale]} onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)} onFocus={() => setPaused(true)} onBlur={() => setPaused(false)}>
      <a className="flash-ticker-label" href={flashPath(locale)} onClick={(event) => { event.preventDefault(); openFlash(locale); }}>
        <span className="flash-live"><i aria-hidden="true" />{t.live[locale]}</span><b>{t.name[locale]}</b>
      </a>
      <div className="flash-ticker-window" aria-live="polite">
        <div className="flash-ticker-track" style={{ transform: `translateY(-${(index * 100) / items.length}%)` }}>
          {items.map((item, position) => <a key={item.slug} className="flash-ticker-line" href={flashPath(locale, item.slug)} tabIndex={position === index ? 0 : -1} aria-hidden={position === index ? undefined : true} onClick={(event) => { event.preventDefault(); openFlash(locale, item.slug); }}>
            <i style={{ background: CATEGORY_DOT[item.category] }} aria-hidden="true" /><em>{t[item.category][locale]}</em><strong>{item.text.title}</strong><time dateTime={item.publishedAt} suppressHydrationWarning>{timeAgo(item.publishedAt, locale)}</time>
          </a>)}
        </div>
      </div>
      <div className="flash-ticker-actions">
        <button type="button" className="flash-read" onClick={() => openFlash(locale, current.slug)}>{t.readMore[locale]}</button>
        <button type="button" className="flash-poster" onClick={() => void tools.makePoster(current)} disabled={tools.busy}>{t.poster[locale]}</button>
        <button type="button" className="flash-share-icon" onClick={() => tools.share(current)} aria-label={t.share[locale]}>↗</button>
      </div>
    </div>
    {tools.ui}
  </>;
}

// --------------------------------------------------------------------------- home strip
export function HomeFlashStrip({ locale }: { locale: Locale }) {
  const feed = useFlashFeed(locale);
  const t = flashText;
  if (!feed.items.length) return null;
  return <section className="home-flash" aria-labelledby="home-flash-title">
    <header>
      <p><span className="flash-live"><i aria-hidden="true" />{t.live[locale]}</span> {t.eyebrow[locale]}</p>
      <h2 id="home-flash-title">{t.name[locale]}</h2>
      <a href={flashPath(locale)} onClick={(event) => { event.preventDefault(); openFlash(locale); }}>{t.all[locale]} →</a>
    </header>
    <div className="home-flash-grid">
      {feed.items.slice(0, 3).map((item) => <a className="home-flash-card" key={item.slug} href={flashPath(locale, item.slug)} onClick={(event) => { event.preventDefault(); openFlash(locale, item.slug); }}>
        <span className="flash-widget-meta"><CategoryTag category={item.category} locale={locale} /><time dateTime={item.publishedAt} suppressHydrationWarning>{timeAgo(item.publishedAt, locale)}</time></span>
        <strong>{item.text.title}</strong>
        <small>{item.text.summary}</small>
      </a>)}
    </div>
  </section>;
}

// --------------------------------------------------------------------------- timeline + detail
function currentSlug() {
  if (typeof window === "undefined") return null;
  const parts = window.location.pathname.split("/").filter(Boolean);
  const at = parts.indexOf("flash");
  const slug = at >= 0 ? parts[at + 1] : undefined;
  return slug && /^[a-z0-9][a-z0-9-]{3,90}$/.test(slug) ? slug : null;
}

export function FlashScreen({ locale, navigate, initial }: { locale: Locale; navigate: (route: AppRoute) => void; initial?: FlashItem | null }) {
  const [slug, setSlug] = useState<string | null>(initial?.slug ?? null);
  useEffect(() => {
    const read = () => setSlug(currentSlug());
    read();
    window.addEventListener("popstate", read);
    window.addEventListener("xn:navigate", read);
    return () => { window.removeEventListener("popstate", read); window.removeEventListener("xn:navigate", read); };
  }, []);
  return slug ? <FlashDetail locale={locale} slug={slug} navigate={navigate} initial={initial?.slug === slug ? initial : null} /> : <FlashTimeline locale={locale} navigate={navigate} />;
}

function CardFooter({ item, locale, navigate, tools }: { item: FlashItem; locale: Locale; navigate: (route: AppRoute) => void; tools: ReturnType<typeof useShareTools> }) {
  return <div className="flash-card-bar">
    <ReadBadge item={item} locale={locale} />
    <button type="button" className="flash-cta" onClick={() => navigate(item.cta as AppRoute)}>{ctaLabel(item.cta, locale)}</button>
    <span className="flash-card-tools">
      <button type="button" onClick={() => void tools.makePoster(item)} disabled={tools.busy} aria-label={flashText.poster[locale]} title={flashText.poster[locale]}>▣</button>
      <button type="button" onClick={() => tools.share(item)} aria-label={flashText.share[locale]} title={flashText.share[locale]}>↗</button>
    </span>
  </div>;
}

function FlashTimeline({ locale, navigate }: { locale: Locale; navigate: (route: AppRoute) => void }) {
  const feed = useFlashFeed(locale);
  const t = flashText;
  const tools = useShareTools(locale);
  const [filter, setFilter] = useState<FlashCategory | "all">("all");
  const [older, setOlder] = useState<FlashItem[]>([]);
  const [next, setNext] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  useEffect(() => { setOlder([]); setNext(null); }, [locale, filter]);
  useEffect(() => { if (typeof document !== "undefined") document.title = `${t.name[locale]} · Xuannova`; }, [locale, t]);
  const [filtered, setFiltered] = useState<{ items: FlashItem[]; next: string | null } | null>(null);
  useEffect(() => {
    if (filter === "all") { setFiltered(null); return; }
    let alive = true;
    void fetch(`/api/flash?locale=${encodeURIComponent(locale)}&limit=20&category=${filter}`).then((response) => response.json()).then((data: { items?: FlashItem[]; next?: string | null }) => { if (alive) setFiltered({ items: data.items ?? [], next: data.next ?? null }); }).catch(() => undefined);
    return () => { alive = false; };
  }, [filter, locale, feed.version]);
  const base = filter === "all" ? feed.items : filtered?.items ?? [];
  const items = useMemo(() => { const seen = new Set<string>(); return [...base, ...older].filter((item) => (seen.has(item.slug) ? false : (seen.add(item.slug), true))); }, [base, older]);
  const cursor = next ?? (filter === "all" ? feed.next : filtered?.next ?? null);
  const more = async () => {
    if (!cursor) return;
    setLoading(true);
    try {
      const response = await fetch(`/api/flash?locale=${encodeURIComponent(locale)}&limit=12&before=${encodeURIComponent(cursor)}${filter === "all" ? "" : `&category=${filter}`}`);
      const data = await response.json() as { items?: FlashItem[]; next?: string | null };
      setOlder((list) => [...list, ...(data.items ?? [])]); setNext(data.next ?? null);
      if (!data.next) setNext("");
    } finally { setLoading(false); }
  };
  let lastDay = "";
  return <main className="flash-page">
    <header className="flash-hero">
      <p><span className="flash-live"><i aria-hidden="true" />{t.live[locale]}</span> {t.eyebrow[locale]}</p>
      <h1>{t.name[locale]}</h1>
      <span>{t.lead[locale]}</span>
      <nav className="flash-filters" aria-label={t.name[locale]}>
        {(["all", "focus", "energy", "wisdom"] as const).map((key) => <button type="button" key={key} className={filter === key ? "active" : ""} aria-pressed={filter === key} onClick={() => setFilter(key)}>{key !== "all" && <i style={{ background: CATEGORY_DOT[key] }} aria-hidden="true" />}{key === "all" ? t.filterAll[locale] : t[key][locale]}</button>)}
      </nav>
    </header>
    {!feed.loaded && <div className="lazy-screen-loading" aria-busy="true"><i /></div>}
    {feed.loaded && !items.length && <p className="flash-empty">{t.empty[locale]}</p>}
    <ol className="flash-timeline">
      {items.map((item) => {
        const day = dayKey(item.publishedAt, locale);
        const showDay = day !== lastDay; lastDay = day;
        return <li key={item.slug} className={`flash-entry flash-${item.category}`}>
          {showDay && <h2 className="flash-day" suppressHydrationWarning>{day}</h2>}
          <div className="flash-axis" aria-hidden="true"><i style={{ borderColor: CATEGORY_DOT[item.category] }} /></div>
          <article className="flash-card">
            <div className="flash-widget-meta"><CategoryTag category={item.category} locale={locale} /><Badges item={item} locale={locale} /><time dateTime={item.publishedAt} suppressHydrationWarning>{new Date(item.publishedAt).toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" })}</time></div>
            <h3><a href={flashPath(locale, item.slug)} onClick={(event) => { event.preventDefault(); openFlash(locale, item.slug); }}>{item.text.title}</a></h3>
            <p>{item.text.body}</p>
            {item.text.quote && <blockquote>{item.text.quote}{item.text.quoteSource && <cite>— {item.text.quoteSource}</cite>}</blockquote>}
            <CardFooter item={item} locale={locale} navigate={navigate} tools={tools} />
          </article>
        </li>;
      })}
    </ol>
    {cursor ? <button type="button" className="secondary-action flash-more" onClick={() => void more()} disabled={loading}>{t.loadMore[locale]}</button> : null}
    {tools.ui}
  </main>;
}

function FlashDetail({ locale, slug, navigate, initial }: { locale: Locale; slug: string; navigate: (route: AppRoute) => void; initial: FlashItem | null }) {
  const t = flashText;
  const [item, setItem] = useState<FlashItem | null>(initial);
  const [missing, setMissing] = useState(false);
  const feed = useFlashFeed(locale);
  const tools = useShareTools(locale);
  useEffect(() => {
    let alive = true;
    setMissing(false);
    if (!initial || initial.slug !== slug || initial.locale !== locale) {
      void fetch(`/api/flash/item/${slug}?locale=${encodeURIComponent(locale)}`).then(async (response) => {
        if (!alive) return;
        if (!response.ok) { setMissing(true); return; }
        setItem(((await response.json()) as { item: FlashItem }).item);
      }).catch(() => { if (alive) setMissing(true); });
    }
    return () => { alive = false; };
  }, [slug, locale, initial]);
  // count one real view per device per day
  useEffect(() => {
    void fetch(`/api/flash/item/${slug}/view`, { method: "POST", headers: { "content-type": "application/json" }, body: "{}", credentials: "same-origin" })
      .catch(() => undefined);
  }, [slug]);
  useEffect(() => { if (item) document.title = `${item.text.title} · ${t.name[locale]}`; }, [item, locale, t]);
  if (missing) return <main className="flash-page"><p className="flash-empty">{t.gone[locale]}</p><button type="button" className="secondary-action" onClick={() => openFlash(locale)}>← {t.back[locale]}</button></main>;
  if (!item) return <main className="flash-page"><div className="lazy-screen-loading" aria-busy="true"><i /></div></main>;
  const related = feed.items.filter((other) => other.slug !== item.slug).slice(0, 4);
  return <main className="flash-page flash-detail">
    <a className="flash-back" href={flashPath(locale)} onClick={(event) => { event.preventDefault(); openFlash(locale); }}>← {t.back[locale]}</a>
    <article className="flash-article">
      <div className="flash-widget-meta"><CategoryTag category={item.category} locale={locale} /><Badges item={item} locale={locale} /><time dateTime={item.publishedAt} suppressHydrationWarning>{new Date(item.publishedAt).toLocaleString(locale, { year: "numeric", month: "long", day: "numeric", hour: "2-digit", minute: "2-digit" })}</time></div>
      <h1>{item.text.title}</h1>
      <p className="flash-lead">{item.text.summary}</p>
      {item.text.body.split(/\n+/).map((paragraph, index) => <p key={index}>{paragraph}</p>)}
      {item.text.quote && <blockquote className="flash-quote"><span aria-hidden="true">“</span>{item.text.quote}{item.text.quoteSource && <cite>— {item.text.quoteSource}</cite>}</blockquote>}
      {item.sourceUrl && <p className="flash-source">{t.source[locale]}：<a href={item.sourceUrl} target="_blank" rel="nofollow noopener noreferrer">{item.sourceName ?? new URL(item.sourceUrl).hostname} ↗</a></p>}
      <CardFooter item={item} locale={locale} navigate={navigate} tools={tools} />
      <div className="flash-share-row">
        <button type="button" className="primary-action" onClick={() => tools.share(item)}>{t.share[locale]} <b>↗</b></button>
        <button type="button" className="secondary-action" onClick={() => void tools.makePoster(item)} disabled={tools.busy}>{t.poster[locale]}</button>
      </div>
    </article>
    {related.length > 0 && <section className="flash-related">
      <h2>{t.related[locale]}</h2>
      <div className="home-flash-grid">{related.map((other) => <a className="home-flash-card" key={other.slug} href={flashPath(locale, other.slug)} onClick={(event) => { event.preventDefault(); openFlash(locale, other.slug); }}>
        <span className="flash-widget-meta"><CategoryTag category={other.category} locale={locale} /><time dateTime={other.publishedAt} suppressHydrationWarning>{timeAgo(other.publishedAt, locale)}</time></span>
        <strong>{other.text.title}</strong><small>{other.text.summary}</small>
      </a>)}</div>
    </section>}
    {tools.ui}
  </main>;
}
