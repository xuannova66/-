"use client";

import { useSyncExternalStore } from "react";

const errorCopy = {
  en: { title: "This page needs a moment", body: "Your information has not been changed. Try loading this page again.", retry: "Try again" },
  "zh-Hans": { title: "页面暂时遇到问题", body: "你的信息没有被更改。可以尝试重新加载此页面。", retry: "重新加载" },
  "zh-Hant": { title: "頁面暫時遇到問題", body: "你的資料沒有被更改。可以嘗試重新載入此頁面。", retry: "重新載入" },
  ja: { title: "ページを読み込めませんでした", body: "入力内容は変更されていません。もう一度読み込んでください。", retry: "再試行" },
  ko: { title: "페이지를 불러오지 못했습니다", body: "입력 정보는 변경되지 않았습니다. 다시 시도해 주세요.", retry: "다시 시도" },
  vi: { title: "Trang này đang gặp sự cố", body: "Thông tin của bạn chưa bị thay đổi. Hãy thử tải lại trang.", retry: "Thử lại" },
  th: { title: "หน้านี้ขัดข้องชั่วคราว", body: "ข้อมูลของคุณยังไม่เปลี่ยนแปลง ลองโหลดหน้านี้อีกครั้ง", retry: "ลองอีกครั้ง" },
} as const;

type ErrorLocale = keyof typeof errorCopy;

function detectLocale(): ErrorLocale {
  const language = typeof navigator === "undefined" ? "en" : navigator.language.toLowerCase();
  if (language.startsWith("zh-tw") || language.startsWith("zh-hk") || language.startsWith("zh-hant")) return "zh-Hant";
  if (language.startsWith("zh")) return "zh-Hans";
  if (language.startsWith("ja")) return "ja";
  if (language.startsWith("ko")) return "ko";
  if (language.startsWith("vi")) return "vi";
  if (language.startsWith("th")) return "th";
  return "en";
}

export default function Error({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  const locale = useSyncExternalStore(() => () => {}, detectLocale, () => "en" as ErrorLocale);

  const copy = errorCopy[locale];
  return (
    <main role="alert" style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 24, background: "#111516", color: "#f0ece0", textAlign: "center" }}>
      <section style={{ width: "min(100%, 560px)", border: "1px solid rgba(235,236,222,.24)", padding: "clamp(24px, 6vw, 48px)" }}>
        <p style={{ color: "#e2ce98", letterSpacing: ".12em" }}>Xuannova</p>
        <h1 style={{ fontSize: "clamp(24px, 6vw, 34px)", fontWeight: 500 }}>{copy.title}</h1>
        <p style={{ color: "#b6b9ad", fontSize: 16, lineHeight: 1.7 }}>{copy.body}</p>
        <button onClick={() => reset()} style={{ minHeight: 48, marginTop: 12, border: 0, padding: "0 24px", background: "#bea66c", color: "#171917", font: "inherit", fontWeight: 600 }}>
          {copy.retry}
        </button>
      </section>
    </main>
  );
}
