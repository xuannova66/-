import { createStudyResult, type StudyInput, type StudyResult } from "./study-engine";
import { branchTenGod, calculateBaziReference, dayMasterStrength } from "./bazi-reference";
import { Solar } from "lunar-javascript";
import {
  branchAt as branchAtIndex, branchIndex as branchIdx, branchPairRelations, ELEMENT_EN, jiaziIndex as jiaziIdx, lifeStage, ratHourStem,
  seasonalState, STEM_COMBINE, stemAt as stemAtIndex, stemIndex as stemIdx, tenGod, type Element,
} from "./metaphysics/core";
import { annualCycle, branchRelationRows, branchRelationsByPillar, climateOf, monthCadence, naYinElementOf, pillarShenSha, seasonalStateOfStem } from "./metaphysics/bazi-extra";
import { ziweiMonth, ziweiPlacement } from "./metaphysics/ziwei";
import { ascendant, aspectBetween, eclipticLongitudes, qizhengChart, ZODIAC, zodiacOf } from "./metaphysics/qizheng";
import { PALACE_BRANCHES, qimenChart } from "./metaphysics/qimen";
import { castLiuyao, hexagramName, trigramOf } from "./metaphysics/liuyao";
import { DIRECTIONS, fengshuiChart, type Direction } from "./metaphysics/fengshui";
import { liurenChart } from "./metaphysics/liuren";
import { drawTarot } from "./metaphysics/tarot";
import { matchDreamSymbols } from "./metaphysics/dream";
import { selectDays, type ZeriExclusion } from "./metaphysics/zeri";
import type { ActivityKey } from "./almanac";
import { heLuo, jinKouJue, taiYiYear, tieBan, TAIYI_PALACE_DIRECTION, TAIYI_PALACE_NAME } from "./metaphysics/extra-methods";

export type BoardKind = "pillars" | "twelve-palace" | "nine-palace" | "hexagram" | "six-ren" | "spread" | "comparison";
export type BoardTone = "gold" | "vermillion" | "violet" | "jade" | "quiet";

export type BoardItem = {
  label: string;
  value: string;
  tone?: BoardTone;
};

export type BoardCell = {
  id: string;
  title: string;
  subtitle?: string;
  items: BoardItem[];
  tone?: BoardTone;
  active?: boolean;
};

export type BoardSection = {
  id: string;
  title: string;
  lead: string;
  items: BoardItem[];
};

export type CompleteChart = {
  tool: string;
  calendar: StudyResult["calendar"];
  pillars: string[];
  board: { kind: BoardKind; label: string; cells: BoardCell[] };
  sections: BoardSection[];
  sourceFacts: string[];
  inputSummary: { focus: string; place: string; version: number; name?: string; companionName?: string };
};

export type InterpretationRequest = {
  tool: string;
  locale: string;
  question: string;
  chart: CompleteChart;
  disclaimer: string;
};

export type InterpretationResponse = {
  title: string;
  summary: string;
  conclusion?: string;
  keyPoints?: string[];
  /** Free part only: one sentence on what the locked sections cover. */
  teaser?: string;
  sections: Array<{ title: string; text: string }>;
  followUps: string[];
};

// ---------------------------------------------------------------------------
// Every board below is computed from calendar rules. No seeded or placeholder values:
// the same input always produces the same chart.
// ---------------------------------------------------------------------------

const stemElements: Record<string, string> = { 甲: "Wood", 乙: "Wood", 丙: "Fire", 丁: "Fire", 戊: "Earth", 己: "Earth", 庚: "Metal", 辛: "Metal", 壬: "Water", 癸: "Water" };
const branchElements: Record<string, string> = { 子: "Water", 丑: "Earth", 寅: "Wood", 卯: "Wood", 辰: "Earth", 巳: "Fire", 午: "Fire", 未: "Earth", 申: "Metal", 酉: "Metal", 戌: "Earth", 亥: "Water" };
const hiddenStemsTable: Record<string, string[]> = {
  子: ["癸"], 丑: ["己", "癸", "辛"], 寅: ["甲", "丙", "戊"], 卯: ["乙"], 辰: ["戊", "乙", "癸"], 巳: ["丙", "庚", "戊"],
  午: ["丁", "己"], 未: ["己", "丁", "乙"], 申: ["庚", "壬", "戊"], 酉: ["辛"], 戌: ["戊", "辛", "丁"], 亥: ["壬", "甲"],
};
const pillarRoles = ["Year pillar", "Month pillar", "Day pillar", "Hour pillar"];
const elementNames = ["Wood", "Fire", "Earth", "Metal", "Water"] as const;
const triadGroups = ["申子辰", "亥卯未", "寅午戌", "巳酉丑"];
const palaceDirections = ["Southeast", "South", "Southwest", "East", "Center", "West", "Northeast", "North", "Northwest"];
const palaceNumbers = [4, 9, 2, 3, 5, 7, 8, 1, 6];
const palaceElements: Record<number, string> = { 1: "Water", 2: "Earth", 3: "Wood", 4: "Wood", 5: "Earth", 6: "Metal", 7: "Metal", 8: "Earth", 9: "Fire" };
const yinYangLabel = (yang: boolean) => (yang ? "Yang" : "Yin");
const currentYear = () => new Date().getFullYear();

function elementLine(result: StudyResult) {
  return result.calendar.elements.map((item) => `${item.name} ${item.count}`).join(" · ");
}

function calculationBasis(result: StudyResult): BoardSection {
  if (result.astro.manualPillars) {
    return {
      id: "calculation-basis",
      title: "Calendar context",
      lead: "Four-pillar moment retained as the chart anchor",
      items: [
        { label: "Input mode", value: "Manual four pillars" },
        { label: "Four pillars", value: result.pillars.join(" ") },
      ],
    };
  }
  const civilTime = `${result.calendar.civilDate} ${result.calendar.civilTime}`;
  const trueSolarTime = result.calendar.trueSolarDate && result.calendar.trueSolarTime
    ? `${result.calendar.trueSolarDate} ${result.calendar.trueSolarTime}`
    : civilTime;
  return {
    id: "calculation-basis",
    title: "Calendar context",
    lead: "Four-pillar moment retained as the chart anchor",
    items: [
      { label: "Solar", value: result.calendar.solar },
      { label: "Lunar", value: result.calendar.lunar },
      { label: "Civil time", value: civilTime },
      { label: "True solar time", value: trueSolarTime },
      { label: "Chart time", value: result.calendar.timeBasis === "true-solar" ? trueSolarTime : civilTime },
      { label: "Solar term", value: result.astro.prevJieQi },
    ],
  };
}

// ---------------------------------------------------------------- BaZi
function baziBoard(result: StudyResult, gender: "yin" | "yang", detailed = false) {
  const labels = ["Year", "Month", "Day", "Hour"];
  const dayStem = result.pillars[2]?.charAt(0) ?? "—";
  const monthBranch = result.pillars[1]?.charAt(1) ?? "—";
  const derived = calculateBaziReference(result.pillars, gender);
  const shensha = pillarShenSha(result.pillars);
  const relationsByPillar = branchRelationsByPillar(result.pillars);
  const climate = climateOf(monthBranch);
  const luck = result.astro.luck;
  const cells = result.pillars.map((pillar, index) => {
    const stem = pillar.charAt(0);
    const branch = pillar.charAt(1);
    const hidden = derived.hiddenStems[index] ?? hiddenStemsTable[branch] ?? [stem];
    return {
      id: `pillar-${index}`,
      title: `${labels[index]} pillar`,
      subtitle: pillar,
      tone: index === 2 ? "gold" : "quiet" as BoardTone,
      active: index === 2,
      items: [
        { label: "Stem", value: stem, tone: "vermillion" as BoardTone },
        { label: "Stem element", value: stemElements[stem] ?? "—" },
        { label: "Branch", value: branch, tone: "jade" as BoardTone },
        { label: "Branch element", value: branchElements[branch] ?? "—" },
        { label: "Ten God", value: derived.tenGods[index] },
        { label: "Hidden stems", value: hidden.join(" · ") },
        { label: "Life stage", value: derived.lifeStages[index] },
        { label: "NaYin", value: derived.naYin[index] },
        { label: "Pillar role", value: pillarRoles[index] },
        { label: "Day-stem relation", value: hidden.map((h) => (index === 2 && h === stem ? "日主" : tenGod(dayStem, h))).join(" · ") },
        { label: "Seasonal status", value: seasonalStateOfStem(stem, monthBranch) },
        { label: "Auxiliary star", value: shensha[index].other.join(" · ") || "—" },
        { label: "Pillar shen-sha", value: shensha[index].noble.join(" · ") || "—" },
        { label: "Branch relation", value: relationsByPillar[index] },
      ],
    };
  });
  const strengthRows = elementNames.map((element) => {
    const visible = result.pillars.reduce((sum, pillar) => sum + (stemElements[pillar.charAt(0)] === element ? 1 : 0) + (branchElements[pillar.charAt(1)] === element ? 1 : 0), 0);
    const hidden = result.pillars.reduce((sum, pillar) => sum + (hiddenStemsTable[pillar.charAt(1)] ?? []).filter((h) => stemElements[h] === element).length, 0);
    return { label: element, value: `${visible + hidden} · ${visible}/${hidden}` };
  });
  const year = currentYear();
  const annual = annualCycle(dayStem, year, 12);
  const months = monthCadence(year, dayStem);
  const cycles = luck?.cycles.length ? luck.cycles.slice(0, 8) : derived.dayun.cycles.map((ganzhi) => ({ ganzhi, startAge: Number.NaN, startYear: Number.NaN }));
  const allShensha = shensha.flatMap((entry, index) => [...entry.noble, ...entry.other].map((name) => ({ label: cells[index].title, value: name })));
  const register = allShensha.length ? allShensha : [{ label: "Four pillars", value: "—" }];
  const lane = (index: number) => {
    const names = [...shensha[index].noble, ...shensha[index].other];
    return names.length ? names.map((name) => ({ label: cells[index].title, value: name })) : [{ label: cells[index].title, value: "—" }];
  };
  return {
    kind: "pillars" as const,
    label: "Four Pillars complete board",
    cells,
    sections: [
      { id: "pillar-matrix", title: "Four-pillar matrix", lead: "Stem, branch, root, role and seasonal reference in one dense study grid", items: cells.flatMap((cell) => [{ label: cell.title, value: cell.subtitle ?? "—" }, { label: `${cell.title} · Ten God`, value: cell.items[4].value }, { label: `${cell.title} · NaYin`, value: cell.items[7].value }]) },
      { id: "hidden-stems", title: "Hidden stems", lead: "Branch-root study layer", items: cells.map((cell) => ({ label: cell.title, value: `${cell.items[5].value} · ${cell.items[9].value}` })) },
      { id: "ten-gods", title: "Ten-God relationships", lead: "Local relationship map from the day pillar", items: cells.map((cell) => ({ label: cell.title, value: cell.items[4].value })) },
      { id: "life-stages", title: "Twelve Life Stages", lead: "Twelve-stage seasonal sequence", items: cells.map((cell) => ({ label: cell.title, value: cell.items[6].value })) },
      { id: "five-elements", title: "Five Elements", lead: "Visible stem/branch count", items: result.calendar.elements.map((item) => ({ label: item.name, value: String(item.count) })) },
      { id: "element-strength", title: "Element strength", lead: "Visible and hidden-root counts are held together for study", items: strengthRows },
      { id: "day-master", title: "Day-master context", lead: "The day stem and seasonal branch anchor this study layer", items: [{ label: "Day master", value: dayStem }, { label: "Season branch", value: monthBranch }, { label: "Climate note", value: climate }, { label: "Stem element", value: stemElements[dayStem] ?? "—" }, { label: "Seasonal status", value: seasonalStateOfStem(dayStem, monthBranch) }] },
      { id: "seasonal-command", title: "Seasonal command", lead: "Month command, climate reference and seasonal status", items: [{ label: "Month branch", value: monthBranch }, { label: "Branch element", value: branchElements[monthBranch] ?? "—" }, { label: "Climate note", value: climate }, ...cells.map((cell) => ({ label: cell.title, value: `${cell.items[0].value} · ${cell.items[10].value}` }))] },
      { id: "branch-relations", title: "Branch relationships", lead: "Four visible branches and their relation map", items: branchRelationRows(result.pillars) },
      { id: "relation-matrix", title: "Relation matrix", lead: "Pillar, day-stem and branch references read side by side", items: cells.map((cell) => ({ label: cell.title, value: `${cell.items[4].value} · ${cell.items[2].value} · ${cell.items[13].value}` })) },
      { id: "pillar-roles", title: "Pillar roles", lead: "Four visible positions held as one study sequence", items: cells.map((cell) => ({ label: cell.title, value: cell.items[8].value })) },
      { id: "luck-cycles", title: "Ten-year study cycles", lead: "Rhythm table for long-form self-observation", items: cycles.map((cycle, index) => ({ label: `Cycle ${index + 1}`, value: Number.isFinite(cycle.startAge) ? `${cycle.ganzhi} · ${cycle.startAge}–${cycle.startAge + 9} · ${cycle.startYear}` : cycle.ganzhi })) },
      // BaZi deep reading only: each ten-year cycle with its Ten Gods (current cycle marked) and a day-master strength reference.
      ...(detailed ? (() => {
        const nowYear = new Date().getFullYear();
        const strength = dayMasterStrength(result.pillars);
        const deep = { id: "luck-cycles-detail", title: "Luck cycles in depth", lead: "Each ten-year cycle with the Ten Gods of its stem and branch; the current cycle is marked", items: cycles.map((cycle, index) => ({ label: `Cycle ${index + 1}`, value: [cycle.ganzhi, `${tenGod(dayStem, cycle.ganzhi.charAt(0))} / ${branchTenGod(dayStem, cycle.ganzhi.charAt(1))}`, ...(Number.isFinite(cycle.startAge) ? [`${cycle.startAge}–${cycle.startAge + 9}`, `${cycle.startYear}–${cycle.startYear + 9}`] : []), ...(Number.isFinite(cycle.startYear) && nowYear >= cycle.startYear && nowYear <= cycle.startYear + 9 ? ["Current"] : [])].join(" · ") })) };
        const power = strength ? { id: "day-master-strength", title: "Day-master strength", lead: "Supporting and draining forces counted from stems, hidden stems and the season; one common method, schools differ", items: [{ label: "Supporting forces", value: String(strength.support) }, { label: "Draining forces", value: String(strength.drain) }, { label: "Support share", value: `${strength.share}%` }, { label: "Season supports the day master", value: strength.seasonal ? "Yes" : "No" }, { label: "Strength reference", value: strength.verdict }] } : null;
        return power ? [deep, power] : [deep];
      })() : []),
      { id: "annual-cycle", title: "Annual study cycle", lead: "Twelve successive reference points", items: annual.map((entry) => ({ label: String(entry.year), value: `${entry.ganzhi} · ${entry.tenGod} · ${entry.stage}` })) },
      { id: "month-cadence", title: "Month cadence", lead: "Twelve monthly branch references around the seasonal command", items: months.map((entry) => ({ label: entry.term, value: `${entry.ganzhi} · ${entry.element} · ${entry.tenGod}` })) },
      { id: "auxiliary-stars", title: "Auxiliary stars", lead: "Supplementary stars arranged by pillar", items: cells.map((cell) => ({ label: cell.title, value: cell.items[11].value })) },
      { id: "shen-sha-register", title: "Shen-sha register", lead: "Twelve pillar shen-sha markers", items: [...register, ...Array.from({ length: Math.max(0, 12 - register.length) }, () => ({ label: "—", value: "—" }))].slice(0, Math.max(12, register.length)) },
      { id: "year-markers", title: "Year-pillar markers", lead: "Year pillar shen-sha reference lane", items: lane(0) },
      { id: "month-markers", title: "Month-pillar markers", lead: "Month pillar shen-sha reference lane", items: lane(1) },
      { id: "day-markers", title: "Day-pillar markers", lead: "Day pillar shen-sha reference lane", items: lane(2) },
      { id: "hour-markers", title: "Hour-pillar markers", lead: "Hour pillar shen-sha reference lane", items: lane(3) },
      { id: "start-luck", title: "Luck-cycle start", lead: "Timing reference for observing ten-year cycles", items: [{ label: "Orientation", value: derived.dayun.direction === "顺行" ? "Forward" : "Backward" }, { label: "Start age", value: luck ? `${luck.years}y ${luck.months}m ${luck.days}d` : "—" }, { label: "Start year", value: luck?.startYear ? String(luck.startYear) : "—" }, { label: "First cycle", value: cycles[0]?.ganzhi ?? "—" }, { label: "Month command", value: monthBranch }] },
      { id: "nayin-cross-reference", title: "NaYin cross-reference", lead: "Four-pillar tonal reference for patient comparison", items: cells.map((cell, index) => ({ label: cell.title, value: `${cell.items[7].value} · ${ELEMENT_EN[naYinElementOf(result.pillars[index]) as keyof typeof ELEMENT_EN] ?? "—"}` })) },
      { id: "seasonal-adjustment", title: "Seasonal adjustment", lead: "Month branch, climate note and five-element balance", items: [{ label: "Month branch", value: monthBranch }, { label: "Climate note", value: climate }, ...result.calendar.elements.map((item) => ({ label: item.name, value: `${item.count} · ${seasonalStateOfElement(item.name, monthBranch)}` }))] },
    ],
  };
}

function seasonalStateOfElement(english: string, monthBranch: string) {
  const zh = (Object.entries(ELEMENT_EN).find(([, en]) => en === english)?.[0] ?? "土") as Element;
  return seasonalState(zh, monthBranch);
}

// ---------------------------------------------------------------- Zi Wei
function ziweiBoard(result: StudyResult, gender: "yin" | "yang", input?: StudyInput) {
  const astro = result.astro;
  const placement = ziweiPlacement({ yearStem: astro.lunarYearStem, yearBranch: astro.lunarYearBranch, lunarMonth: ziweiMonth(astro.lunarMonth, astro.lunarDay, astro.leapMonth, input?.ziweiLeap), lunarDay: astro.lunarDay, hourBranch: astro.hourBranch, gender, currentYear: currentYear(), transformVariant: input?.ziweiTransform });
  // Cells follow the fixed perimeter order used by the board: 巳 午 未 申 酉 戌 亥 子 丑 寅 卯 辰.
  const ordered = Array.from({ length: 12 }, (_, i) => placement.palaces[(5 + i) % 12]);
  const keyOfBranch = (branch: string) => placement.palaces.find((palace) => palace.branch === branch)?.key ?? "—";
  const cells = ordered.map((palace) => {
    const opposite = placement.palaces.find((other) => other.branch === branchAtIndex(branchIdx(palace.branch) + 6))!;
    const triad = triadGroups.find((group) => group.includes(palace.branch)) ?? "—";
    const borrowed = palace.mainStarNames.length ? [] : opposite.mainStars;
    const marker = [palace.isLife ? "Life palace" : "", palace.isBody ? "Body palace" : ""].filter(Boolean).join(" · ") || "Palace reference";
    return {
      id: `palace-${palace.branch}`,
      title: palace.key,
      subtitle: `${palace.stem}${palace.branch}`,
      tone: palace.isLife ? "gold" as BoardTone : "quiet" as BoardTone,
      active: palace.isLife,
      items: [
        { label: "Core star", value: palace.mainStars.join(" · ") || (borrowed.length ? `${borrowed.join(" · ")} (借)` : "—") },
        { label: "Support star", value: palace.supportStars.join(" · ") || "—" },
        { label: "Transformation", value: palace.transforms.join(" · ") || "—" },
        { label: "Minor star", value: palace.minorStars.join(" · ") || "—" },
        { label: "Decade limit", value: palace.decade },
        { label: "Annual focus", value: palace.annual },
        { label: "Palace branch", value: palace.branch },
        { label: "Palace stem", value: palace.stem },
        { label: "Palace condition", value: palace.brightness.join(" · ") || "—" },
        { label: "Life-body marker", value: marker },
        { label: "Opposing palace", value: opposite.key },
        { label: "Three-harmony group", value: triad },
      ],
    };
  });
  const byKey = (key: string) => cells.find((cell) => cell.title === key)!;
  return {
    kind: "twelve-palace" as const,
    label: "Twelve-palace Zi Wei board",
    cells,
    sections: [
      { id: "core-stars", title: "Core stars", lead: "Palace placement", items: cells.map((cell) => ({ label: cell.title, value: cell.items[0].value })) },
      { id: "support-stars", title: "Support and minor stars", lead: "Support-star and minor-star placement", items: cells.map((cell) => ({ label: cell.title, value: `${cell.items[1].value} · ${cell.items[3].value}` })) },
      { id: "four-transformations", title: "Four Transformations", lead: "Lu · Quan · Ke · Ji study layer", items: placement.transforms.map((entry) => ({ label: astro.lunarYearStem, value: entry })) },
      { id: "decadal-limits", title: "Decadal limits", lead: "Twelve-palace local ten-year rhythm table", items: cells.map((cell) => ({ label: cell.title, value: cell.items[4].value })) },
      { id: "annual-limits", title: "Annual focus", lead: "An annual-reference layer", items: cells.map((cell) => ({ label: cell.title, value: cell.items[5].value })) },
      { id: "bureau-context", title: "Bureau context", lead: "Study framing", items: [{ label: "Bureau element", value: placement.bureauName }, { label: "Life palace", value: `${placement.lifeGanzhi}` }, { label: "Body palace", value: keyOfBranch(placement.bodyBranch) }, { label: "Orientation", value: placement.forward ? "Forward" : "Backward" }, { label: "Lunar birth", value: `${astro.lunarYearStem}${astro.lunarYearBranch} · ${astro.leapMonth ? "闰" : ""}${astro.lunarMonth} / ${astro.lunarDay} · ${astro.hourBranch}` }] },
      { id: "star-dispositions", title: "Star dispositions", lead: "Core, support and minor stars held in one comparative layer", items: cells.map((cell) => ({ label: cell.title, value: `${cell.items[0].value} · ${cell.items[1].value} · ${cell.items[3].value}` })) },
      { id: "palace-axis", title: "Palace axis", lead: "Opposing and supporting sector relationships for study", items: ["Life", "Siblings", "Partnership", "Children", "Wealth", "Health"].map((key) => ({ label: key, value: `${byKey(key).items[10].value} · ${byKey(byKey(key).items[10].value).items[0].value}` })) },
      { id: "palace-stems", title: "Palace stems", lead: "Twelve palace stem references", items: cells.map((cell) => ({ label: cell.title, value: cell.items[7].value })) },
      { id: "palace-branches", title: "Palace branches", lead: "Twelve palace branch references", items: cells.map((cell) => ({ label: cell.title, value: cell.items[6].value })) },
      { id: "life-body-axis", title: "Life and body axis", lead: "Life palace and body palace held as two observation anchors", items: [{ label: "Life palace", value: `${byKey("Life").subtitle} · ${byKey("Life").items[0].value}` }, { label: "Body palace", value: `${keyOfBranch(placement.bodyBranch)} · ${placement.bodyBranch}` }] },
      { id: "three-harmony", title: "Three harmony groups", lead: "Four public three-harmony group references across the twelve palaces", items: triadGroups.map((group) => ({ label: group, value: placement.palaces.filter((palace) => group.includes(palace.branch)).map((palace) => palace.key).join(" · ") })) },
      { id: "opposing-axes", title: "Opposing axes", lead: "Six paired palace axes for comparative observation", items: ["Life", "Siblings", "Partnership", "Children", "Wealth", "Health"].map((key) => ({ label: key, value: byKey(key).items[10].value })) },
      { id: "palace-conditions", title: "Palace conditions", lead: "Local condition notes across the twelve palace field", items: cells.map((cell) => ({ label: cell.title, value: cell.items[8].value })) },
    ],
  };
}

// ---------------------------------------------------------------- Qi Zheng / natal
function qizhengBoard(result: StudyResult) {
  const chart = qizhengChart(result.astro.utcMs, branchIdx(result.astro.hourBranch));
  const cells = chart.palaces.map((palace, index) => ({
    id: `sector-${index}`,
    title: palace.name,
    subtitle: `${palace.branch} · ${palace.station}`,
    tone: index === 0 ? "gold" as BoardTone : "quiet" as BoardTone,
    active: index === 0,
    items: [
      { label: "Body", value: palace.bodies.map((body) => body.name).join(" · ") || "—" },
      { label: "Palace branch", value: palace.branch },
      { label: "Station", value: palace.station },
      { label: "Lunar mansion", value: palace.bodies.map((body) => `${body.mansion}${body.mansionDegree}°`).join(" · ") || "—" },
      { label: "Degree", value: palace.bodies.map((body) => `${body.name} ${body.signDegree}°`).join(" · ") || "—" },
      { label: "Element", value: palace.bodies.map((body) => body.element).join(" · ") || "—" },
    ],
  }));
  const bodies = chart.bodies;
  return {
    kind: "twelve-palace" as const,
    label: "Twelve-sector celestial board",
    cells,
    sections: [
      { id: "bodies", title: "Celestial bodies", lead: "Planet placement by sector", items: bodies.map((body) => ({ label: body.name, value: `${body.branch} · ${chart.palaces.find((palace) => palace.branch === body.branch)?.name ?? "—"}` })) },
      { id: "lunar-mansions", title: "Lunar mansions", lead: "Twenty-eight-mansion cultural reference layer", items: bodies.map((body) => ({ label: body.name, value: `${body.mansion} ${body.mansionDegree}°` })) },
      { id: "planetary-dignities", title: "Planetary dignities", lead: "Planetary condition notes", items: bodies.map((body) => ({ label: body.name, value: `${body.element} · ${body.branch}` })) },
      { id: "celestial-longitude", title: "Ecliptic longitude", lead: "Approximate ephemeris (tropical, degrees)", items: bodies.map((body) => ({ label: body.name, value: `${body.longitude.toFixed(1)}°` })) },
      { id: "celestial-axis", title: "Celestial axes", lead: "Six opposing-sector pairs held as an orientation frame", items: cells.slice(0, 6).map((cell, index) => ({ label: cell.title, value: cells[index + 6].title })) },
      { id: "seasonal-sky", title: "Seasonal sky frame", lead: "Solar-lunar calendar context retained alongside the sector field", items: [{ label: "Solar", value: result.calendar.solar }, { label: "Lunar", value: result.calendar.lunar }, { label: "Seasonal term", value: result.astro.prevJieQi }, { label: "Life palace", value: `${chart.lifeBranch} · ${chart.palaces[0].station}` }] },
      { id: "method-note", title: "Method note", lead: "Approximate ephemeris; mansion widths follow the traditional degrees anchored at Spica; Zi Qi is not listed", items: [{ label: "Time basis", value: result.calendar.timeBasis === "true-solar" ? "True solar time" : "Civil time" }] },
    ],
  };
}

function natalBoard(result: StudyResult) {
  const longitudes = eclipticLongitudes(result.astro.utcMs);
  const names: Array<[string, string]> = [["太阳", "Sun"], ["太阴", "Moon"], ["水星", "Mercury"], ["金星", "Venus"], ["火星", "Mars"], ["木星", "Jupiter"], ["土星", "Saturn"], ["计都", "North Node"]];
  const location = result.calendar.location;
  const asc = location ? ascendant(result.astro.utcMs, location.latitude, location.longitude) : undefined;
  const ascSign = asc === undefined ? undefined : Math.floor(asc / 30);
  const planets = names.map(([key, en]) => ({ name: en, longitude: longitudes[key], sign: zodiacOf(longitudes[key]), degree: Math.floor(longitudes[key] % 30) }));
  const cells = ZODIAC.map((sign, index) => {
    const here = planets.filter((planet) => planet.sign === sign);
    const house = ascSign === undefined ? undefined : ((index - ascSign + 12) % 12) + 1;
    return {
      id: `sector-${index}`,
      title: sign,
      subtitle: house ? `House ${house}` : undefined,
      tone: here.length ? "gold" as BoardTone : "quiet" as BoardTone,
      active: ascSign === index,
      items: [
        { label: "Body", value: here.map((planet) => planet.name).join(" · ") || "—" },
        { label: "Degree", value: here.map((planet) => `${planet.name} ${planet.degree}°`).join(" · ") || "—" },
        { label: "House", value: house ? String(house) : "—" },
        { label: "Ascendant", value: ascSign === index ? `${Math.floor((asc ?? 0) % 30)}°` : "—" },
      ],
    };
  });
  const aspects: BoardItem[] = [];
  for (let i = 0; i < planets.length; i += 1) for (let j = i + 1; j < planets.length; j += 1) {
    const aspect = aspectBetween(planets[i].longitude, planets[j].longitude);
    if (aspect) aspects.push({ label: `${planets[i].name} / ${planets[j].name}`, value: `${aspect.name} · ${aspect.orb}°` });
  }
  return {
    kind: "twelve-palace" as const,
    label: "Twelve-sector celestial board",
    cells,
    sections: [
      { id: "bodies", title: "Celestial bodies", lead: "Planet placement by sector", items: planets.map((planet) => ({ label: planet.name, value: `${planet.sign} ${planet.degree}°` })) },
      { id: "aspects", title: "Aspect map", lead: "Aspect relationship layer", items: aspects.length ? aspects : [{ label: "Aspect", value: "—" }] },
      { id: "ascendant", title: "Ascendant", lead: "Needs a selected city with coordinates", items: [{ label: "Ascendant", value: asc === undefined ? "—" : `${zodiacOf(asc)} ${Math.floor(asc % 30)}°` }] },
      { id: "seasonal-sky", title: "Seasonal sky frame", lead: "Solar-lunar calendar context retained alongside the sector field", items: [{ label: "Solar", value: result.calendar.solar }, { label: "Seasonal term", value: result.astro.prevJieQi }] },
    ],
  };
}

// ---------------------------------------------------------------- Qi Men
function qimenBoard(result: StudyResult) {
  const chart = qimenChart({ term: result.astro.prevJieQi, dayPillar: result.pillars[2], hourPillar: result.pillars[3] });
  const byPalace = (n: number) => chart.palaces.find((palace) => palace.palace === n)!;
  const cells = palaceNumbers.map((number, index) => {
    const palace = byPalace(number);
    return {
      id: `palace-${index + 1}`,
      title: `Palace ${number}`,
      subtitle: number === 5 ? "Central duty" : `${palaceDirections[index]} · ${number}`,
      tone: number === chart.dutyStarPalace ? "gold" as BoardTone : number === chart.dutyGatePalace ? "vermillion" as BoardTone : "quiet" as BoardTone,
      active: number === chart.dutyStarPalace,
      items: [
        { label: "Direction", value: palaceDirections[index] },
        { label: "Palace number", value: String(number) },
        { label: "Earth branch", value: PALACE_BRANCHES[number] || "—" },
        { label: "Palace element", value: palaceElements[number] },
        { label: "Gate", value: palace.gate, tone: "gold" as BoardTone },
        { label: "Star", value: palace.star, tone: "violet" as BoardTone },
        { label: "Deity", value: palace.deity, tone: "jade" as BoardTone },
        { label: "Heaven stem", value: palace.heavenStem },
        { label: "Earth stem", value: palace.earthStem },
        { label: "Void", value: palace.isVoid ? "空亡" : "—" },
        { label: "Post horse", value: palace.isHorse ? "驿马" : "—" },
      ],
    };
  });
  const item = (cell: typeof cells[number], label: string) => cell.items.find((entry) => entry.label === label)?.value ?? "—";
  const dutyStarCell = cells.find((cell) => cell.title === `Palace ${chart.dutyStarPalace}`)!;
  const dutyGateCell = cells.find((cell) => cell.title === `Palace ${chart.dutyGatePalace}`)!;
  const outer = cells.filter((cell) => cell.title !== "Palace 5");
  return {
    kind: "nine-palace" as const,
    label: "Qi Men nine-palace board",
    cells,
    sections: [
      { id: "gates", title: "Eight Gates", lead: "Action and passage layer", items: outer.map((cell) => ({ label: cell.title, value: item(cell, "Gate") })) },
      { id: "stars", title: "Nine Stars", lead: "Timing and condition layer", items: cells.map((cell) => ({ label: cell.title, value: item(cell, "Star") })) },
      { id: "deities", title: "Eight Deities", lead: "Eight-deity distribution layer", items: outer.map((cell) => ({ label: cell.title, value: item(cell, "Deity") })) },
      { id: "stems", title: "Heaven and Earth stems", lead: "Board stem pairing", items: cells.map((cell) => ({ label: cell.title, value: `${item(cell, "Heaven stem")} / ${item(cell, "Earth stem")}` })) },
      { id: "palace-frame", title: "Directions and palace frame", lead: "Nine palace position, direction, branch and element", items: cells.map((cell) => ({ label: cell.title, value: `${item(cell, "Direction")} · ${item(cell, "Earth branch")} · ${item(cell, "Palace element")}` })) },
      { id: "duty-markers", title: "Duty markers", lead: "Local duty-chief, duty-gate and time markers", items: [{ label: "Duty chief", value: chart.dutyStar }, { label: "Duty gate", value: chart.dutyGate }, { label: "Xun head", value: chart.xunHead }, { label: "Time stem", value: result.pillars[3]?.charAt(0) ?? "—" }, { label: "Day stem", value: result.pillars[2]?.charAt(0) ?? "—" }, { label: "Void", value: chart.voidBranches.join("") }, { label: "Post horse", value: chart.horse }] },
      { id: "key-patterns", title: "Key local patterns", lead: "Gate, star and deity combinations by palace", items: outer.map((cell) => ({ label: cell.title, value: `${item(cell, "Heaven stem")}+${item(cell, "Earth stem")} · ${item(cell, "Gate")}` })) },
      { id: "configuration-triad", title: "Configuration triad", lead: "Gate, star and deity are read as three concurrent study layers", items: cells.map((cell) => ({ label: cell.title, value: `${item(cell, "Gate")} · ${item(cell, "Star")} · ${item(cell, "Deity")}` })) },
      { id: "bureau-frame", title: "Bureau frame", lead: "Yin or Yang bureau, term and central palace framing", items: [{ label: "Bureau", value: chart.bureauName }, { label: "Polarity", value: chart.yang ? "阳遁" : "阴遁" }, { label: "Seasonal term", value: chart.term }, { label: "Yuan", value: chart.yuan }, { label: "Day pillar", value: result.pillars[2] }, { label: "Hour pillar", value: result.pillars[3] }] },
      { id: "duty-location", title: "Duty locations", lead: "Duty chief and duty gate positions across the nine palace field", items: [{ label: "Duty chief palace", value: dutyStarCell.title }, { label: "Duty chief", value: chart.dutyStar }, { label: "Duty gate palace", value: dutyGateCell.title }, { label: "Duty gate", value: chart.dutyGate }, { label: "Horse palace", value: `Palace ${chart.horsePalace}` }] },
      { id: "door-trajectory", title: "Eight-door trajectory", lead: "Gate distribution with the central duty held in the same field", items: outer.map((cell) => ({ label: cell.title, value: item(cell, "Gate") })) },
      { id: "star-field", title: "Nine-star field", lead: "Nine-star distribution across the complete palace board", items: cells.map((cell) => ({ label: cell.title, value: item(cell, "Star") })) },
      { id: "deity-field", title: "Eight-deity field", lead: "Deity distribution across the complete palace board", items: outer.map((cell) => ({ label: cell.title, value: item(cell, "Deity") })) },
      { id: "palace-interactions", title: "Palace interactions", lead: "Gate and stem pairs across the nine-palace board", items: outer.map((cell) => ({ label: cell.title, value: `${item(cell, "Gate")} · ${item(cell, "Heaven stem")}/${item(cell, "Earth stem")}` })) },
    ],
  };
}

// ---------------------------------------------------------------- Liuyao
function liuyaoBoard(result: StudyResult) {
  const cast = castLiuyao(result.lines, result.movingLines, result.pillars[2]);
  const top = [...cast.lines].reverse();
  const original = top.map((line) => ({
    id: `original-${line.position}`,
    title: `Original line ${line.position}`,
    subtitle: line.yang ? "Yang —" : "Yin – –",
    tone: line.yang ? "gold" as BoardTone : "quiet" as BoardTone,
    active: line.moving,
    items: [
      { label: "Series", value: "Original hexagram" },
      { label: "Line", value: yinYangLabel(line.yang) },
      { label: "Relative", value: line.relative },
      { label: "Spirit", value: line.spirit },
      { label: "Role", value: line.role || "—" },
      { label: "Change", value: line.moving ? "Moving" : "Still", tone: line.moving ? "vermillion" as BoardTone : "quiet" as BoardTone },
      { label: "Branch", value: `${line.stem}${line.branch}` },
      { label: "Element", value: ELEMENT_EN[line.element] },
      { label: "Hidden spirit", value: line.hidden ?? "—" },
      { label: "Void", value: cast.voids.includes(line.branch) ? "空亡" : "—" },
    ],
  }));
  const changed = top.map((line) => {
    const transformed = line.changed?.yang ?? line.yang;
    return {
      id: `changed-${line.position}`,
      title: `Changed line ${line.position}`,
      subtitle: transformed ? "Yang —" : "Yin – –",
      tone: transformed ? "gold" as BoardTone : "quiet" as BoardTone,
      active: line.moving,
      items: [
        { label: "Series", value: "Transformed hexagram" },
        { label: "Line", value: yinYangLabel(transformed) },
        { label: "Relative", value: line.changed?.relative ?? line.relative },
        { label: "Spirit", value: line.spirit },
        { label: "Role", value: line.role || "—" },
        { label: "Change", value: line.moving ? "From moving line" : "Carries through", tone: line.moving ? "vermillion" as BoardTone : "quiet" as BoardTone },
        { label: "Branch", value: line.changed ? `${line.changed.stem}${line.changed.branch}` : `${line.stem}${line.branch}` },
        { label: "Element", value: ELEMENT_EN[line.element] },
        { label: "Hidden spirit", value: "—" },
        { label: "Void", value: "—" },
      ],
    };
  });
  const cells = original.flatMap((cell, index) => [cell, changed[index]]);
  const movingTitles = original.filter((cell) => cell.active).map((cell) => cell.title);
  return {
    kind: "hexagram" as const,
    label: "Liuyao original and transformed hexagram",
    cells,
    sections: [
      { id: "hexagram-identity", title: "Hexagram identity", lead: "Original and transformed line structures held as one study object", items: [{ label: "Original hexagram", value: cast.name.full }, { label: "Transformed hexagram", value: cast.changedName?.full ?? "—" }, { label: "Palace", value: `${cast.palace}宫 · ${ELEMENT_EN[cast.palaceElement]}` }, { label: "Series", value: cast.palaceStage }, { label: "Moving lines", value: movingTitles.join(" · ") || "—" }] },
      { id: "original-lines", title: "Original hexagram", lead: "Six local line positions before transformation", items: original.map((cell) => ({ label: cell.title, value: `${cell.items[1].value} · ${cell.items[6].value} · ${cell.items[2].value}` })) },
      { id: "transformed-lines", title: "Transformed hexagram", lead: "Six local line positions after moving-line transformation", items: changed.map((cell) => ({ label: cell.title, value: `${cell.items[1].value} · ${cell.items[6].value} · ${cell.items[2].value}` })) },
      { id: "six-relatives", title: "Six relatives", lead: "Inquiry relationship layer", items: original.map((cell) => ({ label: cell.title, value: cell.items[2].value })) },
      { id: "six-spirits", title: "Six spirits", lead: "Six-spirit condition layer", items: original.map((cell) => ({ label: cell.title, value: cell.items[3].value })) },
      { id: "moving-lines", title: "Moving lines", lead: "Original to transformed study points", items: original.map((cell) => ({ label: cell.title, value: cell.items[5].value })) },
      { id: "world-response-axis", title: "World and response axis", lead: "Self, response and relative layers for a focused question", items: [{ label: "世", value: `Line ${cast.world}` }, { label: "应", value: `Line ${cast.response}` }] },
      { id: "hidden-spirits", title: "Hidden spirits", lead: "Six hidden-spirit references paired with the original line set", items: original.map((cell) => ({ label: cell.title, value: cell.items[8].value })) },
      { id: "trigram-frame", title: "Trigram frame", lead: "Upper and lower trigram references for the original and changed hexagrams", items: [{ label: "Original lower trigram", value: cast.lower }, { label: "Original upper trigram", value: cast.upper }, { label: "Changed lower trigram", value: cast.changedLower }, { label: "Changed upper trigram", value: cast.changedUpper }] },
      { id: "void", title: "Void and response", lead: "Timing reference", items: [{ label: "Void", value: cast.voids.join("") }, { label: "Self / response", value: `Line ${cast.world} / Line ${cast.response}` }] },
      { id: "monthly-day-frame", title: "Month and day frame", lead: "Month, day and hour branches used as a local inquiry frame", items: [{ label: "Month branch", value: result.pillars[1]?.charAt(1) ?? "—" }, { label: "Day pillar", value: result.pillars[2] ?? "—" }, { label: "Hour branch", value: result.pillars[3]?.charAt(1) ?? "—" }, { label: "Void branch", value: cast.voids.join("") }] },
      { id: "line-correspondence", title: "Line correspondence", lead: "Original and transformed line pairs held side by side", items: original.map((cell, index) => ({ label: cell.title, value: `${cell.items[6].value} → ${changed[index].items[6].value}` })) },
    ],
  };
}

// ---------------------------------------------------------------- Da Liu Ren
function daliurenBoard(result: StudyResult) {
  const chart = liurenChart({ qi: result.astro.prevQi, dayPillar: result.pillars[2], hourBranch: result.pillars[3].charAt(1), monthBranch: result.pillars[1].charAt(1) });
  const cells = chart.positions.map((position) => ({
    id: `earth-${position.earth}`,
    title: `${position.earth} position`,
    subtitle: `${position.sky} · ${position.general}`,
    tone: position.sky === chart.nobleBranch ? "gold" as BoardTone : "quiet" as BoardTone,
    active: position.earth === chart.hourBranch,
    items: [
      { label: "Earth plate", value: position.earth },
      { label: "Heaven plate", value: position.sky },
      { label: "General", value: position.general, tone: "violet" as BoardTone },
      { label: "Stem", value: position.stem },
      { label: "Element", value: ELEMENT_EN[position.element] },
      { label: "Void", value: chart.voids.includes(position.sky) ? "空亡" : "—" },
      { label: "Post horse", value: position.sky === chart.horse ? "驿马" : "—" },
      { label: "Twelve officer", value: position.officer },
      { label: "Day-night noble", value: position.sky === chart.nobleBranch ? (chart.daytime ? "Day noble" : "Night noble") : "—" },
      { label: "Branch interaction", value: branchPairText(position.earth, position.sky) },
    ],
  }));
  const names = ["Initial", "Middle", "Final"];
  return {
    kind: "six-ren" as const,
    label: "Da Liu Ren heaven and earth plates",
    cells,
    sections: [
      { id: "four-lessons", title: "Four Lessons", lead: "Four linked inquiry positions", items: chart.lessons.map((lesson, index) => ({ label: `Lesson ${index + 1}`, value: `${lesson.lower} → ${lesson.upper} · ${lesson.general}` })) },
      { id: "three-transmissions", title: "Three Transmissions", lead: "Initial · middle · final movement", items: chart.transmissions.map((entry, index) => ({ label: names[index], value: `${entry.branch} · ${entry.relative}` })) },
      { id: "transmission-context", title: "Transmission context", lead: "Three transmissions together with four lessons and the active general", items: chart.transmissions.map((entry, index) => ({ label: names[index], value: `${entry.stem === "空" ? "空" : entry.stem}${entry.branch} · ${entry.general} · ${entry.relative}` })) },
      { id: "heaven-generals", title: "Twelve heaven generals", lead: "General layer around the local heaven-and-earth plates", items: cells.map((cell) => ({ label: cell.title, value: `${cell.items[1].value} · ${cell.items[2].value}` })) },
      { id: "horse-and-void", title: "Horse and void", lead: "Local motion and absence reference", items: [{ label: "Void branch", value: chart.voids.join("") }, { label: "Post horse", value: chart.horse }, { label: "Noble branch", value: chart.nobleBranch }, { label: "旬", value: chart.xun }] },
      { id: "method-frame", title: "Method frame", lead: "Monthly general, hour and transmission method", items: [{ label: "Monthly general", value: chart.monthGeneral }, { label: "Solar term", value: result.astro.prevQi }, { label: "Hour branch", value: chart.hourBranch }, { label: "Method", value: chart.method }] },
      { id: "timing-frame", title: "Timing frame", lead: "Four-pillar moment retained as the chart anchor", items: result.pillars.map((pillar, index) => ({ label: ["Year", "Month", "Day", "Hour"][index], value: pillar })) },
      { id: "plate-correspondence", title: "Plate correspondence", lead: "Earth plate and heaven plate pairings across the twelve positions", items: cells.map((cell) => ({ label: cell.title, value: `${cell.items[0].value} → ${cell.items[1].value}` })) },
      { id: "day-night-noble", title: "Day-night noble", lead: "Day and night noble locations on the twelve-position field", items: [{ label: chart.daytime ? "Day noble" : "Night noble", value: `${chart.nobleBranch} · ${chart.clockwise ? "Forward" : "Backward"}` }] },
      { id: "general-relations", title: "General relations", lead: "Twelve general and officer references held alongside the heaven plate", items: cells.map((cell) => ({ label: cell.title, value: `${cell.items[2].value} · ${cell.items[7].value}` })) },
      { id: "branch-interactions", title: "Branch interactions", lead: "Twelve branch interaction references around the earth and heaven plates", items: cells.map((cell) => ({ label: cell.title, value: `${cell.items[0].value} → ${cell.items[1].value} · ${cell.items[9].value}` })) },
    ],
  };
}

function branchPairText(a: string, b: string) {
  const relations = branchPairRelations(a, b);
  return relations.length ? relations.join(" · ") : "—";
}

// ---------------------------------------------------------------- Daily / timing
function dailyRhythmBoard(result: StudyResult, input: StudyInput) {
  const parts = input.birthDate.split("-").map(Number);
  const lunar = Solar.fromYmdHms(parts[0] || 2026, parts[1] || 1, parts[2] || 1, 12, 0, 0).getLunar();
  const times = lunar.getTimes().slice(1); // the late 子 hour (23:00) belongs to the next day; keep 12 hours from 00:00 onward
  const windows = times.map((time: { getGanZhi: () => string; getZhi: () => string; getMinHm: () => string; getMaxHm: () => string; getTianShen: () => string; getTianShenLuck: () => string; getChongDesc: () => string; getYi: () => string[]; getJi: () => string[] }, index: number) => ({
    id: `daily-window-${index + 1}`,
    title: `Day window ${index + 1}`,
    subtitle: `${time.getMinHm()}–${time.getMaxHm()} · ${time.getGanZhi()}`,
    tone: time.getTianShenLuck() === "吉" ? "gold" as BoardTone : "quiet" as BoardTone,
    active: time.getZhi() === result.pillars[3]?.charAt(1),
    items: [
      { label: "Hour pillar", value: time.getGanZhi() },
      { label: "Hour branch", value: time.getZhi() },
      { label: "Time range", value: `${time.getMinHm()}–${time.getMaxHm()}` },
      { label: "Element", value: branchElements[time.getZhi()] ?? "—" },
      { label: "Day spirit", value: `${time.getTianShen()} · ${time.getTianShenLuck()}` },
      { label: "Clash", value: time.getChongDesc() },
      { label: "Favourable reference", value: time.getYi().slice(0, 3).join(" · ") || "—" },
      { label: "Caution reference", value: time.getJi().slice(0, 3).join(" · ") || "—" },
    ],
  }));
  const elementCount = (name: string) => windows.filter((window: { items: BoardItem[] }) => window.items[3].value === name).length;
  return {
    kind: "comparison" as const,
    label: "Daily rhythm study field",
    cells: windows,
    sections: [
      { id: "daily-calendar", title: "Daily calendar", lead: "The selected date remains visible as a study anchor", items: [{ label: "Solar", value: lunar.getSolar().toYmd() }, { label: "Lunar", value: lunar.toString() }, { label: "Day pillar", value: lunar.getDayInGanZhi() }, { label: "Day officer", value: lunar.getZhiXing() }, { label: "Day spirit", value: `${lunar.getDayTianShen()} · ${lunar.getDayTianShenLuck()}` }, { label: "Lunar mansion", value: lunar.getXiu() }, { label: "Clash", value: lunar.getDayChongDesc() }, { label: "Sha direction", value: lunar.getDaySha() }] },
      { id: "solar-term-context", title: "Solar-term context", lead: "Seasonal markers are observed as cultural context, not a directive", items: [{ label: "Current term", value: lunar.getPrevJieQi(true).getName() }, { label: "Term date", value: lunar.getPrevJieQi(true).getSolar().toYmd() }, { label: "Next term", value: lunar.getNextJieQi(true).getName() }, { label: "Next term date", value: lunar.getNextJieQi(true).getSolar().toYmd() }] },
      { id: "twelve-windows", title: "Twelve day windows", lead: "Twelve small observation windows keep the day spacious", items: windows.map((window: { title: string; items: BoardItem[] }) => ({ label: window.title, value: `${window.items[2].value} · ${window.items[0].value} · ${window.items[4].value}` })) },
      { id: "daily-yi-ji", title: "Almanac references", lead: "Traditional almanac entries for the selected day", items: [{ label: "Favourable reference", value: lunar.getDayYi().slice(0, 6).join(" · ") || "—" }, { label: "Caution reference", value: lunar.getDayJi().slice(0, 6).join(" · ") || "—" }, { label: "Joy direction", value: lunar.getDayPositionXiDesc() }, { label: "Wealth direction", value: lunar.getDayPositionCaiDesc() }, { label: "Fortune direction", value: lunar.getDayPositionFuDesc() }] },
      { id: "elemental-climate", title: "Elemental climate", lead: "Five-element counts and day-window references are held together", items: elementNames.map((name) => ({ label: name, value: `${elementCount(name)}` })) },
      { id: "grounded-sequence", title: "Grounded sequence", lead: "A gentle sequence for attention without claiming a fixed outcome", items: ["Pause", "Notice", "Clarify", "Choose", "Return"].map((label, index) => ({ label: `Step ${index + 1}`, value: label })) },
    ],
  };
}

function timingBoard(result: StudyResult) {
  // 寻时定盘: the twelve candidate birth hours for the selected date.
  const [year, month, day] = result.pillars;
  const dayStem = day.charAt(0);
  const ratStem = stemIdx(ratHourStem(dayStem));
  const ranges = ["23:00–00:59", "01:00–02:59", "03:00–04:59", "05:00–06:59", "07:00–08:59", "09:00–10:59", "11:00–12:59", "13:00–14:59", "15:00–16:59", "17:00–18:59", "19:00–20:59", "21:00–22:59"];
  const cells = Array.from({ length: 12 }, (_, index) => {
    const pillar = `${stemAtIndex(ratStem + index)}${branchAtIndex(index)}`;
    return {
      id: `window-${index + 1}`,
      title: `Window ${index + 1}`,
      subtitle: `${ranges[index]} · ${pillar}`,
      tone: pillar === result.pillars[3] ? "gold" as BoardTone : "quiet" as BoardTone,
      active: pillar === result.pillars[3],
      items: [
        { label: "Time range", value: ranges[index] },
        { label: "Hour pillar", value: pillar },
        { label: "Four pillars", value: `${year} ${month} ${day} ${pillar}` },
        { label: "Ten God", value: tenGod(dayStem, pillar.charAt(0)) },
        { label: "Life stage", value: lifeStage(dayStem, pillar.charAt(1)) },
        { label: "NaYin element", value: ELEMENT_EN[naYinElementOf(pillar) as keyof typeof ELEMENT_EN] ?? "—" },
        { label: "Branch relation", value: branchPairText(pillar.charAt(1), day.charAt(1)) },
      ],
    };
  });
  return {
    kind: "nine-palace" as const,
    label: "Time calibration board",
    cells,
    sections: [
      { id: "estimate-only", title: "An estimate, not a certainty", lead: "These are the twelve possible hours for the date; matching one to your life is an estimate and may be wrong. If you later learn your birth time, use that instead", items: [{ label: "Method", value: "Compare the twelve hour pillars with known events and traits" }, { label: "Certainty", value: "Estimate only" }] },
      { id: "timing-layers", title: "Timing layers", lead: "Twelve candidate hours for the selected date", items: cells.map((cell) => ({ label: cell.items[0].value, value: `${cell.items[1].value} · ${cell.items[3].value}` })) },
      { id: "seasonal-frame", title: "Seasonal frame", lead: "Seasonal term references around the selected moment", items: [{ label: "Seasonal term", value: result.astro.prevJieQi }, { label: "Month branch", value: month.charAt(1) }, { label: "Day pillar", value: day }] },
      { id: "calendar-reference", title: "Calendar reference", lead: "Solar, lunar, day branch and hour branch details", items: [{ label: "Solar", value: result.calendar.solar }, { label: "Lunar", value: result.calendar.lunar }, { label: "Civil time", value: result.calendar.civilTime }, { label: "True solar time", value: result.calendar.trueSolarTime ?? "—" }] },
    ],
  };
}

// ---------------------------------------------------------------- Toolkit
function elementsBoard(result: StudyResult) {
  const monthBranch = result.pillars[1].charAt(1);
  const cycle: Record<string, string> = { Wood: "Wood feeds Fire", Fire: "Fire forms Earth", Earth: "Earth bears Metal", Metal: "Metal gathers Water", Water: "Water nourishes Wood" };
  const max = Math.max(...result.calendar.elements.map((item) => item.count));
  const cells = result.calendar.elements.map((entry) => {
    const stems = result.pillars.map((pillar) => pillar.charAt(0)).filter((stem) => stemElements[stem] === entry.name);
    const branches = result.pillars.map((pillar) => pillar.charAt(1)).filter((branch) => branchElements[branch] === entry.name);
    const hidden = result.pillars.flatMap((pillar) => hiddenStemsTable[pillar.charAt(1)] ?? []).filter((stem) => stemElements[stem] === entry.name);
    return {
      id: `element-${entry.name.toLowerCase()}`,
      title: entry.name,
      subtitle: `${entry.count}`,
      tone: entry.count === max ? "gold" as BoardTone : "quiet" as BoardTone,
      active: entry.count === max,
      items: [
        { label: "Visible count", value: String(entry.count) },
        { label: "Cycle role", value: cycle[entry.name] },
        { label: "Stem reference", value: stems.join(" · ") || "—" },
        { label: "Branch reference", value: branches.join(" · ") || "—" },
        { label: "Hidden stems", value: hidden.join(" · ") || "—" },
        { label: "Seasonal status", value: seasonalStateOfElement(entry.name, monthBranch) },
      ],
    };
  });
  return {
    kind: "comparison" as const,
    label: "Five Elements balance board",
    cells,
    sections: [
      { id: "element-count", title: "Element count", lead: "Visible five-element distribution from the calendar", items: cells.map((cell) => ({ label: cell.title, value: cell.items[0].value })) },
      { id: "visible-roots", title: "Visible roots", lead: "Stem and branch references for each elemental lane", items: cells.map((cell) => ({ label: cell.title, value: `${cell.items[2].value} / ${cell.items[3].value}` })) },
      { id: "hidden-roots", title: "Hidden stems", lead: "Branch-root study layer", items: cells.map((cell) => ({ label: cell.title, value: cell.items[4].value })) },
      { id: "cycle-map", title: "Cycle map", lead: "Five-phase generating cycle as a study reference", items: cells.map((cell) => ({ label: cell.title, value: cell.items[1].value })) },
      { id: "seasonal-balance", title: "Seasonal balance", lead: "Seasonal status carried across the five-element board", items: cells.map((cell) => ({ label: cell.title, value: cell.items[5].value })) },
    ],
  };
}

function dreamBoard(result: StudyResult, input: StudyInput) {
  const matches = matchDreamSymbols(input.focus || "", 3);
  const positions = ["Image", "Feeling", "Return"];
  const cells = matches.length
    ? matches.map((symbol, index) => ({
      id: `dream-${index + 1}`,
      title: positions[index],
      subtitle: symbol.name.en,
      tone: index === 0 ? "gold" as BoardTone : "quiet" as BoardTone,
      active: index === 0,
      items: [
        { label: "Dream image", value: symbol.name.en },
        { label: "Cultural association", value: symbol.theme.en },
        { label: "Element", value: symbol.element },
        { label: "Reflection thread", value: result.prompts[index] ?? "Pause and notice." },
      ],
    }))
    : [{ id: "dream-1", title: "Image", subtitle: "Describe the dream", tone: "quiet" as BoardTone, active: true, items: [{ label: "Dream image", value: "Describe the dream" }, { label: "Cultural association", value: "—" }, { label: "Element", value: "—" }, { label: "Reflection thread", value: result.prompts[0] ?? "Pause and notice." }] }];
  return {
    kind: "spread" as const,
    label: "Dream reflection board",
    cells,
    sections: [
      { id: "dream-symbols", title: "Dream images", lead: "Images recognised in the dream description", items: cells.map((cell) => ({ label: cell.title, value: cell.items[0].value })) },
      { id: "dream-associations", title: "Cultural associations", lead: "Traditional associations, offered for reflection only", items: cells.map((cell) => ({ label: cell.items[0].value, value: cell.items[1].value })) },
      { id: "elemental-tone", title: "Elemental tone", lead: "Five-element texture for each dream image", items: cells.map((cell) => ({ label: cell.items[0].value, value: cell.items[2].value })) },
      { id: "reflection-threads", title: "Reflection threads", lead: "Questions that connect images with current experience", items: cells.map((cell) => ({ label: cell.title, value: cell.items[3].value })) },
      { id: "dream-day", title: "Dream date", lead: "Calendar context of the dream", items: [{ label: "Solar", value: result.calendar.solar.slice(0, 10) }, { label: "Day pillar", value: result.pillars[2] }] },
    ],
  };
}

function nameBoard(result: StudyResult, input: StudyInput) {
  const characters = Array.from((input.name || "").replace(/\s+/g, "")).slice(0, 6);
  const counts = result.calendar.elements;
  const max = Math.max(...counts.map((item) => item.count));
  const min = Math.min(...counts.map((item) => item.count));
  const strongest = counts.filter((item) => item.count === max).map((item) => item.name).join(" · ");
  const weakest = counts.filter((item) => item.count === min).map((item) => item.name).join(" · ");
  const cells = (characters.length ? characters : ["—"]).map((character, index) => ({
    id: `name-${index + 1}`,
    title: `Character ${index + 1}`,
    subtitle: character,
    tone: index === 0 ? "gold" as BoardTone : "quiet" as BoardTone,
    active: index === 0,
    items: [
      { label: "Character reference", value: character },
      { label: "Position", value: index === 0 ? "Surname / first character" : `Character ${index + 1}` },
      { label: "Stroke data", value: "Not assessed" },
    ],
  }));
  return {
    kind: "comparison" as const,
    label: "Name study board",
    cells,
    sections: [
      { id: "character-form", title: "Character form", lead: "Characters of the name in order", items: cells.map((cell) => ({ label: cell.title, value: cell.subtitle ?? "—" })) },
      { id: "birth-balance", title: "Birth-chart element balance", lead: "Five-element counts of the birth pillars, used as the reference for name study", items: [...counts.map((item) => ({ label: item.name, value: String(item.count) })), { label: "Strongest", value: strongest }, { label: "Weakest", value: weakest }] },
      { id: "name-method-note", title: "Method note", lead: "Kangxi stroke counts are needed for stroke-based name analysis; characters are not given an element without that data", items: [{ label: "Four pillars", value: result.pillars.join(" ") }] },
    ],
  };
}

function spreadBoard(result: StudyResult, input: StudyInput, majorsOnly: boolean) {
  const draw = drawTarot(`${input.module}|${input.focus}|${input.name}|${input.birthDate}`, 3, majorsOnly);
  const positions = ["Origin", "Present", "Next gesture"];
  const cells = draw.map(({ card, reversed }, index) => ({
    id: `card-${index}`,
    title: positions[index],
    subtitle: card.name.en,
    tone: index === 1 ? "gold" as BoardTone : "quiet" as BoardTone,
    active: index === 1,
    items: [
      { label: "Card", value: card.name.en },
      { label: "Orientation", value: reversed ? "reversed" : "upright" },
      { label: "Keyword", value: reversed ? card.reversedKeyword.en : card.keyword.en },
      { label: "Position", value: positions[index] },
      { label: "Prompt", value: result.prompts[index] ?? "Pause and notice." },
    ],
  }));
  return {
    kind: "spread" as const,
    label: majorsOnly ? "Mirror reflection spread" : "Three-card tarot spread",
    cells,
    sections: [
      { id: "positions", title: "Spread positions", lead: "Origin · present · next gesture", items: cells.map((cell) => ({ label: cell.title, value: `${cell.items[0].value} · ${cell.items[1].value}` })) },
      { id: "card-keywords", title: "Card keywords", lead: "Traditional keywords for each drawn card", items: cells.map((cell) => ({ label: cell.items[0].value, value: cell.items[2].value })) },
      { id: "actions", title: "Reflection actions", lead: "A three-step practice", items: cells.map((cell, index) => ({ label: `Prompt ${index + 1}`, value: cell.items[4].value })) },
    ],
  };
}

// ---------------------------------------------------------------- Plum blossom (梅花易数)
const TRIGRAM_ELEMENT_ZH: Record<string, Element> = { 乾: "金", 兑: "金", 离: "火", 震: "木", 巽: "木", 坎: "水", 艮: "土", 坤: "土" };
function tiYongRelation(ti: Element, yong: Element) {
  if (ti === yong) return "体用比和";
  const gen: Record<Element, Element> = { 木: "火", 火: "土", 土: "金", 金: "水", 水: "木" };
  const ctl: Record<Element, Element> = { 木: "土", 土: "水", 水: "火", 火: "金", 金: "木" };
  if (gen[yong] === ti) return "用生体";
  if (gen[ti] === yong) return "体生用";
  if (ctl[ti] === yong) return "体克用";
  return "用克体";
}

function meihuaBoard(result: StudyResult, input?: StudyInput) {
  const lines = result.lines;
  const movingIndex = Math.max(0, result.movingLines.findIndex(Boolean));
  const lower = trigramOf(lines.slice(0, 3));
  const upper = trigramOf(lines.slice(3, 6));
  const changed = lines.map((yang, index) => (index === movingIndex ? !yang : yang));
  const mutual = [lines[1], lines[2], lines[3], lines[2], lines[3], lines[4]];
  const original = hexagramName(lower, upper);
  const mutualName = hexagramName(trigramOf(mutual.slice(0, 3)), trigramOf(mutual.slice(3, 6)));
  const changedName = hexagramName(trigramOf(changed.slice(0, 3)), trigramOf(changed.slice(3, 6)));
  const movingInLower = movingIndex < 3;
  const ti = movingInLower ? upper : lower;
  const yong = movingInLower ? lower : upper;
  const relation = tiYongRelation(TRIGRAM_ELEMENT_ZH[ti], TRIGRAM_ELEMENT_ZH[yong]);
  const stage = (title: string, name: { full: string }, set: boolean[]) => ({
    id: `meihua-${title.toLowerCase().replace(/\s+/g, "-")}`,
    title,
    subtitle: name.full,
    tone: title === "Original hexagram" ? "gold" as BoardTone : "quiet" as BoardTone,
    active: title === "Original hexagram",
    items: [
      { label: "Hexagram", value: name.full },
      { label: "Upper trigram", value: trigramOf(set.slice(3, 6)) },
      { label: "Lower trigram", value: trigramOf(set.slice(0, 3)) },
      { label: "Lines", value: [...set].reverse().map(yinYangLabel).join(" · ") },
    ],
  });
  const cells = [stage("Original hexagram", original, lines), stage("Mutual hexagram", mutualName, mutual), stage("Transformed hexagram", changedName, changed)];
  return {
    kind: "spread" as const,
    label: "Plum blossom numerology board",
    cells,
    sections: [
      input?.meihuaMethod === "numbers" && input.meihuaNumbers
        ? { id: "meihua-casting", title: "Casting", lead: "Number casting: the first number gives the upper trigram, the second the lower; their sum plus the hour gives the moving line", items: [{ label: "Numbers", value: input.meihuaNumbers.join(" · ") }, { label: "Moving lines", value: `Line ${movingIndex + 1}` }] }
        : input?.meihuaMethod === "text" && input.meihuaText?.trim()
          ? { id: "meihua-casting", title: "Casting", lead: "Text casting: the first half of the phrase gives the upper trigram, the second half the lower; the total plus the hour gives the moving line", items: [{ label: "Phrase", value: input.meihuaText.trim().slice(0, 60) }, { label: "Moving lines", value: `Line ${movingIndex + 1}` }] }
          : { id: "meihua-casting", title: "Casting", lead: "Time casting: lunar year branch, month and day give the upper trigram; adding the hour gives the lower trigram and the moving line", items: [{ label: "Lunar birth", value: `${result.astro.lunarYearBranch} · ${result.astro.lunarMonth} / ${result.astro.lunarDay} · ${result.astro.hourBranch}` }, { label: "Moving lines", value: `Line ${movingIndex + 1}` }] },
      { id: "meihua-ti-yong", title: "Body and function", lead: "The trigram without the moving line is the body; the one with it is the function", items: [{ label: "体", value: `${ti} · ${ELEMENT_EN[TRIGRAM_ELEMENT_ZH[ti]]}` }, { label: "用", value: `${yong} · ${ELEMENT_EN[TRIGRAM_ELEMENT_ZH[yong]]}` }, { label: "Relation", value: relation }] },
      { id: "meihua-sequence", title: "Hexagram sequence", lead: "Original, mutual and transformed hexagrams read as beginning, process and outcome", items: cells.map((cell) => ({ label: cell.title, value: cell.subtitle })) },
    ],
  };
}

// ---------------------------------------------------------------- House feng shui (八宅 + 年飞星)
function fengshuiBoard(result: StudyResult, input: StudyInput) {
  const yearPillar = result.pillars[0];
  const birthYear = Number((input.birthDate || "1990").slice(0, 4));
  // The solar year begins at 立春: use the year whose ganzhi matches the year pillar.
  const solarYear = [birthYear, birthYear - 1].find((year) => ganzhiOfYear(year) === yearPillar) ?? birthYear;
  const sitting = (DIRECTIONS as readonly string[]).includes(input.houseSitting ?? "") ? input.houseSitting as Direction : "North";
  const chart = fengshuiChart({ solarYear, gender: input.gender ?? "yang", sitting, currentYear: currentYear() });
  const cells = chart.directions.map((entry) => ({
    id: `direction-${entry.direction.toLowerCase()}`,
    title: entry.direction,
    subtitle: entry.trigram,
    tone: ["生气", "天医", "延年", "伏位"].includes(entry.personal) ? "gold" as BoardTone : "quiet" as BoardTone,
    active: entry.direction === chart.facing,
    items: [
      { label: "Trigram", value: entry.trigram },
      { label: "Personal direction", value: entry.personal },
      { label: "House direction", value: entry.house },
      { label: "Annual star", value: entry.annualStar },
    ],
  }));
  return {
    kind: "nine-palace" as const,
    label: "Space and Qi board",
    cells,
    sections: [
      { id: "fengshui-person", title: "Personal trigram", lead: "Eight Mansions personal trigram from the solar birth year and gender", items: [{ label: "Kua number", value: String(chart.kua) }, { label: "Trigram", value: chart.kuaTrigram }, { label: "Group", value: chart.personGroup }] },
      { id: "fengshui-house", title: "House trigram", lead: "The house trigram follows the sitting direction", items: [{ label: "Sitting", value: chart.sitting }, { label: "Facing", value: chart.facing }, { label: "Trigram", value: chart.houseTrigram }, { label: "Group", value: chart.houseGroup }, { label: "Match", value: chart.matched ? "Same group" : "Different groups" }] },
      { id: "fengshui-directions", title: "Eight directions", lead: "Traditional Eight Mansions labels for the person and the house", items: cells.map((cell) => ({ label: cell.title, value: `${cell.items[1].value} / ${cell.items[2].value}` })) },
      { id: "fengshui-annual", title: "Annual flying stars", lead: "The year's star in the centre flies through the nine palaces in Luo Shu order", items: [{ label: String(chart.year), value: `${chart.yearGanzhi} · ${chart.centerStar}` }, ...cells.map((cell) => ({ label: cell.title, value: cell.items[3].value }))] },
      { id: "fengshui-note", title: "Method note", lead: "A cultural reference based on directions only; it does not assess the building, its safety or its value", items: [{ label: "Year", value: String(solarYear) }] },
    ],
  };
}
const ganzhiOfYear = (year: number) => `${"甲乙丙丁戊己庚辛壬癸"[((year - 4) % 10 + 10) % 10]}${"子丑寅卯辰巳午未申酉戌亥"[((year - 4) % 12 + 12) % 12]}`;

// ---------------------------------------------------------------- Comparison modules
function weakestElements(pillars: string[]) {
  const counts = elementNames.map((name) => ({ name, count: pillars.reduce((sum, pillar) => sum + (stemElements[pillar.charAt(0)] === name ? 1 : 0) + (branchElements[pillar.charAt(1)] === name ? 1 : 0), 0) }));
  const min = Math.min(...counts.map((entry) => entry.count));
  return { counts, weakest: counts.filter((entry) => entry.count === min).map((entry) => entry.name) };
}

function comparisonBoard(result: StudyResult, input: StudyInput, label: string) {
  const dayStem = result.pillars[2].charAt(0);
  const own = weakestElements(result.pillars);
  let cells: BoardCell[];
  let sections: BoardSection[];
  if (result.module === "compatibility") {
    const other = result.companionPillars;
    if (!other || other.some((pillar) => jiaziIdx(pillar) < 0)) {
      cells = [{ id: "lens-0", title: "Pair context", subtitle: "—", items: [{ label: "Pair context", value: "Add a second profile to extend this layer." }], tone: "quiet", active: true }];
      sections = [{ id: "pair-resonance", title: "Pair resonance", lead: "Two profiles are compared as a conversation aid, never as a fixed outcome", items: [{ label: "Pair context", value: "Add a second profile to extend this layer." }] }];
    } else {
      const otherDay = other[2].charAt(0);
      const theirs = weakestElements(other);
      const stemCombine = STEM_COMBINE[dayStem]?.[0] === otherDay ? `合化${STEM_COMBINE[dayStem][1]}` : "—";
      cells = result.pillars.map((pillar, index) => ({
        id: `lens-${index}`,
        title: pillarRoles[index],
        subtitle: `${pillar} / ${other[index]}`,
        tone: index === 2 ? "gold" as BoardTone : "quiet" as BoardTone,
        active: index === 2,
        items: [
          { label: "First profile", value: pillar },
          { label: "Second profile", value: other[index] },
          { label: "Branch relation", value: branchPairText(pillar.charAt(1), other[index].charAt(1)) },
          { label: "Stem element", value: `${stemElements[pillar.charAt(0)]} / ${stemElements[other[index].charAt(0)]}` },
        ],
      }));
      sections = [
        { id: "pair-resonance", title: "Pair resonance", lead: "Two profiles are compared as a conversation aid, never as a fixed outcome", items: [{ label: "Day stems", value: `${dayStem} / ${otherDay} · ${stemCombine}` }, { label: "Second profile's day stem for the first", value: tenGod(dayStem, otherDay) }, { label: "First profile's day stem for the second", value: tenGod(otherDay, dayStem) }, { label: "Day branches", value: `${result.pillars[2].charAt(1)}${other[2].charAt(1)} · ${branchPairText(result.pillars[2].charAt(1), other[2].charAt(1))}` }, { label: "Year branches", value: `${result.pillars[0].charAt(1)}${other[0].charAt(1)} · ${branchPairText(result.pillars[0].charAt(1), other[0].charAt(1))}` }] },
        { id: "two-profile-frame", title: "Two-profile frame", lead: "The two profiles remain distinguishable at every pillar position", items: cells.map((cell) => ({ label: cell.title, value: `${cell.items[0].value} / ${cell.items[1].value} · ${cell.items[2].value}` })) },
        { id: "element-dialogue", title: "Element dialogue", lead: "Five-element references are a vocabulary for conversation, not a score", items: own.counts.map((entry, index) => ({ label: entry.name, value: `${entry.count} / ${theirs.counts[index].count}` })) },
        { id: "element-complement", title: "Element complement", lead: "Where one profile is light, whether the other carries that element", items: [{ label: "First profile weakest", value: `${own.weakest.join(" · ")} · ${own.weakest.map((name) => theirs.counts.find((entry) => entry.name === name)?.count ?? 0).join(" · ")}` }, { label: "Second profile weakest", value: `${theirs.weakest.join(" · ")} · ${theirs.weakest.map((name) => own.counts.find((entry) => entry.name === name)?.count ?? 0).join(" · ")}` }] },
      ];
    }
  } else if (result.module === "wenshi") {
    const cast = castLiuyao(result.lines, result.movingLines, result.pillars[2]);
    cells = [...cast.lines].reverse().map((line) => ({
      id: `lens-${line.position}`,
      title: `Line ${line.position}`,
      subtitle: `${yinYangLabel(line.yang)} · ${line.stem}${line.branch}`,
      tone: line.role === "世" ? "gold" as BoardTone : "quiet" as BoardTone,
      active: line.role === "世",
      items: [{ label: "Line", value: yinYangLabel(line.yang) }, { label: "Branch", value: `${line.stem}${line.branch}` }, { label: "Relative", value: line.relative }, { label: "Spirit", value: line.spirit }, { label: "Role", value: line.role || "—" }, { label: "Change", value: line.moving ? "Moving" : "Still" }],
    }));
    sections = [
      { id: "inquiry-triangulation", title: "Inquiry triangulation", lead: "Question, timing and line references remain distinct before reflection", items: [{ label: "Question", value: result.focus || "—" }, { label: "Timing", value: `${result.pillars[1]} · ${result.pillars[2]} · ${result.pillars[3]}` }, { label: "Original hexagram", value: cast.name.full }, { label: "Transformed hexagram", value: cast.changedName?.full ?? "—" }] },
      { id: "line-context", title: "Line context", lead: "Six line positions are retained with their yin-yang state and calendar frame", items: cells.map((cell) => ({ label: cell.title, value: `${cell.items[0].value} · ${cell.items[1].value} · ${cell.items[2].value}` })) },
      { id: "inquiry-frame", title: "Month and day frame", lead: "Month, day and hour branches used as a local inquiry frame", items: [{ label: "Month branch", value: result.pillars[1].charAt(1) }, { label: "Day pillar", value: result.pillars[2] }, { label: "Void", value: cast.voids.join("") }, { label: "世", value: `Line ${cast.world}` }, { label: "应", value: `Line ${cast.response}` }] },
    ];
  } else {
    // 合参: BaZi, Zi Wei and the current year read together.
    const derived = calculateBaziReference(result.pillars, input.gender ?? "yang");
    const astro = result.astro;
    const zw = ziweiPlacement({ yearStem: astro.lunarYearStem, yearBranch: astro.lunarYearBranch, lunarMonth: ziweiMonth(astro.lunarMonth, astro.lunarDay, astro.leapMonth, input.ziweiLeap), lunarDay: astro.lunarDay, hourBranch: astro.hourBranch, gender: input.gender ?? "yang", currentYear: currentYear(), transformVariant: input.ziweiTransform });
    const life = zw.palaces.find((palace) => palace.isLife)!;
    const year = annualCycle(dayStem, currentYear(), 1)[0];
    cells = [
      { id: "lens-0", title: "Pillars", subtitle: result.pillars.join(" "), tone: "quiet", active: false, items: [{ label: "Day master", value: dayStem }, { label: "Seasonal status", value: seasonalStateOfStem(dayStem, result.pillars[1].charAt(1)) }, { label: "Ten God", value: derived.tenGods.join(" · ") }] },
      { id: "lens-1", title: "Elements", subtitle: elementLine(result), tone: "gold", active: true, items: [{ label: "Element balance", value: elementLine(result) }, { label: "Weakest", value: own.weakest.join(" · ") }] },
      { id: "lens-2", title: "Life palace", subtitle: `${life.stem}${life.branch}`, tone: "quiet", active: false, items: [{ label: "Core star", value: life.mainStars.join(" · ") || "—" }, { label: "Bureau element", value: zw.bureauName }, { label: "Decade limit", value: life.decade }] },
      { id: "lens-3", title: "Current year", subtitle: `${year.year} ${year.ganzhi}`, tone: "quiet", active: false, items: [{ label: "Annual pillar", value: year.ganzhi }, { label: "Ten God", value: year.tenGod }, { label: "Life stage", value: year.stage }] },
    ];
    sections = [
      { id: "pillar-crosscheck", title: "Pillar cross-check", lead: "Four-pillar, element and timing references held in one comparison", items: result.pillars.map((pillar, index) => ({ label: pillarRoles[index], value: `${pillar} · ${derived.tenGods[index]} · ${derived.naYin[index]}` })) },
      { id: "profile-structure", title: "Profile structure", lead: "Year, month, day and hour references kept visible before comparison", items: [{ label: "Day master", value: `${dayStem} · ${stemElements[dayStem]}` }, { label: "Life palace", value: `${life.branch} · ${life.mainStars.join(" · ") || "—"}` }, { label: "Bureau element", value: zw.bureauName }] },
      { id: "element-correspondence", title: "Element correspondence", lead: "Visible element counts and branch roots held side by side", items: own.counts.map((entry) => ({ label: entry.name, value: String(entry.count) })) },
      { id: "timing-correspondence", title: "Timing correspondence", lead: "Calendar, civil time and chosen time basis kept separate", items: [{ label: "Solar", value: result.calendar.solar }, { label: "Lunar", value: result.calendar.lunar }, { label: String(year.year), value: `${year.ganzhi} · ${year.tenGod} · ${year.stage}` }] },
    ];
  }
  return { kind: "comparison" as const, label, cells, sections };
}

// ---------------------------------------------------------------- 金口诀 / 河洛理数 / 铁板神数 / 太乙神数
const JKJ_ROLE_EN: Record<string, string> = { 人元: "Human stem", 贵神: "Noble general", 将神: "General spirit", 地分: "Earth position" };
const RELATION_EN: Record<string, string> = { 比和: "Same element", 上生下: "Upper generates lower", 下生上: "Lower generates upper", 上克下: "Upper controls lower", 下克上: "Lower controls upper" };
const PATTERN_EN: Record<string, string> = { 四阳: "Four yang", 四阴: "Four yin", 三阳一阴: "Three yang, one yin", 三阴一阳: "Three yin, one yang", 二阳二阴: "Two yang, two yin" };

function jinkoujueBoard(result: StudyResult, input: StudyInput) {
  const lesson = jinKouJue({ qi: result.astro.prevQi, dayPillar: result.pillars[2], hourBranch: result.pillars[3].charAt(1), monthBranch: result.pillars[1].charAt(1), difen: input.difen });
  const cells = lesson.positions.map((position, index) => ({
    id: `position-${index + 1}`,
    title: JKJ_ROLE_EN[position.role],
    subtitle: position.value,
    tone: position.role === lesson.use ? "gold" as BoardTone : "quiet" as BoardTone,
    active: position.role === lesson.use,
    items: [
      { label: "Value", value: position.value },
      { label: "Element", value: ELEMENT_EN[position.element] },
      { label: "Seasonal status", value: position.state },
      { label: "Yin-yang", value: yinYangLabel(position.yang) },
      { label: "Use position", value: position.role === lesson.use ? "✓" : "—", tone: position.role === lesson.use ? "gold" as BoardTone : undefined },
      { label: "Void", value: lesson.voids.includes(position.value) ? "空亡" : "—" },
    ],
  }));
  return {
    kind: "spread" as const,
    label: "Jin Kou Jue four-position lesson",
    cells,
    sections: [
      { id: "jkj-frame", title: "Lesson frame", lead: "Monthly general placed on the hour; the chosen earth position fixes the lesson", items: [{ label: "Earth position", value: `${lesson.difen} · ${lesson.direction}` }, { label: "Monthly general", value: lesson.monthGeneral }, { label: "Solar term", value: result.astro.prevQi }, { label: "Day pillar", value: result.pillars[2] }, { label: "Hour branch", value: result.pillars[3].charAt(1) }] },
      { id: "jkj-use", title: "Use position", lead: "The position whose element stands apart from the other three is taken as the use position", items: [{ label: "Use position", value: JKJ_ROLE_EN[lesson.use] }, { label: "Yin-yang pattern", value: PATTERN_EN[lesson.pattern] }] },
      { id: "jkj-relations", title: "Upper and lower relations", lead: "Each position is read against the one below it: generating, controlling or the same element", items: lesson.links.map((link) => ({ label: link.pair.split(" / ").map((role) => JKJ_ROLE_EN[role]).join(" / "), value: RELATION_EN[link.relation] })) },
      { id: "jkj-void", title: "Void", lead: "Void branches of the day's ten-day group", items: [{ label: "Void branch", value: lesson.voids.join("") }, { label: "Void positions", value: lesson.voidHit.length ? lesson.voidHit.map((role) => JKJ_ROLE_EN[role]).join(" · ") : "—" }] },
    ],
  };
}

function hexagramCell(id: string, title: string, name: { full: string }, lines: boolean[], marked: number, active: boolean) {
  return {
    id, title, subtitle: name.full, tone: active ? "gold" as BoardTone : "quiet" as BoardTone, active,
    items: [
      { label: "Hexagram", value: name.full },
      { label: "Upper trigram", value: trigramOf(lines.slice(3, 6)) },
      { label: "Lower trigram", value: trigramOf(lines.slice(0, 3)) },
      { label: "Lines", value: [...lines].reverse().map(yinYangLabel).join(" · ") },
      { label: "Yuan Tang line", value: `Line ${marked}` },
    ],
  };
}

function birthYearOf(result: StudyResult, input: StudyInput) {
  const year = Number(input.birthDate.slice(0, 4)) || currentYear();
  // The year pillar turns at Start of Spring: a January birth can still belong to the previous year.
  return `${stemAtIndex(year - 4)}${branchAtIndex(year - 4)}` === result.pillars[0] ? year : year - 1;
}

function heluoBoard(result: StudyResult, input: StudyInput) {
  const birthYear = birthYearOf(result, input);
  const chart = heLuo({ pillars: result.pillars, gender: input.gender ?? "yang", hourBranch: result.pillars[3].charAt(1), birthYear, currentYear: currentYear() });
  const cells = [
    hexagramCell("former-hexagram", "Former Heaven hexagram", chart.former.name, chart.former.lines, chart.former.yuanTang, !chart.current || chart.current.stage === "先天"),
    hexagramCell("later-hexagram", "Later Heaven hexagram", chart.later.name, chart.later.lines, chart.later.yuanTang, chart.current?.stage === "后天"),
  ];
  return {
    kind: "spread" as const,
    label: "He Luo numerology board",
    cells,
    sections: [
      { id: "heluo-numbers", title: "Heaven and earth numbers", lead: "Each stem and branch takes its He Tu number; odd numbers add to the heaven number, even numbers to the earth number", items: [
        ...result.pillars.map((pillar, index) => ({ label: pillarRoles[index], value: `${pillar} · ${chart.numbers.slice(index * 3, index * 3 + 3).join(" · ")}` })),
        { label: "Heaven number", value: `${chart.heavenTotal} → ${chart.heavenNumber} · ${chart.heavenTrigram}` },
        { label: "Earth number", value: `${chart.earthTotal} → ${chart.earthNumber} · ${chart.earthTrigram}` },
      ] },
      { id: "heluo-yuantang", title: "Yuan Tang", lead: "Yang-hour births count the yang lines and yin-hour births the yin lines to find the Yuan Tang line", items: [{ label: "Hour branch", value: result.pillars[3].charAt(1) }, { label: "Yuan Tang line", value: `Line ${chart.former.yuanTang}` }, { label: "Later Heaven hexagram", value: chart.later.name.full }] },
      { id: "heluo-periods", title: "Life periods", lead: "From the Yuan Tang line upward, a yang line governs nine years and a yin line six; then the Later Heaven hexagram continues", items: chart.periods.map((period) => ({ label: `Ages ${period.from}–${period.to}`, value: `${period.stage === "先天" ? "Former Heaven hexagram" : "Later Heaven hexagram"} · Line ${period.line} · ${yinYangLabel(period.yang)}` })) },
      { id: "heluo-current", title: "Current period", lead: "The period that contains this year", items: chart.current ? [{ label: "Age", value: String(chart.currentAge) }, { label: `Ages ${chart.current.from}–${chart.current.to}`, value: `${chart.current.stage === "先天" ? "Former Heaven hexagram" : "Later Heaven hexagram"} · Line ${chart.current.line}` }] : [{ label: "Age", value: String(chart.currentAge) }] },
    ],
  };
}

function tiebanBoard(result: StudyResult, input: StudyInput) {
  const chart = tieBan({ pillars: result.pillars, birthTime: input.birthTime });
  const cells = [
    { id: "tieban-hexagram", title: "Tai Xuan hexagram", subtitle: chart.name.full, tone: "gold" as BoardTone, active: true, items: [
      { label: "Hexagram", value: chart.name.full },
      { label: "Upper trigram", value: chart.upper },
      { label: "Lower trigram", value: chart.lower },
      { label: "Stem total", value: String(chart.stemTotal) },
      { label: "Branch total", value: String(chart.branchTotal) },
    ] },
    { id: "tieban-quarter", title: "Birth quarter", subtitle: `${chart.hourBranch} · Quarter ${chart.quarter}`, tone: "quiet" as BoardTone, active: false, items: [
      { label: "Hour branch", value: chart.hourBranch },
      { label: "Quarter", value: `Quarter ${chart.quarter}` },
      { label: "Trigram", value: chart.quarterTrigram },
      { label: "Time range", value: `${chart.quarters[chart.quarter - 1].from}–${chart.quarters[chart.quarter - 1].to}` },
    ] },
  ];
  return {
    kind: "spread" as const,
    label: "Tie Ban number framework",
    cells,
    sections: [
      { id: "tieban-numbers", title: "Tai Xuan numbers", lead: "Each stem and branch takes its Tai Xuan number, from nine down to four", items: chart.perPillar.map((item, index) => ({ label: pillarRoles[index], value: `${item.pillar} · ${item.stem} · ${item.branch}` })) },
      { id: "tieban-quarters", title: "Eight quarters of the birth hour", lead: "The two-hour period is divided into eight quarters of fifteen minutes to fix the birth moment", items: chart.quarters.map((quarter) => ({ label: `Quarter ${quarter.index}`, value: `${quarter.from}–${quarter.to} · ${quarter.trigram}` })) },
      { id: "tieban-scope", title: "Scope", lead: "This page gives the number framework only; the verse book used to look up the numbers is not included", items: [{ label: "Verse texts", value: "Not included" }] },
    ],
  };
}

const ZERI_PURPOSE_EN: Record<string, string> = { wedding: "Wedding", engagement: "Engagement", move: "Moving house", opening: "Opening a business", contract: "Signing a contract", travel: "Travel", renovation: "Renovation", prayer: "Prayer and offerings" };
const ZERI_EXCLUSION_EN: Record<ZeriExclusion, string> = { purpose: "Purpose not favoured that day", "personal-year": "Clashes your zodiac year branch", "personal-day": "Clashes your day branch", "year-break": "Year break", "month-break": "Month break", "si-li": "Four Separations", "si-jue": "Four Extinctions", yanggong: "Yang Gong taboo day", sanniang: "San Niang day (weddings)" };
const STAR_EN: Record<string, string> = { 天德: "Heavenly Virtue", 月德: "Monthly Virtue", 天德合: "Heavenly Virtue Union", 月德合: "Monthly Virtue Union", 天赦: "Heavenly Pardon", 天恩: "Heavenly Grace", 母仓: "Mother Granary", 天喜: "Heavenly Joy" };
const lunarLabel = (day: { lunarMonth: number; lunarDay: number; lunarLeap: boolean }) => `${day.lunarLeap ? "Leap lunar" : "Lunar"} month ${day.lunarMonth} day ${day.lunarDay}`;
const WEEKDAY_EN = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

function zeriBoard(result: StudyResult, input: StudyInput) {
  const purpose = (Object.keys(ZERI_PURPOSE_EN).includes(input.zeriPurpose ?? "") ? input.zeriPurpose : "wedding") as ActivityKey;
  const start = /^\d{4}-\d{2}-\d{2}$/.test(input.zeriStart ?? "") ? input.zeriStart! : new Date().toISOString().slice(0, 10);
  const selection = selectDays({ purpose, pillars: result.pillars, start, days: input.zeriDays ?? 60 });
  const cells = selection.top.map((day, index) => ({
    id: `day-${index + 1}`,
    title: day.iso,
    subtitle: `${day.dayGanZhi} · ${lunarLabel(day)}`,
    tone: index === 0 ? "gold" as BoardTone : "quiet" as BoardTone,
    active: index === 0,
    items: [
      { label: "Weekday", value: WEEKDAY_EN[day.weekday] },
      { label: "Day pillar", value: day.dayGanZhi },
      { label: "Lunar", value: lunarLabel(day) },
      { label: "Day officer", value: day.officer },
      { label: "Day spirit", value: `${day.spirit} · ${day.spiritType === "黄道" ? "Yellow path" : "Black path"}` },
      { label: "Lucky stars", value: day.stars.length ? day.stars.map((star) => STAR_EN[star] ?? star).join(" · ") : "—" },
      { label: "Favourable element", value: day.favourableElement ? ELEMENT_EN[day.dayElement] : "—" },
      { label: "Good hours", value: day.hours.length ? day.hours.map((hour) => `${hour.branch} ${hour.from}–${hour.to}`).join(" · ") : "—" },
      { label: "Score", value: String(day.score) },
    ],
  }));
  return {
    kind: "comparison" as const,
    label: "Personal date selection",
    cells: cells.length ? cells : [{ id: "day-none", title: "No suitable day", subtitle: ZERI_PURPOSE_EN[purpose], tone: "quiet" as BoardTone, active: true, items: [{ label: "Days checked", value: String(selection.checked) }] }],
    sections: [
      { id: "zeri-frame", title: "Selection frame", lead: "Purpose, search window and the parts of your chart that are checked", items: [
        { label: "Purpose", value: ZERI_PURPOSE_EN[purpose] },
        { label: "From", value: start },
        { label: "Days checked", value: String(selection.checked) },
        { label: "Suitable days", value: String(selection.chosen.length) },
        { label: "Year branch", value: selection.yearBranch },
        { label: "Day branch", value: selection.dayBranch },
        { label: "Day master strength", value: selection.favour.verdict },
        { label: "Favourable elements", value: selection.favour.elements.length ? selection.favour.elements.map((element) => ELEMENT_EN[element]).join(" · ") : "—" },
      ] },
      { id: "zeri-excluded", title: "Days left out", lead: "A day is left out for any one of these reasons", items: (Object.keys(ZERI_EXCLUSION_EN) as ZeriExclusion[]).filter((key) => selection.counts[key]).map((key) => ({ label: ZERI_EXCLUSION_EN[key], value: String(selection.counts[key]) })) },
      { id: "zeri-all", title: "All suitable days", lead: "Every day in the window that passed all checks, by date", items: [...selection.chosen].sort((a, b) => a.iso.localeCompare(b.iso)).slice(0, 24).map((day) => ({ label: day.iso, value: `${day.dayGanZhi} · ${day.officer} · ${day.spiritType === "黄道" ? "Yellow path" : "Black path"} · ${day.score}` })) },
    ],
  };
}

const ERA_EN: Record<string, string> = { 甲子元: "Jia Zi era", 丙子元: "Bing Zi era", 戊子元: "Wu Zi era", 庚子元: "Geng Zi era", 壬子元: "Ren Zi era" };
const TAIYI_GRID = [9, 2, 7, 4, 5, 6, 3, 8, 1];
function taiyiBoard(result: StudyResult, input: StudyInput) {
  const year = birthYearOf(result, input);
  const chart = taiYiYear(year);
  const cells = TAIYI_GRID.map((palace) => ({
    id: `palace-${palace}`,
    title: `Palace ${palace}`,
    subtitle: palace === 5 ? "Center" : `${TAIYI_PALACE_NAME[palace]} · ${TAIYI_PALACE_DIRECTION[palace]}`,
    tone: palace === chart.palace ? "gold" as BoardTone : "quiet" as BoardTone,
    active: palace === chart.palace,
    items: palace === 5
      ? [{ label: "Tai Yi", value: "Never enters the centre" }]
      : [
        { label: "Trigram", value: TAIYI_PALACE_NAME[palace] },
        { label: "Direction", value: TAIYI_PALACE_DIRECTION[palace] },
        { label: "Tai Yi", value: palace === chart.palace ? `Year ${chart.yearInPalace} of 3` : "—" },
      ],
  }));
  return {
    kind: "nine-palace" as const,
    label: "Tai Yi yearly reckoning board",
    cells,
    sections: [
      { id: "taiyi-year", title: "Year reckoning", lead: "Accumulated years from the Tai Yi epoch (10,153,917 years before year 0)", items: [{ label: "Year", value: `${chart.year} · ${chart.ganzhi}` }, { label: "Accumulated years", value: chart.accumulated.toLocaleString("en-US") }, { label: "Round", value: `${chart.round} / 24` }] },
      { id: "taiyi-palace", title: "Tai Yi palace", lead: "Tai Yi stays three years in each of the eight outer palaces and never enters the centre", items: [{ label: "Palace", value: `Palace ${chart.palace}` }, { label: "Trigram", value: chart.palaceName }, { label: "Direction", value: chart.direction }, { label: "Year in palace", value: `Year ${chart.yearInPalace} of 3` }, { label: "Next palace", value: String(chart.nextPalaceYear) }] },
      { id: "taiyi-era", title: "Five eras", lead: "Five eras of seventy-two years make one 360-year cycle", items: [{ label: "Era", value: ERA_EN[chart.era] ?? chart.era }, { label: "Year in era", value: `${chart.yearInEra} / 72` }] },
    ],
  };
}

/** Birth time unknown: blank the hour pillar everywhere it shows and recount the elements from three pillars. */
function hideHourPillar(configuration: { cells: Array<{ id: string; title: string; subtitle?: string; tone?: BoardTone; items: Array<{ label: string; value: string; tone?: BoardTone }> }>; sections: Array<{ id: string; title: string; lead: string; items: Array<{ label: string; value: string }> }> }, result: StudyResult) {
  const hour = result.pillars[3] ?? "";
  for (const cell of configuration.cells) {
    if (cell.id === "pillar-3" || cell.title === "Hour pillar") {
      cell.subtitle = "Hour unknown";
      cell.tone = "quiet";
      cell.items = cell.items.map((item) => ({ label: item.label, value: "—" }));
    }
  }
  const three = result.pillars.slice(0, 3);
  for (const section of configuration.sections) {
    if (section.id === "hour-markers") section.items = [{ label: "Hour pillar", value: "—" }];
    if (section.id === "five-elements") {
      const counts = new Map(["Wood", "Fire", "Earth", "Metal", "Water"].map((name) => [name, 0]));
      for (const character of three.join("")) { const element = stemElements[character] ?? branchElements[character]; if (element) counts.set(element, (counts.get(element) ?? 0) + 1); }
      section.items = [...counts].map(([label, count]) => ({ label, value: String(count) }));
    }
    section.items = section.items.map((item) => (item.label.startsWith("Hour pillar") || (hour && item.value === hour && item.label.includes("Hour")) ? { label: item.label, value: "—" } : item));
  }
  configuration.sections.unshift({ id: "birth-time-unknown", title: "Birth time unknown", lead: "The hour pillar is not calculated; readings that depend on it are limited", items: [{ label: "Hour pillar", value: "Not calculated" }, { label: "Pillars used", value: three.join(" · ") }] });
}

export function createCompleteChart(input: StudyInput): CompleteChart {
  const result = createStudyResult(input);
  const tool = input.module;
  const gender = input.gender ?? "yang";
  const configuration = tool === "bazi" || tool === "detail" ? baziBoard(result, gender, tool === "detail")
    : tool === "ziwei" ? ziweiBoard(result, gender, input)
      : tool === "qizheng" ? qizhengBoard(result)
        : tool === "toolkit-natal" ? natalBoard(result)
          : tool === "liuyao" || tool === "toolkit-iching" ? liuyaoBoard(result)
            : tool === "qimen" ? qimenBoard(result)
              : tool === "daliuren" ? daliurenBoard(result)
                : tool === "daily" ? dailyRhythmBoard(result, input)
                  : tool === "toolkit-time" ? timingBoard(result)
                    : tool === "toolkit-elements" ? elementsBoard(result)
                      : tool === "toolkit-dream" ? dreamBoard(result, input)
                        : tool === "toolkit-name" ? nameBoard(result, input)
                          : tool === "mirror" ? spreadBoard(result, input, true)
                            : tool === "toolkit-tarot" ? spreadBoard(result, input, false)
                              : tool === "toolkit-meihua" ? meihuaBoard(result, input)
                                : tool === "toolkit-fengshui" ? fengshuiBoard(result, input)
                                  : tool === "meihua" ? meihuaBoard(result, input)
                                    : tool === "jinkoujue" ? jinkoujueBoard(result, input)
                                      : tool === "heluo" ? heluoBoard(result, input)
                                        : tool === "tieban" ? tiebanBoard(result, input)
                                          : tool === "taiyi" ? taiyiBoard(result, input)
                                            : tool === "zeri" ? zeriBoard(result, input)
                              : comparisonBoard(result, input, tool === "compatibility" ? "Compatibility study map" : tool === "wenshi" ? "Inquiry synthesis board" : "Synthesis study map");
  if (input.timeUnknown) hideHourPillar(configuration, result);
  return {
    tool,
    calendar: result.calendar,
    pillars: result.pillars,
    board: { kind: configuration.kind, label: configuration.label, cells: configuration.cells },
    sections: [calculationBasis(result), ...configuration.sections],
    // The birth-time note goes first so it survives the server-side cap on the number of facts.
    sourceFacts: [...(input.timeUnknown ? ["Birth time unknown: the hour pillar is NOT known (any hour shown is a placeholder). Do not interpret the hour pillar, hour-based stars or anything classically read from the hour (children, later life); say plainly that these parts are limited because the birth time is unknown."] : []), ...result.sources, `Element balance: ${elementLine(result)}`],
    inputSummary: { focus: input.focus, place: input.place?.trim() || "—", version: input.version, name: input.name, companionName: input.companionName },
  };
}

export function createInterpretationRequest({ tool, locale, question, chart }: Omit<InterpretationRequest, "disclaimer">): InterpretationRequest {
  return {
    tool,
    locale,
    question,
    chart,
    disclaimer: "Cultural-learning and reflection reference only; never a deterministic prediction or guarantee.",
  };
}

const readingLocaleCopy: Record<string, {
  handoff: string;
  summary: (question: string, board: string, focal: string) => string;
  orientation: (lunar: string, naYin: string) => string;
  thread: (title: string, values: string) => string;
  next: string;
  headings: [string, string, string];
  followUps: string[];
}> = {
  en: {
    handoff: "interpretation handoff",
    summary: (question, board, focal) => `Hold “${question}” beside the ${board.toLowerCase()}. The highlighted study position is ${focal}.`,
    orientation: (lunar, naYin) => `${lunar} · ${naYin}. Start by observing the board before choosing a meaning.`,
    thread: (title, values) => `${title}: ${values}.`,
    next: "Name one action within your control, wait for more context when needed, and retain your own judgement.",
    headings: ["Chart orientation", "Reading thread", "Grounded next step"],
    followUps: ["What is already clear?", "What needs more context?", "What is one modest action you can take?"],
  },
  "zh-Hans": {
    handoff: "解读交接",
    summary: (question, board, focal) => `将“${question}”放在「${board}」旁观察；当前盘的聚焦位置是「${focal}」。`,
    orientation: (lunar, naYin) => `${lunar} · ${naYin}。先看盘面结构，再安放意义。`,
    thread: (title, values) => `${title}：${values}。`,
    next: "选择一件自己能够掌握的小行动；需要时等待更多信息，决定始终由你自己做出。",
    headings: ["盘面定位", "解读线索", "可落实的下一步"],
    followUps: ["此刻已经清楚的是什么？", "还需要哪些信息？", "下一步能做的一件小事是什么？"],
  },
  "zh-Hant": {
    handoff: "解讀交接",
    summary: (question, board, focal) => `將「${question}」放在「${board}」旁觀察；目前盤的聚焦位置是「${focal}」。`,
    orientation: (lunar, naYin) => `${lunar} · ${naYin}。先看盤面結構，再安放意義。`,
    thread: (title, values) => `${title}：${values}。`,
    next: "選擇一件自己能掌握的小行動；需要時等待更多資訊，決定始終由你自己做出。",
    headings: ["盤面定位", "解讀線索", "可落實的下一步"],
    followUps: ["此刻已經清楚的是什麼？", "還需要哪些資訊？", "下一步能做的一件小事是什麼？"],
  },
  ja: {
    handoff: "解釈の受け渡し",
    summary: (question, board, focal) => `「${question}」を「${board}」と並べて見ます。現在の盤で焦点となる位置は「${focal}」です。`,
    orientation: (lunar, naYin) => `${lunar}・${naYin}。意味を急がず、まず盤面の配置を観察します。`,
    thread: (title, values) => `${title}：${values}。`,
    next: "自分で選べる小さな行動を一つ言葉にし、必要なら情報を待ってください。選択の主体はあなたです。",
    headings: ["盤面の配置", "読みの糸口", "現実的な次の一歩"],
    followUps: ["すでに明らかなことは何ですか？", "さらに必要な文脈は何ですか？", "今できる小さな一歩は何ですか？"],
  },
  ko: {
    handoff: "해석 전달",
    summary: (question, board, focal) => `“${question}”을(를) 「${board}」와 함께 살펴봅니다. 현재 판면의 초점 위치는 「${focal}」입니다.`,
    orientation: (lunar, naYin) => `${lunar} · ${naYin}. 의미를 정하기 전에 먼저 판면의 배치를 관찰하세요.`,
    thread: (title, values) => `${title}: ${values}.`,
    next: "내가 통제할 수 있는 작은 행동 하나를 정하고, 필요하다면 더 많은 맥락을 기다리세요. 선택의 주체는 당신입니다.",
    headings: ["판면의 위치", "해석의 실마리", "현실적인 다음 단계"],
    followUps: ["이미 분명한 것은 무엇인가요?", "어떤 맥락이 더 필요한가요?", "지금 할 수 있는 작은 행동은 무엇인가요?"],
  },
  vi: {
    handoff: "bàn giao diễn giải",
    summary: (question, board, focal) => `Đặt “${question}” bên cạnh ${board}. Vị trí trọng tâm của bàn hiện tại là ${focal}.`,
    orientation: (lunar, naYin) => `${lunar} · ${naYin}. Hãy quan sát cấu trúc bàn cục trước khi gán ý nghĩa.`,
    thread: (title, values) => `${title}: ${values}.`,
    next: "Gọi tên một hành động nhỏ bạn có thể chủ động làm, chờ thêm bối cảnh khi cần, và giữ quyền lựa chọn của mình.",
    headings: ["Định vị bàn cục", "Mạch diễn giải", "Bước tiếp theo thực tế"],
    followUps: ["Điều gì đã rõ?", "Cần thêm bối cảnh nào?", "Một bước nhỏ bạn có thể làm là gì?"],
  },
  th: {
    handoff: "จุดส่งต่อคำอธิบาย",
    summary: (question, board, focal) => `วางคำถาม “${question}” ไว้คู่กับ ${board} ตำแหน่งโฟกัสของกระดานตอนนี้คือ ${focal}`,
    orientation: (lunar, naYin) => `${lunar} · ${naYin} เริ่มจากสังเกตโครงสร้างของกระดานก่อนค่อยให้ความหมาย`,
    thread: (title, values) => `${title}: ${values}`,
    next: "เลือกการกระทำเล็ก ๆ ที่คุณควบคุมได้ รอข้อมูลเพิ่มเมื่อจำเป็น และคงสิทธิ์ในการตัดสินใจไว้กับตัวเอง",
    headings: ["ตำแหน่งบนกระดาน", "เส้นทางการอ่าน", "ก้าวต่อไปที่ทำได้จริง"],
    followUps: ["อะไรที่ชัดเจนอยู่แล้ว?", "ยังต้องการบริบทอะไรเพิ่ม?", "ก้าวเล็ก ๆ ที่ทำได้ตอนนี้คืออะไร?"],
  },
};

export function createLocalInterpretation(request: InterpretationRequest): InterpretationResponse {
  const focalCell = request.chart.board.cells.find((cell) => cell.active) ?? request.chart.board.cells[0];
  const question = request.question.trim() || request.chart.inputSummary.focus || "this current study";
  const text = readingLocaleCopy[request.locale] ?? readingLocaleCopy.en;
  const values = focalCell?.items.map((item) => `${item.label} ${item.value}`).join(" · ") ?? "";
  return {
    title: `${request.tool} · ${text.handoff}`,
    summary: text.summary(question, request.chart.board.label, focalCell?.title ?? "the current chart"),
    sections: [
      { title: text.headings[0], text: text.orientation(request.chart.calendar.lunar, request.chart.calendar.naYin) },
      { title: text.headings[1], text: focalCell ? text.thread(focalCell.title, values) : text.thread(request.chart.board.label, "—") },
      { title: text.headings[2], text: text.next },
    ],
    followUps: text.followUps,
  };
}
