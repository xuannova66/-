"use client";
// Extra sections of the "All study methods" menu: the toolkit's individual tools and the learning
// resources (library, video courses, workshop), plus one-line descriptions for each study method.
import type { Locale } from "./site-content";
import type { AppRoute, ToolkitKey } from "./study-suite";
import { toolkitItems } from "./study-suite";
import { toolkitName } from "./toolkit-copy";
import { pathFor } from "./study-navigation";
import { workshopHref } from "./contact-config";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

/** A tool chosen from the menu, picked up by the toolkit page when it opens. */
let pendingToolkitTool: ToolkitKey | null = null;
/** Open the toolkit on a given tool (used by the menu and the beginner guide). */
export function setPendingToolkitTool(key: ToolkitKey) { pendingToolkitTool = key; }
export function takePendingToolkitTool(): ToolkitKey | null {
  const fromMenu = pendingToolkitTool;
  pendingToolkitTool = null;
  if (fromMenu) return fromMenu;
  if (typeof window === "undefined") return null;
  const fromUrl = new URLSearchParams(window.location.search).get("tool");
  // Plum blossom and the home analysis became full study methods: send old toolkit links to their pages.
  const moved: Record<string, string> = { meihua: "meihua", fengshui: "zhuzhai" };
  if (fromUrl && moved[fromUrl] && /\/toolkit\/?$/.test(window.location.pathname)) {
    window.location.replace(window.location.pathname.replace(/toolkit\/?$/, moved[fromUrl]));
    return null;
  }
  return toolkitItems.some((item) => item.key === fromUrl) ? (fromUrl as ToolkitKey) : null;
}

const text = {
  toolkit: L("STUDY REFERENCES", "百宝袋 · 研习常备", "百寶袋 · 研習常備", "百宝袋・研究の常備", "도구함 · 학습 상비", "BÁCH BẢO · TRA CỨU", "คลังศาสตร์ · ข้อมูลอ้างอิง"),
  resources: L("LEARN MORE", "学习资源", "學習資源", "学びの資料", "학습 자료", "TÀI NGUYÊN HỌC", "แหล่งเรียนรู้"),
  allTools: L("Open the toolkit", "进入百宝袋", "進入百寶袋", "百宝袋を開く", "도구함 열기", "Mở bách bảo", "เปิดคลังศาสตร์"),
  library: L("Wisdom library", "藏经阁", "藏經閣", "知恵の書庫", "지혜 도서관", "Thư viện tri thức", "คลังความรู้"),
  libraryLead: L("23 classics to read in full", "23 部典籍在线全文", "23 部典籍線上全文", "古典23冊を全文で", "고전 23권 전문", "23 kinh điển toàn văn", "ตำรา 23 เล่มฉบับเต็ม"),
  courses: L("Video courses", "视频课程", "影片課程", "動画講座", "영상 강좌", "Khóa học video", "คอร์สวิดีโอ"),
  coursesLead: L("Watch free after registering", "免费注册后观看", "免費註冊後觀看", "無料登録で視聴", "무료 가입 후 시청", "Đăng ký miễn phí để xem", "สมัครฟรีแล้วดูได้"),
  workshop: L("Workshop", "器物坊", "器物坊", "工房", "공방", "Xưởng", "โรงงานศิลป์"),
  guide: L("Beginner's guide", "新手指南", "新手指南", "初心者ガイド", "초보자 가이드", "Hướng dẫn cho người mới", "คู่มือมือใหม่"),
  guideLead: L("How to start and which method to pick", "怎么开始、选哪个方法", "怎麼開始、選哪個方法", "始め方と方法の選び方", "시작하는 법과 방법 고르기", "Cách bắt đầu và chọn phương pháp", "เริ่มอย่างไรและเลือกวิธีไหน"),
  workshopLead: L("Cultural objects", "文化器物", "文化器物", "文化の品", "문화 공예품", "Vật phẩm văn hóa", "ของใช้เชิงวัฒนธรรม"),
};

export function MethodDrawerExtras({ locale, navigate, mark }: { locale: Locale; navigate: (route: AppRoute) => void; mark: (value: string, locale: Locale) => string }) {
  const go = (route: AppRoute) => (event: React.MouseEvent) => {
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return;
    event.preventDefault(); navigate(route);
  };
  return <>
    <section className="method-drawer-tools">
      <small>{text.toolkit[locale]}</small>
      <div>
        {toolkitItems.map((item) => <a key={item.key} className="nav-link" href={`${pathFor(locale, "toolkit")}?tool=${item.key}`} onClick={(event) => { if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return; event.preventDefault(); pendingToolkitTool = item.key; navigate("toolkit"); }}>
          <i>{mark(item.mark, locale)}</i><span><b>{toolkitName(item.key, locale)}</b></span>
        </a>)}
        <a className="nav-link" href={pathFor(locale, "toolkit")} onClick={go("toolkit")}><i>{mark("袋", locale)}</i><span><b>{text.allTools[locale]} →</b></span></a>
      </div>
    </section>
    <section className="method-drawer-resources">
      <small>{text.resources[locale]}</small>
      <div>
        <a className="nav-link" href={pathFor(locale, "library")} onClick={go("library")}><i>{mark("藏", locale)}</i><span><b>{text.library[locale]}</b><em>{text.libraryLead[locale]}</em></span></a>
        <a className="nav-link" href={pathFor(locale, "guide")} onClick={go("guide")}><i>{mark("新", locale)}</i><span><b>{text.guide[locale]}</b><em>{text.guideLead[locale]}</em></span></a>
        <a className="nav-link" href={pathFor(locale, "courses")} onClick={go("courses")}><i>{mark("課", locale)}</i><span><b>{text.courses[locale]}</b><em>{text.coursesLead[locale]}</em></span></a>
        <a className="nav-link" href={workshopHref(locale)}><i>{mark("器", locale)}</i><span><b>{text.workshop[locale]}</b><em>{text.workshopLead[locale]}</em></span></a>
      </div>
    </section>
  </>;
}
