"use client";
// Social and support contacts shown as icons only (no account names on the page).
// Links open the channel; KakaoTalk has no public web link, so its icon copies the number.
import { useState } from "react";
import { publicContacts } from "./contact-config";

export function ContactIcon({ label }: { label: string }) {
  if (label === "Telegram") return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m20.7 3.6-3 15.2c-.2 1.1-.8 1.4-1.7.9l-4.9-3.6-2.4 2.3c-.3.3-.5.5-1 .5l.4-5 9.1-8.2c.4-.4-.1-.6-.6-.2L5.4 12.6.6 11.1c-1-.3-1-1 .2-1.5L19.5 2.4c.9-.3 1.6.2 1.2 1.2Z" fill="currentColor" /></svg>;
  if (label === "X") return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18.9 2.8h3.7l-8 9.1 9.4 9.3h-7.4l-5.8-5.7-5 5.7H2.1l8.6-9.8-9-8.6h7.6l5.2 5.1 4.4-5.1Zm-1.3 16.2h2L8.1 4.9H6L17.6 19Z" fill="currentColor" /></svg>;
  if (label === "WhatsApp") return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.4a8.5 8.5 0 0 0-7.3 12.8L3.5 20.6l4.5-1.2A8.5 8.5 0 1 0 12 3.4Zm0 14.8a6.3 6.3 0 0 1-3.2-.9l-.3-.2-2.7.7.7-2.6-.2-.3A6.3 6.3 0 1 1 12 18.2Zm3.5-4.7c-.2-.1-1.2-.6-1.4-.6s-.3-.1-.5.2-.5.6-.6.7-.2.2-.4.1a5.2 5.2 0 0 1-1.5-.9 5.8 5.8 0 0 1-1-1.3c-.1-.2 0-.3.1-.4l.3-.3.2-.3c.1-.1 0-.3 0-.4l-.6-1.3c-.2-.4-.3-.4-.5-.4h-.4c-.1 0-.4.1-.6.3s-.8.8-.8 2 .8 2.3.9 2.5c.1.2 1.7 2.6 4.1 3.6.6.2 1 .4 1.4.5.6.2 1.2.2 1.6.1.5-.1 1.2-.5 1.4-1s.2-.9.1-1-.2-.2-.4-.3Z" fill="currentColor" /></svg>;
  if (label === "LINE") return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.8 10.6c0-4-4-7.3-8.8-7.3S3.2 6.6 3.2 10.6c0 3.6 3.2 6.6 7.5 7.2l.3 2.9 2.7-2.5c4.1-.6 7.1-3.7 7.1-7.6Zm-12.5 2.1H6.6V8.5h1v3.2h.7v1Zm2.5 0H9.1V8.5h1v3.2h.7v1Zm2.4 0h-1V8.5h1v4.2Zm4.1 0h-1l-1.4-2v2h-1V8.5h1l1.4 2v-2h1v4.2Z" fill="currentColor" /></svg>;
  if (label === "KakaoTalk") return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.2c-5 0-9 3.2-9 7.2 0 2.5 1.8 4.8 4.5 6.1l-.8 4.1 4.1-2.7h1.2c5 0 9-3.2 9-7.2s-4-7.5-9-7.5Z" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/><circle cx="8.5" cy="10.5" r=".8" fill="currentColor"/><circle cx="12" cy="10.5" r=".8" fill="currentColor"/><circle cx="15.5" cy="10.5" r=".8" fill="currentColor"/></svg>;
  return <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2" fill="none" stroke="currentColor" strokeWidth="1.8" /><path d="m4.5 7 7.5 5.7L19.5 7" fill="none" stroke="currentColor" strokeWidth="1.8" /></svg>;
}

export function ContactIconRow({ className = "", copied = "✓" }: { className?: string; copied?: string }) {
  const [done, setDone] = useState("");
  const copy = async (label: string, value: string) => {
    try { await navigator.clipboard.writeText(value); setDone(label); window.setTimeout(() => setDone(""), 1800); } catch { /* clipboard blocked: nothing to show */ }
  };
  return <ul className={`contact-icons ${className}`.trim()}>{publicContacts.map((contact) => {
    const href = contact.label === "Email" ? `mailto:${contact.handle}` : contact.url;
    return <li key={contact.label}>{href
      ? <a href={href} aria-label={contact.label} title={contact.label} {...(href.startsWith("http") ? { target: "_blank", rel: "noreferrer" } : {})}><ContactIcon label={contact.label} /></a>
      : <button type="button" aria-label={contact.label} title={contact.label} onClick={() => void copy(contact.label, contact.handle)}><ContactIcon label={contact.label} />{done === contact.label && <em role="status">{copied}</em>}</button>}</li>;
  })}</ul>;
}
