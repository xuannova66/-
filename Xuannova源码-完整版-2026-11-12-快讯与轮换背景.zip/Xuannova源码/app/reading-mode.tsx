"use client";
// 普通版 / 专业版: everyday readers see a short plain-language gloss beside chart terms; experts see the terms only.
// Every term can still be tapped for a one-line explanation in both modes. The choice is remembered on this device.
import { useSyncExternalStore } from "react";
import type { Locale } from "./site-content";

export type ReadingMode = "beginner" | "expert";
const KEY = "xn.readingMode";
const listeners = new Set<() => void>();
let current: ReadingMode | null = null;
const read = (): ReadingMode => {
  if (current) return current;
  try { current = window.localStorage.getItem(KEY) === "expert" ? "expert" : "beginner"; } catch { current = "beginner"; }
  return current;
};
export function setReadingMode(mode: ReadingMode) {
  current = mode;
  try { window.localStorage.setItem(KEY, mode); } catch { /* storage unavailable */ }
  listeners.forEach((listener) => listener());
}
export function useReadingMode(): ReadingMode {
  return useSyncExternalStore((listener) => { listeners.add(listener); return () => { listeners.delete(listener); }; }, read, () => "beginner");
}

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });
const text = {
  label: L("Reading style", "阅读模式", "閱讀模式", "表示モード", "읽기 모드", "Chế độ đọc", "โหมดการอ่าน"),
  beginner: L("Everyday", "普通版", "普通版", "一般向け", "일반판", "Phổ thông", "ทั่วไป"),
  expert: L("Expert", "专业版", "專業版", "専門家向け", "전문판", "Chuyên sâu", "มืออาชีพ"),
  beginnerHint: L("Readings are written in everyday language, with plain notes beside any terms; tap an underlined term for more.", "解读用大白话来写，术语旁附通俗说明；点带下划线的术语可看详细解释。", "解讀用大白話來寫，術語旁附通俗說明；點帶底線的術語可看詳細解釋。", "解説はやさしい言葉で書き、用語の横に説明を付けます。下線の用語はタップで詳しく。", "해석을 쉬운 말로 쓰고, 용어 옆에 설명을 붙여요. 밑줄 친 용어를 누르면 자세히.", "Bài giải viết bằng lời dễ hiểu, có chú thích cạnh thuật ngữ; chạm thuật ngữ gạch chân để xem thêm.", "คำอธิบายใช้ภาษาง่าย ๆ มีหมายเหตุข้างศัพท์ แตะศัพท์ที่ขีดเส้นใต้เพื่อดูเพิ่ม"),
  expertHint: L("Readings keep the full traditional terminology and cite the chart evidence; tap a term if you need it.", "解读保留完整的传统术语，并列出盘面依据；需要时点术语查看解释。", "解讀保留完整的傳統術語，並列出盤面依據；需要時點術語查看解釋。", "解説は伝統用語をそのまま使い、盤の根拠も示します。必要なら用語をタップ。", "해석은 전통 용어를 그대로 쓰고 차트 근거를 보여 줘요. 필요하면 용어를 누르세요.", "Bài giải giữ nguyên thuật ngữ truyền thống và dẫn chứng lá số; chạm thuật ngữ khi cần.", "คำอธิบายใช้ศัพท์ดั้งเดิมครบ และอ้างหลักฐานจากผัง แตะศัพท์เมื่อต้องการ"),
  nextNote: L("Switching changes the notes now; a newly generated reading is written in the chosen style.", "切换后术语说明立即变化；新生成的解读会按所选版本的写法来写。", "切換後術語說明立即變化；新產生的解讀會按所選版本的寫法來寫。", "切り替えると用語の説明はすぐ変わり、新しく作る解説は選んだ書き方になります。", "전환하면 용어 설명은 바로 바뀌고, 새로 만드는 해석은 선택한 방식으로 써요.", "Đổi chế độ thì chú thích đổi ngay; bài giải tạo mới sẽ viết theo kiểu đã chọn.", "สลับแล้วหมายเหตุศัพท์เปลี่ยนทันที คำอธิบายที่สร้างใหม่จะเขียนตามแบบที่เลือก"),
};

export function ReadingModeToggle({ locale, inReading = false }: { locale: Locale; inReading?: boolean }) {
  const mode = useReadingMode();
  return <div className="reading-mode" role="group" aria-label={text.label[locale]}>
    <div className="reading-mode-switch">
      {(["beginner", "expert"] as const).map((item) => <button key={item} type="button" className={mode === item ? "is-on" : ""} aria-pressed={mode === item} onClick={() => setReadingMode(item)}>{text[item][locale]}</button>)}
    </div>
    <small>{(mode === "beginner" ? text.beginnerHint : text.expertHint)[locale]}{inReading && <> {text.nextNote[locale]}</>}</small>
  </div>;
}
