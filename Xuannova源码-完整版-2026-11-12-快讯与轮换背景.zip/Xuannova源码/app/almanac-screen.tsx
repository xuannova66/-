"use client";
// Daily almanac (黄历) page and the home "Today's almanac" card.
import { useEffect, useMemo, useState } from "react";
import type { Locale } from "./site-content";
import type { AppRoute } from "./study-suite";
import { pathFor } from "./study-navigation";
import { localizeBoardTerm } from "./complete-chart-board";
import { MonthlyOutlook } from "./monthly-outlook";
import { ActionPosterButton } from "./daily-posters";
import { activityKeys, almanacDay, almanacMonth, goodDaysFor, shiftIso, todayIso, type ActivityKey, type AlmanacDay } from "./almanac";
import { activityLabels, almanacText as T, festivalNames, fill, officerNames, ratingLabel, ratingNote } from "./almanac-copy";

const isChinese = (locale: Locale) => locale === "zh-Hans" || locale === "zh-Hant";
const showHan = (locale: Locale) => isChinese(locale) || locale === "ja";
const term = (value: string, locale: Locale) => localizeBoardTerm(value, locale);

function lunarLabel(day: AlmanacDay, locale: Locale) {
  const leap = day.lunarLeap ? T.leap[locale] : "";
  const value = fill(T.lunarValue[locale], { m: day.lunarMonth, d: day.lunarDay, mz: (locale === "zh-Hant" ? day.lunarMonthZh.replace("腊", "臘") : day.lunarMonthZh), dz: day.lunarDayZh });
  return isChinese(locale) ? `${leap}${value}` : `${leap}${value}`;
}

function dateLabel(iso: string, locale: Locale, options: Intl.DateTimeFormatOptions) {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, m - 1, d, 12).toLocaleDateString(locale, options);
}

function festivalLabel(name: string, locale: Locale) { return festivalNames[name]?.[locale] ?? (showHan(locale) ? name : null); }

function DayCard({ day, locale }: { day: AlmanacDay; locale: Locale }) {
  const [why, setWhy] = useState(false);
  const festivals = day.festivals.map((name) => festivalLabel(name, locale)).filter(Boolean) as string[];
  const list = (items: string[]) => (items.length ? items.map((item) => term(item, locale)) : [T.none[locale]]);
  return <article className={`almanac-day rating-${day.rating}`}>
    <header>
      <div className="almanac-date">
        <b>{day.day}</b>
        <span>{dateLabel(day.iso, locale, { year: "numeric", month: "long", weekday: "long" })}</span>
        <small>{T.lunar[locale]} {lunarLabel(day, locale)} · {fill(T.zodiacYear[locale], { z: term(day.zodiac, locale) })}</small>
        <small>{T.pillars[locale]}: {term(day.yearGanZhi, locale)} · {term(day.monthGanZhi, locale)} · {term(day.dayGanZhi, locale)}</small>
        {(day.solarTerm || festivals.length > 0) && <em>{[day.solarTerm ? `${T.solarTerm[locale]}: ${term(day.solarTerm, locale)}` : "", ...festivals.map((name) => `${T.festival[locale]}: ${name}`)].filter(Boolean).join(" · ")}</em>}
      </div>
      <div className="almanac-rating">
        <strong>{ratingLabel(day.rating, locale)}</strong>
        <p>{ratingNote(day.rating, locale)}</p>
        <button type="button" className="text-action" aria-expanded={why} onClick={() => setWhy(!why)}>{T.basis[locale]}: {fill(T.basisText[locale], { spirit: term(day.spirit, locale), type: (day.spiritType === "黄道" ? T.yellow : T.black)[locale], officer: officerNames[day.officer]?.[locale] ?? day.officer })} ?</button>
        {why && <p className="almanac-why">{T.basisHelp[locale]}</p>}
      </div>
    </header>
    <div className="almanac-yiji">
      <section className="yi"><h3>{T.yi[locale]}</h3><ul>{list(day.yi).map((item, index) => <li key={index}>{item}</li>)}</ul></section>
      <section className="ji"><h3>{T.ji[locale]}</h3><ul>{list(day.ji).map((item, index) => <li key={index}>{item}</li>)}</ul></section>
    </div>
    <div className="almanac-poster"><ActionPosterButton locale={locale} iso={day.iso} /></div>
    <section className="almanac-activities">
      <h3>{T.activitiesTitle[locale]}</h3>
      <ul>{activityKeys.map((key) => <li key={key} className={`state-${day.activities[key]}`}><span>{activityLabels[key][locale]}</span><b>{(day.activities[key] === "yes" ? T.stateYes : day.activities[key] === "no" ? T.stateNo : T.stateNeutral)[locale]}</b></li>)}</ul>
    </section>
    <div className="almanac-grid">
      <section>
        <h3>{T.clashTitle[locale]}</h3>
        <p>{fill(T.clashText[locale], { z: term(day.clashZodiac, locale), g: term(day.clashGanZhi, locale), d: term(day.shaDirection, locale) })}</p>
      </section>
      <section>
        <h3>{T.directionsTitle[locale]}</h3>
        <p className="almanac-muted">{T.directionsLead[locale]}</p>
        <dl className="almanac-directions">
          <div><dt>{T.joy[locale]}</dt><dd>{term(day.joy, locale)}</dd></div>
          <div><dt>{T.wealth[locale]}</dt><dd>{term(day.wealth, locale)}</dd></div>
          <div><dt>{T.fortune[locale]}</dt><dd>{term(day.fortune, locale)}</dd></div>
        </dl>
      </section>
    </div>
    <section className="almanac-hours">
      <h3>{T.hoursTitle[locale]}</h3>
      <p className="almanac-muted">{T.hoursLead[locale]}</p>
      <ol>{day.hours.map((hour) => <li key={hour.from} className={hour.good ? "good" : ""}><span>{hour.from}–{hour.to}</span><small>{showHan(locale) ? `${hour.branch}${locale === "ja" ? "の刻" : "时"}` : term(hour.branch, locale)}</small><b>{(hour.good ? T.good : T.bad)[locale]}</b></li>)}</ol>
    </section>
    {showHan(locale) && <p className="almanac-pengzu"><b>{T.pengZu[locale]}</b> {day.pengZu.join(" · ")}</p>}
  </article>;
}

function MonthGrid({ year, month, selected, locale, onPick, onMonth }: { year: number; month: number; selected: string; locale: Locale; onPick: (iso: string) => void; onMonth: (delta: number) => void }) {
  const days = useMemo(() => almanacMonth(year, month), [year, month]);
  const lead = (new Date(year, month - 1, 1).getDay() + 6) % 7; // Monday first
  const weekdays = Array.from({ length: 7 }, (_, index) => new Date(2024, 0, 1 + index).toLocaleDateString(locale, { weekday: "short" }));
  const today = todayIso();
  return <section className="almanac-month">
    <header>
      <button type="button" className="secondary-action" onClick={() => onMonth(-1)} aria-label="‹">‹</button>
      <h2>{T.calendarTitle[locale]} · {new Date(year, month - 1, 1).toLocaleDateString(locale, { year: "numeric", month: "long" })}</h2>
      <button type="button" className="secondary-action" onClick={() => onMonth(1)} aria-label="›">›</button>
    </header>
    <div className="almanac-legend"><span className="rating-good">{T.ratingGood[locale]}</span><span className="rating-ordinary">{T.ratingOrdinary[locale]}</span><span className="rating-care">{T.ratingCare[locale]}</span></div>
    <div className="almanac-cal" role="grid">
      {weekdays.map((name) => <b key={name} className="almanac-wd">{name}</b>)}
      {Array.from({ length: lead }, (_, index) => <span key={`pad-${index}`} />)}
      {days.map((day) => {
        const festival = day.festivals.map((name) => festivalLabel(name, locale)).find(Boolean);
        const sub = festival ?? (day.solarTerm ? term(day.solarTerm, locale) : showHan(locale) ? (day.lunarDay === 1 ? `${day.lunarLeap ? T.leap[locale] : ""}${day.lunarMonthZh}月` : day.lunarDayZh) : `${day.lunarMonth}/${day.lunarDay}`);
        return <button type="button" key={day.iso} className={`rating-${day.rating}${day.iso === selected ? " is-selected" : ""}${day.iso === today ? " is-today" : ""}`} onClick={() => onPick(day.iso)} aria-label={`${day.iso} ${ratingLabel(day.rating, locale)}`}>
          <b>{day.day}</b><small>{sub}</small><i aria-hidden="true" />
        </button>;
      })}
    </div>
  </section>;
}

function GoodDayFinder({ locale, onPick }: { locale: Locale; onPick: (iso: string) => void }) {
  const [activity, setActivity] = useState<ActivityKey>("wedding");
  const [offset, setOffset] = useState(0);
  const [base, setBase] = useState<{ y: number; m: number } | null>(null);
  useEffect(() => { const timer = window.setTimeout(() => { const now = new Date(); setBase({ y: now.getFullYear(), m: now.getMonth() + 1 }); }, 0); return () => window.clearTimeout(timer); }, []);
  if (!base) return null;
  const target = new Date(base.y, base.m - 1 + offset, 1);
  const y = target.getFullYear(); const m = target.getMonth() + 1;
  const days = goodDaysFor(activity, y, m);
  return <section className="almanac-finder">
    <h2>{T.finderTitle[locale]}</h2>
    <p className="almanac-muted">{T.finderLead[locale]}</p>
    <div className="almanac-finder-controls">
      <label><span>{T.finderPlan[locale]}</span><select value={activity} onChange={(event) => setActivity(event.target.value as ActivityKey)}>{activityKeys.map((key) => <option key={key} value={key}>{activityLabels[key][locale]}</option>)}</select></label>
      <label><span>{T.finderMonth[locale]}</span><select value={offset} onChange={(event) => setOffset(Number(event.target.value))}>{Array.from({ length: 12 }, (_, index) => { const date = new Date(base.y, base.m - 1 + index, 1); return <option key={index} value={index}>{date.toLocaleDateString(locale, { year: "numeric", month: "long" })}</option>; })}</select></label>
    </div>
    {days.length === 0 ? <p className="almanac-muted">{T.finderNone[locale]}</p> : <>
      <p className="almanac-count">{fill(T.finderCount[locale], { n: days.length })}</p>
      <ul className="almanac-finder-list">{days.map((day) => <li key={day.iso}><button type="button" className={`rating-${day.rating}`} onClick={() => onPick(day.iso)}>
        <b>{dateLabel(day.iso, locale, { month: "short", day: "numeric", weekday: "short" })}</b>
        <small>{ratingLabel(day.rating, locale)} · {T.clashTitle[locale]}: {term(day.clashZodiac, locale)}</small>
      </button></li>)}</ul>
    </>}
  </section>;
}

export function AlmanacScreen({ locale, navigate }: { locale: Locale; navigate: (route: AppRoute) => void }) {
  const [selected, setSelected] = useState<string | null>(null);
  const [view, setView] = useState<{ y: number; m: number } | null>(null);
  useEffect(() => {
    const timer = window.setTimeout(() => {
      const fromUrl = new URLSearchParams(window.location.search).get("date");
      const start = fromUrl && /^\d{4}-\d{2}-\d{2}$/.test(fromUrl) ? fromUrl : todayIso();
      setSelected(start); const [y, m] = start.split("-").map(Number); setView({ y, m });
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);
  const day = useMemo(() => (selected ? almanacDay(selected) : null), [selected]);
  const pick = (iso: string, scroll = true) => {
    setSelected(iso); const [y, m] = iso.split("-").map(Number); setView({ y, m });
    if (scroll) document.getElementById("almanac-day")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  return <section className="route-screen almanac-screen" data-route="almanac" aria-labelledby="almanac-title">
    <header className="almanac-hero">
      <p>{T.eyebrow[locale]}</p>
      <h1 id="almanac-title">{T.title[locale]}</h1>
      <span>{T.lead[locale]}</span>
    </header>
    {selected && day && view && <>
      <nav className="almanac-nav" id="almanac-day">
        <button type="button" className="secondary-action" onClick={() => pick(shiftIso(selected, -1), false)}>‹ {T.prev[locale]}</button>
        <label><span className="sr-only">{T.pick[locale]}</span><input type="date" value={selected} onChange={(event) => event.target.value && pick(event.target.value, false)} aria-label={T.pick[locale]} /></label>
        <button type="button" className="secondary-action" onClick={() => pick(todayIso(), false)}>{T.today[locale]}</button>
        <button type="button" className="secondary-action" onClick={() => pick(shiftIso(selected, 1), false)}>{T.next[locale]} ›</button>
      </nav>
      <DayCard day={day} locale={locale} />
      <MonthGrid year={view.y} month={view.m} selected={selected} locale={locale} onPick={(iso) => pick(iso)} onMonth={(delta) => { const date = new Date(view.y, view.m - 1 + delta, 1); setView({ y: date.getFullYear(), m: date.getMonth() + 1 }); }} />
      <GoodDayFinder locale={locale} onPick={(iso) => pick(iso)} />
    </>}
    <section className="almanac-how">
      <h2>{T.howTitle[locale]}</h2>
      {[T.how1, T.how2, T.how3, T.how4].map((item, index) => <p key={index}>{item[locale]}</p>)}
    </section>
    <section className="almanac-personal">
      <h2>{T.personalTitle[locale]}</h2>
      <MonthlyOutlook locale={locale} onMakeChart={() => navigate("bazi")} />
    </section>
  </section>;
}

/** Home: today's rating, a few favourable/avoid entries and the clash, with a link to the full almanac. */
export function HomeAlmanacCard({ locale, navigate }: { locale: Locale; navigate: (route: AppRoute) => void }) {
  const [day, setDay] = useState<AlmanacDay | null>(null);
  useEffect(() => { const timer = window.setTimeout(() => setDay(almanacDay(todayIso())), 0); return () => window.clearTimeout(timer); }, []);
  const go = (event: React.MouseEvent) => { if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return; event.preventDefault(); navigate("almanac"); };
  const few = (items: string[]) => (items.length ? items.slice(0, 4).map((item) => term(item, locale)).join(" · ") : T.none[locale]);
  return <section className="home-almanac" aria-labelledby="home-almanac-title">
    <header><p>{T.eyebrow[locale]}</p><h2 id="home-almanac-title">{T.homeTitle[locale]}</h2></header>
    {day ? <a className={`home-almanac-card rating-${day.rating}`} href={pathFor(locale, "almanac")} onClick={go}>
      <div><b>{dateLabel(day.iso, locale, { month: "long", day: "numeric", weekday: "short" })}</b><small>{T.lunar[locale]} {lunarLabel(day, locale)}</small></div>
      <strong>{ratingLabel(day.rating, locale)}</strong>
      <p><em>{T.yi[locale]}</em> {few(day.yi)}</p>
      <p><em>{T.ji[locale]}</em> {few(day.ji)}</p>
      <p><em>{T.clashTitle[locale]}</em> {term(day.clashZodiac, locale)} · {term(day.shaDirection, locale)}</p>
      <span>{T.homeMore[locale]} →</span>
    </a> : <a className="home-almanac-card" href={pathFor(locale, "almanac")} onClick={go}><span>{T.homeMore[locale]} →</span></a>}
  </section>;
}
