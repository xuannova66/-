/** Local-only quote primitives. This does not enable any payment chain or route.
 * A chain adapter must independently validate token identity, route and fees.
 */
import { displayAssetAmount, parseAssetAmount } from "./asset-amounts";

export type ExactOutputQuote = {
  outputUnits: bigint;
  inputUnits: bigint;
  maxInputUnits: bigint;
  estimatedDisplay: string;
  maximumDisplay: string;
  expiresAt: number;
};

export function makeExactOutputQuote(input: {
  outputAmount: string;
  outputDecimals: number;
  inputDecimals: number;
  quotedInputUnits: bigint;
  slippageBps: number;
  nowSeconds: number;
  quoteTtlSeconds: number;
  transferFee: "none-verified" | "unknown" | "fee-on-transfer";
}): ExactOutputQuote {
  // Unknown and taxed tokens must be verified and supported by a dedicated
  // execution route; padding a quote cannot make a taxed transfer safe.
  if (input.transferFee !== "none-verified") throw new Error("TOKEN_TRANSFER_FEE_UNSUPPORTED");
  if (!Number.isInteger(input.slippageBps) || input.slippageBps < 0 || input.slippageBps > 100) throw new Error("INVALID_SLIPPAGE");
  if (!Number.isSafeInteger(input.nowSeconds) || input.nowSeconds <= 0 || !Number.isSafeInteger(input.quoteTtlSeconds) || input.quoteTtlSeconds <= 0 || input.quoteTtlSeconds > 120 || !Number.isSafeInteger(input.nowSeconds + input.quoteTtlSeconds)) throw new Error("INVALID_QUOTE_EXPIRY");
  if (typeof input.quotedInputUnits !== "bigint" || input.quotedInputUnits <= 0n) throw new Error("INVALID_INPUT_QUOTE");
  const outputUnits = parseAssetAmount(input.outputAmount, input.outputDecimals);
  const maxInputUnits = (input.quotedInputUnits * BigInt(10_000 + input.slippageBps) + 9_999n) / 10_000n;
  return {
    outputUnits,
    inputUnits: input.quotedInputUnits,
    maxInputUnits,
    estimatedDisplay: displayAssetAmount(input.quotedInputUnits, input.inputDecimals),
    maximumDisplay: displayAssetAmount(maxInputUnits, input.inputDecimals),
    expiresAt: input.nowSeconds + input.quoteTtlSeconds,
  };
}
