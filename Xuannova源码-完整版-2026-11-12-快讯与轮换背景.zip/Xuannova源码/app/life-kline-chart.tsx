"use client";
// 人生K线: the life candlestick chart shown under the birth-chart methods (see metaphysics/life-kline.ts).
import { useEffect, useMemo, useRef, useState } from "react";
import type { Locale } from "./site-content";
import { lifeKLine, movingAverage, type KLineCandle, type KLineReason } from "./metaphysics/life-kline";
import { localizeBoardTerm } from "./complete-chart-board";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

const T = {
  title: L("Life K-line", "人生K线", "人生K線", "人生Kライン", "인생 K라인", "Biểu đồ nến cuộc đời", "กราฟแท่งเทียนชีวิต"),
  lead: L("Each year of life scored from the ten-year luck pillars and the year pillars of your BaZi chart, drawn like a stock chart: one candle per year.", "按八字的十年大运和每年流年给人生每一年打分，画成股票那样的K线：一根蜡烛代表一年。", "按八字的十年大運和每年流年給人生每一年打分，畫成股票那樣的K線：一根蠟燭代表一年。", "八字の十年大運と毎年の流年から人生の一年ごとに点数をつけ、株価チャートのように描きます。ろうそく1本が1年です。", "사주의 10년 대운과 해마다의 세운으로 인생의 한 해 한 해에 점수를 매겨 주식 차트처럼 그렸습니다. 촛대 하나가 1년입니다.", "Mỗi năm trong đời được chấm điểm theo đại vận mười năm và lưu niên của lá số Bát Tự, vẽ như biểu đồ chứng khoán: mỗi cây nến là một năm.", "ให้คะแนนแต่ละปีของชีวิตจากวัยจรสิบปีและดวงประจำปีของปาจื้อ แล้ววาดแบบกราฟหุ้น หนึ่งแท่งเทียนคือหนึ่งปี"),
  legendUp: L("Red: up on the year", "红：比上年上升", "紅：比上年上升", "赤：前年より上昇", "빨강: 전년보다 상승", "Đỏ: tăng so với năm trước", "แดง: ขึ้นจากปีก่อน"),
  legendDown: L("Green: down on the year", "绿：比上年下降", "綠：比上年下降", "緑：前年より下降", "초록: 전년보다 하락", "Xanh: giảm so với năm trước", "เขียว: ลงจากปีก่อน"),
  legendMa: L("Gold line: 10-year average", "金线：十年均线", "金線：十年均線", "金線：10年移動平均", "금색 선: 10년 이동평균", "Đường vàng: trung bình 10 năm", "เส้นทอง: ค่าเฉลี่ย 10 ปี"),
  favourable: L("Helpful elements", "喜用五行", "喜用五行", "喜用の五行", "희용 오행", "Hành hỷ dụng", "ธาตุที่เป็นคุณ"),
  strain: L("Straining elements", "忌神五行", "忌神五行", "忌神の五行", "기신 오행", "Hành kỵ", "ธาตุที่เป็นโทษ"),
  peaks: L("High points", "人生高点", "人生高點", "高値の年", "인생 고점", "Đỉnh cao", "จุดสูงสุด"),
  troughs: L("Low points", "人生低谷", "人生低谷", "安値の年", "인생 저점", "Đáy thấp", "จุดต่ำสุด"),
  bestLuck: L("Strongest ten-year cycle", "最旺的十年大运", "最旺的十年大運", "最も強い十年大運", "가장 좋은 10년 대운", "Đại vận mạnh nhất", "วัยจรสิบปีที่ดีที่สุด"),
  average: L("Life average", "一生平均分", "一生平均分", "生涯平均", "평생 평균", "Điểm trung bình", "ค่าเฉลี่ยตลอดชีวิต"),
  age: L("age {n}", "{n}岁", "{n}歲", "{n}歳", "{n}세", "{n} tuổi", "อายุ {n}"),
  ages: L("ages {a}–{b}", "{a}–{b}岁", "{a}–{b}歲", "{a}–{b}歳", "{a}–{b}세", "{a}–{b} tuổi", "อายุ {a}–{b}"),
  thisYear: L("This year", "今年", "今年", "今年", "올해", "Năm nay", "ปีนี้"),
  year: L("Year", "流年", "流年", "流年", "세운", "Lưu niên", "ปีจร"),
  luck: L("Luck cycle", "大运", "大運", "大運", "대운", "Đại vận", "วัยจร"),
  childhood: L("Before the first luck cycle (childhood)", "起运前（童限）", "起運前（童限）", "起運前（幼少期）", "대운 시작 전(유년)", "Trước khi khởi vận (thời thơ ấu)", "ก่อนเริ่มวัยจร (วัยเด็ก)"),
  ohlc: L("Open {o} · Close {c} · High {h} · Low {l}", "开 {o} · 收 {c} · 高 {h} · 低 {l}", "開 {o} · 收 {c} · 高 {h} · 低 {l}", "始値 {o} · 終値 {c} · 高値 {h} · 安値 {l}", "시가 {o} · 종가 {c} · 고가 {h} · 저가 {l}", "Mở {o} · Đóng {c} · Cao {h} · Thấp {l}", "เปิด {o} · ปิด {c} · สูง {h} · ต่ำ {l}"),
  why: L("Why this year moves", "这一年为什么这样走", "這一年為什麼這樣走", "この年の動きの理由", "이 해의 흐름 이유", "Vì sao năm này như vậy", "ทำไมปีนี้เป็นแบบนี้"),
  tap: L("Tap a candle to see that year.", "点任意一根K线查看那一年。", "點任意一根K線查看那一年。", "ろうそくをタップするとその年を表示します。", "촛대를 누르면 그 해를 볼 수 있어요.", "Chạm vào một cây nến để xem năm đó.", "แตะแท่งเทียนเพื่อดูปีนั้น"),
  note: L("A traditional-culture study reference drawn by fixed rules (one common school). It shows the rhythm of the chart, not a prediction of events.", "按固定规则（一种常见流派）计算的传统文化研习参考，用来看命盘的起伏节奏，不是对具体事件的预测。", "按固定規則（一種常見流派）計算的傳統文化研習參考，用來看命盤的起伏節奏，不是對具體事件的預測。", "一般的な一流派の固定ルールで描いた伝統文化の学習参考です。命式のリズムを示すもので、出来事の予言ではありません。", "일반적인 한 유파의 고정 규칙으로 그린 전통문화 학습 참고 자료입니다. 명식의 흐름을 보여 줄 뿐 사건의 예언이 아닙니다.", "Tài liệu tham khảo văn hóa truyền thống, tính theo quy tắc cố định (một trường phái phổ biến). Thể hiện nhịp lên xuống của lá số, không phải dự đoán sự việc.", "ข้อมูลอ้างอิงเพื่อศึกษาวัฒนธรรมดั้งเดิม คำนวณตามกฎตายตัว (สำนักหนึ่งที่นิยม) แสดงจังหวะขึ้นลงของดวง ไม่ใช่การทำนายเหตุการณ์"),
  verdictWeak: L("Day master leaning weak", "日主偏弱", "日主偏弱", "日主やや弱", "일간 약한 편", "Nhật chủ thiên nhược", "เจ้าวันค่อนข้างอ่อน"),
  verdictStrong: L("Day master leaning strong", "日主偏强", "日主偏強", "日主やや強", "일간 강한 편", "Nhật chủ thiên vượng", "เจ้าวันค่อนข้างแข็ง"),
  verdictBalanced: L("Day master balanced", "日主中和", "日主中和", "日主は中和", "일간 중화", "Nhật chủ trung hòa", "เจ้าวันสมดุล"),
};
const R: Record<KLineReason["key"], L7> = {
  luckGood: L("Luck cycle {g} brings helpful elements", "大运{g}带来喜用之气", "大運{g}帶來喜用之氣", "大運{g}が喜用の気を運ぶ", "대운 {g}이 희용의 기운을 가져옴", "Đại vận {g} mang hành hỷ dụng", "วัยจร {g} นำธาตุที่เป็นคุณมา"),
  luckBad: L("Luck cycle {g} leans on straining elements", "大运{g}偏忌神", "大運{g}偏忌神", "大運{g}は忌神寄り", "대운 {g}이 기신 쪽", "Đại vận {g} thiên về hành kỵ", "วัยจร {g} เอียงไปทางธาตุโทษ"),
  stemGood: L("Year stem {v} is helpful", "流年天干{v}为喜用", "流年天干{v}為喜用", "流年の天干{v}は喜用", "세운 천간 {v}은 희용", "Thiên can năm {v} là hỷ dụng", "ก้านฟ้าปี {v} เป็นคุณ"),
  stemBad: L("Year stem {v} strains the chart", "流年天干{v}为忌", "流年天干{v}為忌", "流年の天干{v}は忌", "세운 천간 {v}은 기신", "Thiên can năm {v} là kỵ", "ก้านฟ้าปี {v} เป็นโทษ"),
  branchGood: L("Year branch {v} is helpful", "流年地支{v}为喜用", "流年地支{v}為喜用", "流年の地支{v}は喜用", "세운 지지 {v}은 희용", "Địa chi năm {v} là hỷ dụng", "กิ่งดินปี {v} เป็นคุณ"),
  branchBad: L("Year branch {v} strains the chart", "流年地支{v}为忌", "流年地支{v}為忌", "流年の地支{v}は忌", "세운 지지 {v}은 기신", "Địa chi năm {v} là kỵ", "กิ่งดินปี {v} เป็นโทษ"),
  clashDay: L("Clash with the day branch ({v}): changes at home or in close relationships", "冲日支（{v}）：家庭、亲密关系易有变动", "沖日支（{v}）：家庭、親密關係易有變動", "日支と冲（{v}）：家庭や身近な関係に変化", "일지와 충({v}): 가정·가까운 관계에 변동", "Xung chi ngày ({v}): dễ biến động gia đình, quan hệ thân", "ปะทะกิ่งวัน ({v}): ครอบครัวและคนใกล้ชิดมักเปลี่ยนแปลง"),
  clashYear: L("Clash with the birth-year branch ({v})", "冲太岁本命（{v}）", "沖太歲本命（{v}）", "生年支と冲（{v}）", "생년지와 충({v})", "Xung chi năm sinh ({v})", "ปะทะกิ่งปีเกิด ({v})"),
  benming: L("Birth-year branch returns ({v}, 本命年)", "本命年（{v}）", "本命年（{v}）", "本命年（{v}）", "본명년({v})", "Năm tuổi ({v})", "ปีชง/ปีเกิด ({v})"),
  harmonyDay: L("Six-harmony with the day branch ({v})", "与日支六合（{v}）", "與日支六合（{v}）", "日支と六合（{v}）", "일지와 육합({v})", "Lục hợp với chi ngày ({v})", "หกประสานกับกิ่งวัน ({v})"),
  clashLuck: L("Year clashes the luck cycle ({v})", "流年冲大运（{v}）", "流年沖大運（{v}）", "流年が大運と冲（{v}）", "세운이 대운과 충({v})", "Lưu niên xung đại vận ({v})", "ปีจรปะทะวัยจร ({v})"),
  luckClash: L("Stem controls and branch clashes the luck cycle ({v}, 天克地冲)", "天克地冲大运（{v}）", "天剋地沖大運（{v}）", "天剋地冲で大運とぶつかる（{v}）", "천극지충으로 대운과 충돌({v})", "Thiên khắc địa xung đại vận ({v})", "ฟ้าข่มดินปะทะวัยจร ({v})"),
  childhood: L("Childhood, before the first luck cycle", "起运前的童限", "起運前的童限", "起運前の幼少期", "대운 시작 전 유년기", "Thời thơ ấu trước khởi vận", "วัยเด็กก่อนเริ่มวัยจร"),
};

const UP = "#e0464b", DOWN = "#1f9d6a";
const fill = (text: string, values: Record<string, string | number>) => Object.entries(values).reduce((out, [key, value]) => out.replaceAll(`{${key}}`, String(value)), text);

export function LifeKLineChart({ pillars, birthYear, luck, locale }: { pillars: string[]; birthYear: number; luck?: { cycles: Array<{ ganzhi: string; startAge: number; startYear: number }> }; locale: Locale }) {
  const data = useMemo(() => lifeKLine({ pillars, birthYear, luck }), [pillars, birthYear, luck]);
  const ma = useMemo(() => movingAverage(data.candles), [data]);
  const nowYear = new Date().getFullYear();
  const [selectedYear, setSelectedYear] = useState(() => (nowYear >= birthYear && nowYear < birthYear + data.candles.length ? nowYear : data.peaks[0]?.year ?? birthYear));
  const term = (value: string) => localizeBoardTerm(value, locale);
  const scrollRef = useRef<HTMLDivElement>(null);
  // On narrow screens the chart scrolls sideways: start with this year (or the selected year) in view.
  useEffect(() => {
    const box = scrollRef.current;
    if (!box || box.scrollWidth <= box.clientWidth) return;
    const ratio = (selectedYear - birthYear + 0.5) / data.candles.length;
    box.scrollLeft = Math.max(0, ratio * box.scrollWidth - box.clientWidth / 2);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [birthYear, data.candles.length]);
  const t = (key: keyof typeof T) => T[key][locale];
  const selected = data.candles.find((candle) => candle.year === selectedYear) ?? data.candles[0];

  const step = 9, left = 34, top = 28, height = 230, right = 12;
  const width = left + data.candles.length * step + right;
  const y = (value: number) => top + (1 - value / 100) * height;
  const x = (index: number) => left + index * step + step / 2;
  const maPath = ma.map((value, index) => (value === null ? "" : `${ma[index - 1] === null || index === 0 ? "M" : "L"}${x(index).toFixed(1)},${y(value).toFixed(1)}`)).join(" ");
  const yearLabel = (candle: KLineCandle) => `${candle.year} · ${fill(t("age"), { n: candle.age })}`;
  // "子午" (two branches) reads as 子–午; "甲子" (a stem-branch pair) is one term.
  const piece = (value: string) => (value.length === 2 && !"甲乙丙丁戊己庚辛壬癸".includes(value.charAt(0)) ? value.split("").map(term).join("–") : term(value));
  const reasonText = (reason: KLineReason) => fill(R[reason.key][locale], { g: "ganzhi" in reason ? term(reason.ganzhi) : "", v: "value" in reason ? reason.value.split("/").map(piece).join(" / ") : "" });
  const verdict = data.verdict === "Leaning weak" ? t("verdictWeak") : data.verdict === "Leaning strong" ? t("verdictStrong") : t("verdictBalanced");

  return <section className="life-kline" aria-label={t("title")}>
    <header>
      <h3>{t("title")}</h3>
      <p>{t("lead")}</p>
      <div className="life-kline-tags">
        <span>{verdict}</span>
        <span>{t("favourable")} · {data.favourable.map(term).join(" ")}</span>
        <span>{t("strain")} · {data.unfavourable.map(term).join(" ")}</span>
      </div>
    </header>
    <div className="life-kline-scroll" ref={scrollRef}>
      <svg viewBox={`0 0 ${width} ${top + height + 30}`} width={width} height={top + height + 30} role="img" aria-label={t("title")}>
        {data.lucks.map((cycle, index) => {
          const from = Math.max(0, cycle.startYear - birthYear), to = Math.min(data.candles.length, cycle.endYear - birthYear + 1);
          if (to <= from) return null;
          return <g key={cycle.startYear}>
            <rect x={left + from * step} y={top} width={(to - from) * step} height={height} className={index % 2 ? "band-b" : "band-a"} />
            <text x={left + from * step + 3} y={top - 8} className="band-label">{term(cycle.ganzhi)}</text>
          </g>;
        })}
        {[20, 40, 60, 80].map((value) => <g key={value}><line x1={left} x2={width - right} y1={y(value)} y2={y(value)} className="grid" /><text x={left - 6} y={y(value) + 3} className="axis" textAnchor="end">{value}</text></g>)}
        {data.candles.map((candle, index) => {
          const color = candle.close >= candle.open ? UP : DOWN;
          const bodyTop = y(Math.max(candle.open, candle.close)), bodyBottom = y(Math.min(candle.open, candle.close));
          return <g key={candle.year} className={candle.year === selectedYear ? "candle is-selected" : "candle"} onClick={() => setSelectedYear(candle.year)}>
            <rect x={left + index * step} y={top} width={step} height={height} fill="transparent" />
            <line x1={x(index)} x2={x(index)} y1={y(candle.high)} y2={y(candle.low)} stroke={color} strokeWidth="1" />
            <rect x={x(index) - 3} y={bodyTop} width={6} height={Math.max(1.2, bodyBottom - bodyTop)} fill={color} />
          </g>;
        })}
        <path d={maPath} className="ma" />
        {nowYear >= birthYear && nowYear < birthYear + data.candles.length && <g><line x1={x(nowYear - birthYear)} x2={x(nowYear - birthYear)} y1={top} y2={top + height} className="now" /><text x={x(nowYear - birthYear)} y={top + height + 24} className="now-label" textAnchor="middle">{t("thisYear")}</text></g>}
        {data.peaks.slice(0, 1).map((candle) => <text key="peak" x={x(candle.year - birthYear)} y={y(candle.high) - 5} className="mark" textAnchor="middle">▲{candle.year}</text>)}
        {data.troughs.slice(0, 1).map((candle) => <text key="trough" x={x(candle.year - birthYear)} y={y(candle.low) + 13} className="mark" textAnchor="middle">▼{candle.year}</text>)}
        {data.candles.filter((candle) => candle.age % 10 === 0).map((candle) => <text key={candle.year} x={x(candle.year - birthYear)} y={top + height + 12} className="axis" textAnchor="middle">{candle.age}</text>)}
      </svg>
    </div>
    <p className="life-kline-legend"><i style={{ background: UP }} />{t("legendUp")}<i style={{ background: DOWN }} />{t("legendDown")}<i className="is-ma" />{t("legendMa")}<span>{t("tap")}</span></p>
    {selected && <div className="life-kline-detail">
      <b>{yearLabel(selected)}</b>
      <span>{t("year")} {term(selected.ganzhi)} · {selected.luck ? `${t("luck")} ${term(selected.luck)}` : t("childhood")}</span>
      <small>{fill(t("ohlc"), { o: selected.open, c: selected.close, h: selected.high, l: selected.low })}</small>
      <ul aria-label={t("why")}>{selected.reasons.map((reason, index) => <li key={index}>{reasonText(reason)}</li>)}</ul>
    </div>}
    <div className="life-kline-summary">
      <div><small>{t("peaks")}</small>{data.peaks.map((candle) => <button type="button" key={candle.year} onClick={() => setSelectedYear(candle.year)}>{yearLabel(candle)} <b>{candle.close}</b></button>)}</div>
      <div><small>{t("troughs")}</small>{data.troughs.map((candle) => <button type="button" key={candle.year} onClick={() => setSelectedYear(candle.year)}>{yearLabel(candle)} <b>{candle.close}</b></button>)}</div>
      <div><small>{t("bestLuck")}</small>{data.bestLuck ? <button type="button" onClick={() => setSelectedYear(data.bestLuck!.startYear)}>{term(data.bestLuck.ganzhi)} · {data.bestLuck.startYear}–{data.bestLuck.endYear} <b>{data.bestLuck.average}</b></button> : <span>—</span>}</div>
      <div><small>{t("average")}</small><strong>{data.average}</strong></div>
    </div>
    <p className="life-kline-note">{t("note")}</p>
  </section>;
}
