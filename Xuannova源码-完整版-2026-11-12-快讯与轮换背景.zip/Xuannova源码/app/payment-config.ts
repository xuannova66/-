/**
 * Owner configuration boundary for USDT checkout.
 * Keep every value empty until the owner supplies a verified destination.
 */
export const paymentConfig = {
  checkoutUrl: "",
  qrImageUrl: "",
  recipientAddress: "",
  networkLabel: "",
  verificationMode: "manual" as const,
};

export const hasConfiguredPaymentChannel = Boolean(
  paymentConfig.checkoutUrl || paymentConfig.qrImageUrl || paymentConfig.recipientAddress,
);
