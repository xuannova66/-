/**
 * Self-hosted API entry (Node / AWS EC2).
 *
 * On Cloudflare the worker entry (`worker/index.ts`) answers `/api/*` before the
 * app renderer, so this route handler is never reached there. Under
 * `vinext start` on a plain Node host it becomes the API surface, backed by the
 * SQLite adapter in `server/sqlite-db.ts` and configuration from `process.env`.
 */
import { handleCommerceApi, type CommerceEnv } from "../../../worker/commerce-api";
import { handleGeocodingApi } from "../../../worker/geocoding-api";
import { sharedDatabase } from "../../../server/sqlite-db";
import { startChainWatcher } from "../../../server/chain-watcher";
import { startReminderMailer } from "../../../server/reminder-mailer";
import { startFlashRunner } from "../../../server/flash-runner";
import { handleMediaStream, handleMediaUpload } from "../../../server/media";

export const dynamic = "force-dynamic";

startChainWatcher(environment);
startReminderMailer(environment);
startFlashRunner(environment);

function environment(): CommerceEnv {
  return {
    DB: sharedDatabase(),
    ADMIN_EMAIL: process.env.ADMIN_EMAIL,
    ADMIN_EMAILS: process.env.ADMIN_EMAILS,
    ADMIN_PASSWORD: process.env.ADMIN_PASSWORD,
    SESSION_SECRET: process.env.SESSION_SECRET,
    DEEPSEEK_API_KEY: process.env.DEEPSEEK_API_KEY,
    DEEPSEEK_MODEL: process.env.DEEPSEEK_MODEL,
    VISION_API_URL: process.env.VISION_API_URL,
    VISION_API_KEY: process.env.VISION_API_KEY,
    VISION_MODEL: process.env.VISION_MODEL,
    VISION_DAILY_LIMIT: process.env.VISION_DAILY_LIMIT,
    CREDIT_STORE_ADDRESS: process.env.CREDIT_STORE_ADDRESS,
    USDC_CHECKOUT_ADDRESS: process.env.USDC_CHECKOUT_ADDRESS,
    USDC_CHECKOUT_ENABLED: process.env.USDC_CHECKOUT_ENABLED,
    USDC_CHECKOUT_REPLACE_LEGACY: process.env.USDC_CHECKOUT_REPLACE_LEGACY,
    USDC_CHECKOUT_TOKENS: process.env.USDC_CHECKOUT_TOKENS,
    MULTICHAIN_WALLET_LINK_ENABLED: process.env.MULTICHAIN_WALLET_LINK_ENABLED,
    MULTICHAIN_DRAFT_RECOVERY_ENABLED: process.env.MULTICHAIN_DRAFT_RECOVERY_ENABLED,
    MULTICHAIN_DRAFT_ORDERS_ENABLED: process.env.MULTICHAIN_DRAFT_ORDERS_ENABLED,
    ETHEREUM_DRAFT_USDC_ADDRESS: process.env.ETHEREUM_DRAFT_USDC_ADDRESS,
    BSC_RPC_URLS: process.env.BSC_RPC_URLS,
    BSC_CHAIN_ID: process.env.BSC_CHAIN_ID,
    USDT_ADDRESS: process.env.USDT_ADDRESS,
    GOOGLE_CLIENT_ID: process.env.GOOGLE_CLIENT_ID,
    RESEND_API_KEY: process.env.RESEND_API_KEY,
    MAIL_FROM: process.env.MAIL_FROM,
    SITE_URL: process.env.SITE_URL,
    DODO_API_KEY: process.env.DODO_API_KEY,
    DODO_WEBHOOK_SECRET: process.env.DODO_WEBHOOK_SECRET,
    DODO_ENVIRONMENT: process.env.DODO_ENVIRONMENT,
    DODO_PRODUCTS: process.env.DODO_PRODUCTS,
    COOKIE_DOMAIN: process.env.COOKIE_DOMAIN,
    // Keep in step with worker/index.ts: this route is the API on the AWS (Node) server.
    FREE_FULL_TOOLS: process.env.FREE_FULL_TOOLS,
    HALL_LAMP_COST: process.env.HALL_LAMP_COST,
    FLASH_API_TOKEN: process.env.FLASH_API_TOKEN,
    LIBRARY_BASE_URL: process.env.LIBRARY_BASE_URL,
    LIBRARY_TRANSLATE_GUEST_DAILY: process.env.LIBRARY_TRANSLATE_GUEST_DAILY,
    LIBRARY_TRANSLATE_MEMBER_DAILY: process.env.LIBRARY_TRANSLATE_MEMBER_DAILY,
    LIBRARY_TRANSLATE_SITE_DAILY: process.env.LIBRARY_TRANSLATE_SITE_DAILY,
    WALLET_PAY_ENABLED: process.env.WALLET_PAY_ENABLED,
    ETHEREUM_RPC_URL: process.env.ETHEREUM_RPC_URL,
    ETHEREUM_CONFIRMATIONS: process.env.ETHEREUM_CONFIRMATIONS,
    SOLANA_RPC_URL: process.env.SOLANA_RPC_URL,
    TRON_API_URL: process.env.TRON_API_URL,
    TRON_API_KEY: process.env.TRON_API_KEY,
  };
}

/**
 * Behind Caddy / nginx the app sees plain HTTP. vinext rebuilds `request.url`
 * from X-Forwarded-Proto / X-Forwarded-Host when the host is listed in
 * VINEXT_TRUSTED_HOSTS (set in deploy/aws/xuanyuan.env), so origin checks and
 * the wallet sign-in message use the public https://domain.
 */
async function handle(request: Request) {
  const { pathname } = new URL(request.url);
  if (pathname === "/api/admin/lectures/upload" && request.method === "POST") return handleMediaUpload(request, environment());
  const media = pathname.match(/^\/api\/media\/([A-Za-z0-9.-]{8,80})$/);
  if (media && request.method === "GET") return handleMediaStream(request, environment(), media[1]);
  const geocoding = await handleGeocodingApi(request);
  if (geocoding) return geocoding;
  const commerce = await handleCommerceApi(request, environment());
  if (commerce) return commerce;
  return new Response(JSON.stringify({ error: "API route not found" }), { status: 404, headers: { "content-type": "application/json; charset=utf-8" } });
}

export const GET = handle;
export const POST = handle;
