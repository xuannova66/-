// 每日五行穿搭: today's lucky colour for one person. The person's day master (日主, from the birth date) meets today's
// day stem; the colour follows a simple, traditional balancing rule (扶抑 / 通关):
//   today's element generates the day master (印日)  → wear the day master's own element (keep the support flowing)
//   today's element is the day master's (比日)        → wear the element the day master generates (let it express)
//   the day master generates today's element (泄日)   → wear the element that generates the day master (replenish)
//   the day master controls today's element (财日)    → wear the day master's own element (strength to carry it)
//   today's element controls the day master (官杀日)  → wear the element that generates the day master (通关, turn pressure into support)
// The shade rotates with the date so the card is fresh every day. Cultural reference and entertainment only.
import { Lunar, Solar } from "lunar-javascript";
import type { Locale } from "./site-content";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

export type Element = "wood" | "fire" | "earth" | "metal" | "water";
const ORDER: Element[] = ["wood", "fire", "earth", "metal", "water"];
const STEM_ELEMENT: Record<string, Element> = { 甲: "wood", 乙: "wood", 丙: "fire", 丁: "fire", 戊: "earth", 己: "earth", 庚: "metal", 辛: "metal", 壬: "water", 癸: "water" };
const generates = (element: Element) => ORDER[(ORDER.indexOf(element) + 1) % 5];
const generatedBy = (element: Element) => ORDER[(ORDER.indexOf(element) + 4) % 5];
const controls = (element: Element) => ORDER[(ORDER.indexOf(element) + 2) % 5];
const controlledBy = (element: Element) => ORDER[(ORDER.indexOf(element) + 3) % 5];

export const elementNames: Record<Element, L7> = {
  wood: L("Wood", "木", "木", "木", "목", "Mộc", "ไม้"),
  fire: L("Fire", "火", "火", "火", "화", "Hỏa", "ไฟ"),
  earth: L("Earth", "土", "土", "土", "토", "Thổ", "ดิน"),
  metal: L("Metal", "金", "金", "金", "금", "Kim", "ทอง"),
  water: L("Water", "水", "水", "水", "수", "Thủy", "น้ำ"),
};

/** The colour family of each element, for "go easy on …" (e.g. earth → yellow-browns). */
export const colorFamily: Record<Element, L7> = {
  wood: L("greens and teals", "青绿色系", "青綠色系", "青・緑系", "청록 계열", "tông xanh lá", "โทนเขียว"),
  fire: L("reds and purples", "红紫色系", "紅紫色系", "赤・紫系", "빨강·자주 계열", "tông đỏ tím", "โทนแดงม่วง"),
  earth: L("yellows and browns", "黄褐色系", "黃褐色系", "黄・茶系", "노랑·갈색 계열", "tông vàng nâu", "โทนเหลืองน้ำตาล"),
  metal: L("whites and silvers", "白银色系", "白銀色系", "白・銀系", "흰색·은색 계열", "tông trắng bạc", "โทนขาวเงิน"),
  water: L("blacks and deep blues", "黑蓝色系", "黑藍色系", "黒・紺系", "검정·남색 계열", "tông đen xanh thẫm", "โทนดำน้ำเงินเข้ม"),
};

export type Shade = { hex: string; zh: string; name: L7 };
// Everyday colour names (红色、黄色 …) so anyone knows what to wear; the swatch shows the exact shade.
export const shades: Record<Element, Shade[]> = {
  wood: [
    { hex: "#6B9A6E", zh: "绿色", name: L("Green", "绿色", "綠色", "緑", "초록색", "Xanh lá", "สีเขียว") },
    { hex: "#3E6B4F", zh: "深绿色", name: L("Dark green", "深绿色", "深綠色", "深緑", "진초록색", "Xanh lá đậm", "สีเขียวเข้ม") },
    { hex: "#3A6F73", zh: "青绿色", name: L("Teal", "青绿色", "青綠色", "青緑", "청록색", "Xanh ngọc", "สีเขียวอมฟ้า") },
  ],
  fire: [
    { hex: "#B5442E", zh: "红色", name: L("Red", "红色", "紅色", "赤", "빨간색", "Đỏ", "สีแดง") },
    { hex: "#A83A4A", zh: "玫红色", name: L("Rose red", "玫红色", "玫紅色", "ローズレッド", "장미색", "Đỏ hồng", "สีแดงกุหลาบ") },
    { hex: "#7B3B5C", zh: "紫色", name: L("Purple", "紫色", "紫色", "紫", "보라색", "Tím", "สีม่วง") },
  ],
  earth: [
    { hex: "#C08A3E", zh: "黄色", name: L("Yellow", "黄色", "黃色", "黄色", "노란색", "Vàng", "สีเหลือง") },
    { hex: "#A0673A", zh: "棕色", name: L("Brown", "棕色", "棕色", "茶色", "갈색", "Nâu", "สีน้ำตาล") },
    { hex: "#C9AE84", zh: "卡其色", name: L("Khaki", "卡其色", "卡其色", "カーキ", "카키색", "Kaki", "สีกากี") },
  ],
  metal: [
    { hex: "#E6E4DA", zh: "白色", name: L("White", "白色", "白色", "白", "흰색", "Trắng", "สีขาว") },
    { hex: "#A9AAA6", zh: "灰色", name: L("Grey", "灰色", "灰色", "グレー", "회색", "Xám", "สีเทา") },
    { hex: "#EFE6D2", zh: "米白色", name: L("Off-white", "米白色", "米白色", "オフホワイト", "아이보리색", "Trắng kem", "สีขาวนวล") },
  ],
  water: [
    { hex: "#23324A", zh: "藏青色", name: L("Navy", "藏青色", "藏青色", "紺色", "남색", "Xanh than", "สีกรมท่า") },
    { hex: "#2E4A7A", zh: "深蓝色", name: L("Dark blue", "深蓝色", "深藍色", "濃い青", "진파란색", "Xanh dương đậm", "สีน้ำเงินเข้ม") },
    { hex: "#1E1F22", zh: "黑色", name: L("Black", "黑色", "黑色", "黒", "검은색", "Đen", "สีดำ") },
  ],
};

/** A line from the 尚书·洪范 (Book of Documents, "Great Plan") for each element, with a plain modern reading. */
export const elementQuotes: Record<Element, { zh: string; reading: L7 }> = {
  wood: { zh: "木曰曲直", reading: L("Wood bends and straightens: follow nature, grow supple and strong.", "木曰曲直：顺应自然，柔韧生长。", "木曰曲直：順應自然，柔韌生長。", "木は曲がり、また真っすぐに伸びる。自然に従い、しなやかに育つ。", "나무는 굽고 곧게 자란다. 자연을 따라 유연하게 성장하라.", "Mộc vừa cong vừa thẳng: thuận theo tự nhiên, mềm dẻo mà lớn mạnh.", "ไม้โค้งได้ตรงได้ คล้อยตามธรรมชาติ เติบโตอย่างยืดหยุ่น") },
  fire: { zh: "火曰炎上", reading: L("Fire blazes upward: let your warmth and clarity rise.", "火曰炎上：心怀热忱，光明向上。", "火曰炎上：心懷熱忱，光明向上。", "火は炎となって上へ。熱意と明るさを高く掲げる。", "불은 위로 타오른다. 열정과 밝음을 높이 펼쳐라.", "Hỏa bốc lên cao: giữ nhiệt huyết, sáng suốt vươn lên.", "ไฟลุกโชนขึ้นสูง ให้ความอบอุ่นและความสว่างนำทาง") },
  earth: { zh: "土爰稼穑", reading: L("Earth is for sowing and reaping: steady work brings a full harvest.", "土爰稼穑：踏实耕耘，自有收成。", "土爰稼穡：踏實耕耘，自有收成。", "土は種をまき実りを収める。着実な働きが豊かな実りを生む。", "흙은 씨 뿌리고 거두는 곳. 꾸준한 노력이 결실을 맺는다.", "Thổ để gieo trồng gặt hái: chăm chỉ vững vàng ắt có mùa vàng.", "ดินคือที่หว่านและเก็บเกี่ยว ทำงานอย่างมั่นคงย่อมได้ผล") },
  metal: { zh: "金曰从革", reading: L("Metal yields and is reshaped: refine yourself, cut away the excess.", "金曰从革：去芜存菁，精进自新。", "金曰從革：去蕪存菁，精進自新。", "金は従い形を改める。無駄をそぎ落とし、自らを磨く。", "쇠는 따르며 새로 빚어진다. 군더더기를 덜고 자신을 단련하라.", "Kim thuận theo mà đổi mới: gạn đục khơi trong, rèn mình tinh tiến.", "ทองยอมหลอมเปลี่ยนรูป ตัดส่วนเกิน ขัดเกลาตนเอง") },
  water: { zh: "水曰润下", reading: L("Water moistens and flows low: be humble, and nourish all you touch.", "水曰润下：谦和低处，润物无声。", "水曰潤下：謙和低處，潤物無聲。", "水は潤し低きへ流れる。謙虚に、触れるものを静かに潤す。", "물은 적시며 낮은 곳으로 흐른다. 겸손하게 만물을 적셔라.", "Thủy thấm nhuần chảy xuống thấp: khiêm nhường, lặng lẽ nuôi dưỡng.", "น้ำหล่อเลี้ยงไหลสู่ที่ต่ำ ถ่อมตนและหล่อเลี้ยงทุกสิ่งอย่างเงียบงัน") },
};

/** The modern reading without the classical line in front (for Chinese and Japanese, which repeat it). */
export function quoteReading(element: Element, locale: Locale) {
  const { zh, reading } = elementQuotes[element];
  const text = reading[locale];
  return text.startsWith(zh.slice(0, 2)) ? text.replace(/^.{4}[：:—―\s]+/, "") : text;
}

export const reasonText: Record<"resource" | "self" | "output", L7> = {
  resource: L("{color} ({element}) nourishes your {dm} day master and turns today's pressure into support.", "{color}属{element}，能生扶你的{dm}日主，把今天的压力化为助力。", "{color}屬{element}，能生扶你的{dm}日主，把今天的壓力化為助力。", "{color}は{element}。あなたの{dm}の日主を育て、今日の重圧を支えに変えます。", "{color}은(는) {element}. {dm} 일간을 북돋워 오늘의 부담을 힘으로 바꿉니다.", "{color} thuộc {element}, nâng đỡ nhật chủ {dm} của bạn, biến áp lực hôm nay thành trợ lực.", "{color} เป็นธาตุ{element} ช่วยหนุนเจ้าชะตา{dm} เปลี่ยนแรงกดดันวันนี้เป็นแรงหนุน"),
  self: L("{color} ({element}) matches your {dm} day master and keeps today's energy steady.", "{color}属{element}，与你的{dm}日主同气，今天稳住自己的节奏。", "{color}屬{element}，與你的{dm}日主同氣，今天穩住自己的節奏。", "{color}は{element}。あなたの{dm}の日主と同じ気で、今日のリズムを安定させます。", "{color}은(는) {element}. {dm} 일간과 같은 기운으로 오늘의 리듬을 지켜 줍니다.", "{color} thuộc {element}, cùng khí với nhật chủ {dm}, giữ nhịp ổn định hôm nay.", "{color} เป็นธาตุ{element} เข้ากับเจ้าชะตา{dm} ช่วยให้จังหวะวันนี้มั่นคง"),
  output: L("{color} ({element}) lets your {dm} day master express itself — good for creating and speaking up.", "{color}属{element}，让你的{dm}日主顺势发挥，适合表达与创作。", "{color}屬{element}，讓你的{dm}日主順勢發揮，適合表達與創作。", "{color}は{element}。あなたの{dm}の日主をのびやかに表し、表現や創作に向きます。", "{color}은(는) {element}. {dm} 일간이 자연스럽게 드러나 표현과 창작에 좋습니다.", "{color} thuộc {element}, giúp nhật chủ {dm} phát huy, hợp để thể hiện và sáng tạo.", "{color} เป็นธาตุ{element} ให้เจ้าชะตา{dm} ได้แสดงออก เหมาะกับการสร้างสรรค์"),
};

export type DailyColor = {
  iso: string; dayMaster: Element; dayMasterStem: string; today: Element; todayGanZhi: string;
  lucky: Element; shade: Shade; second: Shade; avoid: Element; reason: "resource" | "self" | "output";
};

/** Today's lucky colour for someone born on `birthIso` (YYYY-MM-DD). */
export function dailyColor(birthIso: string, todayIso: string): DailyColor {
  const [by, bm, bd] = birthIso.split("-").map(Number);
  const [ty, tm, td] = todayIso.split("-").map(Number);
  const stem = Solar.fromYmdHms(by, bm, bd, 12, 0, 0).getLunar().getEightChar().getDayGan() as string;
  const todayLunar = Solar.fromYmd(ty, tm, td).getLunar();
  const todayStem = todayLunar.getDayGan() as string;
  const dm = STEM_ELEMENT[stem], today = STEM_ELEMENT[todayStem];
  let lucky: Element, reason: DailyColor["reason"];
  if (generates(today) === dm) { lucky = dm; reason = "self"; }               // 印日
  else if (today === dm) { lucky = generates(dm); reason = "output"; }         // 比日
  else if (generates(dm) === today) { lucky = generatedBy(dm); reason = "resource"; } // 泄日
  else if (controls(dm) === today) { lucky = dm; reason = "self"; }           // 财日
  else { lucky = generatedBy(dm); reason = "resource"; }                       // 官杀日
  const dayNumber = Math.floor(Date.UTC(ty, tm - 1, td) / 86_400_000);
  const list = shades[lucky];
  const shade = list[dayNumber % list.length];
  const secondElement = lucky === dm ? generatedBy(dm) : dm;
  const second = shades[secondElement][(dayNumber + 1) % shades[secondElement].length];
  return { iso: todayIso, dayMaster: dm, dayMasterStem: stem, today, todayGanZhi: todayLunar.getDayInGanZhi() as string, lucky, shade, second, avoid: controlledBy(dm), reason };
}

export const fillText = (template: string, values: Record<string, string>) => template.replace(/\{(\w+)\}/g, (_, key: string) => values[key] ?? "");

/** The solar (Gregorian) date of a saved birth date that may be in the lunar calendar. Null when it can't be read. */
export function solarBirthIso(date: string, calendar: "solar" | "lunar" | string, leapMonth = false): string | null {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(date);
  if (!match) return null;
  if (calendar !== "lunar") return date;
  try {
    const [y, m, d] = [Number(match[1]), Number(match[2]), Number(match[3])];
    const solar = Lunar.fromYmd(y, leapMonth ? -m : m, d).getSolar();
    return `${solar.getYear()}-${String(solar.getMonth()).padStart(2, "0")}-${String(solar.getDay()).padStart(2, "0")}`;
  } catch { return null; }
}
