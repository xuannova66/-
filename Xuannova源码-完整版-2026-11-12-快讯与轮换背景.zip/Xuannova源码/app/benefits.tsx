// One benefits table and one price list, used everywhere the site explains what is free and what costs credits
// (home, credits page, courses, the reading panel). The numbers come from the same constants the server charges by.
import type { Locale } from "./site-content";
import { interpretationCost } from "./credit-wallet";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

/** Mirrors worker/commerce-api.ts (dailyBonusAmount, dailyBonusCap) and worker/commerce-policy.ts. */
export const CREDIT_RULES = { report: interpretationCost("bazi"), deep: interpretationCost("detail"), followUp: interpretationCost(""), dailyBonus: 5, dailyCap: 20, firstPurchase: 20 } as const;

const fill = (value: string) => value
  .replaceAll("{report}", String(CREDIT_RULES.report)).replaceAll("{deep}", String(CREDIT_RULES.deep)).replaceAll("{followUp}", String(CREDIT_RULES.followUp))
  .replaceAll("{daily}", String(CREDIT_RULES.dailyBonus)).replaceAll("{cap}", String(CREDIT_RULES.dailyCap)).replaceAll("{first}", String(CREDIT_RULES.firstPurchase));

export const benefitsText = {
  eyebrow: L("What is free · what uses credits", "免费 · 注册 · 积分", "免費 · 註冊 · 積分", "無料・登録・クレジット", "무료 · 가입 · 크레딧", "Miễn phí · Đăng ký · Điểm", "ฟรี · สมัคร · เครดิต"),
  title: L("Three levels, one table", "三种权益，一张表说清楚", "三種權益，一張表說清楚", "3つの利用範囲を1つの表で", "세 가지 혜택을 한 표로", "Ba mức quyền lợi trong một bảng", "สิทธิ์ 3 ระดับในตารางเดียว"),
  guest: L("Visitor", "游客", "訪客", "ゲスト", "방문자", "Khách", "ผู้เยี่ยมชม"),
  guestNote: L("No account needed", "无需注册", "無需註冊", "登録不要", "가입 불필요", "Không cần tài khoản", "ไม่ต้องสมัคร"),
  member: L("Free registration", "免费注册用户", "免費註冊用戶", "無料登録ユーザー", "무료 가입 회원", "Đăng ký miễn phí", "สมัครสมาชิกฟรี"),
  memberNote: L("Email, about a minute", "邮箱注册，约一分钟", "信箱註冊，約一分鐘", "メールで約1分", "이메일로 약 1분", "Bằng email, khoảng 1 phút", "ใช้อีเมล ประมาณ 1 นาที"),
  credits: L("Using credits", "使用积分", "使用積分", "クレジット利用", "크레딧 사용", "Dùng điểm", "ใช้เครดิต"),
  creditsNote: L("Bought in packages, never expire", "按套餐购买，长期有效", "按方案購買，長期有效", "パッケージで購入・期限なし", "패키지 구매 · 기한 없음", "Mua theo gói, không hết hạn", "ซื้อเป็นแพ็กเกจ ไม่มีวันหมดอายุ"),
  guestItems: [
    L("Cast every chart (all methods)", "全部方法免费排盘", "全部方法免費排盤", "すべての方法で無料で盤を作成", "모든 방법으로 무료 차트 작성", "Lập lá số miễn phí với mọi phương pháp", "ผูกดวงฟรีทุกวิธี"),
    L("Preview the first half of each reading", "每份解读预览前半部分", "每份解讀預覽前半部分", "各解説の前半をプレビュー", "각 해석의 앞부분 미리보기", "Xem trước nửa đầu mỗi bài giải", "ดูตัวอย่างครึ่งแรกของคำอธิบาย"),
    L("Life K-line, almanac, classics library", "人生K线、每日黄历、藏经阁", "人生K線、每日黃曆、藏經閣", "人生Kライン・暦・古典書庫", "인생 K라인 · 달력 · 고전 서고", "Biểu đồ K đời người, lịch ngày, thư viện", "กราฟ K ชีวิต ปฏิทิน ห้องคัมภีร์"),
    L("Daily lucky-colour card and today's action guide, with share posters", "每日幸运色日签、今日行动指南（可生成分享海报）", "每日幸運色日籤、今日行動指南（可產生分享海報）", "毎日のラッキーカラーと行動ガイド（シェア用ポスター付き）", "매일 행운 색 카드와 오늘의 행동 가이드(공유 포스터)", "Thiệp màu may mắn và hướng dẫn hành động mỗi ngày (kèm ảnh chia sẻ)", "การ์ดสีมงคลและคู่มือประจำวัน (พร้อมโปสเตอร์แชร์)"),
    L("Study hall with fellow practitioners — walk around inside", "研习殿同殿共修，可在殿内走动", "研習殿同殿共修，可在殿內走動", "研習殿で道友と学び、殿内を歩ける", "연습전에서 도우들과 함께, 전각 안을 거닐기", "Điện tu học cùng đạo hữu — dạo quanh trong điện", "หอศึกษากับเพื่อนร่วมทาง เดินในหอได้"),
    L("Add to your phone's home screen like an app", "添加到手机桌面，像 App 一样打开", "加到手機主畫面，像 App 一樣開啟", "スマホのホーム画面に追加してアプリのように", "휴대폰 홈 화면에 앱처럼 추가", "Thêm vào màn hình chính như ứng dụng", "เพิ่มไว้หน้าจอโฮมเหมือนแอป"),
  ],
  memberItems: [
    L("Everything a visitor gets", "游客的全部权益", "訪客的全部權益", "ゲストの機能すべて", "방문자 혜택 전부", "Mọi quyền lợi của khách", "สิทธิ์ทั้งหมดของผู้เยี่ยมชม"),
    L("First full BaZi reading free", "首份完整八字解读免费", "首份完整八字解讀免費", "最初の八字の完全解説が無料", "첫 사주 전체 해석 무료", "Bài giải Bát tự đầy đủ đầu tiên miễn phí", "คำอธิบายปาจื้อฉบับเต็มครั้งแรกฟรี"),
    L("All video courses free", "全部视频课程免费观看", "全部影片課程免費觀看", "すべての動画講座が無料", "모든 영상 강좌 무료", "Xem miễn phí mọi khóa học video", "ดูคอร์สวิดีโอทั้งหมดฟรี"),
    L("+{daily} credits a day (kept up to {cap})", "每日赠送 {daily} 积分（最多累积 {cap}）", "每日贈送 {daily} 積分（最多累積 {cap}）", "毎日 {daily} クレジット（最大 {cap} まで）", "매일 {daily} 크레딧 (최대 {cap})", "+{daily} điểm mỗi ngày (tối đa {cap})", "รับ {daily} เครดิตทุกวัน (สะสมได้ถึง {cap})"),
    L("Saved profiles, reports and quiet rooms", "保存档案、报告和我的静室", "保存檔案、報告和我的靜室", "プロフィール・レポート・静室の保存", "프로필 · 리포트 · 조용한 방 저장", "Lưu hồ sơ, báo cáo và phòng riêng", "บันทึกโปรไฟล์ รายงาน และห้องส่วนตัว"),
    L("Light prayer lamps in the study hall (free for now)", "研习殿点亮祈福灯（限时免费）", "研習殿點亮祈福燈（限時免費）", "研習殿で祈りの灯をともす（期間限定無料）", "연습전 기원등 밝히기(한시 무료)", "Thắp đèn cầu phúc ở điện học (miễn phí có thời hạn)", "จุดโคมอธิษฐานในหอศึกษา (ฟรีช่วงนี้)"),
    L("Posters carry your invitation code: 5 credits each when a friend first buys", "海报自带邀请码：好友首次购买，双方各得 5 积分", "海報自帶邀請碼：好友首次購買，雙方各得 5 積分", "ポスターに招待コード付き：友だちの初回購入で双方5クレジット", "포스터에 초대 코드 포함: 친구 첫 구매 시 서로 5크레딧", "Ảnh có mã mời: bạn bè mua lần đầu, mỗi người 5 điểm", "โปสเตอร์มีรหัสเชิญ: เพื่อนซื้อครั้งแรก รับคนละ 5 เครดิต"),
  ],
  creditItems: [
    L("Unlock any other full reading", "解锁其他完整解读", "解鎖其他完整解讀", "その他の完全解説を開く", "다른 전체 해석 열기", "Mở khóa các bài giải đầy đủ khác", "ปลดล็อกคำอธิบายฉบับเต็มอื่น ๆ"),
    L("Follow-up questions on a reading", "针对报告继续追问", "針對報告繼續追問", "解説への追加質問", "해석에 대한 추가 질문", "Hỏi tiếp về bài giải", "ถามต่อจากคำอธิบาย"),
    L("Prices per service below", "每项服务价格见下表", "每項服務價格見下表", "サービス別の料金は下表", "서비스별 가격은 아래 표", "Giá từng dịch vụ ở bảng dưới", "ราคาแต่ละบริการดูตารางด้านล่าง"),
  ],
  priceTitle: L("Credits per service", "每项服务消耗多少积分", "每項服務消耗多少積分", "サービスごとのクレジット", "서비스별 크레딧", "Điểm cho từng dịch vụ", "เครดิตต่อบริการ"),
  service: L("Service", "服务", "服務", "サービス", "서비스", "Dịch vụ", "บริการ"),
  price: L("Credits", "积分", "積分", "クレジット", "크레딧", "Điểm", "เครดิต"),
  rows: [
    [L("Chart and first half of the reading", "排盘与前半部分解读", "排盤與前半部分解讀", "盤の作成と解説の前半", "차트와 해석 앞부분", "Lá số và nửa đầu bài giải", "ผังดวงและครึ่งแรกของคำอธิบาย"), L("Free", "免费", "免費", "無料", "무료", "Miễn phí", "ฟรี")],
    [L("Full reading report (one method)", "完整解读报告（单个方法）", "完整解讀報告（單個方法）", "完全な解説レポート（1つの方法）", "전체 해석 리포트 (방법 1개)", "Báo cáo giải đầy đủ (một phương pháp)", "รายงานคำอธิบายฉบับเต็ม (1 วิธี)"), L("{report} per report", "每份 {report}", "每份 {report}", "1件 {report}", "1건 {report}", "{report} mỗi báo cáo", "ฉบับละ {report}")],
    [L("BaZi deep study (twice as long)", "八字详研（篇幅加倍）", "八字詳研（篇幅加倍）", "八字詳細研究（2倍の長さ）", "사주 심층 연구 (2배 분량)", "Nghiên cứu sâu Bát tự (dài gấp đôi)", "ปาจื้อเชิงลึก (ยาวสองเท่า)"), L("{deep} per report", "每份 {deep}", "每份 {deep}", "1件 {deep}", "1건 {deep}", "{deep} mỗi báo cáo", "ฉบับละ {deep}")],
    [L("Follow-up question", "继续追问", "繼續追問", "追加質問", "추가 질문", "Câu hỏi tiếp", "คำถามต่อ"), L("{followUp} each time, only when you ask", "每次 {followUp}，不问不扣", "每次 {followUp}，不問不扣", "1回 {followUp}（質問した時のみ）", "1회 {followUp} (질문할 때만)", "{followUp} mỗi lần, chỉ khi bạn hỏi", "ครั้งละ {followUp} เฉพาะเมื่อถาม")],
    [L("Viewing a report you already unlocked", "再次查看已解锁的报告", "再次查看已解鎖的報告", "開いたレポートの再閲覧", "열어 둔 리포트 다시 보기", "Xem lại báo cáo đã mở khóa", "ดูรายงานที่ปลดล็อกแล้วอีกครั้ง"), L("Free, any time (Personal centre → reports)", "免费，随时在个人中心查看", "免費，隨時在個人中心查看", "無料・いつでも（マイページ）", "무료 · 언제든 (내 센터)", "Miễn phí, bất cứ lúc nào (Trang cá nhân)", "ฟรี ดูได้ทุกเมื่อ (ศูนย์ส่วนตัว)")],
    [L("A reading that fails or is cut off", "生成失败或中断", "生成失敗或中斷", "生成の失敗・中断", "생성 실패 또는 중단", "Tạo thất bại hoặc bị gián đoạn", "สร้างไม่สำเร็จหรือถูกตัด"), L("Not charged (credits are taken only after success)", "不扣积分（成功生成后才扣）", "不扣積分（成功生成後才扣）", "消費なし（成功後にのみ消費）", "차감 없음 (성공 후에만 차감)", "Không trừ (chỉ trừ khi thành công)", "ไม่หักเครดิต (หักหลังสร้างสำเร็จเท่านั้น)")],
    [L("Prayer lamp in the study hall (glows 24 hours)", "研习殿祈福灯（亮灯 24 小时）", "研習殿祈福燈（亮燈 24 小時）", "研習殿の祈りの灯（24時間）", "연습전 기원등 (24시간)", "Đèn cầu phúc ở điện học (sáng 24 giờ)", "โคมอธิษฐานในหอศึกษา (สว่าง 24 ชั่วโมง)"), L("Free for now", "限时免费", "限時免費", "期間限定で無料", "한시 무료", "Miễn phí có thời hạn", "ฟรีช่วงนี้")],
    [L("Purchased credits", "购买的积分", "購買的積分", "購入したクレジット", "구매한 크레딧", "Điểm đã mua", "เครดิตที่ซื้อ"), L("Never expire", "长期有效，不过期", "長期有效，不過期", "有効期限なし", "유효기간 없음", "Không hết hạn", "ไม่มีวันหมดอายุ")],
    [L("Daily gift credits", "每日赠送积分", "每日贈送積分", "毎日のプレゼント", "매일 선물 크레딧", "Điểm tặng hằng ngày", "เครดิตของขวัญรายวัน"), L("+{daily} a day, kept up to {cap}, used first", "每天 +{daily}，最多累积 {cap}，优先使用", "每天 +{daily}，最多累積 {cap}，優先使用", "1日 +{daily}・最大 {cap}・先に使用", "하루 +{daily} · 최대 {cap} · 먼저 사용", "+{daily} mỗi ngày, tối đa {cap}, dùng trước", "วันละ +{daily} สะสมได้ถึง {cap} ใช้ก่อน")],
    [L("First purchase", "首次购买", "首次購買", "初回購入", "첫 구매", "Lần mua đầu", "ซื้อครั้งแรก"), L("+{first} bonus, on top of the package", "另赠 +{first}，不含在套餐积分内", "另贈 +{first}，不含在方案積分內", "パッケージとは別に +{first}", "패키지와 별도로 +{first}", "Tặng thêm +{first}, ngoài số điểm của gói", "รับเพิ่ม +{first} แยกจากเครดิตในแพ็กเกจ")],
  ] as Array<[L7, L7]>,
  thisCost: L("This uses {cost} credits · your balance {balance} credits", "本次消耗 {cost} 积分，当前余额 {balance} 积分", "本次消耗 {cost} 積分，目前餘額 {balance} 積分", "今回 {cost} クレジット使用・残高 {balance} クレジット", "이번 사용 {cost} 크레딧 · 현재 잔액 {balance} 크레딧", "Lần này dùng {cost} điểm · số dư {balance} điểm", "ครั้งนี้ใช้ {cost} เครดิต · ยอดคงเหลือ {balance} เครดิต"),
  thisCostGuest: L("This uses {cost} credits · sign in to see your balance", "本次消耗 {cost} 积分，登录后显示余额", "本次消耗 {cost} 積分，登入後顯示餘額", "今回 {cost} クレジット使用・ログインで残高表示", "이번 사용 {cost} 크레딧 · 로그인하면 잔액 표시", "Lần này dùng {cost} điểm · đăng nhập để xem số dư", "ครั้งนี้ใช้ {cost} เครดิต · เข้าสู่ระบบเพื่อดูยอดคงเหลือ"),
  thisFree: L("This one is free · your balance {balance} credits", "本次免费，当前余额 {balance} 积分", "本次免費，目前餘額 {balance} 積分", "今回は無料・残高 {balance} クレジット", "이번은 무료 · 현재 잔액 {balance} 크레딧", "Lần này miễn phí · số dư {balance} điểm", "ครั้งนี้ฟรี · ยอดคงเหลือ {balance} เครดิต"),
  costFoot: L("Not charged if generation fails · viewing it again is free", "生成失败不扣分 · 再次查看免费", "生成失敗不扣分 · 再次查看免費", "失敗時は消費なし・再閲覧は無料", "실패 시 차감 없음 · 다시 보기 무료", "Không trừ nếu thất bại · xem lại miễn phí", "ไม่หักถ้าสร้างไม่สำเร็จ · ดูซ้ำฟรี"),
  base: L("{n} credits", "基础 {n} 积分", "基礎 {n} 積分", "基本 {n} クレジット", "기본 {n} 크레딧", "{n} điểm cơ bản", "เครดิตพื้นฐาน {n}"),
  firstBonus: L("+{n} first-purchase bonus", "首购赠送 +{n}", "首購贈送 +{n}", "初回ボーナス +{n}", "첫 구매 보너스 +{n}", "Thưởng lần đầu +{n}", "โบนัสซื้อครั้งแรก +{n}"),
  firstTotal: L("{n} credits in total on a first purchase", "首次购买共到账 {n} 积分", "首次購買共到帳 {n} 積分", "初回購入は合計 {n} クレジット", "첫 구매 시 총 {n} 크레딧", "Lần mua đầu nhận tổng {n} điểm", "ซื้อครั้งแรกได้รวม {n} เครดิต"),
  reports: L("about {n} full reports", "约可解锁 {n} 份完整报告", "約可解鎖 {n} 份完整報告", "完全な解説 約 {n} 件分", "전체 리포트 약 {n}건", "khoảng {n} báo cáo đầy đủ", "ประมาณ {n} รายงานฉบับเต็ม"),
};

export const fillCredits = (value: string, values: Record<string, number | string> = {}) =>
  Object.entries(values).reduce((text, [key, item]) => text.replaceAll(`{${key}}`, String(item)), fill(value));

/** The guest / free registration / credits table. */
export function BenefitsTable({ locale, heading = true }: { locale: Locale; heading?: boolean }) {
  const t = benefitsText;
  const column = (title: L7, note: L7, items: L7[], tone: string) => <div className={`benefit-col is-${tone}`}>
    <h4>{title[locale]}<small>{note[locale]}</small></h4>
    <ul>{items.map((item) => <li key={item.en}>{fill(item[locale])}</li>)}</ul>
  </div>;
  return <section className="benefits-table" aria-label={t.title[locale]} data-testid="benefits-table">
    {heading && <header><span>{t.eyebrow[locale]}</span><h3>{t.title[locale]}</h3></header>}
    <div className="benefit-cols">
      {column(t.guest, t.guestNote, t.guestItems, "guest")}
      {column(t.member, t.memberNote, t.memberItems, "member")}
      {column(t.credits, t.creditsNote, t.creditItems, "credits")}
    </div>
  </section>;
}

/** Per-service credit prices: full report, deep study, follow-up, re-view, failure, expiry, daily gift, first purchase. */
export function CreditPriceList({ locale }: { locale: Locale }) {
  const t = benefitsText;
  return <section className="credit-price-list" aria-label={t.priceTitle[locale]} data-testid="credit-price-list">
    <h4>{t.priceTitle[locale]}</h4>
    <table><thead><tr><th scope="col">{t.service[locale]}</th><th scope="col">{t.price[locale]}</th></tr></thead>
      <tbody>{t.rows.map(([service, price]) => <tr key={service.en}><th scope="row">{service[locale]}</th><td>{fill(price[locale])}</td></tr>)}</tbody>
    </table>
  </section>;
}

/** 「本次消耗 × 积分，当前余额 × 积分」 shown beside a button that spends credits. */
export function CostLine({ locale, cost, balance, free = false }: { locale: Locale; cost: number; balance: number | null; free?: boolean }) {
  const t = benefitsText;
  const line = free ? (balance === null ? null : fillCredits(t.thisFree[locale], { balance }))
    : balance === null ? fillCredits(t.thisCostGuest[locale], { cost }) : fillCredits(t.thisCost[locale], { cost, balance });
  if (!line) return null;
  return <p className={`cost-line${!free && balance !== null && balance < cost ? " is-short" : ""}`} data-testid="cost-line"><span>{line}</span><small>{t.costFoot[locale]}</small></p>;
}
