"use client";
// The four payment networks shown in the checkout: what settles there, which coins are planned, and which
// payment methods are open today. Wallet payment on all four: BNB Chain (store contract) and Ethereum, Solana and
// TRON (direct transfer with an order reference, four wallets each; see direct-wallets.ts and wallet-direct-pay.tsx).
import type { Locale } from "./site-content";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

export type PayChainId = "bsc" | "ethereum" | "solana" | "tron";
export type PayChain = { id: PayChainId; name: string; short: string; glyph: string; settlement: string; coins: string[]; qrNetwork?: "bsc" | "trc20" | "erc20" | "solana"; transferCoins: string[] };

export const payChains: PayChain[] = [
  { id: "bsc", name: "BNB Chain", short: "BSC", glyph: "B", settlement: "USDT", coins: ["USDT", "USDC", "BNB", "ASTER", "CAKE", "BTCB", "WETH", "USD1", "XRP", "SOL", "DOGE", "LINK", "UNI", "AAVE", "XAUt", "SHIB"], qrNetwork: "bsc", transferCoins: ["USDT"] },
  { id: "ethereum", name: "Ethereum", short: "ETH", glyph: "Ξ", settlement: "USDC / USDT", coins: ["USDC", "USDT", "ETH", "WETH", "WBTC", "LINK", "UNI", "AAVE"], qrNetwork: "erc20", transferCoins: ["USDC", "USDT"] },
  { id: "solana", name: "Solana", short: "SOL", glyph: "◎", settlement: "USDC / USDT", coins: ["USDC", "USDT", "SOL", "RAY", "JLP"], qrNetwork: "solana", transferCoins: ["USDC", "USDT"] },
  { id: "tron", name: "TRON", short: "TRX", glyph: "T", settlement: "USDT", coins: ["USDT", "TRX"], qrNetwork: "trc20", transferCoins: ["USDT"] },
];

export const payChainText = {
  chooseNetwork: L("1 · Choose a network", "1 · 选择付款网络", "1 · 選擇付款網路", "1 · ネットワークを選ぶ", "1 · 네트워크 선택", "1 · Chọn mạng", "1 · เลือกเครือข่าย"),
  chooseMethod: L("2 · Choose how to pay", "2 · 选择付款方式", "2 · 選擇付款方式", "2 · 支払い方法を選ぶ", "2 · 결제 방법 선택", "2 · Chọn cách thanh toán", "2 · เลือกวิธีชำระ"),
  settles: L("Settles in", "到账币种", "到帳幣種", "受取通貨", "정산 통화", "Nhận bằng", "ชำระเป็น"),
  coins: L("Coins you can pay with", "可用币种", "可用幣種", "支払いに使える通貨", "결제 가능한 코인", "Coin có thể dùng", "เหรียญที่ใช้จ่ายได้"),
  payCoins: L("Pay with {coins}", "可付 {coins}", "可付 {coins}", "支払い可能：{coins}", "결제 가능: {coins}", "Trả bằng {coins}", "จ่ายได้ด้วย {coins}"),
  coinsNow: L("Open now", "现已开放", "現已開放", "現在利用可", "지금 이용 가능", "Đã mở", "เปิดแล้ว"),
  coinsSoon: L("Coming soon", "即将开放", "即將開放", "近日公開", "곧 오픈", "Sắp mở", "เร็ว ๆ นี้"),
  walletSoon: L("Wallet payment on this network is being tested and will open soon. You can already pay by transfer where shown.", "该网络的钱包支付正在测试，很快开放；可扫码转账的网络现在就能付款。", "該網路的錢包支付正在測試，很快開放；可掃碼轉帳的網路現在就能付款。", "このネットワークのウォレット決済はテスト中で、まもなく公開します。送金に対応する場合は今すぐ支払えます。", "이 네트워크의 지갑 결제는 테스트 중이며 곧 열립니다. 송금이 표시된 곳은 지금 바로 결제할 수 있어요.", "Thanh toán ví trên mạng này đang thử nghiệm và sắp mở. Nơi có chuyển khoản thì đã thanh toán được.", "การชำระผ่านกระเป๋าบนเครือข่ายนี้กำลังทดสอบและจะเปิดเร็ว ๆ นี้ หากมีตัวเลือกโอนก็ชำระได้ทันที"),
  qrNetwork: L("Transfer {coin} on {chain}", "{chain} 链上转账 {coin}", "{chain} 鏈上轉帳 {coin}", "{chain} で {coin} を送金", "{chain}에서 {coin} 송금", "Chuyển {coin} trên {chain}", "โอน {coin} บน {chain}"),
  moreCoins: L("Other coins on this network: wallet payment with automatic conversion is being added.", "该网络的其他币种：钱包直付（自动兑换）正在接入。", "該網路的其他幣種：錢包直付（自動兌換）正在接入。", "このネットワークの他の通貨：自動両替つきのウォレット決済を追加中です。", "이 네트워크의 다른 코인: 자동 환전 지갑 결제를 추가하는 중입니다.", "Các coin khác trên mạng này: đang thêm thanh toán ví có tự động quy đổi.", "เหรียญอื่นบนเครือข่ายนี้: กำลังเพิ่มการชำระผ่านกระเป๋าพร้อมแปลงอัตโนมัติ"),
  stableNote: L("Send exactly the package price in USDC or USDT (1 = 1 US dollar) on this network.", "在该网络转入与套餐价格相同数量的 USDC 或 USDT（1 枚 = 1 美元）。", "在該網路轉入與套餐價格相同數量的 USDC 或 USDT（1 枚 = 1 美元）。", "このネットワークで、パッケージ価格と同額の USDC または USDT（1 枚 = 1 米ドル）を送金してください。", "이 네트워크에서 패키지 가격과 같은 수량의 USDC 또는 USDT(1개 = 1달러)를 보내 주세요.", "Chuyển đúng số USDC hoặc USDT bằng giá gói (1 = 1 USD) trên mạng này.", "โอน USDC หรือ USDT จำนวนเท่ากับราคาแพ็กเกจ (1 = 1 ดอลลาร์) บนเครือข่ายนี้"),
  qrLead: L("Scan the code or copy the address, then submit the transaction hash. Credited after review.", "扫码或复制地址转账，再提交交易哈希，审核后到账。", "掃碼或複製地址轉帳，再提交交易雜湊，審核後到帳。", "コードを読み取るかアドレスをコピーして送金し、取引ハッシュを送信。確認後に付与されます。", "코드를 스캔하거나 주소를 복사해 송금한 뒤 거래 해시를 제출하세요. 확인 후 지급됩니다.", "Quét mã hoặc sao chép địa chỉ để chuyển, rồi gửi mã giao dịch. Cộng điểm sau khi duyệt.", "สแกนหรือคัดลอกที่อยู่เพื่อโอน แล้วส่งแฮชธุรกรรม เครดิตเข้าหลังตรวจสอบ"),
};

const coinColors: Record<string, string> = { USDT: "#26A17B", USDC: "#2775CA", BNB: "#F3BA2F", ETH: "#627EEA", WETH: "#627EEA", SOL: "#9945FF", TRX: "#EB0029", BTCB: "#F7931A", WBTC: "#F7931A", CAKE: "#D1884F", LINK: "#2A5ADA", UNI: "#FF007A", AAVE: "#B6509E", DOGE: "#C2A633", XRP: "#7A8A99", SHIB: "#E0442B", XAUt: "#C9A227", USD1: "#3D8B6E", ASTER: "#8C6BE0", RAY: "#4D7BE0", JLP: "#C7F284" };

// Logos in /public/tokens (see README there for sources and licences).
const logoFiles: Record<string, string> = { USDT: "usdt.svg", USDC: "usdc.svg", BNB: "bnb.svg", ETH: "eth.svg", SOL: "sol.svg", TRX: "trx.svg", LINK: "link.svg", UNI: "uni.svg", AAVE: "aave.svg", DOGE: "doge.svg", XRP: "xrp.svg", RAY: "ray.svg", WBTC: "wbtc.svg", CAKE: "cake.png", SHIB: "shib.png", ASTER: "aster.png", USD1: "usd1.png", BTCB: "btcb.png", XAUt: "xaut.png", WETH: "weth.png", JLP: "jlp.png" };
const chainLogo: Record<PayChainId, string> = { bsc: "bnb.svg", ethereum: "eth.svg", solana: "sol.svg", tron: "trx.svg" };

export function CoinChip({ symbol, dim = false }: { symbol: string; dim?: boolean }) {
  const file = logoFiles[symbol];
  return <span className={`pay-coin${dim ? " is-dim" : ""}`}>{file
    ? <img src={`/tokens/${file}`} alt="" width={20} height={20} loading="lazy" />
    : <i style={{ background: coinColors[symbol] ?? "#6b7280" }} aria-hidden="true">{symbol.slice(0, 1)}</i>}{symbol}</span>;
}

export function ChainBadge({ chain }: { chain: PayChain }) {
  return <span className={`pay-chain-badge is-${chain.id}`} aria-hidden="true"><img src={`/tokens/${chainLogo[chain.id]}`} alt="" width={40} height={40} /></span>;
}

/** Chain logo for a manual-transfer network id (trc20, bsc, erc20, solana). */
const networkChain: Record<string, PayChainId> = { trc20: "tron", bsc: "bsc", erc20: "ethereum", solana: "solana" };
export function NetworkLogo({ network, size = 22 }: { network: string; size?: number }) {
  const chain = networkChain[network];
  return chain ? <img className="pay-network-logo" src={`/tokens/${chainLogo[chain]}`} alt="" width={size} height={size} /> : null;
}
