/**
 * Real, crawlable URLs for every tool in every language: /bazi, /ja/bazi, /zh-hant/daily …
 * The page server-renders the same app with the right language and tool, plus per-page
 * metadata (title, description, canonical, hreflang) and structured data.
 * Xuannova Flash items have their own URLs too: /flash/{slug}, /zh-hans/flash/{slug} …
 */
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Home from "../page";
import { metadataFor, structuredDataFor } from "../seo";
import { flashMetadata, flashStructuredData, loadFlashPage } from "../flash-seo";
import { PUBLIC_ROUTES, URL_LOCALES, parseStudyPath, pathFor, type UrlLocale } from "../study-navigation";

type Params = { slug?: string[] };

function resolve(slug: string[] = []) {
  const path = `/${slug.join("/")}`;
  const parsed = parseStudyPath(path);
  const locale = parsed.locale ?? "en";
  // A flash item: /{lang}/flash/{slug}
  const parts = slug.map((part) => decodeURIComponent(part));
  const rest = parsed.locale ? parts.slice(1) : parts;
  if (rest.length === 2 && rest[0] === "flash" && /^[a-z0-9][a-z0-9-]{3,90}$/.test(rest[1])) {
    if (`${pathFor(locale, "flash")}/${rest[1]}`.toLowerCase() !== path.toLowerCase()) return null;
    return { locale, route: parsed.route, flashSlug: rest[1] };
  }
  // Reject unknown paths instead of serving the home page under arbitrary URLs.
  const canonicalPath = pathFor(locale, parsed.route, parsed.stage);
  if (canonicalPath.toLowerCase() !== path.toLowerCase().replace(/\/$/, "")) return null;
  return { locale, route: parsed.route, flashSlug: null as string | null };
}

export function generateStaticParams() {
  return PUBLIC_ROUTES.flatMap((route) => URL_LOCALES.map((locale) => ({ slug: pathFor(locale, route).split("/").filter(Boolean) }))).filter((entry) => entry.slug.length > 0);
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const resolved = resolve((await params).slug);
  if (!resolved) return {};
  if (resolved.flashSlug) {
    const data = await loadFlashPage(resolved.flashSlug, resolved.locale as UrlLocale);
    return data && data !== "unavailable" ? flashMetadata(data, resolved.locale as UrlLocale) : metadataFor(resolved.locale, "flash");
  }
  return metadataFor(resolved.locale, resolved.route);
}

export default async function LocalizedPage({ params }: { params: Promise<Params> }) {
  const resolved = resolve((await params).slug);
  if (!resolved) notFound();
  if (resolved.flashSlug) {
    const data = await loadFlashPage(resolved.flashSlug, resolved.locale as UrlLocale);
    if (data === null) notFound();
    const item = data === "unavailable" ? null : data.item;
    return <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(item ? flashStructuredData(item, resolved.locale as UrlLocale) : structuredDataFor(resolved.locale, "flash")).replace(/</g, "\\u003c") }} />
      <Home initialLocale={resolved.locale} initialRoute="flash" initialFlash={item} />
    </>;
  }
  return <>
    <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredDataFor(resolved.locale, resolved.route)).replace(/</g, "\\u003c") }} />
    <Home initialLocale={resolved.locale} initialRoute={resolved.route} />
  </>;
}
