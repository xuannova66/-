export type CoinFace = "heads" | "tails";

export type CoinThrow = {
  coins: [CoinFace, CoinFace, CoinFace];
  total: 6 | 7 | 8 | 9;
  yang: boolean;
  moving: boolean;
  kind: "old-yin" | "young-yang" | "young-yin" | "old-yang";
};

export function resolveThreeCoinThrow(
  coins: [CoinFace, CoinFace, CoinFace],
): CoinThrow {
  const total = coins.reduce<number>((sum, coin) => sum + (coin === "heads" ? 3 : 2), 0) as 6 | 7 | 8 | 9;

  if (total === 6) return { coins, total, yang: false, moving: true, kind: "old-yin" };
  if (total === 7) return { coins, total, yang: true, moving: false, kind: "young-yang" };
  if (total === 8) return { coins, total, yang: false, moving: false, kind: "young-yin" };
  return { coins, total, yang: true, moving: true, kind: "old-yang" };
}

export function throwThreeCoins(random = Math.random): CoinThrow {
  const coins: [CoinFace, CoinFace, CoinFace] = [
    random() >= 0.5 ? "heads" : "tails",
    random() >= 0.5 ? "heads" : "tails",
    random() >= 0.5 ? "heads" : "tails",
  ];
  return resolveThreeCoinThrow(coins);
}

export function lineStatesFromThrows(throws: CoinThrow[]) {
  return {
    lines: throws.map((entry) => entry.yang),
    movingLines: throws.map((entry) => entry.moving),
  };
}
