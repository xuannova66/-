const STEMS = "甲乙丙丁戊己庚辛壬癸";
const BRANCHES = "子丑寅卯辰巳午未申酉戌亥";
const STEM_ELEMENT: Record<string, string> = {
  甲: "木", 乙: "木", 丙: "火", 丁: "火", 戊: "土",
  己: "土", 庚: "金", 辛: "金", 壬: "水", 癸: "水",
};
const YANG_STEMS = new Set(["甲", "丙", "戊", "庚", "壬"]);
const GENERATES: Record<string, string> = { 木: "火", 火: "土", 土: "金", 金: "水", 水: "木" };
const CONTROLS: Record<string, string> = { 木: "土", 土: "水", 水: "火", 火: "金", 金: "木" };
const HIDDEN_STEMS: Record<string, string[]> = {
  子: ["癸"], 丑: ["己", "癸", "辛"], 寅: ["甲", "丙", "戊"], 卯: ["乙"],
  辰: ["戊", "乙", "癸"], 巳: ["丙", "庚", "戊"], 午: ["丁", "己"],
  未: ["己", "丁", "乙"], 申: ["庚", "壬", "戊"], 酉: ["辛"],
  戌: ["戊", "辛", "丁"], 亥: ["壬", "甲"],
};
const NAYIN = [
  "海中金", "炉中火", "大林木", "路旁土", "剑锋金", "山头火", "涧下水", "城头土", "白蜡金", "杨柳木",
  "泉中水", "屋上土", "霹雳火", "松柏木", "长流水", "沙中金", "山下火", "平地木", "壁上土", "金箔金",
  "覆灯火", "天河水", "大驿土", "钗钏金", "桑柘木", "大溪水", "沙中土", "天上火", "石榴木", "大海水",
];
const LIFE_STAGES = "长生 沐浴 冠带 临官 帝旺 衰 病 死 墓 绝 胎 养".split(" ");
const STAGE_START: Record<string, string> = {
  甲: "亥", 丙: "寅", 戊: "寅", 庚: "巳", 壬: "申",
  乙: "午", 丁: "酉", 己: "酉", 辛: "子", 癸: "卯",
};

function jiaziIndex(pillar: string): number {
  if (pillar.length !== 2) return -1;
  const stemIndex = STEMS.indexOf(pillar[0]);
  const branchIndex = BRANCHES.indexOf(pillar[1]);
  if (stemIndex < 0 || branchIndex < 0) return -1;
  for (let index = 0; index < 60; index += 1) {
    if (index % 10 === stemIndex && index % 12 === branchIndex) return index;
  }
  return -1;
}

export function tenGod(dayStem: string, otherStem: string): string {
  const dayElement = STEM_ELEMENT[dayStem];
  const otherElement = STEM_ELEMENT[otherStem];
  if (!dayElement || !otherElement) return "—";
  const samePolarity = YANG_STEMS.has(dayStem) === YANG_STEMS.has(otherStem);
  if (dayElement === otherElement) return samePolarity ? "比肩" : "劫财";
  if (GENERATES[dayElement] === otherElement) return samePolarity ? "食神" : "伤官";
  if (CONTROLS[dayElement] === otherElement) return samePolarity ? "偏财" : "正财";
  if (CONTROLS[otherElement] === dayElement) return samePolarity ? "七杀" : "正官";
  if (GENERATES[otherElement] === dayElement) return samePolarity ? "偏印" : "正印";
  return "—";
}

function lifeStage(dayStem: string, branch: string): string {
  const start = STAGE_START[dayStem];
  const startIndex = BRANCHES.indexOf(start);
  const branchIndex = BRANCHES.indexOf(branch);
  if (startIndex < 0 || branchIndex < 0) return "—";
  const offset = YANG_STEMS.has(dayStem)
    ? (branchIndex - startIndex + 12) % 12
    : (startIndex - branchIndex + 12) % 12;
  return LIFE_STAGES[offset];
}

function ganzhiAt(index: number): string {
  return `${STEMS[((index % 10) + 10) % 10]}${BRANCHES[((index % 12) + 12) % 12]}`;
}

export function calculateBaziReference(pillars: string[], gender: "yin" | "yang" = "yang", cycleCount = 8) {
  if (pillars.length !== 4 || pillars.some((pillar) => jiaziIndex(pillar) < 0)) {
    throw new Error("BaZi calculation requires four valid stem-branch pillars.");
  }
  const dayStem = pillars[2][0];
  const yearStem = pillars[0][0];
  const monthIndex = jiaziIndex(pillars[1]);
  const forward = YANG_STEMS.has(yearStem) === (gender === "yang");
  const step = forward ? 1 : -1;
  const direction = forward ? "顺行" : "逆行";
  const cycles = Array.from({ length: cycleCount }, (_, index) => ganzhiAt(monthIndex + step * (index + 1)));

  return {
    tenGods: pillars.map((pillar, index) => index === 2 ? "日主" : tenGod(dayStem, pillar[0])),
    naYin: pillars.map((pillar) => NAYIN[Math.floor(jiaziIndex(pillar) / 2)]),
    lifeStages: pillars.map((pillar) => lifeStage(dayStem, pillar[1])),
    hiddenStems: pillars.map((pillar) => HIDDEN_STEMS[pillar[1]]),
    dayun: { direction, cycles },
  };
}

/** Ten God of a branch, read from its main hidden stem. */
export function branchTenGod(dayStem: string, branch: string): string {
  const main = HIDDEN_STEMS[branch]?.[0];
  return main ? tenGod(dayStem, main) : "—";
}

/**
 * Day-master strength reference (one common counting method; schools differ): stems count 1, each
 * branch's main hidden stem 1 (the month branch 2), other hidden stems 0.3. Supporting = same element
 * or the element that produces the day master; draining = everything else.
 */
export function dayMasterStrength(pillars: string[]) {
  const dayStem = pillars[2]?.[0] ?? "";
  const dayElement = STEM_ELEMENT[dayStem];
  if (!dayElement || pillars.length !== 4) return null;
  const supports = (stem: string) => { const element = STEM_ELEMENT[stem]; return element === dayElement || GENERATES[element] === dayElement; };
  let support = 0; let drain = 0;
  pillars.forEach((pillar, index) => {
    // An empty pillar (birth time unknown) is simply left out of the count.
    if (!pillar) return;
    if (index !== 2) { if (supports(pillar[0])) support += 1; else drain += 1; }
    (HIDDEN_STEMS[pillar[1]] ?? []).forEach((stem, order) => {
      const weight = order === 0 ? (index === 1 ? 2 : 1) : 0.3;
      if (supports(stem)) support += weight; else drain += weight;
    });
  });
  const monthMain = HIDDEN_STEMS[pillars[1]?.[1] ?? ""]?.[0];
  const seasonal = monthMain ? supports(monthMain) : false;
  const share = support / Math.max(0.001, support + drain);
  const verdict = share >= 0.55 ? "Leaning strong" : share <= 0.45 ? "Leaning weak" : "Balanced";
  return { support: Math.round(support * 10) / 10, drain: Math.round(drain * 10) / 10, seasonal, share: Math.round(share * 100), verdict };
}
