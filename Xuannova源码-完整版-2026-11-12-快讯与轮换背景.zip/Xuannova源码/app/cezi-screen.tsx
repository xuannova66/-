"use client";
// 测字 (/cezi): one character and a question. The character's form (Kangxi strokes, radical, layout, components)
// comes from the server (cached per character); a plum-blossom hexagram is cast from the stroke counts and the
// hour; the reading runs through the normal interpretation flow (first half free).
import { useMemo, useState } from "react";
import type { Locale } from "./site-content";
import type { AppRoute } from "./study-suite";
import type { CompleteChart } from "./chart-model";
import type { CreditWallet } from "./credit-wallet";
import { createStudyResult } from "./study-engine";
import { InterpretationPanel } from "./interpretation-panel";
import { MethodHelp } from "./guide";
import { hexagramName, plumBlossomNumberCast, trigramOf } from "./metaphysics/liuyao";
import { localizeBoardTerm } from "./complete-chart-board";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

type Analysis = { character: string; traditional: string; strokes: number; structure: "single" | "left-right" | "top-bottom" | "enclosing" | "other"; parts: Array<{ text: string; strokes: number }>; radical: string; radicalElement: string; components: string[]; meaning: string };

const t = {
  kicker: L("XUANNOVA · STUDY", "Xuannova · 研习", "Xuannova · 研習", "Xuannova · 研究", "Xuannova · 학습", "XUANNOVA · NGHIÊN CỨU", "Xuannova · ศึกษา"),
  title: L("Character Divination", "测字", "測字", "測字", "측자", "Đoán chữ", "ทำนายอักษร"),
  lead: L("Write the first Chinese character that comes to mind and your question: the character's form and strokes become a hexagram.", "写下心里浮现的第一个汉字和你的问题：由字形与笔画起卦来解读。", "寫下心裡浮現的第一個漢字和你的問題：由字形與筆畫起卦來解讀。", "心に浮かんだ最初の漢字と問いを書いてください。字の形と画数から卦を立てて読みます。", "마음에 떠오른 첫 한자와 질문을 적으세요. 글자의 형태와 획수로 괘를 세워 해석합니다.", "Viết chữ Hán đầu tiên hiện ra trong đầu và câu hỏi của bạn: hình chữ và số nét sẽ thành quẻ để luận.", "เขียนอักษรจีนตัวแรกที่นึกถึงและคำถามของคุณ รูปอักษรและจำนวนขีดจะตั้งเป็นกว้าเพื่ออ่าน"),
  character: L("One Chinese character", "一个汉字", "一個漢字", "漢字一字", "한자 한 글자", "Một chữ Hán", "อักษรจีนหนึ่งตัว"),
  characterHint: L("Do not think too long; the first character that appears is used.", "不用多想，取第一个浮现的字。", "不用多想，取第一個浮現的字。", "考えすぎず、最初に浮かんだ字を。", "오래 생각하지 말고 처음 떠오른 글자를 쓰세요.", "Đừng nghĩ lâu, lấy chữ đầu tiên hiện ra.", "ไม่ต้องคิดนาน ใช้ตัวแรกที่นึกออก"),
  question: L("Your question", "你想问的事", "你想問的事", "問いたいこと", "묻고 싶은 일", "Câu hỏi của bạn", "เรื่องที่อยากถาม"),
  analyse: L("Read the character", "开始测字", "開始測字", "測字を始める", "측자 시작", "Bắt đầu đoán chữ", "เริ่มทำนาย"),
  analysing: L("Reading the character…", "正在分析字形…", "正在分析字形…", "字形を分析しています…", "글자 형태를 분석 중…", "Đang phân tích chữ…", "กำลังวิเคราะห์อักษร…"),
  invalid: L("Please enter exactly one Chinese character.", "请输入一个汉字。", "請輸入一個漢字。", "漢字を一字だけ入力してください。", "한자 한 글자만 입력하세요.", "Vui lòng nhập đúng một chữ Hán.", "กรุณาใส่อักษรจีนหนึ่งตัว"),
  limit: L("Today's limit for new characters is reached. Please try again tomorrow.", "今天新字分析次数已用完，请明天再试。", "今天新字分析次數已用完，請明天再試。", "本日の新しい字の分析回数に達しました。明日お試しください。", "오늘 새 글자 분석 횟수를 다 썼습니다. 내일 다시 시도해 주세요.", "Đã hết lượt phân tích chữ mới hôm nay. Vui lòng thử lại ngày mai.", "วันนี้ใช้สิทธิ์วิเคราะห์อักษรใหม่ครบแล้ว กรุณาลองพรุ่งนี้"),
  failed: L("The analysis service is busy. Please try again in a moment.", "分析服务暂时繁忙，请稍后再试。", "分析服務暫時繁忙，請稍後再試。", "分析サービスが混み合っています。しばらくしてからお試しください。", "분석 서비스가 혼잡합니다. 잠시 후 다시 시도해 주세요.", "Dịch vụ đang bận. Vui lòng thử lại sau.", "บริการไม่ว่าง กรุณาลองใหม่อีกครั้ง"),
  form: L("Character form", "字形", "字形", "字形", "자형", "Hình chữ", "รูปอักษร"),
  traditional: L("Traditional form", "繁体", "繁體", "旧字体", "번체", "Dạng phồn thể", "ตัวเต็ม"),
  strokes: L("Kangxi strokes", "康熙笔画", "康熙筆畫", "康熙画数", "강희 획수", "Số nét Khang Hy", "จำนวนขีดคังซี"),
  strokesNote: L("Counted by the Kangxi dictionary; correct it if you know it differs.", "按康熙字典计；如果你知道笔画不同，可以修改。", "按康熙字典計；如果你知道筆畫不同，可以修改。", "康熙字典の画数です。違う場合は修正できます。", "강희자전 기준입니다. 다르면 고칠 수 있습니다.", "Theo Khang Hy tự điển; có thể sửa nếu bạn biết khác.", "นับตามพจนานุกรมคังซี แก้ไขได้หากทราบว่าต่างไป"),
  structure: L("Structure", "结构", "結構", "構造", "구조", "Kết cấu", "โครงสร้าง"),
  radical: L("Radical", "部首", "部首", "部首", "부수", "Bộ thủ", "หมวดนำ"),
  element: L("Radical element", "部首五行", "部首五行", "部首の五行", "부수 오행", "Ngũ hành bộ thủ", "ธาตุของหมวดนำ"),
  components: L("Components", "拆字", "拆字", "構成要素", "구성 요소", "Các thành phần", "ส่วนประกอบ"),
  meaning: L("Meaning", "字义", "字義", "字義", "뜻", "Nghĩa", "ความหมาย"),
  cast: L("Hexagram from the strokes", "笔画起卦", "筆畫起卦", "画数による卦", "획수 기괘", "Lập quẻ từ số nét", "ตั้งกว้าจากจำนวนขีด"),
  original: L("Original", "本卦", "本卦", "本卦", "본괘", "Quẻ chủ", "กว้าหลัก"),
  mutual: L("Mutual", "互卦", "互卦", "互卦", "호괘", "Quẻ hỗ", "กว้าซ้อน"),
  changed: L("Changed", "变卦", "變卦", "変卦", "변괘", "Quẻ biến", "กว้าแปร"),
  moving: L("Moving line", "动爻", "動爻", "動爻", "동효", "Hào động", "เส้นเคลื่อน"),
  castNote: L("First part's strokes give the upper trigram, second part's the lower; their sum plus the hour gives the moving line.", "前半字笔画定上卦、后半字笔画定下卦，二者之和加时辰定动爻。", "前半字筆畫定上卦、後半字筆畫定下卦，二者之和加時辰定動爻。", "前半の画数で上卦、後半の画数で下卦、その和に時刻を加えて動爻を定めます。", "앞부분 획수로 상괘, 뒷부분 획수로 하괘, 그 합에 시진을 더해 동효를 정합니다.", "Số nét phần đầu định quẻ trên, phần sau định quẻ dưới; tổng cộng giờ định hào động.", "ขีดส่วนแรกกำหนดตรีแกรมบน ส่วนหลังกำหนดล่าง ผลรวมบวกชั่วยามกำหนดเส้นเคลื่อน"),
};
const structureNames: Record<Analysis["structure"], L7> = {
  single: L("Single unit", "独体字", "獨體字", "独体字", "독체자", "Chữ đơn thể", "อักษรเดี่ยว"),
  "left-right": L("Left and right", "左右结构", "左右結構", "左右構造", "좌우 구조", "Trái phải", "ซ้ายขวา"),
  "top-bottom": L("Top and bottom", "上下结构", "上下結構", "上下構造", "상하 구조", "Trên dưới", "บนล่าง"),
  enclosing: L("Enclosing", "包围结构", "包圍結構", "囲み構造", "에운 구조", "Bao quanh", "ล้อมรอบ"),
  other: L("Other", "其他结构", "其他結構", "その他", "기타", "Khác", "อื่น ๆ"),
};
const ELEMENT_EN: Record<string, string> = { 木: "Wood", 火: "Fire", 土: "Earth", 金: "Metal", 水: "Water" };

function todayIso() {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

export function CeziScreen({ locale, wallet, onSpend, onOpenMembership, navigate }: { locale: Locale; wallet: CreditWallet; onSpend: (tool: string) => boolean; onOpenMembership: () => void; navigate: (route: AppRoute) => void }) {
  const [character, setCharacter] = useState("");
  const [question, setQuestion] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [strokes, setStrokes] = useState<number[]>([]);
  const [castAt, setCastAt] = useState<Date | null>(null);
  const [version, setVersion] = useState(0);

  const analyse = async () => {
    const chars = [...character.trim()];
    if (chars.length !== 1 || !/^[㐀-䶿一-鿿]$/.test(chars[0])) { setMessage(t.invalid[locale]); return; }
    setBusy(true); setMessage("");
    try {
      const response = await fetch("/api/cezi/analyse", { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify({ character: chars[0], locale }) });
      const payload = await response.json().catch(() => ({})) as { analysis?: Analysis; code?: string };
      if (payload.code === "CEZI_LIMIT") { setMessage(t.limit[locale]); return; }
      if (!response.ok || !payload.analysis) { setMessage(payload.code === "INVALID_CHARACTER" ? t.invalid[locale] : t.failed[locale]); return; }
      setAnalysis(payload.analysis);
      setStrokes(payload.analysis.parts.length === 2 ? payload.analysis.parts.map((part) => part.strokes) : [payload.analysis.strokes]);
      setCastAt(new Date());
      setVersion((value) => value + 1);
    } catch { setMessage(t.failed[locale]); } finally { setBusy(false); }
  };

  const cast = useMemo(() => {
    if (!analysis || !castAt || !strokes.length) return null;
    const hourNumber = Math.floor(((castAt.getHours() + 1) % 24) / 2) + 1;
    const first = strokes[0];
    const second = strokes.length === 2 ? strokes[1] : strokes[0] + hourNumber;
    const result = plumBlossomNumberCast(first, second, hourNumber);
    const lines = result.lines;
    const moving = result.movingLines.findIndex(Boolean);
    const changed = lines.map((yang, index) => (index === moving ? !yang : yang));
    const mutual = [lines[1], lines[2], lines[3], lines[2], lines[3], lines[4]];
    const name = (set: boolean[]) => hexagramName(trigramOf(set.slice(0, 3)), trigramOf(set.slice(3, 6)));
    return { first, second, hourNumber, moving: moving + 1, original: name(lines), mutual: name(mutual), changed: name(changed), upper: trigramOf(lines.slice(3, 6)), lower: trigramOf(lines.slice(0, 3)) };
  }, [analysis, strokes, castAt]);

  const chart = useMemo<CompleteChart | null>(() => {
    if (!analysis || !cast) return null;
    const base = createStudyResult({ birthDate: todayIso(), birthTime: `${String(castAt!.getHours()).padStart(2, "0")}:${String(castAt!.getMinutes()).padStart(2, "0")}`, calendar: "solar", focus: question, name: "", companionName: "", module: "cezi", version });
    const total = strokes.reduce((sum, value) => sum + value, 0);
    return {
      tool: "cezi",
      calendar: base.calendar,
      pillars: base.pillars,
      board: { kind: "spread", label: "Character divination board", cells: [
        { id: "character", title: "Character", subtitle: analysis.character, active: true, tone: "gold", items: [
          { label: "Character", value: analysis.character }, { label: "Traditional form", value: analysis.traditional }, { label: "Kangxi strokes", value: String(total) },
          { label: "Structure", value: structureNames[analysis.structure].en }, { label: "Radical", value: analysis.radical || "—" }, { label: "Radical element", value: ELEMENT_EN[analysis.radicalElement] ?? "—" },
          { label: "Components", value: analysis.components.join(" · ") || "—" }, { label: "Meaning", value: analysis.meaning || "—" },
        ] },
        { id: "original", title: "Original hexagram", subtitle: cast.original.full, items: [{ label: "Hexagram", value: cast.original.full }, { label: "Upper trigram", value: cast.upper }, { label: "Lower trigram", value: cast.lower }, { label: "Moving lines", value: `Line ${cast.moving}` }] },
        { id: "mutual", title: "Mutual hexagram", subtitle: cast.mutual.full, items: [{ label: "Hexagram", value: cast.mutual.full }] },
        { id: "changed", title: "Transformed hexagram", subtitle: cast.changed.full, items: [{ label: "Hexagram", value: cast.changed.full }] },
      ] },
      sections: [
        { id: "cezi-form", title: "Character form", lead: "Form of the written character used for character divination", items: [{ label: "Parts", value: analysis.parts.map((part, index) => `${part.text} ${strokes[index] ?? part.strokes}`).join(" · ") }, { label: "Components", value: analysis.components.join(" · ") || "—" }] },
        { id: "cezi-cast", title: "Casting from strokes", lead: "First part's strokes give the upper trigram, second part's the lower; their sum plus the hour gives the moving line", items: [{ label: "Numbers", value: `${cast.first} · ${cast.second}` }, { label: "Hour", value: String(cast.hourNumber) }, { label: "Original hexagram", value: cast.original.full }, { label: "Transformed hexagram", value: cast.changed.full }] },
      ],
      sourceFacts: ["Character form analysed by the text model (Kangxi strokes can be corrected by the user).", "Hexagram cast from stroke counts and the hour (plum blossom number method)."],
      inputSummary: { focus: question, place: "—", version },
    };
  }, [analysis, cast, strokes, question, version, castAt]);

  return <section className="route-screen cezi-screen" data-route="cezi">
    <header className="route-heading">
      <p>{t.kicker[locale]}</p>
      <h1><span>字</span>{t.title[locale]}</h1>
      <p>{t.lead[locale]}</p>
    </header>
    <MethodHelp helpKey="cezi" locale={locale} navigate={navigate} />
    <div className="xiangshu-layout cezi-layout">
      <form className="xiangshu-form" onSubmit={(event) => { event.preventDefault(); void analyse(); }}>
        <label className="cezi-char"><span>{t.character[locale]}</span><input value={character} maxLength={2} onChange={(event) => setCharacter(event.target.value)} placeholder="福" lang="zh" /><small>{t.characterHint[locale]}</small></label>
        <label className="cezi-question"><span>{t.question[locale]}</span><textarea value={question} onChange={(event) => setQuestion(event.target.value)} rows={3} /></label>
        <button type="submit" className="primary-action" disabled={busy}>{busy ? t.analysing[locale] : t.analyse[locale]}<b>→</b></button>
        {message && <p className="form-error" role="alert">{message}</p>}
      </form>
      <div className="xiangshu-result">
        {analysis && cast ? <>
          <div className="cezi-big" aria-hidden="true">{analysis.character}</div>
          <h2>{t.form[locale]}</h2>
          <dl>
            {analysis.traditional !== analysis.character && <div><dt>{t.traditional[locale]}</dt><dd>{analysis.traditional}</dd></div>}
            <div><dt>{t.structure[locale]}</dt><dd>{structureNames[analysis.structure][locale]}</dd></div>
            <div><dt>{t.strokes[locale]}</dt><dd className="cezi-strokes">{analysis.parts.map((part, index) => <label key={index}>{analysis.parts.length > 1 && <span>{part.text}</span>}<input type="number" min={1} max={64} value={strokes[index] ?? part.strokes} onChange={(event) => { const next = [...strokes]; next[index] = Math.max(1, Math.min(64, Number(event.target.value) || 1)); setStrokes(next); }} /></label>)}<small>{t.strokesNote[locale]}</small></dd></div>
            {analysis.radical && <div><dt>{t.radical[locale]}</dt><dd>{analysis.radical}{analysis.radicalElement ? ` · ${localizeBoardTerm(ELEMENT_EN[analysis.radicalElement] ?? "", locale)}` : ""}</dd></div>}
            {analysis.components.length > 0 && <div><dt>{t.components[locale]}</dt><dd>{analysis.components.join(" · ")}</dd></div>}
            {analysis.meaning && <div><dt>{t.meaning[locale]}</dt><dd>{analysis.meaning}</dd></div>}
          </dl>
          <h2>{t.cast[locale]}</h2>
          <dl>
            <div><dt>{t.original[locale]}</dt><dd>{localizeBoardTerm(cast.original.full, locale)}</dd></div>
            <div><dt>{t.mutual[locale]}</dt><dd>{localizeBoardTerm(cast.mutual.full, locale)}</dd></div>
            <div><dt>{t.changed[locale]}</dt><dd>{localizeBoardTerm(cast.changed.full, locale)}</dd></div>
            <div><dt>{t.moving[locale]}</dt><dd>{localizeBoardTerm(`Line ${cast.moving}`, locale)}</dd></div>
          </dl>
          <small>{t.castNote[locale]}</small>
        </> : <div className="xiangshu-placeholder" aria-hidden="true">字</div>}
      </div>
    </div>
    {chart && <div className="xiangshu-reading"><InterpretationPanel key={version} autoStart chart={chart} locale={locale} wallet={wallet} onSpend={onSpend} onOpenMembership={onOpenMembership} onNavigate={(next) => navigate(next as AppRoute)} /></div>}
  </section>;
}
