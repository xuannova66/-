"use client";
// 「查看示例报告」: what a reading looks like, shown with a clearly fictional person. The chart is the real BaZi of the
// fictional birth data (checked in tests/sample-report.test.mjs); the text follows the real report structure:
// one-sentence conclusion, three key points, plain summary and the first chapter are free; chapters 2–6 and the
// follow-up suggestions are in the full report.
import { useEffect, useState } from "react";
import type { Locale } from "./site-content";
import { CREDIT_RULES } from "./benefits";

export const SAMPLE_CASE = { date: "1990-03-15", time: "08:30", gender: "female", pillars: ["庚午", "己卯", "己卯", "戊辰"], elements: { wood: 2, fire: 1, earth: 4, metal: 1, water: 0 } } as const;

type Sample = {
  badge: string; disclaimer: string; person: string; question: string;
  ui: { who: string; asked: string; open: string; close: string; title: string; lead: string; summary: string; conclusion: string; keyPoints: string; mapping: string; evidence: string; says: string; chapters: string; free: string; full: string; boundary: string; followUps: string; followLead: string; tryOwn: string; pillars: [string, string, string, string]; elements: string };
  conclusion: string; keyPoints: [string, string, string]; summary: string;
  mapping: Array<[string, string]>;
  chapters: [string, string, string, string, string, string]; firstChapter: string;
  followUps: [string, string, string];
};

const zhHans: Sample = {
  badge: "虚构示例", disclaimer: "本页人物、出生资料与解读内容均为虚构，仅用于展示报告的格式与结构，不针对任何真实的人。",
  person: "林清（虚构）· 女 · 公历 1990-03-15 08:30 · 按民用时计算", question: "未来两年，工作方向要不要调整？",
  ui: { who: "示例人物", asked: "提问", open: "查看示例报告", close: "关闭", title: "报告长什么样", lead: "用一个虚构案例，展示一份八字完整解读从头到尾的样子。", summary: "开头的白话总结", conclusion: "一句话结论", keyPoints: "三个要点", mapping: "盘面与解释如何对应", evidence: "盘面依据", says: "报告里的说法", chapters: "报告包含哪些章节", free: "免费可看", full: "完整版", boundary: "免费部分到第 1 章为止；第 2–6 章与追问建议需要解锁完整版（{n} 积分，注册用户首份八字免费）。", followUps: "可以继续追问什么", followLead: "完整报告末尾会给出三条追问建议，也可以自己提问；每次追问 {n} 积分。", tryOwn: "用自己的资料试试", pillars: ["年柱", "月柱", "日柱", "时柱"], elements: "五行：木 2 · 火 1 · 土 4 · 金 1 · 水 0（水藏于辰）" },
  conclusion: "未来两年更适合在现有领域把事情做实，用一两项看得见的成果换取主动权，而不是急着换赛道。",
  keyPoints: ["七杀当令：压力大，但也带来被看见的机会。", "伤官透出：多提方案，同时注意表达方式。", "比劫有力：找可靠的搭档一起推进。"],
  summary: "这张盘以己土为日主，生在卯月，月令七杀当旺，传统上代表外部要求多、责任重。年干庚金伤官透出，说明想法多、愿意改进；时柱戊辰与月干己土让你身边不缺帮手。整体看，适合稳中求进，以成果说话。",
  mapping: [
    ["日柱 己卯 · 日主己土", "你属于“己土”型：像田地，擅长承接、整理，把事情落地。"],
    ["月柱 己卯 · 卯木七杀当令", "工作环境往往要求高、节奏紧，压力感多来自规则与上级。"],
    ["年柱 庚午 · 庚金伤官透干", "表达和改良意见多，适合需要提出方案的岗位；措辞宜留余地。"],
    ["时柱 戊辰 · 比劫帮身", "可借力的同伴多，合作往往比单打独斗更顺。"],
    ["五行 · 水 0（藏于辰）", "代表“财”的水不显，传统上建议理财求稳，先养成固定储蓄的习惯。"],
  ],
  chapters: ["命局结构：日主与五行", "性格与优势", "工作与财务", "人际与亲密关系", "作息与健康节奏", "未来两年的节奏与建议"],
  firstChapter: "日主己土生于卯月，卯木为七杀，当令而旺，所以日主不得月令。不过年支午火生土，月干己土、时柱戊辰都是同类帮扶，传统上看属于中和略偏强的格局。这样的结构通常被理解为“扛得住压力，但需要把压力转成具体成果”。你可以留意：最近一次让你觉得被认可的事，是不是正好来自一项落了地的工作？",
  followUps: ["明年适合主动提出调岗吗？", "和上级沟通时，伤官的特点要注意什么？", "“财不显”在理财上具体可以怎么做？"],
};

const zhHant: Sample = {
  badge: "虛構示例", disclaimer: "本頁人物、出生資料與解讀內容均為虛構，僅用於展示報告的格式與結構，不針對任何真實的人。",
  person: "林清（虛構）· 女 · 公曆 1990-03-15 08:30 · 按民用時計算", question: "未來兩年，工作方向要不要調整？",
  ui: { who: "示例人物", asked: "提問", open: "查看示例報告", close: "關閉", title: "報告長什麼樣", lead: "用一個虛構案例，展示一份八字完整解讀從頭到尾的樣子。", summary: "開頭的白話總結", conclusion: "一句話結論", keyPoints: "三個要點", mapping: "盤面與解釋如何對應", evidence: "盤面依據", says: "報告裡的說法", chapters: "報告包含哪些章節", free: "免費可看", full: "完整版", boundary: "免費部分到第 1 章為止；第 2–6 章與追問建議需要解鎖完整版（{n} 積分，註冊用戶首份八字免費）。", followUps: "可以繼續追問什麼", followLead: "完整報告末尾會給出三條追問建議，也可以自己提問；每次追問 {n} 積分。", tryOwn: "用自己的資料試試", pillars: ["年柱", "月柱", "日柱", "時柱"], elements: "五行：木 2 · 火 1 · 土 4 · 金 1 · 水 0（水藏於辰）" },
  conclusion: "未來兩年更適合在現有領域把事情做實，用一兩項看得見的成果換取主動權，而不是急著換賽道。",
  keyPoints: ["七殺當令：壓力大，但也帶來被看見的機會。", "傷官透出：多提方案，同時注意表達方式。", "比劫有力：找可靠的搭檔一起推進。"],
  summary: "這張盤以己土為日主，生在卯月，月令七殺當旺，傳統上代表外部要求多、責任重。年干庚金傷官透出，說明想法多、願意改進；時柱戊辰與月干己土讓你身邊不缺幫手。整體看，適合穩中求進，以成果說話。",
  mapping: [
    ["日柱 己卯 · 日主己土", "你屬於「己土」型：像田地，擅長承接、整理，把事情落地。"],
    ["月柱 己卯 · 卯木七殺當令", "工作環境往往要求高、節奏緊，壓力感多來自規則與上級。"],
    ["年柱 庚午 · 庚金傷官透干", "表達和改良意見多，適合需要提出方案的崗位；措辭宜留餘地。"],
    ["時柱 戊辰 · 比劫幫身", "可借力的同伴多，合作往往比單打獨鬥更順。"],
    ["五行 · 水 0（藏於辰）", "代表「財」的水不顯，傳統上建議理財求穩，先養成固定儲蓄的習慣。"],
  ],
  chapters: ["命局結構：日主與五行", "性格與優勢", "工作與財務", "人際與親密關係", "作息與健康節奏", "未來兩年的節奏與建議"],
  firstChapter: "日主己土生於卯月，卯木為七殺，當令而旺，所以日主不得月令。不過年支午火生土，月干己土、時柱戊辰都是同類幫扶，傳統上看屬於中和略偏強的格局。這樣的結構通常被理解為「扛得住壓力，但需要把壓力轉成具體成果」。你可以留意：最近一次讓你覺得被認可的事，是不是正好來自一項落了地的工作？",
  followUps: ["明年適合主動提出調崗嗎？", "和上級溝通時，傷官的特點要注意什麼？", "「財不顯」在理財上具體可以怎麼做？"],
};

const en: Sample = {
  badge: "Fictional example", disclaimer: "The person, birth data and reading on this page are fictional. They only show the format and structure of a report and are not about any real person.",
  person: "Lin Qing (fictional) · female · 15 March 1990, 08:30 · civil time", question: "Should I change my work direction in the next two years?",
  ui: { who: "Person", asked: "Question", open: "See a sample report", close: "Close", title: "What a report looks like", lead: "A fictional case showing a full BaZi reading from start to finish.", summary: "Plain-language summary at the top", conclusion: "One-sentence conclusion", keyPoints: "Three key points", mapping: "How the chart maps to the text", evidence: "In the chart", says: "What the report says", chapters: "Chapters in the report", free: "Free", full: "Full report", boundary: "The free part ends after chapter 1. Chapters 2–6 and the follow-up suggestions need the full report ({n} credits; a registered member's first BaZi reading is free).", followUps: "What you can ask next", followLead: "The full report ends with three suggested follow-ups, or ask your own; each follow-up uses {n} credits.", tryOwn: "Try it with your own details", pillars: ["Year", "Month", "Day", "Hour"], elements: "Five elements: wood 2 · fire 1 · earth 4 · metal 1 · water 0 (hidden in Chen)" },
  conclusion: "The next two years favour making things solid in your current field and earning room to choose through one or two visible results, rather than rushing to switch tracks.",
  keyPoints: ["Seven Killings rules the month: real pressure, but also a chance to be noticed.", "Hurting Officer shows on a stem: bring proposals, and watch how you phrase them.", "Strong companions: find a reliable partner to move things forward."],
  summary: "This chart's day master is Ji earth, born in the Mao month, where Seven Killings is in season — traditionally read as heavy outside demands and responsibility. Geng metal, the Hurting Officer, shows on the year stem: plenty of ideas and a wish to improve things. The Wu Chen hour and the Ji month stem bring helpers. Overall: steady progress, letting results speak.",
  mapping: [
    ["Day pillar Ji Mao · day master Ji earth", "You are a “Ji earth” type: like a field, good at receiving, organising and getting things done."],
    ["Month pillar Ji Mao · Seven Killings in season", "Work settings tend to be demanding and fast; pressure comes mostly from rules and superiors."],
    ["Year pillar Geng Wu · Hurting Officer on the stem", "Many ideas for improvement; suits roles that propose solutions — leave room in how you say things."],
    ["Hour pillar Wu Chen · companions support", "Plenty of people to lean on; working together tends to go better than going it alone."],
    ["Elements · water 0 (hidden in Chen)", "Water, the “wealth” element here, is not visible; tradition suggests steady money habits, starting with regular saving."],
  ],
  chapters: ["Chart structure: day master and elements", "Temperament and strengths", "Work and money", "People and relationships", "Daily rhythm and health", "The next two years: rhythm and suggestions"],
  firstChapter: "Ji earth is born in the Mao month, where Mao wood is Seven Killings and in season, so the day master is out of season. Yet the Wu fire of the year branch feeds earth, and the Ji month stem and the Wu Chen hour pillar are companions, so the chart is traditionally read as balanced to slightly strong. Such a structure is usually understood as “able to carry pressure, but needing to turn it into concrete results”. You might notice whether the last time you felt recognised came from a piece of work you actually finished.",
  followUps: ["Is next year a good time to ask for a new role?", "What should I watch for with the Hurting Officer when talking to my manager?", "In practice, what does “wealth not visible” mean for my money habits?"],
};

const ja: Sample = {
  badge: "架空の例", disclaimer: "このページの人物・生年月日・解説はすべて架空です。レポートの形式と構成を示すためのもので、実在の人物とは関係ありません。",
  person: "リン・チン（架空）· 女性 · 1990年3月15日 8:30 · 標準時で計算", question: "これから2年、仕事の方向を変えるべき？",
  ui: { who: "人物", asked: "質問", open: "サンプルレポートを見る", close: "閉じる", title: "レポートの中身", lead: "架空のケースで、八字の完全な解説を最初から最後まで紹介します。", summary: "冒頭のやさしい要約", conclusion: "ひとことの結論", keyPoints: "3つのポイント", mapping: "盤と解説の対応", evidence: "盤の根拠", says: "レポートでの説明", chapters: "レポートの章立て", free: "無料", full: "完全版", boundary: "無料部分は第1章まで。第2〜6章と追加質問の提案は完全版（{n} クレジット、登録ユーザーは最初の八字が無料）。", followUps: "次に聞けること", followLead: "完全版の最後に追加質問の提案が3つあり、自分で質問することもできます。1回 {n} クレジット。", tryOwn: "自分の情報で試す", pillars: ["年柱", "月柱", "日柱", "時柱"], elements: "五行：木2・火1・土4・金1・水0（水は辰に蔵す）" },
  conclusion: "これからの2年は、今の分野で成果を固め、目に見える実績で選択の余地を広げる時期。急いで道を変える必要はありません。",
  keyPoints: ["七殺が月令に：プレッシャーは大きいが、認められる機会も。", "傷官が透る：提案は積極的に、言い方には配慮を。", "比劫が強い：頼れる相棒と一緒に進める。"],
  summary: "日主は己土、卯月の生まれで、月令は七殺が旺じています。伝統的には外からの要求と責任が重いと読みます。年干の庚金は傷官で、アイデアが多く改善志向。時柱の戊辰と月干の己土が支えとなり、協力者に恵まれます。全体として、着実に進み成果で語るタイプです。",
  mapping: [
    ["日柱 己卯・日主 己土", "「己土」タイプ：田畑のように受け止め、整理し、形にするのが得意。"],
    ["月柱 己卯・卯木の七殺が当令", "職場は要求が高くテンポも速め。プレッシャーは規則や上司から来やすい。"],
    ["年柱 庚午・庚金の傷官が透干", "改善案が多く、提案型の仕事に向く。言い方には余白を。"],
    ["時柱 戊辰・比劫が助ける", "頼れる仲間が多く、一人より協力したほうが順調。"],
    ["五行・水0（辰に蔵す）", "「財」にあたる水が表に出ていないので、お金は堅実に。まず定期的な貯蓄から。"],
  ],
  chapters: ["命式の構造：日主と五行", "性格と強み", "仕事とお金", "人間関係とパートナー", "生活リズムと健康", "これからの2年のリズムと提案"],
  firstChapter: "己土の日主は卯月生まれ。卯木は七殺で当令して旺じるため、日主は月令を得ません。しかし年支の午火が土を生じ、月干の己土と時柱の戊辰が同類として助けるので、伝統的には中和からやや強めと見ます。「プレッシャーに耐えられるが、それを具体的な成果に変える必要がある」構造とされます。最近認められたと感じた出来事が、実際に形になった仕事から来ていないか振り返ってみてください。",
  followUps: ["来年は自分から異動を申し出てもいい？", "上司と話すとき、傷官の特徴で気をつけることは？", "「財が表に出ない」とは、お金の習慣で具体的にどういうこと？"],
};

const ko: Sample = {
  badge: "가상의 예시", disclaimer: "이 페이지의 인물, 출생 정보, 해석은 모두 가상입니다. 리포트의 형식과 구성을 보여 주기 위한 것이며 실제 인물과 관련이 없습니다.",
  person: "린칭(가상) · 여성 · 1990년 3월 15일 08:30 · 표준시 기준", question: "앞으로 2년, 일의 방향을 바꿔야 할까요?",
  ui: { who: "인물", asked: "질문", open: "예시 리포트 보기", close: "닫기", title: "리포트는 이렇게 생겼습니다", lead: "가상의 사례로 사주 전체 해석을 처음부터 끝까지 보여 드립니다.", summary: "첫머리의 쉬운 요약", conclusion: "한 문장 결론", keyPoints: "세 가지 요점", mapping: "차트와 해석의 연결", evidence: "차트 근거", says: "리포트의 설명", chapters: "리포트 구성", free: "무료", full: "전체판", boundary: "무료 부분은 1장까지입니다. 2~6장과 추가 질문 제안은 전체판에서 볼 수 있습니다({n} 크레딧, 가입 회원은 첫 사주 무료).", followUps: "이어서 물어볼 수 있는 것", followLead: "전체판 끝에 추가 질문 제안 세 가지가 있고, 직접 질문할 수도 있습니다. 1회 {n} 크레딧.", tryOwn: "내 정보로 해 보기", pillars: ["연주", "월주", "일주", "시주"], elements: "오행: 목 2 · 화 1 · 토 4 · 금 1 · 수 0 (진토에 숨음)" },
  conclusion: "앞으로 2년은 지금 분야에서 일을 단단히 하고, 눈에 보이는 성과로 선택의 폭을 넓히기에 좋은 때입니다. 서둘러 길을 바꿀 필요는 없습니다.",
  keyPoints: ["칠살이 월령을 잡음: 압박은 크지만 인정받을 기회도 됩니다.", "상관이 드러남: 제안은 적극적으로, 표현은 부드럽게.", "비겁이 힘 있음: 믿을 만한 동료와 함께 추진하세요."],
  summary: "일간은 기토이고 묘월에 태어나 월령의 칠살이 왕합니다. 전통적으로 외부의 요구와 책임이 크다고 봅니다. 연간의 경금 상관이 드러나 아이디어가 많고 개선하려는 성향이 있습니다. 시주 무진과 월간 기토가 도와 주변에 조력자가 많습니다. 전체적으로 꾸준히 나아가며 성과로 말하는 구조입니다.",
  mapping: [
    ["일주 기묘 · 일간 기토", "‘기토’ 유형: 밭처럼 받아들이고 정리해 일을 실제로 이루어 냅니다."],
    ["월주 기묘 · 묘목 칠살이 월령", "업무 환경은 요구가 높고 속도가 빠른 편이며, 압박은 주로 규칙과 상사에게서 옵니다."],
    ["연주 경오 · 경금 상관 투출", "개선 의견이 많아 제안하는 역할에 맞습니다. 말할 때 여지를 남기세요."],
    ["시주 무진 · 비겁이 도움", "기댈 동료가 많아 혼자보다 함께할 때 순조롭습니다."],
    ["오행 · 수 0 (진토에 숨음)", "‘재’에 해당하는 수가 드러나지 않아 돈 관리는 안정적으로, 정기 저축부터 시작하길 권합니다."],
  ],
  chapters: ["명식 구조: 일간과 오행", "성격과 강점", "일과 재물", "인간관계와 연애", "생활 리듬과 건강", "앞으로 2년의 흐름과 제안"],
  firstChapter: "기토 일간이 묘월에 태어났고, 묘목은 칠살로 월령을 잡아 왕하므로 일간은 월령을 얻지 못합니다. 그러나 연지 오화가 토를 생하고 월간 기토와 시주 무진이 같은 기운으로 도와, 전통적으로는 중화에서 약간 강한 편으로 봅니다. ‘압박을 견딜 수 있지만 그것을 구체적인 성과로 바꿔야 하는’ 구조로 이해됩니다. 최근 인정받았다고 느낀 일이 실제로 마무리한 일에서 비롯되었는지 돌아보세요.",
  followUps: ["내년에 먼저 부서 이동을 요청해도 될까요?", "상사와 대화할 때 상관의 특징에서 주의할 점은?", "‘재가 드러나지 않음’은 돈 습관에서 구체적으로 무엇을 뜻하나요?"],
};

const vi: Sample = {
  badge: "Ví dụ hư cấu", disclaimer: "Nhân vật, ngày sinh và nội dung giải đọc trên trang này đều là hư cấu, chỉ để minh họa hình thức và cấu trúc của báo cáo, không nói về người thật nào.",
  person: "Lâm Thanh (hư cấu) · nữ · 15/03/1990, 08:30 · giờ dân dụng", question: "Hai năm tới có nên đổi hướng công việc không?",
  ui: { who: "Nhân vật", asked: "Câu hỏi", open: "Xem báo cáo mẫu", close: "Đóng", title: "Một báo cáo trông như thế nào", lead: "Một trường hợp hư cấu cho thấy bài giải Bát tự đầy đủ từ đầu đến cuối.", summary: "Tóm tắt dễ hiểu ở đầu", conclusion: "Kết luận một câu", keyPoints: "Ba ý chính", mapping: "Lá số khớp với lời giải thế nào", evidence: "Trong lá số", says: "Báo cáo nói gì", chapters: "Các chương của báo cáo", free: "Miễn phí", full: "Bản đầy đủ", boundary: "Phần miễn phí kết thúc sau chương 1. Chương 2–6 và gợi ý hỏi tiếp nằm trong bản đầy đủ ({n} điểm; thành viên đăng ký được miễn phí bài Bát tự đầu tiên).", followUps: "Có thể hỏi tiếp gì", followLead: "Cuối bản đầy đủ có ba gợi ý hỏi tiếp, hoặc bạn tự đặt câu hỏi; mỗi lần hỏi tiếp {n} điểm.", tryOwn: "Thử với thông tin của bạn", pillars: ["Năm", "Tháng", "Ngày", "Giờ"], elements: "Ngũ hành: Mộc 2 · Hỏa 1 · Thổ 4 · Kim 1 · Thủy 0 (ẩn trong Thìn)" },
  conclusion: "Hai năm tới hợp với việc làm vững chắc trong lĩnh vực hiện tại và dùng một hai kết quả rõ ràng để có thêm quyền lựa chọn, thay vì vội đổi hướng.",
  keyPoints: ["Thất Sát nắm lệnh tháng: áp lực lớn nhưng cũng là cơ hội được ghi nhận.", "Thương Quan lộ ra: hãy đề xuất nhiều, nhưng chú ý cách nói.", "Tỷ Kiếp mạnh: tìm người cộng sự đáng tin để cùng làm."],
  summary: "Nhật chủ là Kỷ Thổ, sinh tháng Mão, Thất Sát đương lệnh — theo truyền thống là yêu cầu bên ngoài nhiều, trách nhiệm nặng. Canh Kim Thương Quan lộ ở can năm: nhiều ý tưởng, muốn cải tiến. Trụ giờ Mậu Thìn và can tháng Kỷ Thổ đem lại người giúp đỡ. Nhìn chung: tiến chắc, để kết quả lên tiếng.",
  mapping: [
    ["Trụ ngày Kỷ Mão · Nhật chủ Kỷ Thổ", "Bạn thuộc kiểu “Kỷ Thổ”: như ruộng đất, giỏi tiếp nhận, sắp xếp và làm cho việc thành hình."],
    ["Trụ tháng Kỷ Mão · Thất Sát đương lệnh", "Môi trường làm việc thường đòi hỏi cao, nhịp nhanh; áp lực chủ yếu từ quy định và cấp trên."],
    ["Trụ năm Canh Ngọ · Thương Quan lộ can", "Nhiều ý kiến cải tiến, hợp vai trò đưa ra giải pháp — nói năng nên chừa chỗ."],
    ["Trụ giờ Mậu Thìn · Tỷ Kiếp trợ thân", "Nhiều bạn đồng hành để dựa vào; hợp tác thường thuận hơn làm một mình."],
    ["Ngũ hành · Thủy 0 (ẩn trong Thìn)", "Thủy — hành “tài” ở đây — không lộ; truyền thống khuyên quản lý tiền ổn định, bắt đầu từ tiết kiệm đều đặn."],
  ],
  chapters: ["Cấu trúc lá số: nhật chủ và ngũ hành", "Tính cách và điểm mạnh", "Công việc và tài chính", "Quan hệ và tình cảm", "Nhịp sinh hoạt và sức khỏe", "Hai năm tới: nhịp độ và gợi ý"],
  firstChapter: "Kỷ Thổ sinh tháng Mão; Mão Mộc là Thất Sát, đương lệnh nên vượng, vì vậy nhật chủ không được lệnh tháng. Tuy vậy Ngọ Hỏa ở chi năm sinh Thổ, can tháng Kỷ Thổ và trụ giờ Mậu Thìn đều là cùng loại trợ giúp, nên theo truyền thống lá số được xem là trung hòa hơi mạnh. Cấu trúc này thường được hiểu là “chịu được áp lực, nhưng cần biến áp lực thành kết quả cụ thể”. Bạn có thể để ý xem lần gần nhất được ghi nhận có phải đến từ một việc đã thực sự hoàn thành.",
  followUps: ["Năm sau có nên chủ động xin chuyển vị trí không?", "Khi nói chuyện với cấp trên, cần chú ý gì về Thương Quan?", "“Tài không lộ” cụ thể nghĩa là gì với thói quen tiền bạc?"],
};

const th: Sample = {
  badge: "ตัวอย่างสมมติ", disclaimer: "บุคคล ข้อมูลวันเกิด และคำอธิบายในหน้านี้เป็นเรื่องสมมติทั้งหมด ใช้เพื่อแสดงรูปแบบและโครงสร้างของรายงานเท่านั้น ไม่เกี่ยวกับบุคคลจริง",
  person: "หลินชิง (สมมติ) · หญิง · 15 มี.ค. 1990 เวลา 08:30 · คำนวณตามเวลามาตรฐาน", question: "สองปีข้างหน้าควรเปลี่ยนทิศทางงานไหม",
  ui: { who: "บุคคล", asked: "คำถาม", open: "ดูรายงานตัวอย่าง", close: "ปิด", title: "รายงานมีหน้าตาแบบนี้", lead: "กรณีสมมติที่แสดงคำอธิบายปาจื้อฉบับเต็มตั้งแต่ต้นจนจบ", summary: "สรุปภาษาง่ายตอนต้น", conclusion: "ข้อสรุปหนึ่งประโยค", keyPoints: "สามประเด็นหลัก", mapping: "ผังดวงเชื่อมกับคำอธิบายอย่างไร", evidence: "หลักฐานในผัง", says: "รายงานบอกว่า", chapters: "บทในรายงาน", free: "ฟรี", full: "ฉบับเต็ม", boundary: "ส่วนฟรีจบที่บทที่ 1 บทที่ 2–6 และคำถามแนะนำอยู่ในฉบับเต็ม ({n} เครดิต สมาชิกที่สมัครแล้วได้ปาจื้อฉบับแรกฟรี)", followUps: "ถามต่ออะไรได้บ้าง", followLead: "ท้ายฉบับเต็มมีคำถามแนะนำ 3 ข้อ หรือถามเองก็ได้ ถามต่อครั้งละ {n} เครดิต", tryOwn: "ลองด้วยข้อมูลของคุณ", pillars: ["ปี", "เดือน", "วัน", "ยาม"], elements: "ห้าธาตุ: ไม้ 2 · ไฟ 1 · ดิน 4 · ทอง 1 · น้ำ 0 (ซ่อนในเฉิน)" },
  conclusion: "สองปีข้างหน้าเหมาะกับการทำงานในสายเดิมให้มั่นคง และใช้ผลงานที่เห็นชัดหนึ่งสองชิ้นเพื่อเปิดทางเลือก มากกว่ารีบเปลี่ยนสาย",
  keyPoints: ["ชีซาครองเดือน: แรงกดดันสูง แต่ก็เป็นโอกาสให้ถูกมองเห็น", "ซางกวนปรากฏ: เสนอความคิดได้มาก แต่ระวังวิธีพูด", "เพื่อนร่วมธาตุแข็งแรง: หาคู่หูที่ไว้ใจได้มาช่วยผลักดัน"],
  summary: "เจ้าชะตาคือดินจี่ เกิดเดือนเหมา ชีซาครองฤดู ตามตำราหมายถึงความคาดหวังจากภายนอกและภาระที่หนัก ทองเกิงซึ่งเป็นซางกวนปรากฏที่ก้านปี แสดงว่ามีความคิดมากและอยากปรับปรุง เสาชั่วยามอู้เฉินและก้านเดือนจี่ช่วยให้มีผู้สนับสนุน โดยรวมคือก้าวอย่างมั่นคงและให้ผลงานพูดแทน",
  mapping: [
    ["เสาวัน จี่เหมา · เจ้าชะตาดินจี่", "คุณเป็นแบบ “ดินจี่” เหมือนผืนนา เก่งเรื่องรับ จัดระเบียบ และทำให้งานเกิดขึ้นจริง"],
    ["เสาเดือน จี่เหมา · ไม้เหมาเป็นชีซาครองฤดู", "ที่ทำงานมักคาดหวังสูงและเร่ง แรงกดดันมาจากกฎและหัวหน้าเป็นหลัก"],
    ["เสาปี เกิงอู่ · ซางกวนปรากฏบนก้าน", "มีข้อเสนอปรับปรุงมาก เหมาะกับบทบาทที่ต้องเสนอทางออก แต่ควรพูดให้มีที่ว่าง"],
    ["เสาชั่วยาม อู้เฉิน · เพื่อนร่วมธาตุช่วย", "มีคนให้พึ่งพามาก ทำงานร่วมกันมักราบรื่นกว่าทำคนเดียว"],
    ["ห้าธาตุ · น้ำ 0 (ซ่อนในเฉิน)", "น้ำซึ่งเป็นธาตุ “ทรัพย์” ไม่ปรากฏ ตำราแนะนำให้จัดการเงินอย่างมั่นคง เริ่มจากออมเป็นประจำ"],
  ],
  chapters: ["โครงสร้างดวง: เจ้าชะตาและห้าธาตุ", "นิสัยและจุดแข็ง", "งานและการเงิน", "ผู้คนและความสัมพันธ์", "จังหวะชีวิตและสุขภาพ", "สองปีข้างหน้า: จังหวะและคำแนะนำ"],
  firstChapter: "ดินจี่เกิดเดือนเหมา ไม้เหมาเป็นชีซาและครองฤดูจึงแข็งแรง เจ้าชะตาจึงไม่ได้ฤดู แต่ไฟอู่ที่กิ่งปีให้กำเนิดดิน ก้านเดือนจี่และเสาชั่วยามอู้เฉินเป็นพวกเดียวกันที่ช่วยเหลือ ตามตำราจึงมองว่าค่อนข้างสมดุลถึงแข็งเล็กน้อย โครงสร้างแบบนี้มักเข้าใจว่า “รับแรงกดดันได้ แต่ต้องเปลี่ยนแรงกดดันเป็นผลงานที่จับต้องได้” ลองสังเกตว่าครั้งล่าสุดที่รู้สึกได้รับการยอมรับ มาจากงานที่ทำเสร็จจริงหรือไม่",
  followUps: ["ปีหน้าควรขอย้ายตำแหน่งเองไหม", "เวลาคุยกับหัวหน้า ควรระวังลักษณะซางกวนอย่างไร", "“ทรัพย์ไม่ปรากฏ” หมายถึงอะไรในเรื่องนิสัยการเงิน"],
};

export const sampleReports: Record<Locale, Sample> = { en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th };

export function SampleReportBody({ locale }: { locale: Locale }) {
  const s = sampleReports[locale] ?? en;
  const n = (value: string, amount: number) => value.replace("{n}", String(amount));
  return <div className="sample-report" data-testid="sample-report">
    <p className="sample-badge"><b>{s.badge}</b><span>{s.disclaimer}</span></p>
    <dl className="sample-case"><div><dt>{s.ui.who}</dt><dd>{s.person}</dd></div><div><dt>{s.ui.asked}</dt><dd>{s.question}</dd></div></dl>
    <div className="sample-pillars" aria-label={s.ui.evidence}>{SAMPLE_CASE.pillars.map((pillar, index) => <span key={index}><small>{s.ui.pillars[index]}</small><b>{pillar}</b></span>)}</div>
    <p className="sample-elements">{s.ui.elements}</p>

    <section><h4>{s.ui.summary}<em className="is-free">{s.ui.free}</em></h4>
      <p className="sample-conclusion"><small>{s.ui.conclusion}</small>{s.conclusion}</p>
      <small className="sample-sub">{s.ui.keyPoints}</small><ul className="sample-points">{s.keyPoints.map((point) => <li key={point}>{point}</li>)}</ul>
      <p>{s.summary}</p>
    </section>

    <section><h4>{s.ui.mapping}</h4>
      <table className="sample-map"><thead><tr><th scope="col">{s.ui.evidence}</th><th scope="col">{s.ui.says}</th></tr></thead>
        <tbody>{s.mapping.map(([evidence, says]) => <tr key={evidence}><th scope="row">{evidence}</th><td>{says}</td></tr>)}</tbody></table>
    </section>

    <section><h4>{s.ui.chapters}</h4>
      <ol className="sample-chapters">{s.chapters.map((title, index) => <li key={title} className={index === 0 ? "is-free" : "is-locked"}>
        <span>{title}</span><em>{index === 0 ? s.ui.free : s.ui.full}</em>
        {index === 0 && <p>{s.firstChapter}</p>}
      </li>)}</ol>
      <p className="sample-boundary">{n(s.ui.boundary, CREDIT_RULES.report)}</p>
    </section>

    <section><h4>{s.ui.followUps}<em>{s.ui.full}</em></h4>
      <ul className="sample-follow">{s.followUps.map((item) => <li key={item}>{item}</li>)}</ul>
      <p className="sample-sub">{n(s.ui.followLead, CREDIT_RULES.followUp)}</p>
    </section>
  </div>;
}

/** Button that opens the sample report in a dialog. */
export function SampleReportButton({ locale, className = "secondary-action", onTry }: { locale: Locale; className?: string; onTry?: () => void }) {
  const [open, setOpen] = useState(false);
  const s = sampleReports[locale] ?? en;
  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") setOpen(false); };
    window.addEventListener("keydown", onKey);
    const overflow = document.body.style.overflow; document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", onKey); document.body.style.overflow = overflow; };
  }, [open]);
  return <>
    <button type="button" className={className} onClick={() => setOpen(true)} data-testid="sample-report-open">{s.ui.open}<b>↗</b></button>
    {open && <div className="sample-overlay" role="presentation" onClick={(event) => { if (event.target === event.currentTarget) setOpen(false); }}>
      <div className="sample-dialog" role="dialog" aria-modal="true" aria-label={s.ui.title}>
        <header><div><span>{s.badge}</span><h3>{s.ui.title}</h3><p>{s.ui.lead}</p></div><button type="button" className="sample-close" onClick={() => setOpen(false)} aria-label={s.ui.close}>×</button></header>
        <SampleReportBody locale={locale} />
        {onTry && <footer><button type="button" className="primary-action" onClick={() => { setOpen(false); onTry(); }}>{s.ui.tryOwn}<b>↗</b></button></footer>}
      </div>
    </div>}
  </>;
}

/** Home-page card: the conclusion and two mappings, plus the button for the whole sample. */
export function SampleReportTeaser({ locale, onTry }: { locale: Locale; onTry?: () => void }) {
  const s = sampleReports[locale] ?? en;
  return <div className="sample-teaser">
    <p className="sample-badge"><b>{s.badge}</b><span>{s.person}</span></p>
    <p className="sample-conclusion"><small>{s.ui.conclusion}</small>{s.conclusion}</p>
    <table className="sample-map"><tbody>{s.mapping.slice(0, 2).map(([evidence, says]) => <tr key={evidence}><th scope="row">{evidence}</th><td>{says}</td></tr>)}</tbody></table>
    <SampleReportButton locale={locale} className="primary-action" onTry={onTry} />
  </div>;
}
