"use client";
// Library shelf: favourite classics (members) and the last reading position per book.
// Members are synced through /api/member/library; everyone also keeps a copy in this browser,
// so the reader can reopen at the right place straight away.
import { useEffect, useState } from "react";
import type { Locale } from "./site-content";

export type ShelfItem = { workId: string; favorite: boolean; chapter: number | null; chapterCount: number | null; paragraph: number | null; chapterTitle: string | null; favoritedAt?: string | null; readAt: string | null };
export type Shelf = { signedIn: boolean; items: Record<string, ShelfItem> };

const LOCAL_KEY = "xuannova-library-shelf";
const EVENT = "xn:shelf";
let loading: Promise<Shelf> | null = null;
let current: Shelf | null = null;

function readLocal(): Record<string, ShelfItem> {
  try { const value = JSON.parse(window.localStorage.getItem(LOCAL_KEY) ?? "{}") as Record<string, ShelfItem>; return value && typeof value === "object" ? value : {}; } catch { return {}; }
}
function writeLocal(items: Record<string, ShelfItem>) {
  try { window.localStorage.setItem(LOCAL_KEY, JSON.stringify(items)); } catch { /* private mode */ }
}
function publish(shelf: Shelf) { current = shelf; window.dispatchEvent(new CustomEvent(EVENT, { detail: shelf })); }

async function post(workId: string, body: Record<string, unknown>) {
  const response = await fetch(`/api/member/library/${encodeURIComponent(workId)}`, { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
  return response.ok ? ((await response.json()) as { item: ShelfItem }).item : null;
}

/** Load the shelf once (members: server copy merged with this browser's newer reading positions). */
export function loadShelf(force = false): Promise<Shelf> {
  if (current && !force) return Promise.resolve(current);
  if (loading && !force) return loading;
  loading = (async () => {
    const local = readLocal();
    try {
      const response = await fetch("/api/member/library", { credentials: "same-origin", cache: "no-store" });
      if (response.ok) {
        const { items } = (await response.json()) as { items: ShelfItem[] };
        const merged: Record<string, ShelfItem> = Object.fromEntries(items.map((item) => [item.workId, item]));
        // A position read on this device while signed out (or offline) wins when it is newer.
        for (const item of Object.values(local)) {
          const server = merged[item.workId];
          if (item.chapter !== null && (!server?.readAt || (item.readAt ?? "") > server.readAt)) {
            merged[item.workId] = { ...(server ?? item), chapter: item.chapter, chapterCount: item.chapterCount, paragraph: item.paragraph, chapterTitle: item.chapterTitle, readAt: item.readAt, favorite: server?.favorite ?? false };
            void post(item.workId, { chapter: item.chapter, chapterCount: item.chapterCount, paragraph: item.paragraph, chapterTitle: item.chapterTitle });
          }
        }
        writeLocal(merged);
        const shelf = { signedIn: true, items: merged };
        publish(shelf); return shelf;
      }
    } catch { /* offline: fall back to this browser */ }
    const shelf = { signedIn: false, items: local };
    publish(shelf); return shelf;
  })();
  return loading;
}

if (typeof window !== "undefined") window.addEventListener("xuannova:member", () => { current = null; loading = null; void loadShelf(true); });

export function onShelf(listener: (shelf: Shelf) => void) {
  const handler = (event: Event) => listener((event as CustomEvent<Shelf>).detail);
  window.addEventListener(EVENT, handler);
  return () => window.removeEventListener(EVENT, handler);
}

let pending: ReturnType<typeof setTimeout> | null = null;
/** Remember where the reader is (saved locally at once, sent to the server after a short pause). */
export function saveReadingPosition(workId: string, position: { chapter: number; chapterCount: number; paragraph: number; chapterTitle: string }) {
  const shelf = current ?? { signedIn: false, items: readLocal() };
  const previous = shelf.items[workId];
  const item: ShelfItem = { workId, favorite: previous?.favorite ?? false, favoritedAt: previous?.favoritedAt ?? null, ...position, readAt: new Date().toISOString() };
  const items = { ...shelf.items, [workId]: item };
  writeLocal(items); publish({ ...shelf, items });
  if (!shelf.signedIn) return;
  if (pending) clearTimeout(pending);
  pending = setTimeout(() => { pending = null; void post(workId, position); }, 1200);
}

/** Favourite or unfavourite a book (members only). Returns false when the visitor is not signed in. */
export async function setFavorite(workId: string, favorite: boolean): Promise<boolean> {
  const shelf = current ?? (await loadShelf());
  if (!shelf.signedIn) return false;
  const previous = shelf.items[workId];
  const optimistic: ShelfItem = previous ? { ...previous, favorite } : { workId, chapter: null, chapterCount: null, paragraph: null, chapterTitle: null, readAt: null, favorite };
  publish({ ...shelf, items: { ...shelf.items, [workId]: optimistic } });
  const saved = await post(workId, { favorite });
  const latest = current ?? shelf;
  const items = { ...latest.items, [workId]: saved ?? { ...optimistic, favorite: previous?.favorite ?? false } };
  writeLocal(items); publish({ ...latest, items });
  return Boolean(saved);
}

export const progressPercent = (item: ShelfItem | undefined) => (item && item.chapter !== null && item.chapterCount ? Math.max(1, Math.min(100, Math.round(((item.chapter + 1) / item.chapterCount) * 100))) : 0);

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });
export const shelfText = {
  favorite: L("Add to favourites", "收藏", "收藏", "お気に入りに追加", "즐겨찾기", "Lưu vào yêu thích", "บันทึกเป็นรายการโปรด"),
  favorited: L("In your favourites", "已收藏", "已收藏", "お気に入り済み", "즐겨찾기됨", "Đã lưu", "อยู่ในรายการโปรดแล้ว"),
  signInToFavorite: L("Sign in as a member to save favourites; they follow you to any device.", "登录会员后即可收藏，换设备也能同步。", "登入會員後即可收藏，換裝置也能同步。", "会員としてログインするとお気に入りに保存でき、どの端末でも同期されます。", "회원으로 로그인하면 즐겨찾기를 저장하고 어느 기기에서나 볼 수 있습니다.", "Đăng nhập thành viên để lưu sách yêu thích, đồng bộ trên mọi thiết bị.", "เข้าสู่ระบบสมาชิกเพื่อบันทึกรายการโปรด และซิงก์ได้ทุกอุปกรณ์"),
  signIn: L("Sign in / register", "登录 / 注册", "登入 / 註冊", "ログイン / 登録", "로그인 / 가입", "Đăng nhập / Đăng ký", "เข้าสู่ระบบ / สมัคร"),
  myFavorites: L("My favourites", "我的收藏", "我的收藏", "お気に入り", "내 즐겨찾기", "Sách yêu thích", "รายการโปรด"),
  continueReading: L("Continue reading", "继续阅读", "繼續閱讀", "続きを読む", "이어 읽기", "Đọc tiếp", "อ่านต่อ"),
  continueAt: L("Continue: {title}", "继续阅读：{title}", "繼續閱讀：{title}", "続きから：{title}", "이어 읽기: {title}", "Đọc tiếp: {title}", "อ่านต่อ: {title}"),
  fromStart: L("Start from the beginning", "从头开始", "從頭開始", "最初から", "처음부터", "Đọc từ đầu", "เริ่มจากต้น"),
  progress: L("{p}% read", "已读 {p}%", "已讀 {p}%", "{p}% 読了", "{p}% 읽음", "Đã đọc {p}%", "อ่านแล้ว {p}%"),
  readTo: L("Stopped at: {title}", "读到：{title}", "讀到：{title}", "ここまで：{title}", "여기까지: {title}", "Đang đọc: {title}", "อ่านถึง: {title}"),
  shelfTitle: L("My bookshelf", "我的书架", "我的書架", "マイ本棚", "내 책장", "Tủ sách của tôi", "ชั้นหนังสือของฉัน"),
  shelfEmpty: L("No favourites or reading yet. Visit the library →", "还没有收藏或阅读记录。去藏经阁看看 →", "還沒有收藏或閱讀紀錄。去藏經閣看看 →", "まだお気に入りや読書記録はありません。書庫へ →", "아직 즐겨찾기나 읽은 기록이 없습니다. 도서관으로 →", "Chưa có sách yêu thích hay đang đọc. Vào thư viện →", "ยังไม่มีรายการโปรดหรือประวัติการอ่าน ไปที่คลังความรู้ →"),
  recent: L("Recently read", "最近阅读", "最近閱讀", "最近読んだ本", "최근 읽은 책", "Đọc gần đây", "อ่านล่าสุด"),
  all: L("All", "全部", "全部", "すべて", "전체", "Tất cả", "ทั้งหมด"),
};
export const fillShelf = (template: string, values: Record<string, string | number>) => template.replace(/\{(\w+)\}/g, (_, key: string) => String(values[key] ?? ""));

/** The shelf as React state (loads once, then follows every change). */
export function useShelf() {
  const [shelf, setShelf] = useState<Shelf | null>(null);
  useEffect(() => { let alive = true; void loadShelf().then((value) => { if (alive) setShelf(value); }); const stop = onShelf(setShelf); return () => { alive = false; stop(); }; }, []);
  return shelf;
}

/** Calls back once with ?book=<id> from the address, after the first render. */
export function useBookParam(open: (book: string) => void) {
  useEffect(() => {
    const timer = window.setTimeout(() => { const book = new URLSearchParams(window.location.search).get("book"); if (book) open(book); }, 0);
    return () => window.clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}
