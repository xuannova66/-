/** Local connection research only. No authentication, network verification,
 * transaction creation, signing, submission, UI integration or live use.
 */
import { hexToBytes, sha256 } from "viem";
const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
function decodeBase58(text: string): Uint8Array {
  if (!text || text.length > 64) throw new Error("INVALID_WALLET_ADDRESS");
  let value = 0n;
  for (const char of text) { const digit = ALPHABET.indexOf(char); if (digit < 0) throw new Error("INVALID_WALLET_ADDRESS"); value = value * 58n + BigInt(digit); }
  const bytes: number[] = [];
  while (value > 0n) { bytes.unshift(Number(value & 255n)); value >>= 8n; }
  let zeros = 0; while (text[zeros] === "1") zeros++;
  return Uint8Array.from([...new Array<number>(zeros).fill(0), ...bytes]);
}
function validSolana(address: string): boolean { try { return decodeBase58(address).length === 32; } catch { return false; } }
function validTron(address: string): boolean {
  try {
    const bytes = decodeBase58(address);
    if (bytes.length !== 25 || bytes[0] !== 0x41) return false;
    const digest = hexToBytes(sha256(hexToBytes(sha256(bytes.slice(0, 21)))));
    return bytes.slice(21).every((byte, index) => byte === digest[index]);
  } catch { return false; }
}
type PublicKey = { toString(): string };
export type SolanaWallet = { connect(): Promise<{ publicKey: PublicKey }>; publicKey?: PublicKey | null; isConnected?: boolean };
export type TronWallet = { request(args: {method: string}): Promise<unknown>; tronWeb?: false | {ready?: boolean; defaultAddress?: {base58?: string}} };

/** A wallet connection reveals an address; it does NOT establish which Solana
 * cluster a wallet uses. Network/transaction verification is a separate gate.
 */
export async function connectSolanaDraft(provider: SolanaWallet) {
  if (!provider || typeof provider.connect !== "function") throw new Error("WALLET_NOT_AVAILABLE");
  const result = await provider.connect();
  const address = result?.publicKey?.toString();
  if (typeof address !== "string" || !validSolana(address)) throw new Error("INVALID_WALLET_ADDRESS");
  if (provider.publicKey && provider.publicKey.toString() !== address) throw new Error("WALLET_ACCOUNT_CHANGED");
  return { address, chain: "solana" as const, networkVerified: false as const };
}

/** TronLink authorization does not prove the currently configured network.
 * Mainnet verification and signed member login must occur separately.
 */
export async function connectTronDraft(provider: TronWallet) {
  if (!provider || typeof provider.request !== "function") throw new Error("WALLET_NOT_AVAILABLE");
  const accounts = await provider.request({ method: "eth_requestAccounts" });
  if (!Array.isArray(accounts) || typeof accounts[0] !== "string" || !validTron(accounts[0])) throw new Error("INVALID_WALLET_ADDRESS");
  const web = provider.tronWeb;
  if (!web || !web.ready || web.defaultAddress?.base58 !== accounts[0]) throw new Error("WALLET_ACCOUNT_UNAVAILABLE_OR_CHANGED");
  return { address: accounts[0] as string, chain: "tron" as const, networkVerified: false as const };
}
