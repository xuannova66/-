"use client";

import { useState } from "react";
import type { Locale } from "./site-content";
import { linkSolanaWallet, linkTronWallet, type SolanaSignWallet, type TronSignWallet } from "./wallet-link-client";

const copy: Record<Locale, { title: string; note: string; pending: string; success: string; failure: string }> = {
  en: { title: "Link another wallet", note: "Linking verifies ownership only. Solana and TRON payments are not yet available.", pending: "Confirm the connection and signature in your wallet…", success: "Wallet linked", failure: "Could not link wallet. Check that it is installed and unlocked, then retry." },
  "zh-Hans": { title: "关联其他钱包", note: "关联仅用于验证钱包归属，Solana 和 TRON 支付尚未开放。", pending: "请在钱包中确认连接及签名…", success: "钱包已关联", failure: "关联失败，请检查钱包是否安装并解锁后重试。" },
  "zh-Hant": { title: "關聯其他錢包", note: "關聯僅用於驗證錢包歸屬，Solana 和 TRON 付款尚未開放。", pending: "請在錢包中確認連線及簽名…", success: "錢包已關聯", failure: "關聯失敗，請檢查錢包是否安裝並解鎖後重試。" },
  ja: { title: "別のウォレットを連携", note: "連携は所有権の確認のみです。Solana と TRON の決済はまだ利用できません。", pending: "ウォレットで接続と署名を確認してください…", success: "ウォレットを連携しました", failure: "連携できませんでした。ウォレットを確認して再試行してください。" },
  ko: { title: "다른 지갑 연결", note: "연결은 소유권 확인만 합니다. Solana 및 TRON 결제는 아직 지원되지 않습니다.", pending: "지갑에서 연결과 서명을 확인하세요…", success: "지갑이 연결되었습니다", failure: "연결하지 못했습니다. 지갑을 확인한 후 다시 시도하세요." },
  vi: { title: "Liên kết ví khác", note: "Liên kết chỉ xác minh quyền sở hữu. Thanh toán Solana và TRON chưa khả dụng.", pending: "Xác nhận kết nối và chữ ký trong ví…", success: "Đã liên kết ví", failure: "Không thể liên kết. Hãy kiểm tra ví và thử lại." },
  th: { title: "เชื่อมกระเป๋าอื่น", note: "การเชื่อมใช้ยืนยันความเป็นเจ้าของเท่านั้น ยังไม่เปิดชำระเงินผ่าน Solana และ TRON", pending: "ยืนยันการเชื่อมต่อและลายเซ็นในกระเป๋า…", success: "เชื่อมกระเป๋าแล้ว", failure: "เชื่อมไม่ได้ โปรดตรวจสอบกระเป๋าแล้วลองอีกครั้ง" },
};

type WalletWindow = Window & { phantom?: { solana?: SolanaSignWallet }; solana?: SolanaSignWallet; tronLink?: TronSignWallet };

export function MultichainWalletLink({ locale }: { locale: Locale }) {
  const text = copy[locale];
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("");
  async function link(chain: "solana" | "tron") {
    if (busy) return;
    setBusy(true); setStatus(text.pending);
    try {
      const wallet = window as WalletWindow;
      const provider = chain === "solana" ? wallet.phantom?.solana ?? wallet.solana : wallet.tronLink;
      if (!provider) throw new Error("WALLET_NOT_AVAILABLE");
      const address = chain === "solana" ? await linkSolanaWallet(provider as SolanaSignWallet) : await linkTronWallet(provider as TronSignWallet);
      setStatus(`${text.success}: ${address}`);
    } catch { setStatus(text.failure); } finally { setBusy(false); }
  }
  return <section className="mc-card" data-testid="multichain-wallet-link">
    <header><h3>{text.title}</h3><p>{text.note}</p></header>
    <div><button type="button" className="text-action" disabled={busy} onClick={() => void link("solana")}>Phantom / Solana</button>{" · "}<button type="button" className="text-action" disabled={busy} onClick={() => void link("tron")}>TronLink</button></div>
    {status && <p role="status" style={{ overflowWrap: "anywhere" }}>{status}</p>}
  </section>;
}
