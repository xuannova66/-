"use client";

import { useMemo, useState } from "react";
import { rememberScroll } from "./scroll-memory";
import { classicalWorks, libraryCategories, localizedLibraryTitle, type ClassicalWork, type LibraryCategory } from "./library-catalogue";
import type { Locale } from "./site-content";
import { libraryGuide } from "./library-guides";
import { LibraryReader } from "./library-reader";
import { fillShelf, progressPercent, setFavorite, shelfText, useBookParam, useShelf, type Shelf } from "./library-shelf";
import { pathFor } from "./study-navigation";

function openMembership(locale: Locale) {
  rememberScroll();
  window.history.pushState({ scrollY: 0 }, "", pathFor(locale, "membership"));
  window.dispatchEvent(new Event("xn:navigate"));
  window.scrollTo({ top: 0, behavior: "instant" });
}

function FavoriteButton({ workId, locale, shelf }: { workId: string; locale: Locale; shelf: Shelf | null }) {
  const [note, setNote] = useState(false);
  const favorite = Boolean(shelf?.items[workId]?.favorite);
  return <div className="library-favorite">
    <button type="button" className={`secondary-action${favorite ? " is-on" : ""}`} aria-pressed={favorite} onClick={() => {
      if (!shelf?.signedIn) { setNote(true); return; }
      void setFavorite(workId, !favorite);
    }}>{favorite ? "★" : "☆"} {favorite ? shelfText.favorited[locale] : shelfText.favorite[locale]}</button>
    {note && !shelf?.signedIn && <p role="status">{shelfText.signInToFavorite[locale]} <button type="button" className="text-action" onClick={() => openMembership(locale)}>{shelfText.signIn[locale]} →</button></p>}
  </div>;
}

type LibraryCopy = {
  eyebrow: string; title: string; lead: string; count: string; search: string; all: string;
  categories: Record<LibraryCategory, string>; open: string; close: string;
  record: string; noResults: string; related: string; original: string;
};

const copy: Record<Locale, LibraryCopy> = {
  en: { eyebrow: "XUANNOVA ARCHIVE", title: "Classics library", lead: "Classics for every study method. Select a title for its guide and read the full text here.", count: "catalogue records", search: "Search titles, topics or methods", all: "All", categories: { foundation: "Foundations", bazi: "BaZi", ziwei: "Zi Wei", qimen: "Qi Men", liuyao: "Liuyao", daliuren: "Da Liu Ren", qizheng: "Celestial", reflection: "Reflection" }, open: "View record", close: "Back to list", record: "Archive record", noResults: "No records match that search.", related: "Related study", original: "Original title" },
  "zh-Hans": { eyebrow: "Xuannova · 藏经阁", title: "东方典籍目录", lead: "覆盖全部研习工具的典籍目录。选择书目即可查看导读，并在站内阅读全文。", count: "册典籍记录", search: "搜索书名、主题或研习工具", all: "全部", categories: { foundation: "基础典籍", bazi: "八字", ziwei: "紫微斗数", qimen: "奇门遁甲", liuyao: "六爻", daliuren: "大六壬", qizheng: "七政四余", reflection: "观照研习" }, open: "查看资料", close: "返回目录", record: "档案记录", noResults: "没有符合此次搜索的典籍记录。", related: "关联研习", original: "原典书名" },
  "zh-Hant": { eyebrow: "Xuannova · 藏經閣", title: "東方典籍目錄", lead: "覆蓋全部研習工具的典籍目錄。選擇書目即可查看導讀，並在站內閱讀全文。", count: "冊典籍記錄", search: "搜尋書名、主題或研習工具", all: "全部", categories: { foundation: "基礎典籍", bazi: "八字", ziwei: "紫微斗數", qimen: "奇門遁甲", liuyao: "六爻", daliuren: "大六壬", qizheng: "七政四餘", reflection: "觀照研習" }, open: "查看資料", close: "返回目錄", record: "檔案記錄", noResults: "沒有符合此次搜尋的典籍記錄。", related: "關聯研習", original: "原典書名" },
  ja: { eyebrow: "Xuannova · 蔵経閣", title: "東方古典目録", lead: "すべての学習ツールに対応する古典の目録です。書目を選ぶとガイドを読み、サイト内で全文を読めます。", count: "件の典籍記録", search: "書名・テーマ・学習ツールを検索", all: "すべて", categories: { foundation: "基礎典籍", bazi: "四柱推命", ziwei: "紫微斗数", qimen: "奇門遁甲", liuyao: "六爻", daliuren: "大六壬", qizheng: "天体研究", reflection: "内省研究" }, open: "記録を見る", close: "目録に戻る", record: "アーカイブ記録", noResults: "検索に一致する典籍記録はありません。", related: "関連する学習", original: "原典名" },
  ko: { eyebrow: "Xuannova · 장경각", title: "동양 고전 목록", lead: "모든 학습 도구를 위한 고전 목록입니다. 서목을 선택하면 안내를 보고 사이트에서 전문을 읽을 수 있습니다.", count: "권의 전적 기록", search: "책 제목, 주제 또는 학습 도구 검색", all: "전체", categories: { foundation: "기초 전적", bazi: "사주", ziwei: "자미두수", qimen: "기문둔갑", liuyao: "육효", daliuren: "대육임", qizheng: "천체 연구", reflection: "성찰 연구" }, open: "기록 보기", close: "목록으로 돌아가기", record: "아카이브 기록", noResults: "검색과 일치하는 전적 기록이 없습니다.", related: "연결된 학습", original: "원전 제목" },
  vi: { eyebrow: "XUANNOVA · TÀNG KINH CÁC", title: "Danh mục kinh điển Đông phương", lead: "Danh mục kinh điển cho mọi công cụ học tập. Chọn một tựa sách để xem phần giới thiệu và đọc toàn văn ngay tại đây.", count: "hồ sơ kinh điển", search: "Tìm theo tên sách, chủ đề hoặc công cụ", all: "Tất cả", categories: { foundation: "Nền tảng", bazi: "Bát tự", ziwei: "Tử vi", qimen: "Kỳ Môn", liuyao: "Lục Hào", daliuren: "Đại Lục Nhâm", qizheng: "Thiên thể", reflection: "Chiêm nghiệm" }, open: "Xem hồ sơ", close: "Trở lại danh mục", record: "Hồ sơ lưu trữ", noResults: "Không có hồ sơ kinh điển phù hợp với tìm kiếm này.", related: "Học tập liên quan", original: "Tên nguyên điển" },
  th: { eyebrow: "Xuannova · หอคัมภีร์", title: "สารบบตำราคลาสสิกตะวันออก", lead: "สารบบตำราสำหรับเครื่องมือการศึกษาทุกชนิด เลือกชื่อหนังสือเพื่ออ่านคำแนะนำและอ่านฉบับเต็มได้ที่นี่", count: "ระเบียนตำรา", search: "ค้นหาชื่อหนังสือ หัวข้อ หรือเครื่องมือ", all: "ทั้งหมด", categories: { foundation: "ตำราพื้นฐาน", bazi: "ปาจื้อ", ziwei: "จื่อเวย", qimen: "ฉีเหมิน", liuyao: "ลิ่วเหยา", daliuren: "ต้าหลิ่วเริ่น", qizheng: "การศึกษาดวงดาว", reflection: "การใคร่ครวญ" }, open: "ดูระเบียน", close: "กลับสารบบ", record: "ระเบียนคลัง", noResults: "ไม่พบระเบียนตำราที่ตรงกับการค้นหานี้", related: "การศึกษาที่เกี่ยวข้อง", original: "ชื่อต้นฉบับ" },
};

const categoryMarks: Record<LibraryCategory, string> = {
  foundation: "01",
  bazi: "02",
  ziwei: "03",
  qimen: "04",
  liuyao: "05",
  daliuren: "06",
  qizheng: "07",
  reflection: "08",
};

function ArchiveBookCover({ work, locale, large = false }: { work: ClassicalWork; locale: Locale; large?: boolean }) {
  return <span className={`archive-book-cover${large ? " is-large" : ""}`} data-cover={work.cover} data-category={work.category} aria-hidden="true">
    <span className="archive-book-cover-grain" />
    <span className="archive-book-cover-mark">{categoryMarks[work.category]}</span>
    <span className="archive-book-cover-title">{localizedLibraryTitle(work, locale)}</span>
    <span className="archive-book-cover-rule" />
    <span className="archive-book-cover-imprint">XUANNOVA</span>
  </span>;
}

export function LibraryExplorer({ locale, initialCategory = "all" }: { locale: Locale; initialCategory?: LibraryCategory | "all" }) {
  const text = copy[locale];
  const [category, setCategory] = useState<LibraryCategory | "all">(initialCategory);
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [onlyFavorites, setOnlyFavorites] = useState(false);
  const shelf = useShelf();
  // /library?book=<id> opens that book (links from the member centre's bookshelf).
  useBookParam((book) => { if (classicalWorks.some((work) => work.id === book)) setSelectedId(book); });
  const favoriteCount = shelf ? Object.values(shelf.items).filter((item) => item.favorite).length : 0;
  const recent = shelf ? Object.values(shelf.items).filter((item) => item.chapter !== null && item.readAt && classicalWorks.some((work) => work.id === item.workId)).sort((a, b) => (b.readAt ?? "").localeCompare(a.readAt ?? "")).slice(0, 3) : [];
  const selected = selectedId ? classicalWorks.find((work) => work.id === selectedId) ?? null : null;
  const results = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return classicalWorks.filter((work) => (!onlyFavorites || Boolean(shelf?.items[work.id]?.favorite)) && (category === "all" || work.category === category) && (!needle || `${localizedLibraryTitle(work, locale)} ${work.title} ${work.originalTitle} ${work.tags.join(" ")} ${work.methods.join(" ")} ${text.categories[work.category]} ${libraryGuide(work.id, locale)}`.toLowerCase().includes(needle)));
  }, [category, locale, query, text.categories, onlyFavorites, shelf]);

  if (selected) return <section className="route-screen archive-library" data-route="library">
    <header className="archive-simple-heading"><span>{text.eyebrow}</span><h1>{text.record}</h1></header>
    <article className="archive-detail">
      <button type="button" onClick={() => setSelectedId(null)}>← {text.close}</button>
      <div className="archive-detail-layout">
        <ArchiveBookCover work={selected} locale={locale} large />
        <div className="archive-detail-copy">
          <small>{text.categories[selected.category]}</small>
          <h2>{localizedLibraryTitle(selected, locale)}</h2>
          <dl><div><dt>{text.related}</dt><dd>{text.categories[selected.category]}</dd></div><div><dt>{text.original}</dt><dd>{selected.originalTitle}</dd></div></dl>
          <FavoriteButton workId={selected.id} locale={locale} shelf={shelf} />
          <p className="library-guide">{libraryGuide(selected.id, locale)}</p>
          <LibraryReader id={selected.id} locale={locale} />
        </div>
      </div>
    </article>
  </section>;

  return <section className="route-screen archive-library" data-route="library">
    <header className="archive-simple-heading"><span>{text.eyebrow}</span><h1>{text.title}</h1><p>{text.lead}</p><small>{classicalWorks.length} {text.count}</small></header>
    {recent.length > 0 && <section className="library-continue" aria-label={shelfText.recent[locale]}>
      <small>{shelfText.recent[locale]}</small>
      <div>{recent.map((item) => { const work = classicalWorks.find((entry) => entry.id === item.workId)!; const percent = progressPercent(item); return <button type="button" key={item.workId} onClick={() => setSelectedId(item.workId)}>
        <strong>{localizedLibraryTitle(work, locale)}</strong>
        <span>{fillShelf(shelfText.readTo[locale], { title: item.chapterTitle ?? String((item.chapter ?? 0) + 1) })}</span>
        <span className="library-progress"><i style={{ width: `${percent}%` }} /><small>{fillShelf(shelfText.progress[locale], { p: percent })}</small></span>
        <b>{shelfText.continueReading[locale]} →</b>
      </button>; })}</div>
    </section>}
    <div className="archive-controls"><label><span className="sr-only">{text.search}</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={text.search} /></label><div>{(["all", ...libraryCategories] as const).map((item) => <button type="button" key={item} className={!onlyFavorites && category === item ? "active" : ""} onClick={() => { setOnlyFavorites(false); setCategory(item); }}>{item === "all" ? text.all : text.categories[item]}</button>)}{favoriteCount > 0 && <button type="button" className={onlyFavorites ? "active" : ""} onClick={() => { setOnlyFavorites(!onlyFavorites); setCategory("all"); }}>★ {shelfText.myFavorites[locale]} ({favoriteCount})</button>}</div></div>
    <section className="archive-list" aria-label={text.title}>{results.length ? results.map((work, index) => <button type="button" key={work.id} className="archive-list-row" onClick={() => setSelectedId(work.id)}>
      <i>{String(index + 1).padStart(2, "0")}</i>
      <ArchiveBookCover work={work} locale={locale} />
      <strong>{shelf?.items[work.id]?.favorite ? "★ " : ""}{localizedLibraryTitle(work, locale)}</strong>
      <span>{text.categories[work.category]}{progressPercent(shelf?.items[work.id]) > 0 ? ` · ${fillShelf(shelfText.progress[locale], { p: progressPercent(shelf?.items[work.id]) })}` : ""}</span>
      <b>{text.open} →</b>
    </button>) : <p className="archive-empty">{text.noResults}</p>}</section>
  </section>;
}
