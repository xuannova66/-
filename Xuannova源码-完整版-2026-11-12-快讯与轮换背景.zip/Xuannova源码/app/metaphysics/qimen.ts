// Hour Qi Men Dun Jia (时家奇门), rotating-plate method with 拆补 bureau selection.
import { branchIndex, jiaziIndex, mod, postHorse, xunHead, xunKong } from "./core";

const BUREAU_TABLE: Record<string, [number, number, number]> = {
  冬至: [1, 7, 4], 小寒: [2, 8, 5], 大寒: [3, 9, 6], 立春: [8, 5, 2], 雨水: [9, 6, 3], 惊蛰: [1, 7, 4],
  春分: [3, 9, 6], 清明: [4, 1, 7], 谷雨: [5, 2, 8], 立夏: [4, 1, 7], 小满: [5, 2, 8], 芒种: [6, 3, 9],
  夏至: [9, 3, 6], 小暑: [8, 2, 5], 大暑: [7, 1, 4], 立秋: [2, 5, 8], 处暑: [1, 4, 7], 白露: [9, 3, 6],
  秋分: [7, 1, 4], 寒露: [6, 9, 3], 霜降: [5, 8, 2], 立冬: [6, 9, 3], 小雪: [5, 8, 2], 大雪: [4, 7, 1],
};
const YANG_TERMS = new Set(["冬至", "小寒", "大寒", "立春", "雨水", "惊蛰", "春分", "清明", "谷雨", "立夏", "小满", "芒种"]);
const EARTH_ORDER = ["戊", "己", "庚", "辛", "壬", "癸", "丁", "丙", "乙"];
const XUN_YI: Record<string, string> = { 甲子: "戊", 甲戌: "己", 甲申: "庚", 甲午: "辛", 甲辰: "壬", 甲寅: "癸" };
export const PALACE_STAR: Record<number, string> = { 1: "天蓬", 2: "天芮", 3: "天冲", 4: "天辅", 5: "天禽", 6: "天心", 7: "天柱", 8: "天任", 9: "天英" };
export const PALACE_GATE: Record<number, string> = { 1: "休门", 2: "死门", 3: "伤门", 4: "杜门", 6: "开门", 7: "惊门", 8: "生门", 9: "景门" };
const RING = [1, 8, 3, 4, 9, 2, 7, 6]; // clockwise around the Luo Shu ring
const DEITIES = ["值符", "螣蛇", "太阴", "六合", "白虎", "玄武", "九地", "九天"];
export const PALACE_BRANCHES: Record<number, string> = { 1: "子", 8: "丑寅", 3: "卯", 4: "辰巳", 9: "午", 2: "未申", 7: "酉", 6: "戌亥", 5: "" };
const branchPalace = (branch: string) => Number(Object.entries(PALACE_BRANCHES).find(([, value]) => value.includes(branch))?.[0] ?? 0);
const ring = (palace: number) => RING.indexOf(palace === 5 ? 2 : palace);

export function qimenChart(params: { term: string; dayPillar: string; hourPillar: string }) {
  const { term, dayPillar, hourPillar } = params;
  const yang = YANG_TERMS.has(term);
  const dayIndex = jiaziIndex(dayPillar);
  const fuTou = dayIndex - (dayIndex % 5);
  const fuTouBranch = mod(fuTou, 12);
  const yuan = [0, 6, 3, 9].includes(fuTouBranch) ? 0 : [2, 8, 5, 11].includes(fuTouBranch) ? 1 : 2;
  const bureau = (BUREAU_TABLE[term] ?? [1, 7, 4])[yuan];
  // Earth plate
  const earth: Record<number, string> = {};
  EARTH_ORDER.forEach((stem, index) => {
    const palace = yang ? mod(bureau - 1 + index, 9) + 1 : mod(bureau - 1 - index, 9) + 1;
    earth[palace] = stem;
  });
  const findStem = (stem: string) => Number(Object.entries(earth).find(([, value]) => value === stem)?.[0] ?? 5);
  const head = xunHead(hourPillar);
  const yi = XUN_YI[head] ?? "戊";
  const dutyPalace = findStem(yi);
  const dutyStar = PALACE_STAR[dutyPalace];
  const dutyGate = PALACE_GATE[dutyPalace === 5 ? 2 : dutyPalace];
  // Heaven plate: the duty star follows the hour stem.
  const hourStem = hourPillar.charAt(0);
  const hourStemPalace = findStem(hourStem === "甲" ? yi : hourStem);
  const starShift = ring(hourStemPalace) - ring(dutyPalace);
  const heavenStar: Record<number, string[]> = {};
  const heavenStem: Record<number, string[]> = {};
  for (const source of RING) {
    const target = RING[mod(ring(source) + starShift, 8)];
    heavenStar[target] = [PALACE_STAR[source]];
    heavenStem[target] = [earth[source]];
    if (source === 2) { heavenStar[target].push(PALACE_STAR[5]); heavenStem[target].push(earth[5]); }
  }
  // Gates: the duty gate moves one palace per hour from the xun head.
  const steps = jiaziIndex(hourPillar) - jiaziIndex(head);
  let gatePalace = yang ? mod(dutyPalace - 1 + steps, 9) + 1 : mod(dutyPalace - 1 - steps, 9) + 1;
  if (gatePalace === 5) gatePalace = 2;
  const gateShift = ring(gatePalace) - ring(dutyPalace === 5 ? 2 : dutyPalace);
  const gates: Record<number, string> = {};
  for (const source of RING) gates[RING[mod(ring(source) + gateShift, 8)]] = PALACE_GATE[source];
  // Deities start from the palace now holding the duty star.
  const starPalace = RING[mod(ring(dutyPalace) + starShift, 8)];
  const deities: Record<number, string> = {};
  DEITIES.forEach((deity, index) => { deities[RING[mod(ring(starPalace) + (yang ? index : -index), 8)]] = deity; });
  const voidBranches = xunKong(hourPillar);
  const voidPalaces = [...new Set(voidBranches.map(branchPalace))];
  const horsePalace = branchPalace(postHorse(hourPillar.charAt(1)));
  const palaces = [1, 2, 3, 4, 5, 6, 7, 8, 9].map((palace) => ({
    palace,
    earthStem: earth[palace],
    heavenStem: palace === 5 ? earth[5] : heavenStem[palace]?.join("") ?? "—",
    star: palace === 5 ? PALACE_STAR[5] : heavenStar[palace]?.join("·") ?? "—",
    gate: palace === 5 ? "—" : gates[palace],
    deity: palace === 5 ? "—" : deities[palace],
    isVoid: voidPalaces.includes(palace),
    isHorse: palace === horsePalace,
  }));
  return {
    yang, bureau, yuan: ["上元", "中元", "下元"][yuan], term,
    bureauName: `${yang ? "阳遁" : "阴遁"}${["一", "二", "三", "四", "五", "六", "七", "八", "九"][bureau - 1]}局`,
    xunHead: `${head}${yi}`,
    dutyStar, dutyGate, dutyStarPalace: starPalace, dutyGatePalace: gatePalace,
    voidBranches, horse: postHorse(hourPillar.charAt(1)), horsePalace,
    palaces,
  };
}

export { branchIndex };
