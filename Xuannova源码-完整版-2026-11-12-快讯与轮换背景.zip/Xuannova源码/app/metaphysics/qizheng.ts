// Seven Governors and Four Remainders (七政四余) — approximate ephemeris.
// Planet longitudes use the JPL Keplerian elements (valid 1800–2050, error well under 1°);
// the Moon uses the main periodic terms. 紫炁 is omitted because schools disagree on its epoch.
import { branchAt, mod } from "./core";

const RAD = Math.PI / 180;
type Elements = [number, number, number, number, number, number, number, number, number, number, number, number];
// a, da, e, de, I, dI, L, dL, peri, dperi, node, dnode (per Julian century)
const PLANETS: Record<string, Elements> = {
  水星: [0.38709927, 0.00000037, 0.20563593, 0.00001906, 7.00497902, -0.00594749, 252.2503235, 149472.67411175, 77.45779628, 0.16047689, 48.33076593, -0.12534081],
  金星: [0.72333566, 0.0000039, 0.00677672, -0.00004107, 3.39467605, -0.0007889, 181.9790995, 58517.81538729, 131.60246718, 0.00268329, 76.67984255, -0.27769418],
  地球: [1.00000261, 0.00000562, 0.01671123, -0.00004392, -0.00001531, -0.01294668, 100.46457166, 35999.37244981, 102.93768193, 0.32327364, 0, 0],
  火星: [1.52371034, 0.00001847, 0.0933941, 0.00007882, 1.84969142, -0.00813131, -4.55343205, 19140.30268499, -23.94362959, 0.44441088, 49.55953891, -0.29257343],
  木星: [5.202887, -0.00011607, 0.04838624, -0.00013253, 1.30439695, -0.00183714, 34.39644051, 3034.74612775, 14.72847983, 0.21252668, 100.47390909, 0.20469106],
  土星: [9.53667594, -0.0012506, 0.05386179, -0.00050991, 2.48599187, 0.00193609, 49.95424423, 1222.49362201, 92.59887831, -0.41897216, 113.66242448, -0.28867794],
};

function heliocentric(el: Elements, T: number) {
  const a = el[0] + el[1] * T;
  const e = el[2] + el[3] * T;
  const I = (el[4] + el[5] * T) * RAD;
  const L = el[6] + el[7] * T;
  const peri = el[8] + el[9] * T;
  const node = el[10] + el[11] * T;
  const M = mod(L - peri, 360) * RAD;
  let E = M + e * Math.sin(M);
  for (let i = 0; i < 8; i += 1) E -= (E - e * Math.sin(E) - M) / (1 - e * Math.cos(E));
  const xp = a * (Math.cos(E) - e);
  const yp = a * Math.sqrt(1 - e * e) * Math.sin(E);
  const w = (peri - node) * RAD;
  const O = node * RAD;
  const x = (Math.cos(w) * Math.cos(O) - Math.sin(w) * Math.sin(O) * Math.cos(I)) * xp + (-Math.sin(w) * Math.cos(O) - Math.cos(w) * Math.sin(O) * Math.cos(I)) * yp;
  const y = (Math.cos(w) * Math.sin(O) + Math.sin(w) * Math.cos(O) * Math.cos(I)) * xp + (-Math.sin(w) * Math.sin(O) + Math.cos(w) * Math.cos(O) * Math.cos(I)) * yp;
  return { x, y };
}

/** Days since J2000.0 (2000-01-01 12:00 TT ≈ UTC) for a UTC epoch in ms. */
export const daysSinceJ2000 = (utcMs: number) => utcMs / 86400000 - 10957.5;

export function eclipticLongitudes(utcMs: number) {
  const d = daysSinceJ2000(utcMs);
  const T = d / 36525;
  const earth = heliocentric(PLANETS.地球, T);
  const out: Record<string, number> = {};
  out.太阳 = mod(Math.atan2(-earth.y, -earth.x) / RAD, 360);
  for (const name of ["水星", "金星", "火星", "木星", "土星"]) {
    const p = heliocentric(PLANETS[name], T);
    out[name] = mod(Math.atan2(p.y - earth.y, p.x - earth.x) / RAD, 360);
  }
  const L = 218.316 + 13.176396 * d;
  const Mm = (134.963 + 13.064993 * d) * RAD;
  const Ms = (357.529 + 0.98560028 * d) * RAD;
  const D = (297.85 + 12.190749 * d) * RAD;
  const F = (93.272 + 13.22935 * d) * RAD;
  out.太阴 = mod(L + 6.289 * Math.sin(Mm) - 1.274 * Math.sin(2 * D - Mm) + 0.658 * Math.sin(2 * D) + 0.214 * Math.sin(2 * Mm) - 0.186 * Math.sin(Ms) - 0.114 * Math.sin(2 * F), 360);
  const ascendingNode = mod(125.04452 - 0.0529538083 * d, 360);
  out.计都 = ascendingNode; // 七政四余 convention: 计都 = ascending node, 罗睺 = descending node
  out.罗睺 = mod(ascendingNode + 180, 360);
  out.月孛 = mod(83.3532465 + 0.111403533 * d + 180, 360); // mean lunar apogee
  return out;
}

// Traditional mansion widths in ancient degrees (sum 365.25), anchored at 角 = Spica.
const MANSIONS: Array<[string, number]> = [["角", 12], ["亢", 9], ["氐", 15], ["房", 5], ["心", 5], ["尾", 18], ["箕", 11], ["斗", 26.25], ["牛", 8], ["女", 12], ["虚", 10], ["危", 17], ["室", 16], ["壁", 9], ["奎", 16], ["娄", 12], ["胃", 14], ["昴", 11], ["毕", 16], ["觜", 2], ["参", 9], ["井", 33], ["鬼", 4], ["柳", 15], ["星", 7], ["张", 18], ["翼", 18], ["轸", 17]];
export function mansionOf(longitude: number, utcMs: number) {
  const years = daysSinceJ2000(utcMs) / 365.25;
  const spica = 203.84 + (50.29 / 3600) * years;
  let offset = mod(longitude - spica, 360) * (365.25 / 360);
  for (const [name, width] of MANSIONS) {
    if (offset < width) return { name, degree: Math.floor(offset) };
    offset -= width;
  }
  return { name: "轸", degree: 16 };
}

/** Chinese twelve stations: tropical sign → branch (Aries = 戌 … Pisces = 亥). */
export const branchOfLongitude = (longitude: number) => branchAt(10 - Math.floor(mod(longitude, 360) / 30));
export const STATIONS: Record<string, string> = { 子: "玄枵", 丑: "星纪", 寅: "析木", 卯: "大火", 辰: "寿星", 巳: "鹑尾", 午: "鹑火", 未: "鹑首", 申: "实沈", 酉: "大梁", 戌: "降娄", 亥: "娵訾" };
export const QIZHENG_PALACES = ["命宫", "财帛", "兄弟", "田宅", "男女", "奴仆", "夫妻", "疾厄", "迁移", "官禄", "福德", "相貌"];
const ELEMENT_OF_BODY: Record<string, string> = { 太阳: "火", 太阴: "水", 水星: "水", 金星: "金", 火星: "火", 木星: "木", 土星: "土", 罗睺: "火", 计都: "土", 月孛: "水" };
export const BODY_ORDER = ["太阳", "太阴", "水星", "金星", "火星", "木星", "土星", "罗睺", "计都", "月孛"];

export function qizhengChart(utcMs: number, hourBranchIndex: number) {
  const longitudes = eclipticLongitudes(utcMs);
  const bodies = BODY_ORDER.map((name) => {
    const lon = longitudes[name];
    const mansion = mansionOf(lon, utcMs);
    return { name, longitude: lon, branch: branchOfLongitude(lon), signDegree: Math.floor(mod(lon, 30)), mansion: mansion.name, mansionDegree: mansion.degree, element: ELEMENT_OF_BODY[name] };
  });
  const sunBranch = branchOfLongitude(longitudes.太阳);
  const BR = "子丑寅卯辰巳午未申酉戌亥";
  const lifeBranch = BR.indexOf(sunBranch) - (hourBranchIndex - 3);
  const palaces = QIZHENG_PALACES.map((name, k) => {
    const branch = branchAt(lifeBranch - k);
    return { name, branch, station: STATIONS[branch], bodies: bodies.filter((body) => body.branch === branch) };
  });
  return { bodies, palaces, lifeBranch: branchAt(lifeBranch), sunBranch };
}

/** Tropical ascendant for a UTC instant and geographic position (degrees). */
export function ascendant(utcMs: number, latitude: number, longitude: number) {
  const d = daysSinceJ2000(utcMs);
  const ramc = mod(280.46061837 + 360.98564736629 * d + longitude, 360) * RAD;
  const eps = 23.4393 * RAD;
  const asc = Math.atan2(Math.cos(ramc), -(Math.sin(ramc) * Math.cos(eps) + Math.tan(latitude * RAD) * Math.sin(eps)));
  return mod(asc / RAD, 360);
}

export const ZODIAC = ["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"];
export const zodiacOf = (longitude: number) => ZODIAC[Math.floor(mod(longitude, 360) / 30)];
const ASPECTS: Array<[string, number, number]> = [["Conjunction", 0, 8], ["Sextile", 60, 5], ["Square", 90, 7], ["Trine", 120, 7], ["Opposition", 180, 8]];
export function aspectBetween(a: number, b: number) {
  const diff = Math.abs(mod(a - b + 180, 360) - 180);
  for (const [name, angle, orb] of ASPECTS) if (Math.abs(diff - angle) <= orb) return { name, orb: Math.round(Math.abs(diff - angle) * 10) / 10 };
  return undefined;
}
