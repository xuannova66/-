// 人生K线 (life candlestick chart): every year of life scored from the BaZi chart and drawn like a stock chart.
// One common school, deterministic and explainable:
//  * favourable elements (喜用) follow the day master's strength: a weak day master is helped by its own element and
//    the element that produces it; a strong one by output, wealth and officer; a balanced chart weighs both lightly;
//  * the ten-year luck pillar (大运) sets the trend: its branch counts more than its stem (地支为重);
//  * the year pillar (流年) moves the year: stem and branch favourable or not, clashes with the day branch (冲日支),
//    the birth-year branch (冲太岁) and the luck branch, the birth-year branch returning (本命年), and a six-harmony
//    with the day branch (六合);
//  * open = last year's close, close = this year's score, the wicks widen with the number of clashes and harmonies.
// Cultural study reference only: it shows the shape of the chart's rhythm, not a prediction.
import { branchElement, branchIndex, controls, generates, ganzhiAt, ELEMENTS, stemElement, type Element } from "./core";
import { favourableElements } from "./zeri";

export type KLineReason =
  | { key: "luckGood" | "luckBad"; ganzhi: string }
  | { key: "stemGood" | "stemBad" | "branchGood" | "branchBad"; value: string }
  | { key: "clashDay" | "clashYear" | "clashLuck" | "benming" | "harmonyDay" | "luckClash"; value: string }
  | { key: "childhood" };

export type KLineCandle = {
  year: number; age: number; ganzhi: string; luck: string | null;
  open: number; close: number; high: number; low: number;
  reasons: KLineReason[];
};
export type KLineLuck = { ganzhi: string; startAge: number; startYear: number; endYear: number; average: number };
export type LifeKLine = {
  birthYear: number; verdict: string; favourable: Element[]; unfavourable: Element[];
  candles: KLineCandle[]; lucks: KLineLuck[];
  peaks: KLineCandle[]; troughs: KLineCandle[]; bestLuck: KLineLuck | null; average: number;
};

const CLASH = (a: string, b: string) => branchIndex(a) >= 0 && branchIndex(b) >= 0 && (branchIndex(a) + 6) % 12 === branchIndex(b);
// 六合: 子丑 寅亥 卯戌 辰酉 巳申 午未
const HARMONY = (a: string, b: string) => { const i = branchIndex(a), j = branchIndex(b); return i >= 0 && j >= 0 && (i + j) % 12 === 1; };
const clamp = (value: number, low: number, high: number) => Math.max(low, Math.min(high, value));
const round1 = (value: number) => Math.round(value * 10) / 10;

/** Elements that help and hurt this chart, with a weight (balanced charts lean less). */
export function elementLeaning(pillars: string[]) {
  const { verdict, elements } = favourableElements(pillars);
  const day = stemElement(pillars[2]?.charAt(0) ?? "");
  if (elements.length) return { verdict, favourable: elements, unfavourable: ELEMENTS.filter((element) => !elements.includes(element)), weight: 1 };
  // Balanced: output and wealth keep the chart flowing; the element that controls the day master is the main strain.
  const output = ELEMENTS.find((element) => generates(day, element))!;
  const wealth = ELEMENTS.find((element) => controls(day, element))!;
  const officer = ELEMENTS.find((element) => controls(element, day))!;
  return { verdict, favourable: [output, wealth], unfavourable: [officer], weight: 0.6 };
}

export function lifeKLine(input: { pillars: string[]; birthYear: number; luck?: { cycles: Array<{ ganzhi: string; startAge: number; startYear: number }> }; years?: number }): LifeKLine {
  const { pillars, birthYear } = input;
  const span = Math.max(10, Math.min(100, input.years ?? 100));
  const lean = elementLeaning(pillars);
  // Weights chosen so that an even spread of the five elements averages out at 50 (the help and the strain balance).
  const nFav = lean.favourable.length, nBad = lean.unfavourable.length;
  const up = (2 * nBad) / (nFav + nBad), down = (2 * nFav) / (nFav + nBad);
  const effect = (element: Element) => (lean.favourable.includes(element) ? up : lean.unfavourable.includes(element) ? -down : 0) * lean.weight;
  const dayBranch = pillars[2]?.charAt(1) ?? "";
  const yearBranch = pillars[0]?.charAt(1) ?? "";
  const cycles = (input.luck?.cycles ?? []).filter((cycle) => cycle.ganzhi?.length === 2 && cycle.startYear > 0);
  const luckFor = (year: number) => [...cycles].reverse().find((cycle) => year >= cycle.startYear) ?? null;

  const candles: KLineCandle[] = [];
  let previous = 50;
  for (let offset = 0; offset < span; offset += 1) {
    const year = birthYear + offset;
    const ganzhi = ganzhiAt(year - 4);
    const stem = ganzhi.charAt(0), branch = ganzhi.charAt(1);
    const luck = luckFor(year);
    const reasons: KLineReason[] = [];
    let score = 50;
    let moves = 0;
    if (luck) {
      const luckEffect = 6 * effect(stemElement(luck.ganzhi.charAt(0))) + 10 * effect(branchElement(luck.ganzhi.charAt(1)));
      score += luckEffect;
      if (luckEffect > 0) reasons.push({ key: "luckGood", ganzhi: luck.ganzhi });
      if (luckEffect < 0) reasons.push({ key: "luckBad", ganzhi: luck.ganzhi });
    } else reasons.push({ key: "childhood" });
    const stemEffect = 7 * effect(stemElement(stem));
    const branchEffect = 7 * effect(branchElement(branch));
    score += stemEffect + branchEffect;
    if (stemEffect > 0) reasons.push({ key: "stemGood", value: stem }); else if (stemEffect < 0) reasons.push({ key: "stemBad", value: stem });
    if (branchEffect > 0) reasons.push({ key: "branchGood", value: branch }); else if (branchEffect < 0) reasons.push({ key: "branchBad", value: branch });
    if (CLASH(branch, dayBranch)) { score -= 8; moves += 1; reasons.push({ key: "clashDay", value: `${branch}${dayBranch}` }); }
    if (CLASH(branch, yearBranch)) { score -= 4; moves += 1; reasons.push({ key: "clashYear", value: `${branch}${yearBranch}` }); }
    if (branch === yearBranch && offset > 0) { score -= 3; moves += 1; reasons.push({ key: "benming", value: branch }); }
    if (HARMONY(branch, dayBranch)) { score += 4; moves += 1; reasons.push({ key: "harmonyDay", value: `${branch}${dayBranch}` }); }
    if (luck && CLASH(branch, luck.ganzhi.charAt(1))) {
      score -= 5; moves += 1;
      // 天克地冲: the year stem also controls the luck stem.
      if (controls(stemElement(stem), stemElement(luck.ganzhi.charAt(0)))) { score -= 4; reasons.push({ key: "luckClash", value: `${ganzhi}/${luck.ganzhi}` }); }
      else reasons.push({ key: "clashLuck", value: `${branch}${luck.ganzhi.charAt(1)}` });
    }
    const close = clamp(Math.round(score), 5, 95);
    const open = offset === 0 ? 50 : previous;
    const swing = 2 + 3 * moves;
    candles.push({ year, age: offset + 1, ganzhi, luck: luck?.ganzhi ?? null, open, close, high: clamp(Math.max(open, close) + swing, 0, 100), low: clamp(Math.min(open, close) - swing, 0, 100), reasons });
    previous = close;
  }

  const lucks: KLineLuck[] = cycles.map((cycle, index) => {
    const endYear = (cycles[index + 1]?.startYear ?? cycle.startYear + 10) - 1;
    const inside = candles.filter((candle) => candle.year >= cycle.startYear && candle.year <= endYear);
    return { ganzhi: cycle.ganzhi, startAge: cycle.startAge, startYear: cycle.startYear, endYear, average: inside.length ? round1(inside.reduce((sum, candle) => sum + candle.close, 0) / inside.length) : 0 };
  }).filter((luck) => luck.startYear < birthYear + span);

  // Highest and lowest years, at least five years apart so they mark different periods of life.
  const spread = (list: KLineCandle[]) => list.reduce<KLineCandle[]>((picked, candle) => (picked.length < 3 && picked.every((other) => Math.abs(other.year - candle.year) >= 5) ? [...picked, candle] : picked), []);
  const peaks = spread([...candles].sort((a, b) => b.close - a.close || a.year - b.year));
  const troughs = spread([...candles].sort((a, b) => a.close - b.close || a.year - b.year));
  const bestLuck = lucks.reduce<KLineLuck | null>((best, luck) => (!best || luck.average > best.average ? luck : best), null);
  const average = round1(candles.reduce((sum, candle) => sum + candle.close, 0) / candles.length);
  return { birthYear, verdict: lean.verdict, favourable: lean.favourable, unfavourable: lean.unfavourable, candles, lucks, peaks, troughs, bestLuck, average };
}

/** Simple moving average of the closes (null until enough years). */
export function movingAverage(candles: KLineCandle[], window = 10) {
  return candles.map((_, index) => (index + 1 < window ? null : round1(candles.slice(index + 1 - window, index + 1).reduce((sum, candle) => sum + candle.close, 0) / window)));
}
