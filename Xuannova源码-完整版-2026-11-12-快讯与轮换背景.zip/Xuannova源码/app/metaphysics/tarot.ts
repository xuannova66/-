// Standard 78-card tarot deck and a deterministic draw (same question + date → same cards).
export type TarotLocale = "en" | "zh-Hans" | "zh-Hant" | "ja" | "ko" | "vi" | "th";
type L7 = Record<TarotLocale, string>;
const l7 = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

// [name, upright keyword, reversed keyword]
const MAJORS: Array<[L7, L7, L7]> = [
  [l7("The Fool", "愚者", "愚者", "愚者", "바보", "Kẻ Khờ", "คนโง่"), l7("new beginnings", "新的开始", "新的開始", "新しい始まり", "새로운 시작", "khởi đầu mới", "การเริ่มต้นใหม่"), l7("hesitation", "犹豫", "猶豫", "ためらい", "망설임", "do dự", "ความลังเล")],
  [l7("The Magician", "魔术师", "魔術師", "魔術師", "마법사", "Nhà Ảo Thuật", "นักมายากล"), l7("skill and focus", "专注与技能", "專注與技能", "集中と技量", "집중과 능력", "kỹ năng và tập trung", "ทักษะและสมาธิ"), l7("scattered effort", "力量分散", "力量分散", "力の分散", "흩어진 노력", "nỗ lực phân tán", "แรงที่กระจัดกระจาย")],
  [l7("The High Priestess", "女祭司", "女祭司", "女教皇", "여사제", "Nữ Tư Tế", "นักบวชหญิง"), l7("intuition", "直觉", "直覺", "直感", "직관", "trực giác", "สัญชาตญาณ"), l7("hidden doubts", "隐藏的疑虑", "隱藏的疑慮", "隠れた疑念", "숨은 의심", "nghi ngờ ẩn giấu", "ความสงสัยที่ซ่อนอยู่")],
  [l7("The Empress", "皇后", "皇后", "女帝", "여황제", "Hoàng Hậu", "จักรพรรดินี"), l7("nurturing", "滋养", "滋養", "育み", "보살핌", "nuôi dưỡng", "การหล่อเลี้ยง"), l7("depletion", "耗损", "耗損", "消耗", "고갈", "cạn kiệt", "ความหมดแรง")],
  [l7("The Emperor", "皇帝", "皇帝", "皇帝", "황제", "Hoàng Đế", "จักรพรรดิ"), l7("structure", "秩序", "秩序", "秩序", "질서", "trật tự", "โครงสร้าง"), l7("rigidity", "僵硬", "僵硬", "硬直", "경직", "cứng nhắc", "ความแข็งทื่อ")],
  [l7("The Hierophant", "教皇", "教皇", "法王", "교황", "Giáo Hoàng", "สังฆราช"), l7("tradition", "传统", "傳統", "伝統", "전통", "truyền thống", "ประเพณี"), l7("questioning rules", "质疑规则", "質疑規則", "規則への疑問", "규칙에 대한 의문", "chất vấn quy tắc", "การตั้งคำถามต่อกฎ")],
  [l7("The Lovers", "恋人", "戀人", "恋人", "연인", "Tình Nhân", "คู่รัก"), l7("choice and union", "选择与结合", "選擇與結合", "選択と結びつき", "선택과 결합", "lựa chọn và gắn kết", "การเลือกและการรวมกัน"), l7("imbalance", "失衡", "失衡", "不均衡", "불균형", "mất cân bằng", "ความไม่สมดุล")],
  [l7("The Chariot", "战车", "戰車", "戦車", "전차", "Cỗ Xe", "รถศึก"), l7("determination", "意志", "意志", "意志", "의지", "quyết tâm", "ความมุ่งมั่น"), l7("loss of direction", "方向不明", "方向不明", "方向の喪失", "방향 상실", "mất phương hướng", "การหลงทิศ")],
  [l7("Strength", "力量", "力量", "力", "힘", "Sức Mạnh", "พลัง"), l7("gentle courage", "柔和的勇气", "柔和的勇氣", "穏やかな勇気", "부드러운 용기", "can đảm dịu dàng", "ความกล้าที่อ่อนโยน"), l7("self-doubt", "自我怀疑", "自我懷疑", "自己不信", "자기 의심", "tự nghi ngờ", "ความไม่มั่นใจ")],
  [l7("The Hermit", "隐者", "隱者", "隠者", "은둔자", "Ẩn Sĩ", "ฤๅษี"), l7("reflection", "内省", "內省", "内省", "성찰", "chiêm nghiệm", "การใคร่ครวญ"), l7("isolation", "孤立", "孤立", "孤立", "고립", "cô lập", "ความโดดเดี่ยว")],
  [l7("Wheel of Fortune", "命运之轮", "命運之輪", "運命の輪", "운명의 수레바퀴", "Bánh Xe Số Phận", "กงล้อแห่งโชคชะตา"), l7("turning point", "转折", "轉折", "転機", "전환점", "bước ngoặt", "จุดเปลี่ยน"), l7("resistance to change", "抗拒变化", "抗拒變化", "変化への抵抗", "변화 거부", "chống lại thay đổi", "การต้านการเปลี่ยนแปลง")],
  [l7("Justice", "正义", "正義", "正義", "정의", "Công Lý", "ความยุติธรรม"), l7("fairness", "公正", "公正", "公正", "공정", "công bằng", "ความเป็นธรรม"), l7("bias", "偏颇", "偏頗", "偏り", "편향", "thiên lệch", "ความลำเอียง")],
  [l7("The Hanged Man", "倒吊人", "倒吊人", "吊るされた男", "매달린 사람", "Người Treo Ngược", "ชายถูกแขวน"), l7("new perspective", "换个角度", "換個角度", "新しい視点", "새로운 관점", "góc nhìn mới", "มุมมองใหม่"), l7("stalling", "停滞", "停滯", "停滞", "정체", "trì trệ", "การหยุดนิ่ง")],
  [l7("Death", "死神", "死神", "死神", "죽음", "Cái Chết", "ความตาย"), l7("ending and renewal", "结束与更新", "結束與更新", "終わりと再生", "끝과 재생", "kết thúc và đổi mới", "การสิ้นสุดและเริ่มใหม่"), l7("clinging", "执着", "執著", "執着", "집착", "níu giữ", "การยึดติด")],
  [l7("Temperance", "节制", "節制", "節制", "절제", "Tiết Độ", "ความพอดี"), l7("balance", "平衡", "平衡", "調和", "균형", "cân bằng", "ความสมดุล"), l7("excess", "过度", "過度", "過剰", "과잉", "thái quá", "ความเกินพอดี")],
  [l7("The Devil", "恶魔", "惡魔", "悪魔", "악마", "Ác Quỷ", "ปีศาจ"), l7("attachment", "束缚", "束縛", "束縛", "속박", "ràng buộc", "พันธนาการ"), l7("release", "解脱", "解脫", "解放", "해방", "giải thoát", "การปลดปล่อย")],
  [l7("The Tower", "高塔", "高塔", "塔", "탑", "Tòa Tháp", "หอคอย"), l7("sudden change", "突变", "突變", "急変", "급변", "biến động bất ngờ", "การเปลี่ยนแปลงฉับพลัน"), l7("delayed change", "迟来的变化", "遲來的變化", "遅れた変化", "지연된 변화", "thay đổi trì hoãn", "การเปลี่ยนแปลงที่ล่าช้า")],
  [l7("The Star", "星星", "星星", "星", "별", "Ngôi Sao", "ดวงดาว"), l7("hope", "希望", "希望", "希望", "희망", "hy vọng", "ความหวัง"), l7("discouragement", "气馁", "氣餒", "落胆", "낙담", "nản lòng", "ความท้อแท้")],
  [l7("The Moon", "月亮", "月亮", "月", "달", "Mặt Trăng", "ดวงจันทร์"), l7("uncertainty", "迷雾", "迷霧", "不確かさ", "불확실성", "mơ hồ", "ความไม่แน่นอน"), l7("clarity returning", "逐渐明朗", "逐漸明朗", "明晰の回復", "명료함 회복", "dần sáng tỏ", "ความชัดเจนกลับมา")],
  [l7("The Sun", "太阳", "太陽", "太陽", "태양", "Mặt Trời", "ดวงอาทิตย์"), l7("vitality", "活力", "活力", "活力", "활력", "sức sống", "พลังชีวิต"), l7("dimmed joy", "喜悦减弱", "喜悅減弱", "陰る喜び", "흐려진 기쁨", "niềm vui phai nhạt", "ความสุขที่จางลง")],
  [l7("Judgement", "审判", "審判", "審判", "심판", "Phán Xét", "การพิพากษา"), l7("awakening", "觉醒", "覺醒", "目覚め", "각성", "thức tỉnh", "การตื่นรู้"), l7("self-criticism", "自责", "自責", "自己批判", "자책", "tự trách", "การตำหนิตนเอง")],
  [l7("The World", "世界", "世界", "世界", "세계", "Thế Giới", "โลก"), l7("completion", "圆满", "圓滿", "完成", "완성", "hoàn thành", "ความสมบูรณ์"), l7("unfinished business", "未竟之事", "未竟之事", "未完の課題", "미완의 일", "việc dang dở", "เรื่องที่ยังไม่จบ")],
];
const SUITS: Array<[L7, L7]> = [
  [l7("Wands", "权杖", "權杖", "ワンド", "완드", "Gậy", "ไม้เท้า"), l7("action and drive", "行动与热情", "行動與熱情", "行動と情熱", "행동과 열정", "hành động và nhiệt huyết", "การลงมือและแรงขับ")],
  [l7("Cups", "圣杯", "聖杯", "カップ", "컵", "Cốc", "ถ้วย"), l7("feelings and relationships", "情感与关系", "情感與關係", "感情と関係", "감정과 관계", "cảm xúc và quan hệ", "อารมณ์และความสัมพันธ์")],
  [l7("Swords", "宝剑", "寶劍", "ソード", "소드", "Kiếm", "ดาบ"), l7("thought and decision", "思考与决断", "思考與決斷", "思考と決断", "사고와 결단", "suy nghĩ và quyết định", "ความคิดและการตัดสินใจ")],
  [l7("Pentacles", "星币", "星幣", "ペンタクル", "펜타클", "Tiền", "เหรียญ"), l7("work and resources", "工作与资源", "工作與資源", "仕事と資源", "일과 자원", "công việc và nguồn lực", "งานและทรัพยากร")],
];
const RANKS: Array<[L7, L7]> = [
  [l7("Ace", "王牌", "王牌", "エース", "에이스", "Át", "เอซ"), l7("a seed", "萌芽", "萌芽", "芽生え", "씨앗", "hạt giống", "เมล็ดพันธุ์")],
  [l7("Two", "二", "二", "2", "2", "Hai", "สอง"), l7("a choice", "抉择", "抉擇", "選択", "선택", "lựa chọn", "การเลือก")],
  [l7("Three", "三", "三", "3", "3", "Ba", "สาม"), l7("growth", "成长", "成長", "成長", "성장", "phát triển", "การเติบโต")],
  [l7("Four", "四", "四", "4", "4", "Bốn", "สี่"), l7("stability", "稳定", "穩定", "安定", "안정", "ổn định", "ความมั่นคง")],
  [l7("Five", "五", "五", "5", "5", "Năm", "ห้า"), l7("friction", "摩擦", "摩擦", "摩擦", "마찰", "va chạm", "แรงเสียดทาน")],
  [l7("Six", "六", "六", "6", "6", "Sáu", "หก"), l7("harmony", "和谐", "和諧", "調和", "조화", "hòa hợp", "ความกลมกลืน")],
  [l7("Seven", "七", "七", "7", "7", "Bảy", "เจ็ด"), l7("assessment", "评估", "評估", "見極め", "점검", "đánh giá", "การประเมิน")],
  [l7("Eight", "八", "八", "8", "8", "Tám", "แปด"), l7("movement", "推进", "推進", "前進", "추진", "chuyển động", "การเคลื่อนไหว")],
  [l7("Nine", "九", "九", "9", "9", "Chín", "เก้า"), l7("near completion", "接近完成", "接近完成", "完成間近", "완성 직전", "gần hoàn thành", "ใกล้สำเร็จ")],
  [l7("Ten", "十", "十", "10", "10", "Mười", "สิบ"), l7("culmination", "圆满或负担", "圓滿或負擔", "集大成", "정점", "đỉnh điểm", "จุดสูงสุด")],
  [l7("Page", "侍从", "侍從", "ペイジ", "페이지", "Tiểu Đồng", "มหาดเล็ก"), l7("curiosity", "好奇", "好奇", "好奇心", "호기심", "tò mò", "ความใคร่รู้")],
  [l7("Knight", "骑士", "騎士", "ナイト", "나이트", "Hiệp Sĩ", "อัศวิน"), l7("pursuit", "追求", "追求", "追求", "추구", "theo đuổi", "การไล่ตาม")],
  [l7("Queen", "王后", "王后", "クイーン", "퀸", "Hoàng Hậu", "ราชินี"), l7("care", "包容", "包容", "包容", "포용", "bao dung", "ความเอาใจใส่")],
  [l7("King", "国王", "國王", "キング", "킹", "Vua", "ราชา"), l7("mastery", "掌控", "掌控", "統率", "통솔", "làm chủ", "ความเชี่ยวชาญ")],
];
const REVERSED = l7("reversed", "逆位", "逆位", "逆位置", "역방향", "ngược", "กลับหัว");
const UPRIGHT = l7("upright", "正位", "正位", "正位置", "정방향", "xuôi", "ตั้งตรง");

export type TarotCard = { id: string; major: boolean; name: L7; keyword: L7; reversedKeyword: L7 };
export const TAROT_DECK: TarotCard[] = [
  ...MAJORS.map(([name, keyword, reversedKeyword], index) => ({ id: `major-${index}`, major: true, name, keyword, reversedKeyword })),
  ...SUITS.flatMap(([suit, theme], s) => RANKS.map(([rank, rankTheme], r) => {
    const join = (loc: TarotLocale, a: string, b: string) => (loc === "en" ? `${a} of ${b}` : loc === "vi" ? `${a} ${b}` : loc === "th" ? `${a}${b}`.replace(/^(.+?)(ไม้เท้า|ถ้วย|ดาบ|เหรียญ)$/, "$1 $2") : loc === "ko" ? `${b} ${a}` : loc === "ja" ? `${b}の${a}` : `${b}${a}`);
    const name = Object.fromEntries((Object.keys(rank) as TarotLocale[]).map((loc) => [loc, join(loc, rank[loc], suit[loc])])) as L7;
    const keyword = Object.fromEntries((Object.keys(rank) as TarotLocale[]).map((loc) => [loc, `${rankTheme[loc]} · ${theme[loc]}`])) as L7;
    return { id: `minor-${s}-${r}`, major: false, name, keyword, reversedKeyword: keyword };
  })),
];

function hash(value: string) {
  let h = 2166136261;
  for (let i = 0; i < value.length; i += 1) { h ^= value.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
/** Deterministic pseudo-random sequence (mulberry32). */
function rng(seed: number) {
  let a = seed;
  return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

export function drawTarot(key: string, count = 3, majorsOnly = false) {
  const deck = majorsOnly ? TAROT_DECK.filter((card) => card.major) : [...TAROT_DECK];
  const random = rng(hash(key));
  for (let i = deck.length - 1; i > 0; i -= 1) { const j = Math.floor(random() * (i + 1)); [deck[i], deck[j]] = [deck[j], deck[i]]; }
  return deck.slice(0, count).map((card) => ({ card, reversed: random() < 0.3 }));
}

/** All localized strings, registered into the chart term dictionary (keyed by the English text). */
export function tarotTermRows(): Array<L7> {
  const rows: L7[] = [REVERSED, UPRIGHT];
  for (const card of TAROT_DECK) rows.push(card.name, card.keyword, card.reversedKeyword);
  return rows;
}
