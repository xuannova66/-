// Zi Wei Dou Shu (紫微斗数) star placement by the standard 安星 rules.
import { branchAt, branchIndex, ganzhiAt, isYangStem, mod, naYinElement, stemAt, stemIndex, tigerMonthStem } from "./core";

export const PALACE_NAMES = ["命宫", "兄弟宫", "夫妻宫", "子女宫", "财帛宫", "疾厄宫", "迁移宫", "交友宫", "官禄宫", "田宅宫", "福德宫", "父母宫"];
export const PALACE_KEYS = ["Life", "Siblings", "Partnership", "Children", "Wealth", "Health", "Travel", "Allies", "Career", "Property", "Fortune", "Parents"];
const BUREAU: Record<string, [number, string]> = { 水: [2, "水二局"], 木: [3, "木三局"], 金: [4, "金四局"], 土: [5, "土五局"], 火: [6, "火六局"] };

// Brightness tables listed from 寅 to 丑 (school variants exist; this follows the common 全书 table).
const BRIGHTNESS: Record<string, string[]> = {
  紫微: ["旺", "旺", "得", "旺", "庙", "庙", "旺", "旺", "得", "旺", "平", "庙"],
  天机: ["得", "旺", "利", "平", "庙", "陷", "得", "旺", "利", "平", "庙", "陷"],
  太阳: ["旺", "庙", "旺", "旺", "旺", "得", "得", "陷", "不", "陷", "陷", "不"],
  武曲: ["得", "利", "庙", "平", "旺", "庙", "得", "利", "庙", "平", "旺", "庙"],
  天同: ["利", "平", "平", "庙", "陷", "不", "旺", "平", "平", "庙", "旺", "不"],
  廉贞: ["庙", "平", "利", "陷", "平", "利", "庙", "平", "利", "陷", "平", "利"],
  天府: ["庙", "得", "庙", "得", "旺", "庙", "得", "旺", "庙", "得", "庙", "庙"],
  太阴: ["旺", "陷", "陷", "陷", "不", "不", "利", "不", "旺", "庙", "庙", "庙"],
  贪狼: ["平", "利", "庙", "陷", "旺", "庙", "平", "利", "庙", "陷", "旺", "庙"],
  巨门: ["庙", "庙", "陷", "旺", "旺", "不", "庙", "庙", "陷", "旺", "旺", "不"],
  天相: ["庙", "陷", "得", "得", "庙", "得", "庙", "陷", "得", "得", "庙", "庙"],
  天梁: ["庙", "庙", "庙", "陷", "庙", "旺", "陷", "得", "庙", "陷", "庙", "旺"],
  七杀: ["庙", "旺", "庙", "平", "旺", "庙", "庙", "庙", "庙", "平", "旺", "庙"],
  破军: ["得", "陷", "旺", "平", "庙", "旺", "得", "陷", "旺", "平", "庙", "旺"],
};
const TRANSFORMS: Record<string, [string, string, string, string]> = {
  甲: ["廉贞", "破军", "武曲", "太阳"], 乙: ["天机", "天梁", "紫微", "太阴"], 丙: ["天同", "天机", "文昌", "廉贞"], 丁: ["太阴", "天同", "天机", "巨门"],
  戊: ["贪狼", "太阴", "右弼", "天机"], 己: ["武曲", "贪狼", "天梁", "文曲"], 庚: ["太阳", "武曲", "太阴", "天同"], 辛: ["巨门", "太阳", "文曲", "文昌"],
  壬: ["天梁", "紫微", "左辅", "武曲"], 癸: ["破军", "巨门", "太阴", "贪狼"],
};
const TRANSFORM_NAMES = ["化禄", "化权", "化科", "化忌"];
const KUI_YUE: Record<string, [string, string]> = { 甲: ["丑", "未"], 戊: ["丑", "未"], 庚: ["丑", "未"], 乙: ["子", "申"], 己: ["子", "申"], 丙: ["亥", "酉"], 丁: ["亥", "酉"], 辛: ["午", "寅"], 壬: ["卯", "巳"], 癸: ["卯", "巳"] };
const LUCUN: Record<string, string> = { 甲: "寅", 乙: "卯", 丙: "巳", 丁: "午", 戊: "巳", 己: "午", 庚: "申", 辛: "酉", 壬: "亥", 癸: "子" };

export type ZiWeiInput = { yearStem: string; yearBranch: string; lunarMonth: number; lunarDay: number; hourBranch: string; gender: "yin" | "yang"; currentYear: number; transformVariant?: "classic" | "alt" };
// Alternative four-transformation tables used by some schools: 庚 太阳·武曲·天府·天同, 壬 天梁·紫微·天府·武曲.
const TRANSFORMS_ALT: Record<string, [string, string, string, string]> = { 庚: ["太阳", "武曲", "天府", "天同"], 壬: ["天梁", "紫微", "天府", "武曲"] };
/** Lunar month used for a leap-month birth: split at day 15 (default), the month itself, or the next month. */
export function ziweiMonth(lunarMonth: number, lunarDay: number, leap: boolean, mode: "split" | "current" | "next" = "split") {
  if (!leap) return lunarMonth;
  if (mode === "current") return lunarMonth;
  if (mode === "next") return lunarMonth + 1;
  return lunarMonth + (lunarDay > 15 ? 1 : 0);
}

export function brightness(star: string, branch: string) {
  const table = BRIGHTNESS[star];
  return table ? table[mod(branchIndex(branch) - 2, 12)] : "";
}

export function ziweiPlacement(input: ZiWeiInput) {
  const hour = branchIndex(input.hourBranch);
  const month = Math.min(Math.max(input.lunarMonth, 1), 12);
  const day = Math.min(Math.max(input.lunarDay, 1), 30);
  const monthPos = 2 + month - 1;
  const lifeBranch = mod(monthPos - hour, 12);
  const bodyBranch = mod(monthPos + hour, 12);
  const yinStem = stemIndex(tigerMonthStem(input.yearStem));
  const palaceStem = (branch: number) => stemAt(yinStem + mod(branch - 2, 12));
  const lifeGanzhi = `${palaceStem(lifeBranch)}${branchAt(lifeBranch)}`;
  const [bureau, bureauName] = BUREAU[naYinElement(lifeGanzhi) ?? "水"];
  // 紫微
  let k = 0;
  while ((day + k) % bureau !== 0) k += 1;
  const q = (day + k) / bureau;
  const ziwei = mod(2 + q - 1 + (k % 2 === 1 ? -k : k), 12);
  const tianfu = mod(4 - ziwei, 12);
  const stars = new Map<number, string[]>();
  const minor = new Map<number, string[]>();
  const support = new Map<number, string[]>();
  const add = (map: Map<number, string[]>, position: number, star: string) => {
    const p = mod(position, 12);
    map.set(p, [...(map.get(p) ?? []), star]);
  };
  [["紫微", 0], ["天机", -1], ["太阳", -3], ["武曲", -4], ["天同", -5], ["廉贞", -8]].forEach(([star, offset]) => add(stars, ziwei + Number(offset), String(star)));
  [["天府", 0], ["太阴", 1], ["贪狼", 2], ["巨门", 3], ["天相", 4], ["天梁", 5], ["七杀", 6], ["破军", 10]].forEach(([star, offset]) => add(stars, tianfu + Number(offset), String(star)));
  add(support, 4 + month - 1, "左辅");
  add(support, 10 - (month - 1), "右弼");
  add(support, 10 - hour, "文昌");
  add(support, 4 + hour, "文曲");
  const [kui, yue] = KUI_YUE[input.yearStem] ?? ["丑", "未"];
  add(support, branchIndex(kui), "天魁");
  add(support, branchIndex(yue), "天钺");
  const lucun = branchIndex(LUCUN[input.yearStem] ?? "寅");
  add(support, lucun, "禄存");
  add(minor, lucun + 1, "擎羊");
  add(minor, lucun - 1, "陀罗");
  const yb = branchIndex(input.yearBranch);
  const group = [[8, 0, 4], [2, 6, 10], [5, 9, 1], [11, 3, 7]].findIndex((g) => g.includes(yb));
  const fireStart = [2, 1, 3, 9][group];
  const bellStart = [10, 3, 10, 10][group];
  add(minor, fireStart + hour, "火星");
  add(minor, bellStart + hour, "铃星");
  add(minor, 11 + hour, "地劫");
  add(minor, 11 - hour, "地空");
  add(minor, [2, 8, 11, 5][group], "天马");
  const hongluan = mod(3 - yb, 12);
  add(minor, hongluan, "红鸾");
  add(minor, hongluan + 6, "天喜");
  const transforms = new Map<string, string>();
  ((input.transformVariant === "alt" ? TRANSFORMS_ALT[input.yearStem] : undefined) ?? TRANSFORMS[input.yearStem] ?? TRANSFORMS.甲).forEach((star, index) => transforms.set(star, TRANSFORM_NAMES[index]));
  const forward = isYangStem(input.yearStem) === (input.gender === "yang");
  const currentBranch = mod(input.currentYear - 4, 12);
  const palaces = Array.from({ length: 12 }, (_, branch) => {
    const order = mod(lifeBranch - branch, 12);
    const step = forward ? mod(branch - lifeBranch, 12) : mod(lifeBranch - branch, 12);
    const decadeStart = bureau + step * 10;
    const yearsUntil = mod(branch - currentBranch, 12);
    const annualYear = input.currentYear + yearsUntil;
    const main = stars.get(branch) ?? [];
    const sup = support.get(branch) ?? [];
    const label = (star: string) => `${star}${brightness(star, branchAt(branch))}${transforms.has(star) ? transforms.get(star) : ""}`;
    return {
      branch: branchAt(branch),
      stem: palaceStem(branch),
      name: PALACE_NAMES[order],
      key: PALACE_KEYS[order],
      mainStars: main.map(label),
      mainStarNames: main,
      supportStars: sup.map((star) => `${star}${transforms.has(star) ? transforms.get(star) : ""}`),
      minorStars: minor.get(branch) ?? [],
      transforms: [...main, ...sup].filter((star) => transforms.has(star)).map((star) => `${star}${transforms.get(star)}`),
      brightness: main.map((star) => brightness(star, branchAt(branch))).filter(Boolean),
      decade: `${decadeStart}–${decadeStart + 9}`,
      annual: `${annualYear} ${ganzhiAt(annualYear - 4)}`,
      isLife: branch === lifeBranch,
      isBody: branch === bodyBranch,
    };
  });
  const borrowed = (branch: number) => stars.get(mod(branch + 6, 12)) ?? [];
  return { palaces, bureau, bureauName, lifeBranch: branchAt(lifeBranch), bodyBranch: branchAt(bodyBranch), lifeGanzhi, forward, borrowed, transforms: [...transforms].map(([star, name]) => `${star}${name}`) };
}
