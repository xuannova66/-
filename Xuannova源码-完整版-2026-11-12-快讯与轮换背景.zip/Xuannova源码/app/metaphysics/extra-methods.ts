// Four further classical methods: 金口诀 (Jin Kou Jue), 河洛理数 (He Luo numerology), 太乙神数 (Tai Yi, yearly
// reckoning) and 铁板神数 (Tie Ban, number framework only). All functions are pure.
import { BRANCHES, branchAt, branchElement, branchIndex, controls, generates, isYangStem, mod, ratHourStem, seasonalState, stemAt, stemElement, stemIndex, xunKong, type Element } from "./core";
import { liurenChart } from "./liuren";
import { hexagramName, type Trigram } from "./liuyao";

// ---------------------------------------------------------------------------------------------
// 金口诀: 地分 (chosen direction) · 将神 (month general on the hour) · 贵神 (heavenly general) · 人元 (五子元遁)
// ---------------------------------------------------------------------------------------------
const GENERAL_BRANCH: Record<string, string> = { 贵人: "丑", 螣蛇: "巳", 朱雀: "午", 六合: "卯", 勾陈: "辰", 青龙: "寅", 天空: "戌", 白虎: "申", 太常: "未", 玄武: "子", 太阴: "酉", 天后: "亥" };
export const BRANCH_DIRECTION: Record<string, string> = { 子: "正北", 丑: "东北", 寅: "东北", 卯: "正东", 辰: "东南", 巳: "东南", 午: "正南", 未: "西南", 申: "西南", 酉: "正西", 戌: "西北", 亥: "西北" };

export type JinPosition = { role: "人元" | "贵神" | "将神" | "地分"; value: string; element: Element; state: string; yang: boolean };

function relation(upper: Element, lower: Element) {
  if (upper === lower) return "比和";
  if (generates(upper, lower)) return "上生下";
  if (generates(lower, upper)) return "下生上";
  if (controls(upper, lower)) return "上克下";
  return "下克上";
}

export function jinKouJue(params: { qi: string; dayPillar: string; hourBranch: string; monthBranch: string; difen?: string }) {
  const { dayPillar, hourBranch, monthBranch } = params;
  const difen = params.difen && branchIndex(params.difen) >= 0 ? params.difen : hourBranch;
  const plate = liurenChart(params);
  const seat = plate.positions.find((position) => position.earth === difen)!;
  const dayStem = dayPillar.charAt(0);
  const renYuan = stemAt(stemIndex(ratHourStem(dayStem)) + branchIndex(difen));
  const guiShen = seat.general;
  const jiangShen = seat.sky;
  const make = (role: JinPosition["role"], value: string, element: Element, yang: boolean): JinPosition => ({ role, value, element, yang, state: seasonalState(element, monthBranch) });
  const positions: JinPosition[] = [
    make("人元", renYuan, stemElement(renYuan), isYangStem(renYuan)),
    make("贵神", guiShen, branchElement(GENERAL_BRANCH[guiShen] ?? "丑"), branchIndex(GENERAL_BRANCH[guiShen] ?? "丑") % 2 === 0),
    make("将神", jiangShen, branchElement(jiangShen), branchIndex(jiangShen) % 2 === 0),
    make("地分", difen, branchElement(difen), branchIndex(difen) % 2 === 0),
  ];
  // 用爻: the position whose element differs from all the others (五行独异者为用); if several, the general (将神) first.
  const unique = positions.filter((position) => positions.filter((other) => other.element === position.element).length === 1);
  const order: JinPosition["role"][] = ["将神", "贵神", "人元", "地分"];
  const use = unique.length ? unique.sort((a, b) => order.indexOf(a.role) - order.indexOf(b.role))[0].role : "将神";
  const yangCount = positions.filter((position) => position.yang).length;
  const voids = xunKong(dayPillar);
  return {
    difen, direction: BRANCH_DIRECTION[difen], monthGeneral: plate.monthGeneral, positions, use,
    pattern: yangCount === 4 ? "四阳" : yangCount === 0 ? "四阴" : yangCount === 3 ? "三阳一阴" : yangCount === 1 ? "三阴一阳" : "二阳二阴",
    links: [
      { pair: "人元 / 贵神", relation: relation(positions[0].element, positions[1].element) },
      { pair: "贵神 / 将神", relation: relation(positions[1].element, positions[2].element) },
      { pair: "将神 / 地分", relation: relation(positions[2].element, positions[3].element) },
    ],
    voids, voidHit: positions.filter((position) => voids.includes(position.value)).map((position) => position.role),
  };
}

// ---------------------------------------------------------------------------------------------
// 河洛理数: stems and branches → He Tu / Luo Shu numbers → 天数 and 地数 → 先天卦, 元堂, 后天卦, life periods
// ---------------------------------------------------------------------------------------------
const STEM_NUMBER: Record<string, number> = { 甲: 6, 乙: 2, 丙: 8, 丁: 7, 戊: 1, 己: 9, 庚: 3, 辛: 4, 壬: 6, 癸: 2 };
const BRANCH_NUMBERS: Record<string, [number, number]> = { 子: [1, 6], 亥: [1, 6], 寅: [3, 8], 卯: [3, 8], 巳: [2, 7], 午: [2, 7], 申: [4, 9], 酉: [4, 9], 辰: [5, 10], 戌: [5, 10], 丑: [5, 10], 未: [5, 10] };
const LUOSHU_TRIGRAM: Record<number, Trigram> = { 1: "坎", 2: "坤", 3: "震", 4: "巽", 6: "乾", 7: "兑", 8: "艮", 9: "离" };
export const TRIGRAM_LINES: Record<Trigram, [boolean, boolean, boolean]> = { 乾: [true, true, true], 兑: [true, true, false], 离: [true, false, true], 震: [true, false, false], 巽: [false, true, true], 坎: [false, true, false], 艮: [false, false, true], 坤: [false, false, false] };
const trigramFromLines = (lines: boolean[]) => (Object.keys(TRIGRAM_LINES) as Trigram[]).find((name) => TRIGRAM_LINES[name].every((line, index) => line === lines[index]))!;

function reduce(total: number, cap: number) {
  let value = total > cap ? total % cap || cap : total;
  if (value >= 10) value = value % 10 || Math.floor(value / 10);
  return value;
}

export function heLuo(params: { pillars: string[]; gender: "yin" | "yang"; hourBranch: string; birthYear: number; currentYear: number }) {
  const { pillars, gender } = params;
  const numbers = pillars.flatMap((pillar) => [STEM_NUMBER[pillar.charAt(0)] ?? 0, ...(BRANCH_NUMBERS[pillar.charAt(1)] ?? [])]);
  const heavenTotal = numbers.filter((value) => value % 2 === 1).reduce((sum, value) => sum + value, 0);
  const earthTotal = numbers.filter((value) => value % 2 === 0).reduce((sum, value) => sum + value, 0);
  const heavenNumber = reduce(heavenTotal, 25);
  const earthNumber = reduce(earthTotal, 30);
  // 5 has no trigram: men lodge it in 艮, women in 坤 (one common rule).
  const toTrigram = (value: number): Trigram => LUOSHU_TRIGRAM[value] ?? (gender === "yang" ? "艮" : "坤");
  const heavenTrigram = toTrigram(heavenNumber);
  const earthTrigram = toTrigram(earthNumber);
  const yangYear = isYangStem(pillars[0].charAt(0));
  const heavenOnTop = (gender === "yang") === yangYear; // 阳男阴女: 天数卦在上
  const upper = heavenOnTop ? heavenTrigram : earthTrigram;
  const lower = heavenOnTop ? earthTrigram : heavenTrigram;
  const lines = [...TRIGRAM_LINES[lower], ...TRIGRAM_LINES[upper]];
  // 元堂: born in a yang hour (子–巳) count the yang lines, in a yin hour (午–亥) the yin lines, from the bottom, cycling.
  const hour = branchIndex(params.hourBranch);
  const yangHour = hour >= 0 && hour < 6;
  const count = yangHour ? hour + 1 : hour - 5;
  let candidates = lines.map((line, index) => ({ line, index })).filter((entry) => entry.line === yangHour).map((entry) => entry.index);
  if (!candidates.length) candidates = [0, 1, 2, 3, 4, 5];
  const yuanTang = candidates[mod(count - 1, candidates.length)];
  const changed = lines.map((line, index) => (index === yuanTang ? !line : line));
  // 后天卦: change the 元堂 line, then swap the upper and lower trigrams; its 元堂 moves by three lines.
  const changedLower = trigramFromLines(changed.slice(0, 3));
  const changedUpper = trigramFromLines(changed.slice(3, 6));
  const laterLines = [...TRIGRAM_LINES[changedUpper], ...TRIGRAM_LINES[changedLower]];
  const laterYuanTang = mod(yuanTang + 3, 6);
  // Life periods: from the 元堂 line upward, a yang line governs 9 years and a yin line 6; then the later hexagram.
  const periods: Array<{ stage: "先天" | "后天"; line: number; yang: boolean; from: number; to: number }> = [];
  let age = 1;
  const walk = (stage: "先天" | "后天", hexLines: boolean[], start: number) => {
    for (let step = 0; step < 6; step += 1) {
      const index = mod(start + step, 6);
      const span = hexLines[index] ? 9 : 6;
      periods.push({ stage, line: index + 1, yang: hexLines[index], from: age, to: age + span - 1 });
      age += span;
    }
  };
  walk("先天", lines, yuanTang);
  walk("后天", laterLines, laterYuanTang);
  const currentAge = params.currentYear - params.birthYear + 1;
  return {
    numbers, heavenTotal, earthTotal, heavenNumber, earthNumber, heavenTrigram, earthTrigram,
    former: { upper, lower, name: hexagramName(lower, upper), lines, yuanTang: yuanTang + 1 },
    later: { upper: changedLower, lower: changedUpper, name: hexagramName(changedUpper, changedLower), lines: laterLines, yuanTang: laterYuanTang + 1 },
    periods, currentAge, current: periods.find((period) => currentAge >= period.from && currentAge <= period.to) ?? null,
  };
}

// ---------------------------------------------------------------------------------------------
// 太乙神数 (年计): accumulated years since the Tai Yi epoch, the palace Tai Yi occupies (three years per palace,
// 24-year round, never the centre) and the five 72-year eras.
// ---------------------------------------------------------------------------------------------
const TAIYI_PALACES = [1, 2, 3, 4, 6, 7, 8, 9];
export const TAIYI_PALACE_NAME: Record<number, string> = { 1: "乾", 2: "离", 3: "艮", 4: "震", 6: "兑", 7: "坤", 8: "坎", 9: "巽" };
export const TAIYI_PALACE_DIRECTION: Record<number, string> = { 1: "西北", 2: "正南", 3: "东北", 4: "正东", 6: "正西", 7: "西南", 8: "正北", 9: "东南" };
const ERAS = ["甲子元", "丙子元", "戊子元", "庚子元", "壬子元"];
export const TAIYI_EPOCH = 10153917;

export function taiYiYear(year: number) {
  const accumulated = TAIYI_EPOCH + year;
  const round = accumulated % 24 || 24;
  const palace = TAIYI_PALACES[Math.ceil(round / 3) - 1];
  const yearInPalace = ((round - 1) % 3) + 1;
  const eraRemainder = accumulated % 360;
  const ganzhi = `${stemAt(year - 4)}${branchAt(year - 4)}`;
  return {
    year, ganzhi, accumulated, round, palace, palaceName: TAIYI_PALACE_NAME[palace], direction: TAIYI_PALACE_DIRECTION[palace], yearInPalace,
    era: ERAS[Math.floor(eraRemainder / 72)], yearInEra: (eraRemainder % 72) + 1,
    nextPalaceYear: year + (3 - yearInPalace) + 1,
  };
}

// ---------------------------------------------------------------------------------------------
// 铁板神数 (number framework): 太玄数 of the eight characters, the trigram pair they give, and the eight
// quarters (刻) of the birth hour used to fix the exact moment (考刻). The verse book is not included.
// ---------------------------------------------------------------------------------------------
const TAIXUAN: Record<string, number> = { 甲: 9, 己: 9, 子: 9, 午: 9, 乙: 8, 庚: 8, 丑: 8, 未: 8, 丙: 7, 辛: 7, 寅: 7, 申: 7, 丁: 6, 壬: 6, 卯: 6, 酉: 6, 戊: 5, 癸: 5, 辰: 5, 戌: 5, 巳: 4, 亥: 4 };
const XIANTIAN: Trigram[] = ["乾", "兑", "离", "震", "巽", "坎", "艮", "坤"];

export function tieBan(params: { pillars: string[]; birthTime: string }) {
  const perPillar = params.pillars.map((pillar) => ({ pillar, stem: TAIXUAN[pillar.charAt(0)] ?? 0, branch: TAIXUAN[pillar.charAt(1)] ?? 0 }));
  const stemTotal = perPillar.reduce((sum, item) => sum + item.stem, 0);
  const branchTotal = perPillar.reduce((sum, item) => sum + item.branch, 0);
  const upper = XIANTIAN[mod(stemTotal - 1, 8)];
  const lower = XIANTIAN[mod(branchTotal - 1, 8)];
  const [hh, mm] = (params.birthTime || "12:00").split(":").map(Number);
  // A two-hour period starts at an odd hour (子 at 23:00); each of its eight quarters (刻) lasts 15 minutes.
  const start = mod(hh % 2 === 1 ? hh : hh - 1, 24);
  const quarter = Math.min(7, Math.floor((mod(hh - start, 24) * 60 + (mm || 0)) / 15));
  const hourBranch = BRANCHES[Math.floor(mod(hh + 1, 24) / 2)];
  const clock = (minutes: number) => `${String(mod(start + Math.floor(minutes / 60), 24)).padStart(2, "0")}:${String(minutes % 60).padStart(2, "0")}`;
  return {
    perPillar, stemTotal, branchTotal, upper, lower, name: hexagramName(lower, upper),
    hourBranch, quarter: quarter + 1, quarterTrigram: XIANTIAN[quarter],
    quarters: XIANTIAN.map((trigram, index) => ({ index: index + 1, trigram, from: clock(index * 15), to: clock(index * 15 + 14) })),
  };
}
