// Six-line (六爻) chart by the Jing Fang / Na Jia method.
// Line arrays are bottom-first: index 0 is the first (初) line, index 5 the top line.
import { branchElement, sixRelative, xunKong, type Element } from "./core";

export const TRIGRAMS = ["乾", "兑", "离", "震", "巽", "坎", "艮", "坤"] as const;
export type Trigram = typeof TRIGRAMS[number];
// bottom, middle, top (true = yang)
const TRIGRAM_LINES: Record<Trigram, [boolean, boolean, boolean]> = {
  乾: [true, true, true], 兑: [true, true, false], 离: [true, false, true], 震: [true, false, false],
  巽: [false, true, true], 坎: [false, true, false], 艮: [false, false, true], 坤: [false, false, false],
};
const TRIGRAM_NATURE: Record<Trigram, string> = { 乾: "天", 兑: "泽", 离: "火", 震: "雷", 巽: "风", 坎: "水", 艮: "山", 坤: "地" };
const TRIGRAM_ELEMENT: Record<Trigram, Element> = { 乾: "金", 兑: "金", 离: "火", 震: "木", 巽: "木", 坎: "水", 艮: "土", 坤: "土" };
const NAJIA_STEM: Record<Trigram, [string, string]> = { 乾: ["甲", "壬"], 坤: ["乙", "癸"], 震: ["庚", "庚"], 巽: ["辛", "辛"], 坎: ["戊", "戊"], 离: ["己", "己"], 艮: ["丙", "丙"], 兑: ["丁", "丁"] };
const NAJIA_BRANCH: Record<Trigram, [string, string]> = {
  乾: ["子寅辰", "午申戌"], 震: ["子寅辰", "午申戌"], 坎: ["寅辰午", "申戌子"], 艮: ["辰午申", "戌子寅"],
  坤: ["未巳卯", "丑亥酉"], 巽: ["丑亥酉", "未巳卯"], 离: ["卯丑亥", "酉未巳"], 兑: ["巳卯丑", "亥酉未"],
};
const SPIRITS = ["青龙", "朱雀", "勾陈", "螣蛇", "白虎", "玄武"];
const SPIRIT_START: Record<string, number> = { 甲: 0, 乙: 0, 丙: 1, 丁: 1, 戊: 2, 己: 3, 庚: 4, 辛: 4, 壬: 5, 癸: 5 };

// King Wen sequence: [number, short name, upper, lower]
const KING_WEN: Array<[number, string, Trigram, Trigram]> = [
  [1, "乾", "乾", "乾"], [2, "坤", "坤", "坤"], [3, "屯", "坎", "震"], [4, "蒙", "艮", "坎"], [5, "需", "坎", "乾"], [6, "讼", "乾", "坎"], [7, "师", "坤", "坎"], [8, "比", "坎", "坤"],
  [9, "小畜", "巽", "乾"], [10, "履", "乾", "兑"], [11, "泰", "坤", "乾"], [12, "否", "乾", "坤"], [13, "同人", "乾", "离"], [14, "大有", "离", "乾"], [15, "谦", "坤", "艮"], [16, "豫", "震", "坤"],
  [17, "随", "兑", "震"], [18, "蛊", "艮", "巽"], [19, "临", "坤", "兑"], [20, "观", "巽", "坤"], [21, "噬嗑", "离", "震"], [22, "贲", "艮", "离"], [23, "剥", "艮", "坤"], [24, "复", "坤", "震"],
  [25, "无妄", "乾", "震"], [26, "大畜", "艮", "乾"], [27, "颐", "艮", "震"], [28, "大过", "兑", "巽"], [29, "坎", "坎", "坎"], [30, "离", "离", "离"], [31, "咸", "兑", "艮"], [32, "恒", "震", "巽"],
  [33, "遁", "乾", "艮"], [34, "大壮", "震", "乾"], [35, "晋", "离", "坤"], [36, "明夷", "坤", "离"], [37, "家人", "巽", "离"], [38, "睽", "离", "兑"], [39, "蹇", "坎", "艮"], [40, "解", "震", "坎"],
  [41, "损", "艮", "兑"], [42, "益", "巽", "震"], [43, "夬", "兑", "乾"], [44, "姤", "乾", "巽"], [45, "萃", "兑", "坤"], [46, "升", "坤", "巽"], [47, "困", "兑", "坎"], [48, "井", "坎", "巽"],
  [49, "革", "兑", "离"], [50, "鼎", "离", "巽"], [51, "震", "震", "震"], [52, "艮", "艮", "艮"], [53, "渐", "巽", "艮"], [54, "归妹", "震", "兑"], [55, "丰", "震", "离"], [56, "旅", "离", "艮"],
  [57, "巽", "巽", "巽"], [58, "兑", "兑", "兑"], [59, "涣", "巽", "坎"], [60, "节", "坎", "兑"], [61, "中孚", "巽", "兑"], [62, "小过", "震", "艮"], [63, "既济", "坎", "离"], [64, "未济", "离", "坎"],
];

export const trigramLines = (name: Trigram) => [...TRIGRAM_LINES[name]];

/** Plum-blossom time casting (梅花易数·时间起卦): lunar year branch, month, day and hour numbers. */
export function plumBlossomCast(yearBranchNumber: number, lunarMonth: number, lunarDay: number, hourBranchNumber: number) {
  const base = yearBranchNumber + lunarMonth + lunarDay;
  const upper = TRIGRAMS[((base % 8) + 7) % 8];
  const lower = TRIGRAMS[(((base + hourBranchNumber) % 8) + 7) % 8];
  const movingIndex = (((base + hourBranchNumber) % 6) + 5) % 6; // 0-based, bottom line first
  const lines = [...TRIGRAM_LINES[lower], ...TRIGRAM_LINES[upper]];
  return { lines, movingLines: lines.map((_, index) => index === movingIndex) };
}

/** Plum-blossom number casting (报数起卦): first number → upper trigram, second → lower, sum + hour → moving line. */
export function plumBlossomNumberCast(first: number, second: number, hourBranchNumber: number) {
  const a = Math.max(1, Math.floor(Math.abs(first)));
  const b = Math.max(1, Math.floor(Math.abs(second)));
  const upper = TRIGRAMS[((a % 8) + 7) % 8];
  const lower = TRIGRAMS[((b % 8) + 7) % 8];
  const movingIndex = (((a + b + hourBranchNumber) % 6) + 5) % 6;
  const lines = [...TRIGRAM_LINES[lower], ...TRIGRAM_LINES[upper]];
  return { lines, movingLines: lines.map((_, index) => index === movingIndex), numbers: [a, b] as [number, number] };
}

/**
 * Plum-blossom text casting (字数起卦): the phrase is split in half; the first half's count gives the upper
 * trigram, the second half's the lower, and the total plus the hour gives the moving line. Chinese, Japanese
 * and Korean text is counted by characters; other languages by words.
 */
export function plumBlossomTextCast(text: string, hourBranchNumber: number) {
  const cjk = /[\u3400-\u9fff\uf900-\ufaff\u3040-\u30ff\uac00-\ud7af]/;
  const units = cjk.test(text) ? Array.from(text.replace(/[\s\p{P}\p{S}]/gu, "")) : text.split(/[\s\p{P}]+/u).filter(Boolean);
  const total = Math.max(2, units.length);
  const firstHalf = Math.floor(total / 2);
  const cast = plumBlossomNumberCast(firstHalf, total - firstHalf, 0);
  const movingIndex = (((total + hourBranchNumber) % 6) + 5) % 6;
  return { ...cast, movingLines: cast.lines.map((_, index) => index === movingIndex), units: total };
}

export function trigramOf(lines: boolean[]): Trigram {
  return TRIGRAMS.find((name) => TRIGRAM_LINES[name].every((yang, index) => yang === lines[index])) ?? "坤";
}

export function hexagramName(lower: Trigram, upper: Trigram) {
  const entry = KING_WEN.find(([, , u, l]) => u === upper && l === lower)!;
  const full = upper === lower ? `${upper}为${TRIGRAM_NATURE[upper]}` : `${TRIGRAM_NATURE[upper]}${TRIGRAM_NATURE[lower]}${entry[1]}`;
  return { number: entry[0], short: entry[1], full };
}

const key = (lines: boolean[]) => lines.map((yang) => (yang ? "1" : "0")).join("");
// palace map: hexagram key -> { palace, world line (1-based) }
const PALACE_MAP = new Map<string, { palace: Trigram; world: number; stage: string }>();
for (const palace of TRIGRAMS) {
  const base = [...TRIGRAM_LINES[palace], ...TRIGRAM_LINES[palace]];
  const flip = (lines: boolean[], positions: number[]) => lines.map((yang, index) => (positions.includes(index) ? !yang : yang));
  const stages: Array<[boolean[], number, string]> = [];
  stages.push([base, 6, "本宫"]);
  for (let n = 1; n <= 5; n += 1) stages.push([flip(base, Array.from({ length: n }, (_, i) => i)), n, `${["一", "二", "三", "四", "五"][n - 1]}世`]);
  const fifth = stages[5][0];
  const wandering = flip(fifth, [3]);
  stages.push([wandering, 4, "游魂"]);
  stages.push([[...base.slice(0, 3), ...wandering.slice(3)], 3, "归魂"]);
  for (const [lines, world, stage] of stages) PALACE_MAP.set(key(lines), { palace, world, stage });
}

export type LiuyaoLine = {
  position: number; // 1..6 bottom-up
  yang: boolean;
  moving: boolean;
  stem: string;
  branch: string;
  element: Element;
  relative: string;
  spirit: string;
  role: "世" | "应" | "";
  hidden?: string;
  changed?: { yang: boolean; stem: string; branch: string; relative: string };
};

function najia(lines: boolean[]) {
  const lower = trigramOf(lines.slice(0, 3));
  const upper = trigramOf(lines.slice(3, 6));
  return lines.map((_, index) => {
    const inner = index < 3;
    const trigram = inner ? lower : upper;
    const stem = NAJIA_STEM[trigram][inner ? 0 : 1];
    const branch = NAJIA_BRANCH[trigram][inner ? 0 : 1].charAt(inner ? index : index - 3);
    return { stem, branch };
  });
}

export function castLiuyao(lines: boolean[], movingLines: boolean[], dayPillar: string) {
  const original = lines.slice(0, 6);
  const moving = Array.from({ length: 6 }, (_, index) => Boolean(movingLines[index]));
  const changedLines = original.map((yang, index) => (moving[index] ? !yang : yang));
  const lower = trigramOf(original.slice(0, 3));
  const upper = trigramOf(original.slice(3, 6));
  const changedLower = trigramOf(changedLines.slice(0, 3));
  const changedUpper = trigramOf(changedLines.slice(3, 6));
  const palaceInfo = PALACE_MAP.get(key(original))!;
  const palaceElement = TRIGRAM_ELEMENT[palaceInfo.palace];
  const world = palaceInfo.world;
  const response = ((world + 2) % 6) + 1;
  const stems = najia(original);
  const changedStems = najia(changedLines);
  const spiritStart = SPIRIT_START[dayPillar.charAt(0)] ?? 0;
  const pureLines = [...TRIGRAM_LINES[palaceInfo.palace], ...TRIGRAM_LINES[palaceInfo.palace]];
  const pureStems = najia(pureLines);
  const result: LiuyaoLine[] = original.map((yang, index) => {
    const { stem, branch } = stems[index];
    const element = branchElement(branch);
    const line: LiuyaoLine = {
      position: index + 1, yang, moving: moving[index], stem, branch, element,
      relative: sixRelative(palaceElement, element),
      spirit: SPIRITS[(spiritStart + index) % 6],
      role: index + 1 === world ? "世" : index + 1 === response ? "应" : "",
    };
    if (moving[index]) {
      const changed = changedStems[index];
      line.changed = { yang: changedLines[index], stem: changed.stem, branch: changed.branch, relative: sixRelative(palaceElement, branchElement(changed.branch)) };
    }
    return line;
  });
  // 伏神: relatives missing from the hexagram are taken from the pure palace hexagram.
  const present = new Set(result.map((line) => line.relative));
  pureStems.forEach(({ stem, branch }, index) => {
    const relative = sixRelative(palaceElement, branchElement(branch));
    if (!present.has(relative)) result[index].hidden = `${relative} ${stem}${branch}`;
  });
  const name = hexagramName(lower, upper);
  const changedName = hexagramName(changedLower, changedUpper);
  const hasMoving = moving.some(Boolean);
  return {
    lines: result,
    palace: palaceInfo.palace,
    palaceElement,
    palaceStage: palaceInfo.stage,
    world,
    response,
    lower, upper, changedLower, changedUpper,
    name,
    changedName: hasMoving ? changedName : undefined,
    voids: xunKong(dayPillar),
  };
}
