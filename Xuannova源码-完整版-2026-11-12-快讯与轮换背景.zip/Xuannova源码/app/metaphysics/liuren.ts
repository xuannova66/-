// Da Liu Ren (大六壬): monthly general, heaven/earth plates, four lessons, three transmissions, heavenly generals.
import { BRANCHES, branchAt, branchElement, branchIndex, controls, isYangStem, mod, postHorse, PUNISH, sixRelative, stemAt, stemElement, xunHead, xunKong, jiaziIndex } from "./core";

const GENERAL_BY_QI: Record<string, string> = { 雨水: "亥", 春分: "戌", 谷雨: "酉", 小满: "申", 夏至: "未", 大暑: "午", 处暑: "巳", 秋分: "辰", 霜降: "卯", 小雪: "寅", 冬至: "丑", 大寒: "子" };
const STEM_LODGE: Record<string, string> = { 甲: "寅", 乙: "辰", 丙: "巳", 丁: "未", 戊: "巳", 己: "未", 庚: "申", 辛: "戌", 壬: "亥", 癸: "丑" };
const NOBLE_DAY: Record<string, [string, string]> = { 甲: ["丑", "未"], 戊: ["丑", "未"], 庚: ["丑", "未"], 乙: ["子", "申"], 己: ["子", "申"], 丙: ["亥", "酉"], 丁: ["亥", "酉"], 壬: ["巳", "卯"], 癸: ["巳", "卯"], 辛: ["午", "寅"] };
export const GENERALS = ["贵人", "螣蛇", "朱雀", "六合", "勾陈", "青龙", "天空", "白虎", "太常", "玄武", "太阴", "天后"];
const OFFICERS = ["建", "除", "满", "平", "定", "执", "破", "危", "成", "收", "开", "闭"];
const MENG = new Set(["寅", "申", "巳", "亥"]);
const ZHONG = new Set(["子", "午", "卯", "酉"]);

export function liurenChart(params: { qi: string; dayPillar: string; hourBranch: string; monthBranch: string }) {
  const { qi, dayPillar, hourBranch, monthBranch } = params;
  const dayStem = dayPillar.charAt(0);
  const dayBranch = dayPillar.charAt(1);
  const general = GENERAL_BY_QI[qi] ?? "子";
  const shift = branchIndex(general) - branchIndex(hourBranch);
  const heaven = (earth: string) => branchAt(branchIndex(earth) + shift);
  const earthUnder = (sky: string) => branchAt(branchIndex(sky) - shift);
  const lodge = STEM_LODGE[dayStem] ?? "寅";
  const l1 = { lower: dayStem, upper: heaven(lodge) };
  const l2 = { lower: l1.upper, upper: heaven(l1.upper) };
  const l3 = { lower: dayBranch, upper: heaven(dayBranch) };
  const l4 = { lower: l3.upper, upper: heaven(l3.upper) };
  const lessons = [l1, l2, l3, l4];
  const elementOf = (value: string) => (branchIndex(value) >= 0 ? branchElement(value) : stemElement(value));
  const yinYang = (value: string) => (branchIndex(value) >= 0 ? branchIndex(value) % 2 === 0 : isYangStem(value));
  const dayYang = isYangStem(dayStem);

  let method = "";
  let initial = "";
  const pickAmong = (candidates: typeof lessons) => {
    const uniq = candidates.filter((lesson, index) => candidates.findIndex((other) => other.upper === lesson.upper) === index);
    if (uniq.length === 1) return uniq[0].upper;
    const same = uniq.filter((lesson) => yinYang(lesson.upper) === dayYang);
    if (same.length === 1) { method = "比用"; return same[0].upper; }
    const pool = same.length ? same : uniq;
    method = "涉害";
    return (pool.find((lesson) => MENG.has(lesson.upper)) ?? pool.find((lesson) => ZHONG.has(lesson.upper)) ?? pool[0]).upper;
  };
  const isFanYin = mod(shift, 12) === 6;
  const isFuYin = mod(shift, 12) === 0;
  const below = lessons.filter((lesson) => controls(elementOf(lesson.lower), elementOf(lesson.upper))); // 下贼上
  const above = lessons.filter((lesson) => controls(elementOf(lesson.upper), elementOf(lesson.lower))); // 上克下
  if (isFuYin) {
    method = "伏吟";
    initial = dayYang ? l1.upper : l3.upper;
    const firstClash = [...below, ...above][0];
    if (firstClash) initial = firstClash.upper;
  } else if (below.length) {
    method = below.length === 1 ? "重审" : "";
    initial = pickAmong(below);
    if (!method) method = "比用";
  } else if (above.length) {
    method = above.length === 1 ? "元首" : "";
    initial = pickAmong(above);
    if (!method) method = "比用";
  } else if (isFanYin) {
    method = "返吟";
    initial = postHorse(dayBranch);
  } else {
    const dayEl = stemElement(dayStem);
    const far1 = lessons.slice(1).filter((lesson) => controls(elementOf(lesson.upper), dayEl));
    const far2 = lessons.slice(1).filter((lesson) => controls(dayEl, elementOf(lesson.upper)));
    if (far1.length || far2.length) {
      method = "遥克";
      initial = pickAmong(far1.length ? far1 : far2);
      method = "遥克";
    } else {
      method = "昴星";
      initial = dayYang ? heaven("酉") : earthUnder("酉");
    }
  }
  let middle: string;
  let final: string;
  if (method === "伏吟") {
    const punish = (branch: string) => (PUNISH[branch] === branch ? branchAt(branchIndex(branch) + 6) : PUNISH[branch]);
    middle = punish(initial);
    final = punish(middle);
  } else if (method === "返吟") {
    middle = l3.upper;
    final = l1.upper;
  } else if (method === "昴星") {
    middle = dayYang ? l3.upper : l1.upper;
    final = dayYang ? l1.upper : l3.upper;
  } else {
    middle = heaven(initial);
    final = heaven(middle);
  }
  // Heavenly generals
  const hour = branchIndex(hourBranch);
  const daytime = hour >= 3 && hour <= 8;
  const nobleBranch = (NOBLE_DAY[dayStem] ?? ["丑", "未"])[daytime ? 0 : 1];
  const nobleSeat = earthUnder(nobleBranch);
  const clockwise = [11, 0, 1, 2, 3, 4].includes(branchIndex(nobleSeat));
  const generalOf = (sky: string) => GENERALS[mod((branchIndex(sky) - branchIndex(nobleBranch)) * (clockwise ? 1 : -1), 12)];
  const head = jiaziIndex(xunHead(dayPillar));
  const hiddenStem = (sky: string) => {
    const offset = mod(branchIndex(sky) - mod(head, 12), 12);
    return offset < 10 ? stemAt(offset) : "空";
  };
  const dayEl = stemElement(dayStem);
  const positions = BRANCHES.map((earth) => {
    const sky = heaven(earth);
    return {
      earth, sky, general: generalOf(sky), stem: hiddenStem(sky), element: branchElement(sky),
      officer: OFFICERS[mod(branchIndex(earth) - branchIndex(monthBranch), 12)],
    };
  });
  const transmission = (branch: string) => ({ branch, general: generalOf(branch), stem: hiddenStem(branch), relative: sixRelative(dayEl, branchElement(branch)) });
  return {
    monthGeneral: general, hourBranch, method,
    lessons: lessons.map((lesson) => ({ ...lesson, general: generalOf(lesson.upper) })),
    transmissions: [transmission(initial), transmission(middle), transmission(final)],
    positions, nobleBranch, daytime, clockwise,
    voids: xunKong(dayPillar), horse: postHorse(dayBranch), xun: xunHead(dayPillar),
  };
}
