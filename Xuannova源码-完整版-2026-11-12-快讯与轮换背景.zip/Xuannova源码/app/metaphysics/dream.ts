// Dream image lookup: keywords in seven languages → traditional cultural associations (reflection only).
type L7 = { en: string; "zh-Hans": string; "zh-Hant": string; ja: string; ko: string; vi: string; th: string };
type Symbol = { name: L7; theme: L7; element: "Wood" | "Fire" | "Earth" | "Metal" | "Water"; keywords: string[] };
const s = (name: [string, string, string, string, string, string, string], theme: [string, string, string, string, string, string, string], element: Symbol["element"], keywords: string): Symbol => ({
  name: { en: name[0], "zh-Hans": name[1], "zh-Hant": name[2], ja: name[3], ko: name[4], vi: name[5], th: name[6] },
  theme: { en: theme[0], "zh-Hans": theme[1], "zh-Hant": theme[2], ja: theme[3], ko: theme[4], vi: theme[5], th: theme[6] },
  element,
  keywords: [...name, ...keywords.split(",")].map((k) => k.trim().toLowerCase()).filter(Boolean),
});

export const DREAM_SYMBOLS: Symbol[] = [
  s(["Water", "水", "水", "水", "물", "Nước", "น้ำ"], ["emotion and flow", "情绪与流动", "情緒與流動", "感情と流れ", "감정과 흐름", "cảm xúc và dòng chảy", "อารมณ์และการไหล"], "Water", "river,sea,ocean,lake,rain,flood,河,海,湖,雨,洪,川,강,바다,비,sông,biển,mưa,ทะเล,แม่น้ำ,ฝน"),
  s(["Fire", "火", "火", "火", "불", "Lửa", "ไฟ"], ["passion and transformation", "热情与转化", "熱情與轉化", "情熱と変化", "열정과 변화", "đam mê và chuyển hóa", "ความหลงใหลและการเปลี่ยนแปลง"], "Fire", "flame,burn,燃,烧,焼,炎,火事,화재,cháy,ลุกไหม้"),
  s(["Snake", "蛇", "蛇", "蛇", "뱀", "Rắn", "งู"], ["hidden energy and change", "潜藏的力量与转变", "潛藏的力量與轉變", "潜む力と変化", "숨은 힘과 변화", "năng lượng ẩn và thay đổi", "พลังที่ซ่อนอยู่และการเปลี่ยนแปลง"], "Fire", "serpent,python,ヘビ,구렁이,trăn"),
  s(["Dragon", "龙", "龍", "龍", "용", "Rồng", "มังกร"], ["ambition and vitality", "志向与生机", "志向與生機", "志と生命力", "포부와 생명력", "hoài bão và sinh lực", "ความทะเยอทะยานและพลังชีวิต"], "Wood", "竜,ドラゴン,드래곤"),
  s(["Fish", "鱼", "魚", "魚", "물고기", "Cá", "ปลา"], ["abundance", "丰足", "豐足", "豊かさ", "풍요", "sung túc", "ความอุดมสมบูรณ์"], "Water", "goldfish,carp,鲤,鯉,잉어,cá chép"),
  s(["Teeth", "牙齿", "牙齒", "歯", "이빨", "Răng", "ฟัน"], ["worry about change or family", "对变化或家人的牵挂", "對變化或家人的牽掛", "変化や家族への気がかり", "변화나 가족에 대한 걱정", "lo lắng về thay đổi hay gia đình", "ความกังวลเรื่องการเปลี่ยนแปลงหรือครอบครัว"], "Metal", "tooth,掉牙,落牙,牙,치아,이가,rụng răng"),
  s(["Flying", "飞", "飛", "飛ぶ", "날다", "Bay", "บิน"], ["freedom and perspective", "自由与视野", "自由與視野", "自由と視点", "자유와 시야", "tự do và tầm nhìn", "อิสรภาพและมุมมอง"], "Wood", "fly,flight,飞翔,飛翔,空を,비행,날아,bay lượn,เหาะ"),
  s(["Falling", "坠落", "墜落", "落ちる", "떨어지다", "Rơi", "ตก"], ["loss of footing", "失去依托", "失去依託", "足場の喪失", "기반 상실", "mất chỗ dựa", "การสูญเสียที่ยึด"], "Earth", "fall,掉下,跌,落下,추락,ngã,rơi xuống,หล่น"),
  s(["Being chased", "被追", "被追", "追いかけられる", "쫓기다", "Bị đuổi", "ถูกไล่"], ["avoided pressure", "回避的压力", "迴避的壓力", "避けている重圧", "회피한 압박", "áp lực né tránh", "แรงกดดันที่หลีกเลี่ยง"], "Metal", "chase,chased,追赶,追趕,追われ,쫓겨,đuổi theo,ไล่ล่า"),
  s(["Death", "死亡", "死亡", "死", "죽음", "Cái chết", "ความตาย"], ["an ending that makes room", "结束与腾出空间", "結束與騰出空間", "終わりと余白", "끝과 새 공간", "kết thúc để mở chỗ mới", "การสิ้นสุดที่เปิดพื้นที่ใหม่"], "Metal", "dead,die,died,死了,死去,죽은,chết,ตาย"),
  s(["Baby", "婴儿", "嬰兒", "赤ちゃん", "아기", "Em bé", "ทารก"], ["a new beginning", "新的开端", "新的開端", "新しい始まり", "새 출발", "khởi đầu mới", "การเริ่มต้นใหม่"], "Wood", "infant,newborn,宝宝,寶寶,赤ん坊,갓난,trẻ sơ sinh,เด็กอ่อน"),
  s(["Wedding", "婚礼", "婚禮", "結婚式", "결혼식", "Đám cưới", "งานแต่งงาน"], ["union and commitment", "结合与承诺", "結合與承諾", "結びつきと約束", "결합과 약속", "gắn kết và cam kết", "การรวมกันและพันธะ"], "Fire", "marriage,marry,结婚,結婚,결혼,cưới,แต่งงาน"),
  s(["House", "房子", "房子", "家", "집", "Ngôi nhà", "บ้าน"], ["the self and security", "自我与安全感", "自我與安全感", "自己と安心", "자아와 안정", "bản thân và an toàn", "ตัวตนและความมั่นคง"], "Earth", "home,room,房屋,房间,房間,部屋,방,nhà,ห้อง"),
  s(["Road", "道路", "道路", "道", "길", "Con đường", "ถนน"], ["direction", "方向", "方向", "方向", "방향", "phương hướng", "ทิศทาง"], "Earth", "path,street,路,road trip,도로,đường,ทาง"),
  s(["Mountain", "山", "山", "山", "산", "Núi", "ภูเขา"], ["challenge and steadiness", "挑战与稳定", "挑戰與穩定", "挑戦と安定", "도전과 안정", "thử thách và vững vàng", "ความท้าทายและความมั่นคง"], "Earth", "hill,climb,爬山,登山,등산,leo núi,ปีนเขา"),
  s(["Money", "钱", "錢", "お金", "돈", "Tiền", "เงิน"], ["value and self-worth", "价值与自我价值", "價值與自我價值", "価値と自己評価", "가치와 자존감", "giá trị và lòng tự trọng", "คุณค่าและการเห็นคุณค่าในตนเอง"], "Metal", "cash,gold,coin,金钱,金錢,黄金,金,현금,vàng,ทอง"),
  s(["Cat", "猫", "貓", "猫", "고양이", "Mèo", "แมว"], ["independence and intuition", "独立与直觉", "獨立與直覺", "自立と直感", "독립과 직관", "độc lập và trực giác", "ความเป็นอิสระและสัญชาตญาณ"], "Wood", "kitten,ネコ,새끼고양이,mèo con,ลูกแมว"),
  s(["Dog", "狗", "狗", "犬", "개", "Chó", "สุนัข"], ["loyalty and protection", "忠诚与守护", "忠誠與守護", "忠誠と守り", "충성과 보호", "trung thành và bảo vệ", "ความภักดีและการปกป้อง"], "Earth", "puppy,犬,イヌ,강아지,cún,หมา"),
  s(["Tiger", "老虎", "老虎", "虎", "호랑이", "Hổ", "เสือ"], ["courage and authority", "勇气与威势", "勇氣與威勢", "勇気と威厳", "용기와 위엄", "dũng khí và uy quyền", "ความกล้าและอำนาจ"], "Wood", "虎,トラ,범,cọp"),
  s(["Bird", "鸟", "鳥", "鳥", "새", "Chim", "นก"], ["messages and aspiration", "讯息与向往", "訊息與嚮往", "知らせと憧れ", "소식과 동경", "tin tức và khát vọng", "ข่าวสารและความใฝ่ฝัน"], "Fire", "birds,eagle,鹰,鷹,독수리,đại bàng,อินทรี"),
  s(["Tree", "树", "樹", "木", "나무", "Cây", "ต้นไม้"], ["growth and roots", "成长与根基", "成長與根基", "成長と根", "성장과 뿌리", "phát triển và cội rễ", "การเติบโตและรากฐาน"], "Wood", "forest,森林,숲,rừng,ป่า"),
  s(["Flower", "花", "花", "花", "꽃", "Hoa", "ดอกไม้"], ["beauty and blossoming", "美好与绽放", "美好與綻放", "美と開花", "아름다움과 개화", "vẻ đẹp và nở rộ", "ความงามและการเบ่งบาน"], "Wood", "flowers,blossom,开花,開花,꽃이,nở hoa,บาน"),
  s(["Moon", "月亮", "月亮", "月", "달", "Mặt trăng", "ดวงจันทร์"], ["the inner world", "内在世界", "內在世界", "内面の世界", "내면 세계", "thế giới nội tâm", "โลกภายใน"], "Water", "moonlight,月光,달빛,ánh trăng,แสงจันทร์"),
  s(["Sun", "太阳", "太陽", "太陽", "태양", "Mặt trời", "ดวงอาทิตย์"], ["clarity and vitality", "明朗与活力", "明朗與活力", "明るさと活力", "명료함과 활력", "sáng tỏ và sức sống", "ความชัดเจนและพลังชีวิต"], "Fire", "sunshine,阳光,陽光,日光,햇빛,nắng,แสงแดด"),
  s(["Exam", "考试", "考試", "試験", "시험", "Thi cử", "การสอบ"], ["self-evaluation", "自我检视", "自我檢視", "自己評価", "자기 평가", "tự đánh giá", "การประเมินตนเอง"], "Metal", "test,exam,考场,考場,テスト,kỳ thi,สอบ"),
  s(["Car", "车", "車", "車", "자동차", "Xe", "รถ"], ["control of one's path", "对方向的掌控", "對方向的掌控", "進路の主導権", "삶의 통제", "làm chủ hướng đi", "การควบคุมเส้นทาง"], "Metal", "driving,drive,开车,開車,運転,운전,lái xe,ขับรถ"),
  s(["Lost", "迷路", "迷路", "迷子", "길을 잃다", "Lạc đường", "หลงทาง"], ["searching for direction", "寻找方向", "尋找方向", "方向探し", "방향 찾기", "tìm hướng đi", "การค้นหาทิศทาง"], "Earth", "lost,迷失,迷い,길을 잃,lạc,หลง"),
  s(["Blood", "血", "血", "血", "피", "Máu", "เลือด"], ["life force and cost", "生命力与付出", "生命力與付出", "生命力と代償", "생명력과 대가", "sinh lực và cái giá", "พลังชีวิตและสิ่งที่ต้องจ่าย"], "Fire", "bleeding,流血,출혈,chảy máu,เลือดออก"),
  s(["Hair", "头发", "頭髮", "髪", "머리카락", "Tóc", "ผม"], ["identity and strength", "身份与力量", "身份與力量", "自己像と力", "정체성과 힘", "bản sắc và sức mạnh", "ตัวตนและพลัง"], "Wood", "haircut,剪发,剪髮,散髪,이발,cắt tóc,ตัดผม"),
  s(["Mother", "母亲", "母親", "母", "어머니", "Mẹ", "แม่"], ["care and origin", "照护与根源", "照護與根源", "世話と根源", "돌봄과 근원", "chăm sóc và cội nguồn", "การดูแลและต้นกำเนิด"], "Earth", "mom,妈妈,媽媽,お母さん,엄마,má,มารดา"),
  s(["Father", "父亲", "父親", "父", "아버지", "Cha", "พ่อ"], ["guidance and boundaries", "引导与界限", "引導與界限", "導きと境界", "인도와 경계", "dẫn dắt và ranh giới", "การชี้นำและขอบเขต"], "Metal", "dad,爸爸,お父さん,아빠,bố,บิดา"),
  s(["Door", "门", "門", "扉", "문", "Cánh cửa", "ประตู"], ["opportunity and transition", "机会与过渡", "機會與過渡", "機会と移行", "기회와 전환", "cơ hội và chuyển tiếp", "โอกาสและการเปลี่ยนผ่าน"], "Wood", "gate,大门,大門,ドア,대문,cổng,ประตูบ้าน"),
  s(["Rain", "下雨", "下雨", "雨", "비가 오다", "Mưa", "ฝนตก"], ["release and cleansing", "释放与洗涤", "釋放與洗滌", "解放と浄化", "해소와 정화", "giải tỏa và gột rửa", "การปลดปล่อยและชำระล้าง"], "Water", "storm,暴雨,嵐,폭우,bão,พายุ"),
  s(["Ghost", "鬼", "鬼", "幽霊", "귀신", "Ma", "ผี"], ["unresolved memories", "未释怀的记忆", "未釋懷的記憶", "未解決の記憶", "풀리지 않은 기억", "ký ức chưa nguôi", "ความทรงจำที่ยังค้างคา"], "Metal", "spirit,幽灵,幽靈,お化け,유령,hồn ma,วิญญาณ"),
];

const LATIN = /^[\p{Script=Latin}\s'-]+$/u;
function keywordPosition(source: string, keyword: string) {
  if (LATIN.test(keyword)) {
    const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const match = new RegExp(`(?<!\\p{L})${escaped}(?!\\p{L})`, "u").exec(source);
    return match ? match.index : Infinity;
  }
  const at = source.indexOf(keyword);
  return at < 0 ? Infinity : at;
}

export function matchDreamSymbols(text: string, limit = 3) {
  const source = text.toLowerCase();
  if (!source.trim()) return [];
  return DREAM_SYMBOLS
    .map((symbol) => ({ symbol, position: Math.min(...symbol.keywords.map((keyword) => keywordPosition(source, keyword))) }))
    .filter((entry) => Number.isFinite(entry.position))
    .sort((a, b) => a.position - b.position)
    .slice(0, limit)
    .map((entry) => entry.symbol);
}

export function dreamTermRows(): L7[] {
  return DREAM_SYMBOLS.flatMap((symbol) => [symbol.name, symbol.theme]);
}
