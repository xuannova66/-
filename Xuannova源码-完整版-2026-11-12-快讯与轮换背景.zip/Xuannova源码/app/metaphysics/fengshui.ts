// House feng shui reference: Eight Mansions (八宅) personal trigram and house trigram, plus the
// year's flying stars (年飞星). Directions use the eight compass points.
import { ganzhiAt, mod } from "./core";

export const DIRECTIONS = ["North", "Northeast", "East", "Southeast", "South", "Southwest", "West", "Northwest"] as const;
export type Direction = typeof DIRECTIONS[number];
const DIRECTION_TRIGRAM: Record<Direction, string> = { North: "坎", Northeast: "艮", East: "震", Southeast: "巽", South: "离", Southwest: "坤", West: "兑", Northwest: "乾" };
const KUA_TRIGRAM: Record<number, string> = { 1: "坎", 2: "坤", 3: "震", 4: "巽", 6: "乾", 7: "兑", 8: "艮", 9: "离" };
const EAST_GROUP = new Set([1, 3, 4, 9]);
const MANSION_NAMES = ["生气", "天医", "延年", "伏位", "祸害", "五鬼", "六煞", "绝命"];
// For each kua: directions of 生气, 天医, 延年, 伏位, 祸害, 五鬼, 六煞, 绝命.
const MANSIONS: Record<number, Direction[]> = {
  1: ["Southeast", "East", "South", "North", "West", "Northeast", "Northwest", "Southwest"],
  2: ["Northeast", "West", "Northwest", "Southwest", "East", "Southeast", "South", "North"],
  3: ["South", "North", "Southeast", "East", "Southwest", "Northwest", "Northeast", "West"],
  4: ["North", "South", "East", "Southeast", "Northwest", "Southwest", "West", "Northeast"],
  6: ["West", "Northeast", "Southwest", "Northwest", "Southeast", "East", "North", "South"],
  7: ["Northwest", "Southwest", "Northeast", "West", "North", "South", "Southeast", "East"],
  8: ["Southwest", "Northwest", "West", "Northeast", "South", "North", "East", "Southeast"],
  9: ["East", "Southeast", "North", "South", "Northeast", "West", "Southwest", "Northwest"],
};
const KUA_OF_TRIGRAM: Record<string, number> = Object.fromEntries(Object.entries(KUA_TRIGRAM).map(([k, v]) => [v, Number(k)]));
export const STAR_NAMES = ["一白", "二黑", "三碧", "四绿", "五黄", "六白", "七赤", "八白", "九紫"];
// Luo Shu flight path from the centre: centre, NW, W, NE, S, N, SW, E, SE
const FLIGHT: Array<Direction | "Center"> = ["Center", "Northwest", "West", "Northeast", "South", "North", "Southwest", "East", "Southeast"];

const digitSum = (value: number) => { let n = value; while (n > 9) n = String(n).split("").reduce((sum, digit) => sum + Number(digit), 0); return n; };

/** Personal (Kua) number by the solar year (starting at 立春) and gender. 5 becomes 2 (male) or 8 (female). */
export function kuaNumber(solarYear: number, gender: "yin" | "yang") {
  const reduced = digitSum(solarYear % 100) || 9;
  const after2000 = solarYear >= 2000;
  let kua = gender === "yang" ? (after2000 ? 9 - reduced : 10 - reduced) : digitSum((after2000 ? 6 : 5) + reduced);
  kua = mod(kua, 9) || 9;
  if (kua === 5) kua = gender === "yang" ? 2 : 8;
  return kua;
}

export function annualCenterStar(solarYear: number) {
  return mod(11 - mod(solarYear, 9), 9) || 9;
}

export function fengshuiChart(params: { solarYear: number; gender: "yin" | "yang"; sitting: Direction; currentYear: number }) {
  const kua = kuaNumber(params.solarYear, params.gender);
  const personGroup = EAST_GROUP.has(kua) ? "东四命" : "西四命";
  const houseTrigram = DIRECTION_TRIGRAM[params.sitting];
  const houseKua = KUA_OF_TRIGRAM[houseTrigram];
  const houseGroup = EAST_GROUP.has(houseKua) ? "东四宅" : "西四宅";
  const personal = MANSIONS[kua];
  const house = MANSIONS[houseKua];
  const center = annualCenterStar(params.currentYear);
  const stars: Record<string, string> = {};
  FLIGHT.forEach((place, step) => { stars[place] = STAR_NAMES[mod(center - 1 + step, 9)]; });
  const facing = DIRECTIONS[mod(DIRECTIONS.indexOf(params.sitting) + 4, 8)];
  const directions = DIRECTIONS.map((direction) => ({
    direction,
    trigram: DIRECTION_TRIGRAM[direction],
    personal: MANSION_NAMES[personal.indexOf(direction)],
    house: MANSION_NAMES[house.indexOf(direction)],
    annualStar: stars[direction],
  }));
  return {
    kua, kuaTrigram: KUA_TRIGRAM[kua], personGroup, houseTrigram, houseGroup, matched: (personGroup === "东四命") === (houseGroup === "东四宅"),
    sitting: params.sitting, facing, centerStar: stars.Center, year: params.currentYear, yearGanzhi: ganzhiAt(params.currentYear - 4), directions,
  };
}
