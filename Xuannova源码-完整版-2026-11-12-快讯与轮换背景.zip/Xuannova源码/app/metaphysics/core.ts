// Shared stem/branch arithmetic for every chart engine.
// All functions are pure: the same input always gives the same output.

export const STEMS = ["甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸"] as const;
export const BRANCHES = ["子", "丑", "寅", "卯", "辰", "巳", "午", "未", "申", "酉", "戌", "亥"] as const;
export type Element = "木" | "火" | "土" | "金" | "水";
export const ELEMENTS: Element[] = ["木", "火", "土", "金", "水"];
export const ELEMENT_EN: Record<Element, "Wood" | "Fire" | "Earth" | "Metal" | "Water"> = { 木: "Wood", 火: "Fire", 土: "Earth", 金: "Metal", 水: "Water" };

const STEM_ELEMENT: Element[] = ["木", "木", "火", "火", "土", "土", "金", "金", "水", "水"];
const BRANCH_ELEMENT: Element[] = ["水", "土", "木", "木", "土", "火", "火", "土", "金", "金", "土", "水"];

export const mod = (value: number, base: number) => ((value % base) + base) % base;
export const stemIndex = (stem: string) => STEMS.indexOf(stem as typeof STEMS[number]);
export const branchIndex = (branch: string) => BRANCHES.indexOf(branch as typeof BRANCHES[number]);
export const stemElement = (stem: string): Element => STEM_ELEMENT[stemIndex(stem)] ?? "土";
export const branchElement = (branch: string): Element => BRANCH_ELEMENT[branchIndex(branch)] ?? "土";
export const isYangStem = (stem: string) => stemIndex(stem) % 2 === 0;
export const branchAt = (index: number) => BRANCHES[mod(index, 12)];
export const stemAt = (index: number) => STEMS[mod(index, 10)];

/** 0–59 index in the sexagenary cycle (甲子 = 0). Returns -1 for invalid pairs. */
export function jiaziIndex(ganzhi: string) {
  const s = stemIndex(ganzhi.charAt(0));
  const b = branchIndex(ganzhi.charAt(1));
  if (s < 0 || b < 0 || s % 2 !== b % 2) return -1;
  return mod(6 * s - 5 * b, 60);
}
export const ganzhiAt = (index: number) => `${STEMS[mod(index, 10)]}${BRANCHES[mod(index, 12)]}`;
export const isValidGanzhi = (ganzhi: string) => jiaziIndex(ganzhi) >= 0;

/** The two "void" branches (旬空) of the ten-day week that contains ganzhi. */
export function xunKong(ganzhi: string): [string, string] {
  const index = jiaziIndex(ganzhi);
  if (index < 0) return ["—", "—"];
  const start = index - (index % 10);
  return [branchAt(start + 10), branchAt(start + 11)];
}
/** 旬首, e.g. 甲子 / 甲戌 … */
export function xunHead(ganzhi: string) {
  const index = jiaziIndex(ganzhi);
  return index < 0 ? "—" : ganzhiAt(index - (index % 10));
}

const NAYIN_ELEMENT: Element[] = ["金", "火", "木", "土", "金", "火", "水", "土", "金", "木", "水", "土", "火", "木", "水", "金", "火", "木", "土", "金", "火", "水", "土", "金", "木", "水", "土", "火", "木", "水"];
export function naYinElement(ganzhi: string): Element | undefined {
  const index = jiaziIndex(ganzhi);
  return index < 0 ? undefined : NAYIN_ELEMENT[Math.floor(index / 2)];
}

const GENERATES: Record<Element, Element> = { 木: "火", 火: "土", 土: "金", 金: "水", 水: "木" };
const CONTROLS: Record<Element, Element> = { 木: "土", 土: "水", 水: "火", 火: "金", 金: "木" };
export const generates = (a: Element, b: Element) => GENERATES[a] === b;
export const controls = (a: Element, b: Element) => CONTROLS[a] === b;

/** Six-relative of `other` seen from `self` (六亲). */
export function sixRelative(self: Element, other: Element) {
  if (self === other) return "兄弟";
  if (generates(self, other)) return "子孙";
  if (generates(other, self)) return "父母";
  if (controls(self, other)) return "妻财";
  return "官鬼";
}

/** 旺相休囚死 of an element in the season ruled by a month branch. */
export function seasonalState(element: Element, monthBranch: string) {
  const ruler = branchElement(monthBranch);
  if (element === ruler) return "旺";
  if (generates(ruler, element)) return "相";
  if (generates(element, ruler)) return "休";
  if (controls(element, ruler)) return "囚";
  return "死";
}

/** Stem of the first (寅) month for a year stem — 五虎遁. */
export function tigerMonthStem(yearStem: string) {
  return stemAt(mod(stemIndex(yearStem), 5) * 2 + 2);
}
/** Stem of the 子 hour for a day stem — 五鼠遁. */
export function ratHourStem(dayStem: string) {
  return stemAt(mod(stemIndex(dayStem), 5) * 2);
}

// 申子辰 water, 寅午戌 fire, 巳酉丑 metal, 亥卯未 wood
const TRIADS: number[][] = [[8, 0, 4], [2, 6, 10], [5, 9, 1], [11, 3, 7]];
export function triadGroup(branch: string) {
  const b = branchIndex(branch);
  return TRIADS.find((group) => group.includes(b)) ?? TRIADS[0];
}
/** 驿马 for a branch's three-harmony group. */
export function postHorse(branch: string) {
  return branchAt(triadGroup(branch)[0] + 6);
}
/** 桃花 */
export function peachBlossom(branch: string) {
  return branchAt(triadGroup(branch)[1] + 9);
}
/** 华盖 */
export function canopy(branch: string) {
  return branchAt(triadGroup(branch)[2]);
}
/** 将星 */
export function generalStar(branch: string) {
  return branchAt(triadGroup(branch)[1]);
}
/** 劫煞 */
export function robberyStar(branch: string) {
  return branchAt(triadGroup(branch)[2] + 1);
}

export const SIX_HARMONY: Record<string, string> = { 子: "丑", 丑: "子", 寅: "亥", 亥: "寅", 卯: "戌", 戌: "卯", 辰: "酉", 酉: "辰", 巳: "申", 申: "巳", 午: "未", 未: "午" };
export const SIX_HARM: Record<string, string> = { 子: "未", 未: "子", 丑: "午", 午: "丑", 寅: "巳", 巳: "寅", 卯: "辰", 辰: "卯", 申: "亥", 亥: "申", 酉: "戌", 戌: "酉" };
export const SIX_BREAK: Record<string, string> = { 子: "酉", 酉: "子", 午: "卯", 卯: "午", 辰: "丑", 丑: "辰", 戌: "未", 未: "戌", 寅: "亥", 亥: "寅", 巳: "申", 申: "巳" };
export const PUNISH: Record<string, string> = { 子: "卯", 卯: "子", 寅: "巳", 巳: "申", 申: "寅", 丑: "戌", 戌: "未", 未: "丑", 辰: "辰", 午: "午", 酉: "酉", 亥: "亥" };

/** Pairwise relations between two branches. */
export function branchPairRelations(a: string, b: string) {
  const out: string[] = [];
  if (SIX_HARMONY[a] === b) out.push("六合");
  if (mod(branchIndex(a) - branchIndex(b), 12) === 6) out.push("六冲");
  if (a === b && PUNISH[a] === a) out.push("自刑");
  else if (PUNISH[a] === b || PUNISH[b] === a) out.push("相刑");
  if (SIX_HARM[a] === b) out.push("六害");
  if (SIX_BREAK[a] === b) out.push("相破");
  if (a !== b && triadGroup(a) === triadGroup(b)) out.push("半合");
  return out;
}

const FULL_TRIADS: Array<[string, string]> = [["申子辰", "三合水局"], ["寅午戌", "三合火局"], ["巳酉丑", "三合金局"], ["亥卯未", "三合木局"]];
const MEETINGS: Array<[string, string]> = [["寅卯辰", "三会木方"], ["巳午未", "三会火方"], ["申酉戌", "三会金方"], ["亥子丑", "三会水方"]];
export function branchGroupRelations(branches: string[]) {
  const set = new Set(branches);
  return [...FULL_TRIADS, ...MEETINGS].filter(([group]) => [...group].every((b) => set.has(b))).map(([group, name]) => `${group} · ${name}`);
}

export const STEM_COMBINE: Record<string, [string, Element]> = { 甲: ["己", "土"], 己: ["甲", "土"], 乙: ["庚", "金"], 庚: ["乙", "金"], 丙: ["辛", "水"], 辛: ["丙", "水"], 丁: ["壬", "木"], 壬: ["丁", "木"], 戊: ["癸", "火"], 癸: ["戊", "火"] };

/** Ten God of `other` stem relative to the day stem. */
export function tenGod(dayStem: string, other: string) {
  const self = stemElement(dayStem);
  const target = stemElement(other);
  const same = isYangStem(dayStem) === isYangStem(other);
  if (self === target) return same ? "比肩" : "劫财";
  if (generates(self, target)) return same ? "食神" : "伤官";
  if (controls(self, target)) return same ? "偏财" : "正财";
  if (controls(target, self)) return same ? "七杀" : "正官";
  return same ? "偏印" : "正印";
}

const LIFE_STAGE_NAMES = ["长生", "沐浴", "冠带", "临官", "帝旺", "衰", "病", "死", "墓", "绝", "胎", "养"];
const BIRTH_BRANCH: Record<string, number> = { 甲: 11, 乙: 6, 丙: 2, 丁: 9, 戊: 2, 己: 9, 庚: 5, 辛: 0, 壬: 8, 癸: 3 };
/** Twelve life stages of a stem in a branch (yang forward, yin backward). */
export function lifeStage(stem: string, branch: string) {
  const start = BIRTH_BRANCH[stem];
  const b = branchIndex(branch);
  if (start === undefined || b < 0) return "—";
  const step = isYangStem(stem) ? mod(b - start, 12) : mod(start - b, 12);
  return LIFE_STAGE_NAMES[step];
}
