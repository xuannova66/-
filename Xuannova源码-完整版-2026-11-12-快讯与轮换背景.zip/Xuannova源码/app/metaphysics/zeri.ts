// 专业择日 (personal date selection): almanac suitability for one purpose, combined with the person's chart.
// Rules (one common school): the purpose must be listed as favourable and not as unfavourable; days that clash the
// person's year or day branch, year-break (岁破) and month-break (月破) days, 四离/四绝, 杨公忌 and (for weddings)
// 三娘煞 days are excluded; 黄道 spirits, good day officers, 天德/月德/天赦/天恩 and days whose stem element the
// chart favours score higher. Pure function; cultural study reference only.
import { Solar } from "lunar-javascript";
import { almanacDay, activityTerms, shiftIso, type ActivityKey } from "../almanac";
import { branchIndex, stemElement, generates, type Element } from "./core";
import { dayMasterStrength } from "../bazi-reference";

const GOOD_OFFICERS = new Set(["除", "危", "定", "执", "成", "开"]);
const LUCKY_STARS = ["天德", "月德", "天德合", "月德合", "天赦", "天恩", "母仓", "天喜"];
// 杨公忌日 by lunar month and day.
const YANGGONG: Array<[number, number]> = [[1, 13], [2, 11], [3, 9], [4, 7], [5, 5], [6, 3], [7, 1], [7, 29], [8, 27], [9, 25], [10, 23], [11, 21], [12, 19]];
const SANNIANG = new Set([3, 7, 13, 18, 22, 27]);
const SI_LI = ["春分", "夏至", "秋分", "冬至"];
const SI_JUE = ["立春", "立夏", "立秋", "立冬"];

const clashes = (a: string, b: string) => branchIndex(a) >= 0 && branchIndex(b) >= 0 && (branchIndex(a) + 6) % 12 === branchIndex(b);

export type ZeriExclusion = "purpose" | "personal-year" | "personal-day" | "year-break" | "month-break" | "si-li" | "si-jue" | "yanggong" | "sanniang";

export type ZeriDay = {
  iso: string; weekday: number; lunar: string; lunarMonth: number; lunarDay: number; lunarLeap: boolean; dayGanZhi: string; officer: string; spirit: string; spiritType: "黄道" | "黑道";
  score: number; stars: string[]; favourableElement: boolean; dayElement: Element;
  hours: Array<{ branch: string; from: string; to: string }>;
  excluded: ZeriExclusion[];
};

/** Elements the chart leans on: a strong day master is balanced by output, wealth and officer; a weak one by support. */
export function favourableElements(pillars: string[]): { verdict: string; elements: Element[] } {
  const strength = dayMasterStrength(pillars);
  const day = stemElement(pillars[2]?.charAt(0) ?? "");
  if (!strength || !day) return { verdict: "Balanced", elements: [] };
  const all: Element[] = ["木", "火", "土", "金", "水"];
  const resource = all.find((element) => generates(element, day))!;
  if (strength.verdict === "Leaning weak") return { verdict: strength.verdict, elements: [day, resource] };
  if (strength.verdict === "Leaning strong") return { verdict: strength.verdict, elements: all.filter((element) => element !== day && element !== resource) };
  return { verdict: strength.verdict, elements: [] };
}

function termDates(year: number) {
  const table = Solar.fromYmd(year, 6, 1).getLunar().getJieQiTable() as Record<string, { toYmd: () => string }>;
  const dates = new Map<string, string>();
  for (const name of [...SI_LI, ...SI_JUE]) if (table[name]) dates.set(table[name].toYmd(), name);
  return dates;
}

export function selectDays(input: { purpose: ActivityKey; pillars: string[]; start: string; days: number }) {
  const yearBranch = input.pillars[0]?.charAt(1) ?? "";
  const dayBranch = input.pillars[2]?.charAt(1) ?? "";
  const favour = favourableElements(input.pillars);
  const span = Math.max(7, Math.min(120, Math.round(input.days)));
  const startYear = Number(input.start.slice(0, 4));
  const terms = new Map([...termDates(startYear), ...termDates(startYear + 1)]);
  const results: ZeriDay[] = [];
  for (let offset = 0; offset < span; offset += 1) {
    const iso = shiftIso(input.start, offset);
    const day = almanacDay(iso);
    const [y, m, d] = iso.split("-").map(Number);
    const lunar = Solar.fromYmd(y, m, d).getLunar();
    const excluded: ZeriExclusion[] = [];
    const terms4 = activityTerms[input.purpose];
    if (!terms4.some((term) => day.yi.includes(term)) || terms4.some((term) => day.ji.includes(term)) || day.yi.includes("诸事不宜")) excluded.push("purpose");
    const branch = day.dayGanZhi.charAt(1);
    if (clashes(branch, yearBranch)) excluded.push("personal-year");
    if (clashes(branch, dayBranch)) excluded.push("personal-day");
    if (clashes(branch, day.yearGanZhi.charAt(1))) excluded.push("year-break");
    if (day.officer === "破") excluded.push("month-break");
    const tomorrow = shiftIso(iso, 1);
    const nextTerm = terms.get(tomorrow);
    if (nextTerm && SI_LI.includes(nextTerm)) excluded.push("si-li");
    if (nextTerm && SI_JUE.includes(nextTerm)) excluded.push("si-jue");
    if (!day.lunarLeap && YANGGONG.some(([month, date]) => month === day.lunarMonth && date === day.lunarDay)) excluded.push("yanggong");
    if (input.purpose === "wedding" && SANNIANG.has(day.lunarDay)) excluded.push("sanniang");
    const stars = (lunar.getDayJiShen() as string[]).filter((star) => LUCKY_STARS.includes(star));
    const dayElement = stemElement(day.dayGanZhi.charAt(0));
    const favourableElement = favour.elements.includes(dayElement);
    let score = 50;
    score += day.spiritType === "黄道" ? 15 : -10;
    score += GOOD_OFFICERS.has(day.officer) ? 10 : 0;
    score += Math.min(3, stars.length) * 6;
    score += favourableElement ? 10 : 0;
    // Hours: auspicious-spirit hours that do not clash the person's year branch.
    const hours = day.hours.filter((hour) => hour.good && !clashes(hour.branch, yearBranch)).map(({ branch, from, to }) => ({ branch, from, to }));
    results.push({ iso, weekday: day.weekday, lunar: `${day.lunarMonthZh}月${day.lunarDayZh}`, lunarMonth: day.lunarMonth, lunarDay: day.lunarDay, lunarLeap: day.lunarLeap, dayGanZhi: day.dayGanZhi, officer: day.officer, spirit: day.spirit, spiritType: day.spiritType, score: Math.max(0, Math.min(100, score)), stars, favourableElement, dayElement, hours, excluded });
  }
  const chosen = results.filter((day) => !day.excluded.length).sort((a, b) => b.score - a.score || a.iso.localeCompare(b.iso));
  const counts = results.reduce((map, day) => { for (const reason of day.excluded) map[reason] = (map[reason] ?? 0) + 1; return map; }, {} as Partial<Record<ZeriExclusion, number>>);
  return { span, yearBranch, dayBranch, favour, chosen, top: chosen.slice(0, 8), counts, checked: results.length };
}

export const zeriPurposes = Object.keys(activityTerms) as ActivityKey[];
