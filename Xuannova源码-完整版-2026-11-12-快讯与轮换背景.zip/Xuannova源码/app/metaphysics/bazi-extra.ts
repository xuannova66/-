// Rule-based BaZi layers that used to be filled with seeded placeholders:
// shen-sha, branch relations, seasonal state, climate, luck start, annual and monthly cycles.
import {
  BRANCHES, branchAt, branchElement, branchGroupRelations, branchIndex, branchPairRelations, canopy, generalStar, ganzhiAt,
  jiaziIndex, lifeStage, naYinElement, peachBlossom, postHorse, robberyStar, seasonalState, stemAt, stemElement, stemIndex,
  tenGod, tigerMonthStem, triadGroup, xunKong, isYangStem, STEM_COMBINE,
} from "./core";

const NOBLE: Record<string, string> = { 甲: "丑未", 戊: "丑未", 庚: "丑未", 乙: "子申", 己: "子申", 丙: "亥酉", 丁: "亥酉", 壬: "巳卯", 癸: "巳卯", 辛: "午寅" };
const LITERARY: Record<string, string> = { 甲: "巳", 乙: "午", 丙: "申", 丁: "酉", 戊: "申", 己: "酉", 庚: "亥", 辛: "子", 壬: "寅", 癸: "卯" };
const PROSPERITY: Record<string, string> = { 甲: "寅", 乙: "卯", 丙: "巳", 丁: "午", 戊: "巳", 己: "午", 庚: "申", 辛: "酉", 壬: "亥", 癸: "子" };
const BLADE: Record<string, string> = { 甲: "卯", 丙: "午", 戊: "午", 庚: "酉", 壬: "子" };
const SUPREME: Record<string, string> = { 甲: "子午", 乙: "子午", 丙: "卯酉", 丁: "卯酉", 戊: "辰戌丑未", 己: "辰戌丑未", 庚: "寅亥", 辛: "寅亥", 壬: "巳申", 癸: "巳申" };
const HEAVEN_VIRTUE: Record<string, string> = { 寅: "丁", 卯: "申", 辰: "壬", 巳: "辛", 午: "亥", 未: "甲", 申: "癸", 酉: "寅", 戌: "丙", 亥: "乙", 子: "巳", 丑: "庚" };
const MONTH_VIRTUE: Record<string, string> = { 寅: "丙", 午: "丙", 戌: "丙", 申: "壬", 子: "壬", 辰: "壬", 亥: "甲", 卯: "甲", 未: "甲", 巳: "庚", 酉: "庚", 丑: "庚" };

function lonelyWidow(yearBranch: string): [string, string] {
  const b = branchIndex(yearBranch);
  const season = Math.floor(((b + 1) % 12) / 3); // 亥子丑=0, 寅卯辰=1, 巳午未=2, 申酉戌=3
  return [["寅", "戌"], ["巳", "丑"], ["申", "辰"], ["亥", "未"]][season] as [string, string];
}

/** Shen-sha found on each of the four pillars, by the common classical rules. */
export function pillarShenSha(pillars: string[]) {
  const [year, month, day] = pillars;
  const dayStem = day.charAt(0);
  const yearStem = year.charAt(0);
  const yearBranch = year.charAt(1);
  const dayBranch = day.charAt(1);
  const monthBranch = month.charAt(1);
  const [lonely, widow] = lonelyWidow(yearBranch);
  const voids = xunKong(day);
  const redLuan = branchAt(3 - branchIndex(yearBranch));
  return pillars.map((pillar, index) => {
    const stem = pillar.charAt(0);
    const branch = pillar.charAt(1);
    const noble: string[] = [];
    const other: string[] = [];
    if (NOBLE[dayStem]?.includes(branch) || NOBLE[yearStem]?.includes(branch)) noble.push("天乙贵人");
    if (SUPREME[dayStem]?.includes(branch) || SUPREME[yearStem]?.includes(branch)) noble.push("太极贵人");
    if (LITERARY[dayStem] === branch) noble.push("文昌贵人");
    const hv = HEAVEN_VIRTUE[monthBranch];
    if (hv && (hv === stem || hv === branch)) noble.push("天德贵人");
    if (MONTH_VIRTUE[monthBranch] === stem) noble.push("月德贵人");
    if (PROSPERITY[dayStem] === branch) noble.push("禄神");
    if (BLADE[dayStem] === branch) other.push("羊刃");
    const refs = index === 0 ? [dayBranch] : index === 2 ? [yearBranch] : [yearBranch, dayBranch];
    if (refs.some((ref) => postHorse(ref) === branch)) other.push("驿马");
    if (refs.some((ref) => peachBlossom(ref) === branch)) other.push("桃花");
    if (refs.some((ref) => canopy(ref) === branch)) other.push("华盖");
    if (refs.some((ref) => generalStar(ref) === branch)) other.push("将星");
    if (refs.some((ref) => robberyStar(ref) === branch)) other.push("劫煞");
    if (index !== 0 && branch === lonely) other.push("孤辰");
    if (index !== 0 && branch === widow) other.push("寡宿");
    if (index !== 0 && branch === redLuan) other.push("红鸾");
    if (index !== 2 && voids.includes(branch)) other.push("空亡");
    return { noble, other };
  });
}

export function branchRelationRows(pillars: string[]) {
  const roles = ["Year branch", "Month branch", "Day branch", "Hour branch"];
  const branches = pillars.map((pillar) => pillar.charAt(1));
  const rows: Array<{ label: string; value: string }> = [];
  for (let i = 0; i < 4; i += 1) for (let j = i + 1; j < 4; j += 1) {
    const relations = branchPairRelations(branches[i], branches[j]);
    if (relations.length) rows.push({ label: `${roles[i]} / ${roles[j]}`, value: `${branches[i]}${branches[j]} · ${relations.join(" · ")}` });
  }
  for (const group of branchGroupRelations(branches)) rows.push({ label: "Four branches", value: group });
  const stems = pillars.map((pillar) => pillar.charAt(0));
  const stemRoles = ["Year stem", "Month stem", "Day stem", "Hour stem"];
  for (let i = 0; i < 4; i += 1) for (let j = i + 1; j < 4; j += 1) {
    const combine = STEM_COMBINE[stems[i]];
    if (combine && combine[0] === stems[j]) rows.push({ label: `${stemRoles[i]} / ${stemRoles[j]}`, value: `${stems[i]}${stems[j]} · 合化${combine[1]}` });
  }
  if (!rows.length) rows.push({ label: "Four branches", value: "无明显合冲刑害" });
  return rows;
}

/** Per-pillar relation summary (relations each branch has with the other three). */
export function branchRelationsByPillar(pillars: string[]) {
  const names = ["年", "月", "日", "时"];
  const branches = pillars.map((pillar) => pillar.charAt(1));
  return branches.map((branch, i) => {
    const parts = branches.flatMap((other, j) => j === i ? [] : branchPairRelations(branch, other).map((relation) => `${names[j]}${relation}`));
    return parts.length ? parts.join(" · ") : "—";
  });
}

const CLIMATE: Record<string, string> = { 子: "寒", 亥: "寒", 丑: "寒湿", 寅: "温", 卯: "温", 辰: "温湿", 巳: "热", 午: "热", 未: "热燥", 申: "凉", 酉: "凉", 戌: "凉燥" };
export const climateOf = (monthBranch: string) => CLIMATE[monthBranch] ?? "—";
export const seasonalStateOfStem = (stem: string, monthBranch: string) => seasonalState(stemElement(stem), monthBranch);
export const naYinElementOf = (pillar: string) => naYinElement(pillar) ?? "—";

/** Annual pillars starting from `fromYear`, with the day master's ten god and life stage. */
export function annualCycle(dayStem: string, fromYear: number, count = 12) {
  return Array.from({ length: count }, (_, offset) => {
    const year = fromYear + offset;
    const ganzhi = ganzhiAt(year - 4);
    return { year, ganzhi, tenGod: tenGod(dayStem, ganzhi.charAt(0)), stage: lifeStage(dayStem, ganzhi.charAt(1)) };
  });
}

const MONTH_TERMS = ["立春", "惊蛰", "清明", "立夏", "芒种", "小暑", "立秋", "白露", "寒露", "立冬", "大雪", "小寒"];
/** The twelve solar months of a year (寅 month first) by 五虎遁. */
export function monthCadence(year: number, dayStem: string) {
  const yearStem = stemAt(year - 4);
  const first = stemIndex(tigerMonthStem(yearStem));
  return MONTH_TERMS.map((term, index) => {
    const stem = stemAt(first + index);
    const branch = branchAt(2 + index);
    return { term, ganzhi: `${stem}${branch}`, element: branchElement(branch), tenGod: tenGod(dayStem, stem) };
  });
}

export type LuckStart = { age: number; years: number; months: number; days: number; startYear: number; cycles: Array<{ ganzhi: string; startAge: number; startYear: number }> };

/** Luck-cycle start from lunar-javascript's 起运 calculation (needs a real birth moment). */
export function luckStart(eightChar: { getYun: (gender: number, sect?: number) => { getStartYear: () => number; getStartMonth: () => number; getStartDay: () => number; getDaYun: () => Array<{ getGanZhi: () => string; getStartAge: () => number; getStartYear: () => number }> } }, gender: "yin" | "yang", sect: 1 | 2 = 1): LuckStart {
  // sect 1: three days = one year (traditional); sect 2: counted to the minute (4320 minutes = one year).
  const yun = eightChar.getYun(gender === "yang" ? 1 : 0, sect);
  const cycles = yun.getDaYun().filter((cycle) => cycle.getGanZhi()).map((cycle) => ({ ganzhi: cycle.getGanZhi(), startAge: cycle.getStartAge(), startYear: cycle.getStartYear() }));
  return { age: cycles[0]?.startAge ?? 0, years: yun.getStartYear(), months: yun.getStartMonth(), days: yun.getStartDay(), startYear: cycles[0]?.startYear ?? 0, cycles };
}

/** Pillar consistency check used for manually entered four pillars (五虎遁 / 五鼠遁). */
export function validatePillars(pillars: string[]) {
  const errors: string[] = [];
  if (pillars.length !== 4 || pillars.some((pillar) => jiaziIndex(pillar) < 0)) return ["invalid-ganzhi"];
  const [year, month, day, hour] = pillars;
  const monthOffset = (branchIndex(month.charAt(1)) - 2 + 12) % 12;
  if (stemIndex(month.charAt(0)) !== (stemIndex(tigerMonthStem(year.charAt(0))) + monthOffset) % 10) errors.push("month-stem");
  const hourBranch = branchIndex(hour.charAt(1));
  const ratStem = stemIndex(day.charAt(0)) % 5 * 2;
  if (stemIndex(hour.charAt(0)) !== (ratStem + hourBranch) % 10) errors.push("hour-stem");
  return errors;
}

export { BRANCHES, isYangStem, triadGroup };
