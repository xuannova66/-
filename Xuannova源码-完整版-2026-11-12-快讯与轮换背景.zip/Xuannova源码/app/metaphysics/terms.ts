// Central dictionary for classical chart terms emitted by the engines (canonical form: Simplified Chinese).
// zh-Hant and ja are derived by character conversion (with word overrides); the other locales are listed.
import { TRIGRAMS, hexagramName } from "./liuyao";
import { ALMANAC_ROWS } from "./almanac-terms";

export type TermLocale = "en" | "zh-Hans" | "zh-Hant" | "ja" | "ko" | "vi" | "th";

// [zh-Hans, en, ko, vi, th]
const ROWS: Array<[string, string, string, string, string]> = [
  // feng shui stars, Eight Mansions, plum blossom body/function
  ["一白", "1 White", "일백", "Nhất Bạch", "หนึ่งขาว"],
  ["二黑", "2 Black", "이흑", "Nhị Hắc", "สองดำ"],
  ["三碧", "3 Jade", "삼벽", "Tam Bích", "สามเขียวหยก"],
  ["四绿", "4 Green", "사록", "Tứ Lục", "สี่เขียว"],
  ["五黄", "5 Yellow", "오황", "Ngũ Hoàng", "ห้าเหลือง"],
  ["六白", "6 White", "육백", "Lục Bạch", "หกขาว"],
  ["七赤", "7 Red", "칠적", "Thất Xích", "เจ็ดแดง"],
  ["八白", "8 White", "팔백", "Bát Bạch", "แปดขาว"],
  ["九紫", "9 Purple", "구자", "Cửu Tử", "เก้าม่วง"],
  ["生气", "Sheng Qi (vitality)", "생기", "Sinh Khí", "เซิงชี่ (พลังชีวิต)"],
  ["天医", "Tian Yi (health)", "천의", "Thiên Y", "เทียนอี (สุขภาพ)"],
  ["延年", "Yan Nian (longevity)", "연년", "Diên Niên", "เหยียนเหนียน (อายุยืน)"],
  ["伏位", "Fu Wei (stability)", "복위", "Phục Vị", "ฝูเว่ย (มั่นคง)"],
  ["祸害", "Huo Hai (mishap)", "화해", "Họa Hại", "ฮั่วไห่ (เคราะห์)"],
  ["五鬼", "Wu Gui (five ghosts)", "오귀", "Ngũ Quỷ", "อู่กุ่ย (ห้าผี)"],
  ["六煞", "Liu Sha (six killings)", "육살", "Lục Sát", "ลิ่วซา (หกสังหาร)"],
  ["绝命", "Jue Ming (total loss)", "절명", "Tuyệt Mệnh", "เจวี๋ยมิ่ง (สูญสิ้น)"],
  ["东四命", "East group (person)", "동사명", "Đông tứ mệnh", "กลุ่มตะวันออก (บุคคล)"],
  ["西四命", "West group (person)", "서사명", "Tây tứ mệnh", "กลุ่มตะวันตก (บุคคล)"],
  ["东四宅", "East group (house)", "동사택", "Đông tứ trạch", "กลุ่มตะวันออก (บ้าน)"],
  ["西四宅", "West group (house)", "서사택", "Tây tứ trạch", "กลุ่มตะวันตก (บ้าน)"],
  ["体", "Body (Ti)", "체", "Thể", "กาย (ถี่)"],
  ["用", "Function (Yong)", "용", "Dụng", "การใช้ (ย่ง)"],
  ["体用比和", "Body and function in harmony", "체용비화", "Thể dụng tỷ hòa", "กายกับการใช้กลมกลืน"],
  ["用生体", "Function supports body", "용생체", "Dụng sinh thể", "การใช้หนุนกาย"],
  ["体生用", "Body supports function", "체생용", "Thể sinh dụng", "กายหนุนการใช้"],
  ["体克用", "Body controls function", "체극용", "Thể khắc dụng", "กายข่มการใช้"],
  ["用克体", "Function controls body", "용극체", "Dụng khắc thể", "การใช้ข่มกาย"],
  // stems & branches
  ["甲", "Jia", "갑", "Giáp", "เจี่ย"], ["乙", "Yi", "을", "Ất", "อี่"], ["丙", "Bing", "병", "Bính", "ปิ่ง"], ["丁", "Ding", "정", "Đinh", "ติง"], ["戊", "Wu", "무", "Mậu", "อู้"],
  ["己", "Ji", "기", "Kỷ", "จี๋"], ["庚", "Geng", "경", "Canh", "เกิง"], ["辛", "Xin", "신", "Tân", "ซิน"], ["壬", "Ren", "임", "Nhâm", "เหริน"], ["癸", "Gui", "계", "Quý", "กุ่ย"],
  ["子", "Zi", "자", "Tý", "จื่อ"], ["丑", "Chou", "축", "Sửu", "โฉ่ว"], ["寅", "Yin", "인", "Dần", "อิ๋น"], ["卯", "Mao", "묘", "Mão", "เหม่า"], ["辰", "Chen", "진", "Thìn", "เฉิน"], ["巳", "Si", "사", "Tỵ", "ซื่อ"],
  ["午", "Wu", "오", "Ngọ", "อู่"], ["未", "Wei", "미", "Mùi", "เว่ย"], ["申", "Shen", "신", "Thân", "เซิน"], ["酉", "You", "유", "Dậu", "โหย่ว"], ["戌", "Xu", "술", "Tuất", "ซวี"], ["亥", "Hai", "해", "Hợi", "ไห่"],
  // elements
  ["木", "Wood", "목", "Mộc", "ไม้"], ["火", "Fire", "화", "Hỏa", "ไฟ"], ["土", "Earth", "토", "Thổ", "ดิน"], ["金", "Metal", "금", "Kim", "โลหะ"], ["水", "Water", "수", "Thủy", "น้ำ"],
  // ten gods
  ["比肩", "Companion", "비견", "Tỷ Kiên", "เพื่อนร่วม (ปี่เจียน)"], ["劫财", "Rob Wealth", "겁재", "Kiếp Tài", "แย่งทรัพย์ (เจี๋ยไฉ)"], ["食神", "Eating God", "식신", "Thực Thần", "เทพอาหาร (สือเสิน)"],
  ["伤官", "Hurting Officer", "상관", "Thương Quan", "ทำร้ายขุนนาง (ซางกวน)"], ["偏财", "Indirect Wealth", "편재", "Thiên Tài", "ทรัพย์อ้อม (เพียนไฉ)"], ["正财", "Direct Wealth", "정재", "Chính Tài", "ทรัพย์ตรง (เจิ้งไฉ)"],
  ["七杀", "Seven Killings", "칠살", "Thất Sát", "เจ็ดสังหาร (ชีซา)"], ["正官", "Direct Officer", "정관", "Chính Quan", "ขุนนางตรง (เจิ้งกวน)"], ["偏印", "Indirect Resource", "편인", "Thiên Ấn", "ตราอ้อม (เพียนอิ้น)"], ["正印", "Direct Resource", "정인", "Chính Ấn", "ตราตรง (เจิ้งอิ้น)"],
  ["日主", "Day master", "일간", "Nhật chủ", "ธาตุวัน"], ["元男", "Day master (male)", "일간(남)", "Nhật chủ (nam)", "ธาตุวัน (ชาย)"], ["元女", "Day master (female)", "일간(여)", "Nhật chủ (nữ)", "ธาตุวัน (หญิง)"],
  // life stages
  ["长生", "Growth", "장생", "Trường Sinh", "เกิด"], ["沐浴", "Bath", "목욕", "Mộc Dục", "อาบน้ำ"], ["冠带", "Crowning", "관대", "Quan Đới", "สวมมงกุฎ"], ["临官", "Official", "건록", "Lâm Quan", "รับราชการ"],
  ["帝旺", "Peak", "제왕", "Đế Vượng", "รุ่งเรืองสูงสุด"], ["衰", "Decline", "쇠", "Suy", "เสื่อม"], ["病", "Illness", "병", "Bệnh", "ป่วย"], ["死", "Death", "사", "Tử", "ดับ"], ["墓", "Tomb", "묘", "Mộ", "สุสาน"],
  ["绝", "Extinction", "절", "Tuyệt", "สิ้นสุด"], ["胎", "Embryo", "태", "Thai", "ปฏิสนธิ"], ["养", "Nurture", "양", "Dưỡng", "บ่มเพาะ"],
  // seasonal state & climate
  ["旺", "Prosperous", "왕", "Vượng", "รุ่งเรือง"], ["相", "Supported", "상", "Tướng", "ได้หนุน"], ["休", "Resting", "휴", "Hưu", "พัก"], ["囚", "Confined", "수", "Tù", "ถูกกัก"],
  ["寒", "Cold", "한", "Hàn", "หนาว"], ["寒湿", "Cold and damp", "한습", "Hàn thấp", "หนาวชื้น"], ["温", "Mild", "온", "Ôn", "อุ่น"], ["温湿", "Mild and damp", "온습", "Ôn thấp", "อุ่นชื้น"],
  ["热", "Hot", "열", "Nhiệt", "ร้อน"], ["热燥", "Hot and dry", "열조", "Nhiệt táo", "ร้อนแห้ง"], ["凉", "Cool", "량", "Lương", "เย็น"], ["凉燥", "Cool and dry", "량조", "Lương táo", "เย็นแห้ง"],
  // shen-sha
  ["天乙贵人", "Heavenly Noble", "천을귀인", "Thiên Ất Quý Nhân", "ผู้อุปถัมภ์สวรรค์"], ["太极贵人", "Supreme Noble", "태극귀인", "Thái Cực Quý Nhân", "ผู้อุปถัมภ์ไท่จี๋"], ["文昌贵人", "Academic Star", "문창귀인", "Văn Xương Quý Nhân", "ดาววิชาการ"],
  ["天德贵人", "Heavenly Virtue", "천덕귀인", "Thiên Đức Quý Nhân", "คุณธรรมสวรรค์"], ["月德贵人", "Monthly Virtue", "월덕귀인", "Nguyệt Đức Quý Nhân", "คุณธรรมเดือน"], ["禄神", "Prosperity Star", "녹신", "Lộc Thần", "ดาวลาภ"],
  ["羊刃", "Goat Blade", "양인", "Dương Nhận", "ดาบแพะ"], ["驿马", "Travelling Horse", "역마", "Dịch Mã", "ม้าเดินทาง"], ["桃花", "Peach Blossom", "도화", "Đào Hoa", "ดอกท้อ"], ["华盖", "Canopy", "화개", "Hoa Cái", "ฉัตร"],
  ["将星", "General Star", "장성", "Tướng Tinh", "ดาวแม่ทัพ"], ["劫煞", "Robbery Sha", "겁살", "Kiếp Sát", "ดาวปล้น"], ["孤辰", "Lonely Star", "고신", "Cô Thần", "ดาวโดดเดี่ยว"], ["寡宿", "Widow Star", "과숙", "Quả Tú", "ดาวเปล่าเปลี่ยว"],
  ["红鸾", "Red Phoenix", "홍란", "Hồng Loan", "หงส์แดง"], ["天喜", "Heavenly Joy", "천희", "Thiên Hỷ", "ยินดีสวรรค์"], ["空亡", "Void", "공망", "Không Vong", "ว่าง"], ["空", "Void", "공", "Không", "ว่าง"],
  // relations
  ["六合", "Six Harmony", "육합", "Lục Hợp", "หกประสาน"], ["六冲", "Clash", "육충", "Lục Xung", "ปะทะ"], ["自刑", "Self-punishment", "자형", "Tự Hình", "ลงโทษตนเอง"], ["相刑", "Punishment", "상형", "Tương Hình", "ลงโทษกัน"],
  ["六害", "Harm", "육해", "Lục Hại", "ทำร้าย"], ["相破", "Break", "상파", "Tương Phá", "แตกหัก"], ["半合", "Half Harmony", "반합", "Bán Hợp", "ประสานครึ่ง"],
  ["三合水局", "Water Triad", "삼합수국", "Tam Hợp Thủy Cục", "สามประสานน้ำ"], ["三合火局", "Fire Triad", "삼합화국", "Tam Hợp Hỏa Cục", "สามประสานไฟ"], ["三合金局", "Metal Triad", "삼합금국", "Tam Hợp Kim Cục", "สามประสานโลหะ"], ["三合木局", "Wood Triad", "삼합목국", "Tam Hợp Mộc Cục", "สามประสานไม้"],
  ["三会木方", "Wood Directional Meeting", "삼회목방", "Tam Hội Mộc", "สามรวมทิศไม้"], ["三会火方", "Fire Directional Meeting", "삼회화방", "Tam Hội Hỏa", "สามรวมทิศไฟ"], ["三会金方", "Metal Directional Meeting", "삼회금방", "Tam Hội Kim", "สามรวมทิศโลหะ"], ["三会水方", "Water Directional Meeting", "삼회수방", "Tam Hội Thủy", "สามรวมทิศน้ำ"],
  ["合化土", "Combine into Earth", "합화토", "Hợp hóa Thổ", "รวมเป็นดิน"], ["合化金", "Combine into Metal", "합화금", "Hợp hóa Kim", "รวมเป็นโลหะ"], ["合化水", "Combine into Water", "합화수", "Hợp hóa Thủy", "รวมเป็นน้ำ"], ["合化木", "Combine into Wood", "합화목", "Hợp hóa Mộc", "รวมเป็นไม้"], ["合化火", "Combine into Fire", "합화화", "Hợp hóa Hỏa", "รวมเป็นไฟ"],
  ["无明显合冲刑害", "No notable combination, clash, punishment or harm", "뚜렷한 합충형해 없음", "Không có hợp, xung, hình, hại rõ rệt", "ไม่มีการประสาน ปะทะ ลงโทษ หรือทำร้ายที่เด่นชัด"],
  ["借", "borrowed", "차성", "mượn", "ยืม"], ["闰", "leap", "윤", "nhuận", "อธิกมาส"], ["年", "Year", "년", "Năm", "ปี"], ["月", "Month", "월", "Tháng", "เดือน"], ["日", "Day", "일", "Ngày", "วัน"], ["时", "Hour", "시", "Giờ", "ยาม"],
  // solar terms
  ["立春", "Start of Spring", "입춘", "Lập Xuân", "ลี่ชุน"], ["雨水", "Rain Water", "우수", "Vũ Thủy", "อวี่สุ่ย"], ["惊蛰", "Awakening of Insects", "경칩", "Kinh Trập", "จิงเจ๋อ"], ["春分", "Vernal Equinox", "춘분", "Xuân Phân", "ชุนเฟิน"],
  ["清明", "Clear and Bright", "청명", "Thanh Minh", "ชิงหมิง"], ["谷雨", "Grain Rain", "곡우", "Cốc Vũ", "กู่อวี่"], ["立夏", "Start of Summer", "입하", "Lập Hạ", "ลี่เซี่ย"], ["小满", "Grain Buds", "소만", "Tiểu Mãn", "เสี่ยวหม่าน"],
  ["芒种", "Grain in Ear", "망종", "Mang Chủng", "หมางจ้ง"], ["夏至", "Summer Solstice", "하지", "Hạ Chí", "เซี่ยจื้อ"], ["小暑", "Minor Heat", "소서", "Tiểu Thử", "เสี่ยวสู่"], ["大暑", "Major Heat", "대서", "Đại Thử", "ต้าสู่"],
  ["立秋", "Start of Autumn", "입추", "Lập Thu", "ลี่ชิว"], ["处暑", "End of Heat", "처서", "Xử Thử", "ฉู่สู่"], ["白露", "White Dew", "백로", "Bạch Lộ", "ไป๋ลู่"], ["秋分", "Autumnal Equinox", "추분", "Thu Phân", "ชิวเฟิน"],
  ["寒露", "Cold Dew", "한로", "Hàn Lộ", "หานลู่"], ["霜降", "Frost's Descent", "상강", "Sương Giáng", "ซวงเจี้ยง"], ["立冬", "Start of Winter", "입동", "Lập Đông", "ลี่ตง"], ["小雪", "Minor Snow", "소설", "Tiểu Tuyết", "เสี่ยวเสวี่ย"],
  ["大雪", "Major Snow", "대설", "Đại Tuyết", "ต้าเสวี่ย"], ["冬至", "Winter Solstice", "동지", "Đông Chí", "ตงจื้อ"], ["小寒", "Minor Cold", "소한", "Tiểu Hàn", "เสี่ยวหาน"], ["大寒", "Major Cold", "대한", "Đại Hàn", "ต้าหาน"],
  // trigrams
  ["乾", "Qian", "건", "Càn", "เฉียน"], ["兑", "Dui", "태", "Đoài", "ตุ้ย"], ["离", "Li", "리", "Ly", "หลี"], ["震", "Zhen", "진", "Chấn", "เจิ้น"], ["巽", "Xun", "손", "Tốn", "ซวิ่น"], ["坎", "Kan", "감", "Khảm", "ข่าน"], ["艮", "Gen", "간", "Cấn", "เกิ้น"], ["坤", "Kun", "곤", "Khôn", "คุน"],
  // liuyao
  ["父母", "Parents", "부모", "Phụ Mẫu", "บิดามารดา"], ["兄弟", "Siblings", "형제", "Huynh Đệ", "พี่น้อง"], ["子孙", "Offspring", "자손", "Tử Tôn", "ลูกหลาน"], ["妻财", "Wealth", "처재", "Thê Tài", "ทรัพย์"], ["官鬼", "Officer", "관귀", "Quan Quỷ", "ขุนนาง"],
  ["青龙", "Azure Dragon", "청룡", "Thanh Long", "มังกรเขียว"], ["朱雀", "Vermilion Bird", "주작", "Chu Tước", "หงส์แดงชาด"], ["勾陈", "Hook Array", "구진", "Câu Trần", "โกวเฉิน"], ["螣蛇", "Soaring Serpent", "등사", "Đằng Xà", "งูเหิน"],
  ["白虎", "White Tiger", "백호", "Bạch Hổ", "เสือขาว"], ["玄武", "Black Tortoise", "현무", "Huyền Vũ", "เต่าดำ"],
  ["世", "Self line", "세", "Thế", "เส้นตน"], ["应", "Response line", "응", "Ứng", "เส้นตอบ"], ["本宫", "Pure palace", "본궁", "Bản cung", "วังแท้"], ["一世", "First generation", "일세", "Nhất thế", "รุ่นที่หนึ่ง"], ["二世", "Second generation", "이세", "Nhị thế", "รุ่นที่สอง"],
  ["三世", "Third generation", "삼세", "Tam thế", "รุ่นที่สาม"], ["四世", "Fourth generation", "사세", "Tứ thế", "รุ่นที่สี่"], ["五世", "Fifth generation", "오세", "Ngũ thế", "รุ่นที่ห้า"], ["游魂", "Wandering soul", "유혼", "Du hồn", "วิญญาณเร่ร่อน"], ["归魂", "Returning soul", "귀혼", "Quy hồn", "วิญญาณคืน"],
  ["阳", "Yang", "양", "Dương", "หยาง"], ["阴", "Yin", "음", "Âm", "หยิน"], ["动", "Moving", "동", "Động", "เคลื่อน"], ["静", "Still", "정", "Tĩnh", "นิ่ง"],
  ["乾宫", "Qian palace", "건궁", "Cung Càn", "วังเฉียน"], ["兑宫", "Dui palace", "태궁", "Cung Đoài", "วังตุ้ย"], ["离宫", "Li palace", "리궁", "Cung Ly", "วังหลี"], ["震宫", "Zhen palace", "진궁", "Cung Chấn", "วังเจิ้น"],
  ["巽宫", "Xun palace", "손궁", "Cung Tốn", "วังซวิ่น"], ["坎宫", "Kan palace", "감궁", "Cung Khảm", "วังข่าน"], ["艮宫", "Gen palace", "간궁", "Cung Cấn", "วังเกิ้น"], ["坤宫", "Kun palace", "곤궁", "Cung Khôn", "วังคุน"],
  // ziwei stars
  ["紫微", "Zi Wei", "자미", "Tử Vi", "จื่อเวย"], ["天机", "Tian Ji", "천기", "Thiên Cơ", "เทียนจี"], ["太阳", "Tai Yang (Sun)", "태양", "Thái Dương", "ไท่หยาง"], ["武曲", "Wu Qu", "무곡", "Vũ Khúc", "อู่ชวี"],
  ["天同", "Tian Tong", "천동", "Thiên Đồng", "เทียนถง"], ["廉贞", "Lian Zhen", "염정", "Liêm Trinh", "เหลียนเจิน"], ["天府", "Tian Fu", "천부", "Thiên Phủ", "เทียนฝู่"], ["太阴", "Tai Yin (Moon)", "태음", "Thái Âm", "ไท่อิน"],
  ["贪狼", "Tan Lang", "탐랑", "Tham Lang", "ทานหลาง"], ["巨门", "Ju Men", "거문", "Cự Môn", "จวี้เหมิน"], ["天相", "Tian Xiang", "천상", "Thiên Tướng", "เทียนเซี่ยง"], ["天梁", "Tian Liang", "천량", "Thiên Lương", "เทียนเหลียง"],
  ["七杀", "Qi Sha", "칠살", "Thất Sát", "ชีซา"], ["破军", "Po Jun", "파군", "Phá Quân", "พั่วจวิน"],
  ["左辅", "Zuo Fu", "좌보", "Tả Phụ", "จั่วฝู่"], ["右弼", "You Bi", "우필", "Hữu Bật", "โหย่วปี้"], ["文昌", "Wen Chang", "문창", "Văn Xương", "เหวินชาง"], ["文曲", "Wen Qu", "문곡", "Văn Khúc", "เหวินชวี"],
  ["天魁", "Tian Kui", "천괴", "Thiên Khôi", "เทียนขุย"], ["天钺", "Tian Yue", "천월", "Thiên Việt", "เทียนเยวี่ย"], ["禄存", "Lu Cun", "녹존", "Lộc Tồn", "ลู่ฉุน"], ["擎羊", "Qing Yang", "경양", "Kình Dương", "ฉิงหยาง"],
  ["陀罗", "Tuo Luo", "타라", "Đà La", "ถัวหลัว"], ["火星", "Huo Xing (Mars)", "화성", "Hỏa Tinh", "หั่วซิง (ดาวอังคาร)"], ["铃星", "Ling Xing", "영성", "Linh Tinh", "หลิงซิง"], ["地劫", "Di Jie", "지겁", "Địa Kiếp", "ตี้เจี๋ย"], ["地空", "Di Kong", "지공", "Địa Không", "ตี้คง"], ["天马", "Tian Ma", "천마", "Thiên Mã", "เทียนหม่า"],
  ["庙", "Temple", "묘", "Miếu", "วัด (แรงสุด)"], ["得", "Gain", "득", "Đắc", "ได้ที่"], ["利", "Favourable", "리", "Lợi", "เอื้อ"], ["平", "Neutral", "평", "Bình", "กลาง"], ["不", "Weak", "불", "Bất", "อ่อน"], ["陷", "Fallen", "함", "Hãm", "ตกต่ำ"],
  ["化禄", "Hua Lu", "화록", "Hóa Lộc", "ฮว่าลู่"], ["化权", "Hua Quan", "화권", "Hóa Quyền", "ฮว่าเฉวียน"], ["化科", "Hua Ke", "화과", "Hóa Khoa", "ฮว่าเคอ"], ["化忌", "Hua Ji", "화기", "Hóa Kỵ", "ฮว่าจี้"],
  ["命宫", "Life palace", "명궁", "Cung Mệnh", "วังชีวิต"], ["身宫", "Body palace", "신궁", "Cung Thân", "วังกาย"],
  ["水二局", "Water bureau 2", "수이국", "Thủy nhị cục", "ผังน้ำ 2"], ["木三局", "Wood bureau 3", "목삼국", "Mộc tam cục", "ผังไม้ 3"], ["金四局", "Metal bureau 4", "금사국", "Kim tứ cục", "ผังโลหะ 4"], ["土五局", "Earth bureau 5", "토오국", "Thổ ngũ cục", "ผังดิน 5"], ["火六局", "Fire bureau 6", "화육국", "Hỏa lục cục", "ผังไฟ 6"],
  ["顺行", "Forward", "순행", "Thuận hành", "เดินหน้า"], ["逆行", "Backward", "역행", "Nghịch hành", "ถอยหลัง"],
  // qimen
  ["天蓬", "Tian Peng", "천봉", "Thiên Bồng", "เทียนเผิง"], ["天芮", "Tian Rui", "천예", "Thiên Nhuế", "เทียนรุ่ย"], ["天冲", "Tian Chong", "천충", "Thiên Xung", "เทียนชง"], ["天辅", "Tian Fu (Assist)", "천보", "Thiên Phụ", "เทียนฝู่ (ช่วย)"], ["天禽", "Tian Qin", "천금", "Thiên Cầm", "เทียนฉิน"],
  ["天心", "Tian Xin", "천심", "Thiên Tâm", "เทียนซิน"], ["天柱", "Tian Zhu", "천주", "Thiên Trụ", "เทียนจู้"], ["天任", "Tian Ren", "천임", "Thiên Nhậm", "เทียนเริ่น"], ["天英", "Tian Ying", "천영", "Thiên Anh", "เทียนอิง"],
  ["休门", "Rest Gate", "휴문", "Hưu Môn", "ประตูพัก"], ["生门", "Life Gate", "생문", "Sinh Môn", "ประตูชีวิต"], ["伤门", "Harm Gate", "상문", "Thương Môn", "ประตูบาดเจ็บ"], ["杜门", "Block Gate", "두문", "Đỗ Môn", "ประตูปิดกั้น"],
  ["景门", "View Gate", "경문(경치)", "Cảnh Môn", "ประตูทัศน์"], ["死门", "Death Gate", "사문", "Tử Môn", "ประตูดับ"], ["惊门", "Shock Gate", "경문(놀람)", "Kinh Môn", "ประตูตื่นตระหนก"], ["开门", "Open Gate", "개문", "Khai Môn", "ประตูเปิด"],
  ["值符", "Chief", "직부", "Trực Phù", "จื๋อฝู"], ["九地", "Nine Earth", "구지", "Cửu Địa", "เก้าปฐพี"], ["九天", "Nine Heaven", "구천", "Cửu Thiên", "เก้าสวรรค์"],
  ["阳遁", "Yang Dun", "양둔", "Dương độn", "หยางตุ้น"], ["阴遁", "Yin Dun", "음둔", "Âm độn", "หยินตุ้น"], ["上元", "Upper cycle", "상원", "Thượng nguyên", "รอบบน"], ["中元", "Middle cycle", "중원", "Trung nguyên", "รอบกลาง"], ["下元", "Lower cycle", "하원", "Hạ nguyên", "รอบล่าง"],
  // liuren generals & methods
  ["贵人", "Noble", "귀인", "Quý Nhân", "ผู้สูงศักดิ์"], ["天空", "Heavenly Void", "천공", "Thiên Không", "ฟ้าว่าง"], ["太常", "Grand Constant", "태상", "Thái Thường", "ไท่ฉาง"], ["天后", "Heavenly Empress", "천후", "Thiên Hậu", "จักรพรรดินีฟ้า"],
  ["重审", "Chong Shen (lower overcomes upper)", "중심", "Trùng Thẩm", "ฉงเสิ่น"], ["元首", "Yuan Shou (upper overcomes lower)", "원수", "Nguyên Thủ", "หยวนโส่ว"], ["比用", "Bi Yong", "비용", "Tỷ Dụng", "ปี่ยง"], ["涉害", "She Hai", "섭해", "Thiệp Hại", "เซ่อไห่"],
  ["遥克", "Yao Ke (distant control)", "요극", "Dao Khắc", "เหยาเค่อ"], ["昴星", "Mao Xing", "묘성", "Mão Tinh", "เหม่าซิง"], ["伏吟", "Fu Yin", "복음", "Phục Ngâm", "ฝูอิ๋น"], ["返吟", "Fan Yin", "반음", "Phản Ngâm", "ฝ่านอิ๋น"],
  ["建", "Establish", "건", "Kiến", "ก่อตั้ง"], ["除", "Remove", "제", "Trừ", "ขจัด"], ["满", "Full", "만", "Mãn", "เต็ม"], ["定", "Settle", "정", "Định", "ตั้งมั่น"], ["执", "Hold", "집", "Chấp", "ยึด"], ["破", "Break", "파", "Phá", "แตก"],
  ["危", "Danger", "위", "Nguy", "เสี่ยง"], ["成", "Complete", "성", "Thành", "สำเร็จ"], ["收", "Gather", "수", "Thu", "เก็บ"], ["开", "Open", "개", "Khai", "เปิด"], ["闭", "Close", "폐", "Bế", "ปิด"], ["昼", "Day", "주", "Ngày", "กลางวัน"], ["夜", "Night", "야", "Đêm", "กลางคืน"],
  // qizheng
  ["水星", "Mercury", "수성", "Thủy Tinh", "ดาวพุธ"], ["金星", "Venus", "금성", "Kim Tinh", "ดาวศุกร์"], ["木星", "Jupiter", "목성", "Mộc Tinh", "ดาวพฤหัส"], ["土星", "Saturn", "토성", "Thổ Tinh", "ดาวเสาร์"],
  ["罗睺", "Luohou (descending node)", "나후", "La Hầu", "ราหู (จุดโหนดลง)"], ["计都", "Jidu (ascending node)", "계도", "Kế Đô", "เกตุ (จุดโหนดขึ้น)"], ["月孛", "Yuebei (lunar apogee)", "월패", "Nguyệt Bột", "จุดไกลโลกของดวงจันทร์"],
  ["玄枵", "Xuanxiao", "현효", "Huyền Hiêu", "เสวียนเซียว"], ["星纪", "Xingji", "성기", "Tinh Kỷ", "ซิงจี้"], ["析木", "Ximu", "석목", "Tích Mộc", "ซีมู่"], ["大火", "Dahuo", "대화", "Đại Hỏa", "ต้าหั่ว"], ["寿星", "Shouxing", "수성차", "Thọ Tinh", "โซ่วซิง"], ["鹑尾", "Chunwei", "순미", "Thuần Vĩ", "ฉุนเหว่ย"],
  ["鹑火", "Chunhuo", "순화", "Thuần Hỏa", "ฉุนหั่ว"], ["鹑首", "Chunshou", "순수", "Thuần Thủ", "ฉุนโส่ว"], ["实沈", "Shishen", "실침", "Thực Trầm", "สือเฉิน"], ["大梁", "Daliang", "대량", "Đại Lương", "ต้าเหลียง"], ["降娄", "Jianglou", "강루", "Giáng Lâu", "เจี้ยงโหลว"], ["娵訾", "Juzi", "추자", "Tưu Tư", "จวีจือ"],
  ["财帛", "Wealth", "재백", "Tài Bạch", "ทรัพย์"], ["田宅", "Property", "전택", "Điền Trạch", "ที่ดินบ้าน"], ["男女", "Children", "남녀", "Nam Nữ", "บุตร"], ["奴仆", "Helpers", "노복", "Nô Bộc", "ผู้ช่วย"], ["夫妻", "Partnership", "부처", "Phu Thê", "คู่ครอง"],
  ["疾厄", "Health", "질액", "Tật Ách", "สุขภาพ"], ["迁移", "Travel", "천이", "Thiên Di", "เดินทาง"], ["官禄", "Career", "관록", "Quan Lộc", "การงาน"], ["福德", "Fortune", "복덕", "Phúc Đức", "บุญวาสนา"], ["相貌", "Appearance", "상모", "Tướng Mạo", "รูปลักษณ์"],
  // 28 mansions
  ["角", "Horn", "각", "Giác", "เจี่ยว (เขา)"], ["亢", "Neck", "항", "Cang", "คั่ง (คอ)"], ["氐", "Root", "저", "Đê", "ตี (ราก)"], ["房", "Room", "방", "Phòng", "ฝาง (ห้อง)"], ["心", "Heart", "심", "Tâm", "ซิน (หัวใจ)"], ["尾", "Tail", "미", "Vĩ", "เหว่ย (หาง)"], ["箕", "Winnowing Basket", "기", "Cơ", "จี (กระด้ง)"],
  ["斗", "Dipper", "두", "Đẩu", "โต่ว (กระบวย)"], ["牛", "Ox", "우", "Ngưu", "หนิว (วัว)"], ["女", "Girl", "녀", "Nữ", "หนี่ว์ (หญิง)"], ["虚", "Emptiness", "허", "Hư", "ซวี (ว่าง)"], ["室", "Encampment", "실", "Thất", "ซื่อ (ห้อง)"], ["壁", "Wall", "벽", "Bích", "ปี้ (กำแพง)"],
  ["奎", "Legs", "규", "Khuê", "ขุย (ขา)"], ["娄", "Bond", "루", "Lâu", "โหลว (ผูก)"], ["胃", "Stomach", "위", "Vị", "เว่ย (กระเพาะ)"], ["昴", "Hairy Head", "묘", "Mão", "เหม่า (กลุ่มดาวลูกไก่)"], ["毕", "Net", "필", "Tất", "ปี้ (ตาข่าย)"], ["觜", "Turtle Beak", "자", "Chủy", "จือ (จะงอย)"], ["参", "Three Stars", "삼", "Sâm", "เซิน (สามดาว)"],
  ["井", "Well", "정", "Tỉnh", "จิ่ง (บ่อน้ำ)"], ["鬼", "Ghost", "귀", "Quỷ", "กุ่ย (ผี)"], ["柳", "Willow", "류", "Liễu", "หลิ่ว (หลิว)"], ["星", "Star", "성", "Tinh", "ซิง (ดาว)"], ["张", "Extended Net", "장", "Trương", "จาง (แผ่)"], ["翼", "Wings", "익", "Dực", "อี้ (ปีก)"], ["轸", "Chariot", "진", "Chẩn", "เจิ่น (รถ)"],
];

// Simplified → Traditional character map (only characters without ambiguity in chart text).
const S2T: Record<string, string> = {};
const S2T_PAIRS = "绿綠 黄黃 竖竪 殓殮 坟墳 厕廁 渔漁 蚁蟻 涂塗 饰飾 筑築 钻鑽 匮匱 佣傭 医醫 艺藝 碍礙 财財 伤傷 杀殺 贵貴 带帶 临臨 养養 绝絕 湿濕 热熱 凉涼 华華 盖蓋 将將 煞煞 鸾鸞 冲沖 会會 刑刑 无無 显顯 种種 满滿 处處 惊驚 兑兌 离離 孙孫 阳陽 阴陰 动動 静靜 宫宮 归歸 魂魂 游遊 机機 贞貞 贪貪 门門 军軍 辅輔 钺鉞 陀陀 罗羅 铃鈴 马馬 庙廟 权權 顺順 禄祿 局局 遁遁 执執 开開 闭閉 计計 孛孛 纪紀 寿壽 鹑鶉 实實 沈沈 娄婁 张張 轸軫 虚虛 毕畢 龙龍 勾勾 陈陳 员員 时時 岁歲 运運 纳納 长長 历曆 气氣 节節 关關 风風 泽澤 为為 讼訟 师師 随隨 蛊蠱 观觀 贲賁 剥剝 复復 颐頤 过過 晋晉 损損 渐漸 丰豐 涣渙 济濟 谦謙 应應 变變 盘盤 传傳 课課 间間 转轉 规規 则則 来來 从從 对對 点點 论論 宾賓 战戰 东東 东東 两兩 个個 们們 与與 业業 产產 亲親 仪儀 优優 伙夥 体體 侧側 储儲 关關 兴興 农農 冯馮 准準 刘劉 创創 别別 办辦 务務 劳勞 势勢 区區 协協 单單 卫衛 历歷 压壓 参參 双雙 发發 变變 叶葉 号號 叹嘆 后後 吗嗎 启啟 员員 响響 团團 园園 围圍 图圖 圆圓 场場 坏壞 块塊 坚堅 垒壘 声聲 处處 备備 头頭 夹夾 夺奪 奋奮 妇婦 妈媽 学學 宁寧 宝寶 实實 宽寬 审審 宪憲 对對 导導 寻尋 层層 岁歲 岛島 岭嶺 币幣 帅帥 师師 帐帳 带帶 帮幫 广廣 庄莊 库庫 应應 废廢 开開 异異 弃棄 张張 弯彎 弹彈 强強 归歸 录錄 彻徹 忆憶 忧憂 怀懷 态態 总總 恋戀 恶惡 悬懸 惊驚 惯慣 愿願 戏戲 战戰 户戶 扩擴 执執 扫掃 扬揚 护護 报報 担擔 拥擁 择擇 挂掛 挥揮 换換 据據 掷擲 摆擺 摄攝 数數 敌敵 断斷 无無 旧舊 时時 显顯 晓曉 术術 机機 杀殺 杂雜 权權 条條 来來 杨楊 极極 构構 标標 栏欄 树樹 样樣 桥橋 检檢 楼樓 欢歡 毕畢 气氣 汇匯 汉漢 汤湯 沟溝 没沒 泪淚 泽澤 洁潔 浅淺 测測 济濟 浓濃 涌湧 润潤 渐漸 温溫 湾灣 满滿 滞滯 灭滅 灵靈 灾災 炉爐 点點 烟煙 热熱 爱愛 牵牽 犹猶 状狀 独獨 猎獵 献獻 环環 现現 电電 画畫 畅暢 疗療 盐鹽 监監 盘盤 礼禮 祸禍 离離 种種 积積 称稱 稳穩 穷窮 竞競 笔筆 签簽 简簡 类類 粮糧 紧緊 纠糾 红紅 约約 级級 纪紀 纯純 纲綱 纳納 纵縱 纸紙 线線 练練 组組 细細 织織 终終 经經 结結 绕繞 绘繪 给給 络絡 统統 继繼 绩績 续續 维維 综綜 绿綠 缘緣 缺缺 网網 罗羅 职職 联聯 肃肅 胜勝 脑腦 脚腳 节節 苏蘇 范範 荣榮 药藥 获獲 营營 虑慮 虽雖 补補 装裝 见見 观觀 规規 视視 览覽 觉覺 计計 认認 让讓 训訓 议議 讯訊 记記 讲講 许許 论論 设設 访訪 证證 评評 识識 诉訴 词詞 译譯 试試 诗詩 话話 询詢 该該 详詳 语語 误誤 说說 请請 读讀 课課 谁誰 调調 谈談 谋謀 谢謝 谨謹 贝貝 负負 贡貢 财財 责責 贤賢 败敗 货貨 质質 贫貧 购購 贯貫 费費 贴貼 贸貿 资資 赏賞 赐賜 赞讚 赠贈 赢贏 赵趙 车車 轨軌 转轉 轮輪 软軟 轻輕 载載 较較 辈輩 辑輯 输輸 辩辯 边邊 达達 迁遷 过過 运運 还還 这這 进進 远遠 违違 连連 迟遲 适適 选選 递遞 逻邏 遗遺 邮郵 邻鄰 郑鄭 释釋 鉴鑑 针針 钟鐘 钱錢 铁鐵 银銀 链鏈 锁鎖 错錯 键鍵 镜鏡 长長 门門 闪閃 闭閉 问問 闲閒 间間 闻聞 阅閱 队隊 阶階 际際 陆陸 险險 随隨 隐隱 难難 雾霧 静靜 预預 领領 频頻 题題 颜顏 额額 风風 飞飛 饭飯 驱驅 验驗 鱼魚 鸟鳥 鸡雞 麦麥 齐齊 齿齒 龟龜 义義 乐樂 书書 习習 乡鄉 买買 乱亂 争爭 亏虧 云雲 亚亞 仅僅 从從 仓倉 价價 众眾 伟偉 传傳 伤傷 伦倫 侠俠 俭儉 债債 倾傾 偿償 兰蘭 关關 养養 兽獸 内內 冈岡 册冊 写寫 军軍 农農 冲衝 决決 况況 冻凍 净淨 凉涼 减減 凤鳳 凭憑 击擊 刚剛 则則 创創 删刪 剑劍 剧劇 劝勸 动動 励勵 劲勁 势勢 勋勳 匀勻 华華 协協 卖賣 卢盧 卧臥 厅廳 历歷 厉厲 县縣 叁參 台臺 叶葉 吓嚇 吕呂 吴吳 听聽 呜嗚 咏詠 员員 呐吶 哗嘩 唤喚 啬嗇 喷噴 嘱囑 圣聖 坛壇 坝壩 坠墜 垦墾 堕墮 墙牆 壮壯 壳殼 夸誇 奖獎 妆妝 娱娛 婴嬰 孙孫 宫宮 宾賓 尔爾 尘塵 尝嘗 尧堯 尸屍 尽盡 届屆 属屬 岂豈 峡峽 巩鞏 币幣 帘簾 ".split(" ");
for (const pair of S2T_PAIRS) if (pair.length === 2) S2T[pair[0]] = pair[1];
// Ambiguous characters handled only inside whole words (天干, 天后, 丑, 谷雨 …): never convert them alone.
for (const ambiguous of ["干", "后", "丑", "谷", "斗", "余", "里", "面", "只", "系", "发", "台", "云", "冲", "复", "历", "范"]) delete S2T[ambiguous];
const T_WORDS: Array<[string, string]> = [["理发", "理髮"], ["六冲", "六沖"], ["天冲", "天衝"], ["相冲", "相沖"], ["四余", "四餘"], ["复卦", "復卦"], ["地雷复", "地雷復"]];
// Japanese uses some shinjitai forms that differ from Traditional Chinese.
const JA_PAIRS = "藝芸 權権 氣気 關関 歸帰 應応 變変 傳伝 將将 驛駅 會会 實実 壽寿 擇択 對対 從従 來来 點点 濟済 豐豊 觀観 隨随 晉晋 惡悪 戰戦 數数 圖図 學学 擔担 輕軽 讀読 鐵鉄 錢銭 驗験 號号 續続 總総 樂楽 歲歳 齒歯 雙双 單単 處処 祿禄 澤沢 靜静 參参 黃黄 盡尽 營営 價価 縣県 鹽塩 狀状 獨独 圓円 舊旧 擊撃 劍剣 聽聴 稱称 藥薬 轉転 譯訳 讓譲 寫写 勸勧 勵励 縱縦 繼継 辯弁 邊辺 濕湿 絕絶 帶帯 沖冲 曆暦 歷歴 剝剥 盜盗 顯顕 圍囲 團団 廣広 莊荘 廢廃 彈弾 錄録 徵徴 懷懐 戲戯 擴拡 斷断 櫻桜 樣様 檢検 樓楼 歡歓 滿満 滯滞 靈霊 爐炉 爭争 犧犠 獻献 畫画 禮礼 稅税 穩穏 聲声 肅粛 腦脳 舉挙 虛虚 蟲虫 裝装 覺覚 覽覧 證証 譽誉 貓猫 賣売 贊賛 辦弁 遲遅 醫医 釋釈 險険 隱隠 雜雑 顏顔 驅駆 鬥闘 麥麦 齊斉 龜亀 殼殻 壯壮 獎奨 嚴厳 歐欧 囑嘱 兩両 亂乱 佛仏 假仮 儉倹 兒児 凜凛 勞労 區区 卻却 壓圧 壞壊 壘塁 奧奥 孃嬢 寶宝 專専 屆届 屬属 嶽岳 巖巌 幫幇 彥彦 徑径 恆恒 戀恋 拔抜 搖揺 敘叙 晝昼 曉暁 條条 榮栄 歎嘆 殘残 毆殴 淚涙 淨浄 淺浅 渴渇 溫温 灣湾 燈灯 爲為 牀床 狹狭 畵画 發発 盃杯 碎砕 祕秘 稻稲 窗窓 粹粋 經経 綠緑 緣縁 繪絵 纖繊 罐缶 聰聡 脫脱 臟臓 與与 舍舎 莖茎 萬万 衞衛 觸触 說説 謠謡 豬猪 貳弐 賴頼 踐践 辭辞 遞逓 鄉郷 醉酔 鋪舗 鎭鎮 鑄鋳 閱閲 隸隷 餘余 騷騒 髮髪 鬪闘 鹼鹸 黑黒 默黙 黨党 齋斎".split(" ");
const JA_OVERRIDES: Record<string, string> = Object.fromEntries(JA_PAIRS.map((pair) => [pair[0], pair[1]]));

function toTraditional(value: string) {
  let out = value;
  for (const [from, to] of T_WORDS) out = out.replaceAll(from, to);
  return [...out].map((char) => S2T[char] ?? char).join("");
}
function toJapanese(value: string) {
  return [...toTraditional(value)].map((char) => JA_OVERRIDES[char] ?? char).join("");
}

const DICTIONARY = new Map<string, Record<TermLocale, string>>();
function register(zh: string, en: string, ko: string, vi: string, th: string) {
  DICTIONARY.set(zh, { en, "zh-Hans": zh, "zh-Hant": toTraditional(zh), ja: toJapanese(zh), ko, vi, th });
}
for (const row of ALMANAC_ROWS) register(...row);
for (const row of ROWS) register(...row);
// The sixty stem-branch pairs as single terms (ko without an inner space: 갑술).
{
  const STEMS = "甲乙丙丁戊己庚辛壬癸";
  const BRANCHES = "子丑寅卯辰巳午未申酉戌亥";
  for (let i = 0; i < 60; i += 1) {
    const stem = DICTIONARY.get(STEMS[i % 10])!;
    const branch = DICTIONARY.get(BRANCHES[i % 12])!;
    register(`${STEMS[i % 10]}${BRANCHES[i % 12]}`, `${stem.en} ${branch.en}`, `${stem.ko}${branch.ko}`, `${stem.vi} ${branch.vi}`, `${stem.th}${branch.th}`);
  }
}
// Palace names with 宫 suffix for Zi Wei
const ZIWEI_PALACES: Array<[string, string, string, string, string]> = [
  ["兄弟宫", "Siblings palace", "형제궁", "Cung Huynh Đệ", "วังพี่น้อง"], ["夫妻宫", "Partnership palace", "부처궁", "Cung Phu Thê", "วังคู่ครอง"], ["子女宫", "Children palace", "자녀궁", "Cung Tử Tức", "วังบุตร"],
  ["财帛宫", "Wealth palace", "재백궁", "Cung Tài Bạch", "วังทรัพย์"], ["疾厄宫", "Health palace", "질액궁", "Cung Tật Ách", "วังสุขภาพ"], ["迁移宫", "Travel palace", "천이궁", "Cung Thiên Di", "วังเดินทาง"],
  ["交友宫", "Allies palace", "교우궁", "Cung Nô Bộc", "วังมิตรสหาย"], ["官禄宫", "Career palace", "관록궁", "Cung Quan Lộc", "วังการงาน"], ["田宅宫", "Property palace", "전택궁", "Cung Điền Trạch", "วังที่ดินบ้าน"],
  ["福德宫", "Fortune palace", "복덕궁", "Cung Phúc Đức", "วังบุญวาสนา"], ["父母宫", "Parents palace", "부모궁", "Cung Phụ Mẫu", "วังบิดามารดา"],
];
for (const row of ZIWEI_PALACES) register(...row);

// Qi Men bureau names (阳遁一局 … 阴遁九局)
const NUM_ZH = ["一", "二", "三", "四", "五", "六", "七", "八", "九"];
NUM_ZH.forEach((num, index) => {
  const n = index + 1;
  register(`阳遁${num}局`, `Yang Dun bureau ${n}`, `양둔 ${n}국`, `Dương độn cục ${n}`, `หยางตุ้น ผัง ${n}`);
  register(`阴遁${num}局`, `Yin Dun bureau ${n}`, `음둔 ${n}국`, `Âm độn cục ${n}`, `หยินตุ้น ผัง ${n}`);
});

// Hexagram names
const HEX_EN = ["Qian", "Kun", "Zhun", "Meng", "Xu", "Song", "Shi", "Bi", "Xiao Chu", "Lü", "Tai", "Pi", "Tong Ren", "Da You", "Qian (Modesty)", "Yu", "Sui", "Gu", "Lin", "Guan", "Shi He", "Bi (Grace)", "Bo", "Fu", "Wu Wang", "Da Chu", "Yi (Nourishing)", "Da Guo", "Kan", "Li", "Xian", "Heng", "Dun", "Da Zhuang", "Jin", "Ming Yi", "Jia Ren", "Kui", "Jian (Obstruction)", "Xie", "Sun", "Yi (Increase)", "Guai", "Gou", "Cui", "Sheng", "Kun (Exhaustion)", "Jing", "Ge", "Ding", "Zhen", "Gen", "Jian (Development)", "Gui Mei", "Feng", "Lü (Wanderer)", "Xun", "Dui", "Huan", "Jie", "Zhong Fu", "Xiao Guo", "Ji Ji", "Wei Ji"];
const HEX_KO = ["건", "곤", "둔", "몽", "수", "송", "사", "비", "소축", "리", "태", "비", "동인", "대유", "겸", "예", "수", "고", "림", "관", "서합", "비", "박", "복", "무망", "대축", "이", "대과", "감", "리", "함", "항", "둔", "대장", "진", "명이", "가인", "규", "건", "해", "손", "익", "쾌", "구", "췌", "승", "곤", "정", "혁", "정", "진", "간", "점", "귀매", "풍", "려", "손", "태", "환", "절", "중부", "소과", "기제", "미제"];
const HEX_VI = ["Càn", "Khôn", "Truân", "Mông", "Nhu", "Tụng", "Sư", "Tỷ", "Tiểu Súc", "Lý", "Thái", "Bĩ", "Đồng Nhân", "Đại Hữu", "Khiêm", "Dự", "Tùy", "Cổ", "Lâm", "Quan", "Phệ Hạp", "Bí", "Bác", "Phục", "Vô Vọng", "Đại Súc", "Di", "Đại Quá", "Khảm", "Ly", "Hàm", "Hằng", "Độn", "Đại Tráng", "Tấn", "Minh Di", "Gia Nhân", "Khuê", "Kiển", "Giải", "Tổn", "Ích", "Quải", "Cấu", "Tụy", "Thăng", "Khốn", "Tỉnh", "Cách", "Đỉnh", "Chấn", "Cấn", "Tiệm", "Quy Muội", "Phong", "Lữ", "Tốn", "Đoài", "Hoán", "Tiết", "Trung Phu", "Tiểu Quá", "Ký Tế", "Vị Tế"];
const TRI_TH: Record<string, string> = { 乾: "เฉียน", 兑: "ตุ้ย", 离: "หลี", 震: "เจิ้น", 巽: "ซวิ่น", 坎: "ข่าน", 艮: "เกิ้น", 坤: "คุน" };
for (const upper of TRIGRAMS) for (const lower of TRIGRAMS) {
  const name = hexagramName(lower, upper);
  const i = name.number - 1;
  const entry = { en: `Hexagram ${name.number} · ${HEX_EN[i]}`, ko: `${HEX_KO[i]}괘 (${name.number})`, vi: `Quẻ ${HEX_VI[i]} (${name.number})`, th: `เฮ็กซะแกรม ${name.number} (${TRI_TH[upper]}/${TRI_TH[lower]})` };
  register(name.full, entry.en, entry.ko, entry.vi, entry.th);
}

export function lookupChartTerm(value: string, locale: TermLocale) {
  return DICTIONARY.get(value)?.[locale];
}

const HAN = /[㐀-鿿]/;
const sortedKeys = () => [...DICTIONARY.keys()].sort((a, b) => b.length - a.length);
let keysCache: string[] | undefined;

/** Translate a free string made of known terms: whole match, whitespace tokens, then greedy segmentation. */
export function translateChartText(value: string, locale: TermLocale): string | undefined {
  if (!HAN.test(value)) return undefined;
  const whole = lookupChartTerm(value, locale);
  if (whole) return whole;
  if (locale === "zh-Hans") return value;
  if (locale === "zh-Hant") return toTraditional(value);
  if (locale === "ja") return toJapanese(value);
  if (/\s/.test(value.trim())) {
    return value.split(/(\s+)/).map((part) => (HAN.test(part) ? translateChartText(part, locale) ?? part : part)).join("");
  }
  keysCache ??= sortedKeys();
  const parts: string[] = [];
  let rest = value;
  while (rest.length) {
    const key = HAN.test(rest.charAt(0)) ? keysCache.find((candidate) => rest.startsWith(candidate)) : undefined;
    if (key) { parts.push(lookupChartTerm(key, locale)!); rest = rest.slice(key.length); continue; }
    const plain = rest.match(/^[^㐀-鿿]+/)?.[0];
    if (plain) { parts.push(plain.trim()); rest = rest.slice(plain.length); continue; }
    return undefined; // unknown Han character: let the caller fall back
  }
  return parts.filter(Boolean).join(" ");
}

export const convertToTraditional = toTraditional;
export const convertToJapanese = toJapanese;
