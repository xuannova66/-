"use client";
// Free daily share posters (1080 × 1920, drawn in the browser):
//   每日五行穿搭日签 — today's lucky colour for the reader's birth date, a 洪范 line, date, logo, QR code.
//   今日行动指南     — today's almanac 宜 / 忌 as modern actions, date, logo, QR code.
// The QR code carries the member's invite code when signed in, so every shared card can bring a friend.
import { useEffect, useMemo, useState } from "react";
import type { Locale } from "./site-content";
import { almanacDay, todayIso, type AlmanacDay } from "./almanac";
import { actionGuide } from "./almanac-actions";
import { colorFamily, dailyColor, solarBirthIso, elementNames, elementQuotes, fillText, quoteReading, reasonText, shades, type DailyColor } from "./daily-color";
import { fontFor, wrap } from "./share-card";
import { pathFor } from "./study-navigation";
import { track } from "./analytics";
import { InstallAppButton } from "./install-app";
import { countShare, type ShareSource } from "./share-stats-client";
import qrcodeFactory from "./vendor/qrcode";
import { canShareImages, cloud, corners, enso, goldFoil, inkBlot, isDark, mountains, paper, rgba, seal, seeded, shadeHex, sparkles, tickRing, watermark } from "./poster-art";

type QrCode = { addData: (data: string) => void; make: () => void; getModuleCount: () => number; isDark: (row: number, col: number) => boolean };
const qrcode = qrcodeFactory as unknown as (typeNumber: number, level: "L" | "M" | "Q" | "H") => QrCode;
type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });
const W = 1080, H = 1920;

export const posterText = {
  eyebrow: L("Today", "今日", "今日", "今日", "오늘", "Hôm nay", "วันนี้"),
  title: L("Invite good fortune today", "今日纳福，好运随身", "今日納福，好運隨身", "今日、福を招く", "오늘, 복을 부르세요", "Đón phúc hôm nay, may mắn theo bạn", "รับสิริมงคลวันนี้ โชคดีติดตัว"),
  lead: L("Free every day: your lucky colour and today's action guide, ready to save and share.", "每天免费：你的今日幸运色和今日行动指南，可保存、可分享。", "每天免費：你的今日幸運色和今日行動指南，可保存、可分享。", "毎日無料：今日のラッキーカラーと行動ガイド。保存もシェアもできます。", "매일 무료: 오늘의 행운 색과 행동 가이드, 저장·공유 가능.", "Miễn phí mỗi ngày: màu may mắn và hướng dẫn hành động hôm nay, lưu và chia sẻ được.", "ฟรีทุกวัน: สีมงคลและคู่มือวันนี้ บันทึกและแชร์ได้"),
  colorTitle: L("Daily five-element outfit", "每日五行穿搭", "每日五行穿搭", "毎日の五行コーデ", "매일 오행 코디", "Trang phục ngũ hành mỗi ngày", "แต่งตัวตามห้าธาตุประจำวัน"),
  colorLead: L("Enter your birth date to see today's lucky colour.", "输入生日，看看今天穿什么颜色最顺。", "輸入生日，看看今天穿什麼顏色最順。", "誕生日を入れて、今日のラッキーカラーを見る。", "생일을 입력하고 오늘의 행운 색을 확인하세요.", "Nhập ngày sinh để xem màu may mắn hôm nay.", "ใส่วันเกิดเพื่อดูสีมงคลวันนี้"),
  birth: L("Birth date", "出生日期", "出生日期", "生年月日", "생년월일", "Ngày sinh", "วันเกิด"),
  sharedBirth: L("Using the birth date saved on this site — change it here and it updates everywhere.", "已使用你在本站保存的生日，在这里修改会同步到全站。", "已使用你在本站儲存的生日，在這裡修改會同步到全站。", "このサイトに保存した生年月日を使っています。ここで変えると全体に反映されます。", "이 사이트에 저장한 생일을 사용해요. 여기서 바꾸면 전체에 반영돼요.", "Đang dùng ngày sinh bạn đã lưu trên trang — sửa ở đây sẽ cập nhật mọi nơi.", "ใช้วันเกิดที่บันทึกไว้ในเว็บนี้ แก้ที่นี่จะอัปเดตทุกที่"),
  check: L("See today's colour", "查看今日幸运色", "查看今日幸運色", "今日の色を見る", "오늘의 색 보기", "Xem màu hôm nay", "ดูสีวันนี้"),
  generate: L("Generate Daily Card", "生成专属日签", "產生專屬日籤", "日めくりカードを作る", "나만의 데일리 카드 만들기", "Tạo thiệp hằng ngày", "สร้างการ์ดประจำวัน"),
  lucky: L("Lucky Color", "今日幸运色", "今日幸運色", "ラッキーカラー", "행운의 색", "Màu may mắn", "สีมงคล"),
  alsoGood: L("Also good", "备选", "備選", "こちらも◎", "함께 좋은 색", "Cũng hợp", "สีเสริม"),
  avoid: L("Go easy on", "慎用", "慎用", "控えめに", "줄일 색", "Hạn chế", "ควรเลี่ยง"),
  wear: L("Wear it as a scarf, shirt or accessory — even a small touch counts.", "可用在外套、衬衫、围巾或配饰上，一点点也算。", "可用在外套、襯衫、圍巾或配飾上，一點點也算。", "上着やシャツ、スカーフ、小物に。少しでも効果あり。", "겉옷, 셔츠, 스카프나 액세서리에 — 조금만 더해도 좋아요.", "Dùng cho áo, khăn hay phụ kiện — một chút cũng đủ.", "ใช้กับเสื้อ ผ้าพันคอ หรือเครื่องประดับ แม้เพียงเล็กน้อยก็ได้"),
  basis: L("Your day master: {dm} · Today: {day}", "你的日主：{dm} · 今日：{day}", "你的日主：{dm} · 今日：{day}", "あなたの日主：{dm}・今日：{day}", "나의 일간: {dm} · 오늘: {day}", "Nhật chủ: {dm} · Hôm nay: {day}", "เจ้าชะตา: {dm} · วันนี้: {day}"),
  actionTitle: L("Today's Action Guide", "今日行动指南", "今日行動指南", "今日の行動ガイド", "오늘의 행동 가이드", "Hướng dẫn hành động hôm nay", "คู่มือการกระทำวันนี้"),
  actionLead: L("The almanac's 宜 / 忌, in modern words.", "黄历的宜与忌，用现代的话说。", "黃曆的宜與忌，用現代的話說。", "暦の「宜・忌」を現代の言葉で。", "역서의 의(宜)·기(忌)를 오늘의 말로.", "Nên / kiêng của lịch, bằng lời hiện đại.", "สิ่งควร/ไม่ควรจากปฏิทิน ในภาษาวันนี้"),
  suitable: L("Suitable for", "宜", "宜", "宜（よし）", "의(宜)", "Nên làm", "ควรทำ"),
  avoidFor: L("Avoid", "忌", "忌", "忌（いむ）", "기(忌)", "Nên tránh", "ควรเลี่ยง"),
  makeAction: L("Generate action card", "生成黄历海报", "產生黃曆海報", "行動ガイドカードを作る", "행동 가이드 카드 만들기", "Tạo thiệp hướng dẫn", "สร้างการ์ดคู่มือ"),
  making: L("Drawing…", "正在生成…", "正在產生…", "作成中…", "만드는 중…", "Đang tạo…", "กำลังสร้าง…"),
  save: L("Save image", "保存图片", "儲存圖片", "画像を保存", "이미지 저장", "Lưu ảnh", "บันทึกภาพ"),
  share: L("Share", "分享", "分享", "シェア", "공유", "Chia sẻ", "แชร์"),
  saveTip: L("On a phone, press and hold the image to save it to your photos.", "手机上可长按图片保存到相册。", "手機上可長按圖片儲存到相簿。", "スマホでは画像を長押しして写真に保存できます。", "휴대폰에서는 이미지를 길게 눌러 사진에 저장하세요.", "Trên điện thoại, nhấn giữ ảnh để lưu vào thư viện.", "บนมือถือ กดค้างที่ภาพเพื่อบันทึก"),
  close: L("Close", "关闭", "關閉", "閉じる", "닫기", "Đóng", "ปิด"),
  slogan: L("Discover your Eastern Wisdom", "发现你的东方智慧", "發現你的東方智慧", "あなたの東洋の知恵を見つけよう", "당신의 동양 지혜를 발견하세요", "Khám phá trí tuệ phương Đông của bạn", "ค้นพบปัญญาตะวันออกของคุณ"),
  scan: L("Scan for your own card", "扫码，生成你的专属日签", "掃碼，產生你的專屬日籤", "読み取って自分のカードを", "스캔해서 나만의 카드 받기", "Quét để có thiệp của bạn", "สแกนรับการ์ดของคุณ"),
};
const weekdays: Record<Locale, string[]> = {
  en: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], "zh-Hans": ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"], "zh-Hant": ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"],
  ja: ["日曜日", "月曜日", "火曜日", "水曜日", "木曜日", "金曜日", "土曜日"], ko: ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"], vi: ["Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"], th: ["วันอาทิตย์", "วันจันทร์", "วันอังคาร", "วันพุธ", "วันพฤหัสบดี", "วันศุกร์", "วันเสาร์"],
};
export const dateLine = (day: AlmanacDay, locale: Locale) => `${new Date(Date.UTC(day.year, day.month - 1, day.day)).toLocaleDateString(locale, { year: "numeric", month: "long", day: "numeric", timeZone: "UTC" })} · ${weekdays[locale][day.weekday]}`;
// Traditional-script locales get 農曆 / 閏 / 臘月 / 馬年 … (the lunar library returns simplified characters).
const TO_HANT: Record<string, string> = { 农: "農", 历: "曆", 闰: "閏", 腊: "臘", 龙: "龍", 马: "馬", 鸡: "雞", 猪: "豬", 签: "籤", 润: "潤", 穑: "穡", 从: "從" };
export const hant = (text: string, locale: Locale) => (locale === "zh-Hant" ? text.replace(/[农历闰腊龙马鸡猪签润穑从]/g, (ch) => TO_HANT[ch] ?? ch) : text);
export const lunarLine = (day: AlmanacDay, locale: Locale = "zh-Hans") => hant(`农历${day.lunarLeap ? "闰" : ""}${day.lunarMonthZh}月${day.lunarDayZh} · ${day.dayGanZhi}日`, locale);
const isHan = (locale: Locale) => locale === "zh-Hans" || locale === "zh-Hant" || locale === "ja";
const serif = '"Noto Serif SC", "Songti SC", Georgia, serif';

let logo: HTMLImageElement | null = null;
export const loadLogo = () => new Promise<HTMLImageElement | null>((resolve) => {
  if (logo?.complete) { resolve(logo); return; }
  const image = new Image(); image.onload = () => { logo = image; resolve(image); }; image.onerror = () => resolve(null); image.src = "/icon-192.png";
});

export function drawQr(ctx: CanvasRenderingContext2D, link: string, x: number, y: number, size: number, ink: string) {
  const qr = qrcode(0, "M"); qr.addData(link); qr.make();
  const count = qr.getModuleCount();
  ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.roundRect(x - 16, y - 16, size + 32, size + 32, 18); ctx.fill();
  const cell = size / count;
  ctx.fillStyle = ink;
  for (let r = 0; r < count; r += 1) for (let c = 0; c < count; c += 1) if (qr.isDark(r, c)) ctx.fillRect(Math.floor(x + c * cell), Math.floor(y + r * cell), Math.ceil(cell), Math.ceil(cell));
}

/** Footer shared by every poster: a light panel with logo, xuannova.com, slogan, scan line and QR code. */
export function drawFooter(ctx: CanvasRenderingContext2D, options: { locale: Locale; link: string; ink: string; soft: string; accent: string; icon: HTMLImageElement | null; panel?: string; scan?: string }) {
  const { locale, link, ink, soft, accent, icon } = options;
  const font = fontFor(locale);
  const top = H - 330;
  ctx.save();
  ctx.shadowColor = "rgba(40,25,10,.18)"; ctx.shadowBlur = 30; ctx.shadowOffsetY = 8;
  ctx.fillStyle = options.panel ?? "rgba(255,252,245,.82)"; ctx.beginPath(); ctx.roundRect(48, top - 56, W - 96, 360, 28); ctx.fill();
  ctx.restore();
  ctx.strokeStyle = goldFoil(ctx, 48, top - 56, W - 48, top + 304); ctx.lineWidth = 2.5; ctx.beginPath(); ctx.roundRect(48, top - 56, W - 96, 360, 28); ctx.stroke();
  if (icon) { ctx.save(); ctx.beginPath(); ctx.roundRect(80, top - 14, 92, 92, 20); ctx.clip(); ctx.drawImage(icon, 80, top - 14, 92, 92); ctx.restore(); }
  ctx.textAlign = "left";
  ctx.fillStyle = ink; ctx.font = `600 54px "Cormorant Garamond", Georgia, serif`; ctx.fillText("Xuannova", 194, top + 38);
  ctx.fillStyle = accent; ctx.font = `500 30px Georgia, serif`; ctx.fillText("xuannova.com", 194, top + 78);
  ctx.fillStyle = ink; ctx.font = `600 34px ${font}`;
  let y = top + 150;
  for (const line of wrap(ctx, posterText.slogan[locale], W - 520, locale, 2)) { ctx.fillText(line, 80, y); y += 44; }
  if (locale !== "en") { ctx.fillStyle = accent; ctx.font = `italic 400 28px Georgia, serif`; ctx.fillText(posterText.slogan.en, 80, y - 4); y += 40; }
  ctx.fillStyle = soft; ctx.font = `400 26px ${font}`;
  for (const line of wrap(ctx, options.scan ?? posterText.scan[locale], W - 520, locale, 2)) { ctx.fillText(line, 80, y + 4); y += 36; }
  drawQr(ctx, link, W - 100 - 210, top - 10, 210, "#1b1611");
}

const ELEMENT_CHAR: Record<string, string> = { wood: "木", fire: "火", earth: "土", metal: "金", water: "水" };

export async function drawColorPoster(canvas: HTMLCanvasElement, options: { locale: Locale; color: DailyColor; day: AlmanacDay; link: string }) {
  const { locale, color, day, link } = options;
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext("2d")!;
  const font = fontFor(locale);
  const icon = await loadLogo();
  const rand = seeded(`${day.iso}|${color.shade.hex}`);
  const hex = color.shade.hex;
  const ink = "#1f1b16", soft = "#6f665a", accent = "#94652f";
  // Rice paper tinted by the lucky colour, a giant element character, mountains in the colour.
  paper(ctx, W, H, "#f3ede0", hex, rand);
  watermark(ctx, ELEMENT_CHAR[color.lucky], W / 2, 640, 980, hex, 0.03);
  mountains(ctx, W, 1470, isDark(hex) ? hex : shadeHex(hex, -0.25), rand, 3);
  sparkles(ctx, W, 1000, 26, "#e8c77a", rand, 220);
  const foil = goldFoil(ctx, 0, 0, W, H);
  corners(ctx, 40, 40, W - 80, H - 80, 90, foil, 3);
  // Header
  ctx.textAlign = "center";
  ctx.fillStyle = accent; ctx.font = `600 30px ${font}`; ctx.fillText(`${posterText.colorTitle[locale]} · ${dateLine(day, locale)}`, W / 2, 128);
  ctx.fillStyle = soft; ctx.font = `400 26px ${serif}`; ctx.fillText(`${lunarLine(day, locale)} · 今日${elementNames[color.today]["zh-Hans"]}`, W / 2, 172);
  // The colour: an ink blot inside a gold ensō and a ring of 72 ticks.
  const cx = W / 2, cy = 610, r = 270;
  tickRing(ctx, cx, cy, 392, rgba("#b08a46", 0.55));
  inkBlot(ctx, cx, cy, r, hex, rand);
  enso(ctx, cx, cy, 340, foil, rand, 20);
  ctx.fillStyle = isDark(hex) ? "rgba(255,255,255,.85)" : "rgba(30,25,20,.7)"; ctx.font = `500 30px Georgia, serif`; ctx.fillText(hex.toUpperCase(), cx, cy + 190);
  ctx.font = `700 64px ${serif}`; ctx.fillText(ELEMENT_CHAR[color.lucky], cx, cy - 150);
  seal(ctx, cx + 300, cy - 290, 92, hant("日签", locale), rand);
  // Colour name, with a brush stroke behind it
  ctx.fillStyle = soft; ctx.font = `500 32px ${font}`; ctx.fillText(`— ${posterText.lucky[locale]} —`, W / 2, 1050);
  const name = isHan(locale) ? color.shade.name[locale] : `${color.shade.name[locale]} (${color.shade.zh})`;
  ctx.font = `700 ${name.length > 18 ? 68 : 92}px ${isHan(locale) ? serif : font}`;
  const nameWidth = Math.min(W - 160, ctx.measureText(name).width);
  const stroke = ctx.createLinearGradient(W / 2 - nameWidth / 2 - 40, 0, W / 2 + nameWidth / 2 + 40, 0);
  stroke.addColorStop(0, rgba(hex, 0)); stroke.addColorStop(0.12, rgba(hex, 0.32)); stroke.addColorStop(0.85, rgba(hex, 0.28)); stroke.addColorStop(1, rgba(hex, 0));
  ctx.fillStyle = stroke; ctx.beginPath(); ctx.ellipse(W / 2, 1128, nameWidth / 2 + 50, 26, -0.02, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = ink;
  wrap(ctx, name, W - 160, locale, 2).forEach((line, index) => ctx.fillText(line, W / 2, 1150 + index * 90));
  if (isHan(locale)) { ctx.fillStyle = accent; ctx.font = `italic 400 34px Georgia, serif`; ctx.fillText(`Lucky Color: ${color.shade.name.en}`, W / 2, 1210); }
  // Also good · go easy on, with little swatches
  const metaY = isHan(locale) ? 1264 : 1226;
  // "Also good: Moon White ●   Go easy on: yellows and browns (Earth) ●●●"
  const good = `${posterText.alsoGood[locale]}: ${color.second.name[locale]}`;
  const avoid = `${posterText.avoid[locale]}: ${colorFamily[color.avoid][locale]}（${elementNames[color.avoid][locale]}）`.replace("（", isHan(locale) ? "（" : " (").replace("）", isHan(locale) ? "）" : ")");
  ctx.font = `400 28px ${font}`;
  const dot = 13, gap = 10, sep = 46;
  const goodW = ctx.measureText(good).width, avoidW = ctx.measureText(avoid).width;
  const total = dot * 2 + gap + goodW + sep + avoidW + gap + dot * 2 * 3 + 6 * 2;
  const oneLine = total < W - 120;
  const swatch = (x: number, y: number, hex: string) => { ctx.fillStyle = hex; ctx.beginPath(); ctx.arc(x, y, dot, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = "rgba(0,0,0,.18)"; ctx.lineWidth = 1.2; ctx.stroke(); };
  const drawGood = (x: number, y: number) => { swatch(x + dot, y - 9, color.second.hex); ctx.fillStyle = soft; ctx.textAlign = "left"; ctx.fillText(good, x + dot * 2 + gap, y); };
  const drawAvoid = (x: number, y: number) => {
    ctx.fillStyle = soft; ctx.textAlign = "left"; ctx.fillText(avoid, x, y);
    shades[color.avoid].forEach((shadeItem, index) => swatch(x + avoidW + gap + dot + index * (dot * 2 + 6), y - 9, shadeItem.hex));
  };
  if (oneLine) { const x0 = W / 2 - total / 2; drawGood(x0, metaY); drawAvoid(x0 + dot * 2 + gap + goodW + sep, metaY); }
  else {
    const goodTotal = dot * 2 + gap + goodW, avoidTotal = avoidW + gap + dot * 2 * 3 + 12;
    drawGood(W / 2 - goodTotal / 2, metaY - 20); drawAvoid(W / 2 - avoidTotal / 2, metaY + 22);
  }
  ctx.textAlign = "center";
  // Quote between two gold rules with a diamond
  const ruleY = metaY + (oneLine ? 46 : 70);
  ctx.strokeStyle = foil; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(W / 2 - 300, ruleY); ctx.lineTo(W / 2 - 20, ruleY); ctx.moveTo(W / 2 + 20, ruleY); ctx.lineTo(W / 2 + 300, ruleY); ctx.stroke();
  ctx.fillStyle = foil; ctx.beginPath(); ctx.moveTo(W / 2, ruleY - 9); ctx.lineTo(W / 2 + 9, ruleY); ctx.lineTo(W / 2, ruleY + 9); ctx.lineTo(W / 2 - 9, ruleY); ctx.fill();
  const quote = elementQuotes[color.lucky];
  ctx.fillStyle = foil; ctx.font = `700 60px ${serif}`; ctx.fillText(`「${hant(quote.zh, locale)}」`, W / 2, ruleY + 84);
  ctx.fillStyle = ink; ctx.font = `400 32px ${font}`;
  let qy = ruleY + 138;
  for (const line of wrap(ctx, quoteReading(color.lucky, locale), W - 200, locale, 2)) { ctx.fillText(line, W / 2, qy); qy += 42; }
  ctx.fillStyle = soft;
  if (locale.startsWith("zh")) { ctx.font = `italic 400 27px Georgia, serif`; for (const line of wrap(ctx, quote.reading.en, W - 220, "en", 2)) { ctx.fillText(line, W / 2, qy + 2); qy += 36; } }
  else { ctx.font = `400 26px ${serif}`; ctx.fillText(quoteReading(color.lucky, "zh-Hans"), W / 2, qy + 4); }
  drawFooter(ctx, { locale, link, ink, soft, accent, icon });
}

export async function drawActionPoster(canvas: HTMLCanvasElement, options: { locale: Locale; day: AlmanacDay; link: string }) {
  const { locale, day, link } = options;
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext("2d")!;
  const font = fontFor(locale);
  const icon = await loadLogo();
  const rand = seeded(`action|${day.iso}`);
  const ink = "#1f1b16", soft = "#6f665a", cinnabar = "#b5442e", jade = "#2f7a5c";
  // Deep cinnabar ground with gold clouds and dust.
  const bg = ctx.createLinearGradient(0, 0, W * 0.4, H);
  bg.addColorStop(0, "#5c140f"); bg.addColorStop(0.5, "#8e2a1d"); bg.addColorStop(1, "#4a100c");
  ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
  const glow = ctx.createRadialGradient(W / 2, 520, 50, W / 2, 520, 900); glow.addColorStop(0, "rgba(255,190,110,.28)"); glow.addColorStop(1, "rgba(255,190,110,0)");
  ctx.fillStyle = glow; ctx.fillRect(0, 0, W, H);
  const foil = goldFoil(ctx, 0, 0, W, H);
  ctx.globalAlpha = 0.45;
  cloud(ctx, 40, 80, 1.3, foil); cloud(ctx, W - 40, 150, 1.1, foil, true); cloud(ctx, 20, 1500, 1.0, foil); cloud(ctx, W - 30, 1440, 1.25, foil, true);
  ctx.globalAlpha = 1;
  sparkles(ctx, W, H, 60, "#f2cf86", rand);
  // Calendar card on cream paper, with binding rings, a gold double frame and a cinnabar header.
  const x = 96, y = 150, w = W - 192, h = 1290;
  ctx.save(); ctx.shadowColor = "rgba(0,0,0,.45)"; ctx.shadowBlur = 50; ctx.shadowOffsetY = 18;
  ctx.fillStyle = "#fbf6ea"; ctx.beginPath(); ctx.roundRect(x, y, w, h, 26); ctx.fill(); ctx.restore();
  ctx.save(); ctx.beginPath(); ctx.roundRect(x, y, w, h, 26); ctx.clip();
  paper(ctx, W, H, "#fbf6ea", "#d9b26a", rand);
  ctx.fillStyle = cinnabar; ctx.fillRect(x, y, w, 190);
  const band = ctx.createLinearGradient(0, y, 0, y + 190); band.addColorStop(0, "rgba(255,255,255,.12)"); band.addColorStop(1, "rgba(0,0,0,.18)");
  ctx.fillStyle = band; ctx.fillRect(x, y, w, 190);
  ctx.globalAlpha = 0.35; cloud(ctx, x + 30, y + 120, 0.9, foil); cloud(ctx, x + w - 30, y + 110, 0.9, foil, true); ctx.globalAlpha = 1;
  watermark(ctx, "宜", W / 2, y + 840, 760, cinnabar, 0.03);
  ctx.restore();
  ctx.strokeStyle = foil; ctx.lineWidth = 4; ctx.beginPath(); ctx.roundRect(x, y, w, h, 26); ctx.stroke();
  ctx.lineWidth = 1.5; ctx.beginPath(); ctx.roundRect(x + 16, y + 206, w - 32, h - 222, 16); ctx.stroke();
  corners(ctx, x + 30, y + 220, w - 60, h - 250, 46, foil, 2);
  for (const rx of [x + 160, x + w - 160]) { // binding rings
    ctx.fillStyle = "#3a0d09"; ctx.beginPath(); ctx.arc(rx, y + 22, 14, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = foil; ctx.lineWidth = 9; ctx.beginPath(); ctx.ellipse(rx, y - 6, 18, 34, 0, Math.PI * 0.95, Math.PI * 2.05); ctx.stroke();
  }
  ctx.textAlign = "center";
  ctx.fillStyle = foil; ctx.font = `700 50px ${isHan(locale) ? serif : font}`; ctx.fillText(posterText.actionTitle[locale], W / 2, y + 102);
  ctx.fillStyle = "rgba(255,236,200,.85)"; ctx.font = `italic 400 28px Georgia, serif`; ctx.fillText(locale === "en" ? "宜 · 忌 · in modern words" : "Today's Action Guide", W / 2, y + 152);
  // Day number in gold foil with a seal of the day's 干支
  ctx.fillStyle = goldFoil(ctx, W / 2 - 150, y + 260, W / 2 + 150, y + 470); ctx.font = `700 240px ${serif}`; ctx.fillText(String(day.day), W / 2, y + 470);
  seal(ctx, W / 2 + 200, y + 330, 88, day.dayGanZhi, rand);
  ctx.fillStyle = ink; ctx.font = `500 34px ${font}`; ctx.fillText(dateLine(day, locale), W / 2, y + 540);
  ctx.fillStyle = soft; ctx.font = `400 28px ${serif}`; ctx.fillText(`${lunarLine(day, locale)} · ${hant(day.zodiac, locale)}年`, W / 2, y + 588);
  ctx.strokeStyle = foil; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x + 120, y + 630); ctx.lineTo(x + w - 120, y + 630); ctx.stroke();
  const guide = actionGuide(day, locale);
  // The badge always carries the classical 宜 / 忌; other languages get their own word above the list.
  const block = (glyph: string, label: string, items: string[], top: number, colour: string) => {
    const bx = x + 116, by = top - 14;
    const badge = ctx.createRadialGradient(bx - 14, by - 14, 4, bx, by, 52); badge.addColorStop(0, shadeHex(colour, 0.25)); badge.addColorStop(1, colour);
    ctx.fillStyle = badge; ctx.beginPath(); ctx.arc(bx, by, 50, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = foil; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(bx, by, 58, 0, Math.PI * 2); ctx.stroke();
    ctx.fillStyle = "#fff8ea"; ctx.textAlign = "center"; ctx.font = `700 50px ${serif}`; ctx.fillText(glyph, bx, by + 18);
    ctx.textAlign = "left";
    let lineTop = top;
    if (!isHan(locale)) { ctx.fillStyle = colour; ctx.font = `700 28px ${font}`; ctx.fillText(label.toUpperCase(), x + 200, top - 36); lineTop = top + 14; }
    ctx.font = `500 40px ${font}`;
    let line = 0;
    for (const item of items) wrap(ctx, item, w - 300, locale, 2).forEach((text, index) => {
      const ly = lineTop + line * 58;
      if (index === 0) { ctx.fillStyle = colour; ctx.beginPath(); ctx.moveTo(x + 206, ly - 22); ctx.lineTo(x + 214, ly - 14); ctx.lineTo(x + 206, ly - 6); ctx.lineTo(x + 198, ly - 14); ctx.fill(); }
      ctx.fillStyle = ink; ctx.fillText(text, x + 230, ly); line += 1;
    });
    return line;
  };
  const used = block("宜", posterText.suitable[locale], guide.suitable, y + 740, jade);
  block("忌", posterText.avoidFor[locale], guide.avoid, y + 780 + Math.max(3, used) * 58 + 40, cinnabar);
  ctx.textAlign = "center";
  drawFooter(ctx, { locale, link, ink, soft, accent: "#94652f", icon, panel: "rgba(251,246,234,.96)" });
}

/** Full link to a page of the site, tagged with the share source and the member's invite code. */
export async function invitedUrl(path: string, source: string) {
  const code = await inviteCode();
  const params = new URLSearchParams({ utm_source: source });
  if (code) params.set("invite", code);
  return `https://xuannova.com${path}?${params.toString()}`;
}

/** The member's invite code, for the QR link (null when signed out). */
async function inviteCode() {
  try { const response = await fetch("/api/member/me?soft=1", { credentials: "same-origin" }); const data = await response.json() as { member?: { inviteCode?: string | null } | null }; return data.member?.inviteCode ?? null; } catch { return null; }
}
export async function shareLink(locale: Locale, source: string) {
  const code = await inviteCode();
  const params = new URLSearchParams({ utm_source: source });
  if (code) params.set("invite", code);
  return `https://xuannova.com${pathFor(locale, "home")}?${params.toString()}`;
}

/** Poster preview with Save / Share. */
export function PosterPreview({ locale, image, onClose, name, source }: { locale: Locale; image: { url: string; blob: Blob }; onClose: () => void; name: string; source: ShareSource }) {
  const t = posterText;
  const share = async () => {
    const file = new File([image.blob], name, { type: "image/png" });
    const nav = navigator as Navigator & { canShare?: (data: { files: File[] }) => boolean };
    if (nav.canShare?.({ files: [file] })) { try { await nav.share({ files: [file], title: "Xuannova" }); track("share", { method: "native", tool: name }); countShare(source, "shared"); } catch { /* cancelled */ } }
  };
  return <div className="poster-overlay" role="presentation" onClick={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <button type="button" className="overlay-close" onClick={onClose} aria-label={t.close[locale]}>×</button>
    <figure className="poster-dialog" role="dialog" aria-modal="true">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={image.url} alt={name} />
      <figcaption>
        <a className="primary-action" href={image.url} download={name} onClick={() => { track("share", { method: "download", tool: name }); countShare(source, "saved"); }}>{t.save[locale]}<b>↓</b></a>
        {canShareImages() && <button type="button" className="secondary-action" onClick={() => void share()}>{t.share[locale]}</button>}
        <button type="button" className="text-action" onClick={onClose}>{t.close[locale]}</button>
        <small>{t.saveTip[locale]}</small>
      </figcaption>
    </figure>
  </div>;
}

export function usePoster() {
  const [image, setImage] = useState<{ url: string; blob: Blob } | null>(null);
  const [busy, setBusy] = useState(false);
  const make = async (draw: (canvas: HTMLCanvasElement) => Promise<void>, source?: ShareSource) => {
    setBusy(true);
    try {
      await document.fonts?.ready;
      const canvas = document.createElement("canvas");
      await draw(canvas);
      const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/png"));
      if (blob) { setImage((previous) => { if (previous) URL.revokeObjectURL(previous.url); return { url: URL.createObjectURL(blob), blob }; }); if (source) countShare(source, "made"); }
    } finally { setBusy(false); }
  };
  return { image, busy, make, clear: () => setImage((previous) => { if (previous) URL.revokeObjectURL(previous.url); return null; }) };
}

const birthKey = "xn.daily.birth";

/** Home: today's lucky colour (needs a birth date) and today's action guide, each with a share poster. */
/** Home: today's lucky colour and today's action guide. The birth date is the site's one shared profile date
 *  (the same one the chart forms use); changing it here changes it everywhere. */
export function DailyCards({ locale, profileBirth, onBirth }: { locale: Locale; profileBirth?: string | null; onBirth?: (solarIso: string) => void }) {
  const t = posterText;
  const today = useMemo(() => todayIso(), []);
  const day = useMemo(() => almanacDay(today), [today]);
  const guide = useMemo(() => actionGuide(day, locale), [day, locale]);
  const [birth, setBirth] = useState("");
  const [result, setResult] = useState<DailyColor | null>(null);
  const colorPoster = usePoster(), actionPoster = usePoster();
  useEffect(() => {
    if (profileBirth) { setBirth(profileBirth); return; }
    // Older visits kept the date only here: hand it to the shared profile once.
    try { const old = window.localStorage.getItem(birthKey); if (old && /^\d{4}-\d{2}-\d{2}$/.test(old)) { setBirth(old); onBirth?.(old); } } catch { /* storage unavailable */ }
  }, [profileBirth]); // eslint-disable-line react-hooks/exhaustive-deps
  const check = () => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(birth)) return;
    if (birth !== profileBirth) onBirth?.(birth);
    setResult(dailyColor(birth, today));
    track("daily_color", {});
  };
  return <section className="daily-cards" id="today" aria-labelledby="daily-cards-title">
    <header><p>{t.eyebrow[locale]} · {dateLine(day, locale)}</p><h2 id="daily-cards-title">{t.title[locale]}</h2><span>{t.lead[locale]}</span></header>
    <div className="daily-cards-grid">
      <article className="daily-card is-color">
        <h3>{t.colorTitle[locale]}</h3>
        <p>{t.colorLead[locale]}</p>
        <form onSubmit={(event) => { event.preventDefault(); check(); }}>
          <label><span>{t.birth[locale]}</span><input type="date" value={birth} max={today} onChange={(event) => setBirth(event.target.value)} required /></label>
          <button type="submit" className="primary-action">{t.check[locale]}<b>→</b></button>
        </form>
        {profileBirth && birth === profileBirth && <small className="daily-shared-birth">{t.sharedBirth[locale]}</small>}
        <div className="daily-swatches" aria-hidden="true">{(["wood", "fire", "earth", "metal", "water"] as const).map((element) => <i key={element} style={{ background: shades[element][0].hex }} />)}</div>
      </article>
      <article className="daily-card is-action">
        <h3>{t.actionTitle[locale]}</h3>
        <p>{t.actionLead[locale]}</p>
        <dl>
          <div><dt className="is-yes">{t.suitable[locale]}</dt><dd>{guide.suitable.join(" · ")}</dd></div>
          <div><dt className="is-no">{t.avoidFor[locale]}</dt><dd>{guide.avoid.join(" · ")}</dd></div>
        </dl>
        <button type="button" className="secondary-action" disabled={actionPoster.busy} onClick={() => void actionPoster.make(async (canvas) => { await drawActionPoster(canvas, { locale, day, link: await shareLink(locale, "action-card") }); track("action_card", {}); }, "action-card")}>{actionPoster.busy ? t.making[locale] : t.makeAction[locale]}<b>↗</b></button>
      </article>
    </div>
    <InstallAppButton locale={locale} />
    {result && !colorPoster.image && <div className="poster-overlay" role="presentation" onClick={(event) => { if (event.target === event.currentTarget) setResult(null); }}>
      <div className="daily-result" role="dialog" aria-modal="true" aria-label={t.colorTitle[locale]}>
        <button type="button" className="sample-close" onClick={() => setResult(null)} aria-label={t.close[locale]}>×</button>
        <small>{t.lucky[locale]} · {dateLine(day, locale)}</small>
        <div className="daily-result-swatch" style={{ background: result.shade.hex }}><span>{result.shade.hex.toUpperCase()}</span></div>
        <h3>{isHan(locale) ? result.shade.name[locale] : `${result.shade.name[locale]} (${result.shade.zh})`}</h3>
        <p>{fillText(reasonText[result.reason][locale], { color: result.shade.name[locale], element: elementNames[result.lucky][locale], dm: `${result.dayMasterStem}${elementNames[result.dayMaster][locale]}` })}</p>
        <p className="daily-result-meta">{t.alsoGood[locale]}: <i style={{ background: result.second.hex }} /> {result.second.name[locale]}</p>
        <p className="daily-result-meta">{t.avoid[locale]}: {colorFamily[result.avoid][locale]}{isHan(locale) ? `（${elementNames[result.avoid][locale]}）` : ` (${elementNames[result.avoid][locale]})`} {shades[result.avoid].map((shadeItem) => <i key={shadeItem.hex} title={shadeItem.name[locale]} style={{ background: shadeItem.hex }} />)}</p>
        <blockquote>「{hant(elementQuotes[result.lucky].zh, locale)}」<span>{quoteReading(result.lucky, locale)}</span></blockquote>
        <p className="daily-result-meta">{t.wear[locale]}</p>
        <p className="daily-result-meta">{fillText(t.basis[locale], { dm: `${result.dayMasterStem}${elementNames[result.dayMaster][locale]}`, day: `${result.todayGanZhi} · ${elementNames[result.today][locale]}` })}</p>
        <button type="button" className="primary-action daily-generate" disabled={colorPoster.busy} onClick={() => void colorPoster.make(async (canvas) => { await drawColorPoster(canvas, { locale, color: result, day, link: await shareLink(locale, "daily-card") }); track("daily_card", { color: result.shade.zh }); }, "daily-card")}>{colorPoster.busy ? t.making[locale] : `✦ ${t.generate[locale]}`}<b>↗</b></button>
      </div>
    </div>}
    {colorPoster.image && <PosterPreview locale={locale} image={colorPoster.image} name="xuannova-daily-card.png" source="daily-card" onClose={() => { colorPoster.clear(); }} />}
    {actionPoster.image && <PosterPreview locale={locale} image={actionPoster.image} name="xuannova-action-guide.png" source="action-card" onClose={actionPoster.clear} />}
  </section>;
}

/** Almanac page: a poster for the chosen day. */
export function ActionPosterButton({ locale, iso }: { locale: Locale; iso: string }) {
  const poster = usePoster();
  return <>
    <button type="button" className="secondary-action" disabled={poster.busy} onClick={() => void poster.make(async (canvas) => { await drawActionPoster(canvas, { locale, day: almanacDay(iso), link: await shareLink(locale, "almanac-card") }); track("action_card", { from: "almanac" }); }, "almanac-card")}>{poster.busy ? posterText.making[locale] : posterText.makeAction[locale]}<b>↗</b></button>
    {poster.image && <PosterPreview locale={locale} image={poster.image} name={`xuannova-${iso}.png`} source="almanac-card" onClose={poster.clear} />}
  </>;
}
