// Birth-time honesty: an "unknown birth time" option, the example birthday marked as an example, and the wording
// used wherever the site talks about birth time and true solar time. Shared by the forms, the chart page and the
// chart model so all of them say the same thing.
import type { Locale } from "./site-content";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

/** The example birthday the forms start with. */
export const EXAMPLE_BIRTH = { date: "1994-08-18", time: "12:00" } as const;

/** Methods whose core depends on the hour: without a birth time they cannot be calculated honestly. */
export const HOUR_REQUIRED_ROUTES = new Set(["ziwei", "qizheng", "tieban", "heluo"]);

export const birthTimeText = {
  unknown: L("Birth time unknown", "出生时间不详", "出生時間不詳", "出生時刻が不明", "출생 시간 모름", "Không rõ giờ sinh", "ไม่ทราบเวลาเกิด"),
  hint: L(
    "The birth time sets the hour pillar. If you don't know it, tick “Birth time unknown”: the hour pillar is left out and readings that depend on it are limited. You can also estimate it with the Birth-hour finder (an estimate, not a certainty).",
    "出生时间用来计算时柱。不知道就勾选「出生时间不详」：不计算时柱，与时柱有关的解读会受限。也可以用「寻时定盘」推测时辰（只是推测，存在不确定性）。",
    "出生時間用來計算時柱。不知道就勾選「出生時間不詳」：不計算時柱，與時柱有關的解讀會受限。也可以用「尋時定盤」推測時辰（只是推測，存在不確定性）。",
    "出生時刻は時柱の計算に使います。分からない場合は「出生時刻が不明」にチェック：時柱は計算せず、時柱に関わる解読は限定されます。「生まれ時刻の確認」で推定することもできます（推定であり、不確かさがあります）。",
    "출생 시간은 시주 계산에 쓰입니다. 모르면 '출생 시간 모름'에 체크하세요. 시주는 계산하지 않고 시주와 관련된 해석은 제한됩니다. '출생 시각 찾기'로 추정할 수도 있어요(추정일 뿐 불확실합니다).",
    "Giờ sinh dùng để tính trụ giờ. Nếu không biết, hãy chọn “Không rõ giờ sinh”: không tính trụ giờ, phần luận giải liên quan sẽ bị hạn chế. Bạn cũng có thể ước đoán bằng “Tìm giờ sinh” (chỉ là ước đoán, không chắc chắn).",
    "เวลาเกิดใช้คำนวณเสายาม หากไม่ทราบให้เลือก “ไม่ทราบเวลาเกิด” ระบบจะไม่คำนวณเสายาม และการตีความที่เกี่ยวข้องจะจำกัด หรือใช้ “หาเวลาเกิด” เพื่อประมาณ (เป็นการประมาณ ไม่แน่นอน)",
  ),
  unknownOn: L(
    "Hour pillar not calculated. Year, month and day pillars are used; anything that depends on the hour (hour pillar, children and later years in classical readings) is limited.",
    "不计算时柱。只用年、月、日三柱；凡依赖时辰的内容（时柱、传统上看子女与晚年的部分）都会受限。",
    "不計算時柱。只用年、月、日三柱；凡依賴時辰的內容（時柱、傳統上看子女與晚年的部分）都會受限。",
    "時柱は計算しません。年・月・日の三柱のみを使い、時刻に依存する内容（時柱、伝統的に子女や晩年を見る部分）は限定されます。",
    "시주는 계산하지 않습니다. 연·월·일 세 기둥만 쓰며, 시간에 따른 내용(시주, 전통적으로 자녀와 말년을 보는 부분)은 제한됩니다.",
    "Không tính trụ giờ. Chỉ dùng trụ năm, tháng, ngày; mọi phần phụ thuộc giờ sinh (trụ giờ, con cái và hậu vận theo truyền thống) đều bị hạn chế.",
    "ไม่คำนวณเสายาม ใช้เพียงเสาปี เดือน วัน ส่วนที่ขึ้นกับเวลาเกิด (เสายาม เรื่องบุตรและวัยปลายตามตำรา) จะจำกัด",
  ),
  required: L(
    "This method is built on the birth hour, so it needs a birth time. If you don't know it, try the Birth-hour finder first (an estimate) or choose BaZi, which works without the hour.",
    "这门研习以出生时辰为核心，必须填写出生时间。不知道的话，可先用「寻时定盘」推测（仅供参考），或改用不需要时辰的八字排盘。",
    "這門研習以出生時辰為核心，必須填寫出生時間。不知道的話，可先用「尋時定盤」推測（僅供參考），或改用不需要時辰的八字排盤。",
    "この方法は出生時刻が中心のため、出生時刻が必要です。分からない場合はまず「生まれ時刻の確認」で推定するか（参考程度）、時刻なしでも使える八字をお選びください。",
    "이 공부는 출생 시각이 핵심이라 출생 시간이 꼭 필요합니다. 모르면 먼저 '출생 시각 찾기'로 추정하거나(참고용), 시간 없이도 되는 사주를 선택하세요.",
    "Phương pháp này dựa vào giờ sinh nên cần giờ sinh. Nếu không biết, hãy thử “Tìm giờ sinh” (chỉ ước đoán) hoặc chọn Bát Tự, không cần giờ.",
    "ศาสตร์นี้อาศัยเวลาเกิดเป็นหลัก จึงต้องมีเวลาเกิด หากไม่ทราบ ลองใช้ “หาเวลาเกิด” ก่อน (เป็นการประมาณ) หรือเลือกปาจื้อที่ไม่ต้องใช้เวลา"),
  finder: L("Estimate with the Birth-hour finder", "用「寻时定盘」推测时辰", "用「尋時定盤」推測時辰", "「生まれ時刻の確認」で推定する", "'출생 시각 찾기'로 추정하기", "Ước đoán bằng “Tìm giờ sinh”", "ประมาณด้วย “หาเวลาเกิด”"),
  example: L("Example", "示例", "示例", "例", "예시", "Ví dụ", "ตัวอย่าง"),
  exampleNote: L(
    "This is an example birthday (18 Aug 1994, 12:00). Change it to your own birth details, or try the example first to see what a chart looks like.",
    "当前是示例生日（1994-08-18 12:00）。请改成你自己的出生资料；也可以先用示例看看排盘效果。",
    "目前是示例生日（1994-08-18 12:00）。請改成你自己的出生資料；也可以先用示例看看排盤效果。",
    "現在は例の誕生日（1994-08-18 12:00）です。ご自分の出生情報に変更するか、まず例で命盤の見え方を確認できます。",
    "지금은 예시 생일(1994-08-18 12:00)입니다. 본인의 출생 정보로 바꾸거나, 먼저 예시로 명반을 확인해 보세요.",
    "Đây là ngày sinh ví dụ (18-08-1994, 12:00). Hãy đổi sang thông tin của bạn, hoặc xem thử ví dụ trước.",
    "นี่คือวันเกิดตัวอย่าง (18-08-1994 เวลา 12:00) โปรดเปลี่ยนเป็นข้อมูลของคุณ หรือดูตัวอย่างก่อน"),
  tryExample: L("See the example chart", "先用示例看看", "先用示例看看", "例で見てみる", "예시로 먼저 보기", "Xem thử ví dụ", "ดูตัวอย่างก่อน"),
  exampleChart: L("Example chart: this is not your chart. Enter your own birth details to see yours.", "示例命盘：这不是你的命盘。填写你自己的出生资料后才是你的结果。", "示例命盤：這不是你的命盤。填寫你自己的出生資料後才是你的結果。", "例の命盤です。あなたの命盤ではありません。ご自分の出生情報を入力してください。", "예시 명반입니다. 본인의 명반이 아닙니다. 본인의 출생 정보를 입력하세요.", "Lá số ví dụ, không phải của bạn. Hãy nhập thông tin của bạn.", "ดวงตัวอย่าง ไม่ใช่ดวงของคุณ โปรดกรอกข้อมูลของคุณเอง"),
  // Calculation basis shown on every birth-chart result
  basisTitle: L("Calculated with", "本次计算依据", "本次計算依據", "今回の計算条件", "이번 계산 기준", "Căn cứ tính lần này", "เกณฑ์การคำนวณครั้งนี้"),
  basisDate: L("Birth date", "出生日期", "出生日期", "出生日", "출생일", "Ngày sinh", "วันเกิด"),
  basisTime: L("Birth time used", "采用的出生时间", "採用的出生時間", "採用した出生時刻", "적용한 출생 시간", "Giờ sinh đã dùng", "เวลาเกิดที่ใช้"),
  basisPlace: L("Birthplace", "出生地", "出生地", "出生地", "출생지", "Nơi sinh", "สถานที่เกิด"),
  basisRule: L("Correction", "校正规则", "校正規則", "補正", "보정 규칙", "Hiệu chỉnh", "การปรับแก้"),
  noPlace: L("Not given", "未填写", "未填寫", "未入力", "미입력", "Chưa nhập", "ไม่ได้กรอก"),
  civil: L("Clock time as entered, no true-solar correction", "按填写的钟表时间，未做真太阳时校正", "按填寫的鐘錶時間，未做真太陽時校正", "入力した時計の時刻のまま（真太陽時補正なし）", "입력한 시계 시간 그대로(진태양시 보정 없음)", "Theo giờ đồng hồ đã nhập, không hiệu chỉnh giờ mặt trời thực", "ตามเวลานาฬิกาที่กรอก ไม่ปรับเวลาสุริยะจริง"),
  civilNoPlace: L("Clock time as entered. To use true solar time, enter the birthplace and tick “Use true solar time” in the form.", "按填写的钟表时间。如需真太阳时，请在表单里填写出生地并勾选「使用真太阳时」。", "按填寫的鐘錶時間。如需真太陽時，請在表單裡填寫出生地並勾選「使用真太陽時」。", "入力した時計の時刻のままです。真太陽時を使うには、出生地を入力し「真太陽時を使う」にチェックしてください。", "입력한 시계 시간 그대로입니다. 진태양시를 쓰려면 출생지를 입력하고 '진태양시 사용'에 체크하세요.", "Theo giờ đồng hồ đã nhập. Muốn dùng giờ mặt trời thực, hãy nhập nơi sinh và chọn “Dùng giờ mặt trời thực”.", "ตามเวลานาฬิกาที่กรอก หากต้องการเวลาสุริยะจริง ให้กรอกสถานที่เกิดและเลือก “ใช้เวลาสุริยะจริง”"),
  trueSolar: L("True solar time: {t} ({m} minutes from clock time, by the birthplace longitude and the equation of time)", "真太阳时 {t}（按出生地经度与均时差，比钟表时间 {m} 分钟）", "真太陽時 {t}（按出生地經度與均時差，比鐘錶時間 {m} 分鐘）", "真太陽時 {t}（出生地の経度と均時差により、時計時刻と {m} 分の差）", "진태양시 {t}(출생지 경도와 균시차 기준, 시계 시간과 {m}분 차이)", "Giờ mặt trời thực {t} (theo kinh độ nơi sinh và phương trình thời gian, lệch {m} phút)", "เวลาสุริยะจริง {t} (ตามลองจิจูดสถานที่เกิดและสมการเวลา ต่างจากนาฬิกา {m} นาที)"),
  timeUnknownBasis: L("Unknown: the hour pillar is not calculated", "不详：不计算时柱", "不詳：不計算時柱", "不明：時柱は計算しません", "모름: 시주를 계산하지 않음", "Không rõ: không tính trụ giờ", "ไม่ทราบ: ไม่คำนวณเสายาม"),
  hourUnknown: L("Hour unknown", "时辰不详", "時辰不詳", "時刻不明", "시간 모름", "Không rõ giờ", "ไม่ทราบยาม"),
  luckNote: L("Birth time unknown: the luck-cycle start is estimated from noon on the birth day, so it may shift by a few months.", "出生时间不详：大运起运按出生当天中午估算，可能相差几个月。", "出生時間不詳：大運起運按出生當天中午估算，可能相差幾個月。", "出生時刻不明：大運の起運は当日正午で推定しているため、数か月ずれることがあります。", "출생 시간 모름: 대운 시작은 출생일 정오 기준으로 추정해 몇 달 차이가 날 수 있습니다.", "Không rõ giờ sinh: tuổi khởi vận ước tính theo trưa ngày sinh, có thể lệch vài tháng.", "ไม่ทราบเวลาเกิด: อายุเริ่มวัยจรประมาณจากเที่ยงวันเกิด อาจคลาดไปไม่กี่เดือน"),
};
