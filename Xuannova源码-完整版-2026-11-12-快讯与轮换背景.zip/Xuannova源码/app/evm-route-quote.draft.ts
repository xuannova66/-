/** Local-only V2-router quote prototype. No signing, sending or live config.
 * Registry, router and RPC must be verified by the server/operator. Pool
 * quotes are not a manipulation-resistant fair-price oracle. Taxed or
 * unknown tokens are deliberately rejected by makeExactOutputQuote.
 */
import { getAddress, type Address } from "viem";
import { makeExactOutputQuote } from "./multichain-quote";
import { packageSettlement } from "../worker/multichain-policy";
import {requireReadyAsset,type DraftAsset} from "../worker/asset-readiness.draft";

type Asset={symbol:string;address:Address;decimals:number;transferFee:"none-verified"|"unknown"|"fee-on-transfer";evidence:DraftAsset["evidence"]};
type Config={network:"ethereum"|"bsc";router:Address;settlement:Address;assets:readonly Asset[];intermediates:readonly Address[]};
type Reader={getChainId():Promise<number>;quote(router:Address,output:bigint,path:readonly Address[]):Promise<readonly bigint[]>};

export async function quoteEvmDraft(input:{config:Config;reader:Reader;packageId:string;asset:Address;paths:readonly (readonly Address[])[];clock:()=>number;slippageBps:number;getReference:(request:{chainId:number;asset:Address;settlement:Address;outputUnits:bigint})=>Promise<{inputUnits:bigint;observedAt:number}>}) {
  const {config,reader}=input, terms=packageSettlement(config.network,input.packageId);
  if(await reader.getChainId()!==terms.chainId) throw new Error("WRONG_CHAIN");
  const router=getAddress(config.router), settlement=getAddress(config.settlement), asset=getAddress(input.asset);
  if(router===settlement || !input.paths.length || input.paths.length>8) throw new Error("INVALID_ROUTE_CONFIGURATION");
  const item=config.assets.find(x=>getAddress(x.address)===asset);
  if(!item || !Number.isInteger(item.decimals) || item.decimals<0 || item.decimals>18) throw new Error("UNSUPPORTED_ASSET");
  if(item.transferFee!=="none-verified") throw new Error("TOKEN_TRANSFER_FEE_UNSUPPORTED");
  requireReadyAsset({chain:config.network,symbol:item.symbol,address:item.address,decimals:item.decimals,evidence:item.evidence});
  if(asset===settlement) throw new Error("DIRECT_SETTLEMENT_REQUIRES_NO_SWAP");
  const allowed=new Set(config.intermediates.map(getAddress));
  const validPaths=input.paths.map(path=>{
    const p=path.map(getAddress);
    if(p.length<2 || p.length>3 || p[0]!==asset || p[p.length-1]!==settlement || new Set(p).size!==p.length || (p.length===3 && !allowed.has(p[1]))) throw new Error("INVALID_ROUTE");
    return p;
  });
  const attempts=await Promise.all(validPaths.map(async path=>{
    try {
      const values=await reader.quote(router,terms.amountUnits,path);
      if(values.length!==path.length || values.some(x=>typeof x!=="bigint"||x<=0n) || values[values.length-1]!==terms.amountUnits) return null;
      return {path,input:values[0]};
    } catch {return null;}
  }));
  const available=attempts.filter((x):x is {path:Address[];input:bigint}=>x!==null).sort((a,b)=>a.input<b.input?-1:a.input>b.input?1:0);
  if(!available.length) throw new Error("NO_VALID_ROUTE");
  const best=available[0];
  // The caller must obtain this reference independently from the V2 pool.
  // A manipulated spot quote must not become its own price benchmark.
  let ref:{inputUnits:bigint;observedAt:number};
  try {ref=await input.getReference({chainId:terms.chainId,asset,settlement,outputUnits:terms.amountUnits});} catch {throw new Error("REFERENCE_PRICE_UNAVAILABLE");}
  const now=input.clock();
  if(!ref || typeof ref.inputUnits!=="bigint" || ref.inputUnits<=0n || !Number.isSafeInteger(now) || !Number.isSafeInteger(ref.observedAt) || ref.observedAt>now || now-ref.observedAt>=30) throw new Error("INVALID_REFERENCE_PRICE");
  // A reference 29 seconds old must not authorize a further two minutes of
  // trades. The contract deadline is inclusive only until this expiry.
  const quoteTtlSeconds=30-(now-ref.observedAt);
  const quote=makeExactOutputQuote({outputAmount:terms.price,outputDecimals:terms.decimals,inputDecimals:item.decimals,quotedInputUnits:best.input,slippageBps:input.slippageBps,nowSeconds:now,quoteTtlSeconds,transferFee:item.transferFee});
  // Bound the user's *maximum* input, not only the nominal quote, to 102%
  // of the fresh independent benchmark, including the slippage allowance.
  if(quote.inputUnits*10000n<ref.inputUnits*9800n || quote.maxInputUnits*10000n>ref.inputUnits*10200n) throw new Error("QUOTE_PRICE_DEVIATION");
  return {...quote,network:config.network,chainId:terms.chainId,router,asset,symbol:item.symbol,path:best.path};
}
