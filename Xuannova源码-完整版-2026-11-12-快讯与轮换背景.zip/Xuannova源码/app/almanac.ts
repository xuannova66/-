// Daily almanac (黄历) data from lunar-javascript: favourable/unfavourable activities, the day's
// zodiac clash, lucky hours, directions, and a simple traditional day rating. Cultural reference only.
import { Solar } from "lunar-javascript";

export type DayRating = "good" | "ordinary" | "care";
export type ActivityKey = "wedding" | "engagement" | "move" | "opening" | "contract" | "travel" | "renovation" | "prayer";

/** Almanac entries that count for each everyday activity (any one in 宜, none in 忌). */
export const activityTerms: Record<ActivityKey, string[]> = {
  wedding: ["嫁娶"],
  engagement: ["订盟", "纳采"],
  move: ["移徙", "入宅"],
  opening: ["开市"],
  contract: ["立券", "交易"],
  travel: ["出行"],
  renovation: ["动土", "修造"],
  prayer: ["祈福", "祭祀"],
};
export const activityKeys = Object.keys(activityTerms) as ActivityKey[];

// One common version of the twelve day officers (建除十二神).
const GOOD_OFFICERS = new Set(["除", "危", "定", "执", "成", "开"]);

export type AlmanacDay = {
  iso: string;
  year: number; month: number; day: number; weekday: number;
  lunarMonth: number; lunarDay: number; lunarLeap: boolean;
  lunarMonthZh: string; lunarDayZh: string;
  yearGanZhi: string; monthGanZhi: string; dayGanZhi: string; zodiac: string;
  yi: string[]; ji: string[];
  spirit: string; spiritType: "黄道" | "黑道"; officer: string;
  rating: DayRating;
  clashZodiac: string; clashGanZhi: string; shaDirection: string;
  joy: string; wealth: string; fortune: string;
  pengZu: [string, string];
  solarTerm: string; festivals: string[];
  hours: Array<{ branch: string; from: string; to: string; good: boolean }>;
  activities: Record<ActivityKey, "yes" | "no" | "neutral">;
};

const pad = (value: number) => String(value).padStart(2, "0");
export const isoOf = (year: number, month: number, day: number) => `${year}-${pad(month)}-${pad(day)}`;
export function todayIso(now = new Date()) { return isoOf(now.getFullYear(), now.getMonth() + 1, now.getDate()); }

export function rateDay(spiritLuck: string, officer: string, yi: string[]): DayRating {
  // 破 (Break) days are traditionally treated as the least favourable of the twelve.
  if (yi.includes("诸事不宜") || officer === "破") return "care";
  let score = spiritLuck === "吉" ? 1 : -1;
  score += GOOD_OFFICERS.has(officer) ? 1 : -1;
  return score >= 2 ? "good" : score <= -2 ? "care" : "ordinary";
}

// Each day is worked out once and kept: the almanac page, its month grid, the "good days" finder and the posters all
// ask for the same days, and the lunar maths is the slow part (it made opening the page stutter on phones).
const dayCache = new Map<string, AlmanacDay>();

export function almanacDay(iso: string): AlmanacDay {
  const cached = dayCache.get(iso);
  if (cached) return cached;
  const result = computeAlmanacDay(iso);
  if (dayCache.size > 900) dayCache.delete(dayCache.keys().next().value as string);
  dayCache.set(iso, result);
  return result;
}

/** Works out this month and next in small pieces while the phone is idle, so the almanac opens without a stall. */
export function prewarmAlmanac(fromIso: string) {
  if (typeof window === "undefined") return;
  const w = window as Window & { requestIdleCallback?: (cb: (deadline: { timeRemaining: () => number }) => void, o?: { timeout: number }) => number };
  const [year, month] = fromIso.split("-").map(Number);
  const queue: string[] = [];
  for (let k = 0; k < 2; k += 1) {
    const y = year + Math.floor((month - 1 + k) / 12), m = ((month - 1 + k) % 12) + 1;
    const days = new Date(y, m, 0).getDate();
    for (let d = 1; d <= days; d += 1) queue.push(isoOf(y, m, d));
  }
  // today and the days around it first
  queue.sort((a, b) => Math.abs(Date.parse(a) - Date.parse(fromIso)) - Math.abs(Date.parse(b) - Date.parse(fromIso)));
  const step = (deadline?: { timeRemaining: () => number }) => {
    let n = 0;
    while (queue.length && (deadline ? deadline.timeRemaining() > 4 : n < 2)) { almanacDay(queue.shift() as string); n += 1; }
    if (queue.length) { if (w.requestIdleCallback) w.requestIdleCallback(step, { timeout: 3000 }); else setTimeout(() => step(), 60); }
  };
  if (w.requestIdleCallback) w.requestIdleCallback(step, { timeout: 3000 }); else setTimeout(() => step(), 1500);
}

function computeAlmanacDay(iso: string): AlmanacDay {
  const [year, month, day] = iso.split("-").map(Number);
  const solar = Solar.fromYmd(year, month, day);
  const lunar = solar.getLunar();
  const yi: string[] = lunar.getDayYi();
  const ji: string[] = lunar.getDayJi();
  const officer: string = lunar.getZhiXing();
  const chong: string = lunar.getDayChongDesc(); // "(乙亥)猪"
  const activities = Object.fromEntries(activityKeys.map((key) => {
    const terms = activityTerms[key];
    const state = terms.some((term) => ji.includes(term)) ? "no" : terms.some((term) => yi.includes(term)) ? "yes" : "neutral";
    return [key, state];
  })) as AlmanacDay["activities"];
  const lunarMonth: number = lunar.getMonth();
  return {
    iso, year, month, day, weekday: solar.getWeek(),
    lunarMonth: Math.abs(lunarMonth), lunarDay: lunar.getDay(), lunarLeap: lunarMonth < 0,
    lunarMonthZh: lunar.getMonthInChinese(), lunarDayZh: lunar.getDayInChinese(),
    yearGanZhi: lunar.getYearInGanZhi(), monthGanZhi: lunar.getMonthInGanZhi(), dayGanZhi: lunar.getDayInGanZhi(), zodiac: lunar.getYearShengXiao(),
    yi, ji,
    spirit: lunar.getDayTianShen(), spiritType: lunar.getDayTianShenType() === "黄道" ? "黄道" : "黑道", officer,
    rating: rateDay(lunar.getDayTianShenLuck(), officer, yi),
    clashZodiac: lunar.getDayChongShengXiao(), clashGanZhi: chong.replace(/[()（）]/g, "").replace(/[^一-鿿]/g, "").slice(0, 2), shaDirection: lunar.getDaySha(),
    joy: lunar.getDayPositionXiDesc(), wealth: lunar.getDayPositionCaiDesc(), fortune: lunar.getDayPositionFuDesc(),
    pengZu: [lunar.getPengZuGan(), lunar.getPengZuZhi()],
    solarTerm: lunar.getJieQi() || "", festivals: lunar.getFestivals(),
    hours: lunar.getTimes().slice(0, 12).map((time: { getZhi: () => string; getMinHm: () => string; getMaxHm: () => string; getTianShenLuck: () => string }) => ({ branch: time.getZhi(), from: time.getMinHm(), to: time.getMaxHm(), good: time.getTianShenLuck() === "吉" })),
    activities,
  };
}

/** All days of a month (for the calendar grid). */
export function almanacMonth(year: number, month: number): AlmanacDay[] {
  const days = new Date(year, month, 0).getDate();
  return Array.from({ length: days }, (_, index) => almanacDay(isoOf(year, month, index + 1)));
}

/** Days in a month when the almanac lists an activity as favourable (and not unfavourable). */
export function goodDaysFor(activity: ActivityKey, year: number, month: number): AlmanacDay[] {
  return almanacMonth(year, month).filter((day) => day.activities[activity] === "yes");
}

export function shiftIso(iso: string, days: number) {
  const [year, month, day] = iso.split("-").map(Number);
  const date = new Date(year, month - 1, day + days, 12);
  return isoOf(date.getFullYear(), date.getMonth() + 1, date.getDate());
}
