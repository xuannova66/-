// Texts for the daily almanac (黄历) page and the home "Today's almanac" card, in 7 languages.
import type { Locale } from "./site-content";
import type { ActivityKey, DayRating } from "./almanac";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

export const almanacText = {
  eyebrow: L("Chinese almanac", "中国黄历", "中國黃曆", "中国の暦", "중국 황력", "Lịch vạn sự", "ปฏิทินจีน"),
  title: L("Is today a good day?", "今天日子好不好？", "今天日子好不好？", "今日は良い日？", "오늘은 좋은 날일까?", "Hôm nay ngày tốt hay xấu?", "วันนี้เป็นวันดีไหม?"),
  lead: L("The traditional Chinese almanac lists, for every day, what is favourable, what to avoid, the zodiac sign that clashes with the day and the better hours. Pick any date to check it.", "中国传统黄历为每一天写明：宜做什么、忌做什么、冲哪个生肖、哪些时辰比较好。选任意一天就能查看。", "中國傳統黃曆為每一天寫明：宜做什麼、忌做什麼、沖哪個生肖、哪些時辰比較好。選任意一天就能查看。", "中国の伝統的な暦（黄暦）は、毎日について、向いていること・避けたいこと・ぶつかる干支・よい時間帯を記しています。好きな日付を選んで確認できます。", "중국 전통 황력은 매일 좋은 일, 피할 일, 충하는 띠, 좋은 시간대를 알려 줍니다. 원하는 날짜를 골라 확인해 보세요.", "Lịch vạn sự truyền thống Trung Hoa ghi cho mỗi ngày: nên làm gì, kiêng gì, xung tuổi nào và giờ nào tốt. Chọn bất kỳ ngày nào để xem.", "ปฏิทินจีนดั้งเดิมบอกสำหรับทุกวันว่า ควรทำอะไร ควรเลี่ยงอะไร ชงกับปีนักษัตรใด และช่วงเวลาไหนดี เลือกวันที่ใดก็ได้เพื่อดู"),
  prev: L("Previous day", "前一天", "前一天", "前日", "전날", "Hôm trước", "วันก่อน"),
  next: L("Next day", "后一天", "後一天", "翌日", "다음 날", "Hôm sau", "วันถัดไป"),
  today: L("Today", "今天", "今天", "今日", "오늘", "Hôm nay", "วันนี้"),
  pick: L("Choose a date", "选择日期", "選擇日期", "日付を選ぶ", "날짜 선택", "Chọn ngày", "เลือกวันที่"),
  lunar: L("Lunar date", "农历", "農曆", "旧暦", "음력", "Âm lịch", "จันทรคติ"),
  lunarValue: L("month {m}, day {d}", "{mz}月{dz}", "{mz}月{dz}", "{m}月{d}日", "{m}월 {d}일", "ngày {d} tháng {m}", "เดือน {m} วันที่ {d}"),
  leap: L("leap ", "闰", "閏", "閏", "윤", "nhuận ", "อธิกมาส "),
  pillars: L("Year · month · day", "年 · 月 · 日干支", "年 · 月 · 日干支", "年・月・日の干支", "연·월·일 간지", "Can chi năm · tháng · ngày", "ก้านกิ่ง ปี · เดือน · วัน"),
  zodiacYear: L("Year of the {z}", "{z}年", "{z}年", "{z}年", "{z}띠 해", "Năm {z}", "ปี{z}"),
  solarTerm: L("Solar term today", "今日节气", "今日節氣", "今日の節気", "오늘의 절기", "Tiết khí hôm nay", "สารทวันนี้"),
  basis: L("Why", "依据", "依據", "根拠", "근거", "Căn cứ", "เหตุผล"),
  basisText: L("{spirit} ({type}) · day officer “{officer}”", "{spirit}（{type}日）· 建除“{officer}”日", "{spirit}（{type}日）· 建除「{officer}」日", "{spirit}（{type}日）・建除「{officer}」の日", "{spirit}({type}일) · 건제 '{officer}'일", "{spirit} (ngày {type}) · trực “{officer}”", "{spirit} (วัน{type}) · เจ้าวัน “{officer}”"),
  basisHelp: L("The almanac rates a day with two traditional systems: the twelve day spirits (the six “Yellow Path” spirits are auspicious) and the twelve day officers (Remove, Danger, Settle, Hold, Success and Open count as favourable). This rating combines the two, as one common method.", "黄历用两套传统方法判断一天吉凶：十二值神（青龙、明堂等“黄道”六神为吉）和建除十二值（除、危、定、执、成、开为吉）。这里综合两者给出参考，是常见算法之一。", "黃曆用兩套傳統方法判斷一天吉凶：十二值神（青龍、明堂等「黃道」六神為吉）和建除十二值（除、危、定、執、成、開為吉）。這裡綜合兩者給出參考，是常見算法之一。", "暦では2つの伝統的な方法で日の吉凶を判断します。十二の値神（青龍・明堂など「黄道」の6神が吉）と、建除十二値（除・危・定・執・成・開が吉）です。ここでは両方を合わせた目安を示しています（一般的な方法のひとつ）。", "황력은 두 가지 전통 방법으로 날의 길흉을 봅니다. 열두 치신(청룡·명당 등 '황도' 여섯 신이 길)과 건제십이치(제·위·정·집·성·개가 길)입니다. 여기서는 둘을 합쳐 참고로 보여 줍니다(흔히 쓰는 방법 중 하나).", "Lịch đánh giá một ngày bằng hai hệ thống truyền thống: mười hai thần trực ngày (sáu thần \"Hoàng đạo\" là tốt) và thập nhị trực (Trừ, Nguy, Định, Chấp, Thành, Khai là tốt). Kết quả ở đây kết hợp cả hai, là một cách tính phổ biến.", "ปฏิทินประเมินวันด้วยสองระบบดั้งเดิม คือเทพประจำวันสิบสององค์ (หกองค์ฝ่าย “ทางเหลือง” เป็นมงคล) และเจ้าวันสิบสอง (ขจัด อันตราย มั่นคง ยึดถือ สำเร็จ และเปิด ถือว่าดี) ผลที่นี่รวมทั้งสองระบบตามวิธีที่ใช้ทั่วไป"),
  yellow: L("Yellow Path", "黄道", "黃道", "黄道", "황도", "Hoàng đạo", "ทางเหลือง"),
  black: L("Black Path", "黑道", "黑道", "黒道", "흑도", "Hắc đạo", "ทางดำ"),
  yi: L("Good for", "宜", "宜", "宜（よい）", "의(좋음)", "Nên làm", "ควรทำ"),
  ji: L("Avoid", "忌", "忌", "忌（避ける）", "기(피함)", "Nên tránh", "ควรเลี่ยง"),
  none: L("Nothing listed", "无", "無", "なし", "없음", "Không có", "ไม่มี"),
  activitiesTitle: L("Everyday plans today", "常见事项今天怎么样", "常見事項今天怎麼樣", "よくある予定は今日どう？", "흔한 일정, 오늘은?", "Việc thường gặp hôm nay", "เรื่องทั่วไปวันนี้"),
  stateYes: L("Favourable", "宜", "宜", "吉", "좋음", "Nên", "ดี"),
  stateNo: L("Avoid", "忌", "忌", "避ける", "피함", "Kiêng", "เลี่ยง"),
  stateNeutral: L("Not listed", "未提及", "未提及", "記載なし", "언급 없음", "Không ghi", "ไม่ระบุ"),
  clashTitle: L("Zodiac clash", "冲煞", "沖煞", "冲（ぶつかる干支）", "충살", "Xung sát", "ปีชง"),
  clashText: L("Today clashes with the {z} ({g}). Traditionally, people born in a year of the {z} keep a low profile today, and the {d} is the direction to avoid for major work.", "今日冲{z}（{g}），煞{d}。传统上属{z}的人今天宜低调行事；{d}方不宜动土、远行。", "今日沖{z}（{g}），煞{d}。傳統上屬{z}的人今天宜低調行事；{d}方不宜動土、遠行。", "今日は{z}（{g}）と冲。伝統的に{z}年生まれの人は控えめに過ごし、{d}は大きな作業を避ける方角とされます。", "오늘은 {z}({g})와 충입니다. 전통적으로 {z}띠는 오늘 조용히 지내는 것이 좋고, {d} 방향은 큰일을 피하는 방향입니다.", "Hôm nay xung tuổi {z} ({g}). Theo truyền thống, người tuổi {z} nên giữ mình hôm nay; hướng {d} nên tránh làm việc lớn.", "วันนี้ชงกับปี{z} ({g}) ตามธรรมเนียมผู้เกิดปี{z}ควรทำตัวเรียบง่ายในวันนี้ และทิศ{d}ควรเลี่ยงงานใหญ่"),
  hoursTitle: L("Better hours", "吉时", "吉時", "よい時間帯", "좋은 시간", "Giờ tốt", "ช่วงเวลาดี"),
  hoursLead: L("The day is split into twelve two-hour periods. Those marked auspicious are traditionally better for starting things.", "一天分为十二个时辰，每个两小时。标“吉”的时辰传统上更适合开始办事。", "一天分為十二個時辰，每個兩小時。標「吉」的時辰傳統上更適合開始辦事。", "1日は2時間ずつ12の時辰に分かれます。「吉」の時辰は、物事を始めるのに向いているとされます。", "하루는 두 시간씩 열두 시진으로 나뉩니다. '길'로 표시된 시진이 일을 시작하기에 좋다고 봅니다.", "Một ngày chia thành mười hai giờ, mỗi giờ hai tiếng. Giờ ghi \"tốt\" theo truyền thống thích hợp để bắt đầu công việc.", "หนึ่งวันแบ่งเป็นสิบสองยาม ยามละสองชั่วโมง ยามที่เป็นมงคลเหมาะกับการเริ่มต้นสิ่งต่าง ๆ ตามธรรมเนียม"),
  good: L("Auspicious", "吉", "吉", "吉", "길", "Tốt", "มงคล"),
  bad: L("Less so", "凶", "凶", "凶", "흉", "Xấu", "ไม่มงคล"),
  directionsTitle: L("Directions today", "今日方位", "今日方位", "今日の方角", "오늘의 방위", "Phương hướng hôm nay", "ทิศวันนี้"),
  directionsLead: L("Traditional directions of the day, sometimes used when choosing which way to set out or face.", "传统上每天的吉神方位，有人出门、谈事时会参考朝哪个方向。", "傳統上每天的吉神方位，有人出門、談事時會參考朝哪個方向。", "その日の吉神の方角。出かける方向や向く方向を決めるときに参考にされます。", "그날 길신의 방위로, 외출이나 마주 앉을 방향을 정할 때 참고하기도 합니다.", "Phương vị cát thần trong ngày, đôi khi được tham khảo khi chọn hướng xuất hành hay hướng ngồi.", "ทิศมงคลของวันตามธรรมเนียม บางคนใช้เลือกทิศออกเดินทางหรือทิศที่หันหน้า"),
  joy: L("Joy", "喜神", "喜神", "喜神", "희신", "Hỷ thần", "เทพแห่งความยินดี"),
  wealth: L("Wealth", "财神", "財神", "財神", "재신", "Tài thần", "เทพแห่งโชคลาภ"),
  fortune: L("Fortune", "福神", "福神", "福神", "복신", "Phúc thần", "เทพแห่งวาสนา"),
  pengZu: L("Peng Zu's taboos", "彭祖百忌", "彭祖百忌", "彭祖百忌", "팽조백기", "Bành Tổ bách kỵ", "ข้อห้ามของเผิงจู่"),
  calendarTitle: L("This month at a glance", "本月黄历", "本月黃曆", "今月の暦", "이달의 황력", "Lịch tháng này", "ปฏิทินเดือนนี้"),
  ratingGood: L("Good day", "好日子", "好日子", "良い日", "좋은 날", "Ngày tốt", "วันดี"),
  ratingOrdinary: L("Ordinary day", "普通日子", "普通日子", "普通の日", "보통 날", "Ngày bình thường", "วันธรรมดา"),
  ratingCare: L("Take care", "宜谨慎", "宜謹慎", "慎重に", "신중하게", "Nên thận trọng", "ควรระวัง"),
  ratingGoodNote: L("Traditionally an auspicious day, suited to important plans.", "传统上视为吉日，适合安排重要的事。", "傳統上視為吉日，適合安排重要的事。", "伝統的に吉日とされ、大切な予定に向いています。", "전통적으로 길일로 여겨 중요한 일에 좋습니다.", "Theo truyền thống là ngày tốt, hợp cho việc quan trọng.", "ตามธรรมเนียมถือเป็นวันมงคล เหมาะกับเรื่องสำคัญ"),
  ratingOrdinaryNote: L("A mixed day; everyday matters can go ahead as usual.", "吉凶参半，日常事务照常进行即可。", "吉凶參半，日常事務照常進行即可。", "吉凶が半々。日常のことは普段どおりで大丈夫です。", "길흉이 반반. 일상적인 일은 평소대로 하면 됩니다.", "Tốt xấu lẫn lộn; việc thường ngày cứ làm bình thường.", "ดีและไม่ดีปนกัน เรื่องประจำวันทำได้ตามปกติ"),
  ratingCareNote: L("Traditionally not a day for major plans; consider another date for important matters.", "传统上不宜办大事，重要安排可以另选日子。", "傳統上不宜辦大事，重要安排可以另選日子。", "伝統的に大きなことには向かない日。大切な予定は別の日も検討を。", "전통적으로 큰일에는 맞지 않는 날. 중요한 일은 다른 날을 고려해 보세요.", "Theo truyền thống không hợp việc lớn; việc quan trọng nên chọn ngày khác.", "ตามธรรมเนียมไม่เหมาะกับเรื่องใหญ่ เรื่องสำคัญลองเลือกวันอื่น"),
  finderTitle: L("Find a good day", "找好日子", "找好日子", "良い日を探す", "좋은 날 찾기", "Tìm ngày tốt", "หาวันดี"),
  finderLead: L("Choose a plan and a month to see which days the almanac marks as favourable.", "选一件事和月份，看看哪几天黄历上写着“宜”。", "選一件事和月份，看看哪幾天黃曆上寫著「宜」。", "予定と月を選ぶと、暦で「宜」とされている日がわかります。", "일과 달을 고르면 황력에서 '의'로 표시된 날을 볼 수 있어요.", "Chọn việc và tháng để xem những ngày lịch ghi là \"nên\".", "เลือกเรื่องและเดือน เพื่อดูว่าวันไหนปฏิทินระบุว่า “ควรทำ”"),
  finderPlan: L("Plan", "事项", "事項", "予定", "일", "Việc", "เรื่อง"),
  finderMonth: L("Month", "月份", "月份", "月", "달", "Tháng", "เดือน"),
  finderNone: L("No favourable days this month. Try the next month.", "这个月没有标“宜”的日子，看看下个月吧。", "這個月沒有標「宜」的日子，看看下個月吧。", "今月は「宜」の日がありません。来月を見てみましょう。", "이번 달에는 '의'로 표시된 날이 없어요. 다음 달을 확인해 보세요.", "Tháng này không có ngày ghi \"nên\". Hãy xem tháng sau.", "เดือนนี้ไม่มีวันที่ระบุว่าควรทำ ลองดูเดือนถัดไป"),
  finderCount: L("{n} days", "共 {n} 天", "共 {n} 天", "{n}日", "{n}일", "{n} ngày", "{n} วัน"),
  howTitle: L("How to read the almanac", "怎么看黄历？", "怎麼看黃曆？", "暦の読み方", "황력 보는 법", "Cách xem lịch vạn sự", "วิธีอ่านปฏิทินจีน"),
  how1: L("“Good for” and “Avoid” are traditional lists of activities, such as marriage, moving house, opening a business or travel. People often check them before choosing a date for a big event.", "“宜”和“忌”是传统上列出的事项，比如嫁娶、搬家、开业、出行。很多人在定大日子前会先看一眼。", "「宜」和「忌」是傳統上列出的事項，比如嫁娶、搬家、開業、出行。很多人在定大日子前會先看一眼。", "「宜」と「忌」は、結婚・引っ越し・開業・旅行などの伝統的な項目です。大切な日を決める前に確認する人が多くいます。", "'의'와 '기'는 결혼, 이사, 개업, 여행 같은 전통적인 항목입니다. 큰일의 날짜를 정하기 전에 확인하는 사람이 많아요.", "\"Nên làm\" và \"nên tránh\" là danh sách việc truyền thống như cưới hỏi, chuyển nhà, khai trương, xuất hành. Nhiều người xem trước khi chọn ngày cho việc lớn.", "“ควรทำ” และ “ควรเลี่ยง” เป็นรายการกิจกรรมตามธรรมเนียม เช่น แต่งงาน ย้ายบ้าน เปิดกิจการ เดินทาง หลายคนดูก่อนเลือกวันสำหรับงานสำคัญ"),
  how2: L("Each day “clashes” with one of the twelve zodiac animals. If it is your birth-year animal, the tradition suggests keeping important plans for another day.", "每天会“冲”十二生肖中的一个。如果正好是你的属相，传统上建议把重要的事安排到别的日子。", "每天會「沖」十二生肖中的一個。如果正好是你的屬相，傳統上建議把重要的事安排到別的日子。", "毎日、十二支の動物のひとつと「冲」になります。それが自分の生まれ年の動物なら、大切な予定は別の日にするのが伝統的です。", "매일 열두 띠 중 하나와 '충'이 됩니다. 그것이 내 띠라면 중요한 일은 다른 날로 미루는 것이 전통입니다.", "Mỗi ngày \"xung\" với một trong mười hai con giáp. Nếu trùng tuổi bạn, truyền thống khuyên để việc quan trọng sang ngày khác.", "แต่ละวันจะ “ชง” กับนักษัตรหนึ่งในสิบสอง หากตรงกับปีเกิดของคุณ ตามธรรมเนียมแนะนำให้เลื่อนเรื่องสำคัญไปวันอื่น"),
  how3: L("Chinese months follow the moon and the year starts at Chinese New Year, so the lunar date differs from the calendar date. The almanac day still runs midnight to midnight.", "中国的农历按月亮运行，新年从春节开始，所以农历日期和公历不同；黄历的一天仍然是从午夜到午夜。", "中國的農曆按月亮運行，新年從春節開始，所以農曆日期和公曆不同；黃曆的一天仍然是從午夜到午夜。", "中国の旧暦は月の満ち欠けに従い、新年は春節から始まるため、新暦とは日付が異なります。暦の1日は真夜中から真夜中までです。", "중국 음력은 달의 움직임을 따르고 새해는 춘절에 시작하므로 양력 날짜와 다릅니다. 황력의 하루는 자정부터 자정까지입니다.", "Âm lịch theo chu kỳ mặt trăng và năm mới bắt đầu từ Tết, nên ngày âm khác ngày dương. Một ngày trong lịch vẫn tính từ nửa đêm đến nửa đêm.", "ปฏิทินจันทรคติจีนนับตามดวงจันทร์ และปีใหม่เริ่มที่ตรุษจีน วันที่จึงต่างจากปฏิทินสากล แต่วันหนึ่งยังนับจากเที่ยงคืนถึงเที่ยงคืน"),
  how4: L("The almanac is a piece of cultural heritage. Use it as a gentle reference, not as a rule for health, money or legal decisions.", "黄历是一种传统文化，可作为生活的温和参考，健康、财务、法律等决定请以实际情况和专业意见为准。", "黃曆是一種傳統文化，可作為生活的溫和參考，健康、財務、法律等決定請以實際情況和專業意見為準。", "暦は文化遺産のひとつです。やさしい参考として使い、健康・お金・法律の判断は実情と専門家の意見に従ってください。", "황력은 전통문화입니다. 가벼운 참고로만 쓰고, 건강·돈·법률에 관한 결정은 실제 상황과 전문가 의견을 따르세요.", "Lịch vạn sự là di sản văn hóa. Hãy dùng như tham khảo nhẹ nhàng; các quyết định về sức khỏe, tài chính, pháp lý nên dựa vào thực tế và ý kiến chuyên gia.", "ปฏิทินจีนเป็นมรดกทางวัฒนธรรม ใช้เป็นข้อมูลอ้างอิงเบา ๆ ส่วนการตัดสินใจเรื่องสุขภาพ การเงิน หรือกฎหมาย ควรยึดสถานการณ์จริงและความเห็นผู้เชี่ยวชาญ"),
  personalTitle: L("Your own year", "你自己的流年", "你自己的流年", "あなた自身の一年", "나만의 한 해", "Năm của riêng bạn", "ปีของคุณเอง"),
  homeTitle: L("Today's almanac", "今日黄历", "今日黃曆", "今日の暦", "오늘의 황력", "Lịch hôm nay", "ปฏิทินวันนี้"),
  homeMore: L("Full almanac and good-day finder", "查看完整黄历、找好日子", "查看完整黃曆、找好日子", "暦の詳細と良い日探し", "전체 황력과 좋은 날 찾기", "Xem lịch đầy đủ và tìm ngày tốt", "ดูปฏิทินเต็มและหาวันดี"),
  festival: L("Festival", "节日", "節日", "祭日", "명절", "Lễ tết", "เทศกาล"),
};

export const activityLabels: Record<ActivityKey, L7> = {
  wedding: L("Wedding", "结婚", "結婚", "結婚", "결혼", "Cưới hỏi", "แต่งงาน"),
  engagement: L("Engagement", "订婚", "訂婚", "婚約", "약혼", "Đính hôn", "หมั้น"),
  move: L("Moving house", "搬家入宅", "搬家入宅", "引っ越し", "이사", "Chuyển nhà", "ย้ายบ้าน"),
  opening: L("Opening a business", "开业", "開業", "開業", "개업", "Khai trương", "เปิดกิจการ"),
  contract: L("Signing a contract", "签约交易", "簽約交易", "契約", "계약", "Ký hợp đồng", "เซ็นสัญญา"),
  travel: L("Travel", "出行", "出行", "旅行・外出", "여행", "Xuất hành", "เดินทาง"),
  renovation: L("Building and renovation", "动土装修", "動土裝修", "工事・リフォーム", "공사·수리", "Động thổ, sửa nhà", "ก่อสร้างและซ่อมแซม"),
  prayer: L("Prayer and offerings", "祈福祭祀", "祈福祭祀", "祈願・祭祀", "기복·제사", "Cầu phúc, cúng tế", "ขอพรและบูชา"),
};

export const ratingLabel = (rating: DayRating, locale: Locale) => (rating === "good" ? almanacText.ratingGood : rating === "care" ? almanacText.ratingCare : almanacText.ratingOrdinary)[locale];
export const ratingNote = (rating: DayRating, locale: Locale) => (rating === "good" ? almanacText.ratingGoodNote : rating === "care" ? almanacText.ratingCareNote : almanacText.ratingOrdinaryNote)[locale];

/** The twelve day officers (建除十二神) with a short meaning. */
export const officerNames: Record<string, L7> = {
  建: L("Establish", "建", "建", "建", "건", "Kiến", "สร้าง"), 除: L("Remove", "除", "除", "除", "제", "Trừ", "ขจัด"), 满: L("Full", "满", "滿", "満", "만", "Mãn", "เต็ม"),
  平: L("Balance", "平", "平", "平", "평", "Bình", "ราบ"), 定: L("Settle", "定", "定", "定", "정", "Định", "มั่นคง"), 执: L("Hold", "执", "執", "執", "집", "Chấp", "ยึดถือ"),
  破: L("Break", "破", "破", "破", "파", "Phá", "แตก"), 危: L("Danger", "危", "危", "危", "위", "Nguy", "อันตราย"), 成: L("Success", "成", "成", "成", "성", "Thành", "สำเร็จ"),
  收: L("Receive", "收", "收", "収", "수", "Thu", "เก็บ"), 开: L("Open", "开", "開", "開", "개", "Khai", "เปิด"), 闭: L("Close", "闭", "閉", "閉", "폐", "Bế", "ปิด"),
};

/** Main lunar festivals returned by the library. */
export const festivalNames: Record<string, L7> = {
  春节: L("Chinese New Year", "春节", "春節", "春節", "춘절(설날)", "Tết Nguyên Đán", "ตรุษจีน"),
  元宵节: L("Lantern Festival", "元宵节", "元宵節", "元宵節", "정월 대보름", "Tết Nguyên Tiêu", "เทศกาลโคมไฟ"),
  龙头节: L("Dragon Head Festival", "龙抬头", "龍抬頭", "龍抬頭", "용두절", "Long Đầu tiết", "เทศกาลมังกรเงยหน้า"),
  上巳节: L("Shangsi Festival", "上巳节", "上巳節", "上巳節", "상사절", "Tết Thượng Tị", "เทศกาลซ่างซื่อ"),
  端午节: L("Dragon Boat Festival", "端午节", "端午節", "端午節", "단오", "Tết Đoan Ngọ", "เทศกาลเรือมังกร"),
  七夕节: L("Qixi (Double Seventh)", "七夕节", "七夕節", "七夕", "칠석", "Thất Tịch", "วันชีซี"),
  中元节: L("Ghost Festival", "中元节", "中元節", "中元節", "중원절", "Lễ Vu Lan / Trung Nguyên", "สารทจีน"),
  中秋节: L("Mid-Autumn Festival", "中秋节", "中秋節", "中秋節", "추석(중추절)", "Tết Trung Thu", "ไหว้พระจันทร์"),
  重阳节: L("Double Ninth Festival", "重阳节", "重陽節", "重陽節", "중양절", "Tết Trùng Cửu", "เทศกาลฉงหยาง"),
  腊八节: L("Laba Festival", "腊八节", "臘八節", "臘八節", "납팔절", "Lễ Lạp Bát", "เทศกาลล่าปา"),
  除夕: L("Chinese New Year's Eve", "除夕", "除夕", "大晦日（除夕）", "섣달그믐", "Giao thừa", "วันส่งท้ายปีเก่าจีน"),
};

export const fill = (template: string, values: Record<string, string | number>) => template.replace(/\{(\w+)\}/g, (_, key: string) => String(values[key] ?? ""));
