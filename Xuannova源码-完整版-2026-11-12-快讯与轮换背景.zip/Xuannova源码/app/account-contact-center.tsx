"use client";
/* eslint-disable @next/next/no-img-element -- The owner may supply a QR image from an arbitrary verified payment host. */

import { useState } from "react";
import { ContactIconRow } from "./contact-icons";
import styles from "./account-contact-center.module.css";
import { creditCopy } from "./credit-copy";
import { creditPackages, type CreditWallet } from "./credit-wallet";
import { clearLocalSession, createLocalSession, isValidEmail, readLocalSession, saveLocalSession, type LocalSession } from "./local-account";
import { hasConfiguredPaymentChannel, paymentConfig } from "./payment-config";
import type { Locale } from "./site-content";
import { uiCopy } from "./ui-copy";

type AccountCopy = {
  eyebrow: string;
  title: string;
  lead: string;
  emailTitle: string;
  emailLabel: string;
  emailPlaceholder: string;
  submit: string;
  localNote: string;
  invalidEmail: string;
  signedIn: string;
  signOut: string;
  communityTitle: string;
  communityLead: string;
  communityReady: string;
  communityPending: string;
  supportTitle: string;
  supportLead: string;
  supportReady: string;
  supportPending: string;
  setupNote: string;
  recentTitle: string;
  empty: string;
};

const accountCopy: Record<Locale, AccountCopy> = {
  en: { eyebrow: "MEMBERSHIP · CONTACT", title: "Keep your study close", lead: "Sign in, reach the community, or contact Xuannova support.", emailTitle: "Email sign-in", emailLabel: "Email address", emailPlaceholder: "you@example.com", submit: "Save local sign-in", localNote: "Stored only in this browser. This local edition does not send an email or contact any server.", invalidEmail: "Enter a valid email address.", signedIn: "Signed in locally as", signOut: "Clear local sign-in", communityTitle: "Global study community", communityLead: "A reserved entry for your future group, Discord, LINE, KakaoTalk, or other community destination.", communityReady: "Open community", communityPending: "Community link not configured", supportTitle: "Contact support", supportLead: "A reserved handoff for the owner’s support inbox and consultation coordination.", supportReady: "Email support", supportPending: "Support email not configured", setupNote: "Owner setup: add real destinations in app/contact-config.ts to activate these links.", recentTitle: "Recent studies", empty: "No study has been generated in this browser yet." },
  "zh-Hans": { eyebrow: "会员 · 联系我们", title: "让研习留在身边", lead: "登录账户、加入社群，或联系 Xuannova 客服。", emailTitle: "邮箱登录", emailLabel: "邮箱地址", emailPlaceholder: "you@example.com", submit: "保存本地登录", localNote: "仅保存在当前浏览器。本地版不会发送邮件，也不会连接任何服务器。", invalidEmail: "请输入有效的邮箱地址。", signedIn: "已在本机登录", signOut: "清除本地登录", communityTitle: "全球研习社群", communityLead: "预留给未来的群组、Discord、LINE、KakaoTalk 或其他社群入口。", communityReady: "进入社群", communityPending: "社群链接尚未配置", supportTitle: "联系支持", supportLead: "预留给站主支持邮箱与一对一咨询协调入口。", supportReady: "发送支持邮件", supportPending: "支持邮箱尚未配置", setupNote: "站主配置：在 app/contact-config.ts 填入真实联系方式后即可激活链接。", recentTitle: "本机最近研习", empty: "此浏览器尚未生成研习记录。" },
  "zh-Hant": { eyebrow: "會員 · 聯絡我們", title: "讓研習留在身邊", lead: "登入帳戶、加入社群，或聯絡 Xuannova 客服。", emailTitle: "信箱登入", emailLabel: "信箱地址", emailPlaceholder: "you@example.com", submit: "儲存本地登入", localNote: "僅儲存在目前瀏覽器。本地版不會寄送郵件，也不會連線至任何伺服器。", invalidEmail: "請輸入有效的信箱地址。", signedIn: "已在本機登入", signOut: "清除本地登入", communityTitle: "全球研習社群", communityLead: "預留給未來的群組、Discord、LINE、KakaoTalk 或其他社群入口。", communityReady: "進入社群", communityPending: "社群連結尚未設定", supportTitle: "聯絡支援", supportLead: "預留給站主支援信箱與一對一諮詢協調入口。", supportReady: "寄送支援郵件", supportPending: "支援信箱尚未設定", setupNote: "站主設定：在 app/contact-config.ts 填入真實聯絡方式後即可啟用連結。", recentTitle: "本機最近研習", empty: "此瀏覽器尚未產生研習紀錄。" },
  ja: { eyebrow: "メンバーシップ · お問い合わせ", title: "学びを身近に残す", lead: "サインイン、コミュニティへの参加、Xuannova サポートへのお問い合わせはこちら。", emailTitle: "メールでサインイン", emailLabel: "メールアドレス", emailPlaceholder: "you@example.com", submit: "ローカルサインインを保存", localNote: "このブラウザ内だけに保存されます。ローカル版はメール送信もサーバー接続もしません。", invalidEmail: "有効なメールアドレスを入力してください。", signedIn: "この端末でサインイン中", signOut: "ローカルサインインを消去", communityTitle: "グローバル学習コミュニティ", communityLead: "将来のグループ、Discord、LINE、KakaoTalk などの入口として用意されています。", communityReady: "コミュニティを開く", communityPending: "コミュニティリンクは未設定です", supportTitle: "サポートに連絡", supportLead: "運営者のサポート窓口と個別相談の連携先として用意されています。", supportReady: "サポートにメール", supportPending: "サポートメールは未設定です", setupNote: "運営者設定：app/contact-config.ts に実際の連絡先を追加するとリンクが有効になります。", recentTitle: "最近の学習", empty: "このブラウザにはまだ学習記録がありません。" },
  ko: { eyebrow: "멤버십 · 문의", title: "학습을 가까이에", lead: "로그인하고 커뮤니티에 참여하거나 Xuannova 지원팀에 문의하세요.", emailTitle: "이메일 로그인", emailLabel: "이메일 주소", emailPlaceholder: "you@example.com", submit: "로컬 로그인 저장", localNote: "현재 브라우저에만 저장됩니다. 로컬 에디션은 이메일을 보내거나 서버에 연결하지 않습니다.", invalidEmail: "유효한 이메일 주소를 입력하세요.", signedIn: "이 기기에 로그인됨", signOut: "로컬 로그인 지우기", communityTitle: "글로벌 학습 커뮤니티", communityLead: "향후 그룹, Discord, LINE, KakaoTalk 등의 목적지를 위한 자리입니다.", communityReady: "커뮤니티 열기", communityPending: "커뮤니티 링크가 설정되지 않았습니다", supportTitle: "지원 문의", supportLead: "운영자의 지원 메일함과 1:1 상담 조율을 위한 연결 자리입니다.", supportReady: "지원 이메일", supportPending: "지원 이메일이 설정되지 않았습니다", setupNote: "운영자 설정: app/contact-config.ts에 실제 연락처를 추가하면 링크가 활성화됩니다.", recentTitle: "최근 학습", empty: "이 브라우저에는 아직 학습 기록이 없습니다." },
  vi: { eyebrow: "THÀNH VIÊN · LIÊN HỆ", title: "Giữ hành trình học tập ở gần", lead: "Đăng nhập, tham gia cộng đồng hoặc liên hệ hỗ trợ Xuannova.", emailTitle: "Đăng nhập bằng email", emailLabel: "Địa chỉ email", emailPlaceholder: "you@example.com", submit: "Lưu đăng nhập cục bộ", localNote: "Chỉ được lưu trong trình duyệt này. Bản cục bộ không gửi email hoặc kết nối máy chủ.", invalidEmail: "Hãy nhập một địa chỉ email hợp lệ.", signedIn: "Đã đăng nhập cục bộ với", signOut: "Xóa đăng nhập cục bộ", communityTitle: "Cộng đồng học tập toàn cầu", communityLead: "Chỗ dành cho nhóm, Discord, LINE, KakaoTalk hoặc điểm đến cộng đồng trong tương lai.", communityReady: "Mở cộng đồng", communityPending: "Liên kết cộng đồng chưa được cấu hình", supportTitle: "Liên hệ hỗ trợ", supportLead: "Chỗ bàn giao cho hộp thư hỗ trợ của chủ sở hữu và điều phối tư vấn riêng.", supportReady: "Gửi email hỗ trợ", supportPending: "Email hỗ trợ chưa được cấu hình", setupNote: "Thiết lập của chủ sở hữu: thêm địa chỉ thật trong app/contact-config.ts để kích hoạt các liên kết.", recentTitle: "Các nghiên cứu gần đây", empty: "Chưa có nghiên cứu nào được tạo trong trình duyệt này." },
  th: { eyebrow: "สมาชิก · ติดต่อเรา", title: "เก็บการศึกษาไว้ใกล้ตัว", lead: "เข้าสู่ระบบ เข้าร่วมชุมชน หรือติดต่อฝ่ายช่วยเหลือของ Xuannova", emailTitle: "เข้าสู่ระบบด้วยอีเมล", emailLabel: "ที่อยู่อีเมล", emailPlaceholder: "you@example.com", submit: "บันทึกการเข้าสู่ระบบในเครื่อง", localNote: "เก็บไว้ในเบราว์เซอร์นี้เท่านั้น ฉบับในเครื่องจะไม่ส่งอีเมลหรือเชื่อมต่อเซิร์ฟเวอร์ใด ๆ", invalidEmail: "กรุณากรอกอีเมลที่ถูกต้อง", signedIn: "เข้าสู่ระบบในเครื่องด้วย", signOut: "ล้างการเข้าสู่ระบบในเครื่อง", communityTitle: "ชุมชนการศึกษาระดับโลก", communityLead: "พื้นที่สำหรับกลุ่ม Discord, LINE, KakaoTalk หรือปลายทางชุมชนอื่นในอนาคต", communityReady: "เปิดชุมชน", communityPending: "ยังไม่ได้ตั้งค่าลิงก์ชุมชน", supportTitle: "ติดต่อฝ่ายสนับสนุน", supportLead: "พื้นที่สำหรับอีเมลสนับสนุนของเจ้าของและการประสานงานปรึกษาส่วนตัว", supportReady: "ส่งอีเมลถึงฝ่ายสนับสนุน", supportPending: "ยังไม่ได้ตั้งค่าอีเมลสนับสนุน", setupNote: "การตั้งค่าเจ้าของ: เพิ่มปลายทางจริงใน app/contact-config.ts เพื่อเปิดใช้ลิงก์เหล่านี้", recentTitle: "การศึกษาล่าสุด", empty: "ยังไม่มีการสร้างผลการศึกษาในเบราว์เซอร์นี้" },
};

const contactCopy: Record<Locale, { title: string; lead: string; copy: string; copied: string }> = {
  en: { title: "Direct contact", lead: "Join an official channel or copy a contact handle to reach the institute.", copy: "Copy handle", copied: "Copied" },
  "zh-Hans": { title: "官方联系方式", lead: "加入官方频道，或复制联系方式与Xuannova取得联系。", copy: "复制账号", copied: "已复制" },
  "zh-Hant": { title: "官方聯絡方式", lead: "加入官方頻道，或複製聯絡方式與Xuannova取得聯繫。", copy: "複製帳號", copied: "已複製" },
  ja: { title: "公式連絡先", lead: "公式チャンネルに参加するか、連絡先をコピーしてXuannovaへご連絡ください。", copy: "連絡先をコピー", copied: "コピー済み" },
  ko: { title: "공식 연락처", lead: "공식 채널에 참여하거나 연락처를 복사하여 Xuannova에 문의하세요.", copy: "연락처 복사", copied: "복사됨" },
  vi: { title: "Liên hệ chính thức", lead: "Tham gia kênh chính thức hoặc sao chép thông tin liên hệ để kết nối với Xuannova.", copy: "Sao chép liên hệ", copied: "Đã sao chép" },
  th: { title: "ช่องทางติดต่ออย่างเป็นทางการ", lead: "เข้าร่วมช่องทางอย่างเป็นทางการ หรือคัดลอกข้อมูลติดต่อเพื่อเชื่อมต่อกับXuannova", copy: "คัดลอกข้อมูลติดต่อ", copied: "คัดลอกแล้ว" },
};

type RecentStudy = { title: string; stamp: string };

export function AccountContactCenter({ locale, recent, wallet }: { locale: Locale; recent: RecentStudy[]; wallet: CreditWallet }) {
  const text = accountCopy[locale];
  const contactText = contactCopy[locale];
  const credit = creditCopy(locale);
  const shared = uiCopy(locale);
  const [session, setSession] = useState<LocalSession | null>(() => readLocalSession());
  const [email, setEmail] = useState(() => readLocalSession()?.email ?? "");
  const [error, setError] = useState("");

  function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!isValidEmail(email)) {
      setError(text.invalidEmail);
      return;
    }
    const nextSession = createLocalSession(email);
    saveLocalSession(nextSession);
    setSession(nextSession);
    setEmail(nextSession.email);
    setError("");
  }

  function signOut() {
    clearLocalSession();
    setSession(null);
  }

  const paymentReady = hasConfiguredPaymentChannel && Boolean(paymentConfig.checkoutUrl);
  const showLegacyLocalPreview = false;

  return <section className="account-contact-center" data-testid="account-contact-center">
    <header className="route-heading"><p>{text.eyebrow}</p><h1>{text.title}</h1><p>{text.lead}</p></header>
    <div className="account-contact-grid">
      {showLegacyLocalPreview && <section className="credit-wallet-card">
        <header><span>00 · {credit.eyebrow}</span><h2>{credit.wallet}</h2><p>{credit.walletLead}</p></header>
        <div className="credit-balance"><span>{credit.available}</span><b>{wallet.balance}</b><small>{credit.credits}</small></div>
        <div className="credit-rules"><p>{credit.standardRule}</p><p>{credit.synthesisRule}</p></div>
        <section className="credit-package-area"><header><span>{credit.packages}</span><p>{credit.packageLead}</p></header><div className="credit-package-grid">{creditPackages.map((item) => <article className="credit-package" key={item.id}><span>{item.usdt} U</span><b>{item.credits}</b><small>{credit.credits}</small>{paymentReady ? <a href={paymentConfig.checkoutUrl} target="_blank" rel="noreferrer">{credit.payWithUsdt}<b>↗</b></a> : <button type="button" disabled>{credit.payWithUsdt}</button>}</article>)}</div></section>
        <aside className="payment-channel-note">{paymentConfig.qrImageUrl && <img src={paymentConfig.qrImageUrl} alt={credit.payWithUsdt} />}{paymentConfig.recipientAddress && <code>{paymentConfig.networkLabel ? `${paymentConfig.networkLabel} · ` : ""}{paymentConfig.recipientAddress}</code>}<p>{paymentReady ? credit.afterPayment : credit.paymentPending}</p><small>{credit.paymentSafetyNote}</small><small>{credit.deviceNote}</small></aside>
      </section>}
      {showLegacyLocalPreview && <form className="account-login-card" onSubmit={submit} noValidate>
        <span>01 · {shared.account.access}</span><h2>{text.emailTitle}</h2>
        <label>{text.emailLabel}<input type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder={text.emailPlaceholder} autoComplete="email" /></label>
        {error && <p className="account-error" role="alert">{error}</p>}
        {session ? <div className="local-session"><p>{text.signedIn}<b>{session.email}</b></p><button type="button" onClick={signOut}>{text.signOut}</button></div> : <button type="submit" className="primary-action">{text.submit}<b>↗</b></button>}
        <small>{text.localNote}</small>
      </form>}
      <article className={`account-contact-card ${styles.details}`}><span>02 · {shared.account.support}</span><h2>{contactText.title}</h2><p>{contactText.lead}</p><ContactIconRow className="account-contact-icons" copied={contactText.copied} /></article>
      {showLegacyLocalPreview && <aside className="account-setup-note"><p>{text.setupNote}</p></aside>}
      <section className="account-recent"><small>{text.recentTitle}</small>{recent.length ? recent.map((item) => <p key={`${item.title}-${item.stamp}`}><b>{item.title}</b><span>{item.stamp}</span></p>) : <p>{text.empty}</p>}</section>
    </div>
  </section>;
}
