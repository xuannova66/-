/** Local prototype only. An entry is an untrusted payment candidate, not a
 * receipt or evidence of credit. Do not store keys, signatures or secrets.
 * Server must authenticate member/order and independently verify the chain.
 * A browser buffer cannot cover closing the page before a hash is returned.
 */
type Chain="ethereum"|"solana"|"tron";
export type RecoveryCandidate={memberId:string;orderId:string;chain:Chain;transactionId:string;createdAt:string};
type StorageLike={getItem(key:string):string|null;setItem(key:string,value:string):void;removeItem(key:string):void};
const KEY="xuannova:payment-candidates:draft:v1", MAX=100;

function candidate(value:unknown):RecoveryCandidate {
  if(!value || typeof value!=="object") throw new Error("INVALID_RECOVERY_CANDIDATE");
  const x=value as Partial<RecoveryCandidate>;
  if(typeof x.memberId!=="string" || !/^[a-zA-Z0-9_-]{1,128}$/.test(x.memberId) || typeof x.orderId!=="string" || !/^[a-zA-Z0-9_-]{1,128}$/.test(x.orderId) || !["ethereum","solana","tron"].includes(x.chain??"") || typeof x.transactionId!=="string" || typeof x.createdAt!=="string") throw new Error("INVALID_RECOVERY_CANDIDATE");
  const when=Date.parse(x.createdAt);
  if(!Number.isFinite(when) || new Date(when).toISOString()!==x.createdAt) throw new Error("INVALID_RECOVERY_CANDIDATE");
  let tx=x.transactionId;
  if(x.chain==="solana") {if(!/^[1-9A-HJ-NP-Za-km-z]{64,88}$/.test(tx)) throw new Error("INVALID_RECOVERY_CANDIDATE");}
  else {tx=tx.replace(/^0x/i,"").toLowerCase();if(!/^[a-f0-9]{64}$/.test(tx)) throw new Error("INVALID_RECOVERY_CANDIDATE");}
  return {memberId:x.memberId,orderId:x.orderId,chain:x.chain as Chain,transactionId:tx,createdAt:x.createdAt};
}
function read(storage:StorageLike):RecoveryCandidate[] {
  const raw=storage.getItem(KEY); if(raw===null) return [];
  let value:unknown; try {value=JSON.parse(raw);} catch {throw new Error("RECOVERY_BUFFER_CORRUPT");}
  if(!Array.isArray(value)||value.length>MAX) throw new Error("RECOVERY_BUFFER_CORRUPT");
  try {return value.map(candidate);} catch {throw new Error("RECOVERY_BUFFER_CORRUPT");}
}
function identity(x:RecoveryCandidate) {return `${x.memberId}:${x.orderId}:${x.chain}:${x.transactionId}`;}

export function saveRecoveryCandidate(storage:StorageLike,input:RecoveryCandidate) {
  const entry=candidate(input), entries=read(storage);
  if(entries.some(x=>identity(x)===identity(entry))) return;
  if(entries.length>=MAX) throw new Error("RECOVERY_BUFFER_FULL");
  try {storage.setItem(KEY,JSON.stringify([...entries,entry]));} catch {throw new Error("RECOVERY_STORAGE_UNAVAILABLE");}
}

/** Only pass a server function that durably records the attempt for the current
 * authenticated member. Cross-tab locking and server API integration are not
 * implemented; do not enable this prototype for real payments as-is.
 */
export async function flushRecoveryCandidates(storage:StorageLike,memberId:string,submit:(entry:RecoveryCandidate)=>Promise<{recorded:boolean}>) {
  let sent=0, pending=0;
  for(const entry of read(storage).filter(x=>x.memberId===memberId)) {
    try {
      const ack=await submit(entry);
      if(typeof ack?.recorded!=="boolean") throw new Error("INVALID_ACKNOWLEDGEMENT");
      // Re-read to avoid deleting unrelated entries added while awaiting I/O.
      const remaining=read(storage).filter(x=>identity(x)!==identity(entry));
      if(remaining.length) storage.setItem(KEY,JSON.stringify(remaining));else storage.removeItem(KEY);
      sent++;
    } catch {pending++;}
  }
  return {sent,pending};
}

/** The server chooses member identity from the session; local identity and
 * chain are not sent as authority. This endpoint is disabled by default. */
export async function submitRecoveryCandidate(input:RecoveryCandidate,fetcher:typeof fetch=fetch):Promise<{recorded:boolean}> {
  const entry=candidate(input);
  const response=await fetcher("/api/draft/payment-attempts",{method:"POST",credentials:"same-origin",headers:{"content-type":"application/json"},body:JSON.stringify({orderId:entry.orderId,transactionId:entry.transactionId})});
  if(!response.ok) throw new Error("RECOVERY_SUBMISSION_FAILED");
  const body:unknown=await response.json();
  if(!body || typeof body!=="object" || typeof (body as {recorded?:unknown}).recorded!=="boolean") throw new Error("INVALID_ACKNOWLEDGEMENT");
  return {recorded:(body as {recorded:boolean}).recorded};
}
