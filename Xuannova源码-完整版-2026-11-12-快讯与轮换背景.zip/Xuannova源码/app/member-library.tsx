"use client";
// Member centre as "my data and report library": saved birth profiles, every unlocked report (grouped by
// person, method and date) with notes and follow-up questions, solar-term reminders and privacy controls.
import { useCallback, useEffect, useMemo, useState } from "react";
import { rememberScroll } from "./scroll-memory";
import type { Locale } from "./site-content";
import { titleForRoute, type AppRoute, type ToolkitKey } from "./study-suite";
import { toolkitName } from "./toolkit-copy";
import { pathFor } from "./study-navigation";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

export const libraryText = {
  profilesTitle: L("My profiles", "我的档案", "我的檔案", "マイプロフィール", "내 프로필", "Hồ sơ của tôi", "โปรไฟล์ของฉัน"),
  profilesLead: L("Save your own birth details, and those of family members who agreed, so you never have to type them again. Pick a profile at the top of any form.", "保存自己以及经同意的家人的出生资料，之后不必重复填写。在任何表单顶部选择档案即可自动填入。", "儲存自己以及經同意的家人的出生資料，之後不必重複填寫。在任何表單頂部選擇檔案即可自動填入。", "自分と、同意を得た家族の生年月日などを保存すれば、もう入力し直す必要はありません。各フォームの上でプロフィールを選ぶだけです。", "나와 동의한 가족의 출생 정보를 저장하면 다시 입력할 필요가 없습니다. 각 양식 위에서 프로필을 고르면 됩니다.", "Lưu thông tin ngày sinh của bạn và người thân đã đồng ý, không cần nhập lại. Chọn hồ sơ ở đầu mỗi biểu mẫu là xong.", "บันทึกข้อมูลวันเกิดของคุณและคนในครอบครัวที่ยินยอม จะได้ไม่ต้องกรอกซ้ำ เลือกโปรไฟล์ที่ด้านบนของแบบฟอร์มใดก็ได้"),
  addSelf: L("Add my own profile", "添加本人档案", "新增本人檔案", "自分のプロフィールを追加", "내 프로필 추가", "Thêm hồ sơ của tôi", "เพิ่มโปรไฟล์ของฉัน"),
  addOther: L("Add family or a friend", "添加家人或朋友", "新增家人或朋友", "家族・友人を追加", "가족·친구 추가", "Thêm người thân hoặc bạn bè", "เพิ่มครอบครัวหรือเพื่อน"),
  profilesUnavailable: L("Profiles could not be loaded right now. Please refresh the page in a moment.", "档案暂时无法读取，请稍后刷新页面。", "檔案暫時無法讀取，請稍後重新整理頁面。", "プロフィールを読み込めませんでした。しばらくして再読み込みしてください。", "프로필을 불러오지 못했습니다. 잠시 후 새로고침해 주세요.", "Chưa tải được hồ sơ. Vui lòng tải lại trang sau ít phút.", "โหลดโปรไฟล์ไม่ได้ในขณะนี้ กรุณารีเฟรชหน้าอีกครั้งภายหลัง"),
  add: L("Add a profile", "添加档案", "新增檔案", "プロフィールを追加", "프로필 추가", "Thêm hồ sơ", "เพิ่มโปรไฟล์"),
  edit: L("Edit", "编辑", "編輯", "編集", "편집", "Sửa", "แก้ไข"),
  remove: L("Delete", "删除", "刪除", "削除", "삭제", "Xóa", "ลบ"),
  confirmRemove: L("Tap again to delete", "再点一次确认删除", "再點一次確認刪除", "もう一度押すと削除", "한 번 더 누르면 삭제", "Bấm lần nữa để xóa", "แตะอีกครั้งเพื่อลบ"),
  save: L("Save", "保存", "儲存", "保存", "저장", "Lưu", "บันทึก"),
  cancel: L("Cancel", "取消", "取消", "キャンセル", "취소", "Hủy", "ยกเลิก"),
  label: L("Profile name", "档案名称", "檔案名稱", "プロフィール名", "프로필 이름", "Tên hồ sơ", "ชื่อโปรไฟล์"),
  relation: L("Relationship", "关系", "關係", "関係", "관계", "Quan hệ", "ความสัมพันธ์"),
  name: L("Name (optional)", "姓名（可选）", "姓名（選填）", "氏名（任意）", "이름(선택)", "Họ tên (không bắt buộc)", "ชื่อ (ไม่บังคับ)"),
  date: L("Birth date", "出生日期", "出生日期", "生年月日", "생년월일", "Ngày sinh", "วันเกิด"),
  time: L("Birth time", "出生时间", "出生時間", "生まれた時刻", "출생 시각", "Giờ sinh", "เวลาเกิด"),
  calendar: L("Calendar", "历法", "曆法", "暦", "역법", "Lịch", "ปฏิทิน"),
  solar: L("Solar", "公历", "公曆", "新暦", "양력", "Dương lịch", "สุริยคติ"),
  lunar: L("Lunar", "农历", "農曆", "旧暦", "음력", "Âm lịch", "จันทรคติ"),
  gender: L("Gender", "性别", "性別", "性別", "성별", "Giới tính", "เพศ"),
  male: L("Male", "男", "男", "男性", "남", "Nam", "ชาย"),
  female: L("Female", "女", "女", "女性", "여", "Nữ", "หญิง"),
  place: L("Birthplace (city)", "出生地（城市）", "出生地（城市）", "出生地（都市）", "출생지(도시)", "Nơi sinh (thành phố)", "สถานที่เกิด (เมือง)"),
  consent: L("This person agreed that I may save their birth details here.", "我已获得对方同意，在这里保存其出生资料。", "我已獲得對方同意，在這裡儲存其出生資料。", "この方の同意を得て、生年月日などをここに保存します。", "이 사람의 동의를 받아 출생 정보를 여기에 저장합니다.", "Người này đã đồng ý để tôi lưu thông tin ngày sinh ở đây.", "บุคคลนี้ยินยอมให้ฉันบันทึกข้อมูลวันเกิดไว้ที่นี่"),
  consentNeeded: L("Please confirm this person's agreement first.", "请先确认已获得对方同意。", "請先確認已獲得對方同意。", "先にご本人の同意を確認してください。", "먼저 본인의 동의를 확인해 주세요.", "Vui lòng xác nhận đã có sự đồng ý của người đó.", "โปรดยืนยันว่าได้รับความยินยอมแล้ว"),
  invalid: L("Enter a profile name and a birth date.", "请填写档案名称和出生日期。", "請填寫檔案名稱和出生日期。", "プロフィール名と生年月日を入力してください。", "프로필 이름과 생년월일을 입력해 주세요.", "Hãy nhập tên hồ sơ và ngày sinh.", "กรอกชื่อโปรไฟล์และวันเกิด"),
  emptyProfiles: L("No profiles yet.", "还没有档案。", "還沒有檔案。", "まだプロフィールはありません。", "아직 프로필이 없습니다.", "Chưa có hồ sơ.", "ยังไม่มีโปรไฟล์"),
  reportsTitle: L("My reports", "我的报告", "我的報告", "マイレポート", "내 보고서", "Báo cáo của tôi", "รายงานของฉัน"),
  reportsLead: L("Every reading you unlocked stays here for good. Filter by person, method or date, add your own notes, and ask a follow-up in the same context.", "解锁过的每份报告都长期保存在这里。可按人物、方法和日期筛选，写下自己的笔记，并在原报告语境中继续追问。", "解鎖過的每份報告都長期保存在這裡。可按人物、方法和日期篩選，寫下自己的筆記，並在原報告語境中繼續追問。", "解除したレポートはすべてここに保存されます。人物・方法・日付で絞り込み、メモを残し、同じ文脈で追加質問できます。", "열어 본 모든 보고서가 여기에 계속 보관됩니다. 인물, 방법, 날짜로 걸러 보고 메모를 남기며 같은 맥락에서 추가 질문할 수 있습니다.", "Mọi bài giải đã mở đều được lưu lâu dài tại đây. Lọc theo người, phương pháp hoặc ngày, ghi chú riêng và hỏi tiếp trong cùng ngữ cảnh.", "รายงานทุกฉบับที่ปลดล็อกจะเก็บไว้ที่นี่ตลอด กรองตามบุคคล วิธี หรือวันที่ จดบันทึกของคุณ และถามต่อในบริบทเดิมได้"),
  everyone: L("Everyone", "全部人物", "全部人物", "全員", "모든 사람", "Mọi người", "ทุกคน"),
  allMethods: L("All methods", "全部方法", "全部方法", "すべての方法", "모든 방법", "Mọi phương pháp", "ทุกวิธี"),
  anyTime: L("Any time", "全部时间", "全部時間", "すべての期間", "전체 기간", "Mọi thời gian", "ทุกช่วงเวลา"),
  last30: L("Last 30 days", "最近 30 天", "最近 30 天", "直近30日", "최근 30일", "30 ngày qua", "30 วันล่าสุด"),
  thisYear: L("This year", "今年", "今年", "今年", "올해", "Năm nay", "ปีนี้"),
  unnamed: L("(no name)", "（未填姓名）", "（未填姓名）", "（名前なし）", "(이름 없음)", "(không tên)", "(ไม่มีชื่อ)"),
  noReports: L("No reports yet. Unlock a full reading and it will be kept here.", "还没有报告。解锁完整解读后会自动保存在这里。", "還沒有報告。解鎖完整解讀後會自動保存在這裡。", "まだレポートはありません。完全版を解除すると、ここに保存されます。", "아직 보고서가 없습니다. 전체 해설을 열면 여기에 보관됩니다.", "Chưa có báo cáo. Mở bài giải đầy đủ và nó sẽ được lưu ở đây.", "ยังไม่มีรายงาน ปลดล็อกคำอธิบายฉบับเต็มแล้วจะเก็บไว้ที่นี่"),
  noMatch: L("No reports match these filters.", "没有符合筛选条件的报告。", "沒有符合篩選條件的報告。", "条件に合うレポートはありません。", "조건에 맞는 보고서가 없습니다.", "Không có báo cáo phù hợp bộ lọc.", "ไม่มีรายงานที่ตรงกับตัวกรอง"),
  open: L("Open", "打开", "打開", "開く", "열기", "Mở", "เปิด"),
  back: L("Back to the list", "返回列表", "返回列表", "一覧に戻る", "목록으로", "Về danh sách", "กลับไปที่รายการ"),
  question: L("Question", "所问", "所問", "質問", "질문", "Câu hỏi", "คำถาม"),
  notes: L("My notes", "我的笔记", "我的筆記", "マイメモ", "내 메모", "Ghi chú của tôi", "บันทึกของฉัน"),
  notesHint: L("Write down what you noticed, so you can compare later.", "写下你的观察，之后回来对照。", "寫下你的觀察，之後回來對照。", "気づいたことを書いておけば、あとで見比べられます。", "느낀 점을 적어 두면 나중에 비교할 수 있어요.", "Ghi lại điều bạn nhận thấy để sau này đối chiếu.", "จดสิ่งที่สังเกตไว้ แล้วกลับมาเทียบภายหลัง"),
  saved: L("Saved", "已保存", "已儲存", "保存しました", "저장됨", "Đã lưu", "บันทึกแล้ว"),
  followUp: L("Ask a follow-up about this report", "就这份报告继续追问", "就這份報告繼續追問", "このレポートについて追加で質問", "이 보고서에 대해 추가 질문", "Hỏi tiếp về báo cáo này", "ถามต่อเกี่ยวกับรายงานนี้"),
  followUpHint: L("For example: what should I pay attention to next month?", "例如：下个月我应该注意什么？", "例如：下個月我應該注意什麼？", "例：来月は何に気をつけるとよいですか？", "예: 다음 달에는 무엇에 주의하면 좋을까요?", "Ví dụ: tháng sau tôi nên chú ý điều gì?", "เช่น เดือนหน้าควรระวังเรื่องอะไร"),
  ask: L("Ask · 20 credits", "提问 · 20 积分", "提問 · 20 積分", "質問する · 20 クレジット", "질문 · 20 크레딧", "Hỏi · 20 điểm", "ถาม · 20 เครดิต"),
  asking: L("Writing the answer…", "正在生成回答…", "正在產生回答…", "回答を作成中…", "답변 작성 중…", "Đang viết câu trả lời…", "กำลังเขียนคำตอบ…"),
  noChart: L("This older report was saved before charts were kept, so follow-ups are not available for it.", "这份较早的报告保存时还没有记录命盘，所以无法继续追问。", "這份較早的報告保存時還沒有記錄命盤，所以無法繼續追問。", "この古いレポートは命盤を保存する前のものなので、追加質問はできません。", "이 예전 보고서는 명반을 저장하기 전에 만들어져 추가 질문을 할 수 없습니다.", "Báo cáo cũ này được lưu khi chưa lưu lá số, nên không thể hỏi tiếp.", "รายงานเก่านี้บันทึกก่อนมีการเก็บผัง จึงถามต่อไม่ได้"),
  lowCredits: L("Not enough credits. Buy credits to continue.", "积分不足，请先购买积分。", "積分不足，請先購買積分。", "クレジットが足りません。購入してください。", "크레딧이 부족합니다. 먼저 구매해 주세요.", "Không đủ điểm. Hãy mua thêm điểm.", "เครดิตไม่พอ โปรดซื้อเครดิตก่อน"),
  failed: L("The answer could not be written just now. Please try again.", "暂时无法生成回答，请稍后再试。", "暫時無法產生回答，請稍後再試。", "いま回答を作成できませんでした。もう一度お試しください。", "지금은 답변을 만들 수 없습니다. 다시 시도해 주세요.", "Hiện chưa viết được câu trả lời. Vui lòng thử lại.", "ตอนนี้เขียนคำตอบไม่ได้ โปรดลองอีกครั้ง"),
  privacyTitle: L("Privacy and my data", "隐私与我的数据", "隱私與我的資料", "プライバシーとデータ", "개인정보와 내 데이터", "Quyền riêng tư và dữ liệu", "ความเป็นส่วนตัวและข้อมูลของฉัน"),
  privacyLead: L("See everything stored about you, or delete it. Credit and purchase records are kept for accounting and refunds.", "查看或删除我们为你保存的资料。积分与购买记录会保留，用于对账和退款。", "查看或刪除我們為你保存的資料。積分與購買紀錄會保留，用於對帳和退款。", "保存されている内容を確認・削除できます。クレジットと購入の記録は会計と返金のため保持されます。", "저장된 정보를 확인하거나 삭제할 수 있습니다. 크레딧과 구매 기록은 정산과 환불을 위해 보관됩니다.", "Xem hoặc xóa dữ liệu chúng tôi lưu về bạn. Hồ sơ điểm và mua hàng được giữ lại để đối soát và hoàn tiền.", "ดูหรือลบข้อมูลที่เราเก็บเกี่ยวกับคุณ ประวัติเครดิตและการซื้อจะเก็บไว้เพื่อการบัญชีและการคืนเงิน"),
  download: L("Download my data (JSON)", "下载我的数据（JSON）", "下載我的資料（JSON）", "データをダウンロード（JSON）", "내 데이터 다운로드(JSON)", "Tải dữ liệu của tôi (JSON)", "ดาวน์โหลดข้อมูลของฉัน (JSON)"),
  deleteTitle: L("Delete", "删除", "刪除", "削除", "삭제", "Xóa", "ลบ"),
  scopeReports: L("All reports and their notes", "全部报告及其笔记", "全部報告及其筆記", "すべてのレポートとメモ", "모든 보고서와 메모", "Tất cả báo cáo và ghi chú", "รายงานทั้งหมดและบันทึก"),
  scopeProfiles: L("All saved profiles", "全部档案", "全部檔案", "保存したプロフィール", "저장된 모든 프로필", "Tất cả hồ sơ đã lưu", "โปรไฟล์ทั้งหมด"),
  scopeNotes: L("All notes", "全部笔记", "全部筆記", "すべてのメモ", "모든 메모", "Tất cả ghi chú", "บันทึกทั้งหมด"),
  scopeShelf: L("Bookshelf and reading progress", "书架与阅读进度", "書架與閱讀進度", "本棚と読書の進み具合", "책장과 읽기 진도", "Tủ sách và tiến độ đọc", "ชั้นหนังสือและความคืบหน้าการอ่าน"),
  deleteButton: L("Delete selected", "删除所选", "刪除所選", "選んだ項目を削除", "선택 항목 삭제", "Xóa mục đã chọn", "ลบรายการที่เลือก"),
  deleteConfirm: L("This cannot be undone. Tap again to delete.", "删除后无法恢复，再点一次确认。", "刪除後無法恢復，再點一次確認。", "元に戻せません。もう一度押すと削除します。", "삭제하면 되돌릴 수 없습니다. 한 번 더 누르세요.", "Không thể hoàn tác. Bấm lần nữa để xóa.", "ลบแล้วกู้คืนไม่ได้ แตะอีกครั้งเพื่อยืนยัน"),
  deleted: L("Deleted.", "已删除。", "已刪除。", "削除しました。", "삭제했습니다.", "Đã xóa.", "ลบแล้ว"),
  account: L("To close your account entirely, contact us through the icons at the bottom of the page.", "如需注销账户，请通过页面底部的联系方式联系我们。", "如需註銷帳戶，請透過頁面底部的聯絡方式聯絡我們。", "アカウントを完全に閉じたい場合は、ページ下部の連絡先からご連絡ください。", "계정을 완전히 닫으려면 페이지 하단의 연락처로 문의해 주세요.", "Để đóng hẳn tài khoản, hãy liên hệ qua các biểu tượng ở cuối trang.", "หากต้องการปิดบัญชี โปรดติดต่อผ่านไอคอนที่ด้านล่างของหน้า"),
  termTitle: L("Solar-term e-mail", "节气提醒邮件", "節氣提醒郵件", "節気のお知らせメール", "절기 알림 메일", "Email báo tiết khí", "อีเมลแจ้งสารท"),
  termLead: L("One short e-mail on the day each of the 24 solar terms begins, with a link to that day's almanac.", "二十四节气交节当天发一封简短邮件，附当天黄历链接。", "二十四節氣交節當天發一封簡短郵件，附當天黃曆連結。", "二十四節気が始まる日に、その日の暦へのリンク付きで短いメールをお送りします。", "24절기가 시작되는 날 그날 황력 링크와 함께 짧은 메일을 보내 드립니다.", "Một email ngắn vào ngày bắt đầu mỗi tiết khí trong 24 tiết khí, kèm liên kết lịch hôm đó.", "อีเมลสั้น ๆ ในวันที่แต่ละสารทในยี่สิบสี่สารทเริ่มต้น พร้อมลิงก์ปฏิทินของวันนั้น"),
  creditsNote: L("Credits do not expire. Purchases, gifts, readings and refunds are all listed here.", "积分没有有效期。充值、赠送、消费和退款都会记录在这里。", "積分沒有有效期。儲值、贈送、消費和退款都會記錄在這裡。", "クレジットに有効期限はありません。購入・プレゼント・利用・返金はすべてここに記録されます。", "크레딧은 만료되지 않습니다. 구매, 선물, 사용, 환불이 모두 여기에 기록됩니다.", "Điểm không có hạn sử dụng. Nạp, tặng, sử dụng và hoàn tiền đều được ghi tại đây.", "เครดิตไม่มีวันหมดอายุ การซื้อ ของขวัญ การใช้ และการคืนเงินจะบันทึกไว้ที่นี่ทั้งหมด"),
  pickProfile: L("Fill from my profiles", "从我的档案填入", "從我的檔案填入", "プロフィールから入力", "내 프로필로 채우기", "Điền từ hồ sơ", "กรอกจากโปรไฟล์"),
  saveAsProfile: L("Save these details as a profile", "把这些资料存为档案", "把這些資料存為檔案", "この内容をプロフィールに保存", "이 정보를 프로필로 저장", "Lưu thông tin này thành hồ sơ", "บันทึกข้อมูลนี้เป็นโปรไฟล์"),
  profileSaved: L("Saved to my profiles.", "已存入我的档案。", "已存入我的檔案。", "プロフィールに保存しました。", "내 프로필에 저장했습니다.", "Đã lưu vào hồ sơ.", "บันทึกในโปรไฟล์แล้ว"),
};
export const relationLabels: Record<string, L7> = {
  self: L("Me", "本人", "本人", "本人", "본인", "Bản thân", "ตัวเอง"),
  partner: L("Partner", "伴侣", "伴侶", "パートナー", "배우자·연인", "Bạn đời", "คู่ครอง"),
  child: L("Child", "子女", "子女", "子ども", "자녀", "Con", "ลูก"),
  parent: L("Parent", "父母", "父母", "親", "부모", "Cha mẹ", "พ่อแม่"),
  sibling: L("Sibling", "兄弟姐妹", "兄弟姊妹", "兄弟姉妹", "형제자매", "Anh chị em", "พี่น้อง"),
  friend: L("Friend", "朋友", "朋友", "友人", "친구", "Bạn bè", "เพื่อน"),
  other: L("Other", "其他", "其他", "その他", "기타", "Khác", "อื่น ๆ"),
};

export type Profile = { id: string; label: string; relation: string; name: string; gender: "yin" | "yang"; calendar: "solar" | "lunar"; date: string; time: string; leapMonth: boolean; place: string; location: { label: string; latitude: number; longitude: number; timezone: string } | null; consentAt: string | null };
type Reading = { title?: string; conclusion?: string; keyPoints?: string[]; summary?: string; sections?: Array<{ title: string; text: string }>; followUps?: string[] };
type Report = { id: string; tool: string; locale: string; mode: string; question: string; response: Reading; cost: number; createdAt: string; subject: string | null; hasChart?: boolean };

const post = async (path: string, body: unknown) => {
  const response = await fetch(path, { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
  return { ok: response.ok, status: response.status, body: await response.json().catch(() => ({})) as Record<string, unknown> };
};

export const methodName = (tool: string, locale: Locale) => (tool.startsWith("toolkit-") ? toolkitName(tool.slice(8) as ToolkitKey, locale) : titleForRoute(tool as AppRoute, locale) ?? tool);

/** Load the member's saved profiles (empty when signed out). */
export function useProfiles() {
  const [profiles, setProfiles] = useState<Profile[] | null>(null);
  const reload = useCallback(async () => {
    try { const response = await fetch("/api/member/profiles", { credentials: "same-origin" }); setProfiles(response.ok ? ((await response.json()) as { profiles: Profile[] }).profiles : null); } catch { setProfiles(null); }
  }, []);
  useEffect(() => { const timer = window.setTimeout(() => { void reload(); }, 0); const onMember = () => { void reload(); }; window.addEventListener("xuannova:member", onMember); window.addEventListener("xn:profiles", onMember); return () => { window.clearTimeout(timer); window.removeEventListener("xuannova:member", onMember); window.removeEventListener("xn:profiles", onMember); }; }, [reload]);
  return { profiles, setProfiles, reload };
}

const emptyDraft = { id: "", label: "", relation: "self", name: "", gender: "yang" as const, calendar: "solar" as const, date: "1990-01-01", time: "", leapMonth: false, place: "", location: null, consentAt: null, consent: false };
type Draft = Omit<Profile, "id"> & { id: string; consent: boolean };

export function ProfileEditor({ locale, initial, onSaved, onCancel }: { locale: Locale; initial?: Partial<Draft>; onSaved: (profiles: Profile[]) => void; onCancel?: () => void }) {
  const t = libraryText;
  const [draft, setDraft] = useState<Draft>({ ...emptyDraft, ...initial } as Draft);
  const [note, setNote] = useState("");
  const set = <K extends keyof Draft>(key: K, value: Draft[K]) => setDraft((current) => ({ ...current, [key]: value }));
  const save = async () => {
    if (!draft.label.trim() || !/^\d{4}-\d{2}-\d{2}$/.test(draft.date)) { setNote(t.invalid[locale]); return; }
    if (draft.relation !== "self" && !draft.consent && !draft.consentAt) { setNote(t.consentNeeded[locale]); return; }
    const result = await post(draft.id ? `/api/member/profiles/${draft.id}` : "/api/member/profiles", { ...draft, consent: draft.consent || Boolean(draft.consentAt) });
    if (result.ok) { onSaved((result.body.profiles as Profile[]) ?? []); window.dispatchEvent(new Event("xn:profiles")); }
    else setNote(result.body.code === "CONSENT_REQUIRED" ? t.consentNeeded[locale] : t.invalid[locale]);
  };
  return <div className="ml-editor">
    <div className="ml-grid">
      <label><span>{t.label[locale]}</span><input value={draft.label} maxLength={40} onChange={(event) => set("label", event.target.value)} /></label>
      <label><span>{t.relation[locale]}</span><select value={draft.relation} onChange={(event) => set("relation", event.target.value)}>{Object.keys(relationLabels).map((key) => <option key={key} value={key}>{relationLabels[key][locale]}</option>)}</select></label>
      <label><span>{t.name[locale]}</span><input value={draft.name} maxLength={60} onChange={(event) => set("name", event.target.value)} /></label>
      <label><span>{t.gender[locale]}</span><select value={draft.gender} onChange={(event) => set("gender", event.target.value as Draft["gender"])}><option value="yang">{t.male[locale]}</option><option value="yin">{t.female[locale]}</option></select></label>
      <label><span>{t.calendar[locale]}</span><select value={draft.calendar} onChange={(event) => set("calendar", event.target.value as Draft["calendar"])}><option value="solar">{t.solar[locale]}</option><option value="lunar">{t.lunar[locale]}</option></select></label>
      <label><span>{t.date[locale]}</span><input type="date" value={draft.date} onChange={(event) => set("date", event.target.value)} /></label>
      <label><span>{t.time[locale]}</span><input type="time" value={draft.time} onChange={(event) => set("time", event.target.value)} /></label>
      <label><span>{t.place[locale]}</span><input value={draft.place} maxLength={120} onChange={(event) => set("place", event.target.value)} /></label>
    </div>
    {draft.relation !== "self" && !draft.consentAt && <label className="ml-consent"><input type="checkbox" checked={draft.consent} onChange={(event) => set("consent", event.target.checked)} /> <span>{t.consent[locale]}</span></label>}
    {note && <p className="ml-note" role="alert">{note}</p>}
    <div className="ml-actions"><button type="button" className="primary-action" onClick={() => void save()}>{t.save[locale]}</button>{onCancel && <button type="button" className="text-action" onClick={onCancel}>{t.cancel[locale]}</button>}</div>
  </div>;
}

export function MemberProfiles({ locale, startAdding = false }: { locale: Locale; startAdding?: boolean }) {
  const t = libraryText;
  const { profiles, setProfiles } = useProfiles();
  const [editing, setEditing] = useState<Profile | "new-self" | "new-other" | null>(startAdding ? "new-other" : null);
  const [confirm, setConfirm] = useState<string | null>(null);
  if (profiles === null) return <section className="mc-card ml-card"><header><h3>{t.profilesTitle[locale]}</h3><p>{t.profilesLead[locale]}</p></header><p className="ml-muted">{t.profilesUnavailable[locale]}</p></section>;
  const hasSelf = profiles.some((profile) => profile.relation === "self");
  const isNew = editing === "new-self" || editing === "new-other";
  return <section className="mc-card ml-card">
    <header><h3>{t.profilesTitle[locale]}</h3><p>{t.profilesLead[locale]}</p></header>
    {profiles.length ? <ul className="ml-profiles">{profiles.map((profile) => <li key={profile.id}>
      {!isNew && editing && typeof editing === "object" && editing.id === profile.id
        ? <ProfileEditor locale={locale} initial={{ ...profile, consent: Boolean(profile.consentAt) }} onSaved={(next) => { setProfiles(next); setEditing(null); }} onCancel={() => setEditing(null)} />
        : <><div><b>{profile.label}</b><small>{relationLabels[profile.relation]?.[locale] ?? profile.relation} · {profile.date}{profile.time ? ` ${profile.time}` : ""}{profile.place ? ` · ${profile.place}` : ""}</small></div>
          <span><button type="button" className="text-action" onClick={() => setEditing(profile)}>{t.edit[locale]}</button>
          <button type="button" className="text-action ml-danger" onClick={async () => { if (confirm !== profile.id) { setConfirm(profile.id); window.setTimeout(() => setConfirm(null), 4000); return; } const result = await post(`/api/member/profiles/${profile.id}/delete`, {}); if (result.ok) { setProfiles(result.body.profiles as Profile[]); window.dispatchEvent(new Event("xn:profiles")); } setConfirm(null); }}>{confirm === profile.id ? t.confirmRemove[locale] : t.remove[locale]}</button></span></>}
    </li>)}</ul> : <p className="ml-muted">{t.emptyProfiles[locale]}</p>}
    {isNew ? <ProfileEditor locale={locale} initial={{ relation: editing === "new-self" ? "self" : "partner" }} onSaved={(next) => { setProfiles(next); setEditing(null); }} onCancel={() => setEditing(null)} />
      : <div className="ml-add-row">
        {!hasSelf && <button type="button" className="secondary-action" onClick={() => setEditing("new-self")}>+ {t.addSelf[locale]}</button>}
        <button type="button" className="secondary-action" onClick={() => setEditing("new-other")}>+ {t.addOther[locale]}</button>
      </div>}
  </section>;
}

function ReadingView({ reading }: { reading: Reading }) {
  return <div className="ml-reading">
    {reading.title && <h4>{reading.title}</h4>}
    {reading.conclusion && <p className="ml-conclusion">{reading.conclusion}</p>}
    {reading.keyPoints?.length ? <ul>{reading.keyPoints.map((point, index) => <li key={index}>{point}</li>)}</ul> : null}
    {reading.summary && <p>{reading.summary}</p>}
    {reading.sections?.map((section, index) => <section key={index}><h5>{section.title}</h5>{section.text.split("\n").filter(Boolean).map((paragraph, number) => <p key={number}>{paragraph}</p>)}</section>)}
  </div>;
}

function ReportDetail({ id, locale, onBack, notes, onNote }: { id: string; locale: Locale; onBack: () => void; notes: Record<string, string>; onNote: (ref: string, body: string) => void }) {
  const t = libraryText;
  const [report, setReport] = useState<(Report & { chart: unknown }) | null>(null);
  const [note, setNote] = useState(notes[`report:${id}`] ?? "");
  const [savedAt, setSavedAt] = useState(false);
  const [question, setQuestion] = useState("");
  const [busy, setBusy] = useState(false);
  const [answers, setAnswers] = useState<Array<{ question: string; reading: Reading }>>([]);
  const [error, setError] = useState("");
  useEffect(() => { let alive = true; void fetch(`/api/member/interpretations/${id}`, { credentials: "same-origin" }).then((response) => response.json()).then((data: { interpretation?: Report & { chart: unknown } }) => { if (alive && data.interpretation) setReport(data.interpretation); }); return () => { alive = false; }; }, [id]);
  useEffect(() => {
    if (note === (notes[`report:${id}`] ?? "")) return;
    const timer = window.setTimeout(() => { void post("/api/member/notes", { ref: `report:${id}`, body: note }).then((result) => { if (result.ok) { onNote(`report:${id}`, note); setSavedAt(true); window.setTimeout(() => setSavedAt(false), 1500); } }); }, 900);
    return () => window.clearTimeout(timer);
  }, [note, id, notes, onNote]);
  if (!report) return <section className="mc-card ml-card"><button type="button" className="text-action" onClick={onBack}>← {t.back[locale]}</button></section>;
  const ask = async () => {
    if (!question.trim() || !report.chart) return;
    setBusy(true); setError("");
    const history = [{ question: report.question, answer: [report.response.conclusion, report.response.summary].filter(Boolean).join(" ").slice(0, 1500) }, ...answers.map((item) => ({ question: item.question, answer: (item.reading.summary ?? "").slice(0, 1500) }))].slice(-10);
    const result = await post("/api/interpretations", { tool: report.tool, locale, question: question.trim(), mode: "conversation", chart: report.chart, conversationHistory: history });
    setBusy(false);
    if (result.ok && result.body.response) { setAnswers((items) => [...items, { question: question.trim(), reading: result.body.response as Reading }]); setQuestion(""); window.dispatchEvent(new CustomEvent("xuannova:member", { detail: true })); }
    else setError(result.status === 402 ? t.lowCredits[locale] : t.failed[locale]);
  };
  return <section className="mc-card ml-card ml-detail">
    <button type="button" className="text-action" onClick={onBack}>← {t.back[locale]}</button>
    <small className="ml-meta">{methodName(report.tool, locale)} · {new Date(report.createdAt).toLocaleString(locale)}{report.subject ? ` · ${report.subject}` : ""}</small>
    <p className="ml-question"><b>{t.question[locale]}:</b> {report.question}</p>
    <ReadingView reading={report.response} />
    <label className="ml-notes"><span>{t.notes[locale]} {savedAt && <em>{t.saved[locale]}</em>}</span><textarea value={note} maxLength={5000} placeholder={t.notesHint[locale]} onChange={(event) => setNote(event.target.value)} /></label>
    {answers.map((item, index) => <article key={index} className="ml-answer"><p className="ml-question"><b>{t.question[locale]}:</b> {item.question}</p><ReadingView reading={item.reading} /></article>)}
    <div className="ml-follow">
      <h4>{t.followUp[locale]}</h4>
      {report.chart ? <>
        <textarea value={question} maxLength={1000} placeholder={t.followUpHint[locale]} onChange={(event) => setQuestion(event.target.value)} />
        {error && <p className="ml-note" role="alert">{error}</p>}
        <button type="button" className="primary-action" disabled={busy || !question.trim()} onClick={() => void ask()}>{busy ? t.asking[locale] : t.ask[locale]}</button>
      </> : <p className="ml-muted">{t.noChart[locale]}</p>}
    </div>
  </section>;
}

export function MemberReports({ locale }: { locale: Locale }) {
  const t = libraryText;
  const [reports, setReports] = useState<Report[] | null>(null);
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [person, setPerson] = useState("all");
  const [method, setMethod] = useState("all");
  const [period, setPeriod] = useState("all");
  const [openId, setOpenId] = useState<string | null>(null);
  const load = useCallback(async () => {
    try {
      const [list, noteList] = await Promise.all([fetch("/api/member/interpretations", { credentials: "same-origin" }), fetch("/api/member/notes", { credentials: "same-origin" })]);
      setReports(list.ok ? ((await list.json()) as { interpretations: Report[] }).interpretations : null);
      if (noteList.ok) setNotes(Object.fromEntries(((await noteList.json()) as { notes: Array<{ ref: string; body: string }> }).notes.map((item) => [item.ref, item.body])));
    } catch { setReports(null); }
  }, []);
  useEffect(() => { const timer = window.setTimeout(() => { void load(); }, 0); return () => window.clearTimeout(timer); }, [load]);
  const onNote = useCallback((ref: string, body: string) => setNotes((current) => ({ ...current, [ref]: body })), []);
  const people = useMemo(() => [...new Set((reports ?? []).map((report) => report.subject ?? ""))], [reports]);
  const methods = useMemo(() => [...new Set((reports ?? []).map((report) => report.tool))], [reports]);
  const shown = useMemo(() => {
    const since = period === "30" ? Date.now() - 30 * 86_400_000 : period === "year" ? new Date(new Date().getFullYear(), 0, 1).getTime() : 0;
    return (reports ?? []).filter((report) => (person === "all" || (report.subject ?? "") === person) && (method === "all" || report.tool === method) && new Date(report.createdAt).getTime() >= since);
  }, [reports, person, method, period]);
  if (reports === null) return null;
  if (openId) return <ReportDetail id={openId} locale={locale} onBack={() => { setOpenId(null); void load(); }} notes={notes} onNote={onNote} />;
  return <section className="mc-card ml-card">
    <header><h3>{t.reportsTitle[locale]}</h3><p>{t.reportsLead[locale]}</p></header>
    {reports.length === 0 ? <p className="ml-muted">{t.noReports[locale]}</p> : <>
      <div className="ml-filters">
        <select value={person} onChange={(event) => setPerson(event.target.value)} aria-label={t.everyone[locale]}><option value="all">{t.everyone[locale]}</option>{people.map((name) => <option key={name} value={name}>{name || t.unnamed[locale]}</option>)}</select>
        <select value={method} onChange={(event) => setMethod(event.target.value)} aria-label={t.allMethods[locale]}><option value="all">{t.allMethods[locale]}</option>{methods.map((tool) => <option key={tool} value={tool}>{methodName(tool, locale)}</option>)}</select>
        <select value={period} onChange={(event) => setPeriod(event.target.value)} aria-label={t.anyTime[locale]}><option value="all">{t.anyTime[locale]}</option><option value="30">{t.last30[locale]}</option><option value="year">{t.thisYear[locale]}</option></select>
      </div>
      {shown.length ? <ul className="ml-reports">{shown.map((report) => <li key={report.id}><button type="button" onClick={() => setOpenId(report.id)}>
        <small>{new Date(report.createdAt).toLocaleDateString(locale)} · {methodName(report.tool, locale)}{report.subject ? ` · ${report.subject}` : ""}</small>
        <b>{report.response.title || report.question}</b>
        <span>{report.question}</span>
        {notes[`report:${report.id}`] && <em>✎ {notes[`report:${report.id}`].slice(0, 60)}</em>}
        <i>{t.open[locale]} →</i>
      </button></li>)}</ul> : <p className="ml-muted">{t.noMatch[locale]}</p>}
    </>}
  </section>;
}

export function SolarTermToggle({ locale }: { locale: Locale }) {
  const [state, setState] = useState<{ solarTerms: boolean; hasEmail: boolean; mailConfigured: boolean } | null>(null);
  useEffect(() => { void fetch("/api/member/reminders", { credentials: "same-origin" }).then((response) => (response.ok ? response.json() : null)).then((value) => setState(value)).catch(() => setState(null)); }, []);
  if (!state || !state.mailConfigured || !state.hasEmail) return null;
  return <label className="ml-term"><input type="checkbox" checked={state.solarTerms} onChange={(event) => {
    const solarTerms = event.target.checked;
    void post("/api/member/reminders", { solarTerms, timezone: Intl.DateTimeFormat().resolvedOptions().timeZone, locale }).then((result) => { if (result.ok) setState({ ...state, solarTerms }); });
  }} /> <span><b>{libraryText.termTitle[locale]}</b><small>{libraryText.termLead[locale]}</small></span></label>;
}

export function MemberPrivacy({ locale }: { locale: Locale }) {
  const t = libraryText;
  const [scopes, setScopes] = useState<string[]>([]);
  const [confirm, setConfirm] = useState(false);
  const [done, setDone] = useState(false);
  const toggle = (scope: string) => setScopes((current) => (current.includes(scope) ? current.filter((item) => item !== scope) : [...current, scope]));
  return <section className="mc-card ml-card">
    <header><h3>{t.privacyTitle[locale]}</h3><p>{t.privacyLead[locale]}</p></header>
    <a className="secondary-action ml-download" href="/api/member/export" download>{t.download[locale]}</a>
    <fieldset className="ml-scopes"><legend>{t.deleteTitle[locale]}</legend>
      {([["reports", t.scopeReports], ["profiles", t.scopeProfiles], ["notes", t.scopeNotes], ["bookshelf", t.scopeShelf]] as const).map(([scope, label]) => <label key={scope}><input type="checkbox" checked={scopes.includes(scope)} onChange={() => { toggle(scope); setConfirm(false); setDone(false); }} /> {label[locale]}</label>)}
    </fieldset>
    <button type="button" className="text-action ml-danger" disabled={!scopes.length} onClick={async () => {
      if (!confirm) { setConfirm(true); return; }
      const result = await post("/api/member/privacy/delete", { scopes });
      if (result.ok) { setDone(true); setScopes([]); setConfirm(false); window.dispatchEvent(new Event("xn:profiles")); if (scopes.includes("bookshelf")) { try { window.localStorage.removeItem("xuannova-library-shelf"); } catch { /* ignore */ } } }
    }}>{confirm ? t.deleteConfirm[locale] : t.deleteButton[locale]}</button>
    {done && <p className="ml-muted" role="status">{t.deleted[locale]}</p>}
    <p className="ml-muted">{t.account[locale]}</p>
  </section>;
}

/** Top of birth forms: fill from a saved profile, or save what was typed as a new profile. */
export function ProfilePicker({ locale, current, onPick }: { locale: Locale; current: { name: string; gender: "yin" | "yang"; calendar: string; date: string; time: string; place: string; leapMonth?: boolean; location: { label: string; latitude: number; longitude: number; timezone: string } | null }; onPick: (profile: Profile) => void }) {
  const t = libraryText;
  const { profiles, setProfiles } = useProfiles();
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  if (!profiles) return null;
  return <div className="ml-picker">
    {profiles.length > 0 && <label><span>{t.pickProfile[locale]}</span><select value="" onChange={(event) => { const profile = profiles.find((item) => item.id === event.target.value); if (profile) onPick(profile); }}>
      <option value="">—</option>{profiles.map((profile) => <option key={profile.id} value={profile.id}>{profile.label} · {relationLabels[profile.relation]?.[locale] ?? ""} · {profile.date}</option>)}
    </select></label>}
    {saving ? <ProfileEditor locale={locale} initial={{ label: current.name, name: current.name, gender: current.gender, calendar: current.calendar === "lunar" ? "lunar" : "solar", date: current.date, time: current.time, place: current.place, leapMonth: Boolean(current.leapMonth), location: current.location, relation: profiles.some((profile) => profile.relation === "self") ? "partner" : "self" }} onSaved={(next) => { setProfiles(next); setSaving(false); setSaved(true); window.setTimeout(() => setSaved(false), 2500); }} onCancel={() => setSaving(false)} />
      : <button type="button" className="text-action" onClick={() => setSaving(true)}>+ {t.saveAsProfile[locale]}</button>}
    {saved && <small role="status">{t.profileSaved[locale]}</small>}
  </div>;
}

export function openLibraryRoute(locale: Locale, route: AppRoute) {
  rememberScroll();
  window.history.pushState({ scrollY: 0 }, "", pathFor(locale, route));
  window.dispatchEvent(new Event("xn:navigate"));
}
