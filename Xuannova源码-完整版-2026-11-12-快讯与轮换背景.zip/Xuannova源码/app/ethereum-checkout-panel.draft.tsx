"use client";
/** Local UI prototype. Not mounted in production. All callbacks must enforce
 * wallet, order and chain verification; this component never calls a wallet
 * or credits an account on its own. */
import {useRef,useState} from "react";
import type {Locale} from "./site-content";
import {packageSettlement} from "../worker/multichain-policy";
import type {Hex} from "viem";

type State="idle"|"connecting"|"ready"|"approving"|"approval_pending"|"approved"|"paying"|"submitted"|"credited"|"unknown";
type Text={title:string;notice:string;connect:string;approve:string;pay:string;refresh:string;busy:string;submitted:string;credited:string;unknown:string;failed:string};
const labels:Record<Locale,Text>={
 en:{title:"Ethereum USDC checkout (test)",notice:"Wallet authorization and payment require separate confirmations. Network fees apply.",connect:"Connect wallet",approve:"Authorize USDC",pay:"Confirm payment",refresh:"Check order",busy:"Waiting for wallet…",submitted:"Transaction submitted; awaiting verification.",credited:"Payment verified; credits issued.",unknown:"Check your wallet and order before trying again.",failed:"Could not complete this step. Check the wallet and retry."},
 "zh-Hans":{title:"以太坊 USDC 支付（测试）",notice:"钱包授权与支付需要分别确认，另有网络费用。",connect:"连接钱包",approve:"授权 USDC",pay:"确认支付",refresh:"查询订单",busy:"等待钱包确认…",submitted:"交易已提交，等待核验。",credited:"付款已核验，积分已到账。",unknown:"请先检查钱包和订单，再决定是否重试。",failed:"本步骤未完成，请检查钱包后重试。"},
 "zh-Hant":{title:"以太坊 USDC 付款（測試）",notice:"錢包授權與付款需分別確認，另有網路費用。",connect:"連接錢包",approve:"授權 USDC",pay:"確認付款",refresh:"查詢訂單",busy:"等待錢包確認…",submitted:"交易已提交，等待核驗。",credited:"付款已核驗，積分已入帳。",unknown:"請先檢查錢包與訂單，再決定是否重試。",failed:"此步驟未完成，請檢查錢包後重試。"},
 ja:{title:"Ethereum USDC 決済（テスト）",notice:"承認と支払いは別々に確認します。ネットワーク手数料がかかります。",connect:"ウォレット接続",approve:"USDCを承認",pay:"支払いを確認",refresh:"注文を確認",busy:"ウォレットの確認待ち…",submitted:"送信済み。検証を待っています。",credited:"支払いを確認し、ポイントを付与しました。",unknown:"再試行前にウォレットと注文を確認してください。",failed:"完了できませんでした。ウォレットを確認してください。"},
 ko:{title:"이더리움 USDC 결제 (테스트)",notice:"승인과 결제를 각각 확인해야 하며 네트워크 수수료가 발생합니다.",connect:"지갑 연결",approve:"USDC 승인",pay:"결제 확인",refresh:"주문 확인",busy:"지갑 확인 대기 중…",submitted:"거래가 제출되어 확인을 기다립니다.",credited:"결제가 확인되어 포인트가 지급되었습니다.",unknown:"다시 시도하기 전에 지갑과 주문을 확인하세요.",failed:"완료하지 못했습니다. 지갑을 확인하세요."},
 vi:{title:"Thanh toán USDC Ethereum (thử nghiệm)",notice:"Phê duyệt và thanh toán cần xác nhận riêng; có phí mạng.",connect:"Kết nối ví",approve:"Phê duyệt USDC",pay:"Xác nhận thanh toán",refresh:"Kiểm tra đơn",busy:"Đang chờ xác nhận trong ví…",submitted:"Đã gửi giao dịch, đang chờ xác minh.",credited:"Đã xác minh thanh toán và cộng điểm.",unknown:"Kiểm tra ví và đơn hàng trước khi thử lại.",failed:"Không hoàn tất bước này; hãy kiểm tra ví."},
 th:{title:"ชำระ USDC บน Ethereum (ทดสอบ)",notice:"ต้องยืนยันการอนุมัติและการชำระแยกกัน และมีค่าธรรมเนียมเครือข่าย",connect:"เชื่อมกระเป๋า",approve:"อนุมัติ USDC",pay:"ยืนยันการชำระ",refresh:"ตรวจสอบคำสั่งซื้อ",busy:"รอการยืนยันในกระเป๋า…",submitted:"ส่งธุรกรรมแล้ว รอการตรวจสอบ",credited:"ยืนยันการชำระและเพิ่มคะแนนแล้ว",unknown:"ตรวจสอบกระเป๋าและคำสั่งซื้อก่อนลองอีกครั้ง",failed:"ขั้นตอนนี้ไม่สำเร็จ โปรดตรวจสอบกระเป๋า"},
};
type Callbacks={connect:()=>Promise<void>;approve:()=>Promise<"sufficient"|"submitted">;approvalStatus:()=>Promise<"confirmed"|"pending"|"failed">;pay:()=>Promise<{hash:Hex;recoveryRecorded:boolean}>;status:()=>Promise<"awaiting_payment"|"submitted"|"credited">};
const detail:Record<Locale,{amount:string;recipient:string;hash:string;recordFailure:string}>={
 en:{amount:"Payment amount",recipient:"Recipient",hash:"Transaction hash",recordFailure:"Payment submitted, but automatic recovery could not be recorded. Save the hash and contact support; do not pay again."},
 "zh-Hans":{amount:"支付金额",recipient:"收款地址",hash:"交易哈希",recordFailure:"付款已提交，但自动恢复记录未保存成功。请保存交易哈希并联系客服，不要再次付款。"},
 "zh-Hant":{amount:"付款金額",recipient:"收款地址",hash:"交易哈希",recordFailure:"付款已提交，但自動復原紀錄未儲存。請保存交易哈希並聯絡客服，不要再次付款。"},
 ja:{amount:"支払額",recipient:"受取先",hash:"取引ハッシュ",recordFailure:"送信済みですが復旧記録に失敗しました。ハッシュを保存してサポートに連絡し、再決済しないでください。"},
 ko:{amount:"결제 금액",recipient:"수취 주소",hash:"거래 해시",recordFailure:"결제는 제출되었으나 복구 기록에 실패했습니다. 해시를 저장하고 고객지원에 문의하며 다시 결제하지 마세요."},
 vi:{amount:"Số tiền thanh toán",recipient:"Địa chỉ nhận",hash:"Mã giao dịch",recordFailure:"Đã gửi thanh toán nhưng không lưu được bản ghi khôi phục. Hãy lưu mã, liên hệ hỗ trợ và không thanh toán lại."},
 th:{amount:"ยอดชำระ",recipient:"ที่อยู่ผู้รับ",hash:"แฮชธุรกรรม",recordFailure:"ส่งการชำระแล้วแต่บันทึกเพื่อกู้คืนไม่สำเร็จ โปรดเก็บแฮช ติดต่อฝ่ายสนับสนุน และอย่าชำระซ้ำ"},
};
export function EthereumCheckoutPanelDraft({locale,packageId,callbacks}:{locale:Locale;packageId:string;callbacks:Callbacks}) {
 const text=labels[locale],info=detail[locale],terms=packageSettlement("ethereum",packageId), [state,setState]=useState<State>("idle"),[message,setMessage]=useState(""),[hash,setHash]=useState<Hex|null>(null),lock=useRef(false);
 async function run(task:()=>Promise<void>) {if(lock.current)return;lock.current=true;try{await task();}finally{lock.current=false;}}
 const connect=()=>run(async()=>{setState("connecting");setMessage("");try{await callbacks.connect();setState("ready");}catch{setState("idle");setMessage(text.failed);}});
 const approve=()=>run(async()=>{setState("approving");setMessage("");try{const result=await callbacks.approve();setState(result==="sufficient"?"approved":"approval_pending");if(result==="submitted")setMessage(text.submitted);}catch(error){if(error instanceof Error&&error.message==="WALLET_REQUEST_REJECTED"){setState("ready");setMessage(text.failed);}else{setState("unknown");setMessage(text.unknown);}}});
 const refreshApproval=()=>run(async()=>{try{const result=await callbacks.approvalStatus();if(result==="confirmed"){setState("approved");setMessage("");}else if(result==="failed"){setState("ready");setMessage(text.failed);}else setMessage(text.submitted);}catch{setMessage(text.unknown);}});
 const pay=()=>run(async()=>{setState("paying");setMessage("");try{const result=await callbacks.pay();setHash(result.hash);setState("submitted");setMessage(result.recoveryRecorded?text.submitted:info.recordFailure);}catch(error){if(error instanceof Error&&error.message==="WALLET_REQUEST_REJECTED"){setState("approved");setMessage(text.failed);}else{setState("unknown");setMessage(text.unknown);}}});
 const refresh=()=>run(async()=>{try{const result=await callbacks.status();if(result==="credited"){setState("credited");setMessage(text.credited);}else if(result==="submitted"){setState("submitted");setMessage(text.submitted);}else{setMessage(text.unknown);}}catch{setMessage(text.failed);}});
 return <section aria-label={text.title} data-testid="ethereum-checkout-draft"><h3>{text.title}</h3><p>{text.notice}</p>
   <dl><dt>{info.amount}</dt><dd>{terms.price} USDC</dd><dt>{info.recipient}</dt><dd style={{overflowWrap:"anywhere"}}>{terms.recipient}</dd></dl>
   {state==="idle"&&<button type="button" onClick={()=>void connect()}>{text.connect}</button>}
   {state==="ready"&&<button type="button" onClick={()=>void approve()}>{text.approve}</button>}
   {state==="approved"&&<button type="button" onClick={()=>void pay()}>{text.pay}</button>}
   {state==="approval_pending"&&<button type="button" onClick={()=>void refreshApproval()}>{text.refresh}</button>}
   {(state==="submitted"||state==="unknown")&&<button type="button" onClick={()=>void refresh()}>{text.refresh}</button>}
   {(state==="connecting"||state==="approving"||state==="paying")&&<p role="status">{text.busy}</p>}
   {message&&<p role="status">{message}</p>}
   {hash&&<p style={{overflowWrap:"anywhere"}}>{info.hash}: <code>{hash}</code></p>}
 </section>;
}
