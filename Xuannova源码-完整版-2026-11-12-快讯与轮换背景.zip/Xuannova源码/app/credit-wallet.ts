export const creditPackages = [
  { id: "seed", name: "入门体验包", usdt: "4.99", credits: 20 },
  { id: "path", name: "热门套餐", usdt: "9.90", credits: 50 },
  { id: "ritual", name: "大容量套餐", usdt: "19.90", credits: 120 },
  { id: "synthesis", name: "至尊旗舰套餐", usdt: "39.90", credits: 280 },
] as const;

export type CreditWallet = { balance: number };

const walletKey = "xuanyuan-institute-credit-wallet";

export function createCreditWallet(balance = 0): CreditWallet {
  return { balance: Math.max(0, Math.floor(Number.isFinite(balance) ? balance : 0)) };
}

/** Credits per full reading: the BaZi deep reading (twice the length) costs 40, everything else 20. */
export function interpretationCost(tool: string) {
  return tool === "detail" ? 40 : 20;
}

export function spendCredits(wallet: CreditWallet, tool: string) {
  const cost = interpretationCost(tool);
  if (wallet.balance < cost) return null;
  return { cost, wallet: createCreditWallet(wallet.balance - cost) };
}

export function readCreditWallet(): CreditWallet {
  if (typeof window === "undefined") return createCreditWallet();
  try {
    const raw = window.localStorage.getItem(walletKey);
    if (!raw) return createCreditWallet();
    const value = JSON.parse(raw) as Partial<CreditWallet>;
    return typeof value.balance === "number" ? createCreditWallet(value.balance) : createCreditWallet();
  } catch {
    return createCreditWallet();
  }
}

export function saveCreditWallet(wallet: CreditWallet) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(walletKey, JSON.stringify(createCreditWallet(wallet.balance)));
}
