import { getAddress, isAddress, type Address } from "viem";

/** BSC mainnet only. Do not reuse these addresses on BSC testnet. */
export const BSC_USDC_ASSETS = {
  USDC: "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d",
  USDT: "0x55d398326f99059fF775485246999027B3197955",
  ASTER: "0x000Ae314E2A2172a039B26378814C252734f556A",
  WBNB: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
  // More coins (paid through MultiCoinCheckout once the owner allows them there). Checked on chain 2026-11-07:
  // name, symbol and decimals match, and PancakeSwap V2 has a route to USDC for each.
  CAKE: "0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82",
  BTCB: "0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c",
  WETH: "0x2170Ed0880ac9A755fd29B2688956BD959F933F8",
  USD1: "0x8d0D000Ee44948FC98c9B98A4FA4921476f08B0d",
  XRP: "0x1D2F0da169ceB9fC7B3144628dB156f3F6c60dBE",
  SOL: "0x570A5D26f7765Ecb712C0924E4De545B89fD43dF",
  DOGE: "0xbA2aE424d960c26247Dd6c32edC70B295c744C43",
  LINK: "0xF8A0BF9cF54Bb92F17374d9e9A321E6a111a51bD",
  UNI: "0xBf5140A22578168FD562DCcF235E5D43A02ce9B1",
  AAVE: "0xfb6115445Bff7b52FeB98650C87f44907E58f802",
  XAUt: "0x21cAef8A43163Eea865baeE23b9C2E327696A3bf",
  SHIB: "0x2859e4544C4bB03966803b044A93563Bd2D0DD4D",
} as const satisfies Record<string, Address>;
/** Coins beyond BNB / USDC / USDT / ASTER; shown only when the server lists them (USDC_CHECKOUT_TOKENS). */
export const EXTRA_CHECKOUT_TOKENS = ["CAKE", "BTCB", "WETH", "USD1", "XRP", "SOL", "DOGE", "LINK", "UNI", "AAVE", "XAUt", "SHIB"] as const;
/** Token decimals on BSC (most are 18; DOGE has 8 and XAUt has 6). */
export const TOKEN_DECIMALS: Record<string, number> = { DOGE: 8, XAUt: 6 };
export const tokenDecimals = (token: string) => TOKEN_DECIMALS[token] ?? 18;
/** A quote whose price is worse than the pool's small-trade price by more than this is refused (thin pools). */
export const MAX_PRICE_IMPACT_BPS = 300;
export const BSC_V2_ROUTER = "0x10ED43C718714eb63d5aA57B78B54704E256024E" as Address;
export type UsdcPaymentToken = "BNB" | "USDC" | "USDT" | "ASTER" | (typeof EXTRA_CHECKOUT_TOKENS)[number];
export type UsdcQuote = { token: UsdcPaymentToken; amountOut: bigint; estimatedInput: bigint; maxInput: bigint; path: Address[]; deadline: bigint; impactBps?: number };

/** Injected read-only DEX quote. No wallet signature or transaction occurs here. */
export async function quoteUsdcPayment(input: {
  token: UsdcPaymentToken;
  amountOut: bigint;
  chainId: number;
  nowSeconds: number;
  slippageBps: number;
  getAmountsIn: (amountOut: bigint, path: Address[]) => Promise<readonly bigint[]>;
}): Promise<UsdcQuote> {
  if (input.chainId !== 56 || input.amountOut <= 0n || !Number.isSafeInteger(input.nowSeconds) || input.nowSeconds <= 0 || !Number.isInteger(input.slippageBps) || input.slippageBps < 0 || input.slippageBps > 100) throw new Error("INVALID_QUOTE_PARAMETERS");
  const deadline = BigInt(input.nowSeconds + 120);
  if (input.token === "USDC") return { token: input.token, amountOut: input.amountOut, estimatedInput: input.amountOut, maxInput: input.amountOut, path: [], deadline };
  if (input.token !== "BNB" && (!(input.token in BSC_USDC_ASSETS) || (input.token as string) === "WBNB")) throw new Error("UNSUPPORTED_TOKEN");
  const start = input.token === "BNB" ? BSC_USDC_ASSETS.WBNB : BSC_USDC_ASSETS[input.token as Exclude<UsdcPaymentToken, "BNB">];
  const paths: Address[][] = [[start, BSC_USDC_ASSETS.USDC]];
  if (input.token !== "BNB") paths.push([start, BSC_USDC_ASSETS.WBNB, BSC_USDC_ASSETS.USDC]);
  if (input.token !== "USDT") paths.push([start, BSC_USDC_ASSETS.USDT, BSC_USDC_ASSETS.USDC]);
  const extra = (EXTRA_CHECKOUT_TOKENS as readonly string[]).includes(input.token);
  const candidates = await Promise.all(paths.map(async (path) => {
    try {
      const amounts = await input.getAmountsIn(input.amountOut, path);
      if (amounts.length !== path.length || amounts[0] <= 0n || amounts[amounts.length - 1] !== input.amountOut || !path.every((address) => isAddress(address))) return null;
      return { path: path.map((address) => getAddress(address)), estimatedInput: amounts[0] };
    } catch { return null; }
  }));
  const best = candidates.filter((item): item is NonNullable<typeof item> => item !== null).sort((a, b) => a.estimatedInput < b.estimatedInput ? -1 : a.estimatedInput > b.estimatedInput ? 1 : 0)[0];
  if (!best) throw new Error("NO_USDC_ROUTE");
  // Extra coins: compare with the same route's price for a trade 1/50 the size. A big gap means a thin pool, where
  // the member would overpay; refuse instead of quoting.
  let impactBps: number | undefined;
  if (extra) {
    const probeOut = input.amountOut / 50n;
    try {
      const probe = await input.getAmountsIn(probeOut, best.path);
      if (probe.length === best.path.length && probe[0] > 0n && probeOut > 0n && probe[probe.length - 1] === probeOut) {
        impactBps = Number((best.estimatedInput * probeOut * 10_000n) / (probe[0] * input.amountOut)) - 10_000;
        if (impactBps > MAX_PRICE_IMPACT_BPS) throw new Error("PRICE_IMPACT_TOO_HIGH");
      } else throw new Error("PRICE_IMPACT_UNAVAILABLE");
    } catch (cause) { if (cause instanceof Error && cause.message === "PRICE_IMPACT_TOO_HIGH") throw cause; throw new Error("PRICE_IMPACT_UNAVAILABLE"); }
  }
  const maxInput = (best.estimatedInput * BigInt(10_000 + input.slippageBps) + 9_999n) / 10_000n;
  return { token: input.token, amountOut: input.amountOut, estimatedInput: best.estimatedInput, maxInput, path: best.path, deadline, ...(impactBps !== undefined ? { impactBps } : {}) };
}
