// Study methods and toolkit references grouped by what the visitor wants to do. Used by the method menu,
// the home catalogue, the toolkit page and the beginner guide so all four show the same structure.
import type { Locale } from "./site-content";
import type { AppRoute, ToolkitKey } from "./study-suite";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });

export type MethodCategoryKey = "self" | "ask" | "relation" | "timing" | "space" | "mind";

export type MethodCategory = { key: MethodCategoryKey; title: L7; lead: L7; routes: AppRoute[]; tools: ToolkitKey[] };

export const methodCategories: MethodCategory[] = [
  {
    key: "self",
    title: L("Know yourself", "了解自己", "了解自己", "自分を知る", "나를 알기", "Hiểu bản thân", "รู้จักตัวเอง"),
    lead: L("Temperament, talents and life rhythm from the birth moment", "按出生时间看性格、天赋与人生节奏", "按出生時間看性格、天賦與人生節奏", "生まれた時刻から性格・才能・人生のリズムを見る", "태어난 시각으로 성격, 재능, 삶의 리듬을 봅니다", "Tính cách, thiên phú và nhịp đời theo giờ sinh", "ดูนิสัย พรสวรรค์ และจังหวะชีวิตจากเวลาเกิด"),
    routes: ["bazi", "detail", "ziwei", "qizheng", "heluo", "tieban", "xiangshu"],
    tools: ["elements", "natal"],
  },
  {
    key: "ask",
    title: L("Ask about a matter", "问一件事", "問一件事", "一つの事を問う", "한 가지 일을 묻기", "Hỏi một việc", "ถามเรื่องหนึ่ง"),
    lead: L("A specific question, cast from the present moment", "心里有具体问题，按当下起卦", "心裡有具體問題，按當下起卦", "具体的な問いを、今この時から立てる", "구체적인 질문을 지금 이 순간으로 세웁니다", "Có câu hỏi cụ thể, lập quẻ theo thời điểm hiện tại", "มีคำถามเฉพาะ ตั้งจากช่วงเวลาปัจจุบัน"),
    routes: ["liuyao", "meihua", "jinkoujue", "daliuren", "qimen", "wenshi"],
    tools: ["iching", "tarot"],
  },
  {
    key: "relation",
    title: L("Relationships", "关系与合参", "關係與合參", "関係と総合", "관계와 종합", "Quan hệ và tổng hợp", "ความสัมพันธ์และการผสาน"),
    lead: L("Two people side by side, or several methods together", "两人对照，或多法合看", "兩人對照，或多法合看", "二人を並べて、または複数の方法を合わせて", "두 사람을 나란히, 또는 여러 방법을 함께", "Hai người đối chiếu, hoặc nhiều phương pháp cùng xem", "สองคนเทียบกัน หรือหลายศาสตร์ร่วมกัน"),
    routes: ["compatibility", "hecan"],
    tools: [],
  },
  {
    key: "timing",
    title: L("Days and timing", "择日与时运", "擇日與時運", "日取りと時運", "택일과 시운", "Chọn ngày và thời vận", "ฤกษ์และจังหวะเวลา"),
    lead: L("Choosing days, the year's rhythm and the larger cycle", "挑日子、看流年、看大势", "挑日子、看流年、看大勢", "日を選び、年の流れと大きな周期を見る", "날을 고르고 한 해의 흐름과 큰 주기를 봅니다", "Chọn ngày, xem lưu niên và đại thế", "เลือกวัน ดูจังหวะของปีและรอบใหญ่"),
    routes: ["almanac", "zeri", "daily", "taiyi"],
    tools: ["time"],
  },
  {
    key: "space",
    title: L("Home and space", "家居空间", "家居空間", "住まいと空間", "주거와 공간", "Nhà ở và không gian", "บ้านและพื้นที่"),
    lead: L("Facing, house trigram and the year's flying stars", "房屋坐向、宅卦与流年飞星", "房屋坐向、宅卦與流年飛星", "家の座向・宅卦・年の飛星", "집의 좌향, 택괘, 한 해의 비성", "Tọa hướng nhà, quẻ trạch và phi tinh năm", "ทิศของบ้าน กว้าบ้าน และดาวบินประจำปี"),
    routes: ["zhuzhai"],
    tools: [],
  },
  {
    key: "mind",
    title: L("Words and inner images", "文字与心象", "文字與心象", "文字と心象", "글자와 마음의 상", "Chữ nghĩa và tâm tượng", "ตัวอักษรและภาพในใจ"),
    lead: L("Names, dreams and self-reflection", "名字、梦境与自我观照", "名字、夢境與自我觀照", "名前・夢・自己観照", "이름, 꿈, 자기 관조", "Tên gọi, giấc mơ và tự quán chiếu", "ชื่อ ความฝัน และการพินิจตนเอง"),
    routes: ["cezi", "mirror"],
    tools: ["name", "dream"],
  },
];

/** Total number of study methods shown in the menu (the toolkit references are counted separately). */
export const STUDY_METHOD_COUNT = methodCategories.reduce((sum, category) => sum + category.routes.length, 0);
export const TOOLKIT_COUNT = methodCategories.reduce((sum, category) => sum + category.tools.length, 0);

export const categoryOfRoute = (route: AppRoute) => methodCategories.find((category) => category.routes.includes(route));
export const categoryOfTool = (tool: ToolkitKey) => methodCategories.find((category) => category.tools.includes(tool));
