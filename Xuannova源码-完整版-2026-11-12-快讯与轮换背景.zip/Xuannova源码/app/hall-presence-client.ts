"use client";
// 研习殿 · 同殿共修 (browser side): one heartbeat every 30 s while the page is visible, carrying the page being
// studied; the server answers with who is online. The hall reads this store to seat the other visitors.
import { useSyncExternalStore } from "react";

export type HallVisitor = { id: string; name: string; latin: string; custom: boolean; route: string | null };
export type HallState = { self: HallVisitor | null; others: HallVisitor[]; rejected: boolean };

let state: HallState = { self: null, others: [], rejected: false };
const listeners = new Set<() => void>();
let route = "home";
let timer: ReturnType<typeof setTimeout> | undefined;
let started = false;
let lastSent = 0;

const emit = () => listeners.forEach((listener) => listener());

async function beat(name?: string) {
  if (typeof document === "undefined" || document.hidden) return;
  lastSent = Date.now();
  try {
    const response = await fetch("/api/hall/heartbeat", { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify(name === undefined ? { route } : { route, name }) });
    if (response.ok) { state = await response.json() as HallState; emit(); }
  } catch { /* offline: keep the last picture */ }
}
function schedule() {
  clearTimeout(timer);
  timer = setTimeout(() => { void beat(); schedule(); }, 30_000);
}
function start() {
  if (started || typeof window === "undefined") return;
  started = true;
  document.addEventListener("visibilitychange", () => { if (!document.hidden && Date.now() - lastSent > 10_000) { void beat(); schedule(); } });
  window.addEventListener("pagehide", () => { try { navigator.sendBeacon?.("/api/hall/leave", new Blob(["{}"], { type: "application/json" })); } catch { /* ignore */ } });
  void beat(); schedule();
}

/** Tell the hall which page this visitor is on (called by the site shell on every route change). */
export function setHallRoute(next: string) {
  route = next;
  if (!started) { start(); return; }
  if (Date.now() - lastSent > 6000) { void beat(); schedule(); }
}
/** Choose a 道号 ("" goes back to the random one). Resolves to false when the server refused the name. */
export async function setHallName(name: string) {
  await beat(name);
  return !state.rejected;
}
export function useHallPresence(): HallState {
  return useSyncExternalStore((listener) => { listeners.add(listener); start(); return () => { listeners.delete(listener); }; }, () => state, () => state);
}
