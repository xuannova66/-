"use client";

import { useEffect, useState } from "react";
import type { Locale } from "./site-content";

type RitualCopy = { eyebrow: string; title: string; steps: [string, string, string]; note: string };

const copy: Record<Locale, RitualCopy> = {
  en: { eyebrow: "Xuannova · Building the chart", title: "The board is taking form", steps: ["Orient the moment", "Resolve the source layers", "Unfold the chart"], note: "Calculation in progress · no data leaves this device" },
  "zh-Hans": { eyebrow: "Xuannova · 正在起局", title: "盘面正在显现", steps: ["校准此刻", "展开基础层", "呈现盘面"], note: "计算中 · 数据不会离开此设备" },
  "zh-Hant": { eyebrow: "Xuannova · 正在起局", title: "盤面正在顯現", steps: ["校準此刻", "展開基礎層", "呈現盤面"], note: "計算中 · 資料不會離開此裝置" },
  ja: { eyebrow: "Xuannova・盤を作成中", title: "盤面を展開しています", steps: ["時を整える", "基礎レイヤーを解く", "盤面を開く"], note: "規則で計算中・データはこの端末から出ません" },
  ko: { eyebrow: "Xuannova · 판 작성 중", title: "판면을 펼치고 있습니다", steps: ["순간을 정렬", "기초 레이어 해석", "판면 전개"], note: "계산 중 · 데이터는 이 기기를 벗어나지 않습니다" },
  vi: { eyebrow: "Xuannova · Đang lập bàn", title: "Bàn cục đang thành hình", steps: ["Định vị thời điểm", "Mở các lớp nền", "Trải bàn"], note: "Đang tính toán · dữ liệu không rời thiết bị này" },
  th: { eyebrow: "Xuannova · กำลังตั้งกระดาน", title: "กระดานกำลังก่อรูป", steps: ["กำหนดช่วงขณะ", "คลี่ชั้นข้อมูลพื้นฐาน", "เปิดกระดาน"], note: "กำลังคำนวณ · ข้อมูลไม่ออกจากอุปกรณ์นี้" },
};

export function RitualSequence({ locale, tool, onComplete }: { locale: Locale; tool: string; onComplete: () => void }) {
  const [step, setStep] = useState(0);
  const text = copy[locale];

  useEffect(() => {
    const reducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    const delays = reducedMotion ? [0, 0, 0, 0] : [220, 560, 900, 1320];
    const timers = [
      window.setTimeout(() => setStep(1), delays[0]),
      window.setTimeout(() => setStep(2), delays[1]),
      window.setTimeout(() => setStep(3), delays[2]),
      window.setTimeout(onComplete, delays[3]),
    ];
    return () => timers.forEach((timer) => window.clearTimeout(timer));
  }, [onComplete, tool]);

  return <section className="ritual-sequence" aria-live="polite" data-testid="ritual-sequence">
    <div className="ritual-orbit" aria-hidden="true"><i /><i /><i /><b>{String(Math.min(step, 3)).padStart(2, "0")}</b></div>
    <div className="ritual-copy"><p>{text.eyebrow}</p><h2>{text.title}</h2><ol>{text.steps.map((label, index) => <li key={label} className={index < step ? "complete" : index === step ? "current" : ""}><span>{String(index + 1).padStart(2, "0")}</span>{label}<i>{index < step ? "✓" : "·"}</i></li>)}</ol><small>{text.note}</small></div>
  </section>;
}
