/** Local-only controller for the draft panel. No live mounting/configuration.
 * Trusted config and authenticated member must come from the server; never
 * infer payment completion from a local hash or wallet response.
 */
import {encodeFunctionData,getAddress,parseAbi,type Address,type Hex} from "viem";
import {connectEvmForNetwork,assertEvmSession,type EvmProvider,type EvmSession} from "./evm-wallet-session.draft";
import {requestEthereumDraftApproval} from "./ethereum-token-approval.draft";
import {submitEthereumDraftCheckout} from "./ethereum-checkout-transaction.draft";
import {saveRecoveryCandidate,flushRecoveryCandidates,submitRecoveryCandidate} from "./payment-recovery-buffer.draft";
import {packageSettlement} from "../worker/multichain-policy";
import {verifyEthereumCheckoutDraft} from "./ethereum-checkout-contract-check.draft";

type StorageLike={getItem(key:string):string|null;setItem(key:string,value:string):void;removeItem(key:string):void};
type Fetcher=typeof fetch;
type Order={id:string;reference:Hex;recipient:string;amountUnits:string};
const allowanceAbi=parseAbi(["function allowance(address,address) view returns(uint256)"]);
export function createEthereumCheckoutControllerDraft(input:{provider:EvmProvider;memberId:string;packageId:string;checkout:Address;settlement:Address;wrappedNative:Address;storage:StorageLike;fetcher:Fetcher;clock:()=>number}) {
 const terms=packageSettlement("ethereum",input.packageId),checkout=getAddress(input.checkout),stable=getAddress(input.settlement);
 let session:EvmSession|null=null,order:Order|null=null,approvalHash:Hex|null=null,paymentHash:Hex|null=null,submissionUnknown=false;
 async function request(path:string,init:RequestInit) {const response=await input.fetcher(path,{...init,credentials:"same-origin"});if(!response.ok)throw new Error("ORDER_REQUEST_FAILED");return response.json() as Promise<unknown>;}
 function ready(){if(!session||!order)throw new Error("ORDER_NOT_READY");return {session,order};}
 const controller={
  async connect() {
   if(session||order||paymentHash||submissionUnknown)throw new Error("ORDER_ALREADY_STARTED");
   const next=await connectEvmForNetwork(input.provider,"ethereum");
   await verifyEthereumCheckoutDraft({provider:input.provider,session:next,checkout,settlement:stable});
   const data=await request("/api/draft/multichain-orders",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({chain:"ethereum",buyer:next.address,packageId:input.packageId})}) as Partial<Order>;
   if(typeof data.id!=="string" || !/^[a-zA-Z0-9_-]{1,128}$/.test(data.id) || typeof data.reference!=="string" || !/^0x[0-9a-fA-F]{64}$/.test(data.reference) || typeof data.recipient!=="string" || getAddress(data.recipient)!==getAddress(terms.recipient) || data.amountUnits!==terms.amountUnits.toString())throw new Error("ORDER_RESPONSE_INVALID");
   await assertEvmSession(input.provider,next);session=next;order=data as Order;
  },
  async approve():Promise<"sufficient"|"submitted"> {
   const current=ready();if(approvalHash||paymentHash||submissionUnknown)throw new Error("ACTION_PENDING");
   await verifyEthereumCheckoutDraft({provider:input.provider,session:current.session,checkout,settlement:stable});
   let result:Awaited<ReturnType<typeof requestEthereumDraftApproval>>;
   try {result=await requestEthereumDraftApproval({provider:input.provider,session:current.session,token:stable,checkout,allowedTokens:[stable],amount:terms.amountUnits,onHash:async()=>{}});}
   catch(cause){if(cause instanceof Error&&cause.message==="APPROVAL_OUTCOME_UNKNOWN_CHECK_WALLET")submissionUnknown=true;throw cause;}
   if(result.status==="already_sufficient")return "sufficient";
   approvalHash=result.hash;return "submitted";
  },
  async approvalStatus():Promise<"confirmed"|"pending"|"failed"> {
   const current=ready();if(!approvalHash)throw new Error("APPROVAL_NOT_SUBMITTED");
   await assertEvmSession(input.provider,current.session);
   const receipt=await input.provider.request({method:"eth_getTransactionReceipt",params:[approvalHash]}) as {transactionHash?:unknown;status?:unknown;to?:unknown}|null;
   if(!receipt)return "pending";
   if(typeof receipt.transactionHash!=="string"||receipt.transactionHash.toLowerCase()!==approvalHash.toLowerCase()||typeof receipt.to!=="string"||getAddress(receipt.to)!==stable)throw new Error("INVALID_APPROVAL_RECEIPT");
   if(receipt.status==="0x0"){approvalHash=null;return "failed";}
   if(receipt.status!=="0x1")throw new Error("INVALID_APPROVAL_RECEIPT");
   const data=encodeFunctionData({abi:allowanceAbi,functionName:"allowance",args:[current.session.address,checkout]});
   const value=await input.provider.request({method:"eth_call",params:[{to:stable,data},"latest"]});
   if(typeof value!=="string"||!/^0x[0-9a-fA-F]{64}$/.test(value)||BigInt(value)<terms.amountUnits)throw new Error("ALLOWANCE_NOT_CONFIRMED");
   approvalHash=null;return "confirmed";
  },
  async pay():Promise<{hash:Hex;recoveryRecorded:boolean}> {
   const current=ready();if(approvalHash||paymentHash||submissionUnknown)throw new Error("ACTION_PENDING");
   await verifyEthereumCheckoutDraft({provider:input.provider,session:current.session,checkout,settlement:stable});
   const seconds=input.clock();
   try {
    const result=await submitEthereumDraftCheckout({provider:input.provider,session:current.session,order:{id:current.order.id,reference:current.order.reference,buyer:current.session.address,packageId:input.packageId},config:{checkout,settlement:stable,wrappedNative:input.wrappedNative,allowedAssets:[],intermediates:[]},quote:{asset:stable,inputUnits:terms.amountUnits,maxInputUnits:terms.amountUnits,outputUnits:terms.amountUnits,path:[],expiresAt:seconds+120},clock:input.clock,onHash:async hash=>{
      paymentHash=hash;
      saveRecoveryCandidate(input.storage,{memberId:input.memberId,orderId:current.order.id,chain:"ethereum",transactionId:hash,createdAt:new Date(input.clock()*1000).toISOString()});
      const result=await flushRecoveryCandidates(input.storage,input.memberId,entry=>submitRecoveryCandidate(entry,input.fetcher));
      if(result.pending)throw new Error("RECOVERY_SUBMISSION_FAILED");
    }});
    paymentHash=result.hash;return result;
   } catch(cause) {if(cause instanceof Error&&cause.message==="SUBMISSION_OUTCOME_UNKNOWN_CHECK_WALLET")submissionUnknown=true;throw cause;}
  },
  async status():Promise<"awaiting_payment"|"submitted"|"credited"> {
   const current=ready(),data=await request(`/api/draft/multichain-orders/status?id=${encodeURIComponent(current.order.id)}`,{method:"GET",cache:"no-store"}) as {id?:unknown;status?:unknown};
   if(data.id!==current.order.id || !["awaiting_payment","submitted","credited"].includes(String(data.status)))throw new Error("INVALID_ORDER_STATUS");
   return data.status as "awaiting_payment"|"submitted"|"credited";
  },
 };
 // Lock synchronously before the first await to prevent double clicks from
 // creating concurrent wallet prompts, authorizations or purchases.
 let busy=false;
 async function exclusive<T>(operation:()=>Promise<T>):Promise<T>{
  if(busy)throw new Error("ACTION_PENDING");
  busy=true;try{return await operation();}finally{busy=false;}
 }
 return {...controller,connect:()=>exclusive(controller.connect),approve:()=>exclusive(controller.approve),approvalStatus:()=>exclusive(controller.approvalStatus),pay:()=>exclusive(controller.pay)};
}
