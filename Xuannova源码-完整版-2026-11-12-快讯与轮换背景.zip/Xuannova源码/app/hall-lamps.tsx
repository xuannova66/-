"use client";
// 研习殿 · 点亮祈福灯: members light a digital lamp (free at launch; the server sets any price) that glows for a day,
// with a rising-lantern animation and a share poster. Only real lamps are shown. It is a cultural, reflective
// gesture: the copy never promises that a wish will come true.
import { useCallback, useEffect, useState } from "react";
import type { Locale } from "./site-content";
import { CostLine } from "./benefits";
import { track } from "./analytics";
import { fontFor, wrap } from "./share-card";
import { dateLine, drawFooter, loadLogo, PosterPreview, shareLink, usePoster } from "./daily-posters";
import { almanacDay, todayIso } from "./almanac";
import { corners, goldFoil, mountains, rgba, seal, seeded, sparkles } from "./poster-art";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });
export type LampKind = "peace" | "study" | "health" | "career" | "love" | "family";
export type Lamp = { id: string; name: string; wish: string | null; kind: LampKind; mine: boolean; createdAt: string; expiresAt: string };
export const LAMP_KINDS: LampKind[] = ["peace", "study", "health", "career", "love", "family"];
export const LAMP_COLORS: Record<LampKind, string> = { peace: "#e8a33c", study: "#5fa8d3", health: "#6dbb7c", career: "#d9573b", love: "#e07a9a", family: "#c58f4a" };

export const lampText = {
  open: L("Light a prayer lamp", "点亮祈福灯", "點亮祈福燈", "祈りの灯をともす", "기원등 밝히기", "Thắp đèn cầu phúc", "จุดโคมอธิษฐาน"),
  lead: L("Light a lamp in the hall with a short wish. It glows for a day among fellow practitioners. Free for now.", "在殿中为自己或家人点一盏灯，写下一句心愿，与道友们的灯一同亮一天。现在点灯免费。", "在殿中為自己或家人點一盞燈，寫下一句心願，與道友們的燈一同亮一天。現在點燈免費。", "殿内に灯をともし、ひとことの願いを。道友の灯とともに一日輝きます。今は無料です。", "전각에 등을 밝히고 짧은 소원을 적어 보세요. 도우들의 등과 함께 하루 동안 빛납니다. 지금은 무료예요.", "Thắp một ngọn đèn trong điện kèm lời nguyện ngắn. Đèn sáng một ngày cùng các đạo hữu. Hiện miễn phí.", "จุดโคมในหอพร้อมคำอธิษฐานสั้น ๆ โคมจะสว่างหนึ่งวันร่วมกับเพื่อนร่วมทาง ตอนนี้จุดฟรี"),
  kinds: {
    peace: L("Peace", "平安", "平安", "平安", "평안", "Bình an", "สงบสุข"),
    study: L("Studies", "学业", "學業", "学業", "학업", "Học hành", "การเรียน"),
    health: L("Health", "健康", "健康", "健康", "건강", "Sức khỏe", "สุขภาพ"),
    career: L("Career", "事业", "事業", "仕事", "사업", "Sự nghiệp", "การงาน"),
    love: L("Love", "姻缘", "姻緣", "良縁", "인연", "Tình duyên", "ความรัก"),
    family: L("Family", "家宅", "家宅", "家族", "가정", "Gia đình", "ครอบครัว"),
  } as Record<LampKind, L7>,
  kind: L("Lamp for", "灯的心意", "燈的心意", "灯のテーマ", "등의 뜻", "Đèn cầu cho", "โคมเพื่อ"),
  wish: L("Your wish (optional, up to 40 characters)", "心愿（可不填，最多 40 字）", "心願（可不填，最多 40 字）", "願い（任意・40文字まで）", "소원 (선택, 40자 이내)", "Lời nguyện (không bắt buộc, tối đa 40 ký tự)", "คำอธิษฐาน (ไม่บังคับ ไม่เกิน 40 ตัวอักษร)"),
  wishPlaceholder: L("May my family be well", "愿家人平安顺遂", "願家人平安順遂", "家族が健やかでありますように", "가족 모두 평안하기를", "Mong gia đình bình an", "ขอให้ครอบครัวสุขสบาย"),
  name: L("Name on the lamp", "灯上署名", "燈上署名", "灯に記す名", "등에 쓸 이름", "Tên trên đèn", "ชื่อบนโคม"),
  namePlaceholder: L("Your Taoist name (optional)", "道号（可不填）", "道號（可不填）", "道号（任意）", "도호 (선택)", "Đạo hiệu (không bắt buộc)", "ฉายา (ไม่บังคับ)"),
  publicWish: L("Show my wish to fellow practitioners", "让道友看到我的心愿", "讓道友看到我的心願", "願いを道友に見せる", "도우들에게 소원 보이기", "Cho đạo hữu thấy lời nguyện", "ให้เพื่อนร่วมทางเห็นคำอธิษฐาน"),
  light: L("Light it", "点亮", "點亮", "ともす", "밝히기", "Thắp đèn", "จุดโคม"),
  lighting: L("Lighting…", "正在点灯…", "正在點燈…", "ともしています…", "밝히는 중…", "Đang thắp…", "กำลังจุด…"),
  signIn: L("Sign in to light a lamp", "登录后点灯", "登入後點燈", "サインインして灯をともす", "로그인 후 등 밝히기", "Đăng nhập để thắp đèn", "เข้าสู่ระบบเพื่อจุดโคม"),
  topUp: L("Get credits", "获取积分", "取得積分", "クレジットを入手", "크레딧 받기", "Nhận điểm", "รับเครดิต"),
  lit: L("Your lamp is lit", "你的灯已点亮", "你的燈已點亮", "灯がともりました", "등이 밝혀졌습니다", "Đèn của bạn đã sáng", "โคมของคุณสว่างแล้ว"),
  litLead: L("It glows in the hall for a day. Come back tomorrow to light a new one. May your heart stay calm and steady.", "它会在殿中亮一天，明天可以再来点一盏。愿你心安，步步踏实。", "它會在殿中亮一天，明天可以再來點一盞。願你心安，步步踏實。", "殿内で一日輝きます。明日また新しい灯を。心穏やかに、一歩ずつ。", "전각에서 하루 동안 빛납니다. 내일 또 새 등을 밝혀 보세요. 마음이 평안하기를.", "Đèn sáng trong điện một ngày, mai hãy quay lại thắp ngọn mới. Mong lòng bạn an yên.", "โคมจะสว่างในหอหนึ่งวัน พรุ่งนี้กลับมาจุดใหม่ได้ ขอให้ใจสงบและมั่นคง"),
  poster: L("Make a share poster", "生成分享海报", "產生分享海報", "シェア用ポスターを作る", "공유 포스터 만들기", "Tạo ảnh chia sẻ", "สร้างโปสเตอร์แชร์"),
  free: L("Free for now · glows for 24 hours", "限时免费 · 灯亮 24 小时", "限時免費 · 燈亮 24 小時", "期間限定で無料・24時間ともります", "한시 무료 · 24시간 밝혀집니다", "Miễn phí có thời hạn · sáng 24 giờ", "ฟรีช่วงนี้ · โคมสว่าง 24 ชั่วโมง"),
  seeIt: L("See it in the hall", "去殿中看我的灯", "去殿中看我的燈", "殿内で見る", "전각에서 보기", "Xem trong điện", "ดูในหอ"),
  close: L("Close", "关闭", "關閉", "閉じる", "닫기", "Đóng", "ปิด"),
  mine: L("My lamps", "我的灯", "我的燈", "わたしの灯", "나의 등", "Đèn của tôi", "โคมของฉัน"),
  until: L("until {d}", "亮至 {d}", "亮至 {d}", "{d}まで", "{d}까지", "đến {d}", "ถึง {d}"),
  glowing: L("Lamps glowing in the hall", "殿中灯火", "殿中燈火", "殿内の灯", "전각의 등불", "Đèn trong điện", "โคมในหอ"),
  firstLamp: L("No lamps yet this week — yours can be the first.", "本周殿中还没有灯，你可以点亮第一盏。", "本週殿中還沒有燈，你可以點亮第一盞。", "今週はまだ灯がありません。最初の一灯を。", "이번 주에는 아직 등이 없어요. 첫 등을 밝혀 보세요.", "Tuần này chưa có đèn nào — hãy thắp ngọn đầu tiên.", "สัปดาห์นี้ยังไม่มีโคม จุดโคมแรกได้เลย"),
  refusedWish: L("That wish can't be used. Please avoid links, contact details or numbers.", "这句心愿无法使用，请不要包含链接、联系方式或长数字。", "這句心願無法使用，請不要包含連結、聯絡方式或長數字。", "この願いは使えません。リンクや連絡先、長い数字は避けてください。", "이 소원은 사용할 수 없습니다. 링크·연락처·긴 숫자는 빼 주세요.", "Không dùng được lời nguyện này. Vui lòng bỏ liên kết, liên hệ hoặc số dài.", "ใช้คำอธิษฐานนี้ไม่ได้ กรุณาอย่าใส่ลิงก์ ช่องทางติดต่อ หรือตัวเลขยาว"),
  refusedName: L("That name can't be used.", "这个署名无法使用。", "這個署名無法使用。", "この名前は使えません。", "이 이름은 사용할 수 없습니다.", "Không dùng được tên này.", "ใช้ชื่อนี้ไม่ได้"),
  limit: L("You've lit 5 lamps today. Come back tomorrow.", "今天已点 5 盏灯，明天再来吧。", "今天已點 5 盞燈，明天再來吧。", "今日は5灯ともしました。また明日。", "오늘은 등 5개를 밝혔어요. 내일 다시 오세요.", "Hôm nay bạn đã thắp 5 đèn. Hẹn ngày mai.", "วันนี้จุดครบ 5 โคมแล้ว พรุ่งนี้มาใหม่นะ"),
  failed: L("The lamp could not be lit. Please try again.", "点灯没有成功，请稍后再试。", "點燈沒有成功，請稍後再試。", "灯をともせませんでした。もう一度お試しください。", "등을 밝히지 못했습니다. 다시 시도해 주세요.", "Chưa thắp được đèn. Vui lòng thử lại.", "จุดโคมไม่สำเร็จ กรุณาลองอีกครั้ง"),
  note: L("One lamp, one heartfelt wish.", "一盏灯，一份心意。", "一盞燈，一份心意。", "一つの灯に、一つの想い。", "등 하나에 마음 하나.", "Một ngọn đèn, một tấm lòng.", "หนึ่งโคม หนึ่งความตั้งใจ"),
  posterTitle: L("I lit a prayer lamp", "我在研习殿点亮了一盏灯", "我在研習殿點亮了一盞燈", "研習殿に灯をともしました", "연습전에 등을 밝혔어요", "Tôi đã thắp một ngọn đèn", "ฉันจุดโคมอธิษฐานแล้ว"),
};

/** Lamps glowing now, and whether the visitor is signed in (with balance). */
export function useHallLamps() {
  const [lamps, setLamps] = useState<Lamp[]>([]);
  const [cost, setCost] = useState(0);
  const refresh = useCallback(async () => {
    try { const response = await fetch("/api/hall/lamps", { credentials: "same-origin" }); if (response.ok) { const data = await response.json() as { lamps?: Lamp[]; cost?: number }; setLamps(data.lamps ?? []); setCost(typeof data.cost === "number" ? data.cost : 0); } } catch { /* offline */ }
  }, []);
  useEffect(() => { void refresh(); const timer = window.setInterval(() => { if (!document.hidden) void refresh(); }, 60_000); return () => window.clearInterval(timer); }, [refresh]);
  return { lamps, cost, refresh, add: (lamp: Lamp) => setLamps((items) => [lamp, ...items.filter((item) => item.id !== lamp.id)]) };
}

function LanternSvg({ color, size = 60 }: { color: string; size?: number }) {
  return <svg width={size} height={size * 1.35} viewBox="0 0 60 81" aria-hidden="true">
    <defs><radialGradient id={`lg-${color.slice(1)}`} cx="50%" cy="45%" r="60%"><stop offset="0" stopColor="#fff6d8" /><stop offset=".35" stopColor={color} /><stop offset="1" stopColor={color} stopOpacity=".75" /></radialGradient></defs>
    <line x1="30" y1="0" x2="30" y2="8" stroke="#c9a14a" strokeWidth="2" />
    <rect x="18" y="8" width="24" height="6" rx="2" fill="#c9a14a" />
    <ellipse cx="30" cy="40" rx="24" ry="27" fill={`url(#lg-${color.slice(1)})`} />
    {[-14, -5, 5, 14].map((dx) => <path key={dx} d={`M${30 + dx * 0.4} 14 Q${30 + dx * 1.35} 40 ${30 + dx * 0.4} 66`} stroke="#00000022" strokeWidth="1.2" fill="none" />)}
    <rect x="18" y="64" width="24" height="6" rx="2" fill="#c9a14a" />
    {[22, 27, 32, 37].map((x) => <line key={x} x1={x} y1="70" x2={x} y2="80" stroke="#c9a14a" strokeWidth="1.5" />)}
  </svg>;
}

async function drawLampPoster(canvas: HTMLCanvasElement, options: { locale: Locale; lamp: Lamp; link: string }) {
  const { locale, lamp, link } = options;
  const W = 1080, H = 1920;
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext("2d")!;
  const font = fontFor(locale);
  const icon = await loadLogo();
  // Night hall background
  const bg = ctx.createLinearGradient(0, 0, 0, H); bg.addColorStop(0, "#0f0c14"); bg.addColorStop(.6, "#1d1420"); bg.addColorStop(1, "#2a1a14");
  ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
  const rand = seeded(lamp.id);
  sparkles(ctx, W, 700, 90, "#fff1c8", rand);
  const moon = ctx.createRadialGradient(860, 230, 10, 860, 230, 120); moon.addColorStop(0, "rgba(255,244,214,.95)"); moon.addColorStop(.5, "rgba(255,230,180,.35)"); moon.addColorStop(1, "rgba(255,230,180,0)");
  ctx.fillStyle = moon; ctx.beginPath(); ctx.arc(860, 230, 120, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = "#fff5dc"; ctx.beginPath(); ctx.arc(860, 230, 44, 0, Math.PI * 2); ctx.fill();
  mountains(ctx, W, 1240, "#05030a", rand, 3);
  // Distant lamps drifting up
  for (let i = 0; i < 46; i += 1) {
    const x = rand() * W, y = 120 + rand() * 1000, r = 6 + rand() * 16;
    const g = ctx.createRadialGradient(x, y, 0, x, y, r * 3); g.addColorStop(0, "rgba(255,190,100,.55)"); g.addColorStop(1, "rgba(255,160,80,0)");
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r * 3, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "rgba(255,200,120,.7)"; ctx.beginPath(); ctx.ellipse(x, y, r * .7, r, 0, 0, Math.PI * 2); ctx.fill();
  }
  // The member's lantern
  const color = LAMP_COLORS[lamp.kind];
  const cx = W / 2, cy = 640;
  const halo = ctx.createRadialGradient(cx, cy, 30, cx, cy, 420); halo.addColorStop(0, "rgba(255,214,140,.55)"); halo.addColorStop(1, "rgba(255,170,90,0)");
  ctx.fillStyle = halo; ctx.beginPath(); ctx.arc(cx, cy, 420, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = "#c9a14a"; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(cx, 300); ctx.lineTo(cx, 380); ctx.stroke();
  ctx.fillStyle = "#c9a14a"; ctx.fillRect(cx - 90, 378, 180, 26); ctx.fillRect(cx - 90, 884, 180, 26);
  const body = ctx.createRadialGradient(cx, cy - 40, 20, cx, cy, 280); body.addColorStop(0, "#fff4d6"); body.addColorStop(.35, color); body.addColorStop(1, color);
  ctx.fillStyle = body; ctx.beginPath(); ctx.ellipse(cx, cy, 230, 250, 0, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = "rgba(0,0,0,.14)"; ctx.lineWidth = 4;
  for (const k of [-0.75, -0.3, 0.3, 0.75]) { ctx.beginPath(); ctx.ellipse(cx, cy, Math.abs(k) * 230, 250, 0, k < 0 ? Math.PI / 2 : -Math.PI / 2, k < 0 ? Math.PI * 1.5 : Math.PI / 2); ctx.stroke(); }
  for (let i = 0; i < 9; i += 1) { ctx.strokeStyle = "#c9a14a"; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(cx - 64 + i * 16, 910); ctx.lineTo(cx - 64 + i * 16, 990); ctx.stroke(); }
  ctx.fillStyle = "#5a1d12"; ctx.textAlign = "center"; ctx.font = `700 120px "Noto Serif SC", serif`;
  ctx.fillText(lampText.kinds[lamp.kind][locale === "zh-Hant" ? "zh-Hant" : "zh-Hans"].slice(0, 2), cx, cy + 42);
  // Text
  ctx.fillStyle = "#e9c987"; ctx.font = `500 32px ${font}`; ctx.fillText(lampText.posterTitle[locale], W / 2, 1080);
  ctx.fillStyle = "#fff3dc"; ctx.font = `600 64px ${font}`; ctx.fillText(`${lamp.name} · ${lampText.kinds[lamp.kind][locale]}`, W / 2, 1170);
  if (lamp.wish) { ctx.fillStyle = "#f2e2c4"; ctx.font = `400 40px ${font}`; wrap(ctx, `「${lamp.wish}」`, W - 200, locale, 2).forEach((line, index) => ctx.fillText(line, W / 2, 1260 + index * 54)); }
  ctx.fillStyle = "#b9a58a"; ctx.font = `400 28px ${font}`; ctx.fillText(dateLine(almanacDay(todayIso()), locale), W / 2, 1400);
  const foil = goldFoil(ctx, 0, 0, W, H);
  corners(ctx, 40, 40, W - 80, H - 80, 90, foil, 3);
  seal(ctx, cx + 250, cy - 230, 90, "祈福", rand);
  ctx.fillStyle = rgba("#e9c987", 0.9);
  drawFooter(ctx, { locale, link, ink: "#1f1b16", soft: "#6f665a", accent: "#9a6a3a", icon, panel: "rgba(250,243,228,.96)" });
}

/** The lamp button, the lighting dialog and the "my lamps" strip under the hall. */
export function HallLamps({ locale, lamps, cost, onLit, selfName, openMembership }: { locale: Locale; lamps: Lamp[]; cost: number; onLit: (lamp: Lamp) => void; selfName: string | null; openMembership: () => void }) {
  const t = lampText;
  const [open, setOpen] = useState(false);
  const [kind, setKind] = useState<LampKind>("peace");
  const [wish, setWish] = useState("");
  const [name, setName] = useState("");
  const [shown, setShown] = useState(true);
  const [busy, setBusy] = useState(false);
  const [problem, setProblem] = useState<string | null>(null);
  const [account, setAccount] = useState<{ signedIn: boolean; balance: number | null }>({ signedIn: false, balance: null });
  const [lit, setLit] = useState<Lamp | null>(null);
  const poster = usePoster();
  const mine = lamps.filter((lamp) => lamp.mine);
  const loadAccount = async () => {
    try { const response = await fetch("/api/member/me?soft=1", { credentials: "same-origin" }); const data = response.ok ? await response.json() as { member?: { balance?: number } | null } : null; setAccount({ signedIn: Boolean(data?.member), balance: typeof data?.member?.balance === "number" ? data.member.balance : null }); } catch { setAccount({ signedIn: false, balance: null }); }
  };
  const begin = () => { setOpen(true); setLit(null); setProblem(null); if (!name && selfName) setName(selfName); void loadAccount(); track("lamp_open", {}); };
  const light = async () => {
    setBusy(true); setProblem(null);
    try {
      const response = await fetch("/api/hall/lamps", { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify({ kind, wish: wish.trim(), name: name.trim(), public: shown }) });
      const data = await response.json() as { lamp?: Lamp; code?: string; member?: { balance?: number } | null };
      if (response.ok && data.lamp) {
        setLit(data.lamp); setWish("");
        if (typeof data.member?.balance === "number") setAccount({ signedIn: true, balance: data.member.balance });
        track("lamp_lit", { kind });
        return;
      }
      if (response.status === 401) { setAccount({ signedIn: false, balance: null }); return; }
      if (data.code === "INSUFFICIENT_CREDITS") { void loadAccount(); setProblem(null); return; }
      setProblem(data.code === "INVALID_WISH" ? t.refusedWish[locale] : data.code === "INVALID_NAME" ? t.refusedName[locale] : data.code === "DAILY_LIMIT" ? t.limit[locale] : t.failed[locale]);
    } catch { setProblem(t.failed[locale]); } finally { setBusy(false); }
  };
  // The new lantern joins the 3D hall when the dialog closes, so the member sees it rise.
  const close = () => { setOpen(false); if (lit) { onLit(lit); setLit(null); } };
  const short = account.signedIn && account.balance !== null && account.balance < cost;
  const until = (iso: string) => new Date(iso).toLocaleString(locale, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
  return <div className="hall-lamps">
    <div className="hall-lamps-bar">
      <button type="button" className="primary-action hall-lamp-open" onClick={begin}><span aria-hidden="true">🏮</span> {t.open[locale]}<b>→</b></button>
      <p>{t.lead[locale]}{lamps.length === 0 && <><br /><small>{t.firstLamp[locale]}</small></>}</p>
    </div>
    {mine.length > 0 && <ul className="hall-lamps-mine" aria-label={t.mine[locale]}>
      {mine.slice(0, 6).map((lamp) => <li key={lamp.id} style={{ ["--lamp" as string]: LAMP_COLORS[lamp.kind] }}><i aria-hidden="true" /><b>{t.kinds[lamp.kind][locale]}</b>{lamp.wish && <span>「{lamp.wish}」</span>}<small>{t.until[locale].replace("{d}", until(lamp.expiresAt))}</small></li>)}
    </ul>}
    {open && !poster.image && <div className="poster-overlay" role="presentation" onClick={(event) => { if (event.target === event.currentTarget && !busy) close(); }}>
      <div className={`lamp-dialog${lit ? " is-lit" : ""}`} role="dialog" aria-modal="true" aria-label={t.open[locale]}>
        <button type="button" className="sample-close" onClick={close} aria-label={t.close[locale]}>×</button>
        {lit ? <>
          <div className="lamp-rise" aria-hidden="true">
            {Array.from({ length: 14 }, (_, index) => <i key={index} style={{ ["--d" as string]: `${(index * 0.37) % 2.4}s`, ["--x" as string]: `${(index * 37) % 100}%` }} />)}
            <div className="lamp-rise-lantern"><LanternSvg color={LAMP_COLORS[lit.kind]} size={90} /></div>
          </div>
          <h3>{t.lit[locale]}</h3>
          <p>{lit.name} · {t.kinds[lit.kind][locale]}{lit.wish ? ` · 「${lit.wish}」` : ""}</p>
          <p className="lamp-muted">{t.litLead[locale]}</p>
          <button type="button" className="primary-action" disabled={poster.busy} onClick={() => void poster.make(async (canvas) => { await drawLampPoster(canvas, { locale, lamp: lit, link: await shareLink(locale, "lamp-card") }); track("lamp_poster", {}); }, "lamp-card")}>{t.poster[locale]}<b>↗</b></button>
          <button type="button" className="text-action" onClick={close}>{t.seeIt[locale]}</button>
        </> : <>
          <div className="lamp-dialog-head"><LanternSvg color={LAMP_COLORS[kind]} size={54} /><div><h3>{t.open[locale]}</h3><p className="lamp-muted">{t.lead[locale]}</p></div></div>
          <fieldset className="lamp-kinds"><legend>{t.kind[locale]}</legend>
            {LAMP_KINDS.map((item) => <button type="button" key={item} className={item === kind ? "is-on" : ""} aria-pressed={item === kind} style={{ ["--lamp" as string]: LAMP_COLORS[item] }} onClick={() => setKind(item)}><i aria-hidden="true" />{t.kinds[item][locale]}</button>)}
          </fieldset>
          <label className="lamp-field"><span>{t.wish[locale]}</span><textarea value={wish} maxLength={40} rows={2} placeholder={t.wishPlaceholder[locale]} onChange={(event) => setWish(event.target.value)} /><small>{[...wish].length}/40</small></label>
          <label className="lamp-field"><span>{t.name[locale]}</span><input value={name} maxLength={10} placeholder={t.namePlaceholder[locale]} onChange={(event) => setName(event.target.value)} /></label>
          <label className="lamp-check"><input type="checkbox" checked={shown} onChange={(event) => setShown(event.target.checked)} /> {t.publicWish[locale]}</label>
          {cost > 0 ? <CostLine locale={locale} cost={cost} balance={account.signedIn ? account.balance : null} /> : <p className="lamp-free">{t.free[locale]}</p>}
          {problem && <p className="lamp-problem" role="alert">{problem}</p>}
          {!account.signedIn ? <button type="button" className="primary-action" onClick={() => { setOpen(false); openMembership(); }}>{t.signIn[locale]}<b>→</b></button>
            : short ? <button type="button" className="primary-action" onClick={() => { setOpen(false); openMembership(); }}>{t.topUp[locale]}<b>→</b></button>
              : <button type="button" className="primary-action" disabled={busy} onClick={() => void light()}>{busy ? t.lighting[locale] : `🏮 ${t.light[locale]}`}<b>→</b></button>}
          <small className="lamp-muted">{t.note[locale]}</small>
        </>}
      </div>
    </div>}
    {poster.image && <PosterPreview locale={locale} image={poster.image} name="xuannova-prayer-lamp.png" source="lamp-card" onClose={poster.clear} />}
  </div>;
}

export { LanternSvg };
