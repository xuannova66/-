"use client";
// Forgot password (request a link) and reset password (from ?reset=<token>), in seven languages.
import { useEffect, useState } from "react";
import type { Locale } from "./site-content";
import { contactConfig } from "./contact-config";
import { serverErrorText } from "./server-errors";

type Copy = { forgot: string; title: string; email: string; send: string; sent: string; noEmail: string; resetTitle: string; newPassword: string; save: string; done: string; cancel: string };
const copy: Record<Locale, Copy> = {
  en: { forgot: "Forgot password?", title: "Reset your password", email: "Account email", send: "Send reset link", sent: "If this email has an account, a reset link is on its way. It works once, for 30 minutes.", noEmail: "Email reset is not available yet. Write to {email} from your account email and we will send you a reset link.", resetTitle: "Set a new password", newPassword: "New password (6–128 characters)", save: "Save new password", done: "Password changed. You can sign in with the new password now.", cancel: "Cancel" },
  "zh-Hans": { forgot: "忘记密码？", title: "重置密码", email: "账户邮箱", send: "发送重置链接", sent: "如果该邮箱已注册，重置链接已发出。链接 30 分钟内有效，只能使用一次。", noEmail: "暂未开通邮件重置。请用账户邮箱写信到 {email}，我们会发给你重置链接。", resetTitle: "设置新密码", newPassword: "新密码（6–128 个字符）", save: "保存新密码", done: "密码已修改，现在可以用新密码登录。", cancel: "取消" },
  "zh-Hant": { forgot: "忘記密碼？", title: "重設密碼", email: "帳戶信箱", send: "寄送重設連結", sent: "如果該信箱已註冊，重設連結已寄出。連結 30 分鐘內有效，只能使用一次。", noEmail: "暫未開通郵件重設。請用帳戶信箱寫信到 {email}，我們會寄給你重設連結。", resetTitle: "設定新密碼", newPassword: "新密碼（6–128 個字元）", save: "儲存新密碼", done: "密碼已修改，現在可以用新密碼登入。", cancel: "取消" },
  ja: { forgot: "パスワードをお忘れですか？", title: "パスワードの再設定", email: "アカウントのメールアドレス", send: "再設定リンクを送る", sent: "このメールアドレスのアカウントがあれば、再設定リンクを送信しました。有効期限は 30 分、1 回のみ使えます。", noEmail: "メールでの再設定はまだ利用できません。アカウントのメールアドレスから {email} までご連絡ください。再設定リンクをお送りします。", resetTitle: "新しいパスワードを設定", newPassword: "新しいパスワード（6〜128 文字）", save: "新しいパスワードを保存", done: "パスワードを変更しました。新しいパスワードでサインインできます。", cancel: "キャンセル" },
  ko: { forgot: "비밀번호를 잊으셨나요?", title: "비밀번호 재설정", email: "계정 이메일", send: "재설정 링크 보내기", sent: "이 이메일로 가입된 계정이 있으면 재설정 링크를 보냈습니다. 30분 동안 한 번만 사용할 수 있습니다.", noEmail: "이메일 재설정은 아직 지원되지 않습니다. 계정 이메일로 {email}에 연락하시면 재설정 링크를 보내드립니다.", resetTitle: "새 비밀번호 설정", newPassword: "새 비밀번호 (6~128자)", save: "새 비밀번호 저장", done: "비밀번호가 변경되었습니다. 새 비밀번호로 로그인하세요.", cancel: "취소" },
  vi: { forgot: "Quên mật khẩu?", title: "Đặt lại mật khẩu", email: "Email tài khoản", send: "Gửi liên kết đặt lại", sent: "Nếu email này có tài khoản, liên kết đặt lại đã được gửi. Liên kết dùng được một lần trong 30 phút.", noEmail: "Chưa hỗ trợ đặt lại qua email. Hãy dùng email tài khoản viết cho {email}, chúng tôi sẽ gửi liên kết đặt lại.", resetTitle: "Đặt mật khẩu mới", newPassword: "Mật khẩu mới (6–128 ký tự)", save: "Lưu mật khẩu mới", done: "Đã đổi mật khẩu. Bạn có thể đăng nhập bằng mật khẩu mới.", cancel: "Hủy" },
  th: { forgot: "ลืมรหัสผ่าน?", title: "รีเซ็ตรหัสผ่าน", email: "อีเมลบัญชี", send: "ส่งลิงก์รีเซ็ต", sent: "หากอีเมลนี้มีบัญชี เราได้ส่งลิงก์รีเซ็ตแล้ว ใช้ได้ครั้งเดียวภายใน 30 นาที", noEmail: "ยังไม่รองรับการรีเซ็ตทางอีเมล โปรดใช้อีเมลบัญชีเขียนถึง {email} แล้วเราจะส่งลิงก์รีเซ็ตให้", resetTitle: "ตั้งรหัสผ่านใหม่", newPassword: "รหัสผ่านใหม่ (6–128 ตัวอักษร)", save: "บันทึกรหัสผ่านใหม่", done: "เปลี่ยนรหัสผ่านแล้ว เข้าสู่ระบบด้วยรหัสผ่านใหม่ได้เลย", cancel: "ยกเลิก" },
};

async function post(path: string, body: unknown) {
  const response = await fetch(path, { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
  const payload = await response.json().catch(() => ({})) as { error?: string; emailEnabled?: boolean };
  if (!response.ok) throw new Error(payload.error ?? "");
  return payload;
}

export function PasswordReset({ locale }: { locale: Locale }) {
  const text = copy[locale];
  const [mode, setMode] = useState<"closed" | "forgot" | "reset">("closed");
  const [token, setToken] = useState("");
  const [value, setValue] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    const timer = window.setTimeout(() => {
      const found = new URLSearchParams(window.location.search).get("reset");
      if (found) { setToken(found); setMode("reset"); }
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);
  const run = async (action: () => Promise<string>) => {
    setBusy(true); setNotice("");
    try { setNotice(await action()); } catch (cause) { setNotice(serverErrorText((cause as Error).message, locale)); } finally { setBusy(false); }
  };
  if (mode === "closed") return <button type="button" className="text-action mc-forgot" onClick={() => { setMode("forgot"); setNotice(""); }}>{text.forgot}</button>;
  return <form className="mc-reset" onSubmit={(event) => {
    event.preventDefault();
    if (mode === "forgot") void run(async () => { const result = await post("/api/auth/forgot", { email: value, locale }); return result.emailEnabled ? text.sent : text.noEmail.replace("{email}", contactConfig.supportEmail); });
    else void run(async () => {
      await post("/api/auth/reset", { token, password: value });
      const url = new URL(window.location.href); url.searchParams.delete("reset"); window.history.replaceState(null, "", url.pathname + url.search + url.hash);
      setValue(""); setToken("");
      return text.done;
    });
  }}>
    <h4>{mode === "forgot" ? text.title : text.resetTitle}</h4>
    <label className="mc-field"><span>{mode === "forgot" ? text.email : text.newPassword}</span>
      <input type={mode === "forgot" ? "email" : "password"} required minLength={mode === "forgot" ? undefined : 6} maxLength={mode === "forgot" ? 254 : 128} autoComplete={mode === "forgot" ? "email" : "new-password"} value={value} onChange={(event) => setValue(event.target.value)} /></label>
    <div className="mc-reset-actions">
      <button type="submit" className="primary-action" disabled={busy || (mode === "reset" && !token)}>{mode === "forgot" ? text.send : text.save}<b>↗</b></button>
      <button type="button" className="text-action" onClick={() => { setMode("closed"); setValue(""); }}>{text.cancel}</button>
    </div>
    {notice && <p className="mc-inline is-info" role="status">{notice}</p>}
  </form>;
}
