"use client";
// Floor-plan feng shui: the visitor picks a floor-plan image (it stays in the browser and is never uploaded),
// says which side of the drawing is the front of the house, and marks each of the nine sectors with a room.
// Each room is then read against the Eight Mansions directions and this year's flying star for that sector.
import { useEffect, useMemo, useState } from "react";
import type { Locale } from "./site-content";
import type { BoardCell } from "./chart-model";
import { localizeBoardTerm } from "./complete-chart-board";

const DIRS = ["North", "Northeast", "East", "Southeast", "South", "Southwest", "West", "Northwest"] as const;
const GOOD = new Set(["生气", "天医", "延年", "伏位"]);
type Side = "top" | "right" | "bottom" | "left";
type Room = "" | "door" | "master" | "bedroom" | "study" | "living" | "dining" | "kitchen" | "bathroom" | "storage";
const ROOMS: Room[] = ["", "door", "master", "bedroom", "study", "living", "dining", "kitchen", "bathroom", "storage"];
// Rooms people use for rest, work and arrival are traditionally placed in favourable sectors; kitchens,
// bathrooms and storage are traditionally placed in unfavourable ones ("pressing down" the unfavourable).
const WANTS_GOOD = new Set<Room>(["door", "master", "bedroom", "study", "living", "dining"]);
// Drawing positions clockwise from the top, and the grid cell (row, col) for each; the centre is separate.
const POSITIONS: Array<[number, number]> = [[0, 1], [0, 2], [1, 2], [2, 2], [2, 1], [2, 0], [1, 0], [0, 0]];
const SIDE_INDEX: Record<Side, number> = { top: 0, right: 2, bottom: 4, left: 6 };

type Copy = { title: string; lead: string; pick: string; privacy: string; front: string; sides: Record<Side, string>; mark: string; rooms: Record<Room, string>; centre: string; result: string; room: string; fit: string; misfit: string; neutral: string; sector: string; personal: string; star: string; advice: string; remove: string };
const copy: Record<Locale, Copy> = {
  en: { title: "Floor plan", lead: "Add a floor plan to see which direction each room falls in.", pick: "Choose a floor-plan image", privacy: "The image stays in your browser and is never uploaded.", front: "Which side of the drawing is the front (facing side) of the house?", sides: { top: "Top", right: "Right", bottom: "Bottom", left: "Left" }, mark: "Tap a sector and choose the room in it.", rooms: { "": "— not set —", door: "Main door", master: "Main bedroom", bedroom: "Bedroom", study: "Study / desk", living: "Living room", dining: "Dining", kitchen: "Kitchen / stove", bathroom: "Bathroom", storage: "Storage" }, centre: "Centre", result: "Room by room", room: "Room", fit: "Traditionally a good fit for this room.", misfit: "Traditionally not ideal for this room; consider using it for a kitchen, bathroom or storage, or moving the bed or desk to a favourable sector.", neutral: "The centre is traditionally kept open, tidy and light.", sector: "Sector", personal: "For you", star: "Year star", advice: "Traditional view", remove: "Remove floor plan" },
  "zh-Hans": { title: "户型图", lead: "加入户型图，看看每个房间落在哪个方位。", pick: "选择户型图图片", privacy: "图片只在你的浏览器中处理，不会上传。", front: "图上哪一边是房屋的正面（朝向）？", sides: { top: "上方", right: "右侧", bottom: "下方", left: "左侧" }, mark: "点选一个区域，选择其中的房间。", rooms: { "": "— 未设置 —", door: "大门", master: "主卧", bedroom: "卧室", study: "书房/书桌", living: "客厅", dining: "餐厅", kitchen: "厨房/灶位", bathroom: "卫生间", storage: "储物间" }, centre: "中宫", result: "逐个房间", room: "房间", fit: "传统上适合这个房间。", misfit: "传统上不太适合这个房间；可考虑作厨房、卫生间或储物，或把床、书桌移到吉方。", neutral: "中宫传统上宜保持开阔、整洁、明亮。", sector: "方位", personal: "对你而言", star: "年飞星", advice: "传统看法", remove: "移除户型图" },
  "zh-Hant": { title: "戶型圖", lead: "加入戶型圖，看看每個房間落在哪個方位。", pick: "選擇戶型圖圖片", privacy: "圖片只在你的瀏覽器中處理，不會上傳。", front: "圖上哪一邊是房屋的正面（朝向）？", sides: { top: "上方", right: "右側", bottom: "下方", left: "左側" }, mark: "點選一個區域，選擇其中的房間。", rooms: { "": "— 未設定 —", door: "大門", master: "主臥", bedroom: "臥室", study: "書房/書桌", living: "客廳", dining: "餐廳", kitchen: "廚房/灶位", bathroom: "衛生間", storage: "儲物間" }, centre: "中宮", result: "逐個房間", room: "房間", fit: "傳統上適合這個房間。", misfit: "傳統上不太適合這個房間；可考慮作廚房、衛生間或儲物，或把床、書桌移到吉方。", neutral: "中宮傳統上宜保持開闊、整潔、明亮。", sector: "方位", personal: "對你而言", star: "年飛星", advice: "傳統看法", remove: "移除戶型圖" },
  ja: { title: "間取り図", lead: "間取り図を加えると、各部屋がどの方位にあるかが分かります。", pick: "間取り図の画像を選ぶ", privacy: "画像はブラウザ内だけで処理され、アップロードされません。", front: "図のどちら側が家の正面（向き）ですか？", sides: { top: "上", right: "右", bottom: "下", left: "左" }, mark: "区画をタップして、その部屋を選んでください。", rooms: { "": "— 未設定 —", door: "玄関", master: "主寝室", bedroom: "寝室", study: "書斎・机", living: "リビング", dining: "ダイニング", kitchen: "台所・コンロ", bathroom: "浴室・トイレ", storage: "収納" }, centre: "中宮", result: "部屋ごと", room: "部屋", fit: "伝統的にこの部屋に向いた方位です。", misfit: "伝統的にはこの部屋に理想的ではありません。台所・浴室・収納に使うか、ベッドや机を吉方へ移すことを検討してください。", neutral: "中宮は伝統的に広く、整頓され、明るく保つのがよいとされます。", sector: "方位", personal: "あなたにとって", star: "年の飛星", advice: "伝統的な見方", remove: "間取り図を外す" },
  ko: { title: "평면도", lead: "평면도를 추가하면 각 방이 어느 방위에 있는지 볼 수 있습니다.", pick: "평면도 이미지 선택", privacy: "이미지는 브라우저 안에서만 처리되며 업로드되지 않습니다.", front: "그림에서 어느 쪽이 집의 정면(향)인가요?", sides: { top: "위", right: "오른쪽", bottom: "아래", left: "왼쪽" }, mark: "구역을 누르고 그 안의 방을 고르세요.", rooms: { "": "— 미지정 —", door: "현관", master: "안방", bedroom: "침실", study: "서재/책상", living: "거실", dining: "식당", kitchen: "주방/화구", bathroom: "욕실", storage: "창고" }, centre: "중궁", result: "방별 보기", room: "방", fit: "전통적으로 이 방에 잘 맞는 방위입니다.", misfit: "전통적으로 이 방에 이상적이지 않습니다. 주방·욕실·창고로 쓰거나 침대나 책상을 길한 방위로 옮기는 것을 고려해 보세요.", neutral: "중궁은 전통적으로 넓고 깔끔하고 밝게 두는 것이 좋습니다.", sector: "방위", personal: "나에게", star: "올해 비성", advice: "전통적 관점", remove: "평면도 제거" },
  vi: { title: "Sơ đồ nhà", lead: "Thêm sơ đồ nhà để xem mỗi phòng nằm ở hướng nào.", pick: "Chọn ảnh sơ đồ nhà", privacy: "Ảnh chỉ được xử lý trong trình duyệt của bạn, không tải lên.", front: "Cạnh nào của bản vẽ là mặt trước (hướng) của nhà?", sides: { top: "Trên", right: "Phải", bottom: "Dưới", left: "Trái" }, mark: "Chạm vào một ô và chọn phòng ở đó.", rooms: { "": "— chưa chọn —", door: "Cửa chính", master: "Phòng ngủ chính", bedroom: "Phòng ngủ", study: "Phòng làm việc / bàn học", living: "Phòng khách", dining: "Phòng ăn", kitchen: "Bếp", bathroom: "Phòng tắm", storage: "Kho" }, centre: "Trung cung", result: "Từng phòng", room: "Phòng", fit: "Theo truyền thống, hướng này hợp với phòng này.", misfit: "Theo truyền thống chưa lý tưởng cho phòng này; có thể dùng làm bếp, phòng tắm hoặc kho, hoặc dời giường, bàn sang hướng tốt.", neutral: "Trung cung theo truyền thống nên thoáng, gọn gàng và sáng sủa.", sector: "Hướng", personal: "Với bạn", star: "Sao năm", advice: "Quan niệm truyền thống", remove: "Bỏ sơ đồ nhà" },
  th: { title: "แปลนบ้าน", lead: "เพิ่มแปลนบ้านเพื่อดูว่าแต่ละห้องอยู่ทิศใด", pick: "เลือกภาพแปลนบ้าน", privacy: "ภาพจะประมวลผลในเบราว์เซอร์ของคุณเท่านั้น ไม่ถูกอัปโหลด", front: "ด้านใดของภาพคือด้านหน้า (ทิศที่บ้านหันไป)?", sides: { top: "บน", right: "ขวา", bottom: "ล่าง", left: "ซ้าย" }, mark: "แตะช่องแล้วเลือกห้องที่อยู่ในช่องนั้น", rooms: { "": "— ยังไม่เลือก —", door: "ประตูหลัก", master: "ห้องนอนใหญ่", bedroom: "ห้องนอน", study: "ห้องทำงาน/โต๊ะ", living: "ห้องนั่งเล่น", dining: "ห้องอาหาร", kitchen: "ครัว/เตา", bathroom: "ห้องน้ำ", storage: "ห้องเก็บของ" }, centre: "ศูนย์กลาง", result: "ทีละห้อง", room: "ห้อง", fit: "ตามประเพณีเหมาะกับห้องนี้", misfit: "ตามประเพณียังไม่เหมาะกับห้องนี้ อาจใช้เป็นครัว ห้องน้ำ หรือห้องเก็บของ หรือย้ายเตียงหรือโต๊ะไปทิศมงคล", neutral: "ตามประเพณีศูนย์กลางบ้านควรโล่ง เป็นระเบียบ และสว่าง", sector: "ทิศ", personal: "สำหรับคุณ", star: "ดาวประจำปี", advice: "มุมมองตามประเพณี", remove: "นำแปลนออก" },
};

export function FloorPlanFengShui({ cells, facing, locale }: { cells: BoardCell[]; facing: string; locale: Locale }) {
  const text = copy[locale];
  const [image, setImage] = useState<string | null>(null);
  const [front, setFront] = useState<Side>("bottom");
  const [rooms, setRooms] = useState<Record<string, Room>>({});
  const [selected, setSelected] = useState<string | null>(null);
  useEffect(() => () => { if (image) URL.revokeObjectURL(image); }, [image]);
  const byDirection = useMemo(() => Object.fromEntries(cells.map((cell) => [cell.title, cell])), [cells]);
  const facingIndex = Math.max(0, DIRS.indexOf(facing as typeof DIRS[number]));
  // Grid cell → compass direction, so that the chosen front side points toward the house's facing direction.
  const grid: Array<{ key: string; row: number; col: number; direction: string | null }> = [
    ...POSITIONS.map(([row, col], position) => ({ key: `${row}-${col}`, row, col, direction: DIRS[(facingIndex + position - SIDE_INDEX[front] + 16) % 8] })),
    { key: "1-1", row: 1, col: 1, direction: null },
  ];
  const label = (term: string) => localizeBoardTerm(term, locale);
  const assigned = grid.filter((entry) => rooms[entry.key]);
  return <section className="floorplan">
    <h3>{text.title}</h3>
    <p>{text.lead}</p>
    <label className="floorplan-file"><span>{text.pick}</span><input type="file" accept="image/*" onChange={(event) => { const file = event.target.files?.[0]; if (file) setImage(URL.createObjectURL(file)); }} /></label>
    <small>{text.privacy}</small>
    {image && <>
      <label><span>{text.front}</span><select value={front} onChange={(event) => setFront(event.target.value as Side)}>{(Object.keys(text.sides) as Side[]).map((side) => <option key={side} value={side}>{text.sides[side]}</option>)}</select></label>
      <p className="floorplan-hint">{text.mark}</p>
      <div className="floorplan-stage" style={{ backgroundImage: `url(${image})` }}>
        {grid.map((entry) => <button type="button" key={entry.key} className={`floorplan-cell${selected === entry.key ? " is-selected" : ""}${entry.direction && GOOD.has(byDirection[entry.direction]?.items[1]?.value ?? "") ? " is-good" : ""}`} style={{ gridRow: entry.row + 1, gridColumn: entry.col + 1 }} onClick={() => setSelected(entry.key)}>
          <small>{entry.direction ? label(entry.direction) : text.centre}</small>
          {rooms[entry.key] && <b>{text.rooms[rooms[entry.key]]}</b>}
        </button>)}
      </div>
      {selected && <label><span>{(() => { const entry = grid.find((item) => item.key === selected); return entry?.direction ? label(entry.direction) : text.centre; })()}</span>
        <select value={rooms[selected] ?? ""} onChange={(event) => setRooms({ ...rooms, [selected]: event.target.value as Room })}>{ROOMS.map((room) => <option key={room || "none"} value={room}>{text.rooms[room]}</option>)}</select></label>}
      {assigned.length > 0 && <div className="floorplan-result"><h4>{text.result}</h4>
        <table><thead><tr><th>{text.sector}</th><th>{text.room}</th><th>{text.personal}</th><th>{text.star}</th><th>{text.advice}</th></tr></thead><tbody>
          {assigned.map((entry) => {
            const room = rooms[entry.key];
            const cell = entry.direction ? byDirection[entry.direction] : undefined;
            const personal = cell?.items[1]?.value ?? "";
            const good = GOOD.has(personal);
            const advice = !entry.direction ? text.neutral : good === WANTS_GOOD.has(room) ? text.fit : text.misfit;
            return <tr key={entry.key}><td>{entry.direction ? label(entry.direction) : text.centre}</td><td>{text.rooms[room]}</td><td>{personal ? label(personal) : "—"}</td><td>{cell ? label(cell.items[3]?.value ?? "") : "—"}</td><td>{advice}</td></tr>;
          })}
        </tbody></table></div>}
      <button type="button" className="text-action" onClick={() => { setImage(null); setRooms({}); setSelected(null); }}>{text.remove}</button>
    </>}
  </section>;
}
