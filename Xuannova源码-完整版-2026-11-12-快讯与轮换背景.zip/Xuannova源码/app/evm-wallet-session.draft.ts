/** DEVELOPMENT ONLY: no payment, signing, account authentication or UI wiring.
 * Invoke connection/switching only from an explicit user gesture. Never treat a
 * wallet address as a logged-in member without a server-verified signature.
 */
import { getAddress, isAddress, type Address } from "viem";

export type EvmProvider = {
  request(args: { method: string; params?: unknown[] }): Promise<unknown>;
  on?(event: string, handler: (...args: unknown[]) => void): void;
  removeListener?(event: string, handler: (...args: unknown[]) => void): void;
};
export type EvmNetwork = "bsc" | "ethereum";
export type EvmSession = { address: Address; network: EvmNetwork; chainId: "0x38" | "0x1" };
const CHAINS = { bsc: "0x38", ethereum: "0x1" } as const;

function account(value: unknown): Address {
  if (!Array.isArray(value) || typeof value[0] !== "string" || !isAddress(value[0], { strict: false })) throw new Error("WALLET_ACCOUNT_UNAVAILABLE");
  return getAddress(value[0].toLowerCase());
}
function chain(value: unknown): string {
  if (typeof value !== "string" || !/^0x[0-9a-f]+$/i.test(value)) throw new Error("INVALID_WALLET_NETWORK");
  try { return `0x${BigInt(value).toString(16)}`; } catch { throw new Error("INVALID_WALLET_NETWORK"); }
}

/** Returns only after the wallet confirms the requested chain and account. */
export async function connectEvmForNetwork(provider: EvmProvider, network: EvmNetwork): Promise<EvmSession> {
  if (!provider || typeof provider.request !== "function") throw new Error("WALLET_NOT_AVAILABLE");
  if (!Object.hasOwn(CHAINS, network)) throw new Error("UNSUPPORTED_WALLET_NETWORK");
  const target = CHAINS[network];
  const initial = account(await provider.request({ method: "eth_requestAccounts" }));
  const current = chain(await provider.request({ method: "eth_chainId" }));
  if (current !== target) await provider.request({ method: "wallet_switchEthereumChain", params: [{ chainId: target }] });
  const afterChain = chain(await provider.request({ method: "eth_chainId" }));
  const afterAccount = account(await provider.request({ method: "eth_accounts" }));
  if (afterChain !== target) throw new Error("WALLET_NETWORK_NOT_SWITCHED");
  if (afterAccount !== initial) throw new Error("WALLET_ACCOUNT_CHANGED");
  return { address: initial, network, chainId: target };
}

/** Recheck immediately before quoting/signing; a cached session is not proof. */
export async function assertEvmSession(provider: EvmProvider, session: EvmSession): Promise<void> {
  if (!Object.hasOwn(CHAINS, session.network) || CHAINS[session.network] !== session.chainId) throw new Error("INVALID_SESSION");
  const current = chain(await provider.request({ method: "eth_chainId" }));
  const currentAccount = account(await provider.request({ method: "eth_accounts" }));
  if (current !== session.chainId) throw new Error("WALLET_NETWORK_CHANGED");
  if (currentAccount !== session.address) throw new Error("WALLET_ACCOUNT_CHANGED");
}

/** Clear quotes/pending UI selection on account, network or disconnect events. */
export function watchEvmSession(provider: EvmProvider, invalidate: () => void): () => void {
  if (!provider.on || !provider.removeListener) throw new Error("WALLET_EVENTS_UNAVAILABLE");
  const handler = () => invalidate();
  for (const event of ["accountsChanged", "chainChanged", "disconnect"]) provider.on(event, handler);
  return () => { for (const event of ["accountsChanged", "chainChanged", "disconnect"]) provider.removeListener!(event, handler); };
}
