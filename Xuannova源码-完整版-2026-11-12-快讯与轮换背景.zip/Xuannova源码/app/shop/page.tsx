"use client";

/**
 * 器物坊 (Workshop) storefront. Deploy at shop.xuannova.com by proxying that host to /shop
 * (see docs). Accounts are shared with the main site; payment is a reviewed USDT transfer.
 */
import { useCallback, useEffect, useMemo, useState } from "react";
import { languageOptions, type Locale } from "../site-content";
import { track } from "../analytics";
import { serverErrorText } from "../server-errors";

type L7 = Partial<Record<Locale, string>>;
type Product = { id: string; name: L7; description: L7; priceUsdt: string; imageUrl: string | null; stock: number };
type Network = { id: string; label: string; address: string; qrImage: string };
type Order = { id: string; items: Array<{ name: L7; quantity: number; priceUsdt: string }>; totalUsdt: string; status: "pending" | "paid" | "shipped" | "rejected"; tracking: string | null; createdAt: string };
type Cart = Record<string, number>;

const T = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): Record<Locale, string> => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });
const text = {
  brand: T("Xuannova Workshop", "Xuannova 器物坊", "Xuannova 器物坊", "Xuannova 工房", "Xuannova 공방", "Xưởng Xuannova", "โรงงานศิลป์ Xuannova"),
  lead: T("Objects for study and daily practice. Paid in USDT; every order is checked by our team before shipping.", "研习与日常所用的器物。以 USDT 付款，每笔订单由专人核对后发货。", "研習與日常所用的器物。以 USDT 付款，每筆訂單由專人核對後出貨。", "学びと日々の実践のための品々。USDT でお支払いいただき、担当者が確認してから発送します。", "공부와 일상 수련을 위한 물건들. USDT로 결제하며 담당자가 확인한 뒤 발송합니다.", "Vật phẩm cho việc học và thực hành hằng ngày. Thanh toán bằng USDT; mỗi đơn được kiểm tra trước khi giao.", "ของใช้สำหรับการศึกษาและการฝึกประจำวัน ชำระด้วย USDT ทุกคำสั่งซื้อมีเจ้าหน้าที่ตรวจสอบก่อนจัดส่ง"),
  empty: T("New pieces are being prepared.", "器物正在上架中。", "器物正在上架中。", "商品を準備中です。", "상품을 준비하고 있습니다.", "Sản phẩm đang được chuẩn bị.", "กำลังเตรียมสินค้า"),
  add: T("Add to cart", "加入购物车", "加入購物車", "カートに入れる", "장바구니 담기", "Thêm vào giỏ", "ใส่ตะกร้า"),
  soldOut: T("Sold out", "已售罄", "已售罄", "売り切れ", "품절", "Hết hàng", "สินค้าหมด"),
  cart: T("Cart", "购物车", "購物車", "カート", "장바구니", "Giỏ hàng", "ตะกร้า"),
  total: T("Total", "合计", "合計", "合計", "합계", "Tổng", "รวม"),
  checkout: T("Checkout", "结算", "結帳", "購入手続き", "결제하기", "Thanh toán", "ชำระเงิน"),
  signInTitle: T("Sign in to order (same account as the main site)", "登录后下单（与主站共用账户）", "登入後下單（與主站共用帳戶）", "注文にはログインが必要です（本サイトと共通のアカウント）", "주문하려면 로그인하세요(메인 사이트와 같은 계정)", "Đăng nhập để đặt hàng (dùng chung tài khoản trang chính)", "เข้าสู่ระบบเพื่อสั่งซื้อ (บัญชีเดียวกับเว็บหลัก)"),
  email: T("Email", "邮箱", "信箱", "メール", "이메일", "Email", "อีเมล"),
  password: T("Password", "密码", "密碼", "パスワード", "비밀번호", "Mật khẩu", "รหัสผ่าน"),
  signIn: T("Sign in / register", "登录 / 注册", "登入 / 註冊", "ログイン / 登録", "로그인 / 가입", "Đăng nhập / Đăng ký", "เข้าสู่ระบบ / สมัคร"),
  shipping: T("Shipping", "收货信息", "收貨資訊", "配送先", "배송 정보", "Thông tin giao hàng", "ข้อมูลจัดส่ง"),
  name: T("Recipient", "收件人", "收件人", "受取人", "받는 분", "Người nhận", "ผู้รับ"),
  phone: T("Phone", "电话", "電話", "電話", "전화", "Điện thoại", "โทรศัพท์"),
  country: T("Country / region", "国家 / 地区", "國家 / 地區", "国・地域", "국가/지역", "Quốc gia / khu vực", "ประเทศ / ภูมิภาค"),
  address: T("Address", "详细地址", "詳細地址", "住所", "주소", "Địa chỉ", "ที่อยู่"),
  postcode: T("Postcode", "邮编", "郵遞區號", "郵便番号", "우편번호", "Mã bưu chính", "รหัสไปรษณีย์"),
  note: T("Note (optional)", "备注（选填）", "備註（選填）", "備考（任意）", "메모(선택)", "Ghi chú (không bắt buộc)", "หมายเหตุ (ไม่บังคับ)"),
  pay: T("Pay with USDT", "USDT 付款", "USDT 付款", "USDT で支払う", "USDT 결제", "Thanh toán USDT", "ชำระด้วย USDT"),
  payLead: T("Send exactly the total in USDT on the selected network, then paste the transaction hash. Your order is confirmed after our team checks the transfer.", "在所选网络转入与合计相同的 USDT，然后粘贴交易哈希。专人核对到账后确认订单。", "在所選網路轉入與合計相同的 USDT，然後貼上交易雜湊。專人核對入帳後確認訂單。", "選択したネットワークで合計額の USDT を送金し、トランザクションハッシュを貼り付けてください。担当者が入金を確認後に注文が確定します。", "선택한 네트워크로 합계 금액의 USDT를 보낸 뒤 거래 해시를 붙여 넣으세요. 담당자가 입금을 확인하면 주문이 확정됩니다.", "Chuyển đúng số USDT bằng tổng trên mạng đã chọn rồi dán mã băm giao dịch. Đơn được xác nhận sau khi chúng tôi kiểm tra.", "โอน USDT เท่ากับยอดรวมบนเครือข่ายที่เลือก แล้ววางแฮชธุรกรรม คำสั่งซื้อจะยืนยันหลังเจ้าหน้าที่ตรวจสอบ"),
  hash: T("Transaction hash", "交易哈希", "交易雜湊", "トランザクションハッシュ", "거래 해시", "Mã băm giao dịch", "แฮชธุรกรรม"),
  submit: T("Place order", "提交订单", "提交訂單", "注文する", "주문하기", "Đặt hàng", "สั่งซื้อ"),
  placed: T("Order received. We will confirm it after checking the transfer.", "订单已提交，核对到账后会确认。", "訂單已提交，核對入帳後會確認。", "ご注文を受け付けました。入金確認後に確定します。", "주문이 접수되었습니다. 입금 확인 후 확정됩니다.", "Đã nhận đơn. Chúng tôi sẽ xác nhận sau khi kiểm tra giao dịch.", "ได้รับคำสั่งซื้อแล้ว จะยืนยันหลังตรวจสอบการโอน"),
  orders: T("My orders", "我的订单", "我的訂單", "注文履歴", "내 주문", "Đơn của tôi", "คำสั่งซื้อของฉัน"),
  pending: T("Checking payment", "核对付款中", "核對付款中", "入金確認中", "결제 확인 중", "Đang kiểm tra", "กำลังตรวจสอบ"),
  paid: T("Paid · preparing", "已付款 · 备货中", "已付款 · 備貨中", "入金済み · 準備中", "결제 완료 · 준비 중", "Đã thanh toán · đang chuẩn bị", "ชำระแล้ว · กำลังเตรียม"),
  shipped: T("Shipped", "已发货", "已出貨", "発送済み", "발송됨", "Đã gửi", "จัดส่งแล้ว"),
  rejected: T("Not confirmed", "未通过", "未通過", "確認できませんでした", "확인되지 않음", "Không xác nhận", "ไม่ผ่านการยืนยัน"),
  back: T("Back to Xuannova", "返回 Xuannova", "返回 Xuannova", "Xuannova に戻る", "Xuannova로 돌아가기", "Về Xuannova", "กลับไป Xuannova"),
  disclaimer: T("Objects are offered as cultural and decorative items; they make no claim to change luck, health or fortune.", "器物作为文化与装饰用品出售，不具有改运、治病或招财等功效。", "器物作為文化與裝飾用品出售，不具有改運、治病或招財等功效。", "品物は文化・装飾品としての販売であり、運勢・健康・金運を変える効果をうたうものではありません。", "물건은 문화·장식용으로 판매되며 운세, 건강, 재물을 바꾸는 효과를 주장하지 않습니다.", "Vật phẩm được bán như đồ văn hóa và trang trí, không có công dụng đổi vận, chữa bệnh hay chiêu tài.", "สินค้าจำหน่ายในฐานะของใช้ทางวัฒนธรรมและของตกแต่ง ไม่อ้างว่าเปลี่ยนโชค สุขภาพ หรือโชคลาภ"),
};
const pick = (map: L7, locale: Locale) => map[locale] ?? map.en ?? map["zh-Hans"] ?? Object.values(map)[0] ?? "";

async function api<T>(path: string, body?: unknown): Promise<T> {
  const response = await fetch(path, { method: body === undefined ? "GET" : "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) });
  const payload = await response.json() as T & { error?: string };
  if (!response.ok) throw Object.assign(new Error(payload.error ?? "Request failed"), { status: response.status });
  return payload;
}

export default function ShopPage() {
  const [locale, setLocale] = useState<Locale>("en");
  const [products, setProducts] = useState<Product[] | null>(null);
  const [networks, setNetworks] = useState<Network[]>([]);
  const [cart, setCart] = useState<Cart>({});
  const [signedIn, setSignedIn] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [auth, setAuth] = useState({ email: "", password: "" });
  const [shipping, setShipping] = useState({ name: "", phone: "", country: "", address: "", postcode: "", note: "" });
  const [networkId, setNetworkId] = useState("bsc");
  const [hash, setHash] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);

  const refreshMember = useCallback(async () => {
    try { const me = await api<{ member: unknown }>("/api/member/me?soft=1"); if (!me.member) throw new Error("signed out"); setSignedIn(true); setOrders((await api<{ orders: Order[] }>("/api/shop/orders")).orders); } catch { setSignedIn(false); }
  }, []);
  useEffect(() => {
    const timer = window.setTimeout(() => {
      try {
        // Language: ?lang= from the main site's link, then the main site's saved choice (older key as a fallback).
        const fromLink = new URLSearchParams(window.location.search).get("lang");
        const stored = fromLink ?? window.localStorage.getItem("xuannova-locale") ?? window.localStorage.getItem("xuanyuan-locale");
        if (stored && languageOptions.some((option) => option.value === stored)) setLocale(stored as Locale);
        const savedCart = JSON.parse(window.localStorage.getItem("xuannova-cart") ?? "{}") as Cart;
        if (savedCart && typeof savedCart === "object") setCart(savedCart);
      } catch { /* optional */ }
      void api<{ products: Product[]; networks: Network[] }>("/api/shop/products").then((payload) => { setProducts(payload.products); setNetworks(payload.networks); }).catch(() => setProducts([]));
      void refreshMember();
    }, 0);
    return () => window.clearTimeout(timer);
  }, [refreshMember]);
  useEffect(() => { try { window.localStorage.setItem("xuannova-cart", JSON.stringify(cart)); } catch { /* optional */ } }, [cart]);
  useEffect(() => { document.documentElement.lang = locale; document.title = text.brand[locale]; try { window.localStorage.setItem("xuannova-locale", locale); } catch { /* optional */ } }, [locale]);

  const lines = useMemo(() => (products ?? []).filter((product) => cart[product.id]).map((product) => ({ product, quantity: Math.min(cart[product.id], product.stock) })).filter((line) => line.quantity > 0), [products, cart]);
  const totalCents = lines.reduce((sum, line) => sum + Math.round(Number(line.product.priceUsdt) * 100) * line.quantity, 0);
  const network = networks.find((item) => item.id === networkId) ?? networks[0];
  const statusLabel = (status: Order["status"]) => text[status][locale];

  const signIn = async (event: React.FormEvent) => {
    event.preventDefault(); setBusy(true); setNotice("");
    try { await api("/api/auth/login", { ...auth, autoRegister: true }); setAuth({ email: "", password: "" }); await refreshMember(); } catch (cause) { setNotice(serverErrorText((cause as Error).message, locale)); } finally { setBusy(false); }
  };
  const placeOrder = async (event: React.FormEvent) => {
    event.preventDefault(); setBusy(true); setNotice("");
    try {
      await api("/api/shop/orders", { items: lines.map((line) => ({ productId: line.product.id, quantity: line.quantity })), network: network?.id, transactionHash: hash, shipping });
      track("shop_order", { items: lines.length });
      setCart({}); setHash(""); setNotice(text.placed[locale]); await refreshMember();
      void api<{ products: Product[]; networks: Network[] }>("/api/shop/products").then((payload) => setProducts(payload.products));
    } catch (cause) { setNotice(serverErrorText((cause as Error).message, locale)); } finally { setBusy(false); }
  };

  return <main className="suite-shell shop-shell" data-theme="aureate" data-locale={locale}>
    <header className="shop-bar"><b>{text.brand[locale]}</b><a href={`https://xuannova.com${locale === "en" ? "/" : `/${locale.toLowerCase()}`}`}>{text.back[locale]}</a>
      <select value={locale} onChange={(event) => setLocale(event.target.value as Locale)} aria-label="Language">{languageOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select></header>
    <section className="shop-hero"><h1>{text.brand[locale]}</h1><p>{text.lead[locale]}</p></section>
    <section className="shop-grid">
      {products && products.length === 0 && <p className="lecture-soon">{text.empty[locale]}</p>}
      {(products ?? []).map((product) => <article key={product.id}>
        {product.imageUrl ? <img src={product.imageUrl} alt={pick(product.name, locale)} loading="lazy" /> : <div className="shop-placeholder" aria-hidden="true">器</div>}
        <h2>{pick(product.name, locale)}</h2>
        <p>{pick(product.description, locale)}</p>
        <footer><strong>{product.priceUsdt} USDT</strong>
          <button type="button" className="primary-action" disabled={product.stock < 1} onClick={() => setCart({ ...cart, [product.id]: Math.min((cart[product.id] ?? 0) + 1, product.stock) })}>{product.stock < 1 ? text.soldOut[locale] : text.add[locale]}</button></footer>
      </article>)}
    </section>
    {lines.length > 0 && <section className="shop-checkout">
      <h2>{text.cart[locale]}</h2>
      <ul>{lines.map((line) => <li key={line.product.id}><span>{pick(line.product.name, locale)}</span>
        <input type="number" min={0} max={line.product.stock} value={line.quantity} aria-label={pick(line.product.name, locale)} onChange={(event) => setCart({ ...cart, [line.product.id]: Math.max(0, Math.min(Number(event.target.value) || 0, line.product.stock)) })} />
        <b>{(Number(line.product.priceUsdt) * line.quantity).toFixed(2)} USDT</b></li>)}</ul>
      <p className="shop-total">{text.total[locale]}: <b>{(totalCents / 100).toFixed(2)} USDT</b></p>
      {!signedIn ? <form onSubmit={signIn} className="shop-form"><h3>{text.signInTitle[locale]}</h3>
        <label>{text.email[locale]}<input type="email" required value={auth.email} onChange={(event) => setAuth({ ...auth, email: event.target.value })} /></label>
        <label>{text.password[locale]}<input type="password" required minLength={6} value={auth.password} onChange={(event) => setAuth({ ...auth, password: event.target.value })} /></label>
        <button type="submit" className="primary-action" disabled={busy}>{text.signIn[locale]}</button></form>
      : <form onSubmit={placeOrder} className="shop-form"><h3>{text.shipping[locale]}</h3>
        {(["name", "phone", "country", "address", "postcode", "note"] as const).map((field) => <label key={field}>{text[field][locale]}<input value={shipping[field]} required={field !== "postcode" && field !== "note"} onChange={(event) => setShipping({ ...shipping, [field]: event.target.value })} /></label>)}
        <h3>{text.pay[locale]}</h3><p>{text.payLead[locale]}</p>
        <div className="shop-networks">{networks.map((item) => <label key={item.id}><input type="radio" name="network" checked={networkId === item.id} onChange={() => setNetworkId(item.id)} />{item.label}</label>)}</div>
        {network && <div className="shop-transfer"><img src={network.qrImage} alt={network.label} /><code>{network.address}</code></div>}
        <label>{text.hash[locale]}<input value={hash} required onChange={(event) => setHash(event.target.value.trim())} /></label>
        <button type="submit" className="primary-action" disabled={busy}>{text.submit[locale]}</button></form>}
    </section>}
    {notice && <p className="commerce-notice" role="status">{notice}</p>}
    {signedIn && orders.length > 0 && <section className="shop-orders"><h2>{text.orders[locale]}</h2><ul>{orders.map((order) => <li key={order.id}>
      <span>{order.items.map((item) => `${pick(item.name, locale)} × ${item.quantity}`).join(", ")}</span><b>{order.totalUsdt} USDT</b><em data-status={order.status}>{statusLabel(order.status)}{order.tracking ? ` · ${order.tracking}` : ""}</em></li>)}</ul></section>}
    <p className="reading-disclaimer shop-disclaimer">{text.disclaimer[locale]}</p>
  </main>;
}
