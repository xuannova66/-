// TokenPocket App bridge (the same calls as TokenPocket's tp-js-sdk, without the dependency). Inside the TokenPocket
// browser only the selected wallet's chain is connected; tp.getWallet({ walletTypes, switch: true }) opens TokenPocket's
// own wallet picker for another chain, after which the page is reloaded with that chain's wallet connected.
type BridgeWindow = Window & {
  TPJSBrigeClient?: { callMessage(method: string, params: string, callback: string): void };
  webkit?: { messageHandlers?: Record<string, { postMessage(message: unknown): void }> };
} & Record<string, unknown>;

/** TokenPocket chain ids (tp-js-sdk TYPE_MAP). */
export const TP_CHAIN_IDS = { ethereum: "1", tron: "10", bsc: "12", solana: "27" } as const;
export type TpChain = keyof typeof TP_CHAIN_IDS;

export function tpBridgeAvailable() {
  if (typeof window === "undefined") return false;
  const w = window as unknown as BridgeWindow;
  return Boolean(w.TPJSBrigeClient || w.webkit?.messageHandlers?.getWallet);
}

/** Ask TokenPocket to switch to a wallet on `chain`. Resolves true when the app answered (the page then reloads). */
export function tpSwitchWallet(chain: TpChain, timeoutMs = 60_000): Promise<boolean> {
  return new Promise((resolve) => {
    if (!tpBridgeAvailable()) { resolve(false); return; }
    const w = window as unknown as BridgeWindow;
    const callback = `tp_callback_${Date.now()}${Math.floor(Math.random() * 100000)}`;
    const timer = window.setTimeout(() => { delete w[callback]; resolve(false); }, timeoutMs);
    w[callback] = (raw: string) => {
      window.clearTimeout(timer); delete w[callback];
      let switched = false;
      try { const result = JSON.parse(String(raw).replace(/[\r\n]/g, "")) as { result?: boolean; data?: unknown }; switched = result.result !== false && Boolean(result.data); } catch { switched = false; }
      resolve(switched);
      // TokenPocket injects the new chain's wallet on load.
      if (switched) window.setTimeout(() => window.location.reload(), 300);
    };
    const params = JSON.stringify({ walletTypes: [TP_CHAIN_IDS[chain]], switch: true });
    try {
      if (w.TPJSBrigeClient) w.TPJSBrigeClient.callMessage("getWallet", params, callback);
      else w.webkit?.messageHandlers?.getWallet?.postMessage({ body: { params, callback } });
    } catch { window.clearTimeout(timer); delete w[callback]; resolve(false); }
  });
}
