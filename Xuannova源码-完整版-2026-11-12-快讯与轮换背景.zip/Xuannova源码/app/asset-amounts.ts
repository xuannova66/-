/** Exact base-unit conversion for future multi-chain checkout.
 * This module is not wired into the live payment flow. Never use JS floating
 * point for on-chain amounts and never silently round extra precision.
 */
import { formatUnits, parseUnits } from "viem";

function checkDecimals(decimals: number): void {
  if (!Number.isInteger(decimals) || decimals < 0 || decimals > 36) throw new Error("INVALID_ASSET_DECIMALS");
}

export function parseAssetAmount(amount: string, decimals: number): bigint {
  checkDecimals(decimals);
  if (!/^(0|[1-9]\d*)(\.\d+)?$/.test(amount)) throw new Error("INVALID_ASSET_AMOUNT");
  const fraction = amount.split(".")[1] ?? "";
  if (fraction.length > decimals) throw new Error("ASSET_PRECISION_EXCEEDED");
  const result = parseUnits(amount, decimals);
  if (result <= 0n) throw new Error("INVALID_ASSET_AMOUNT");
  return result;
}

export function displayAssetAmount(amount: bigint, decimals: number): string {
  checkDecimals(decimals);
  if (amount < 0n) throw new Error("INVALID_ASSET_AMOUNT");
  return formatUnits(amount, decimals);
}
