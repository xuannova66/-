"use client";
// 研习殿: a small 3D hall. A taiji-bagua disc stands on the altar like a shrine's centrepiece; in front of it little
// Taoist disciples sit on mats in rows, one for each study method, with the method's name floating above. Tap a name
// (or a disciple) to open that method. three.js is loaded from /vendor only when the hall scrolls into view, the
// scene renders only while visible, and without WebGL (or with reduced motion) a plain list is shown instead.
import { useEffect, useRef, useState } from "react";
import type { Locale } from "./site-content";
import { methodCategories } from "./method-categories";
import { titleForRoute, type AppRoute } from "./study-suite";
import { useHiddenRoutes } from "./vision-availability";
import { setHallName, useHallPresence, type HallVisitor } from "./hall-presence-client";
import { HallLamps, LAMP_COLORS, useHallLamps } from "./hall-lamps";
import { randomDaoName } from "../worker/hall-presence";
import { buildCourtyard } from "./hall-courtyard";
import { bead, bell, chime, setAmbience, woodFish } from "./hall-sounds";

type L7 = Record<Locale, string>;
const L = (en: string, zhHans: string, zhHant: string, ja: string, ko: string, vi: string, th: string): L7 => ({ en, "zh-Hans": zhHans, "zh-Hant": zhHant, ja, ko, vi, th });
const copy = {
  eyebrow: L("Xuannova · Study hall", "Xuannova · 研习殿", "Xuannova · 研習殿", "Xuannova · 研習殿", "Xuannova · 연습전", "Xuannova · Điện tu học", "Xuannova · ห้องศึกษา"),
  title: L("Fellow practitioners studying together", "同殿共修，各有吉名", "同殿共修，各有吉名", "道友とともに学ぶ研習殿", "도우들과 함께 공부하는 전각", "Cùng tu học trong điện", "ศึกษาร่วมกันในหอ"),
  lead: L("Fellow practitioners sit and study in the hall. Drag to look around; light a lamp below.", "道友们在殿中静坐研习。左右拖动可环顾殿内，下方可点亮祈福灯。", "道友們在殿中靜坐研習。左右拖動可環顧殿內，下方可點亮祈福燈。", "道友たちが殿内で静かに学んでいます。ドラッグで見回し、下で祈りの灯をともせます。", "도우들이 전각에서 조용히 공부하고 있어요. 드래그해 둘러보고, 아래에서 기원등을 밝혀 보세요.", "Các đạo hữu đang tĩnh tọa tu học. Kéo để nhìn quanh; thắp đèn cầu phúc ở bên dưới.", "เพื่อนร่วมทางกำลังนั่งศึกษาในหอ ลากเพื่อมองรอบ ๆ และจุดโคมอธิษฐานได้ด้านล่าง"),
  yourName: L("Your Taoist name", "你的道号", "你的道號", "あなたの道号", "나의 도호", "Đạo hiệu của bạn", "ฉายาของคุณ"),
  rename: L("Choose my own", "自己起道号", "自己起道號", "自分で付ける", "직접 짓기", "Tự đặt", "ตั้งเอง"),
  save: L("Save", "保存", "儲存", "保存", "저장", "Lưu", "บันทึก"),
  cancel: L("Cancel", "取消", "取消", "キャンセル", "취소", "Hủy", "ยกเลิก"),
  random: L("Use a random one", "用随机道号", "用隨機道號", "ランダムに戻す", "무작위 도호", "Dùng ngẫu nhiên", "ใช้แบบสุ่ม"),
  placeholder: L("1–10 characters", "1–10 个字", "1–10 個字", "1〜10文字", "1–10자", "1–10 ký tự", "1–10 ตัวอักษร"),
  refused: L("That name can't be used (no links, contact details or rude words). Please try another.", "这个道号不能用（不能含链接、联系方式或不雅字词），请换一个。", "這個道號不能用（不能含連結、聯絡方式或不雅字詞），請換一個。", "この名前は使えません（リンク・連絡先・不適切な語は不可）。別の名前にしてください。", "이 이름은 쓸 수 없습니다(링크, 연락처, 비속어 불가). 다른 이름을 써 주세요.", "Không dùng được tên này (không chứa liên kết, liên hệ hay từ thô tục). Hãy chọn tên khác.", "ใช้ชื่อนี้ไม่ได้ (ห้ามลิงก์ ช่องทางติดต่อ หรือคำหยาบ) โปรดลองชื่ออื่น"),
  walkHint: L("Tap the ground to walk there — all the way out to the courtyard and the gate; drag to look around.", "点地面就能走过去，可以一路走到庭院和山门；拖动可环顾四周。", "點地面就能走過去，可以一路走到庭院和山門；拖動可環顧四周。", "地面をタップするとそこまで歩きます。庭園や山門まで行けます。ドラッグで見回せます。", "땅을 누르면 그곳으로 걸어갑니다. 뜰과 산문까지 갈 수 있어요. 드래그로 둘러보세요.", "Chạm xuống đất để đi tới đó — ra tận sân và cổng; kéo để nhìn quanh.", "แตะพื้นเพื่อเดินไป ไปได้ถึงลานและประตูวัด ลากเพื่อมองรอบ ๆ"),
  walking: L("You're strolling the grounds — tap the ground to keep walking.", "你正在院中走动，点地面可以继续走。", "你正在院中走動，點地面可以繼續走。", "境内を散策中。地面をタップして歩き続けられます。", "경내를 거닐고 있어요. 땅을 눌러 계속 걸으세요.", "Bạn đang dạo trong khuôn viên — chạm đất để đi tiếp.", "คุณกำลังเดินในบริเวณ แตะพื้นเพื่อเดินต่อ"),
  strolling: L("strolling the grounds", "在院中走动", "在院中走動", "境内を散策中", "경내를 거니는 중", "đang dạo khuôn viên", "กำลังเดินเล่น"),
  backToSeat: L("Back to my seat", "回到座位", "回到座位", "席に戻る", "자리로 돌아가기", "Về chỗ ngồi", "กลับที่นั่ง"),
  you: L("You", "你", "你", "あなた", "나", "Bạn", "คุณ"),
  studying: L("studying {m}", "正在看 {m}", "正在看 {m}", "{m} を学習中", "{m} 공부 중", "đang xem {m}", "กำลังดู {m}"),
  onHome: L("in the hall", "在殿中静坐", "在殿中靜坐", "殿内で静座", "전각에서 정좌", "đang tĩnh tọa", "นั่งสงบในห้อง"),
  inYard: L("strolling the courtyard", "在院中漫步", "在院中漫步", "庭園を散策中", "뜰을 거니는 중", "đang dạo trong sân", "เดินเล่นในลาน"),
  viewHall: L("Hall", "殿内", "殿內", "殿内", "전각 안", "Trong điện", "ในหอ"),
  viewYard: L("Courtyard", "庭院", "庭院", "庭園", "뜰", "Sân", "ลาน"),
  viewFollow: L("Follow me", "跟随我", "跟隨我", "自分を追う", "나 따라가기", "Theo tôi", "ตามฉัน"),
  palms: L("Palms", "合掌", "合掌", "合掌", "합장", "Chắp tay", "พนมมือ"),
  bow: L("Bow", "礼拜", "禮拜", "礼拝", "예배", "Lễ bái", "กราบ"),
  fish: L("Wooden fish", "木鱼", "木魚", "木魚", "목탁", "Mõ", "ม้าเกี้ยว"),
  beads: L("Beads", "念珠", "念珠", "数珠", "염주", "Tràng hạt", "ลูกประคำ"),
  bell: L("Bell", "撞钟", "撞鐘", "鐘", "타종", "Đánh chuông", "ตีระฆัง"),
  sound: L("Ambience", "环境音", "環境音", "環境音", "환경음", "Âm thanh", "เสียงบรรยากาศ"),
  calm: L("Calm +1", "静心 +1", "靜心 +1", "静心 +1", "고요 +1", "Tĩnh tâm +1", "สงบ +1"),
  peace: L("Peace", "心安", "心安", "心安", "평안", "An lành", "ใจสงบ"),
  today: L("today", "今日", "今日", "今日", "오늘", "hôm nay", "วันนี้"),
  loading: L("Opening the hall…", "正在打开研习殿…", "正在打開研習殿…", "研習殿を開いています…", "연습전을 여는 중…", "Đang mở điện…", "กำลังเปิดห้อง…"),
};
// Each disciple's own auspicious name (道号), chosen to echo the method they keep.
const DISCIPLE: Record<string, L7> = {
  bazi: L("Know-Fate", "知命", "知命", "知命", "지명", "Tri Mệnh", "รู้ชะตา"),
  detail: L("Clear-Reason", "明理", "明理", "明理", "명리", "Minh Lý", "แจ้งเหตุ"),
  ziwei: L("Purple-Court", "紫垣", "紫垣", "紫垣", "자원", "Tử Viên", "ราชวังม่วง"),
  qizheng: L("Star-Watcher", "观星", "觀星", "観星", "관성", "Quan Tinh", "ดูดาว"),
  heluo: L("River-Script", "洛书", "洛書", "洛書", "낙서", "Lạc Thư", "ลั่วซู"),
  tieban: L("Fixed-Number", "定数", "定數", "定数", "정수", "Định Số", "เลขกำหนด"),
  xiangshu: L("Read-Faces", "观相", "觀相", "観相", "관상", "Quan Tướng", "ดูลักษณ์"),
  liuyao: L("Ask-the-Lines", "问卦", "問卦", "問卦", "문괘", "Vấn Quái", "ถามกว้า"),
  meihua: L("Plum-Heart", "梅心", "梅心", "梅心", "매심", "Mai Tâm", "ใจเหมย"),
  jinkoujue: L("Golden-Word", "金言", "金言", "金言", "금언", "Kim Ngôn", "วาจาทอง"),
  daliuren: L("Hidden-Key", "玄机", "玄機", "玄機", "현기", "Huyền Cơ", "กลลึกลับ"),
  qimen: L("Right-Moment", "奇正", "奇正", "奇正", "기정", "Kỳ Chính", "จังหวะพลิก"),
  wenshi: L("Seek-the-Way", "问道", "問道", "問道", "문도", "Vấn Đạo", "ถามทาง"),
  compatibility: L("Harmony", "和合", "和合", "和合", "화합", "Hòa Hợp", "กลมเกลียว"),
  hecan: L("Three-Talents", "三才", "三才", "三才", "삼재", "Tam Tài", "สามพลัง"),
  almanac: L("Lucky-Day", "吉日", "吉日", "吉日", "길일", "Cát Nhật", "วันดี"),
  zeri: L("Choose-Good", "择吉", "擇吉", "択吉", "택길", "Trạch Cát", "เลือกฤกษ์"),
  daily: L("With-the-Hours", "顺时", "順時", "順時", "순시", "Thuận Thời", "ตามกาล"),
  taiyi: L("Great-One", "太乙", "太乙", "太乙", "태을", "Thái Ất", "ไท่อี่"),
  zhuzhai: L("Peaceful-Home", "安宅", "安宅", "安宅", "안택", "An Trạch", "บ้านสงบ"),
  cezi: L("Word-Heart", "文心", "文心", "文心", "문심", "Văn Tâm", "ใจอักษร"),
  mirror: L("Quiet-Gaze", "静观", "靜觀", "静観", "정관", "Tĩnh Quán", "มองนิ่ง"),
};
const CATEGORY_COLOR: Record<string, string> = { self: "#e2b65c", ask: "#7fb7d9", relation: "#e48a8a", timing: "#9bcf8e", space: "#c7a07a", mind: "#b9a3e3" };

type Seat = { route: AppRoute; name: string; label: string; color: string };
// Action buttons: simple line icons (drawn here, no icon files).
const ACTS: Array<[HallAct, string]> = [
  ["palms", '<svg viewBox="0 0 24 24"><path d="M12 3c-1 2-1.6 5-1.6 8.2V20l-3.6-1.5c-.8-.3-1.2-1.2-.9-2l2.4-6.2M12 3c1 2 1.6 5 1.6 8.2V20l3.6-1.5c.8-.3 1.2-1.2.9-2l-2.4-6.2" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>'],
  ["bow", '<svg viewBox="0 0 24 24"><circle cx="16.5" cy="7" r="2.4" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M14.5 9.5 9 13l-1 7M9 13l5 2 2 5M4 20h16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>'],
  ["fish", '<svg viewBox="0 0 24 24"><ellipse cx="11" cy="14" rx="7.5" ry="5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M5 13.5h9M16.5 4.5l3 3M18 6l-4.5 5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>'],
  ["beads", '<svg viewBox="0 0 24 24">' + Array.from({ length: 10 }, (_, k) => `<circle cx="${(12 + Math.cos((k / 10) * Math.PI * 2) * 6.5).toFixed(1)}" cy="${(11 + Math.sin((k / 10) * Math.PI * 2) * 6.5).toFixed(1)}" r="1.5" fill="currentColor"/>`).join("") + '<path d="M12 17.5v4" stroke="currentColor" stroke-width="1.6"/></svg>'],
  ["bell", '<svg viewBox="0 0 24 24"><path d="M12 3v2M7 18V11a5 5 0 0 1 10 0v7M5 18h14M10 21h4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>'],
];
// Today's wooden-fish strikes and bead count, kept in this browser only.
const COUNT_KEY = "xn.hall.counts";
type Counts = { day: string; fish: number; beads: number };
const today = () => new Date().toISOString().slice(0, 10);
function readCounts(): Counts {
  try { const value = JSON.parse(localStorage.getItem(COUNT_KEY) ?? "null") as Counts | null; if (value && value.day === today()) return value; } catch { /* private mode */ }
  return { day: today(), fish: 0, beads: 0 };
}
function bumpCount(kind: HallAct): Counts {
  const value = readCounts();
  if (kind === "fish") value.fish += 1; if (kind === "beads") value.beads += 1;
  try { localStorage.setItem(COUNT_KEY, JSON.stringify(value)); } catch { /* private mode */ }
  return value;
}

// three.js has no type package here; the scene code below only uses its stable public API.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Three = any;
const THREE_URL = "/vendor/three/three-r160.module.min.js";

// ---- textures drawn on canvases (no image files) -----------------------------------------------------------------
function canvas(width: number, height: number, draw: (ctx: CanvasRenderingContext2D) => void) {
  const element = document.createElement("canvas");
  element.width = width; element.height = height;
  draw(element.getContext("2d")!);
  return element;
}
function taijiBaguaCanvas() {
  return canvas(1024, 1024, (ctx) => {
    const c = 512;
    ctx.fillStyle = "#1a1410"; ctx.beginPath(); ctx.arc(c, c, 510, 0, Math.PI * 2); ctx.fill();
    const ring = ctx.createRadialGradient(c, c, 300, c, c, 510);
    ring.addColorStop(0, "#3a2a14"); ring.addColorStop(1, "#6b4a1c");
    ctx.fillStyle = ring; ctx.beginPath(); ctx.arc(c, c, 500, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "#e9c46a"; ctx.lineWidth = 10; ctx.beginPath(); ctx.arc(c, c, 492, 0, Math.PI * 2); ctx.stroke();
    ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(c, c, 300, 0, Math.PI * 2); ctx.stroke();
    // Eight trigrams (先天八卦): 乾 at the top, then clockwise 巽 坎 艮 坤 震 离 兑 by the Fu Xi order.
    const trigrams = [[1, 1, 1], [0, 1, 1], [0, 1, 0], [1, 0, 0], [0, 0, 0], [0, 0, 1], [1, 0, 1], [1, 1, 0]];
    trigrams.forEach((lines, index) => {
      ctx.save(); ctx.translate(c, c); ctx.rotate((index * Math.PI) / 4);
      lines.forEach((solid, row) => {
        const y = -455 + row * 42; // outer line first
        ctx.fillStyle = "#f2d792";
        if (solid) ctx.fillRect(-90, y, 180, 24);
        else { ctx.fillRect(-90, y, 78, 24); ctx.fillRect(12, y, 78, 24); }
      });
      ctx.restore();
    });
    // Taiji
    const r = 270;
    ctx.fillStyle = "#f4ead2"; ctx.beginPath(); ctx.arc(c, c, r, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#16120e"; ctx.beginPath(); ctx.arc(c, c, r, -Math.PI / 2, Math.PI / 2); ctx.fill();
    ctx.beginPath(); ctx.arc(c, c - r / 2, r / 2, 0, Math.PI * 2); ctx.fillStyle = "#16120e"; ctx.fill();
    ctx.beginPath(); ctx.arc(c, c + r / 2, r / 2, 0, Math.PI * 2); ctx.fillStyle = "#f4ead2"; ctx.fill();
    ctx.beginPath(); ctx.arc(c, c - r / 2, r / 7, 0, Math.PI * 2); ctx.fillStyle = "#f4ead2"; ctx.fill();
    ctx.beginPath(); ctx.arc(c, c + r / 2, r / 7, 0, Math.PI * 2); ctx.fillStyle = "#16120e"; ctx.fill();
    ctx.strokeStyle = "#e9c46a"; ctx.lineWidth = 6; ctx.beginPath(); ctx.arc(c, c, r, 0, Math.PI * 2); ctx.stroke();
  });
}
function muralCanvas() {
  return canvas(1024, 512, (ctx) => {
    const g = ctx.createLinearGradient(0, 0, 0, 512);
    g.addColorStop(0, "#3b1612"); g.addColorStop(1, "#24100d");
    ctx.fillStyle = g; ctx.fillRect(0, 0, 1024, 512);
    // auspicious clouds (祥云): spirals in faded gold and teal
    let seed = 7;
    const rand = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
    for (let i = 0; i < 70; i++) {
      const x = rand() * 1024, y = rand() * 512, s = 14 + rand() * 34;
      ctx.strokeStyle = rand() > 0.55 ? "rgba(214,170,90,.30)" : "rgba(90,150,140,.22)";
      ctx.lineWidth = 3 + rand() * 3;
      ctx.beginPath();
      for (let t = 0; t < 9; t += 0.25) { const rr = s * (1 - t / 10); ctx.lineTo(x + Math.cos(t) * rr, y + Math.sin(t) * rr * 0.7); }
      ctx.stroke();
    }
    ctx.fillStyle = "rgba(0,0,0,.25)"; ctx.fillRect(0, 470, 1024, 42);
  });
}
function latticeCanvas() {
  return canvas(256, 256, (ctx) => {
    const g = ctx.createLinearGradient(0, 0, 0, 256);
    g.addColorStop(0, "#d9dcc8"); g.addColorStop(1, "#8c977a");
    ctx.fillStyle = g; ctx.fillRect(0, 0, 256, 256);
    ctx.strokeStyle = "#2b211b"; ctx.lineWidth = 7;
    for (let i = 0; i <= 256; i += 42) { ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, 256); ctx.stroke(); ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(256, i); ctx.stroke(); }
  });
}
function floorCanvas() {
  return canvas(512, 512, (ctx) => {
    ctx.fillStyle = "#2b2523"; ctx.fillRect(0, 0, 512, 512);
    ctx.strokeStyle = "rgba(0,0,0,.45)"; ctx.lineWidth = 3;
    for (let i = 0; i <= 512; i += 128) { ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, 512); ctx.stroke(); ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(512, i); ctx.stroke(); }
  });
}
function glowCanvas(color: string) {
  return canvas(128, 128, (ctx) => {
    const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
    g.addColorStop(0, color); g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g; ctx.fillRect(0, 0, 128, 128);
  });
}

function webglAvailable() {
  try { const test = document.createElement("canvas"); return Boolean(test.getContext("webgl2") || test.getContext("webgl")); } catch { return false; }
}

export function StudyHall3D({ locale, navigate }: { locale: Locale; navigate: (route: AppRoute) => void }) {
  const hidden = useHiddenRoutes();
  const seats: Seat[] = methodCategories.flatMap((category) => category.routes.filter((route) => !hidden.includes(route)).map((route) => ({ route, name: DISCIPLE[route]?.[locale] ?? "", label: titleForRoute(route, locale), color: CATEGORY_COLOR[category.key] ?? "#e2b65c" })));
  const box = useRef<HTMLDivElement>(null);
  const labelsRef = useRef<Array<HTMLElement | null>>([]);
  const hoverRef = useRef<number>(-1);
  const [mode, setMode] = useState<"idle" | "loading" | "ready" | "fallback">("idle");
  const navigateRef = useRef(navigate);
  navigateRef.current = navigate;
  const seatKey = seats.map((seat) => seat.route).join(",");
  const presence = useHallPresence();
  const sceneRef = useRef<{ setVisitors(ids: string[], self?: string | null): void; goHome(): void; setLamps(lamps: Array<{ id: string; color: string; mine: boolean; fresh: boolean }>): void; setView(view: HallView): void; act(kind: HallAct, label?: string): void; hallSlots: number; slots: number } | null>(null);
  const [view, setViewState] = useState<HallView>("hall");
  const [hallSlots, setHallSlots] = useState(0);
  const [sound, setSound] = useState(false);
  const [counts, setCounts] = useState(() => readCounts());
  useEffect(() => () => setAmbience(false), []);
  const doAct = (kind: HallAct) => {
    if (kind === "fish") woodFish(); else if (kind === "bell") bell(); else if (kind === "beads") bead(); else if (kind === "palms") chime();
    const next = bumpCount(kind);
    setCounts(next);
    const label = kind === "fish" ? copy.calm[locale] : kind === "palms" ? copy.peace[locale] : kind === "beads" ? `${next.beads % 108 || 108} / 108` : undefined;
    sceneRef.current?.act(kind, label);
  };
  const hallLamps = useHallLamps();
  const freshLamps = useRef(new Set<string>());
  const visitorLabels = useRef(new Map<string, HTMLElement>());
  const [slots, setSlots] = useState(0);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState("");
  const [refused, setRefused] = useState(false);
  const [away, setAway] = useState(false);
  const visitors: HallVisitor[] = presence.self ? [presence.self, ...presence.others] : presence.others;
  // The hall always looks lively: empty places are filled by fellow students whose 道号 change from time to time,
  // so nobody can tell how many people are really online. Real visitors take the first places.
  const realCount = useRef(0);
  const [ambient, setAmbient] = useState<number[]>(() => Array.from({ length: 64 }, () => Math.floor(Math.random() * 1e6)));
  const [seatSeeds, setSeatSeeds] = useState<number[]>(() => Array.from({ length: 40 }, () => Math.floor(Math.random() * 1e6)));
  useEffect(() => {
    if (mode !== "ready") return;
    // Now and then someone in the front rows gets up and another member takes the seat, at irregular moments.
    let timer = 0;
    const step = () => {
      timer = window.setTimeout(() => {
        setSeatSeeds((items) => { const next = [...items]; const changes = Math.random() < 0.25 ? 2 : 1; for (let k = 0; k < changes; k += 1) next[Math.floor(Math.random() * next.length)] = Math.floor(Math.random() * 1e6); return next; });
        step();
      }, 2500 + Math.random() * 7500);
    };
    step();
    return () => window.clearTimeout(timer);
  }, [mode]);
  useEffect(() => {
    if (mode !== "ready") return;
    // People come and go at irregular moments (2–8 s), one or two at a time.
    let timer = 0;
    const step = () => { timer = window.setTimeout(() => { setAmbient((items) => {
      const next = [...items];
      // Every few seconds one or two people with a name tag leave and someone new sits down (names change).
      const tagged = next.map((_, index) => index).filter((index) => (index + realCount.current) % 3 === 1 && index + realCount.current < 36);
      for (let turn = 0; turn < 2; turn += 1) {
        const pool = turn === 0 && tagged.length ? tagged : next.map((_, index) => index);
        next[pool[Math.floor(Math.random() * pool.length)]] = Math.floor(Math.random() * 1e6);
      }
      return next;
    }); step(); }, 2000 + Math.random() * 6000); };
    step();
    return () => window.clearTimeout(timer);
  }, [mode]);
  realCount.current = visitors.length;
  // No two people in the hall share a name.
  // Compare without 子 / 居士 / 道人 / 散人, so 紫霞 and 紫霞道人 are not both present.
  const stem = (name: string) => name.replace(/(居士|道人|散人|子)$/, "");
  const usedNames = new Set(visitors.map((visitor) => stem(visitor.name)));
  // The front rows are fellow members too (no click-through): each has a natural name and the method on their desk.
  const seatNames = seats.map((seat, index) => {
    let dao = randomDaoName(`seat:${seatSeeds[index % seatSeeds.length]}:${seat.route}`);
    for (let k = 1; usedNames.has(stem(dao.name)) && k < 30; k += 1) dao = randomDaoName(`seat:${seatSeeds[index % seatSeeds.length]}:${seat.route}:${k}`);
    usedNames.add(stem(dao.name));
    return dao;
  });
  const ambientVisitors: HallVisitor[] = ambient.map((seed, index) => {
    let dao = randomDaoName(`ambient:${seed}`);
    for (let k = 1; usedNames.has(stem(dao.name)) && k < 30; k += 1) dao = randomDaoName(`ambient:${seed}:${k}`);
    usedNames.add(stem(dao.name));
    const route = seats.length ? seats[seed % (seats.length + 3)]?.route ?? null : null;
    return { id: `ambient-${index}`, name: dao.name, latin: dao.latin, custom: false, route };
  });
  const shown = [...visitors, ...ambientVisitors].slice(0, slots);
  // Every member has a name tag, but it only shows when they are close by (see `near` in the scene loop).
  const shownKey = shown.map((visitor) => visitor.id).join(",");
  useEffect(() => { sceneRef.current?.setVisitors(shown.map((visitor) => visitor.id), presence.self?.id ?? null); }, [shownKey, slots, presence.self?.id]); // eslint-disable-line react-hooks/exhaustive-deps
  const lampKey = hallLamps.lamps.map((lamp) => lamp.id).join(",");
  useEffect(() => {
    // Real lamps first; decorative lanterns keep the hall glowing (30 in all on wide screens, 20 on phones; more lamps hang in the courtyard maples).
    const real = hallLamps.lamps.map((lamp) => ({ id: lamp.id, color: LAMP_COLORS[lamp.kind], mine: lamp.mine, fresh: freshLamps.current.has(lamp.id) }));
    const kinds = Object.values(LAMP_COLORS);
    const target = typeof window !== "undefined" && window.innerWidth < 760 ? 20 : 30;
    const deco = Array.from({ length: Math.max(10, target - real.length) }, (_, index) => ({ id: `deco-${index}`, color: kinds[(index * 5 + 2) % kinds.length], mine: false, fresh: false }));
    sceneRef.current?.setLamps([...real, ...deco]);
  }, [lampKey, mode]); // eslint-disable-line react-hooks/exhaustive-deps
  const displaySeat = (dao: { name: string; latin: string }) => (["zh-Hans", "zh-Hant", "ja"].includes(locale) ? dao.name : dao.latin);
  const displayName = (visitor: HallVisitor) => (!visitor.custom && visitor.latin && !["zh-Hans", "zh-Hant", "ja"].includes(locale) ? visitor.latin : visitor.name);
  const routeTitle = (route: string | null) => {
    const known = seats.find((seat) => seat.route === route);
    return known ? copy.studying[locale].replace("{m}", known.label) : copy.onHome[locale];
  };
  const saveName = async (value: string) => {
    const ok = await setHallName(value);
    setRefused(!ok);
    if (ok) setEditing(false);
  };

  useEffect(() => {
    const host = box.current;
    if (!host) return;
    if (!webglAvailable()) { setMode("fallback"); return; }
    let disposed = false;
    let cleanup: (() => void) | null = null;
    const start = async () => {
      setMode("loading");
      let THREE: Three;
      try { THREE = await import(/* @vite-ignore */ THREE_URL) as Three; } catch { if (!disposed) setMode("fallback"); return; }
      if (disposed) return;
      const zh = locale === "zh-Hant" ? "研習殿" : "研习殿";
      const scene = buildScene(THREE, host, seats.length, labelsRef, hoverRef, () => undefined, visitorLabels, setAway, { plaque: zh, plaqueSmall: "XUANNOVA", gate: "道法自然", onView: setViewState });
      cleanup = () => { sceneRef.current = null; scene.dispose(); };
      sceneRef.current = scene;
      setSlots(scene.slots); setHallSlots(scene.hallSlots);
      setMode("ready");
    };
    // Load three.js only when the hall is about to be seen.
    const watcher = new IntersectionObserver((entries) => { if (entries.some((entry) => entry.isIntersecting)) { watcher.disconnect(); void start(); } }, { rootMargin: "200px" });
    watcher.observe(host);
    return () => { disposed = true; watcher.disconnect(); cleanup?.(); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seatKey]);

  return <section className="study-hall" id="hall" aria-labelledby="study-hall-title">
    <header>
      <p>{copy.eyebrow[locale]}</p>
      <h2 id="study-hall-title">{copy.title[locale]}</h2>
      <span>{copy.lead[locale]}</span>
    </header>
    <div className={`study-hall-stage is-${mode}`} ref={box}>
      {mode === "loading" && <p className="study-hall-loading">{copy.loading[locale]}</p>}
      {mode !== "fallback" && seats.map((seat, index) => <span key={seat.route} ref={(element) => { labelsRef.current[index] = element; }} className="study-hall-label is-visitor is-seat">
        <span><b>{displaySeat(seatNames[index])}</b>{index % 3 === 0 && <small>{copy.studying[locale].replace("{m}", seat.label)}</small>}</span></span>)}
      {mode === "ready" && shown.map((visitor, index) => ({ visitor, index })).map(({ visitor, index }) => <span key={visitor.id} ref={(element) => { if (element) visitorLabels.current.set(visitor.id, element); else visitorLabels.current.delete(visitor.id); }}
        className={`study-hall-label is-visitor${index === 0 && presence.self?.id === visitor.id ? " is-self" : ""}`}
>
        <span><b>{index === 0 && presence.self?.id === visitor.id ? `${copy.you[locale]} · ${displayName(visitor)}` : displayName(visitor)}</b><small>{index === 0 && presence.self?.id === visitor.id && away ? copy.strolling[locale] : hallSlots > 0 && index >= hallSlots ? copy.inYard[locale] : routeTitle(visitor.route)}</small></span></span>)}
      {mode === "ready" && <div className="study-hall-views" role="group" aria-label={copy.viewYard[locale]}>
      {(["hall", "yard"] as const).map((key) => <button type="button" key={key} className={view === key ? "active" : ""} aria-pressed={view === key} onClick={() => sceneRef.current?.setView(key)}>{key === "hall" ? copy.viewHall[locale] : copy.viewYard[locale]}</button>)}
      {away && <button type="button" className={view === "follow" ? "active" : ""} aria-pressed={view === "follow"} onClick={() => sceneRef.current?.setView("follow")}>{copy.viewFollow[locale]}</button>}
      <button type="button" className={`study-hall-sound${sound ? " active" : ""}`} aria-pressed={sound} onClick={() => { setAmbience(!sound); setSound(!sound); }}>{sound ? "🔊" : "🔈"} {copy.sound[locale]}</button>
    </div>}
      {mode === "ready" && <div className="study-hall-actions" role="group" aria-label={copy.palms[locale]}>
      {ACTS.map(([kind, icon]) => <button type="button" key={kind} onClick={() => doAct(kind)}><i aria-hidden="true" dangerouslySetInnerHTML={{ __html: icon }} /><span>{copy[kind][locale]}</span>{(kind === "fish" || kind === "beads") && counts[kind] > 0 && <em>{kind === "beads" ? `${counts.beads % 108 || 108}` : counts.fish}</em>}</button>)}
    </div>}
      {mode === "fallback" && <div className="study-hall-fallback">{seats.map((seat, index) => <span key={seat.route} style={{ ["--seat-color" as string]: seat.color }}><i aria-hidden="true" />{displaySeat(seatNames[index])} · {copy.studying[locale].replace("{m}", seat.label)}</span>)}</div>}
    </div>
    {mode === "ready" && presence.self && <div className="study-hall-walk">
      <span>{away ? copy.walking[locale] : copy.walkHint[locale]}</span>
      {away && <button type="button" className="text-action" onClick={() => sceneRef.current?.goHome()}>{copy.backToSeat[locale]}</button>}
    </div>}
    <div className="study-hall-presence" aria-live="polite">
      {presence.self && !editing && <span className="study-hall-me">{copy.yourName[locale]}：<b>{displayName(presence.self)}</b>
        <button type="button" className="text-action" onClick={() => { setDraft(presence.self?.custom ? presence.self.name : ""); setRefused(false); setEditing(true); }}>{copy.rename[locale]}</button></span>}
      {presence.self && editing && <form className="study-hall-rename" onSubmit={(event) => { event.preventDefault(); void saveName(draft.trim()); }}>
        <input value={draft} maxLength={20} onChange={(event) => setDraft(event.target.value)} placeholder={copy.placeholder[locale]} aria-label={copy.yourName[locale]} autoFocus />
        <button type="submit" className="secondary-action" disabled={!draft.trim()}>{copy.save[locale]}</button>
        {presence.self.custom && <button type="button" className="text-action" onClick={() => void saveName("")}>{copy.random[locale]}</button>}
        <button type="button" className="text-action" onClick={() => { setEditing(false); setRefused(false); }}>{copy.cancel[locale]}</button>
        {refused && <small role="alert">{copy.refused[locale]}</small>}
      </form>}
    </div>
    <HallLamps locale={locale} lamps={hallLamps.lamps} cost={hallLamps.cost} selfName={presence.self?.custom ? presence.self.name : null} openMembership={() => navigate("membership" as AppRoute)}
      onLit={(lamp) => { freshLamps.current.add(lamp.id); hallLamps.add(lamp); window.setTimeout(() => document.querySelector(".study-hall-stage")?.scrollIntoView({ behavior: "smooth", block: "center" }), 50); }} />
  </section>;
}

export type HallView = "hall" | "yard" | "follow";
export type HallAct = "palms" | "bow" | "fish" | "beads" | "bell";

function textSprite(THREE: Three, text: string, color = "#ffe1a0") {
  const element = document.createElement("canvas"); element.width = 512; element.height = 128;
  const ctx = element.getContext("2d");
  if (ctx) { ctx.font = '700 64px "Noto Serif SC", "Noto Sans", sans-serif'; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.shadowColor = "rgba(0,0,0,.7)"; ctx.shadowBlur = 12; ctx.fillStyle = color; ctx.fillText(text, 256, 64); }
  const map = new THREE.CanvasTexture(element); map.colorSpace = THREE.SRGBColorSpace;
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map, transparent: true, depthWrite: false, depthTest: false }));
  sprite.scale.set(2.6, 0.65, 1);
  return sprite;
}

function buildScene(THREE: Three, host: HTMLDivElement, count: number, labelsRef: { current: Array<HTMLElement | null> }, hoverRef: { current: number }, open: (index: number) => void, visitorLabels: { current: Map<string, HTMLElement> }, onSelfAway: (away: boolean) => void = () => undefined, extras: { plaque: string; plaqueSmall: string; gate: string; onView: (view: HallView) => void } = { plaque: "研习殿", plaqueSmall: "Xuannova", gate: "玄门", onView: () => undefined }) {
  const reduce = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: "low-power" });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.domElement.className = "study-hall-canvas";
  host.prepend(renderer.domElement);
  const scene = new THREE.Scene();
  scene.background = new THREE.Color("#2a3557");
  scene.fog = new THREE.Fog("#7a6670", 40, 170);
  const camera = new THREE.PerspectiveCamera(40, 1, 0.1, 400);
  const texture = (source: HTMLCanvasElement, repeat = 1) => { const t = new THREE.CanvasTexture(source); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; if (repeat !== 1) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(repeat, repeat); } return t; };

  scene.add(new THREE.HemisphereLight("#f5e3c0", "#1b1210", 0.85));
  const key = new THREE.DirectionalLight("#ffe2b0", 1.1); key.position.set(-6, 10, 6); scene.add(key);
  // low dusk sun over the courtyard
  const sun = new THREE.DirectionalLight("#ffcf98", 1.15); sun.position.set(-40, 30, 90); scene.add(sun);
  const altarLight = new THREE.PointLight("#ffb85c", 26, 14, 1.6); altarLight.position.set(0, 4, -5); scene.add(altarLight);

  // Floor, walls, window
  const pillarMat = new THREE.MeshStandardMaterial({ color: "#3b2a22", roughness: 0.8 });
  for (const x of [-9, 9]) { const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.5, 11, 16), pillarMat); pillar.position.set(x, 5.5, -7.5); scene.add(pillar); }

  // Altar with the standing taiji-bagua disc
  const stone = new THREE.MeshStandardMaterial({ color: "#3a332e", roughness: 0.85 });
  const step1 = new THREE.Mesh(new THREE.BoxGeometry(9, 0.5, 3.2), stone); step1.position.set(0, 0.25, -6.6); scene.add(step1);
  const step2 = new THREE.Mesh(new THREE.BoxGeometry(6.4, 0.5, 2.4), stone); step2.position.set(0, 0.75, -6.8); scene.add(step2);
  const lotus = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.9, 0.5, 32), new THREE.MeshStandardMaterial({ color: "#b8893a", metalness: 0.6, roughness: 0.35 }));
  lotus.position.set(0, 1.25, -6.9); scene.add(lotus);
  const discGroup = new THREE.Group(); discGroup.position.set(0, 3.9, -7.1); scene.add(discGroup);
  // The disc lights itself (its own pattern as emissive), so it stays bright from every angle and on dim phone screens.
  const discTexture = texture(taijiBaguaCanvas());
  const discFace = new THREE.Mesh(new THREE.CircleGeometry(2.2, 96), new THREE.MeshStandardMaterial({ map: discTexture, emissiveMap: discTexture, roughness: 0.4, metalness: 0.1, emissive: new THREE.Color("#ffffff"), emissiveIntensity: 0.55 }));
  discGroup.add(discFace);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(2.22, 0.11, 12, 96), new THREE.MeshStandardMaterial({ color: "#d9b25c", metalness: 0.8, roughness: 0.3 }));
  discGroup.add(rim);
  const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture(glowCanvas("rgba(255,200,110,.75)")), depthWrite: false, transparent: true }));
  halo.scale.set(8, 8, 1); halo.position.set(0, 3.9, -7.4); scene.add(halo);
  const discLight = new THREE.SpotLight("#ffe2a8", 30, 14, 0.5, 0.6, 1.4); discLight.position.set(0, 6.5, -2.5); discLight.target.position.set(0, 3.9, -7.1); scene.add(discLight, discLight.target);
  const stand = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.25, 1.6, 12), new THREE.MeshStandardMaterial({ color: "#8a6428", metalness: 0.6, roughness: 0.4 }));
  stand.position.set(0, 1.7, -7.1); scene.add(stand);

  // Candles and vases
  const flames: Array<{ sprite: any; light: any; phase: number }> = []; // eslint-disable-line @typescript-eslint/no-explicit-any
  for (const x of [-3.2, 3.2]) {
    const holder = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.3, 0.9, 12), new THREE.MeshStandardMaterial({ color: "#b8893a", metalness: 0.7, roughness: 0.35 }));
    holder.position.set(x, 1.45, -6.2); scene.add(holder);
    const candle = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.8, 12), new THREE.MeshStandardMaterial({ color: "#f3ead8", roughness: 0.6 }));
    candle.position.set(x, 2.3, -6.2); scene.add(candle);
    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture(glowCanvas("rgba(255,200,110,1)")), depthWrite: false, transparent: true, blending: THREE.AdditiveBlending }));
    sprite.scale.set(0.5, 0.8, 1); sprite.position.set(x, 2.85, -6.2); scene.add(sprite);
    const light = new THREE.PointLight("#ffb25c", 4, 6, 2); light.position.set(x, 2.9, -6); scene.add(light);
    flames.push({ sprite, light, phase: Math.random() * 10 });
    const vase = new THREE.Mesh(new THREE.SphereGeometry(0.35, 16, 12), new THREE.MeshStandardMaterial({ color: "#5f8f86", roughness: 0.4 }));
    vase.scale.set(1, 1.3, 1); vase.position.set(x * 1.35, 1.0, -6.0); scene.add(vase);
  }

  // Disciples on mats: rows facing the altar
  // Phones (tall frame): four per row and a steeper view so the rows separate; wide screens: six per row.
  const narrow = host.clientWidth / Math.max(1, host.clientHeight) < 0.9;
  const perRow = narrow ? 4 : count > 16 ? 6 : 5;
  const spacing = narrow ? 2.05 : 2.3;
  const robe = new THREE.MeshStandardMaterial({ color: "#c9d2d6", roughness: 0.8 });
  const sash = new THREE.MeshStandardMaterial({ color: "#e3c35a", roughness: 0.6 });
  const skin = new THREE.MeshStandardMaterial({ color: "#e09a62", roughness: 0.55 });
  const hair = new THREE.MeshStandardMaterial({ color: "#2b1f18", roughness: 0.7 });
  const matMat = new THREE.MeshStandardMaterial({ color: "#3f3b39", roughness: 0.9 });
  const shadowTex = texture(glowCanvas("rgba(0,0,0,.6)"));
  const bodyGeo = new THREE.CylinderGeometry(0.34, 0.5, 0.75, 16);
  const sashGeo = new THREE.CylinderGeometry(0.37, 0.4, 0.16, 16);
  const headGeo = new THREE.SphereGeometry(0.36, 20, 16);
  const bunGeo = new THREE.SphereGeometry(0.13, 12, 10);
  const matGeo = new THREE.BoxGeometry(1.1, 0.12, 1.1);
  const disciples: Array<{ group: any; head: any; phase: number; base: number }> = []; // eslint-disable-line @typescript-eslint/no-explicit-any
  const pickables: any[] = []; // eslint-disable-line @typescript-eslint/no-explicit-any
  for (let index = 0; index < count; index++) {
    const row = Math.floor(index / perRow), col = index % perRow;
    const inRow = Math.min(perRow, count - row * perRow);
    const xPos = (col - (inRow - 1) / 2) * spacing + (row % 2 ? 0.3 : -0.3);
    const zPos = -3.6 + row * 2.2;
    const mat = new THREE.Mesh(matGeo, matMat); mat.position.set(xPos, 0.06, zPos); scene.add(mat);
    const shadow = new THREE.Mesh(new THREE.PlaneGeometry(1.3, 1.3), new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, depthWrite: false }));
    shadow.rotation.x = -Math.PI / 2; shadow.position.set(xPos, 0.13, zPos); scene.add(shadow);
    const group = new THREE.Group(); group.position.set(xPos, 0.12, zPos);
    group.rotation.y = Math.atan2(-xPos * 0.15, -1) + Math.PI; // face the altar, slightly turned inward
    const body = new THREE.Mesh(bodyGeo, robe); body.position.y = 0.38; group.add(body);
    const band = new THREE.Mesh(sashGeo, sash); band.position.y = 0.48; band.rotation.z = 0.35; group.add(band);
    const head = new THREE.Mesh(headGeo, skin); head.position.y = 1.02; group.add(head);
    const bun = new THREE.Mesh(bunGeo, hair); bun.position.set(0, 1.4, 0.02); group.add(bun);
    const cap = new THREE.Mesh(new THREE.SphereGeometry(0.37, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2.6), hair); cap.position.y = 1.03; cap.rotation.x = -0.25; group.add(cap);
    for (const part of [body, band, head, bun, cap, mat]) { part.userData.seat = index; pickables.push(part); }
    scene.add(group);
    disciples.push({ group, head: new THREE.Vector3(xPos, 1.75, zPos), phase: index * 0.7, base: 0.12 });
  }

  // Fellow visitors (同殿共修): extra disciples on the side aisles (wide screens) or in rows behind (phones).
  const rows = Math.ceil(count / perRow);
  const halfWidth = ((perRow - 1) / 2) * spacing + 0.3;
  // A full hall: two columns on each side aisle plus rows behind the disciples (phones: rows behind only).
  const backRows = (count: number, perLine: number, gap: number) => Array.from({ length: count }, (_, index) => ({ x: ((index % perLine) - (perLine - 1) / 2) * gap + (Math.floor(index / perLine) % 2 ? gap / 2 : 0) * 0.5, z: -3.6 + (rows + Math.floor(index / perLine)) * 2.1 }));
  const visitorSlots: Array<{ x: number; z: number; outdoor?: boolean; face?: number }> = narrow
    ? backRows(16, 4, spacing)
    : [
        ...Array.from({ length: 24 }, (_, index) => ({ x: (index % 2 ? 1 : -1) * (halfWidth + 2.2 + (Math.floor(index / 2) % 2) * 1.9), z: -4.4 + Math.floor(index / 4) * 2.1 })),
        ...backRows(Math.max(perRow, 5) * 2, Math.max(perRow, 5), spacing),
      ];
  // Members wear robes in a few quiet colours, so the crowd does not look cloned.
  const robeColours = ["#8fa9a6", "#a7a08c", "#7f8fa6", "#9c8f9e", "#8ea58a", "#b0a48a", "#93a0ad"];
  const robes = robeColours.map((color) => new THREE.MeshStandardMaterial({ color, roughness: 0.8 }));
  const selfRobe = new THREE.MeshStandardMaterial({ color: "#e6c470", roughness: 0.6, emissive: new THREE.Color("#3a2a08"), emissiveIntensity: 0.4 });
  type Figure = { group: any; mat: any; shadow: any; slot: number; phase: number; self: boolean; target: { x: number; z: number } | null; waitUntil: number; outing: boolean; leg: number; face: number | null; act: { kind: HallAct; start: number } | null; via: { x: number; z: number } | null }; // eslint-disable-line @typescript-eslint/no-explicit-any
  const visitorFigures = new Map<string, Figure>(); // eslint-disable-line @typescript-eslint/no-explicit-any
  const makeVisitor = (slot: number, self: boolean) => {
    const { x, z, outdoor, face } = visitorSlots[slot];
    const mat = new THREE.Mesh(matGeo, matMat); mat.position.set(x, 0.06, z); mat.visible = !outdoor; scene.add(mat);
    const shadow = new THREE.Mesh(new THREE.PlaneGeometry(1.3, 1.3), new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, depthWrite: false }));
    shadow.rotation.x = -Math.PI / 2; shadow.position.set(x, 0.13, z); scene.add(shadow);
    const group = new THREE.Group(); group.position.set(x, 0.12, z);
    group.rotation.y = outdoor ? face ?? 0 : Math.atan2(-x * 0.15, -1) + Math.PI;
    const body = new THREE.Mesh(bodyGeo, self ? selfRobe : robes[(slot * 5 + 3) % robes.length]); body.position.y = 0.38; group.add(body);
    const head = new THREE.Mesh(headGeo, skin); head.position.y = 1.02; group.add(head);
    const bun = new THREE.Mesh(bunGeo, hair); bun.position.set(0, 1.4, 0.02); group.add(bun);
    group.scale.setScalar(0.86 + ((slot * 37) % 10) / 100);
    scene.add(group);
    return { group, mat, shadow };
  };
  let selfId: string | null = null;
  const setVisitors = (ids: string[], self: string | null = null) => {
    selfId = self;
    const wanted = new Set(ids.slice(0, visitorSlots.length));
    for (const [id, figure] of visitorFigures) if (!wanted.has(id)) { scene.remove(figure.group, figure.mat, figure.shadow); visitorFigures.delete(id); }
    const used = new Set([...visitorFigures.values()].map((figure) => figure.slot));
    ids.slice(0, visitorSlots.length).forEach((id, index) => {
      if (visitorFigures.has(id)) return;
      const slot = [...visitorSlots.keys()].find((candidate) => !used.has(candidate))!;
      used.add(slot);
      visitorFigures.set(id, { ...makeVisitor(slot, self ? id === self : index === 0), slot, phase: Math.random() * 6, self: id === self, target: null, waitUntil: Math.random() * 6, outing: false, leg: (slot * 3) % yard.loop.length, face: null, act: null, via: null });
    });
  };

  // 祈福灯: real lamps hang above the hall; a newly lit one rises from the floor to its place.
  type Lantern = { group: any; glow: any; light: any | null; x: number; y: number; z: number; phase: number; born: number; spot: number }; // eslint-disable-line @typescript-eslint/no-explicit-any
  const lanterns = new Map<string, Lantern>();
  const lanternGlow = texture(glowCanvas("rgba(255,190,100,1)"));
  const lanternBody = new THREE.CylinderGeometry(0.26, 0.26, 0.5, 14, 1, true);
  const lanternCap = new THREE.CylinderGeometry(0.18, 0.2, 0.07, 12);
  const capMat = new THREE.MeshStandardMaterial({ color: "#c9a14a", metalness: 0.7, roughness: 0.35 });
  const lanternSpot = (index: number) => {
    // Golden-angle spiral over the hall, high enough to stay above the name tags.
    const angle = index * 2.39996, radius = (narrow ? 1.6 : 2.4) + Math.sqrt(index) * (narrow ? 1.05 : 1.55);
    // Wide screens: keep lanterns over the back half of the hall, so none hangs right in front of the camera.
    if (narrow) {
      let x = Math.max(-5.2, Math.min(5.2, Math.cos(angle) * radius * 1.25));
      const z = Math.max(-6.2, Math.min(4.5, -0.8 + Math.sin(angle) * radius * 0.7));
      // Keep the view of the taiji disc clear: lanterns in front of it move out to the sides.
      if (Math.abs(x) < 2.6 && z < 1.5) x = (x < 0 ? -1 : 1) * (2.6 + Math.abs(x) * 0.6);
      return { x, y: 5.0 + ((index * 7) % 5) * 0.32, z };
    }
    return { x: Math.max(-9, Math.min(9, Math.cos(angle) * radius * 1.45)), y: 5.4 + ((index * 7) % 5) * 0.38, z: Math.max(-7, Math.min(-0.5, -3.6 + Math.sin(angle) * radius * 0.45)) };
  };
  const setLamps = (lamps: Array<{ id: string; color: string; mine: boolean; fresh: boolean }>) => {
    const wanted = new Set(lamps.slice(0, 40).map((lamp) => lamp.id));
    for (const [id, lantern] of lanterns) if (!wanted.has(id)) { scene.remove(lantern.group, lantern.glow); if (lantern.light) scene.remove(lantern.light); lanterns.delete(id); }
    lamps.slice(0, 40).forEach((lamp) => {
      if (lanterns.has(lamp.id)) return;
      const taken = new Set([...lanterns.values()].map((item) => item.spot));
      let spotIndex = 0; while (taken.has(spotIndex)) spotIndex += 1;
      const spot = lanternSpot(spotIndex);
      const group = new THREE.Group();
      const body = new THREE.Mesh(lanternBody, new THREE.MeshStandardMaterial({ color: lamp.color, emissive: new THREE.Color(lamp.color), emissiveIntensity: 0.85, roughness: 0.6, side: THREE.DoubleSide, transparent: true, opacity: 0.95 }));
      body.scale.set(1, 1, 1);
      const top = new THREE.Mesh(lanternCap, capMat); top.position.y = 0.28;
      const bottom = new THREE.Mesh(lanternCap, capMat); bottom.position.y = -0.28;
      const cord = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 1.2, 4), capMat); cord.position.y = 0.9;
      group.add(body, top, bottom, cord); group.scale.setScalar(narrow ? 1.5 : 1.15);
      const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: lanternGlow, color: new THREE.Color(lamp.color), depthWrite: false, transparent: true, blending: THREE.AdditiveBlending, opacity: 0.75 }));
      glow.scale.set(2.8, 2.8, 1);
      // Only a few lanterns carry a real light (the member's own first), to stay light on phones.
      const light = lamp.mine && [...lanterns.values()].filter((item) => item.light).length < 3 ? new THREE.PointLight(lamp.color, 2.2, 5, 2) : null;
      scene.add(group, glow); if (light) scene.add(light);
      lanterns.set(lamp.id, { group, glow, light, ...spot, spot: spotIndex, phase: Math.random() * 6, born: lamp.fresh && !reduce ? clockStart() : -1 });
    });
  };
  let clockRef: { getElapsedTime(): number } | null = null;
  const clockStart = () => clockRef?.getElapsedTime() ?? 0;

  // A few members stroll the aisles around the rows, sometimes stopping to bow towards the altar.
  const lastZ = Math.max(...visitorSlots.map((slot) => slot.z), -3.6 + rows * 1.9);
  // The hall is now the main hall of a temple compound: floor, back mural and side windows inside, then the
  // courtyard outside (hall-courtyard.ts) with its own strolling members.
  const hallHalf = Math.max(12.5, halfWidth + 6.5);
  const frontZ = Math.max(12, lastZ + 3.5);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(hallHalf * 2 + 0.6, frontZ + 9.6), new THREE.MeshStandardMaterial({ map: texture(floorCanvas(), 8), roughness: 0.9 }));
  floor.rotation.x = -Math.PI / 2; floor.position.set(0, 0.002, (frontZ - 9.6) / 2); scene.add(floor);
  const mural = new THREE.Mesh(new THREE.PlaneGeometry(hallHalf * 2 + 0.6, 11), new THREE.MeshStandardMaterial({ map: texture(muralCanvas()), roughness: 1 }));
  mural.position.set(0, 5.5, -9.2); scene.add(mural);
  const latticeTex = texture(latticeCanvas());
  for (const side of [-1, 1]) for (const wz of [-1, frontZ * 0.55]) {
    const pane = new THREE.Mesh(new THREE.PlaneGeometry(6, 4), new THREE.MeshBasicMaterial({ map: latticeTex }));
    pane.rotation.y = side * -Math.PI / 2; pane.position.set(side * (hallHalf + 0.08), 4.5, wz); scene.add(pane);
  }
  const yard = buildCourtyard(THREE, scene, { frontZ, hallHalf, narrow, plaque: extras.plaque, plaqueSmall: extras.plaqueSmall, gate: extras.gate });
  const hallSlots = visitorSlots.length;
  // Members out in the courtyard (phones: fewer, to stay smooth).
  const outdoorCount = narrow ? 10 : 16;
  for (let index = 0; index < outdoorCount; index += 1) {
    const spot = yard.spots[index % yard.spots.length];
    const onLoop = index >= yard.spots.length;
    const point = onLoop ? yard.loop[(index * 3) % yard.loop.length] : [spot.x, spot.z] as [number, number];
    visitorSlots.push({ x: point[0] + (onLoop ? 0 : 0), z: point[1], outdoor: true, face: onLoop ? 0 : spot.face });
  }
  // Members under the trees (no name tags): some sit in meditation, some stand looking at the maples.
  const shadeFigures = yard.treeSpots.slice(0, narrow ? 8 : 14).map((spot, index) => {
    const group = new THREE.Group();
    const sitting = index % 3 !== 1;
    const body = new THREE.Mesh(bodyGeo, robes[(index * 3 + 1) % robes.length]); body.position.y = 0.38; group.add(body);
    const head = new THREE.Mesh(headGeo, skin); head.position.y = 1.02; group.add(head);
    const bun = new THREE.Mesh(bunGeo, hair); bun.position.set(0, 1.4, 0.02); group.add(bun);
    if (sitting) { const cushion = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.6, 0.18, 14), matMat); cushion.position.y = 0.05; group.add(cushion); group.scale.set(1, 0.86, 1); }
    group.position.set(spot.x, sitting ? 0.1 : 0.12, spot.z); group.rotation.y = spot.face;
    const shadow = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1.2), new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, depthWrite: false }));
    shadow.rotation.x = -Math.PI / 2; shadow.position.set(spot.x, 0.02, spot.z);
    scene.add(group, shadow);
    return { group, base: group.position.y, phase: index * 1.3 };
  });

  const aisleX = halfWidth + (narrow ? 0.75 : 1.1);
  const loop4 = [[-aisleX, -5.0], [aisleX, -5.0], [aisleX, lastZ + 1.2], [-aisleX, lastZ + 1.2]] as const;
  const loopLength = loop4.reduce((sum, point, index) => { const next = loop4[(index + 1) % 4]; return sum + Math.hypot(next[0] - point[0], next[1] - point[1]); }, 0);
  const pointAt = (distanceAlong: number) => {
    let left = ((distanceAlong % loopLength) + loopLength) % loopLength;
    for (let index = 0; index < 4; index += 1) {
      const a = loop4[index], b = loop4[(index + 1) % 4], length = Math.hypot(b[0] - a[0], b[1] - a[1]);
      if (left <= length) { const k = left / length; return { x: a[0] + (b[0] - a[0]) * k, z: a[1] + (b[1] - a[1]) * k, dx: b[0] - a[0], dz: b[1] - a[1], front: index === 0 }; }
      left -= length;
    }
    return { x: loop4[0][0], z: loop4[0][1], dx: 1, dz: 0, front: true };
  };
  const walkerRobes = ["#6f8fb3", "#b07a5a", "#7aa37a", "#9a7fb0"].map((color) => new THREE.MeshStandardMaterial({ color, roughness: 0.75 }));
  const walkers = Array.from({ length: narrow ? 3 : 4 }, (_, index) => {
    const group = new THREE.Group();
    const body = new THREE.Mesh(bodyGeo, walkerRobes[index % walkerRobes.length]); body.position.y = 0.38; group.add(body);
    const head = new THREE.Mesh(headGeo, skin); head.position.y = 1.02; group.add(head);
    const bun = new THREE.Mesh(bunGeo, hair); bun.position.set(0, 1.4, 0.02); group.add(bun);
    group.scale.setScalar(1.0 + index * 0.03);
    const shadow = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1.2), new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, depthWrite: false }));
    shadow.rotation.x = -Math.PI / 2;
    scene.add(group, shadow);
    return { group, shadow, along: (loopLength / (narrow ? 3 : 4)) * index + Math.random() * 2, speed: 0.45 + Math.random() * 0.25, pauseUntil: 0, bowed: false, direction: index % 2 ? -1 : 1 };
  });
  let lastWalkTime = 0;
  const moveWalkers = (time: number) => {
    const dt = Math.min(0.1, time - lastWalkTime); lastWalkTime = time;
    for (const walker of walkers) {
      const paused = time < walker.pauseUntil;
      if (!paused && !reduce) walker.along += walker.speed * dt * walker.direction;
      const point = pointAt(walker.along);
      // Passing the middle of the front aisle: half of the time, stop and bow to the altar for a moment.
      if (!paused && point.front && Math.abs(point.x) < 0.15) { if (!walker.bowed && Math.random() < 0.5) walker.pauseUntil = time + 2.5; walker.bowed = true; }
      if (!point.front || Math.abs(point.x) > 1) walker.bowed = false;
      const step = paused || reduce ? 0 : Math.abs(Math.sin(walker.along * 5.5)) * 0.06;
      walker.group.position.set(point.x, 0.12 + step, point.z);
      const facing = paused ? 0 : Math.atan2(-point.dx * walker.direction, -point.dz * walker.direction);
      walker.group.rotation.y += ((facing - walker.group.rotation.y + Math.PI * 3) % (Math.PI * 2) - Math.PI) * 0.15;
      walker.group.rotation.x = paused && time < walker.pauseUntil - 0.6 ? 0.28 : (paused ? 0 : Math.sin(walker.along * 5.5) * 0.03);
      walker.shadow.position.set(point.x, 0.13, point.z);
    }
  };

  // Camera: three views. 殿内 looks over the rows to the altar, 庭院 looks from the gate side back to the hall, and
  // 跟随 stays behind your own figure while you walk. Drag to look around; views glide into each other.
  const target = narrow ? new THREE.Vector3(0, 1.6, 1.6) : new THREE.Vector3(0, 2.0, -3.0);
  const targetGoal = target.clone();
  let yaw = 0, yawGoal = 0, distance = 14, hallDistance = 14;
  let pitch = narrow ? 0.62 : 0.36;
  let view: HallView = "hall";
  const yardSpan = yard.gateZ - frontZ;
  const viewGoal = () => {
    if (view === "yard") { targetGoal.set(0, 2.5, frontZ + yardSpan * (narrow ? 0.36 : 0.42)); return { distance: narrow ? 44 : 44, pitch: narrow ? 0.46 : 0.36, limit: 1.3 }; }
    if (view === "follow") {
      const me = selfId ? visitorFigures.get(selfId) : null;
      if (me) targetGoal.set(me.group.position.x, 1.3, me.group.position.z);
      return { distance: narrow ? 13 : 10.5, pitch: narrow ? 0.5 : 0.4, limit: Infinity };
    }
    targetGoal.set(0, narrow ? 1.6 : 2.0, narrow ? 1.6 : -3.0);
    return { distance: hallDistance, pitch: narrow ? 0.62 : 0.36, limit: 0.55 };
  };
  let yawLimit = 0.55;
  const setView = (next: HallView) => {
    if (next === view) return;
    view = next;
    if (next !== "follow") yawGoal = 0;
    extras.onView(next);
  };
  const placeCamera = () => {
    camera.position.set(target.x + Math.sin(yaw) * distance * Math.cos(pitch), target.y + Math.sin(pitch) * distance, target.z + Math.cos(yaw) * distance * Math.cos(pitch));
    camera.lookAt(target);
  };
  let dragging = false, dragX = 0, moved = 0;
  const onDown = (event: PointerEvent) => { dragging = true; dragX = event.clientX; moved = 0; };
  const onMove = (event: PointerEvent) => {
    if (!dragging) return;
    const dx = event.clientX - dragX; dragX = event.clientX; moved += Math.abs(dx);
    yawGoal = Math.max(-yawLimit, Math.min(yawLimit, yawGoal - dx * 0.004));
  };
  const raycaster = new THREE.Raycaster(); const pointer = new THREE.Vector2();
  const onUp = (event: PointerEvent) => {
    if (!dragging) return; dragging = false;
    if (moved > 6) return;
    const rect = renderer.domElement.getBoundingClientRect();
    pointer.set(((event.clientX - rect.left) / rect.width) * 2 - 1, -((event.clientY - rect.top) / rect.height) * 2 + 1);
    raycaster.setFromCamera(pointer, camera);
    const hit = raycaster.intersectObjects(pickables, false)[0];
    if (hit && typeof hit.object.userData.seat === "number") open(hit.object.userData.seat);
    // Tap the floor: your own figure gets up and walks there.
    const me = selfId ? visitorFigures.get(selfId) : null;
    if (!me || !raycaster.ray.intersectPlane(floorPlane, floorHit)) return;
    routeTo(me, yard.clamp(floorHit.x, floorHit.z));
    me.act = null;
    onSelfAway(true);
    setView("follow");
  };
  const floorPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0), floorHit = new THREE.Vector3();
  // Your own walk: through the open front of the hall, never through a side wall.
  const routeTo = (me: Figure, dest: { x: number; z: number }) => {
    me.target = dest; me.via = null;
    const inside = (z: number) => z < frontZ - 0.6;
    const from = me.group.position;
    if (inside(from.z) !== inside(dest.z)) {
      const outsideX = inside(from.z) ? dest.x : from.x;
      if (Math.abs(outsideX) > hallHalf - 1.2 || Math.abs(inside(from.z) ? from.x : dest.x) > hallHalf - 1.2) me.via = { x: Math.max(-hallHalf + 1.5, Math.min(hallHalf - 1.5, outsideX)), z: frontZ + 0.8 };
    }
  };
  const goHome = () => { const me = selfId ? visitorFigures.get(selfId) : null; if (me) { const slot = visitorSlots[me.slot]; routeTo(me, { x: slot.x, z: slot.z }); setView("follow"); } };
  // Actions for your own figure: join palms, bow three times, strike the wooden fish, count beads, ring the bell.
  const floaters: Array<{ sprite: any; born: number; x: number; z: number }> = []; // eslint-disable-line @typescript-eslint/no-explicit-any
  const ringTex = texture(glowCanvas("rgba(255,214,140,.9)"));
  const rings: Array<{ sprite: any; born: number }> = []; // eslint-disable-line @typescript-eslint/no-explicit-any
  const act = (kind: HallAct, label?: string) => {
    const me = selfId ? visitorFigures.get(selfId) : null;
    if (!me) return;
    const time = clock.getElapsedTime();
    if (!me.target) me.act = { kind, start: time };
    const { x, z } = me.group.position;
    if (label) { const sprite = textSprite(THREE, label); scene.add(sprite); floaters.push({ sprite, born: time, x, z }); }
    if (kind === "bell" || kind === "palms") { const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: ringTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending })); sprite.position.set(x, 1.2, z); scene.add(sprite); rings.push({ sprite, born: time }); }
  };
  const onHover = (event: PointerEvent) => {
    if (dragging || event.pointerType !== "mouse") return;
    const rect = renderer.domElement.getBoundingClientRect();
    pointer.set(((event.clientX - rect.left) / rect.width) * 2 - 1, -((event.clientY - rect.top) / rect.height) * 2 + 1);
    raycaster.setFromCamera(pointer, camera);
    const hit = raycaster.intersectObjects(pickables, false)[0];
    hoverRef.current = hit ? hit.object.userData.seat : -1;
    renderer.domElement.style.cursor = "grab";
  };
  renderer.domElement.addEventListener("pointerdown", onDown);
  renderer.domElement.addEventListener("pointermove", onHover);
  window.addEventListener("pointermove", onMove);
  window.addEventListener("pointerup", onUp);

  const resize = () => {
    const width = host.clientWidth, height = host.clientHeight;
    renderer.setSize(width, height, false);
    camera.aspect = width / Math.max(1, height);
    // Narrow screens: step back so every row fits.
    hallDistance = camera.aspect < 0.9 ? 25 : camera.aspect < 1.4 ? 18.5 : 16;
    camera.updateProjectionMatrix();
  };
  const sizeWatcher = new ResizeObserver(resize); sizeWatcher.observe(host); resize();

  let visible = true;
  const visibility = new IntersectionObserver((entries) => { visible = entries.some((entry) => entry.isIntersecting); if (visible) loop(); }, { threshold: 0 });
  visibility.observe(host);
  const projected = new THREE.Vector3();
  let frame = 0;
  let nextOuting = 4, lastFigureTime = 0;
  const clock = new THREE.Clock();
  clockRef = clock;
  const loop = () => {
    cancelAnimationFrame(frame);
    if (!visible || document.hidden) return;
    const time = clock.getElapsedTime();
    // Follow the drag smoothly, plus a slow idle sway so the hall feels alive.
    const goal = viewGoal();
    yawLimit = goal.limit;
    const sway = reduce || view === "follow" ? 0 : Math.sin(time * 0.15) * 0.08;
    yaw += (yawGoal + sway - yaw) * 0.08;
    target.lerp(targetGoal, view === "follow" ? 0.12 : 0.05);
    distance += (goal.distance - distance) * 0.05;
    pitch += (goal.pitch - pitch) * 0.05;
    placeCamera();
    // Roof hidden when looking down into the hall from above; the front columns hidden when the camera stands
    // just behind them inside the hall.
    const overHall = Math.abs(camera.position.x) < hallHalf + 4 && camera.position.z < frontZ + 4;
    const roofOn = !(overHall && camera.position.y > yard.roofY - 0.6);
    for (const part of yard.roof) part.visible = roofOn;
    const facadeOn = !(camera.position.z < frontZ + 7 && Math.abs(camera.position.x) < hallHalf + 4);
    for (const part of yard.facade) part.visible = facadeOn;
    yard.update(time, camera.position);
    for (const shade of shadeFigures) shade.group.position.y = shade.base + (reduce ? 0 : Math.sin(time * 1.1 + shade.phase) * 0.02);
    for (let index = floaters.length - 1; index >= 0; index -= 1) {
      const floater = floaters[index], age = time - floater.born;
      floater.sprite.position.set(floater.x, 2.1 + age * 0.9, floater.z); floater.sprite.material.opacity = Math.max(0, 1 - age / 1.8);
      if (age > 1.8) { scene.remove(floater.sprite); floater.sprite.material.map.dispose(); floater.sprite.material.dispose(); floaters.splice(index, 1); }
    }
    for (let index = rings.length - 1; index >= 0; index -= 1) {
      const ring = rings[index], age = time - ring.born, size = 1 + age * 5;
      ring.sprite.scale.set(size, size, 1); ring.sprite.material.opacity = Math.max(0, 0.8 - age / 2);
      if (age > 1.6) { scene.remove(ring.sprite); ring.sprite.material.dispose(); rings.splice(index, 1); }
    }
    if (!reduce) discFace.rotation.z = -time * 0.12;
    for (const flame of flames) { const flicker = 1 + Math.sin(time * 11 + flame.phase) * 0.08 + Math.sin(time * 23 + flame.phase) * 0.05; flame.sprite.scale.set(0.5 * flicker, 0.8 * flicker, 1); flame.light.intensity = 4 * flicker; }
    const width = host.clientWidth, height = host.clientHeight;
    // Names show only for people close by: near the camera, or within a few steps of your own figure.
    const meNow = selfId ? visitorFigures.get(selfId) : null;
    const nearRange = view === "follow" ? (narrow ? 11 : 9) : view === "yard" ? (narrow ? 34 : 31) : narrow ? 15 : 10.5;
    const near = (x: number, z: number) => Math.hypot(x - camera.position.x, z - camera.position.z) < nearRange || (meNow ? Math.hypot(x - meNow.group.position.x, z - meNow.group.position.z) < 3.5 : false);
    disciples.forEach((disciple, index) => {
      const hovered = hoverRef.current === index;
      const lift = reduce ? 0 : Math.sin(time * 1.6 + disciple.phase) * 0.025;
      disciple.group.position.y = disciple.base + lift + (hovered ? 0.18 : 0);
      disciple.group.scale.setScalar(hovered ? 1.12 : 1);
      const label = labelsRef.current[index];
      if (!label) return;
      projected.copy(disciple.head); projected.y += disciple.group.position.y - disciple.base;
      projected.project(camera);
      const half = (label.offsetWidth || 80) / 2 + 4;
      // Keep every name inside the frame (edge seats on phones would otherwise be cut off).
      const sx = Math.max(half, Math.min(width - half, (projected.x * 0.5 + 0.5) * width)), sy = (-projected.y * 0.5 + 0.5) * height;
      label.style.transform = `translate(-50%, -100%) translate(${sx.toFixed(1)}px, ${sy.toFixed(1)}px)`;
      label.style.zIndex = String(1000 - Math.round(projected.z * 500));
      label.classList.toggle("is-hover", hovered);
      label.style.visibility = projected.z < 1 && view !== "yard" && near(disciple.head.x, disciple.head.z) ? "visible" : "hidden";
    });
    // Now and then a fellow member gets up, strolls along the aisle, pauses, and goes back to the mat.
    if (!reduce && time > nextOuting) {
      nextOuting = time + 3 + Math.random() * 5;
      const out = [...visitorFigures.values()].filter((figure) => figure.outing).length;
      const idle = [...visitorFigures.entries()].filter(([id, figure]) => id.startsWith("ambient-") && !figure.self && !figure.target && !figure.outing);
      if (out < (narrow ? 2 : 3) && idle.length) {
        const [, figure] = idle[Math.floor(Math.random() * idle.length)];
        const spot = pointAt(Math.random() * loopLength);
        figure.target = { x: spot.x, z: spot.z }; figure.outing = true;
      }
    }
    const frameDt = Math.min(0.25, time - lastFigureTime); lastFigureTime = time;
    for (const [id, figure] of visitorFigures) {
      const slot = visitorSlots[figure.slot];
      let walking = false;
      // Courtyard members: walk the loop, stop at the incense burner, the pond or a bench, then move on.
      if (slot.outdoor && !figure.self && !figure.target && time >= figure.waitUntil && !reduce) {
        if (Math.random() < 0.55) { figure.leg = (figure.leg + 1) % yard.loop.length; const [lx, lz] = yard.loop[figure.leg]; figure.target = { x: lx + (Math.random() - 0.5) * 1.2, z: lz + (Math.random() - 0.5) * 1.2 }; figure.face = null; }
        else { const spot = yard.spots[Math.floor(Math.random() * yard.spots.length)]; figure.target = { x: spot.x + (Math.random() - 0.5) * 1.4, z: spot.z + (Math.random() - 0.5) * 0.8 }; figure.face = spot.face; }
      }
      if (slot.outdoor && !figure.self && figure.target && time >= figure.waitUntil) {
        const dx = figure.target.x - figure.group.position.x, dz = figure.target.z - figure.group.position.z, distance = Math.hypot(dx, dz);
        if (distance < 0.08) {
          figure.target = null;
          const atSpot = figure.face !== null;
          figure.waitUntil = time + (atSpot ? 4 + Math.random() * 7 : 0.2 + Math.random() * 1.2);
          if (atSpot) { figure.group.rotation.y = figure.face as number; if (Math.random() < 0.5) figure.act = { kind: "bow", start: time }; }
        } else {
          walking = true;
          const stepLength = Math.min(distance, 1.05 * frameDt);
          figure.group.position.x += (dx / distance) * stepLength; figure.group.position.z += (dz / distance) * stepLength;
          const facing = Math.atan2(-dx, -dz);
          figure.group.rotation.y += ((facing - figure.group.rotation.y + Math.PI * 3) % (Math.PI * 2) - Math.PI) * 0.2;
        }
      } else if (figure.target && time >= figure.waitUntil) {
        const aim = figure.via ?? figure.target;
        const dx = aim.x - figure.group.position.x, dz = aim.z - figure.group.position.z, distance = Math.hypot(dx, dz);
        // your own figure walks faster over long distances, so crossing the courtyard never takes long
        const speed = figure.self ? Math.min(7, 2.6 + Math.hypot(figure.target.x - figure.group.position.x, figure.target.z - figure.group.position.z) * 0.12) : 0.9;
        if (figure.via && distance < 0.3) { figure.via = null; }
        else if (distance < 0.05) {
          figure.group.position.x = figure.target.x; figure.group.position.z = figure.target.z;
          const home = Math.abs(figure.target.x - slot.x) < 0.01 && Math.abs(figure.target.z - slot.z) < 0.01;
          if (home) { figure.target = null; figure.outing = false; figure.group.rotation.y = Math.atan2(-slot.x * 0.15, -1) + Math.PI; if (figure.self) { onSelfAway(false); setView("hall"); } }
          else if (!figure.self) { figure.waitUntil = time + 2.5 + Math.random() * 4; figure.target = { x: slot.x, z: slot.z }; }
          else figure.target = null;
        } else {
          walking = true;
          const stepLength = Math.min(distance, speed * frameDt);
          figure.group.position.x += (dx / distance) * stepLength; figure.group.position.z += (dz / distance) * stepLength;
          const facing = Math.atan2(-dx, -dz);
          figure.group.rotation.y += ((facing - figure.group.rotation.y + Math.PI * 3) % (Math.PI * 2) - Math.PI) * 0.2;
        }
      }
      const lift = reduce ? 0 : walking ? Math.abs(Math.sin(time * 9 + figure.phase)) * 0.07 : Math.sin(time * 1.4 + figure.phase) * 0.025;
      figure.group.position.y = 0.12 + lift;
      // bows and gestures
      let tilt = 0;
      if (figure.act && !walking) {
        const age = time - figure.act.start;
        const kind = figure.act.kind;
        const length = kind === "bow" ? 4.5 : kind === "palms" ? 1.6 : kind === "fish" ? 0.4 : kind === "bell" ? 1.2 : 0.3;
        if (age > length) figure.act = null;
        else if (kind === "bow") tilt = Math.max(0, Math.sin((age / 1.5) * Math.PI)) * 0.6;
        else if (kind === "palms") tilt = Math.sin(Math.min(1, age / 1.6) * Math.PI) * 0.18;
        else if (kind === "fish") tilt = Math.sin((age / 0.4) * Math.PI) * 0.12;
        else if (kind === "bell") tilt = Math.sin((age / 1.2) * Math.PI) * 0.1;
        else tilt = Math.sin((age / 0.3) * Math.PI) * 0.05;
      } else if (walking) figure.act = null;
      figure.group.rotation.x = tilt;
      figure.shadow.position.set(figure.group.position.x, 0.13, figure.group.position.z);
      const label = visitorLabels.current.get(id);
      if (!label) continue;
      projected.set(figure.group.position.x, 1.7 + lift, figure.group.position.z).project(camera);
      const half = (label.offsetWidth || 70) / 2 + 4;
      const sx = Math.max(half, Math.min(width - half, (projected.x * 0.5 + 0.5) * width)), sy = (-projected.y * 0.5 + 0.5) * height;
      label.style.transform = `translate(-50%, -100%) translate(${sx.toFixed(1)}px, ${sy.toFixed(1)}px)`;
      label.style.zIndex = String(1000 - Math.round(projected.z * 500));
      const insideHidden = view === "yard" && !figure.self && figure.group.position.z < frontZ - 0.5;
      const close = figure.self || near(figure.group.position.x, figure.group.position.z);
      label.style.visibility = close && !insideHidden && projected.z < 1 && sx > -40 && sx < width + 40 ? "visible" : "hidden";
    }
    moveWalkers(time);
    for (const lantern of lanterns.values()) {
      // A fresh lamp rises from the floor for 3 s, then sways gently like the others.
      const age = lantern.born < 0 ? 99 : time - lantern.born;
      const rise = Math.min(1, age / 3), eased = 1 - (1 - rise) ** 3;
      const bob = reduce ? 0 : Math.sin(time * 0.9 + lantern.phase) * 0.08;
      const y = 0.6 + (lantern.y - 0.6) * eased + bob;
      const x = lantern.x + (reduce ? 0 : Math.sin(time * 0.4 + lantern.phase) * 0.05);
      lantern.group.position.set(x, y, lantern.z);
      lantern.group.rotation.z = reduce ? 0 : Math.sin(time * 0.7 + lantern.phase) * 0.05;
      lantern.glow.position.set(x, y, lantern.z);
      const pulse = 1 + (reduce ? 0 : Math.sin(time * 2.1 + lantern.phase) * 0.06) + (rise < 1 ? (1 - rise) * 0.8 : 0);
      lantern.glow.scale.set(2.8 * pulse, 2.8 * pulse, 1);
      if (lantern.light) lantern.light.position.set(x, y - 0.1, lantern.z);
    }
    renderer.render(scene, camera);
    frame = requestAnimationFrame(loop);
  };
  const onVisibility = () => { if (!document.hidden) loop(); };
  document.addEventListener("visibilitychange", onVisibility);
  loop();

  const dispose = () => {
    cancelAnimationFrame(frame);
    visibility.disconnect(); sizeWatcher.disconnect();
    document.removeEventListener("visibilitychange", onVisibility);
    window.removeEventListener("pointermove", onMove); window.removeEventListener("pointerup", onUp);
    renderer.domElement.removeEventListener("pointerdown", onDown); renderer.domElement.removeEventListener("pointermove", onHover);
    scene.traverse((object: any) => { // eslint-disable-line @typescript-eslint/no-explicit-any
      const mesh = object as { geometry?: { dispose(): void }; material?: { dispose(): void; map?: { dispose(): void } | null } };
      mesh.geometry?.dispose(); mesh.material?.map?.dispose(); mesh.material?.dispose();
    });
    renderer.dispose(); renderer.domElement.remove();
  };
  return { dispose, setVisitors, setLamps, goHome, setView, act, hallSlots, slots: visitorSlots.length };
}
