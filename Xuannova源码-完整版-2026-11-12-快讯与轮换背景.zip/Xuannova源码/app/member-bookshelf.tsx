"use client";
// Member centre: "My bookshelf" with favourite classics and where each book was left off.
import { useEffect, useState } from "react";
import { rememberScroll } from "./scroll-memory";
import type { Locale } from "./site-content";
import { classicalWorks, localizedLibraryTitle } from "./library-catalogue";
import { fillShelf, loadShelf, onShelf, progressPercent, shelfText, type Shelf, type ShelfItem } from "./library-shelf";
import { pathFor } from "./study-navigation";

function openBook(locale: Locale, workId?: string) {
  const href = `${pathFor(locale, "library")}${workId ? `?book=${encodeURIComponent(workId)}` : ""}`;
  rememberScroll();
  window.history.pushState({ scrollY: 0 }, "", href);
  window.dispatchEvent(new Event("xn:navigate"));
  window.scrollTo({ top: 0, behavior: "instant" });
}

export function MemberBookshelf({ locale }: { locale: Locale }) {
  const [shelf, setShelf] = useState<Shelf | null>(null);
  useEffect(() => { let alive = true; void loadShelf(true).then((value) => { if (alive) setShelf(value); }); const stop = onShelf(setShelf); return () => { alive = false; stop(); }; }, []);
  if (!shelf) return null;
  const items = Object.values(shelf.items).filter((item) => classicalWorks.some((work) => work.id === item.workId) && (item.favorite || item.chapter !== null));
  items.sort((a, b) => ((b.readAt ?? b.favoritedAt ?? "") as string).localeCompare((a.readAt ?? a.favoritedAt ?? "") as string));
  const row = (item: ShelfItem) => {
    const work = classicalWorks.find((entry) => entry.id === item.workId)!;
    const percent = progressPercent(item);
    return <li key={item.workId}><a href={`${pathFor(locale, "library")}?book=${item.workId}`} onClick={(event) => { if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return; event.preventDefault(); openBook(locale, item.workId); }}>
      <strong>{item.favorite ? "★ " : ""}{localizedLibraryTitle(work, locale)}</strong>
      {item.chapter !== null ? <>
        <span>{fillShelf(shelfText.readTo[locale], { title: item.chapterTitle ?? String(item.chapter + 1) })}</span>
        <span className="library-progress"><i style={{ width: `${percent}%` }} /><small>{fillShelf(shelfText.progress[locale], { p: percent })}</small></span>
      </> : <span>{shelfText.favorited[locale]}</span>}
      <b>{item.chapter !== null ? shelfText.continueReading[locale] : shelfText.myFavorites[locale]} →</b>
    </a></li>;
  };
  return <section className="mc-card mc-bookshelf">
    <header><h3>{shelfText.shelfTitle[locale]}</h3></header>
    {items.length ? <ul>{items.slice(0, 8).map(row)}</ul> : <button type="button" className="text-action" onClick={() => openBook(locale)}>{shelfText.shelfEmpty[locale]}</button>}
  </section>;
}
