/** UI state helper only: no wallet calls, no RPC, no persistence, no credits.
 * The calling integration must revalidate the wallet and quote against trusted
 * chain data immediately before signing. Do not connect to production as-is.
 */
type Phase = "selecting" | "quoted" | "authorizing" | "submitted" | "completed";
type Selection = { network: string; asset: string; member: string; wallet: string };
type Quote = { selectionVersion: number; expiresAt: number; id: string };
export class PaymentFlowDraft {
  private phase: Phase = "selecting";
  private selection: Selection | null = null;
  private version = 0;
  private quote: Quote | null = null;
  private transactionId: string | null = null;

  snapshot() { return { phase: this.phase, selection: this.selection ? { ...this.selection } : null, version: this.version, transactionId: this.transactionId }; }
  select(selection: Selection) {
    if (this.phase === "authorizing" || this.phase === "submitted") throw new Error("PAYMENT_PENDING");
    if (!selection.network || !selection.asset || !selection.member || !selection.wallet) throw new Error("INVALID_SELECTION");
    this.selection = { ...selection }; this.version++; this.quote = null; this.transactionId = null; this.phase = "selecting";
    return this.version;
  }
  setQuote(quote: Quote, now: number) {
    if (!this.selection || this.phase !== "selecting" || quote.selectionVersion !== this.version) throw new Error("STALE_SELECTION");
    if (!quote.id || !Number.isSafeInteger(now) || !Number.isSafeInteger(quote.expiresAt) || quote.expiresAt <= now) throw new Error("QUOTE_EXPIRED");
    this.quote = { ...quote }; this.phase = "quoted";
  }
  begin(now: number) {
    if (this.phase !== "quoted" || !this.quote || !this.selection) throw new Error("QUOTE_REQUIRED");
    if (!Number.isSafeInteger(now) || now >= this.quote.expiresAt) { this.quote = null; this.phase = "selecting"; throw new Error("QUOTE_EXPIRED"); }
    this.phase = "authorizing";
    return { selection: { ...this.selection }, quote: { ...this.quote } };
  }
  /** Wallet rejection/definitive failure before broadcast; a fresh quote is required. */
  cancelBeforeBroadcast() {
    if (this.phase !== "authorizing" || this.transactionId) throw new Error("PAYMENT_NOT_CANCELABLE");
    this.quote = null; this.phase = "selecting"; this.version++;
  }
  /** Once a hash exists, keep it even if the account/network subsequently changes. */
  submitted(transactionId: string) {
    if (this.phase !== "authorizing" || !transactionId.trim()) throw new Error("INVALID_PAYMENT_STATE");
    this.transactionId = transactionId; this.phase = "submitted"; this.quote = null;
  }
  invalidateWallet() {
    // Never allow a fresh quote to reuse the previous wallet after a chain or
    // account change, including when an outstanding wallet prompt is cancelled.
    this.version++; this.quote = null; this.selection = null;
    // An open wallet prompt may already be broadcasting: do not allow another
    // payment until it resolves or the original transaction is reconciled.
    if (this.phase !== "authorizing" && this.phase !== "submitted") this.phase = "selecting";
  }
  /** Caller must use server-verified final outcome; this helper cannot verify it. */
  resolveSubmitted(result: "credited" | "verified-revert") {
    if (this.phase !== "submitted" || !this.transactionId) throw new Error("INVALID_PAYMENT_STATE");
    if (result !== "credited" && result !== "verified-revert") throw new Error("INVALID_PAYMENT_OUTCOME");
    this.phase = result === "credited" ? "completed" : "selecting";
    if (result === "verified-revert") this.transactionId = null;
    this.version++;
  }
}
