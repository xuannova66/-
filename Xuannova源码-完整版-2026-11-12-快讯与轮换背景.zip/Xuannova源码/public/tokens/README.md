# Token logos

Shown next to payment coins in the checkout (identification only; each logo is a trademark of its project).

- SVG files (usdt, usdc, bnb, eth, sol, trx, link, uni, aave, doge, xrp, ray, wbtc): spothq/cryptocurrency-icons, CC0 1.0.
- PNG files (cake, shib, aster, usd1, btcb, xaut, weth, jlp), resized to 64 px: trustwallet/assets, MIT License.
