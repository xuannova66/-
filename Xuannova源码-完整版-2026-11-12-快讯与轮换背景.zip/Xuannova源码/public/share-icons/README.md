Put the official share icons here (from each platform's brand-resources page), as SVG:

- wechat.svg   — WeChat (微信)
- weibo.svg    — Weibo (微博)
- facebook.svg — Facebook

The share panel of Xuannova Flash picks them up automatically. X, Telegram, WhatsApp and LINE use the
icons already shown in the site footer. Until a file is here, a plain letter badge is shown.
