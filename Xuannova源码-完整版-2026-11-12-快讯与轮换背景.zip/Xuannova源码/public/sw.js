// Xuannova service worker: lets the site open like an app from the home screen.
// - Pages: network first, but if the network has not answered within 1.8 s and a saved copy exists, show the saved copy
//   (so the home-screen app never sits on a blank screen on a slow connection); offline: saved copy, else the offline page.
// - Hashed build files (/assets/…), icons and fonts: cache first (they never change under the same name).
// - API calls, payments, admin and anything from another site: never cached.
const VERSION = "xn-2026-11-12a";
const SHELL = `${VERSION}-shell`, RUNTIME = `${VERSION}-runtime`;
const PRECACHE = ["/offline.html", "/icon-192.png", "/icon-512.png", "/favicon.svg", "/site.webmanifest"];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(SHELL).then((cache) => cache.addAll(PRECACHE)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => !key.startsWith(VERSION)).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});

const trim = async (name, max) => { const cache = await caches.open(name); const keys = await cache.keys(); for (const key of keys.slice(0, Math.max(0, keys.length - max))) await cache.delete(key); };

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith("/api/") || url.pathname.startsWith("/admin") || url.pathname.startsWith("/payments/") || url.pathname === "/sw.js") return;

  if (request.mode === "navigate") {
    event.respondWith((async () => {
      const network = fetch(request).then((response) => {
        if (response.ok) { const copy = response.clone(); caches.open(RUNTIME).then((cache) => cache.put(request, copy)).then(() => trim(RUNTIME, 80)); }
        return response;
      });
      const saved = () => caches.match(request).then((hit) => hit || caches.match(request, { ignoreSearch: true }));
      const slow = new Promise((resolve) => setTimeout(resolve, 1800, "slow"));
      try {
        const first = await Promise.race([network, slow]);
        if (first !== "slow") return first;
        const copy = await saved();
        if (copy) { event.waitUntil(network.catch(() => undefined)); return copy; }
        return await network;
      } catch {
        return (await saved()) || (await caches.match("/offline.html")) || Response.error();
      }
    })());
    return;
  }

  // Hashed build files never change: cache first. Other images and fonts: answer from cache, refresh in the background
  // (so a picture replaced under the same name still updates on the next visit).
  const hashed = url.pathname.startsWith("/assets/");
  const media = /\.(?:woff2?|png|jpg|jpeg|webp|svg|ico)$/.test(url.pathname);
  if (!hashed && !media) return;
  event.respondWith((async () => {
    const cached = await caches.match(request);
    const refresh = fetch(request).then((response) => {
      if (response.ok && response.type === "basic") { const copy = response.clone(); caches.open(RUNTIME).then((cache) => cache.put(request, copy)).then(() => trim(RUNTIME, 300)); }
      return response;
    });
    if (cached) { if (!hashed) event.waitUntil(refresh.catch(() => undefined)); return cached; }
    return refresh;
  })());
});
