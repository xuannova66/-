import { createCompleteChart } from "./app/chart-model";
import { localizeBoardTerm } from "./app/complete-chart-board";
const modules = ["bazi","detail","compatibility","liuyao","ziwei","qizheng","qimen","daliuren","wenshi","mirror","toolkit-time","toolkit-elements","toolkit-dream","toolkit-name","toolkit-tarot","toolkit-iching","toolkit-natal","hecan","daily"];
const bad = new Map<string, Set<string>>();
for (const m of modules) {
  const chart = createCompleteChart({ birthDate: "1994-08-18", birthTime: "12:00", calendar: "solar", focus: "工作", name: "测试", companionName: "伴侣", module: m, version: 1, place: "Global" });
  const values = [chart.board.label, ...chart.board.cells.flatMap((c) => [c.title, c.subtitle, ...c.items.flatMap((i) => [i.label, i.value])]), ...chart.sections.flatMap((s) => [s.title, s.lead, ...s.items.flatMap((i) => [i.label, i.value])])];
  for (const v of values) if (typeof v === "string") { const out = localizeBoardTerm(v, "zh-Hans"); if (out === "当前盘面数据已展开，请按层级查看") { if(!bad.has(m)) bad.set(m,new Set()); bad.get(m)!.add(v);} }
}
for (const [m,s] of bad) { console.log("==", m, s.size); for (const v of [...s].slice(0,12)) console.log("  ", JSON.stringify(v)); }
