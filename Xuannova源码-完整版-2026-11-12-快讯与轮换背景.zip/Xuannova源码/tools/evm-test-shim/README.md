# Local contract tests without npm

`tests/multiasset-checkout-draft.test.mjs` and `tests/usdc-wallet-local.test.mjs` need `solc` and `ganache`.
This folder provides both as small shims over the native `solc` (0.8.24) and Foundry's `anvil`:

```bash
mkdir -p tools/evm-test-shim/bin
curl -L -o tools/evm-test-shim/bin/solc https://github.com/ethereum/solidity/releases/download/v0.8.24/solc-static-linux
curl -L https://github.com/foundry-rs/foundry/releases/download/v1.3.5/foundry_v1.3.5_linux_amd64.tar.gz | tar xz -C tools/evm-test-shim/bin anvil
chmod +x tools/evm-test-shim/bin/*
XUANNOVA_TEST_TOOLS=$PWD/tools/evm-test-shim node --test tests/multiasset-checkout-draft.test.mjs tests/usdc-wallet-local.test.mjs
```

`SOLC_BIN` / `ANVIL_BIN` override the binary paths. The anvil accounts are its public development keys (local only).
