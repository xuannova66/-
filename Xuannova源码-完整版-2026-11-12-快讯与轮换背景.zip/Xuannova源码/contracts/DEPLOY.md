# XuanyuanCreditStore — Remix 部署清单

## 先在 BSC 测试网演练（推荐）

测试网没有官方 USDT，用本目录的 `TestUSDT.sol` 代替，任何人都能免费 mint。

1. MetaMask 添加 **BSC Testnet**：chainId `97`，RPC `https://data-seed-prebsc-1-s1.bnbchain.org:8545`，符号 `tBNB`，浏览器 `https://testnet.bscscan.com`。
2. 领测试币：https://www.bnbchain.org/en/testnet-faucet（每天 0.3 tBNB 左右，够用）。
3. Remix 部署 `TestUSDT.sol`（无构造参数）→ 记下地址 **T**。点 `faucet` 给自己 1000 tUSDT。
4. Remix 部署 `XuanyuanCreditStore.sol`，构造参数：`usdtToken = T`，其余三项同主网表。→ 记下地址 **S**。
5. 服务器 `/etc/xuanyuan/xuanyuan.env` 设：
   ```
   BSC_CHAIN_ID=97
   USDT_ADDRESS=T
   CREDIT_STORE_ADDRESS=S
   ```
   `sudo systemctl restart xuanyuan`。页面支付区会标出 TESTNET，钱包会自动切到测试网，交易在 testnet.bscscan.com 可查。
6. 走一遍：钱包登录 → 选 4.99U 的「入门体验包」→ 支付 → 积分到账；确认收款地址收到 tUSDT、手续费地址收到 0.00007 tBNB。
7. 演练通过后，按下面主网流程重新部署，把三项改回：`BSC_CHAIN_ID=56`，`USDT_ADDRESS=`（留空），`CREDIT_STORE_ADDRESS=主网合约`。测试网的会员/订单数据建议清空（删掉 `/var/lib/xuanyuan/xuanyuan.sqlite` 后重跑 `sudo xuanyuan-deploy`）。

## 主网部署（BSC 主网，chainId 56）

## 准备
- MetaMask 切换到 **BNB Smart Chain**（chainId 56），部署钱包里有 ≥ 0.01 BNB 作 gas。
- 部署钱包 = 合约 owner，以后改套餐 / 改地址 / 暂停都用它。

## 步骤
1. 打开 https://remix.ethereum.org → File Explorer 新建 `XuanyuanCreditStore.sol`，粘贴本目录同名文件内容。
2. Solidity Compiler：版本**必须选 `0.8.24`**（合约已固定此版本），勾选 **Enable optimization**，Runs 填 `200`，点 Compile。开源验证时也要用完全相同的设置。
3. Deploy & Run：Environment 选 **Injected Provider – MetaMask**，确认右上角网络是 BSC (56)。
4. Contract 选 `XuanyuanCreditStore`，展开 Deploy，按顺序填 4 个构造参数（全部复制粘贴）：

| # | 参数 | 值 |
|---|---|---|
| 1 | `usdtToken` | `0x55d398326f99059fF775485246999027B3197955` |
| 2 | `treasuryWallet`（USDT 收款） | `0x9E946751c432E4FCd05C463956122793ab64202e` |
| 3 | `feeWallet`（0.00007 BNB 手续费收款） | `0xf749AcaB0be460667Bd15922b48c821E4Fb3c13d` |
| 4 | `initialFeeWei` | `70000000000000` |

5. 点 **transact**，MetaMask 确认。等待上链后，在 Remix 左下 “Deployed Contracts” 复制合约地址。
6. 把合约地址填到服务器 `/etc/xuanyuan/xuanyuan.env` 的 `CREDIT_STORE_ADDRESS=`，`sudo systemctl restart xuanyuan`。

## 部署后自检（Remix 里直接点蓝色只读按钮）
- `treasury` → 应显示 `0x9E94…202e`
- `feeRecipient` → 应显示 `0xf749…c13d`
- `feeWei` → `70000000000000`
- `packageById("seed")` → `4990000000000000000, 20, true`

## 可选：BscScan 验证源码
BscScan 打开合约地址 → Contract → Verify and Publish → Single file，编译器版本与优化设置和 Remix 一致，粘贴源码，构造参数 ABI 编码可在 Remix 编译面板 “Compilation Details → ABI-encoded constructor” 取得（或留空让 BscScan 自动读取）。

## 日常管理（owner 钱包在 Remix / BscScan Write Contract 调用）
- `setTreasury(addr)` 换 USDT 收款地址
- `setFeeRecipient(addr)` 换手续费收款地址
- `setFee(wei)` 改手续费 —— **注意**：前后端都以 `worker/commerce-policy.ts` 里的 `platformFeeWei` 为准，改合约手续费前必须先改代码并重新部署站点，否则支付会被拒绝
- `setPackage("seed", 4990000000000000000, 20, true)` 改套餐价格/积分；`active=false` 下架（上架中的套餐价格和积分不能为 0）
- `transferOwnership(addr)` + 新地址调用 `acceptOwnership()` 两步转移所有权（防止填错地址丢失控制权）
- `rescueToken(token, to, amount)` / `sweep(to)` 找回误转进合约的代币 / BNB
- `setPaused(true)` 紧急暂停购买

## 合约开源验证（BscScan Verify & Publish）

开源后任何人都能在 BscScan 上核对合约源码，钱包也会显示可读的函数名，是上线前必做的一步。

### 方法一：BscScan 网页（推荐，5 分钟）
1. 打开 `https://bscscan.com/address/<合约地址>#code`（测试网用 `testnet.bscscan.com`）。
2. 点 **Verify and Publish**，填写：
   - Compiler Type：`Solidity (Single file)`
   - Compiler Version：`v0.8.24+commit.e11b9ed9`
   - Open Source License Type：`MIT License (MIT)`
3. 下一页：
   - Optimization：`Yes`，Runs：`200`
   - Enter the Solidity Contract Code：把 `contracts/XuanyuanCreditStore.sol` **全文**粘贴进去
   - EVM Version：留 `default`
   - Constructor Arguments ABI-encoded：通常自动带出；若为空，在 Remix 编译面板 → **Compilation Details** → **ABI-encoded constructor arguments** 复制粘贴（去掉开头 `0x`）
4. 完成人机验证 → **Verify and Publish**。成功后合约页出现绿色对勾 ✅ 和 **Read / Write Contract** 标签。

### 方法二：Remix 插件
Remix 左侧插件管理器启用 **Contract Verification**（原 Etherscan 插件）→ 选 BSC 网络 → 填合约地址 → 选择已编译的 `XuanyuanCreditStore` → Verify。需要一个 BscScan API Key（在 bscscan.com 免费注册获取）。

### 验证失败常见原因
- 编译器版本或优化设置与部署时不一致（必须 0.8.24 + optimization 200）
- 源码粘贴不完整或部署后又改过源码
- 构造参数编码不对（用 Remix 自动生成的那串）

### 开源后自检
- Read Contract 里 `treasury`、`feeRecipient`、`feeWei`、`owner` 与预期一致
- `packageById("seed")` 返回 `4990000000000000000, 20, true`
- Write Contract 里只有 owner 钱包能调用管理函数

---

# MultiCoinCheckout — BNB 链多币种收款（12 个新币）

**用途**：会员在 BNB 链上用 CAKE、BTCB、WETH、USD1、XRP、SOL、DOGE、LINK、UNI、AAVE、XAUt、SHIB 付款（原来的 USDT、USDC、BNB、ASTER 也照常支持）。

**工作方式**：付款时合约在 PancakeSwap V2 上把币换成**正好等于套餐价**的 USDC，打进收款地址；没用完的币当场退回会员。整笔交易要么全部成功，要么全部不发生。

**和网站的关系**：`buy()` 调用、`Purchased` 事件、0.00007 BNB 平台费都和现在的 `UsdcCheckoutPrototype` 完全一样，所以网站后台的核验和自动到账代码不用改。

> ⚠️ **上线前**：本合约已在本地模拟链上跑通全部测试（`tests/multicoin-checkout-local.test.mjs`），但**还没有经过第三方审计**。要收真钱，建议先审计，再按下面「主网小额」的步骤一个币一个币开放。
> 部署和开放币种都由 owner 钱包签名，私钥只在你自己的钱包里，不要交给任何人。

## 与旧合约相比新增的功能
- `allowedToken(address)`：哪些币能付。USDT、ASTER 部署后就开着；USDC 和 BNB 始终可付，不用设置。
- `setToken(address token, bool allowed)`：只有 owner 能调用，用来开放或关闭某个币。不能填 USDC，也不能填普通钱包地址。
- `rescue(address token)`：只有 owner 能调用。有人误转进合约的币，**只能**转回收款地址（treasury），不能转到别处。
- 带转账手续费的币、会自动增减余额的币，会被合约「金额必须分毫不差」的检查拒绝。

## 编译设置（Remix 或 BscScan 验证都要完全一致）
- Solidity **0.8.24**，Optimization **开启**，Runs **200**，EVM version **shanghai**
- 也可以直接用本目录的 `MultiCoinCheckout.standard-input.json`，在 BscScan 选 “Standard JSON Input” 验证；ABI 在 `MultiCoinCheckout.abi.json`。

## 构造参数（7 个，按顺序复制粘贴）
| # | 参数 | 值 |
|---|---|---|
| 1 | `stable`（USDC） | `0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d` |
| 2 | `tether`（USDT） | `0x55d398326f99059fF775485246999027B3197955` |
| 3 | `asterToken` | `0x000Ae314E2A2172a039B26378814C252734f556A` |
| 4 | `dex`（PancakeSwap V2 Router） | `0x10ED43C718714eb63d5aA57B78B54704E256024E` |
| 5 | `recipient`（USDC 收款） | `0x9E946751c432E4FCd05C463956122793ab64202e` |
| 6 | `feeWallet`（平台费） | `0xf749AcaB0be460667Bd15922b48c821E4Fb3c13d` |
| 7 | `fee` | `70000000000000` |

第 5、6、7 项必须和网站代码里的一致（`worker/commerce-policy.ts`），否则付款页会提示「合约配置不一致」并拒绝付款。

## 开放币种（部署后用 owner 钱包调用 `setToken(地址, true)`，每个币一笔）
以下地址已于 2026-11-07 在链上核对过名称、符号和小数位，PancakeSwap 上也都有兑换路线。

| 币 | 地址 | 小数位 | 付 $5 多付 | 付 $40 多付 |
|---|---|---|---|---|
| CAKE | `0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82` | 18 | 0.11% | 0.25% |
| BTCB | `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` | 18 | 0.02% | 0.03% |
| WETH | `0x2170Ed0880ac9A755fd29B2688956BD959F933F8` | 18 | 0.00% | 0.03% |
| USD1 | `0x8d0D000Ee44948FC98c9B98A4FA4921476f08B0d` | 18 | 0.15% | 0.21% |
| XRP | `0x1D2F0da169ceB9fC7B3144628dB156f3F6c60dBE` | 18 | 0.00% | 0.04% |
| SOL | `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` | 18 | 0.24% | 2.1% |
| DOGE | `0xbA2aE424d960c26247Dd6c32edC70B295c744C43` | 8 | 0.00% | 0.04% |
| LINK | `0xF8A0BF9cF54Bb92F17374d9e9A321E6a111a51bD` | 18 | 0.00% | 0.04% |
| UNI | `0xBf5140A22578168FD562DCcF235E5D43A02ce9B1` | 18 | 0.01% | 0.05% |
| AAVE | `0xfb6115445Bff7b52FeB98650C87f44907E58f802` | 18 | 0.82% | 7.6% |
| XAUt | `0x21cAef8A43163Eea865baeE23b9C2E327696A3bf` | 6 | ≈0 | 0.08% |
| SHIB | `0x2859e4544C4bB03966803b044A93563Bd2D0DD4D` | 18 | 0.02% | 0.18% |

「多付」指和小额兑换相比多付的比例，另外 PancakeSwap 每经过一个兑换池收 0.25% 手续费（大部分币要经过两个池，约 0.5%）。

付款页还有一道保护：报价时如果多付超过 **3%**，会拒绝报价，提示会员换小一点的套餐或换别的币。所以 AAVE 现在只能付小套餐，以后池子变深会自动放开。

## 主网小额上线步骤
1. 部署 → 在 BscScan 验证源码（用上面的编译设置）。
2. 先只开放 1–2 个币，例如 `setToken(CAKE, true)`、`setToken(DOGE, true)`。
3. 在服务器 `/etc/xuanyuan/xuanyuan.env` 设置：
   ```
   USDC_CHECKOUT_ENABLED=true
   USDC_CHECKOUT_ADDRESS=新合约地址
   USDC_CHECKOUT_TOKENS=CAKE,DOGE
   ```
   然后运行 `sudo systemctl restart xuanyuan`。
4. 用这两个币各买一次 4.99 的入门包，确认三件事：收款地址收到 4.99 USDC、积分到账、多余的币退回了钱包。
5. 没问题后，用 `setToken` 开放其余的币，再把 `USDC_CHECKOUT_TOKENS` 填成全部 12 个（逗号分隔，顺序就是页面上的显示顺序），重启服务。
6. 想停用某个币：调用 `setToken(地址, false)`，链上立即生效；再从 `USDC_CHECKOUT_TOKENS` 删掉它，重启服务后页面不再显示。

**注意**：
- 改 `USDC_CHECKOUT_ADDRESS` 之前，确认旧合约 `0x4AAB…0708` 没有未到账的付款，因为网站只核验当前配置的这个合约。
- USDT 直付走的是积分商店合约 `0x9F15…48A6`，不受影响，照常可用。
