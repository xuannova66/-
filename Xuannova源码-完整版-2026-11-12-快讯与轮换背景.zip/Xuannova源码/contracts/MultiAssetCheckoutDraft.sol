// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

// DEVELOPMENT ONLY: not audited, not connected to the site, not for real funds.
// Taxed/rebasing/non-standard tokens are intentionally not supported.
interface IDraftToken {
    function balanceOf(address account) external view returns (uint256);
    function transfer(address to, uint256 amount) external returns (bool);
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function approve(address spender, uint256 amount) external returns (bool);
}
interface IDraftRouter {
    function WETH() external view returns (address);
    function swapTokensForExactTokens(uint256 out, uint256 max, address[] calldata path, address to, uint256 deadline) external returns (uint256[] memory);
    function swapETHForExactTokens(uint256 out, address[] calldata path, address to, uint256 deadline) external payable returns (uint256[] memory);
}

contract MultiAssetCheckoutDraft {
    address public owner;
    address public pendingOwner;
    bool public paused;
    IDraftToken public immutable settlement;
    IDraftRouter public immutable router;
    address public immutable treasury;
    uint256 private immutable centsMultiplier;
    uint256 private entered = 1;
    uint256 public totalSales;
    mapping(address => bool) public allowedAsset;
    mapping(address => mapping(bytes32 => bool)) public usedOrderReference;

    event AssetAllowed(address indexed asset, bool allowed);
    event Paused(bool paused);
    event OwnershipTransferStarted(address indexed owner, address indexed next);
    event OwnershipTransferred(address indexed previous, address indexed next);
    event Purchased(address indexed buyer, bytes32 indexed packageId, address indexed inputAsset, uint256 settlementAmount, uint32 credits, uint256 saleIndex, bytes32 orderReference);
    error Invalid();
    error Unauthorized();
    error TransferFailed();
    error Reentrant();

    constructor(address settlementToken, address dex, address recipient, uint8 settlementDecimals) {
        if (settlementToken.code.length == 0 || dex.code.length == 0 || recipient == address(0) || (settlementDecimals != 6 && settlementDecimals != 18)) revert Invalid();
        owner = msg.sender;
        settlement = IDraftToken(settlementToken);
        router = IDraftRouter(dex);
        treasury = recipient;
        centsMultiplier = 10 ** (settlementDecimals - 2);
        allowedAsset[settlementToken] = true;
        emit OwnershipTransferred(address(0), msg.sender);
    }
    modifier lock() { if (entered != 1) revert Reentrant(); entered = 2; _; entered = 1; }
    receive() external payable { if (msg.sender != address(router)) revert Invalid(); }
    function setAsset(address asset, bool allowed) external {
        if (msg.sender != owner) revert Unauthorized();
        if (asset == address(0) || asset.code.length == 0 || asset == address(settlement)) revert Invalid();
        allowedAsset[asset] = allowed;
        emit AssetAllowed(asset, allowed);
    }
    function setPaused(bool value) external { if (msg.sender != owner) revert Unauthorized(); paused = value; emit Paused(value); }
    function transferOwnership(address next) external { if (msg.sender != owner) revert Unauthorized(); if (next == address(0)) revert Invalid(); pendingOwner = next; emit OwnershipTransferStarted(owner, next); }
    function acceptOwnership() external { if (msg.sender != pendingOwner) revert Unauthorized(); address previous = owner; owner = msg.sender; pendingOwner = address(0); emit OwnershipTransferred(previous, msg.sender); }
    function packageDetails(bytes32 id) public view returns (uint256 amount, uint32 credits) {
        if (id == keccak256("seed")) return (499 * centsMultiplier, 20);
        if (id == keccak256("path")) return (990 * centsMultiplier, 50);
        if (id == keccak256("ritual")) return (1990 * centsMultiplier, 120);
        if (id == keccak256("synthesis")) return (3990 * centsMultiplier, 280);
        revert Invalid();
    }
    function _call(address token, bytes memory data) private {
        (bool ok, bytes memory result) = token.call(data);
        if (!ok || (result.length != 0 && !abi.decode(result, (bool)))) revert TransferFailed();
    }
    function _native(address payable to, uint256 value) private { if (value != 0) { (bool ok,) = to.call{value:value}(""); if (!ok) revert TransferFailed(); } }
    function _path(address input, address[] calldata path) private view {
        if (path.length < 2 || path.length > 3 || path[0] != input || path[path.length - 1] != address(settlement)) revert Invalid();
        if (path.length == 3 && path[1] != router.WETH() && !allowedAsset[path[1]]) revert Invalid();
    }
    function _amounts(uint256[] memory amounts, uint256 length, uint256 maximum, uint256 required) private pure {
        if (amounts.length != length || amounts[0] > maximum || amounts[amounts.length - 1] != required) revert Invalid();
    }
    function buy(bytes32 id, address token, uint256 maxInput, address[] calldata path, uint256 deadline, bytes32 orderReference) external payable lock {
        if (paused || deadline < block.timestamp || maxInput == 0 || orderReference == bytes32(0) || usedOrderReference[msg.sender][orderReference]) revert Invalid();
        usedOrderReference[msg.sender][orderReference] = true;
        (uint256 amount, uint32 credits) = packageDetails(id);
        uint256 saleIndex = ++totalSales;
        uint256 beforeSettlement = settlement.balanceOf(address(this));
        if (token == address(0)) {
            if (msg.value != maxInput) revert Invalid();
            _path(router.WETH(), path);
            uint256 beforeNative = address(this).balance - msg.value;
            uint256[] memory amounts = router.swapETHForExactTokens{value:maxInput}(amount, path, address(this), deadline);
            _amounts(amounts, path.length, maxInput, amount);
            _native(payable(msg.sender), address(this).balance - beforeNative);
        } else {
            if (msg.value != 0 || !allowedAsset[token]) revert Invalid();
            uint256 beforeInput = IDraftToken(token).balanceOf(address(this));
            _call(token, abi.encodeCall(IDraftToken.transferFrom, (msg.sender, address(this), maxInput)));
            if (IDraftToken(token).balanceOf(address(this)) - beforeInput != maxInput) revert Invalid();
            if (token == address(settlement)) {
                if (maxInput != amount || path.length != 0) revert Invalid();
            } else {
                _path(token, path);
                _call(token, abi.encodeCall(IDraftToken.approve, (address(router), 0)));
                _call(token, abi.encodeCall(IDraftToken.approve, (address(router), maxInput)));
                uint256[] memory amounts = router.swapTokensForExactTokens(amount, maxInput, path, address(this), deadline);
                _amounts(amounts, path.length, maxInput, amount);
                _call(token, abi.encodeCall(IDraftToken.approve, (address(router), 0)));
                uint256 refund = IDraftToken(token).balanceOf(address(this)) - beforeInput;
                if (refund != 0) _call(token, abi.encodeCall(IDraftToken.transfer, (msg.sender, refund)));
            }
        }
        if (settlement.balanceOf(address(this)) - beforeSettlement != amount) revert Invalid();
        uint256 beforeTreasury = settlement.balanceOf(treasury);
        _call(address(settlement), abi.encodeCall(IDraftToken.transfer, (treasury, amount)));
        if (settlement.balanceOf(treasury) - beforeTreasury != amount) revert Invalid();
        emit Purchased(msg.sender, id, token, amount, credits, saleIndex, orderReference);
    }
}
