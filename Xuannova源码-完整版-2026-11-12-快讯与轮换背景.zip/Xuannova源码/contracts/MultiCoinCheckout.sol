// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

// Multi-coin checkout for BNB Chain. Same buy() call, Purchased event and platform fee as UsdcCheckoutPrototype, so
// the site's verification is unchanged; the owner can additionally allow more BEP-20 coins, which are swapped to
// the exact USDC price on PancakeSwap V2 inside the purchase (atomic: either the buyer pays and the treasury receives
// the exact USDC amount, or nothing happens). Not yet audited: audit, testnet and small mainnet tests before real use.
// Fee-on-transfer and rebasing coins are rejected by the exact-balance check.
interface IToken {
    function balanceOf(address) external view returns (uint256);
    function transfer(address, uint256) external returns (bool);
    function transferFrom(address, address, uint256) external returns (bool);
    function approve(address, uint256) external returns (bool);
}
interface IExactOutputRouter {
    function WETH() external view returns (address);
    function swapTokensForExactTokens(uint256, uint256, address[] calldata, address, uint256) external returns (uint256[] memory);
    function swapETHForExactTokens(uint256, address[] calldata, address, uint256) external payable returns (uint256[] memory);
}

contract MultiCoinCheckout {
    address public owner;
    address public pendingOwner;
    bool public paused;
    IToken public immutable usdc;
    address public immutable usdt;
    address public immutable aster;
    IExactOutputRouter public immutable router;
    address public immutable treasury;
    address payable public immutable feeRecipient;
    uint256 public immutable feeWei;
    uint256 private entered = 1;
    uint256 public totalSales;
    /// Coins (besides USDC and native BNB) that may be paid with. USDT and ASTER are allowed from the start.
    mapping(address => bool) public allowedToken;

    event Purchased(address indexed buyer, bytes32 indexed packageId, uint256 usdtAmount, uint32 credits, uint256 feeWei, uint256 saleIndex);
    event Paused(bool value);
    event TokenAllowed(address indexed token, bool allowed);
    event Rescued(address indexed token, uint256 amount);
    event OwnershipTransferStarted(address indexed currentOwner, address indexed pendingOwner);
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    error Invalid();
    error TransferFailed();
    error Reentrant();
    error Unauthorized();
    error CheckoutPaused();

    constructor(address stable, address tether, address asterToken, address dex, address recipient, address payable feeWallet, uint256 fee) {
        if (stable == address(0) || tether == address(0) || asterToken == address(0) || dex == address(0) || recipient == address(0) || feeWallet == address(0)) revert Invalid();
        if (stable == tether || stable == asterToken || tether == asterToken) revert Invalid();
        owner = msg.sender; emit OwnershipTransferred(address(0), msg.sender);
        usdc = IToken(stable); usdt = tether; aster = asterToken; router = IExactOutputRouter(dex);
        treasury = recipient; feeRecipient = feeWallet; feeWei = fee;
        allowedToken[tether] = true; allowedToken[asterToken] = true;
        emit TokenAllowed(tether, true); emit TokenAllowed(asterToken, true);
    }
    modifier lock() { if (entered != 1) revert Reentrant(); entered = 2; _; entered = 1; }
    receive() external payable { if (msg.sender != address(router)) revert Invalid(); }
    /// Allow or stop a coin. USDC is always accepted directly and cannot be listed here.
    function setToken(address token, bool allowed) external {
        if (msg.sender != owner) revert Unauthorized();
        if (token == address(0) || token == address(usdc) || token.code.length == 0) revert Invalid();
        allowedToken[token] = allowed;
        emit TokenAllowed(token, allowed);
    }
    /// The contract holds nothing between purchases; anything sent to it by mistake can only go to the treasury.
    function rescue(address token) external lock {
        if (msg.sender != owner) revert Unauthorized();
        uint256 amount = IToken(token).balanceOf(address(this));
        if (amount != 0) _transfer(token, treasury, amount);
        emit Rescued(token, amount);
    }
    function setPaused(bool value) external { if (msg.sender != owner) revert Unauthorized(); paused = value; emit Paused(value); }
    function transferOwnership(address nextOwner) external { if (msg.sender != owner) revert Unauthorized(); if (nextOwner == address(0)) revert Invalid(); pendingOwner = nextOwner; emit OwnershipTransferStarted(owner, nextOwner); }
    function acceptOwnership() external { if (msg.sender != pendingOwner) revert Unauthorized(); address previous = owner; owner = msg.sender; pendingOwner = address(0); emit OwnershipTransferred(previous, msg.sender); }

    function packageDetails(bytes32 id) public pure returns (uint256 amount, uint32 credits) {
        if (id == keccak256("seed")) return (4.99 ether, 20);
        if (id == keccak256("path")) return (9.9 ether, 50);
        if (id == keccak256("ritual")) return (19.9 ether, 120);
        if (id == keccak256("synthesis")) return (39.9 ether, 280);
        revert Invalid();
    }
    function _call(address token, bytes memory data) private {
        (bool ok, bytes memory result) = token.call(data);
        if (!ok || (result.length != 0 && !abi.decode(result, (bool)))) revert TransferFailed();
    }
    function _transfer(address token, address to, uint256 amount) private { _call(token, abi.encodeCall(IToken.transfer, (to, amount))); }
    function _approve(address token, address to, uint256 amount) private { _call(token, abi.encodeCall(IToken.approve, (to, amount))); }
    function _native(address payable to, uint256 amount) private { if (amount != 0) { (bool ok,) = to.call{value: amount}(""); if (!ok) revert TransferFailed(); } }
    function _path(address input, address[] calldata path) private view {
        if (path.length < 2 || path.length > 3 || path[0] != input || path[path.length - 1] != address(usdc)) revert Invalid();
        if (path.length == 3 && path[1] != router.WETH() && path[1] != usdt) revert Invalid();
    }
    function _checkAmounts(uint256[] memory amounts, uint256 pathLength, uint256 maxInput, uint256 requiredOutput) private pure {
        if (amounts.length != pathLength || amounts[0] > maxInput || amounts[amounts.length - 1] != requiredOutput) revert Invalid();
    }

    /// Payment and swap are atomic. USDC stays in the contract only transiently.
    /// maxInput and deadline are chosen by the user from a fresh quote.
    function buy(bytes32 id, address token, uint256 maxInput, address[] calldata path, uint256 deadline) external payable lock {
        if (paused) revert CheckoutPaused();
        (uint256 amount, uint32 credits) = packageDetails(id);
        if (deadline < block.timestamp || maxInput == 0) revert Invalid();
        uint256 saleIndex = ++totalSales;
        uint256 initialUsdc = usdc.balanceOf(address(this));
        if (token == address(0)) {
            if (msg.value != maxInput + feeWei) revert Invalid();
            _path(router.WETH(), path);
            uint256 initialNative = address(this).balance - msg.value;
            uint256[] memory amounts = router.swapETHForExactTokens{value: maxInput}(amount, path, address(this), deadline);
            _checkAmounts(amounts, path.length, maxInput, amount);
            uint256 refund = address(this).balance - initialNative - feeWei;
            _native(payable(msg.sender), refund);
        } else {
            if (msg.value != feeWei || (token != address(usdc) && !allowedToken[token])) revert Invalid();
            uint256 tokenBefore = IToken(token).balanceOf(address(this));
            _call(token, abi.encodeCall(IToken.transferFrom, (msg.sender, address(this), maxInput)));
            if (IToken(token).balanceOf(address(this)) - tokenBefore != maxInput) revert Invalid();
            if (token == address(usdc)) {
                if (maxInput != amount || path.length != 0) revert Invalid();
            } else {
                _path(token, path);
                _approve(token, address(router), 0); _approve(token, address(router), maxInput);
                uint256[] memory amounts = router.swapTokensForExactTokens(amount, maxInput, path, address(this), deadline);
                _checkAmounts(amounts, path.length, maxInput, amount);
                _approve(token, address(router), 0);
                uint256 refund = IToken(token).balanceOf(address(this)) - tokenBefore;
                if (refund != 0) _transfer(token, msg.sender, refund);
            }
        }
        if (usdc.balanceOf(address(this)) - initialUsdc != amount) revert Invalid();
        uint256 treasuryBefore = usdc.balanceOf(treasury);
        _transfer(address(usdc), treasury, amount);
        if (usdc.balanceOf(treasury) - treasuryBefore != amount) revert Invalid();
        _native(feeRecipient, feeWei);
        emit Purchased(msg.sender, id, amount, credits, feeWei, saleIndex);
    }
}
