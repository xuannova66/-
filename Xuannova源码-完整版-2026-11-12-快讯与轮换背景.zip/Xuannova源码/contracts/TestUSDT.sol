// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title TestUSDT
 * @notice Minimal mintable ERC-20 that stands in for USDT on BSC **testnet** only.
 *         18 decimals like the real BEP20 USDT. Anyone can `mint` themselves test
 *         tokens. Never deploy this on mainnet.
 */
contract TestUSDT {
    string public constant name = "Test USDT";
    string public constant symbol = "tUSDT";
    uint8 public constant decimals = 18;
    uint256 public totalSupply;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);

    /// @notice Mint `amount` (in base units, 1 USDT = 1e18) to `to`. Free for everyone on testnet.
    function mint(address to, uint256 amount) external {
        totalSupply += amount;
        balanceOf[to] += amount;
        emit Transfer(address(0), to, amount);
    }

    /// @notice Convenience: mint 1,000 tUSDT to the caller.
    function faucet() external {
        totalSupply += 1000 ether;
        balanceOf[msg.sender] += 1000 ether;
        emit Transfer(address(0), msg.sender, 1000 ether);
    }

    function approve(address spender, uint256 value) external returns (bool) {
        allowance[msg.sender][spender] = value;
        emit Approval(msg.sender, spender, value);
        return true;
    }

    function transfer(address to, uint256 value) external returns (bool) {
        _transfer(msg.sender, to, value);
        return true;
    }

    function transferFrom(address from, address to, uint256 value) external returns (bool) {
        uint256 allowed = allowance[from][msg.sender];
        require(allowed >= value, "allowance");
        if (allowed != type(uint256).max) allowance[from][msg.sender] = allowed - value;
        _transfer(from, to, value);
        return true;
    }

    function _transfer(address from, address to, uint256 value) internal {
        require(balanceOf[from] >= value, "balance");
        balanceOf[from] -= value;
        balanceOf[to] += value;
        emit Transfer(from, to, value);
    }
}
