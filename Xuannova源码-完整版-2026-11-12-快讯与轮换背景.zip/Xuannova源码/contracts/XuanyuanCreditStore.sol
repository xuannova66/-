// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

/// @dev Minimal ERC-20 surface needed for USDT (BEP20) transfers and rescue.
interface IERC20 {
    function transferFrom(address from, address to, uint256 value) external returns (bool);
    function transfer(address to, uint256 value) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
}

/**
 * @title XuanyuanCreditStore
 * @notice On-chain checkout for Xuanyuan Institute study credits.
 *
 *  - Buyers pay USDT (BEP20, 18 decimals on BSC) for a fixed credit package.
 *  - Every purchase also carries a flat platform fee in BNB (default 0.00007 BNB,
 *    supplied as `msg.value`), forwarded in the same transaction to `feeRecipient`.
 *  - USDT goes straight to `treasury`. The contract holds neither USDT nor BNB.
 *  - A `Purchased` event is emitted for every sale. The Xuanyuan backend reads
 *    this event (from the receipt or by scanning logs) to issue credits.
 *
 *  Safety properties
 *  - Checks-effects-interactions + reentrancy guard on `buy`.
 *  - Token transfers use a low-level safe call (works with tokens that return
 *    nothing as well as those that return bool).
 *  - Two-step ownership transfer; the zero address is never accepted anywhere.
 *  - Packages must have a non-zero price and credit amount while active.
 *  - Owner can pause sales and rescue tokens / BNB sent here by mistake.
 *
 *  Deploy on BSC mainnet (chainId 56) with:
 *    usdtToken    = 0x55d398326f99059fF775485246999027B3197955
 *    treasury     = your USDT receiving wallet
 *    feeWallet    = your BNB fee receiving wallet
 *    initialFeeWei = 70_000_000_000_000  (0.00007 BNB)
 */
contract XuanyuanCreditStore {
    struct Package {
        uint256 usdtAmount; // in USDT base units (18 decimals on BSC)
        uint32 credits;     // study credits granted
        bool active;
    }

    address public owner;
    address public pendingOwner;
    address public treasury;
    address payable public feeRecipient;
    IERC20 public immutable usdt;
    uint256 public feeWei;
    bool public paused;
    uint256 public totalSales;

    mapping(bytes32 => Package) public packages;

    uint256 private _entered = 1; // 1 = not entered, 2 = entered

    event Purchased(
        address indexed buyer,
        bytes32 indexed packageId,
        uint256 usdtAmount,
        uint32 credits,
        uint256 feeWei,
        uint256 saleIndex
    );
    event PackageSet(bytes32 indexed packageId, uint256 usdtAmount, uint32 credits, bool active);
    event TreasuryChanged(address indexed treasury);
    event FeeRecipientChanged(address indexed feeRecipient);
    event FeeChanged(uint256 feeWei);
    event Paused(bool paused);
    event OwnershipTransferStarted(address indexed currentOwner, address indexed pendingOwner);
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    event Rescued(address indexed token, address indexed to, uint256 amount);

    error NotOwner();
    error NotPendingOwner();
    error ZeroAddress();
    error StorePaused();
    error UnknownPackage();
    error InvalidPackage();
    error WrongFee(uint256 expected, uint256 supplied);
    error TransferFailed();
    error FeeTransferFailed();
    error Reentrancy();

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner();
        _;
    }

    modifier nonReentrant() {
        if (_entered == 2) revert Reentrancy();
        _entered = 2;
        _;
        _entered = 1;
    }

    constructor(address usdtToken, address treasuryWallet, address payable feeWallet, uint256 initialFeeWei) {
        if (usdtToken == address(0) || treasuryWallet == address(0) || feeWallet == address(0)) revert ZeroAddress();
        owner = msg.sender;
        usdt = IERC20(usdtToken);
        treasury = treasuryWallet;
        feeRecipient = feeWallet;
        feeWei = initialFeeWei;
        emit OwnershipTransferred(address(0), msg.sender);
        emit TreasuryChanged(treasuryWallet);
        emit FeeRecipientChanged(feeWallet);
        emit FeeChanged(initialFeeWei);

        // Default packages mirror worker/commerce-policy.ts (1 USDT = 1e18 on BSC).
        _setPackage("seed", 4.99 ether, 20, true);
        _setPackage("path", 9.90 ether, 50, true);
        _setPackage("ritual", 19.90 ether, 120, true);
        _setPackage("synthesis", 39.90 ether, 280, true);
    }

    // ---------------------------------------------------------------------
    // Purchase
    // ---------------------------------------------------------------------

    /// @notice Buy a credit package. Requires prior USDT `approve` for this contract
    ///         and exactly `feeWei` BNB attached as `msg.value`. USDT goes to the
    ///         treasury and the BNB fee to `feeRecipient` within this call.
    function buy(bytes32 packageId) external payable nonReentrant returns (uint256 saleIndex) {
        if (paused) revert StorePaused();
        Package memory item = packages[packageId];
        if (!item.active) revert UnknownPackage();
        if (msg.value != feeWei) revert WrongFee(feeWei, msg.value);

        // Effects before interactions.
        saleIndex = ++totalSales;
        emit Purchased(msg.sender, packageId, item.usdtAmount, item.credits, msg.value, saleIndex);

        // Interactions.
        _safeTransferFrom(msg.sender, treasury, item.usdtAmount);
        if (msg.value > 0) {
            (bool ok, ) = feeRecipient.call{value: msg.value}("");
            if (!ok) revert FeeTransferFailed();
        }
    }

    /// @notice Convenience helper for front-ends: turn a short id such as "seed" into its bytes32 key.
    function packageKey(string calldata id) external pure returns (bytes32) {
        return _key(id);
    }

    /// @notice Read a package by its short string id.
    function packageById(string calldata id) external view returns (uint256 usdtAmount, uint32 credits, bool active) {
        Package memory item = packages[_key(id)];
        return (item.usdtAmount, item.credits, item.active);
    }

    // ---------------------------------------------------------------------
    // Owner administration
    // ---------------------------------------------------------------------

    function setPackage(string calldata id, uint256 usdtAmount, uint32 credits, bool active) external onlyOwner {
        _setPackage(id, usdtAmount, credits, active);
    }

    function setTreasury(address treasuryWallet) external onlyOwner {
        if (treasuryWallet == address(0)) revert ZeroAddress();
        treasury = treasuryWallet;
        emit TreasuryChanged(treasuryWallet);
    }

    function setFeeRecipient(address payable feeWallet) external onlyOwner {
        if (feeWallet == address(0)) revert ZeroAddress();
        feeRecipient = feeWallet;
        emit FeeRecipientChanged(feeWallet);
    }

    /// @dev The backend verifies purchases against the fee configured in code;
    ///      update and redeploy the site before changing this value.
    function setFee(uint256 newFeeWei) external onlyOwner {
        feeWei = newFeeWei;
        emit FeeChanged(newFeeWei);
    }

    function setPaused(bool state) external onlyOwner {
        paused = state;
        emit Paused(state);
    }

    /// @notice Step 1 of 2: nominate a new owner. Nothing changes until they accept.
    function transferOwnership(address newOwner) external onlyOwner {
        if (newOwner == address(0)) revert ZeroAddress();
        pendingOwner = newOwner;
        emit OwnershipTransferStarted(owner, newOwner);
    }

    /// @notice Step 2 of 2: the nominated wallet accepts ownership.
    function acceptOwnership() external {
        if (msg.sender != pendingOwner) revert NotPendingOwner();
        emit OwnershipTransferred(owner, msg.sender);
        owner = msg.sender;
        pendingOwner = address(0);
    }

    /// @notice Rescue BNB force-sent to the contract (normal fees never stay here).
    function sweep(address payable to) external onlyOwner {
        if (to == address(0)) revert ZeroAddress();
        uint256 amount = address(this).balance;
        (bool ok, ) = to.call{value: amount}("");
        if (!ok) revert FeeTransferFailed();
        emit Rescued(address(0), to, amount);
    }

    /// @notice Rescue ERC-20 tokens sent directly to the contract by mistake.
    function rescueToken(address token, address to, uint256 amount) external onlyOwner {
        if (token == address(0) || to == address(0)) revert ZeroAddress();
        _safeCall(token, abi.encodeWithSelector(IERC20.transfer.selector, to, amount));
        emit Rescued(token, to, amount);
    }

    // ---------------------------------------------------------------------
    // Internals
    // ---------------------------------------------------------------------

    function _key(string memory id) internal pure returns (bytes32) {
        return keccak256(bytes(id));
    }

    function _setPackage(string memory id, uint256 usdtAmount, uint32 credits, bool active) internal {
        if (active && (usdtAmount == 0 || credits == 0)) revert InvalidPackage();
        bytes32 key = _key(id);
        packages[key] = Package({usdtAmount: usdtAmount, credits: credits, active: active});
        emit PackageSet(key, usdtAmount, credits, active);
    }

    function _safeTransferFrom(address from, address to, uint256 value) internal {
        _safeCall(address(usdt), abi.encodeWithSelector(IERC20.transferFrom.selector, from, to, value));
    }

    /// @dev Accepts both tokens that return `true` and tokens that return nothing.
    function _safeCall(address token, bytes memory data) internal {
        (bool ok, bytes memory returned) = token.call(data);
        if (!ok || (returned.length != 0 && !abi.decode(returned, (bool)))) revert TransferFailed();
        if (returned.length == 0 && token.code.length == 0) revert TransferFailed();
    }
}
