#!/bin/bash
# Xuanyuan Institute — one-click AWS deploy (double-click in Finder)
cd "$(dirname "$0")"
IP="18.141.186.162"
DOMAIN="18-141-186-162.sslip.io"
KEY="deploy/aws/keys/aws.pem"
SSH="ssh -i $KEY -o StrictHostKeyChecking=accept-new ec2-user@$IP"

step() { echo; echo "=============================="; echo ">>> $1"; echo "=============================="; }
fail() { echo; echo "!!! 失败：$1"; echo "把上面的红字截图发给 Claude。"; read -p "按回车关闭..."; exit 1; }

[ -f "$KEY" ] || fail "找不到 $KEY"
chmod 600 "$KEY"

step "0/4 连接服务器并准备 rsync"
$SSH 'command -v rsync >/dev/null || sudo dnf install -y rsync >/dev/null' || fail "连接服务器（检查 IP / 密钥 / 安全组 22 端口）"

step "1/4 上传代码到 $IP"
rsync -az --delete --exclude node_modules --exclude dist --exclude data --exclude .env --exclude "deploy/aws/keys" --exclude ".DS_Store" \
  -e "ssh -i $KEY -o StrictHostKeyChecking=accept-new" ./ ec2-user@$IP:/home/ec2-user/xuanyuan/ || fail "上传代码"

step "2/4 安装服务器环境（首次约 10 分钟，之后只更新）"
$SSH 'if [ -f /etc/xuanyuan/xuanyuan.env ]; then sudo xuanyuan-deploy; else sudo bash /home/ec2-user/xuanyuan/deploy/aws/setup.sh '"$DOMAIN"'; fi' || fail "安装/更新"

step "3/4 写入 BSC 测试网合约配置"
$SSH 'sudo sed -i "s|^BSC_CHAIN_ID=.*|BSC_CHAIN_ID=97|; s|^USDT_ADDRESS=.*|USDT_ADDRESS=0x9DA944894784c96160fB38e4509eb783173A6AE2|; s|^CREDIT_STORE_ADDRESS=.*|CREDIT_STORE_ADDRESS=0x0D95191BAfc26f6a21c44F3Ae6cbC107BFF51f4a|" /etc/xuanyuan/xuanyuan.env && sudo systemctl restart xuanyuan' || fail "写配置"

step "4/4 验证"
sleep 8
curl -s --max-time 30 "https://$DOMAIN/api/checkout/config" && echo
echo
echo "完成。浏览器打开： https://$DOMAIN"
echo "后台地址：        https://$DOMAIN/admin"
echo "设置后台密码/DeepSeek key：双击 '设置密钥.command'"
read -p "按回车关闭..."
