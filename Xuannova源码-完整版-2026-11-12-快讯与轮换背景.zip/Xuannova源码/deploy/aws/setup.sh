#!/usr/bin/env bash
# One-shot provisioning for a fresh Ubuntu 22.04 / 24.04 or Amazon Linux 2023 EC2 instance.
#
#   curl -fsSL https://raw.githubusercontent.com/<you>/<repo>/main/deploy/aws/setup.sh | sudo bash -s -- <domain> <git-repo-url>
#   — or copy the repo up with scp/rsync and run:  sudo bash deploy/aws/setup.sh <domain>
#
# Installs Node 22 + pnpm, Caddy (automatic HTTPS), creates the `xuanyuan`
# service user, builds the app in Node mode, applies SQLite migrations and
# registers systemd units for the app and nightly backups.
set -euo pipefail

DOMAIN="${1:-}"
REPO_URL="${2:-}"
APP_USER="xuanyuan"
APP_DIR="/opt/xuanyuan"
ENV_FILE="/etc/xuanyuan/xuanyuan.env"

if [[ -z "$DOMAIN" ]]; then
  echo "usage: setup.sh <domain> [git-repo-url]" >&2
  exit 1
fi
if [[ $EUID -ne 0 ]]; then
  echo "run with sudo" >&2
  exit 1
fi

echo "==> system packages"
if command -v apt-get >/dev/null; then
  PKG=apt
  apt-get update -y
  apt-get install -y curl git ca-certificates gnupg debian-keyring debian-archive-keyring apt-transport-https sqlite3 rsync openssl
elif command -v dnf >/dev/null; then
  PKG=dnf   # Amazon Linux 2023 / Fedora / RHEL 9
  dnf install -y curl-minimal git ca-certificates sqlite rsync openssl tar gzip
else
  echo "unsupported distro (need apt or dnf)" >&2; exit 1
fi

echo "==> Node.js 22"
if ! command -v node >/dev/null || [[ "$(node -v | cut -d. -f1 | tr -d v)" -lt 22 ]]; then
  if [[ "$PKG" == apt ]]; then
    curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
    apt-get install -y nodejs
  else
    curl -fsSL https://rpm.nodesource.com/setup_22.x | bash -
    dnf install -y nodejs
  fi
fi
corepack enable
corepack prepare pnpm@10 --activate
# pnpm/corepack shims land in a per-user dir on some images; expose them system-wide.
for bin in pnpm pnpx; do
  if ! command -v "$bin" >/dev/null && [[ -x "$(dirname "$(command -v node)")/$bin" ]]; then ln -sf "$(dirname "$(command -v node)")/$bin" /usr/local/bin/$bin; fi
done

echo "==> Caddy"
if ! command -v caddy >/dev/null; then
  if [[ "$PKG" == apt ]]; then
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy-stable.list >/dev/null
    apt-get update -y && apt-get install -y caddy
  else
    # Official static binary + systemd unit (dnf has no caddy package on AL2023).
    curl -fsSL "https://caddyserver.com/api/download?os=linux&arch=$(uname -m | sed 's/x86_64/amd64/; s/aarch64/arm64/')" -o /usr/bin/caddy
    chmod 755 /usr/bin/caddy
    groupadd --system caddy 2>/dev/null || true
    useradd --system --gid caddy --create-home --home-dir /var/lib/caddy --shell /usr/sbin/nologin caddy 2>/dev/null || true
    mkdir -p /etc/caddy
    cat > /etc/systemd/system/caddy.service <<'UNIT'
[Unit]
Description=Caddy
After=network.target network-online.target
Requires=network-online.target

[Service]
User=caddy
Group=caddy
ExecStart=/usr/bin/caddy run --environ --config /etc/caddy/Caddyfile
ExecReload=/usr/bin/caddy reload --config /etc/caddy/Caddyfile --force
TimeoutStopSec=5s
LimitNOFILE=1048576
PrivateTmp=true
ProtectSystem=full
AmbientCapabilities=CAP_NET_BIND_SERVICE

[Install]
WantedBy=multi-user.target
UNIT
    systemctl daemon-reload
    systemctl enable caddy
  fi
fi

echo "==> service user + directories"
id -u "$APP_USER" >/dev/null 2>&1 || useradd --system --home "$APP_DIR" --shell "$(command -v nologin || echo /sbin/nologin)" "$APP_USER"
mkdir -p "$APP_DIR" /var/lib/xuanyuan /var/backups/xuanyuan /etc/xuanyuan

echo "==> source code"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
if [[ -n "$REPO_URL" ]]; then
  if [[ -d "$APP_DIR/.git" ]]; then git -C "$APP_DIR" pull --ff-only; else git clone "$REPO_URL" "$APP_DIR"; fi
elif [[ "$SRC_DIR" != "$APP_DIR" && -f "$SRC_DIR/package.json" ]]; then
  rsync -a --delete --exclude node_modules --exclude dist --exclude data --exclude .git "$SRC_DIR/" "$APP_DIR/"
fi

echo "==> environment file"
if [[ ! -f "$ENV_FILE" ]]; then
  SESSION_SECRET="$(openssl rand -base64 48 | tr -d '\n')"
  sed -e "s#__DOMAIN__#$DOMAIN#g" -e "s#__SESSION_SECRET__#$SESSION_SECRET#g" "$APP_DIR/deploy/aws/xuanyuan.env.example" > "$ENV_FILE"
  echo "    created $ENV_FILE — edit it to add CREDIT_STORE_ADDRESS, ADMIN_EMAILS, ADMIN_PASSWORD, DEEPSEEK_API_KEY"
fi

chown root:"$APP_USER" "$ENV_FILE"; chmod 640 "$ENV_FILE"

echo "==> systemd + caddy config"
sed -e "s#__DOMAIN__#$DOMAIN#g" "$APP_DIR/deploy/aws/Caddyfile" > /etc/caddy/Caddyfile
install -m 644 "$APP_DIR/deploy/aws/xuanyuan.service" /etc/systemd/system/xuanyuan.service
install -m 644 "$APP_DIR/deploy/aws/xuanyuan-backup.service" /etc/systemd/system/xuanyuan-backup.service
install -m 644 "$APP_DIR/deploy/aws/xuanyuan-backup.timer" /etc/systemd/system/xuanyuan-backup.timer
install -m 755 "$APP_DIR/deploy/aws/deploy.sh" /usr/local/bin/xuanyuan-deploy
install -m 755 "$APP_DIR/deploy/aws/backup.sh" /usr/local/bin/xuanyuan-backup
chown -R "$APP_USER:$APP_USER" "$APP_DIR" /var/lib/xuanyuan /var/backups/xuanyuan
systemctl daemon-reload

echo "==> build + migrate"
/usr/local/bin/xuanyuan-deploy

systemctl enable --now xuanyuan-backup.timer
systemctl enable --now xuanyuan
systemctl enable caddy >/dev/null 2>&1 || true
systemctl restart caddy
sleep 2
systemctl is-active --quiet caddy || { echo "!!! caddy failed to start:"; journalctl -u caddy -n 20 --no-pager; exit 1; }
systemctl is-active --quiet xuanyuan || { echo "!!! xuanyuan failed to start:"; journalctl -u xuanyuan -n 20 --no-pager; exit 1; }

echo
echo "Done. Site: https://$DOMAIN"
echo "Next: sudo nano $ENV_FILE  (set CREDIT_STORE_ADDRESS etc.)  then  sudo systemctl restart xuanyuan"
