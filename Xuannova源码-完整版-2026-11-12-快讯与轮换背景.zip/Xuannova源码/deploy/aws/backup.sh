#!/usr/bin/env bash
# Consistent SQLite snapshot (safe under WAL) → /var/backups/xuanyuan, keep 14 days.
# Set BACKUP_S3_URI=s3://bucket/prefix in the env file to also copy to S3 (needs aws cli + instance role).
set -euo pipefail
DB="${DATABASE_PATH:-/var/lib/xuanyuan/xuanyuan.sqlite}"
OUT_DIR="/var/backups/xuanyuan"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$OUT_DIR/xuanyuan-$STAMP.sqlite"
mkdir -p "$OUT_DIR"
sqlite3 "$DB" ".backup '$OUT'"
gzip -f "$OUT"
find "$OUT_DIR" -name 'xuanyuan-*.sqlite.gz' -mtime +14 -delete
if [[ -n "${BACKUP_S3_URI:-}" ]] && command -v aws >/dev/null; then
  aws s3 cp "$OUT.gz" "$BACKUP_S3_URI/xuanyuan-$STAMP.sqlite.gz"
fi
echo "backup written: $OUT.gz"
