#!/usr/bin/env bash
# Build + migrate + restart. Run after every code update:  sudo xuanyuan-deploy
set -euo pipefail
APP_DIR="/opt/xuanyuan"
APP_USER="xuanyuan"
ENV_FILE="/etc/xuanyuan/xuanyuan.env"

cd "$APP_DIR"
chown root:"$APP_USER" "$ENV_FILE" 2>/dev/null; chmod 640 "$ENV_FILE" 2>/dev/null
if [[ -d .git ]]; then sudo -u "$APP_USER" git pull --ff-only; fi
sudo -u "$APP_USER" -H bash -c 'cd /opt/xuanyuan && pnpm install --frozen-lockfile || pnpm install'
sudo -u "$APP_USER" -H bash -c 'cd /opt/xuanyuan && DEPLOY_TARGET=node pnpm exec vinext build'
sudo -u "$APP_USER" -H bash -c "set -a; source $ENV_FILE; set +a; cd /opt/xuanyuan && node --no-warnings=ExperimentalWarning scripts/migrate.mjs"
if systemctl is-enabled xuanyuan >/dev/null 2>&1; then systemctl restart xuanyuan; fi
echo "deployed."
