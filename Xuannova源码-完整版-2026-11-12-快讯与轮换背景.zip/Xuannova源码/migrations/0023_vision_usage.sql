-- 手相面相 (2026-11-05): count photo analyses per member per day (UTC) so the vision model cost stays bounded.
-- Only the count is stored; photos are never saved.
CREATE TABLE IF NOT EXISTS vision_usage (
  member_id TEXT NOT NULL,
  usage_date TEXT NOT NULL,
  count INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (member_id, usage_date)
);
