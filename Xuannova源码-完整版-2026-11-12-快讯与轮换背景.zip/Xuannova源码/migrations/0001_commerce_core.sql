PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS members (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_salt TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  credits INTEGER NOT NULL DEFAULT 0 CHECK (credits >= 0),
  role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('member', 'admin')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS payment_orders (
  id TEXT PRIMARY KEY,
  member_id TEXT NOT NULL,
  package_id TEXT NOT NULL,
  amount_usdt TEXT NOT NULL,
  credits INTEGER NOT NULL CHECK (credits > 0),
  network TEXT NOT NULL CHECK (network IN ('trc20', 'bsc')),
  transaction_hash TEXT NOT NULL UNIQUE COLLATE NOCASE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  submitted_at TEXT NOT NULL,
  reviewed_at TEXT,
  reviewed_by TEXT,
  review_note TEXT,
  FOREIGN KEY (member_id) REFERENCES members(id)
);

CREATE INDEX IF NOT EXISTS payment_orders_member_submitted_idx
  ON payment_orders(member_id, submitted_at DESC);
CREATE INDEX IF NOT EXISTS payment_orders_status_submitted_idx
  ON payment_orders(status, submitted_at DESC);

CREATE TABLE IF NOT EXISTS credit_ledger (
  id TEXT PRIMARY KEY,
  member_id TEXT NOT NULL,
  order_id TEXT UNIQUE,
  delta INTEGER NOT NULL,
  balance_after INTEGER NOT NULL CHECK (balance_after >= 0),
  reason TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY (member_id) REFERENCES members(id),
  FOREIGN KEY (order_id) REFERENCES payment_orders(id)
);

CREATE INDEX IF NOT EXISTS credit_ledger_member_created_idx
  ON credit_ledger(member_id, created_at DESC);

CREATE TABLE IF NOT EXISTS admin_audit (
  id TEXT PRIMARY KEY,
  admin_email TEXT NOT NULL,
  event_type TEXT NOT NULL,
  subject_id TEXT,
  detail TEXT,
  created_at TEXT NOT NULL
);

CREATE TRIGGER IF NOT EXISTS payment_order_approved_credit_once
AFTER UPDATE OF status ON payment_orders
WHEN OLD.status = 'pending' AND NEW.status = 'approved'
BEGIN
  UPDATE members
  SET credits = credits + NEW.credits,
      updated_at = NEW.reviewed_at
  WHERE id = NEW.member_id;

  INSERT INTO credit_ledger (
    id, member_id, order_id, delta, balance_after, reason, created_at
  )
  SELECT
    lower(hex(randomblob(16))),
    NEW.member_id,
    NEW.id,
    NEW.credits,
    credits,
    'payment_approval',
    NEW.reviewed_at
  FROM members
  WHERE id = NEW.member_id;
END;
