CREATE TABLE IF NOT EXISTS interpretation_history (
  id TEXT PRIMARY KEY,
  member_id TEXT NOT NULL,
  tool TEXT NOT NULL,
  locale TEXT NOT NULL,
  mode TEXT NOT NULL,
  question TEXT NOT NULL,
  response_json TEXT NOT NULL,
  cost INTEGER NOT NULL CHECK (cost > 0),
  created_at TEXT NOT NULL,
  FOREIGN KEY (member_id) REFERENCES members(id)
);

CREATE INDEX IF NOT EXISTS interpretation_history_member_created_idx
  ON interpretation_history(member_id, created_at DESC);
