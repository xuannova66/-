-- Wallet payments on Solana and TRON (2026-11-06). The server creates an order with a random 32-byte reference; the
-- member's wallet sends a direct USDC/USDT transfer carrying that reference; once the transfer is final on chain and
-- matches the order exactly, an approved payment_orders row is written (the existing trigger credits the member) and
-- the wallet order is marked credited. A transaction signature can be used for one order only.
CREATE TABLE wallet_pay_orders (
  id TEXT PRIMARY KEY,
  member_id TEXT NOT NULL REFERENCES members(id),
  chain TEXT NOT NULL CHECK (chain IN ('solana', 'tron')),
  package_id TEXT NOT NULL,
  credits INTEGER NOT NULL CHECK (credits > 0),
  asset TEXT NOT NULL CHECK (asset IN ('USDC', 'USDT')),
  buyer TEXT NOT NULL,
  recipient TEXT NOT NULL,
  recipient_account TEXT,
  amount_units TEXT NOT NULL,
  reference TEXT NOT NULL UNIQUE CHECK (length(reference) = 64),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'credited')),
  signature TEXT UNIQUE,
  payment_order_id TEXT,
  created_at TEXT NOT NULL,
  credited_at TEXT
);
CREATE INDEX wallet_pay_orders_member_idx ON wallet_pay_orders(member_id, created_at DESC);
