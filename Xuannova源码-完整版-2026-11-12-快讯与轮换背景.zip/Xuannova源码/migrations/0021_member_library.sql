-- Member library (2026-11-05): saved birth profiles, reports kept with their chart (to ask follow-ups
-- later and to group by person), notes on reports, and an opt-in solar-term reminder.

CREATE TABLE IF NOT EXISTS member_profiles (
  id TEXT PRIMARY KEY,
  member_id TEXT NOT NULL,
  label TEXT NOT NULL,
  relation TEXT NOT NULL DEFAULT 'self',
  name TEXT NOT NULL DEFAULT '',
  gender TEXT NOT NULL DEFAULT 'yang',
  calendar TEXT NOT NULL DEFAULT 'solar',
  birth_date TEXT NOT NULL,
  birth_time TEXT NOT NULL DEFAULT '',
  leap_month INTEGER NOT NULL DEFAULT 0,
  place TEXT NOT NULL DEFAULT '',
  location_json TEXT,
  consent_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS member_profiles_member_idx ON member_profiles (member_id, updated_at);

ALTER TABLE reading_drafts ADD COLUMN chart_json TEXT;
ALTER TABLE interpretation_history ADD COLUMN chart_json TEXT;
ALTER TABLE interpretation_history ADD COLUMN subject TEXT;

CREATE TABLE IF NOT EXISTS member_notes (
  member_id TEXT NOT NULL,
  ref TEXT NOT NULL,
  body TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (member_id, ref)
);

ALTER TABLE daily_reminders ADD COLUMN solar_terms INTEGER NOT NULL DEFAULT 0;
