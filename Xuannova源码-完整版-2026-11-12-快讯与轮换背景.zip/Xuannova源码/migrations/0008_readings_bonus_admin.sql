-- Free half-reading drafts: the full reading is stored here and only the first half is sent to the
-- browser until a signed-in member unlocks it with credits.
CREATE TABLE IF NOT EXISTS reading_drafts (
  id TEXT PRIMARY KEY,
  device_id TEXT NOT NULL,
  member_id TEXT,
  tool TEXT NOT NULL,
  locale TEXT NOT NULL,
  mode TEXT NOT NULL,
  question TEXT NOT NULL,
  response_json TEXT NOT NULL,
  cost INTEGER NOT NULL,
  unlocked_by TEXT,
  unlocked_at TEXT,
  history_id TEXT,
  created_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS reading_drafts_device_created_idx ON reading_drafts(device_id, created_at DESC);
--> statement-breakpoint
-- One daily bonus per device per day, whichever account signs in first on that device.
CREATE TABLE IF NOT EXISTS daily_bonus_claims (
  device_id TEXT NOT NULL,
  claim_date TEXT NOT NULL,
  member_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY (device_id, claim_date)
);
--> statement-breakpoint
ALTER TABLE members ADD COLUMN daily_claimed_at TEXT;
--> statement-breakpoint
-- Member groups for targeted packages and bulk grants.
CREATE TABLE IF NOT EXISTS member_groups (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  note TEXT,
  created_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS member_group_members (
  group_id TEXT NOT NULL,
  member_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY (group_id, member_id)
);
--> statement-breakpoint
-- Exclusive credit packages shown only to chosen members or groups (paid through the reviewed
-- manual-transfer order; nothing on-chain changes).
CREATE TABLE IF NOT EXISTS exclusive_packages (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  credits INTEGER NOT NULL CHECK (credits > 0),
  price_usdt TEXT NOT NULL,
  member_id TEXT,
  group_id TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  note TEXT,
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL
);
--> statement-breakpoint
-- Manual credit grants: one administrator requests, a different administrator approves.
CREATE TABLE IF NOT EXISTS credit_grant_requests (
  id TEXT PRIMARY KEY,
  member_id TEXT,
  group_id TEXT,
  credits INTEGER NOT NULL CHECK (credits > 0 AND credits <= 100000),
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  requested_by TEXT NOT NULL,
  reviewed_by TEXT,
  review_note TEXT,
  created_at TEXT NOT NULL,
  reviewed_at TEXT
);
