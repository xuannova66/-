-- 测字 (2026-11-06): the structure of a character is analysed once per character and language and cached;
-- new analyses are counted per member or device per day (UTC) to keep the text-model cost bounded.
CREATE TABLE IF NOT EXISTS cezi_cache (
  character TEXT NOT NULL,
  locale TEXT NOT NULL,
  analysis_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY (character, locale)
);
CREATE TABLE IF NOT EXISTS cezi_usage (
  usage_key TEXT NOT NULL,
  usage_date TEXT NOT NULL,
  count INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (usage_key, usage_date)
);
