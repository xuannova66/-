-- 分享来源统计 (2026-11-08): which poster or link brought people in. members.signup_source keeps the first share
-- source seen on the visitor's device (daily-card, action-card, almanac-card, lamp-card, chart-card, invite-link);
-- share_stats keeps daily totals only (no person, device or IP is stored).
ALTER TABLE members ADD COLUMN signup_source TEXT;
CREATE INDEX IF NOT EXISTS members_signup_source_idx ON members(signup_source);
CREATE TABLE IF NOT EXISTS share_stats (
  day TEXT NOT NULL,
  source TEXT NOT NULL,
  action TEXT NOT NULL,
  count INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (day, source, action)
);
