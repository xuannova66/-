-- Growth features (2026-11-02): first-purchase bonus, daily reminder e-mails, hiding history items.

-- One row per member once their first-purchase bonus has been settled (credits = 0 for members who
-- had already bought before this feature, so the bonus is only for purchases made from now on).
CREATE TABLE IF NOT EXISTS first_purchase_bonus (
  member_id TEXT PRIMARY KEY,
  credits INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
INSERT OR IGNORE INTO first_purchase_bonus (member_id, credits, created_at)
  SELECT DISTINCT member_id, 0, datetime('now') FROM payment_orders WHERE status = 'approved';
INSERT OR IGNORE INTO first_purchase_bonus (member_id, credits, created_at)
  SELECT DISTINCT member_id, 0, datetime('now') FROM dodo_orders WHERE status IN ('paid', 'refunded', 'partially_refunded');

-- Daily reminder e-mail (opt-in, one per local day, unsubscribe link carries the token).
CREATE TABLE IF NOT EXISTS daily_reminders (
  member_id TEXT PRIMARY KEY,
  enabled INTEGER NOT NULL DEFAULT 1,
  timezone TEXT NOT NULL DEFAULT 'UTC',
  locale TEXT NOT NULL DEFAULT 'en',
  token TEXT NOT NULL UNIQUE,
  last_sent_date TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- Members can remove readings they have finished with from their question history.
ALTER TABLE interpretation_history ADD COLUMN hidden_at TEXT;
CREATE INDEX IF NOT EXISTS interpretation_history_member_visible_idx ON interpretation_history (member_id, hidden_at, created_at);
