-- Card payments through Dodo Payments (merchant of record). Kept apart from the USDT payment_orders table,
-- which belongs to the on-chain flow and is not changed.
CREATE TABLE IF NOT EXISTS dodo_orders (
  id TEXT PRIMARY KEY,
  member_id TEXT NOT NULL,
  package_id TEXT NOT NULL,
  credits INTEGER NOT NULL CHECK (credits > 0),
  amount_usd TEXT NOT NULL,
  checkout_session_id TEXT,
  payment_id TEXT UNIQUE,
  status TEXT NOT NULL DEFAULT 'created' CHECK (status IN ('created', 'paid', 'failed', 'refunded', 'partially_refunded')),
  refunded_credits INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  paid_at TEXT,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (member_id) REFERENCES members(id)
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS dodo_orders_member_idx ON dodo_orders(member_id, created_at DESC);
--> statement-breakpoint
-- Each webhook delivery is processed once (Dodo retries deliveries).
CREATE TABLE IF NOT EXISTS dodo_webhook_events (
  webhook_id TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  received_at TEXT NOT NULL
);
--> statement-breakpoint
-- First-purchase invitation reward for card payments (USDT purchases use invitation_purchase_rewards).
CREATE TABLE IF NOT EXISTS dodo_invitation_rewards (
  invitee_member_id TEXT PRIMARY KEY,
  inviter_member_id TEXT NOT NULL,
  dodo_order_id TEXT NOT NULL UNIQUE,
  awarded_at TEXT NOT NULL
);
