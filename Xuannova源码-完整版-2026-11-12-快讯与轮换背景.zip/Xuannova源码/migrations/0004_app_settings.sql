-- Key/value store for runtime bookkeeping (e.g. last scanned BSC block for the purchase watcher).
CREATE TABLE IF NOT EXISTS app_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
