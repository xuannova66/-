-- Existing orders remain USDT; new USDC checkout orders record their actual settlement asset.
ALTER TABLE payment_orders ADD COLUMN settlement_currency TEXT NOT NULL DEFAULT 'USDT' CHECK(settlement_currency IN ('USDT','USDC'));
