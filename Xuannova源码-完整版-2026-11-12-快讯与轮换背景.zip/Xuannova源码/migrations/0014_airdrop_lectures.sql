-- Credit airdrops: a grant can target all members or an explicit list of members (JSON array of ids).
ALTER TABLE credit_grant_requests ADD COLUMN target TEXT NOT NULL DEFAULT 'single';
--> statement-breakpoint
ALTER TABLE credit_grant_requests ADD COLUMN member_list TEXT;
--> statement-breakpoint
-- Lecture videos can be uploaded to the server (members watch them free) instead of only linked.
ALTER TABLE lectures ADD COLUMN media_file TEXT;
--> statement-breakpoint
ALTER TABLE lectures ADD COLUMN members_only INTEGER NOT NULL DEFAULT 1;
