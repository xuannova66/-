-- The free half reading is offered once per device and once per account (not per day).
-- Paid readings generated directly after the free one are stored with is_free = 0.
ALTER TABLE reading_drafts ADD COLUMN is_free INTEGER NOT NULL DEFAULT 1;
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS reading_drafts_member_free_idx ON reading_drafts(member_id, is_free);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS reading_drafts_device_free_idx ON reading_drafts(device_id, is_free);
