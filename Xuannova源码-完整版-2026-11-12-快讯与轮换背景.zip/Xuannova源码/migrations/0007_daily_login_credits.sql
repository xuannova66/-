ALTER TABLE members ADD COLUMN daily_credits INTEGER NOT NULL DEFAULT 0 CHECK (daily_credits >= 0);
--> statement-breakpoint
ALTER TABLE members ADD COLUMN daily_credit_date TEXT;
