-- 我的静室 (2026-11-07): a member's own room. Members are listed by 道号 only; shared charts are snapshots of a
-- member's saved profile (birth date, time, calendar, gender), shared with consent and removable at any time.
CREATE TABLE IF NOT EXISTS rooms (
  id TEXT PRIMARY KEY,
  owner_id TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  invite_token TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS room_members (
  room_id TEXT NOT NULL,
  member_id TEXT NOT NULL,
  dao_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('owner', 'member')),
  joined_at TEXT NOT NULL,
  last_seen TEXT,
  PRIMARY KEY (room_id, member_id)
);
CREATE INDEX IF NOT EXISTS room_members_member_idx ON room_members(member_id);
CREATE TABLE IF NOT EXISTS room_shares (
  id TEXT PRIMARY KEY,
  room_id TEXT NOT NULL,
  member_id TEXT NOT NULL,
  label TEXT NOT NULL,
  chart_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS room_shares_room_idx ON room_shares(room_id, created_at DESC);
