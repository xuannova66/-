-- 玄诺快讯 (2026-11-12): short news items read through Eastern culture (五行, 易经, 节气), in seven languages.
-- One row per item, one row per item and language. Views are real counts (one per device per item per day);
-- they are never seeded or inflated. Items come from the automation API (Make/n8n), the built-in news runner
-- or the admin page.
CREATE TABLE IF NOT EXISTS flash_items (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  category TEXT NOT NULL DEFAULT 'focus',
  status TEXT NOT NULL DEFAULT 'published',
  pinned INTEGER NOT NULL DEFAULT 0,
  featured INTEGER NOT NULL DEFAULT 0,
  cta TEXT NOT NULL DEFAULT 'bazi',
  source_url TEXT,
  source_name TEXT,
  source_key TEXT UNIQUE,
  cover_url TEXT,
  origin TEXT NOT NULL DEFAULT 'api',
  views INTEGER NOT NULL DEFAULT 0,
  shares INTEGER NOT NULL DEFAULT 0,
  posters INTEGER NOT NULL DEFAULT 0,
  published_at TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS flash_items_list_idx ON flash_items(status, published_at);

CREATE TABLE IF NOT EXISTS flash_translations (
  flash_id TEXT NOT NULL,
  locale TEXT NOT NULL,
  title TEXT NOT NULL,
  summary TEXT NOT NULL,
  body TEXT NOT NULL,
  quote TEXT,
  quote_source TEXT,
  PRIMARY KEY (flash_id, locale)
);

-- One view per device per item per day (rows older than a few days are pruned).
CREATE TABLE IF NOT EXISTS flash_views (
  flash_id TEXT NOT NULL,
  visitor TEXT NOT NULL,
  day TEXT NOT NULL,
  PRIMARY KEY (flash_id, visitor, day)
);

-- News the automatic runner has already looked at (used or skipped), so it is not asked about twice.
CREATE TABLE IF NOT EXISTS flash_seen (
  source_key TEXT PRIMARY KEY,
  decision TEXT NOT NULL,
  seen_at TEXT NOT NULL
);
