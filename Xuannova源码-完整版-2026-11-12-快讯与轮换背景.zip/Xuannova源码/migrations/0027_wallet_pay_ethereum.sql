-- Wallet payments on Ethereum (2026-11-07): wallet_pay_orders accepts chain 'ethereum'. The table only references
-- members and nothing references it, so it is rebuilt in place with the same columns and index.
CREATE TABLE wallet_pay_orders_new (
  id TEXT PRIMARY KEY,
  member_id TEXT NOT NULL REFERENCES members(id),
  chain TEXT NOT NULL CHECK (chain IN ('solana', 'tron', 'ethereum')),
  package_id TEXT NOT NULL,
  credits INTEGER NOT NULL CHECK (credits > 0),
  asset TEXT NOT NULL CHECK (asset IN ('USDC', 'USDT')),
  buyer TEXT NOT NULL,
  recipient TEXT NOT NULL,
  recipient_account TEXT,
  amount_units TEXT NOT NULL,
  reference TEXT NOT NULL UNIQUE CHECK (length(reference) = 64),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'credited')),
  signature TEXT UNIQUE,
  payment_order_id TEXT,
  created_at TEXT NOT NULL,
  credited_at TEXT
);
INSERT INTO wallet_pay_orders_new SELECT id, member_id, chain, package_id, credits, asset, buyer, recipient, recipient_account, amount_units, reference, status, signature, payment_order_id, created_at, credited_at FROM wallet_pay_orders;
DROP TABLE wallet_pay_orders;
ALTER TABLE wallet_pay_orders_new RENAME TO wallet_pay_orders;
CREATE INDEX wallet_pay_orders_member_idx ON wallet_pay_orders(member_id, created_at DESC);
