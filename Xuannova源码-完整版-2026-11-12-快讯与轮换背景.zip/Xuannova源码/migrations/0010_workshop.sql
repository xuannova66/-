-- 器物坊 (Workshop): physical goods paid with a reviewed USDT transfer (no on-chain code involved).
CREATE TABLE IF NOT EXISTS shop_products (
  id TEXT PRIMARY KEY,
  name_json TEXT NOT NULL,
  description_json TEXT NOT NULL DEFAULT '{}',
  price_usdt TEXT NOT NULL,
  image_url TEXT,
  stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
  active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS shop_orders (
  id TEXT PRIMARY KEY,
  member_id TEXT NOT NULL,
  items_json TEXT NOT NULL,
  total_usdt TEXT NOT NULL,
  network TEXT NOT NULL,
  transaction_hash TEXT NOT NULL UNIQUE COLLATE NOCASE,
  shipping_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'shipped', 'rejected')),
  tracking TEXT,
  admin_note TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS shop_orders_member_idx ON shop_orders(member_id, created_at DESC);
