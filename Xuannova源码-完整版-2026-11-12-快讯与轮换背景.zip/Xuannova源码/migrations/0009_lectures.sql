-- Free video lectures (no sign-in needed). Titles and summaries are stored per language as JSON.
CREATE TABLE IF NOT EXISTS lectures (
  id TEXT PRIMARY KEY,
  title_json TEXT NOT NULL,
  summary_json TEXT NOT NULL DEFAULT '{}',
  video_url TEXT NOT NULL,
  duration_minutes INTEGER,
  category TEXT NOT NULL DEFAULT 'foundation',
  sort_order INTEGER NOT NULL DEFAULT 0,
  published INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
