-- Library shelf (2026-11-05): members can favourite classics, and the reader remembers where they stopped.
-- (0016 is left for the payment work done in parallel.)
CREATE TABLE IF NOT EXISTS library_shelf (
  member_id TEXT NOT NULL,
  work_id TEXT NOT NULL,
  favorite INTEGER NOT NULL DEFAULT 0,
  chapter INTEGER,
  chapter_count INTEGER,
  paragraph INTEGER,
  chapter_title TEXT,
  favorited_at TEXT,
  read_at TEXT,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (member_id, work_id)
);
CREATE INDEX IF NOT EXISTS library_shelf_member_idx ON library_shelf (member_id, updated_at);
