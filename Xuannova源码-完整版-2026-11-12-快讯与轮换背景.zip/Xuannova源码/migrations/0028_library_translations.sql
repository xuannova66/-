-- 藏经阁 on-demand translation (2026-11-07): each translated passage is cached per book, chapter, paragraph range and
-- language (with a hash of the source text), so it is generated once and shared by every reader. New translations
-- are counted per member or device per day, plus one site-wide counter, to keep the text-model cost bounded.
CREATE TABLE IF NOT EXISTS library_translations (
  cache_key TEXT PRIMARY KEY,
  locale TEXT NOT NULL,
  text_hash TEXT NOT NULL,
  paragraphs_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS library_translation_usage (
  usage_key TEXT NOT NULL,
  usage_date TEXT NOT NULL,
  count INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (usage_key, usage_date)
);
