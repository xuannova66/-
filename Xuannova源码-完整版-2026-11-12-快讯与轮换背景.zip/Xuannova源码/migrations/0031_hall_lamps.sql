-- 研习殿 · 点亮祈福灯 (2026-11-08): a member lights a digital lamp for 2 credits (≈ US$0.50). The lamp glows in the
-- hall for 7 days. Only the 道号 shown on it, an optional short wish (filtered), whether it is shown to others, and
-- the times are kept. The credit debit and its ledger row are written in the same batch as the lamp.
CREATE TABLE IF NOT EXISTS hall_lamps (
  id TEXT PRIMARY KEY,
  member_id TEXT NOT NULL,
  name TEXT NOT NULL,
  wish TEXT,
  kind TEXT NOT NULL DEFAULT 'peace',
  public INTEGER NOT NULL DEFAULT 1,
  ledger_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS hall_lamps_expires_idx ON hall_lamps(expires_at);
CREATE INDEX IF NOT EXISTS hall_lamps_member_idx ON hall_lamps(member_id, created_at);
