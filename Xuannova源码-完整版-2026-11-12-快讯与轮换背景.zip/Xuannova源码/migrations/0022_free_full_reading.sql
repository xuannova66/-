-- Free full BaZi reading (2026-11-05): each signed-in member gets one full 八字排盘 reading free (once per account and per device).
-- interpretation_history is rebuilt so a free report can be kept with cost 0 (the old check required cost > 0).
CREATE TABLE interpretation_history_new (
  id TEXT PRIMARY KEY,
  member_id TEXT NOT NULL,
  tool TEXT NOT NULL,
  locale TEXT NOT NULL,
  mode TEXT NOT NULL,
  question TEXT NOT NULL,
  response_json TEXT NOT NULL,
  cost INTEGER NOT NULL CHECK (cost >= 0),
  created_at TEXT NOT NULL,
  hidden_at TEXT,
  chart_json TEXT,
  subject TEXT,
  FOREIGN KEY (member_id) REFERENCES members(id)
);
INSERT INTO interpretation_history_new (id, member_id, tool, locale, mode, question, response_json, cost, created_at, hidden_at, chart_json, subject)
  SELECT id, member_id, tool, locale, mode, question, response_json, cost, created_at, hidden_at, chart_json, subject FROM interpretation_history;
DROP TABLE interpretation_history;
ALTER TABLE interpretation_history_new RENAME TO interpretation_history;
CREATE INDEX IF NOT EXISTS interpretation_history_member_created_idx ON interpretation_history(member_id, created_at DESC);
CREATE INDEX IF NOT EXISTS interpretation_history_member_visible_idx ON interpretation_history (member_id, hidden_at, created_at);

-- One free full reading per member and per device (claim_date is "once"), so new accounts on the same
-- device do not get extra free readings.
CREATE TABLE IF NOT EXISTS free_full_readings (
  member_id TEXT NOT NULL,
  claim_date TEXT NOT NULL,
  device_id TEXT NOT NULL,
  tool TEXT NOT NULL,
  history_id TEXT,
  created_at TEXT NOT NULL,
  PRIMARY KEY (member_id, claim_date)
);
CREATE UNIQUE INDEX IF NOT EXISTS free_full_readings_device_day ON free_full_readings (device_id, claim_date);
