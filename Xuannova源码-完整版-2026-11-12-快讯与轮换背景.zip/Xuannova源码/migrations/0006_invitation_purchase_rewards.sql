CREATE TABLE IF NOT EXISTS invitation_purchase_rewards (
  invitee_member_id TEXT PRIMARY KEY,
  inviter_member_id TEXT NOT NULL,
  order_id TEXT NOT NULL UNIQUE,
  awarded_at TEXT NOT NULL,
  FOREIGN KEY (invitee_member_id) REFERENCES members(id),
  FOREIGN KEY (inviter_member_id) REFERENCES members(id),
  FOREIGN KEY (order_id) REFERENCES payment_orders(id)
);
