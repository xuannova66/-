-- Rebuild without the old hash-only unique constraint. The migration runner
-- must disable foreign_keys before beginning this migration and check them
-- before committing; existing order ids and ledger references are preserved.
PRAGMA foreign_keys = OFF;
CREATE TABLE payment_orders_new (
  id TEXT PRIMARY KEY, member_id TEXT NOT NULL, package_id TEXT NOT NULL,
  amount_usdt TEXT NOT NULL, credits INTEGER NOT NULL CHECK (credits > 0),
  network TEXT NOT NULL CHECK (network IN ('trc20', 'bsc')),
  transaction_hash TEXT NOT NULL COLLATE NOCASE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  submitted_at TEXT NOT NULL, reviewed_at TEXT, reviewed_by TEXT, review_note TEXT,
  buyer_address TEXT, chain_id INTEGER, contract_address TEXT, fee_wei TEXT, block_number INTEGER,
  settlement_currency TEXT NOT NULL DEFAULT 'USDT' CHECK(settlement_currency IN ('USDT','USDC')),
  sale_index TEXT,
  FOREIGN KEY (member_id) REFERENCES members(id)
);
INSERT INTO payment_orders_new (id,member_id,package_id,amount_usdt,credits,network,transaction_hash,status,submitted_at,reviewed_at,reviewed_by,review_note,buyer_address,chain_id,contract_address,fee_wei,block_number,settlement_currency)
SELECT id,member_id,package_id,amount_usdt,credits,network,transaction_hash,status,submitted_at,reviewed_at,reviewed_by,review_note,buyer_address,chain_id,contract_address,fee_wei,block_number,settlement_currency FROM payment_orders;
DROP TABLE payment_orders;
ALTER TABLE payment_orders_new RENAME TO payment_orders;
CREATE INDEX payment_orders_member_submitted_idx ON payment_orders(member_id, submitted_at DESC);
CREATE INDEX payment_orders_status_submitted_idx ON payment_orders(status, submitted_at DESC);
CREATE INDEX payment_orders_buyer_idx ON payment_orders(buyer_address COLLATE NOCASE);
CREATE INDEX payment_orders_hash_idx ON payment_orders(transaction_hash COLLATE NOCASE);
CREATE UNIQUE INDEX payment_orders_chain_event_idx ON payment_orders(chain_id, contract_address COLLATE NOCASE, transaction_hash COLLATE NOCASE, sale_index) WHERE sale_index IS NOT NULL;
CREATE UNIQUE INDEX payment_orders_legacy_hash_idx ON payment_orders(transaction_hash COLLATE NOCASE) WHERE sale_index IS NULL;
CREATE TRIGGER payment_order_approved_credit_once AFTER UPDATE OF status ON payment_orders
WHEN OLD.status = 'pending' AND NEW.status = 'approved'
BEGIN
 UPDATE members SET credits = credits + NEW.credits, updated_at = NEW.reviewed_at WHERE id = NEW.member_id;
 INSERT INTO credit_ledger (id,member_id,order_id,delta,balance_after,reason,created_at)
 SELECT lower(hex(randomblob(16))),NEW.member_id,NEW.id,NEW.credits,credits,'payment_approval',NEW.reviewed_at FROM members WHERE id = NEW.member_id;
END;
PRAGMA foreign_keys = ON;
