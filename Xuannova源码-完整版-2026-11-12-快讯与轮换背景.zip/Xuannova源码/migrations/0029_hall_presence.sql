-- 研习殿 · 同殿共修 (2026-11-07): visitors online in the study hall. Only a 道号, whether it was chosen by the visitor,
-- the page being studied and the last heartbeat are kept; the id is derived from the device cookie on the server.
-- Rows are removed ten minutes after the last heartbeat.
CREATE TABLE IF NOT EXISTS hall_presence (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  custom INTEGER NOT NULL DEFAULT 0,
  route TEXT,
  last_seen TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS hall_presence_seen_idx ON hall_presence(last_seen);
