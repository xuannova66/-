-- Forgot password: single-use reset links (only a SHA-256 of the token is stored), valid 30 minutes.
CREATE TABLE IF NOT EXISTS password_resets (
  token_hash TEXT PRIMARY KEY,
  member_id TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  used_at TEXT,
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS password_resets_member_idx ON password_resets(member_id, created_at DESC);
