-- Preserve confirmed purchases whose wallet is not yet associated with a member.
CREATE TABLE IF NOT EXISTS unmatched_chain_purchases (
  chain_id INTEGER NOT NULL,
  contract_address TEXT NOT NULL COLLATE NOCASE,
  transaction_hash TEXT NOT NULL COLLATE NOCASE,
  buyer_address TEXT NOT NULL COLLATE NOCASE,
  package_id TEXT NOT NULL,
  fee_wei TEXT NOT NULL,
  sale_index TEXT NOT NULL,
  block_number INTEGER NOT NULL,
  checkout TEXT NOT NULL CHECK (checkout IN ('legacy', 'usdc')),
  created_at TEXT NOT NULL,
  PRIMARY KEY (chain_id, contract_address, transaction_hash, sale_index)
);
