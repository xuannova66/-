ALTER TABLE members ADD COLUMN invite_code TEXT;
ALTER TABLE members ADD COLUMN invited_by_member_id TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS members_invite_code_idx
  ON members(invite_code COLLATE NOCASE);

CREATE INDEX IF NOT EXISTS members_invited_by_member_idx
  ON members(invited_by_member_id);
