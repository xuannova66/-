/**
 * Node-only background job: every CHAIN_SYNC_INTERVAL_MS (default 30 s) scan the
 * XuanyuanCreditStore contract for Purchased events and credit any purchase
 * that was never submitted by the buyer's browser. Started once per process
 * from the API route module; no-op until CREDIT_STORE_ADDRESS is configured.
 */
import { syncPurchasesFromChain, type CommerceEnv } from "../worker/commerce-api";

let started = false;

export function startChainWatcher(environment: () => CommerceEnv) {
  if (started || typeof setInterval !== "function") return;
  started = true;
  const interval = Math.max(10_000, Number(process.env.CHAIN_SYNC_INTERVAL_MS ?? 30_000));
  let running = false;
  const tick = async () => {
    if (running) return;
    running = true;
    try {
      const env = environment();
      if (!env.CREDIT_STORE_ADDRESS && !env.USDC_CHECKOUT_ADDRESS && !process.env.CREDIT_STORE_ADDRESS) return;
      const result = await syncPurchasesFromChain(env);
      if (result.credited > 0) console.log(`[chain-watcher] credited ${result.credited} purchase(s) from blocks ${result.from}-${result.to}`);
      else if (!result.scanned && result.reason && result.reason !== "no contract") console.warn(`[chain-watcher] ${result.reason}`);
      if (env.USDC_CHECKOUT_ADDRESS) {
        const usdc = await syncPurchasesFromChain(env, "usdc");
        if (usdc.credited > 0) console.log(`[chain-watcher] credited ${usdc.credited} USDC purchase(s) from blocks ${usdc.from}-${usdc.to}`);
        else if (!usdc.scanned && usdc.reason && usdc.reason !== "no contract") console.warn(`[chain-watcher] USDC: ${usdc.reason}`);
      }
    } catch (cause) {
      console.warn("[chain-watcher] failed", cause instanceof Error ? cause.message : cause);
    } finally {
      running = false;
    }
  };
  const timer = setInterval(() => { void tick(); }, interval);
  if (typeof timer === "object" && timer && "unref" in timer) (timer as { unref(): void }).unref();
  setTimeout(() => { void tick(); }, 5_000);
}
