/**
 * Self-hosted database adapter.
 *
 * Exposes the small D1-style surface `worker/commerce-api.ts` relies on
 * (prepare → bind → first/all/run, plus batch) on top of Node's built-in
 * `node:sqlite`, so the same worker code runs unchanged on an AWS EC2 / any
 * Node 22.13+ host. Migrations in `migrations/*.sql` are applied by
 * `scripts/migrate.mjs`.
 */
import { DatabaseSync, type StatementSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import path from "node:path";

type StatementResult = { success: boolean; meta: { changes: number } };

export type PreparedStatement = {
  bind(...values: unknown[]): PreparedStatement;
  first<T = Record<string, unknown>>(): Promise<T | null>;
  all<T = Record<string, unknown>>(): Promise<{ results: T[] }>;
  run(): Promise<StatementResult>;
  /** Synchronous variant used inside `batch` so no other request can interleave. */
  runSync(): StatementResult;
};

export type SqliteDatabase = {
  prepare(query: string): PreparedStatement;
  batch(statements: PreparedStatement[]): Promise<StatementResult[]>;
  raw: DatabaseSync;
};

type Bindable = null | number | bigint | string | Uint8Array;

function toBindable(value: unknown): Bindable {
  if (value === undefined || value === null) return null;
  if (typeof value === "boolean") return value ? 1 : 0;
  if (typeof value === "number" || typeof value === "bigint" || typeof value === "string") return value;
  if (value instanceof Uint8Array) return value;
  return JSON.stringify(value);
}

function statement(db: DatabaseSync, query: string, execute: <T>(fn: () => T) => T): PreparedStatement {
  let bindings: Bindable[] = [];
  let compiled: StatementSync | null = null;
  const prepared = () => (compiled ??= db.prepare(query));
  const self: PreparedStatement = {
    bind(...values) {
      bindings = values.map(toBindable);
      return self;
    },
    async first<T>() {
      return execute(() => (prepared().get(...bindings) as T | undefined) ?? null);
    },
    async all<T>() {
      return execute(() => ({ results: prepared().all(...bindings) as T[] }));
    },
    runSync() {
      return execute(() => {
        const result = prepared().run(...bindings);
        return { success: true, meta: { changes: Number(result.changes) } };
      });
    },
    async run() {
      return self.runSync();
    },
  };
  return self;
}

export function openDatabase(file: string): SqliteDatabase {
  if (file !== ":memory:") mkdirSync(path.dirname(file), { recursive: true });
  const raw = new DatabaseSync(file);
  raw.exec("PRAGMA journal_mode = WAL;");
  raw.exec("PRAGMA foreign_keys = ON;");
  raw.exec("PRAGMA busy_timeout = 5000;");
  const execute = <T,>(fn: () => T) => fn();
  return {
    raw,
    prepare(query) {
      return statement(raw, query, execute);
    },
    async batch(statements) {
      // Entirely synchronous between BEGIN and COMMIT: a single shared
      // connection must never let another request's statement slip inside.
      raw.exec("BEGIN IMMEDIATE;");
      try {
        const results = statements.map((item) => item.runSync());
        raw.exec("COMMIT;");
        return results;
      } catch (cause) {
        raw.exec("ROLLBACK;");
        throw cause;
      }
    },
  };
}

let shared: SqliteDatabase | null = null;

/** Process-wide database handle, path from `DATABASE_PATH` (default ./data/xuanyuan.sqlite). */
export function sharedDatabase() {
  if (!shared) shared = openDatabase(process.env.DATABASE_PATH?.trim() || path.resolve(process.cwd(), "data", "xuanyuan.sqlite"));
  return shared;
}
