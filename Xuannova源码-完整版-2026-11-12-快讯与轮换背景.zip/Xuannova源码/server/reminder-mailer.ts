// Sends the opt-in daily reminder e-mails (Node/AWS deployment). Runs every 10 minutes; each member
// gets at most one e-mail per local day, from 08:00 in their time zone. Needs RESEND_API_KEY and MAIL_FROM.
import { Solar } from "lunar-javascript";
import { sendDailyReminders, type CommerceEnv } from "../worker/commerce-api";
import { translateChartText, type TermLocale } from "../app/metaphysics/terms";

let started = false;

/** Chinese almanac line for the e-mail: day pillar, what the almanac lists as suitable and to avoid. */
function almanacLine(date: string) {
  try {
    const [year, month, day] = date.split("-").map(Number);
    const lunar = Solar.fromYmd(year, month, day).getLunar();
    const yi = lunar.getDayYi().slice(0, 6).join("、");
    const ji = lunar.getDayJi().slice(0, 6).join("、");
    return `${date} · ${lunar.getDayInGanZhi()}日 · 宜：${yi || "—"} · 忌：${ji || "—"}（传统黄历，仅供文化参考）`;
  } catch { return null; }
}

/** The solar term that begins on this date (in the member's language), if any. */
export function solarTermOn(date: string, locale: string) {
  try {
    const [year, month, day] = date.split("-").map(Number);
    const term = Solar.fromYmd(year, month, day).getLunar().getJieQi() as string;
    if (!term) return null;
    return translateChartText(term, locale as TermLocale) ?? term;
  } catch { return null; }
}

export function startReminderMailer(environment: () => CommerceEnv) {
  if (started || typeof setInterval !== "function") return;
  started = true;
  let running = false;
  const tick = async () => {
    if (running) return;
    running = true;
    try {
      const result = await sendDailyReminders(environment(), { almanac: almanacLine, solarTerm: solarTermOn });
      if (result.sent) console.log(`[reminders] sent ${result.sent} daily reminder(s)`);
    } catch (cause) {
      console.warn("[reminders] failed", cause instanceof Error ? cause.message : cause);
    } finally { running = false; }
  };
  const timer = setInterval(() => { void tick(); }, 10 * 60_000);
  if (typeof timer === "object" && timer && "unref" in timer) (timer as { unref(): void }).unref();
}
