// 玄诺快讯 automatic writer (Node/AWS deployment). Checks every 10 minutes; the settings in the admin page decide
// whether it runs, how often it looks for news, and whether new items go live at once or wait as drafts.
// Needs DEEPSEEK_API_KEY. Uses no credits of any member.
import { Solar } from "lunar-javascript";
import type { CommerceEnv } from "../worker/commerce-api";
import { runFlashAutomation, type FlashDatabase } from "../worker/flash";

let started = false;

/** The solar term we are in on this date, e.g. 立冬. */
export function currentSolarTerm(date: string) {
  try {
    const [year, month, day] = date.split("-").map(Number);
    return (Solar.fromYmd(year, month, day).getLunar().getPrevJieQi(true) as { getName(): string }).getName();
  } catch { return null; }
}

export function startFlashRunner(environment: () => CommerceEnv) {
  if (started || typeof setInterval !== "function") return;
  started = true;
  let running = false;
  const tick = async () => {
    if (running) return;
    const env = environment();
    if (!env.DB || !env.DEEPSEEK_API_KEY?.trim()) return;
    running = true;
    try {
      const report = await runFlashAutomation(env.DB as unknown as FlashDatabase, env, { now: new Date(), solarTerm: currentSolarTerm });
      if (report.added.length || report.wisdom) console.log(`[flash] added ${report.added.length} item(s)${report.wisdom ? " + quote of the day" : ""}`);
      if (report.errors.length) console.warn(`[flash] ${report.errors.slice(0, 3).join(" | ")}`);
    } catch (cause) {
      console.warn("[flash] failed", cause instanceof Error ? cause.message : cause);
    } finally { running = false; }
  };
  const first = setTimeout(() => { void tick(); }, 90_000);
  const timer = setInterval(() => { void tick(); }, 10 * 60_000);
  for (const handle of [first, timer]) if (typeof handle === "object" && handle && "unref" in handle) (handle as { unref(): void }).unref();
}
