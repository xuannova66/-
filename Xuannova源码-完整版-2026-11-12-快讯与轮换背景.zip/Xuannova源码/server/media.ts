// Uploaded lecture videos on the Node server: administrators upload, members stream with Range support.
// Files live in MEDIA_DIR (default ./data/media) and are never served without the access check.
import { createReadStream, createWriteStream, mkdirSync, statSync, unlinkSync } from "node:fs";
import path from "node:path";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { isAdministratorRequest, lectureMediaAccess, type CommerceEnv } from "../worker/commerce-api";

const TYPES: Record<string, string> = { mp4: "video/mp4", m4v: "video/mp4", webm: "video/webm", mov: "video/quicktime" };
const mediaDir = () => path.resolve(process.env.MEDIA_DIR?.trim() || path.join(process.cwd(), "data", "media"));
const maxBytes = () => Math.max(1, Number(process.env.MEDIA_MAX_MB ?? "2048")) * 1024 * 1024;
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json; charset=utf-8" } });

/** POST /api/admin/lectures/upload — raw file body; header x-file-name gives the original name (for its extension). */
export async function handleMediaUpload(request: Request, env: CommerceEnv) {
  if (!(await isAdministratorRequest(request, env))) return json({ error: "Administrator access required" }, 403);
  const extension = (request.headers.get("x-file-name") ?? "").toLowerCase().split(".").pop() ?? "";
  if (!TYPES[extension]) return json({ error: "Upload an MP4, WebM or MOV video" }, 400);
  const declared = Number(request.headers.get("content-length") ?? "0");
  if (declared > maxBytes()) return json({ error: "The video is larger than the upload limit" }, 413);
  if (!request.body) return json({ error: "Empty upload" }, 400);
  mkdirSync(mediaDir(), { recursive: true });
  const file = `${crypto.randomUUID()}.${extension}`;
  const target = path.join(mediaDir(), file);
  let received = 0;
  const limit = maxBytes();
  try {
    const source = Readable.fromWeb(request.body as import("node:stream/web").ReadableStream<Uint8Array>);
    source.on("data", (chunk: Buffer) => { received += chunk.length; if (received > limit) source.destroy(new Error("too large")); });
    await pipeline(source, createWriteStream(target));
  } catch {
    try { unlinkSync(target); } catch { /* nothing written */ }
    return json({ error: received > limit ? "The video is larger than the upload limit" : "Upload failed" }, received > limit ? 413 : 500);
  }
  return json({ file, bytes: received }, 201);
}

/** GET /api/media/<file> — streams an uploaded lecture video (HTTP Range for seeking). */
export async function handleMediaStream(request: Request, env: CommerceEnv, file: string) {
  const access = await lectureMediaAccess(request, env, file);
  if (access === "missing") return json({ error: "Not found" }, 404);
  if (access === "signin") return json({ error: "Sign in to watch this lecture", code: "SIGN_IN" }, 401);
  const filePath = path.join(mediaDir(), file);
  let size: number;
  try { size = statSync(filePath).size; } catch { return json({ error: "Not found" }, 404); }
  const type = TYPES[file.split(".").pop() ?? ""] ?? "application/octet-stream";
  const headers: Record<string, string> = { "content-type": type, "accept-ranges": "bytes", "cache-control": "private, max-age=3600", "x-content-type-options": "nosniff" };
  const range = /^bytes=(\d*)-(\d*)$/.exec(request.headers.get("range") ?? "");
  if (range && (range[1] || range[2])) {
    const start = range[1] ? Number(range[1]) : Math.max(0, size - Number(range[2]));
    const end = range[1] && range[2] ? Math.min(Number(range[2]), size - 1) : size - 1;
    if (start >= size || start > end) return new Response(null, { status: 416, headers: { "content-range": `bytes */${size}` } });
    const stream = Readable.toWeb(createReadStream(filePath, { start, end })) as unknown as ReadableStream;
    return new Response(stream, { status: 206, headers: { ...headers, "content-range": `bytes ${start}-${end}/${size}`, "content-length": String(end - start + 1) } });
  }
  const stream = Readable.toWeb(createReadStream(filePath)) as unknown as ReadableStream;
  return new Response(stream, { status: 200, headers: { ...headers, "content-length": String(size) } });
}
