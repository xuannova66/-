#!/usr/bin/env node
/**
 * Apply migrations/*.sql to the self-hosted SQLite database.
 *
 *   DATABASE_PATH=./data/xuanyuan.sqlite node scripts/migrate.mjs
 *
 * Each file runs once, inside a transaction, and is recorded in `_migrations`.
 */
import { DatabaseSync } from "node:sqlite";
import { mkdirSync, readdirSync, readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const file = process.env.DATABASE_PATH?.trim() || path.join(root, "data", "xuanyuan.sqlite");
const migrationsDir = path.join(root, "migrations");

mkdirSync(path.dirname(file), { recursive: true });
const db = new DatabaseSync(file);
db.exec("PRAGMA journal_mode = WAL;");
db.exec("PRAGMA foreign_keys = ON;");
db.exec("CREATE TABLE IF NOT EXISTS _migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL);");

const applied = new Set(db.prepare("SELECT name FROM _migrations").all().map((row) => row.name));
// Study-site migrations were renumbered after the payment migrations 0016–0019 (2026-11-06).
// A database that already ran them under the old name records the new name instead of running them again.
const RENAMED = {
  "0020_library_shelf.sql": "0017_library_shelf.sql",
  "0021_member_library.sql": "0018_member_library.sql",
  "0022_free_full_reading.sql": "0019_free_full_reading.sql",
  "0023_vision_usage.sql": "0020_vision_usage.sql",
};
for (const [current, previous] of Object.entries(RENAMED)) {
  if (applied.has(previous) && !applied.has(current)) {
    db.prepare("INSERT INTO _migrations (name, applied_at) VALUES (?, ?)").run(current, new Date().toISOString());
    applied.add(current);
    console.log(`recorded ${current} (already applied as ${previous})`);
  }
}
const files = readdirSync(migrationsDir).filter((name) => name.endsWith(".sql")).sort();

let count = 0;
for (const name of files) {
  if (applied.has(name)) continue;
  const sql = readFileSync(path.join(migrationsDir, name), "utf8");
  const rebuildOrders = name === "0018_payment_order_event_identity.sql" || name === "0025_payment_networks.sql";
  if (rebuildOrders) db.exec("PRAGMA foreign_keys = OFF;");
  db.exec("BEGIN;");
  try {
    db.exec(sql);
    if (rebuildOrders && db.prepare("PRAGMA foreign_key_check").all().length) throw new Error("foreign key check failed");
    db.prepare("INSERT INTO _migrations (name, applied_at) VALUES (?, ?)").run(name, new Date().toISOString());
    db.exec("COMMIT;");
    if (rebuildOrders) db.exec("PRAGMA foreign_keys = ON;");
    count += 1;
    console.log(`applied ${name}`);
  } catch (cause) {
    db.exec("ROLLBACK;");
    console.error(`failed ${name}: ${cause instanceof Error ? cause.message : cause}`);
    process.exit(1);
  }
}
console.log(count === 0 ? `database up to date (${file})` : `${count} migration(s) applied to ${file}`);
