#!/usr/bin/env python3
"""Build the on-site reading texts of the classics library.

Input : a sparse checkout of github.com/garychowcmu/daizhigev20 (public-domain classical texts) and the
        OpenCC dictionaries (Apache-2.0) for Simplified→Traditional conversion.
Output: public/library/<id>/index-<script>.json  (chapter titles → part file)
        public/library/<id>/<script>-<n>.json    (~120 KB parts holding whole chapters)
Usage : python3 scripts/build-library-texts.py <daizhige dir> <opencc dir> <out dir>
"""
import json, os, re, sys

SOURCES = {
    "zhouyi": "易藏/易经/周易.txt", "xici": "易藏/易经/周易.txt", "wuxingdayi": "易藏/术数/五行大义.txt",
    "huainanzi": "子藏/诸子/淮南子.txt", "yuanhai": "易藏/术数/渊海子平.txt",
    "sanming": "易藏/术数/三命通会.txt", "ditiansui": "易藏/术数/滴天髓阐微.txt", "zipingzhenquan": "易藏/术数/子平真诠评注.txt",
    "qiongtong": "易藏/术数/穷通宝鉴.txt", "ziweiquanshu": "道藏/正统道藏续道藏/紫微斗数.txt", "qimentongzong": "易藏/术数/奇门遁甲统宗.txt",
    "qimenbaojian": "易藏/术数/奇门宝鉴御定.txt", "bushizhengzong": "易藏/术数/卜筮正宗.txt", "zengshanbuyi": "易藏/术数/增删卜易.txt",
    "huozhulin": "易藏/术数/火珠林.txt", "yiyin": "易藏/术数/易隐.txt", "liurendaquan": "易藏/术数/六壬大全.txt", "bifafu": "易藏/术数/六壬大全.txt",
    "liurenshending": "易藏/术数/六壬神定经.txt", "xingxuedacheng": "易藏/术数/星学大成.txt",
    "xiejibianfang": "易藏/术数/钦定协纪辨方书.txt", "zhougong": "易藏/术数/周公解梦.txt", "caigentan": "儒藏/修身治家/菜根谭.txt",
}
# Works that live inside a larger text: open the reader at the chapter whose title contains this.
# (太微赋, 斗数骨髓赋, 烟波钓叟歌 and 果老星宗 are not in these source texts; they keep their outside links.)
START_AT = {"xici": "系辞", "bifafu": "毕法"}
MAX_CHAPTER = 12_000
PART_BYTES = 120_000

def load_opencc(base):
    chars, phrases = {}, {}
    for name, target in (("STCharacters.txt", chars), ("STPhrases.txt", phrases)):
        for line in open(os.path.join(base, "data/dictionary", name), encoding="utf8"):
            if "\t" in line:
                key, value = line.rstrip("\n").split("\t", 1)
                target[key] = value.split(" ")[0]
    variants = {}
    for line in open(os.path.join(base, "data/dictionary", "TWVariants.txt"), encoding="utf8"):
        if "\t" in line:
            key, value = line.rstrip("\n").split("\t", 1)
            if len(key) == 1: variants[key] = value.split(" ")[0]
    longest = max(len(k) for k in phrases)
    def convert(text):
        out, i = [], 0
        while i < len(text):
            for size in range(min(longest, len(text) - i), 1, -1):
                piece = text[i:i + size]
                if piece in phrases:
                    out.append(phrases[piece]); i += size; break
            else:
                out.append(chars.get(text[i], text[i])); i += 1
        # Taiwan-standard character forms (為, 裏 → 裡 …), as readers of zh-Hant expect.
        return "".join(variants.get(ch, ch) for ch in "".join(out))
    return convert

# Modern editorial notes added by the digitiser are not part of the classical text.
DROP_LINES = [re.compile(r"^《滴天髓》为中国传统命理学中最重要的典籍")]
# Example charts ("甲寅 癸丑 壬子 辛亥") are body text, not headings.
GANZHI_ROW = re.compile(r"^[甲乙丙丁戊己庚辛壬癸子丑寅卯辰巳午未申酉戌亥乾坤造运\s·　：:]+$")
HEADING_BODY = re.compile(r"^[^，。；！？：,;!?]{1,26}$")

def is_heading(line):
    # Short lines without sentence punctuation; an enumeration mark (一、 / 1.) is allowed only at the start.
    if not HEADING_BODY.match(line) or GANZHI_ROW.match(line):
        return False
    comma = line.find("、")
    return comma == -1 or comma <= 4

def chapters_of(text):
    lines = [line.strip().replace("　", "") for line in text.replace("\r", "").split("\n")]
    lines = [line for line in lines if line and not any(pattern.search(line) for pattern in DROP_LINES)]
    chapters, title, body = [], None, []
    for line in lines:
        if is_heading(line) and not line.isdigit():
            if body or title:
                chapters.append([title or "", body])
            title, body = line, []
        else:
            body.append(line)
    if body or title:
        chapters.append([title or "", body])
    # A heading with no body is joined to the next title ("卷一" + "论五行" → "卷一 · 论五行") when short;
    # runs of empty headings (a printed table of contents) are dropped instead.
    merged = []
    for chapter_title, chapter_body in chapters:
        if merged and not merged[-1][1]:
            joined = f"{merged[-1][0]} · {chapter_title}".strip(" ·")
            merged[-1] = [joined if len(joined) <= 30 else chapter_title, chapter_body]
        else:
            merged.append([chapter_title, chapter_body])
    # Very small chapters are joined so the table of contents stays readable.
    result = []
    for chapter_title, chapter_body in merged:
        size = sum(len(line) for line in chapter_body)
        if result and size < 120 and len(result[-1]["text"]) < 6000:
            result[-1]["text"] += "\n" + (chapter_title + "\n" if chapter_title else "") + "\n".join(chapter_body)
        else:
            result.append({"title": chapter_title or f"{len(result) + 1}", "text": "\n".join(chapter_body)})
    # Long chapters are cut at line breaks into numbered pieces of at most MAX_CHAPTER characters.
    final = []
    for chapter in result:
        if len(chapter["text"]) <= MAX_CHAPTER:
            final.append(chapter); continue
        piece, count = [], 1
        for line in chapter["text"].split("\n"):
            if piece and sum(len(x) for x in piece) + len(line) > MAX_CHAPTER:
                final.append({"title": f"{chapter['title']} ({count})", "text": "\n".join(piece)}); piece, count = [], count + 1
            piece.append(line)
        if piece:
            final.append({"title": f"{chapter['title']} ({count})", "text": "\n".join(piece)})
    return [chapter for chapter in final if chapter["text"].strip() or chapter["title"]]

def write_book(out_dir, book_id, chapters, script):
    os.makedirs(os.path.join(out_dir, book_id), exist_ok=True)
    parts, current, size, index = [], [], 0, []
    for number, chapter in enumerate(chapters):
        encoded = len(json.dumps(chapter, ensure_ascii=False).encode("utf8"))
        if current and size + encoded > PART_BYTES:
            parts.append(current); current, size = [], 0
        current.append(chapter); size += encoded
        index.append({"title": chapter["title"][:60], "part": len(parts), "chars": len(chapter["text"])})
    if current:
        parts.append(current)
    for number, part in enumerate(parts):
        with open(os.path.join(out_dir, book_id, f"{script}-{number}.json"), "w", encoding="utf8") as handle:
            json.dump(part, handle, ensure_ascii=False, separators=(",", ":"))
    return index, len(parts)

def main():
    source_dir, opencc_dir, out_dir = sys.argv[1:4]
    to_traditional = load_opencc(opencc_dir)
    cache, manifest = {}, {}
    for book_id, path in SOURCES.items():
        if path not in cache:
            cache[path] = chapters_of(open(os.path.join(source_dir, path), encoding="utf8").read())
        chapters = cache[path]
        start = 0
        if book_id in START_AT:
            key = START_AT[book_id]
            start = next((i for i, c in enumerate(chapters) if c["title"] == key), next((i for i, c in enumerate(chapters) if i > 0 and key in c["title"]), 0))
        directory = next((other for other, other_path in SOURCES.items() if other_path == path), book_id)
        entry = {"source": f"daizhigev20/{path}", "start": start, "dir": directory}
        if directory != book_id:
            manifest[book_id] = {**manifest[directory], "start": start, "dir": directory}
            print(book_id, "→", directory, "start", start)
            continue
        for script in ("zh-Hans", "zh-Hant"):
            data = chapters if script == "zh-Hans" else [{"title": to_traditional(c["title"]), "text": to_traditional(c["text"])} for c in chapters]
            index, parts = write_book(out_dir, book_id, data, script)
            with open(os.path.join(out_dir, book_id, f"index-{script}.json"), "w", encoding="utf8") as handle:
                json.dump({"chapters": index, "parts": parts, "start": start, "source": entry["source"]}, handle, ensure_ascii=False, separators=(",", ":"))
            entry[script] = {"chapters": len(index), "parts": parts}
        manifest[book_id] = entry
        print(book_id, entry["zh-Hans"]["chapters"], "chapters", entry["zh-Hans"]["parts"], "parts", "start", start)
    with open(os.path.join(out_dir, "manifest.json"), "w", encoding="utf8") as handle:
        json.dump(manifest, handle, ensure_ascii=False, indent=1)

if __name__ == "__main__":
    main()
