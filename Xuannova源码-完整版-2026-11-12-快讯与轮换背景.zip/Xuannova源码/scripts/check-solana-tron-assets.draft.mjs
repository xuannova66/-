/** Read-only metadata checks; no signing, swapping, transfers or token enablement.
 * A mint address/decimal match does not establish authenticity or liquidity. */
import {readFileSync} from "node:fs";
const inventory=JSON.parse(readFileSync(new URL("../config/multichain-assets.draft.json",import.meta.url),"utf8"));
const sol=process.env.XUANNOVA_SOL_READONLY_RPC,tron=process.env.XUANNOVA_TRON_READONLY_RPC;
if(!sol?.startsWith("https://")||!tron?.startsWith("https://"))throw Error("Set both trusted HTTPS RPC URLs");
async function post(url,body){const res=await fetch(url,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(body),signal:AbortSignal.timeout(15000)});if(!res.ok)throw Error(`RPC_HTTP_${res.status}`);return res.json();}
async function solCall(method,params=[]){const body=await post(sol,{jsonrpc:"2.0",id:1,method,params});if(body.error||!("result" in body))throw Error("SOL_RPC_ERROR");return body.result;}
const genesis=await solCall("getGenesisHash");if(genesis!=="5eykt4UsFv8P8NJdTREpY1vzqKqZKvdpKuc147dw2N9d")throw Error("WRONG_SOLANA_CHAIN");
const assets=inventory.chains.solana.assets,mints=assets.map(x=>x.mint??x.wrappedMint);
const accounts=await solCall("getMultipleAccounts",[mints,{encoding:"jsonParsed",commitment:"finalized"}]);
console.log(JSON.stringify({chain:"solana-mainnet",slot:accounts.context?.slot,scope:"read-only metadata only"}));
for(let i=0;i<assets.length;i++){const account=accounts.value?.[i],parsed=account?.data?.parsed;console.log(JSON.stringify({symbol:assets[i].symbol,mint:mints[i],status:parsed?.type==="mint"?"mint_read":"unavailable",program:account?.owner??null,decimals:parsed?.info?.decimals??null}));}
console.log(JSON.stringify({chain:"tron",scope:"readonly contract calls; RPC network is trusted and not independently established"}));
for(const asset of inventory.chains.tron.assets){const address=asset.native?asset.wrappedAddress:asset.address;try{const result=await post(`${tron}/walletsolidity/triggerconstantcontract`,{owner_address:inventory.chains.tron.recipient,contract_address:address,function_selector:"decimals()",visible:true});const value=result.constant_result?.[0];if(!result.result?.result||!value||!/^[a-fA-F0-9]+$/.test(value))throw Error("INVALID_RESPONSE");console.log(JSON.stringify({symbol:asset.symbol,address,decimals:Number(BigInt(`0x${value}`)),status:"contract_read"}));}catch(error){console.log(JSON.stringify({symbol:asset.symbol,address,status:"rpc_unavailable",reason:error instanceof Error?error.message:"unknown"}));}}
