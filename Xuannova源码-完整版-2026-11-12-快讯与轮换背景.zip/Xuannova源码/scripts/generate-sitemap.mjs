/**
 * Writes public/sitemap.xml with every public URL in all seven languages and hreflang links.
 * Run after adding routes:  node scripts/generate-sitemap.mjs
 */
import { writeFileSync } from "node:fs";

const SITE = "https://xuannova.com";
const LOCALES = ["en", "zh-Hans", "zh-Hant", "ja", "ko", "vi", "th"];
const ROUTES = ["home", "bazi", "detail", "ziwei", "qizheng", "compatibility", "hecan", "liuyao", "qimen", "daliuren", "meihua", "jinkoujue", "heluo", "tieban", "taiyi", "zhuzhai", "wenshi", "mirror", "daily", "toolkit", "library", "courses", "guide", "almanac", "xiangshu", "zeri", "cezi", "flash"];
const pathFor = (locale, route) => { const prefix = locale === "en" ? "" : `/${locale.toLowerCase()}`; return route === "home" ? (prefix || "/") : `${prefix}/${route}`; };
const today = new Date().toISOString().slice(0, 10);
const entries = ROUTES.flatMap((route) => LOCALES.map((locale) => {
  const alternates = LOCALES.map((code) => `    <xhtml:link rel="alternate" hreflang="${code}" href="${SITE}${pathFor(code, route)}"/>`).join("\n");
  return `  <url>\n    <loc>${SITE}${pathFor(locale, route)}</loc>\n    <lastmod>${today}</lastmod>\n${alternates}\n    <xhtml:link rel="alternate" hreflang="x-default" href="${SITE}${pathFor("en", route)}"/>\n  </url>`;
}));
writeFileSync(new URL("../public/sitemap.xml", import.meta.url), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">\n${entries.join("\n")}\n</urlset>\n`);
console.log(`sitemap: ${entries.length} URLs`);
