/** Read-only BSC mainnet snapshot; never signs/sends or enables any asset.
 * A router quote does not prove token identity, non-tax behavior, actual
 * execution, fair price, or availability on other router versions.
 */
import {readFileSync} from "node:fs";
import {createPublicClient,http,getAddress,parseAbi,formatUnits,parseUnits} from "viem";
import {bsc,mainnet} from "viem/chains";

const inventory=JSON.parse(readFileSync(new URL("../config/multichain-assets.draft.json",import.meta.url),"utf8"));
const target=process.env.XUANNOVA_AUDIT_CHAIN??"bsc";
if(target!=="bsc"&&target!=="ethereum")throw new Error("UNSUPPORTED_CHAIN");
const chain=target==="bsc"?bsc:mainnet,rpc=process.env.XUANNOVA_READONLY_RPC;
if(!rpc || !/^https:\/\//.test(rpc))throw new Error("Set XUANNOVA_READONLY_RPC to a trusted HTTPS mainnet RPC");
const client=createPublicClient({chain,transport:http(rpc,{timeout:12000,retryCount:1})});
const erc=parseAbi(["function decimals() view returns(uint8)"]),routerAbi=parseAbi(["function getAmountsIn(uint256,address[]) view returns(uint256[])"]);
const router=getAddress(target==="bsc"?"0x10ED43C718714eb63d5aA57B78B54704E256024E":"0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D"), stable=getAddress(target==="bsc"?"0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d":"0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"),wrapped=getAddress(target==="bsc"?"0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c":"0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2");
const settlementDecimals=target==="bsc"?18:6;
if(await client.getChainId()!==chain.id)throw new Error("WRONG_CHAIN");
const blockNumber=await client.getBlockNumber();
const candidates=inventory.chains[target].assets;
console.log(JSON.stringify({chain:chain.id,block:blockNumber.toString(),router,settlement:stable,scope:"read-only V2 snapshot; not identity, tax, fair-price or execution verification"}));
async function inspect(asset){
 if(asset.symbol==="USDC")return {symbol:asset.symbol,status:"settlement_asset",note:"identity and execution not verified by this check"};
 if(!asset.address&&!asset.native)return {symbol:asset.symbol,status:"address_missing"};
 const address=asset.native?wrapped:getAddress(asset.address.toLowerCase());let decimals=18;
 try{
  const code=await client.getBytecode({address,blockNumber});if(!code||code==="0x")return {symbol:asset.symbol,status:"no_contract_code"};
  decimals=await client.readContract({address,abi:erc,functionName:"decimals",blockNumber});
 }catch{return {symbol:asset.symbol,status:"metadata_rpc_failure"};}
 const paths=[[address,stable],...(address===wrapped?[]:[[address,wrapped,stable]])];
 const rows=[];
 for(const dollars of ["4.99","39.90"]){
  const amount=parseUnits(dollars,settlementDecimals);
  let best=null,errors=0;
  for(const path of paths){try{const values=await client.readContract({address:router,abi:routerAbi,functionName:"getAmountsIn",args:[amount,path],blockNumber});if(values.length!==path.length||values.at(-1)!==amount||values[0]<=0n)throw Error("bad result");if(!best||values[0]<best.input)best={input:values[0],hops:path.length-1};}catch{errors++;}}
  rows.push({targetUsdc:dollars,status:best?"quoted":"unavailable_or_rpc_error",...(best?{input:formatUnits(best.input,decimals),hops:best.hops}:{}),errors});
 }
 return {symbol:asset.symbol,address,decimals,expectedDecimals:asset.decimals??null,decimalsMatch:asset.native||asset.decimals===undefined?null:decimals===asset.decimals,quotes:rows};
}
for(let i=0;i<candidates.length;i+=3){const results=await Promise.all(candidates.slice(i,i+3).map(inspect));for(const result of results)console.log(JSON.stringify(result));}
