/** Read-only readiness check. No key, wallet, approval or transaction is used. */
import { createPublicClient, fallback, http, parseAbi, parseUnits, formatUnits, getAddress } from "viem";
const expectedChainId = 56;
const usdc = "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d";
const usdt = "0x55d398326f99059fF775485246999027B3197955";
const aster = "0x000Ae314E2A2172a039B26378814C252734f556A";
const wbnb = "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c";
const router = "0x10ED43C718714eb63d5aA57B78B54704E256024E";
const client = createPublicClient({ transport: fallback(["https://bsc-dataseed.binance.org", "https://bsc-dataseed1.bnbchain.org"].map((url) => http(url, { timeout: 7000, retryCount: 0 }))) });
const abi = parseAbi(["function decimals() view returns (uint8)", "function WETH() view returns (address)", "function getAmountsIn(uint256,address[]) view returns (uint256[])"]);
const chain = await client.getChainId();
if (chain !== expectedChainId) throw new Error(`Wrong network: ${chain}`);
for (const [label, address] of [["USDC", usdc], ["USDT", usdt], ["ASTER", aster], ["router", router]]) {
  const code = await client.getCode({ address });
  if (!code || code === "0x") throw new Error(`${label} has no code on BSC`);
  if (label !== "router") {
    const decimals = await client.readContract({ address, abi, functionName: "decimals" });
    if (decimals !== 18) throw new Error(`${label}: expected 18 decimals, got ${decimals}`);
  }
}
if (getAddress(await client.readContract({ address: router, abi, functionName: "WETH" })) !== getAddress(wbnb)) throw new Error("Unexpected wrapped BNB on router");
const output = parseUnits("4.99", 18);
for (const [label, paths] of [["BNB", [[wbnb, usdc], [wbnb, usdt, usdc]]], ["USDT", [[usdt, usdc], [usdt, wbnb, usdc]]], ["ASTER", [[aster, usdc], [aster, wbnb, usdc], [aster, usdt, usdc]]]]) {
  let routes = 0;
  for (const path of paths) {
    try {
      const amounts = await client.readContract({ address: router, abi, functionName: "getAmountsIn", args: [output, path] });
      console.log(`${label}: ${path.length === 2 ? "direct" : `via ${getAddress(path[1]) === getAddress(wbnb) ? "WBNB" : "USDT"}`} = ${formatUnits(amounts[0], 18)} (read-only estimate)`);
      routes++;
    } catch { console.log(`${label}: route ${path.join(" → ")} unavailable`); }
  }
  if (!routes) { console.error(`${label}: no supported route found`); process.exitCode = 1; }
}
