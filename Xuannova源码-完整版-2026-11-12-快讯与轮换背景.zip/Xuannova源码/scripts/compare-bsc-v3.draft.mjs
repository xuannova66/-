/** Read-only same-block V2/V3 direct quotes. Not a price oracle or trade test. */
import { createPublicClient, http, getAddress, parseAbi, parseUnits, formatUnits, encodeFunctionData, decodeFunctionResult } from 'viem';
import { bsc } from 'viem/chains';

const rpc = process.env.XUANNOVA_READONLY_RPC;
if (!rpc?.startsWith('https://')) throw Error('TRUSTED_HTTPS_RPC_REQUIRED');
const client = createPublicClient({ chain: bsc, transport: http(rpc, { timeout: 15000, retryCount: 1 }) });
const addr = s => getAddress(s.toLowerCase());
const usdc = addr('0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d');
const router = addr('0x10ED43C718714eb63d5aA57B78B54704E256024E');
const quoter = addr('0xB048Bbc1Ee6b733FFfCFb9e9CeF7375518e25997');
const factory = addr('0x0BFbCF9fa4f9C56B0F40a671Ad40E0805A091865');
const poolAbi = parseAbi(['function getPool(address,address,uint24) view returns (address)']);
const v2Abi = parseAbi(['function getAmountsIn(uint256,address[]) view returns (uint256[])']);
const quoteAbi = parseAbi(['function quoteExactOutputSingle((address tokenIn,address tokenOut,uint256 amount,uint24 fee,uint160 sqrtPriceLimitX96) params) returns (uint256 amountIn,uint160 sqrtPriceX96After,uint32 initializedTicksCrossed,uint256 gasEstimate)']);
const decimalsAbi = parseAbi(['function decimals() view returns (uint8)']);
const tokens = {
  BNB: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
  USDT: '0x55d398326f99059fF775485246999027B3197955',
  CAKE: '0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82',
  BTCB: '0x7130d2a12b9bcbfae4f2634d864a1ee1ce3ead9c',
  LINK: '0xf8a0bf9cf54bb92f17374d9e9a321e6a111a51bd',
  ASTER: '0x000Ae314E2A2172a039B26378814C252734f556A',
};
if (await client.getChainId() !== 56) throw Error('WRONG_CHAIN');
const blockNumber = await client.getBlockNumber();
console.log(JSON.stringify({ chain: 56, block: String(blockNumber), scope: 'Pancake direct V2 versus direct V3; quotes are not oracle or execution' }));
for (const [symbol, raw] of Object.entries(tokens)) {
  const token = addr(raw);
  const decimals = await client.readContract({ address: token, abi: decimalsAbi, functionName: 'decimals', blockNumber });
  const pools = [];
  for (const fee of [100, 500, 2500, 10000]) {
    try {
      const pool = await client.readContract({ address: factory, abi: poolAbi, functionName: 'getPool', args: [token, usdc, fee], blockNumber });
      if (pool !== '0x0000000000000000000000000000000000000000') pools.push(fee);
    } catch { /* unavailable is not evidence of no pool */ }
  }
  const rows = [];
  for (const value of ['4.99', '39.90']) {
    const amount = parseUnits(value, 18);
    let v2 = null, best = null, bestFee = null;
    try { [v2] = await client.readContract({ address: router, abi: v2Abi, functionName: 'getAmountsIn', args: [amount, [token, usdc]], blockNumber }); } catch {}
    for (const fee of pools) {
      try {
        const data = encodeFunctionData({ abi: quoteAbi, functionName: 'quoteExactOutputSingle', args: [{ tokenIn: token, tokenOut: usdc, amount, fee, sqrtPriceLimitX96: 0n }] });
        const result = await client.call({ to: quoter, data, blockNumber });
        const [input] = decodeFunctionResult({ abi: quoteAbi, functionName: 'quoteExactOutputSingle', data: result.data });
        if (input > 0n && (!best || input < best)) { best = input; bestFee = fee; }
      } catch { /* empty liquidity, unsupported route, or RPC failure */ }
    }
    rows.push({ targetUsdc: value, v2: v2 ? formatUnits(v2, decimals) : null, v3: best ? formatUnits(best, decimals) : null, v3Fee: bestFee, spreadBps: v2 && best ? Number((v2 > best ? v2 - best : best - v2) * 10000n / (v2 < best ? v2 : best)) : null });
  }
  console.log(JSON.stringify({ symbol, v3PoolFees: pools, rows }));
}
