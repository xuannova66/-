/** Read-only recipient token account check; not a payment or live activation. */
const rpc=process.env.XUANNOVA_SOL_READONLY_RPC;
if(!rpc?.startsWith('https://'))throw Error('TRUSTED_HTTPS_RPC_REQUIRED');
const owner='BzDaU6VKyMtN14QeVuCMva2SGmHLeeYy2GAAG9muJNq2';
const mint='EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v';
async function call(method,params){
 const response=await fetch(rpc,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params}),signal:AbortSignal.timeout(15000)});
 if(!response.ok)throw Error(`RPC_HTTP_${response.status}`);
 const body=await response.json();if(body.error || body.id!==1 || !('result' in body))throw Error('RPC_RESPONSE_INVALID');return body.result;
}
if(await call('getGenesisHash',[])!=='5eykt4UsFv8P8NJdTREpY1vzqKqZKvdpKuc147dw2N9d')throw Error('WRONG_CHAIN');
const result=await call('getTokenAccountsByOwner',[owner,{mint},{encoding:'jsonParsed',commitment:'finalized'}]);
if(!Array.isArray(result?.value))throw Error('RPC_RESPONSE_INVALID');
const accounts=result.value.map(x=>({address:x.pubkey,program:x.account?.owner,owner:x.account?.data?.parsed?.info?.owner,mint:x.account?.data?.parsed?.info?.mint,state:x.account?.data?.parsed?.info?.state}));
console.log(JSON.stringify({network:'solana-mainnet',slot:result.context?.slot,owner,mint,accounts,scope:'read-only; account presence is not proof of operational readiness'}));
