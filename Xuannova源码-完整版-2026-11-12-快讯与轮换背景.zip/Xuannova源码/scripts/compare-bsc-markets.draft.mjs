/** Read-only comparison of two independent V2 factories at one BSC block.
 * Quotes, even if aligned, are NOT a manipulation-resistant market oracle,
 * proof of token identity, an executable simulation, or proof of no tax.
 */
import {readFileSync} from "node:fs";
import {createPublicClient,http,getAddress,parseAbi,formatUnits,parseUnits} from "viem";
import {bsc} from "viem/chains";
const rpc=process.env.XUANNOVA_READONLY_RPC;
if(!rpc?.startsWith("https://"))throw Error("TRUSTED_HTTPS_RPC_REQUIRED");
const client=createPublicClient({chain:bsc,transport:http(rpc,{timeout:12000,retryCount:1})});
const routers=[{name:"PancakeV2",address:getAddress("0x10ED43C718714eb63d5aA57B78B54704E256024E"),factory:getAddress("0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73")},{name:"UniswapV2",address:getAddress("0x4752ba5DBc23f44D87826276BF6Fd6b1C372aD24"),factory:getAddress("0x8909Dc15e40173Ff4699343b6eB8132c65e18eC6")}];
const stable=getAddress("0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d"),wrapped=getAddress("0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c");
const abi=parseAbi(["function factory() view returns(address)","function getAmountsIn(uint256,address[]) view returns(uint256[])"]),tokenAbi=parseAbi(["function decimals() view returns(uint8)"]);
const list=JSON.parse(readFileSync(new URL("../config/multichain-assets.draft.json",import.meta.url),"utf8")).chains.bsc.assets;
if(await client.getChainId()!==56)throw Error("WRONG_CHAIN");const blockNumber=await client.getBlockNumber();
for(const r of routers){const factory=await client.readContract({address:r.address,abi,functionName:"factory",blockNumber});if(getAddress(factory)!==r.factory)throw Error("FACTORY_MISMATCH");}
console.log(JSON.stringify({chain:56,block:blockNumber.toString(),routers:routers.map(x=>x.name),scope:"read-only two-factory V2 quotes; NOT validated oracle"}));
async function inspect(item){
 if(item.symbol==="USDC")return {symbol:item.symbol,status:"settlement_asset"};
 if(!item.address&&!item.native)return {symbol:item.symbol,status:"address_missing"};
 const token=item.native?wrapped:getAddress(item.address.toLowerCase());let decimals;
 try{decimals=await client.readContract({address:token,abi:tokenAbi,functionName:"decimals",blockNumber});}catch{return {symbol:item.symbol,status:"metadata_unavailable"};}
 const paths=[[token,stable],...(token===wrapped?[]:[[token,wrapped,stable]])],rows=[];
 for(const price of ["4.99","39.90"]){const amount=parseUnits(price,18),quotes=[];
  for(const r of routers){let best=null;for(const path of paths){try{const a=await client.readContract({address:r.address,abi,functionName:"getAmountsIn",args:[amount,path],blockNumber});if(a.length===path.length&&a.at(-1)===amount&&a[0]>0n&&(!best||a[0]<best))best=a[0];}catch{/* Not an executable route or RPC failed. */}}
   quotes.push({router:r.name,units:best});}
  const [a,b]=quotes.map(x=>x.units);const spreadBps=a&&b?Number((a>b?a-b:b-a)*10000n/(a<b?a:b)):null;
  rows.push({targetUsdc:price,quotes:quotes.map(x=>({router:x.router,input:x.units?formatUnits(x.units,decimals):null})),spreadBps});}
 return {symbol:item.symbol,decimals,rows};
}
for(let i=0;i<list.length;i+=3){for(const result of await Promise.all(list.slice(i,i+3).map(inspect)))console.log(JSON.stringify(result));}
