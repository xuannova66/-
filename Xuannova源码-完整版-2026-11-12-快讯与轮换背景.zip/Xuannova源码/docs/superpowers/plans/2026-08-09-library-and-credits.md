# Archive Library and Dedicated Credits Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Turn the Wisdom Library into a searchable, source-linked classics catalogue that covers every study method, and add a dedicated purchase-credits route.

**Architecture:** Keep bibliographic data in a focused catalogue module; render it through a compact, localised list-and-detail explorer with external public-source links. Reuse the existing verified `MemberCommerceCenter` on a new `#credits` route, and route paywall actions to that dedicated entry.

**Tech Stack:** React 19, TypeScript, Vinext, Cloudflare Worker/D1 commerce API, CSS, Node test runner.

## Global Constraints

- Do not copy Qingnang source code, layouts, catalogue text, or private calculations.
- Use public-source links only; do not upload commercial book-cover scans or unnecessary decorative imagery.
- Keep all new visible UI labels complete in English, Simplified Chinese, Traditional Chinese, Japanese, Korean, Vietnamese, and Thai.
- Preserve server-side, manually reviewed USDT credit issuance; never auto-credit a QR scan.
- Never store or print owner passwords or API secrets in the source tree.

---

### Task 1: Define the catalogue contract

**Files:**
- Create: `app/library-catalogue.ts`
- Create: `tests/library-catalogue.test.mjs`
- Modify: `package.json`

**Interfaces:**
- Produces `classicalWorks`, `libraryCategories`, `LibraryCategory`, and `coversAllStudyMethods()`.
- Consumers: `app/library-explorer.tsx` and static UI tests.

- [ ] **Step 1: Write the failing test**

```js
import { classicalWorks, coversAllStudyMethods } from "../app/library-catalogue.ts";
test("catalogue covers every study method with public sources", () => {
  assert.ok(classicalWorks.length >= 28);
  assert.equal(coversAllStudyMethods(), true);
  assert.ok(classicalWorks.every((work) => work.sourceUrl.startsWith("https://")));
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pnpm exec tsx --test tests/library-catalogue.test.mjs`

Expected: FAIL because the catalogue module does not exist.

- [ ] **Step 3: Write minimal implementation**

Create the catalogue with at least 28 bibliographic records across foundations, BaZi, Zi Wei, Qi Men, Liuyao, Da Liu Ren, celestial, naming, dream reflection, tarot, I Ching, and natal study. Every record includes id, category, English title, original title, tags, short description, public source URL, and a visual cover variant.

- [ ] **Step 4: Run test to verify it passes**

Run: `pnpm exec tsx --test tests/library-catalogue.test.mjs`

Expected: PASS.

### Task 2: Render a rich catalogue and reading desk

**Files:**
- Create: `app/library-explorer.tsx`
- Modify: `app/page.tsx`
- Modify: `app/globals.css`
- Test: `tests/library-ui-contract.test.mjs`

**Interfaces:**
- Consumes `classicalWorks` and `LibraryCategory` from `app/library-catalogue.ts`.
- Produces `LibraryExplorer({ locale })` with search, category selection, detail drawer, public source link, generated cover treatment, and complete locale UI copy.

- [ ] **Step 1: Write the failing test**

```js
const explorer = readFileSync("app/library-explorer.tsx", "utf8");
assert.match(explorer, /Public source|公开原典|原典公開/);
assert.match(explorer, /archive-list/);
assert.match(explorer, /rel="noreferrer"/);
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pnpm exec tsx --test tests/library-ui-contract.test.mjs`

Expected: FAIL because the explorer does not exist.

- [ ] **Step 3: Write minimal implementation**

Replace the short note grid in `LibraryScreen` with the explorer. The explorer must search title/tags, filter all categories, present each record as a compact indexed list row, open an in-app reading detail, and open the original public source in a new tab.

- [ ] **Step 4: Run test to verify it passes**

Run: `pnpm exec tsx --test tests/library-ui-contract.test.mjs`

Expected: PASS.

### Task 3: Add the independent credits route

**Files:**
- Modify: `app/study-suite.ts`
- Modify: `app/study-navigation.ts`
- Modify: `app/page.tsx`
- Modify: `app/globals.css`
- Test: `tests/library-ui-contract.test.mjs`

**Interfaces:**
- Extends `AppRoute` with `credits`.
- Reuses `MemberCommerceCenter({ locale })` from `app/member-commerce-center.tsx`.

- [ ] **Step 1: Write the failing test**

```js
const suite = readFileSync("app/study-suite.ts", "utf8");
const page = readFileSync("app/page.tsx", "utf8");
assert.match(suite, /\| "credits"/);
assert.match(page, /data-route="credits"/);
assert.match(page, /navigate\("credits"\)/);
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pnpm exec tsx --test tests/library-ui-contract.test.mjs`

Expected: FAIL because the route and entry do not exist.

- [ ] **Step 3: Write minimal implementation**

Add `#credits` to the route union, hash parser, routing set, each of the seven route-copy maps, header action, mobile menu and main route render. Render a dedicated credit-screen heading and `MemberCommerceCenter`; redirect insufficient-credit study actions to it.

- [ ] **Step 4: Run test to verify it passes**

Run: `pnpm exec tsx --test tests/library-ui-contract.test.mjs`

Expected: PASS.

### Task 4: Verify, inspect, and publish

**Files:**
- Modify only if a verification finding requires it.

- [ ] **Step 1: Run focused tests**

Run: `pnpm exec tsx --test tests/library-catalogue.test.mjs tests/library-ui-contract.test.mjs`

Expected: PASS.

- [ ] **Step 2: Run the full validation suite**

Run: `pnpm test && pnpm lint && pnpm build`

Expected: all tests and builds pass; lint may retain the known QR `<img>` warning only.

- [ ] **Step 3: Visually inspect desktop and mobile**

Open `#library` and `#credits` in the local browser; verify the hero image, full card grid, reading desk, payment entry, language switching, 390px mobile layout, and no clipped controls.

- [ ] **Step 4: Deploy the existing preview worker**

Run: `pnpm exec wrangler deploy --config dist/server/wrangler.json --name xuanyuan-institute-preview`

Expected: deployment URL remains under `xuanyuan-institute-preview.workers.dev`.

- [ ] **Step 5: Smoke test public routes**

Run: `curl -I https://xuanyuan-institute-preview.xuanyuan-institute-preview.workers.dev/` and verify `#library` and `#credits` render in a browser.

## Self-review

- The catalogue covers the eleven study routes plus all seven toolkit methods.
- The dedicated credit entry uses the existing manual-review payment workflow without exposing operational secrets.
- The reading links are public sources only and the interface remains intentionally compact.
