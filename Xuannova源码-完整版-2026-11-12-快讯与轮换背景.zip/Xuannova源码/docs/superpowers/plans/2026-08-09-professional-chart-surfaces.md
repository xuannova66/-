# Professional Chart Surfaces Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Present BaZi as an original dense four-pillar matrix and Zi Wei as an original twelve-palace perimeter chart while retaining existing independently calculated chart data.

**Architecture:** `CompleteChartBoard` remains the single chart-stage renderer. It selects a dedicated presentational surface only for `bazi`/`detail` and `ziwei`; all other tools retain their existing board types. The new surfaces read the already available `BoardCell` fields, so the chart data and AI-reading request shapes do not change.

**Tech Stack:** React 19, TypeScript, Vinext, CSS Grid, Node test runner, ESLint.

## Global Constraints

- Do not copy third-party source, visual assets, text, or pixel-identical layouts.
- Keep the existing seven interface locales and `localizeBoardTerm` rendering path.
- Preserve the input → ritual → chart → interpretation flow, privacy controls, credit handling and cultural-study disclaimer.
- Keep mobile usable at `650px` and desktop readable from `860px` upward.

---

### Task 1: Declare presentation contracts for the two specialist boards

**Files:**
- Modify: `tests/chart-engine.test.mjs`
- Modify: `app/complete-chart-board.tsx`

**Interfaces:**
- Consumes: `CompleteChart` with `tool`, `board.cells`, `calendar`, and `pillars`.
- Produces: `ProfessionalBaZiBoard` and `ProfessionalZiWeiBoard`, selected by `CompleteChartBoard`.

- [ ] **Step 1: Write the failing test**

```js
test("BaZi and Zi Wei select specialist chart surfaces", async () => {
  const source = await readFile(new URL("../app/complete-chart-board.tsx", import.meta.url), "utf8");
  assert.match(source, /professional-bazi-board/);
  assert.match(source, /professional-ziwei-board/);
  assert.match(source, /chart\.tool === "bazi" \|\| chart\.tool === "detail"/);
  assert.match(source, /chart\.tool === "ziwei"/);
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pnpm exec tsx --test tests/chart-engine.test.mjs`

Expected: FAIL because the two specialist surface class names are not present.

- [ ] **Step 3: Add the specialist render branches**

```tsx
{view === "board" && (chart.tool === "bazi" || chart.tool === "detail") && <ProfessionalBaZiBoard chart={chart} locale={locale} />}
{view === "board" && chart.tool === "ziwei" && <ProfessionalZiWeiBoard chart={chart} locale={locale} />}
{view === "board" && !["bazi", "detail", "ziwei"].includes(chart.tool) && <div className={`complete-board ${chart.board.kind}`}>...</div>}
```

- [ ] **Step 4: Run the focused test to verify it passes**

Run: `pnpm exec tsx --test tests/chart-engine.test.mjs`

Expected: PASS with the new specialist-surface test and existing chart tests passing.

### Task 2: Build the original BaZi matrix surface

**Files:**
- Modify: `app/complete-chart-board.tsx`
- Modify: `app/globals.css`
- Test: `tests/chart-engine.test.mjs`

**Interfaces:**
- Consumes: `chart.board.cells` in Year, Month, Day, Hour order; each cell has items including `Stem`, `Branch`, `Ten God`, `Hidden stems`, `NaYin`, `Life stage`, and `Pillar shen-sha`.
- Produces: `<section className="professional-bazi-board">` with a four-column matrix, a context rail and luck-cycle table.

- [ ] **Step 1: Write the failing assertions**

```js
test("BaZi has the dense data needed by the four-pillar matrix", () => {
  const chart = createCompleteChart({ ...sharedInput, module: "bazi" });
  for (const label of ["Stem", "Branch", "Ten God", "Hidden stems", "NaYin", "Life stage", "Pillar shen-sha"]) {
    assert.ok(chart.board.cells.every((cell) => cell.items.some((item) => item.label === label)));
  }
});
```

- [ ] **Step 2: Run the focused test to verify it passes against existing chart data**

Run: `pnpm exec tsx --test tests/chart-engine.test.mjs`

Expected: PASS; the layout work will reuse existing data rather than duplicating calculations.

- [ ] **Step 3: Implement the matrix and styles**

```tsx
function ProfessionalBaZiBoard({ chart, locale }: { chart: CompleteChart; locale: Locale }) {
  const rows = ["Stem", "Branch", "Ten God", "Hidden stems", "NaYin", "Life stage", "Pillar shen-sha"];
  return <section className="professional-bazi-board">...</section>;
}
```

```css
.professional-bazi-board { display: grid; grid-template-columns: minmax(0, 1fr) 220px; }
.bazi-matrix { display: grid; grid-template-columns: 116px repeat(4, minmax(108px, 1fr)); }
.bazi-matrix > * { border-right: 1px solid var(--line); border-bottom: 1px solid var(--line); }
```

- [ ] **Step 4: Run the focused test to verify it passes**

Run: `pnpm exec tsx --test tests/chart-engine.test.mjs`

Expected: PASS.

### Task 3: Build the original Zi Wei perimeter surface

**Files:**
- Modify: `app/complete-chart-board.tsx`
- Modify: `app/globals.css`
- Test: `tests/chart-engine.test.mjs`

**Interfaces:**
- Consumes: twelve Zi Wei `chart.board.cells`, where each cell has palace branch/stem, core/support/minor star, transformation, condition, decade limit and annual focus.
- Produces: `<section className="professional-ziwei-board">` with 12 perimeter panels and a central information well.

- [ ] **Step 1: Write the failing assertions**

```js
test("Zi Wei has the twelve-palace data needed by the perimeter chart", () => {
  const chart = createCompleteChart({ ...sharedInput, module: "ziwei" });
  assert.equal(chart.board.cells.length, 12);
  for (const label of ["Palace branch", "Palace stem", "Core star", "Support star", "Transformation", "Minor star", "Decade limit", "Annual focus"]) {
    assert.ok(chart.board.cells.every((cell) => cell.items.some((item) => item.label === label)));
  }
});
```

- [ ] **Step 2: Run test to verify it passes against existing chart data**

Run: `pnpm exec tsx --test tests/chart-engine.test.mjs`

Expected: PASS; no data-model change is needed.

- [ ] **Step 3: Implement the 4×4 perimeter grid and centre well**

```tsx
function ProfessionalZiWeiBoard({ chart, locale }: { chart: CompleteChart; locale: Locale }) {
  return <section className="professional-ziwei-board">...
    <aside className="ziwei-centre-well">...</aside>
  </section>;
}
```

```css
.professional-ziwei-board { display: grid; grid-template-columns: repeat(4, minmax(150px, 1fr)); }
.ziwei-centre-well { grid-area: 2 / 2 / span 2 / span 2; }
.ziwei-palace { min-height: 198px; }
```

- [ ] **Step 4: Run the focused tests to verify they pass**

Run: `pnpm exec tsx --test tests/chart-engine.test.mjs tests/method-completeness.test.mjs`

Expected: all tests PASS.

### Task 4: Responsive QA and publish verification

**Files:**
- Modify: `app/globals.css`
- Test: `tests/rendered-html.test.mjs`

**Interfaces:**
- Consumes: the specialist board class names from Tasks 1–3.
- Produces: two-column BaZi matrix and two-column Zi Wei palace layout below `650px`, with the centre well no longer overlapping panels.

- [ ] **Step 1: Add mobile layout assertions**

```js
test("chart renderer keeps dedicated BaZi and Zi Wei board hooks", async () => {
  const source = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");
  assert.match(source, /professional-bazi-board/);
  assert.match(source, /professional-ziwei-board/);
});
```

- [ ] **Step 2: Implement mobile CSS**

```css
@media (max-width: 650px) {
  .professional-bazi-board { grid-template-columns: 1fr; overflow-x: auto; }
  .professional-ziwei-board { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .ziwei-centre-well { grid-area: auto; grid-column: span 2; }
}
```

- [ ] **Step 3: Run complete verification**

Run: `pnpm test && pnpm lint && pnpm build`

Expected: test suite passes; lint has no errors; build exits 0.

- [ ] **Step 4: Inspect the local generated BaZi and Zi Wei surfaces in a browser**

Run: start the local app, generate one BaZi and one Zi Wei chart, and verify desktop plus narrow-screen hierarchy before deployment.

- [ ] **Step 5: Publish the verified build to the existing preview Worker**

Run: `pnpm exec wrangler deploy --config dist/server/wrangler.json --name xuanyuan-institute-preview`

Expected: Wrangler reports the existing preview URL and a new version ID.
