# Chart Copy and Global Geocoding Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace generic chart narration with tool-specific wording and make worldwide location selection return usable city, country, coordinates, and timezone data.

**Architecture:** Chart text remains a pure client-side mapping over deterministic chart output. Location search uses the existing Open-Meteo global city index first, then a same-origin Worker endpoint that normalizes a global fallback response and resolves all selected results to IANA time zones.

**Tech Stack:** Next.js client components, TypeScript, Cloudflare Worker, Node built-in test runner.

## Global Constraints

- Preserve the existing seven locales: en, zh-Hans, zh-Hant, ja, ko, vi, th.
- Do not duplicate another product's UI, copy, or source code.
- Every new behavior has a red test before its implementation.
- Never return vague chart filler such as a generic "cultural study reference".

---

### Task 1: Lock down chart copy quality

**Files:**
- Modify: `tests/locale-copy.test.mjs`
- Modify: `app/complete-chart-board.tsx`

**Interfaces:**
- Consumes: `localizeBoardTerm(value, locale)`
- Produces: module-specific localized chart titles and section descriptions.

- [ ] **Step 1: Write the failing test**

```js
assert.doesNotMatch(localizeBoardTerm("Stem, branch, root, role and seasonal reference in one dense study grid", "zh-Hans"), /文化研习说明|象征参照/);
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pnpm exec tsx --test tests/locale-copy.test.mjs`

Expected: FAIL because the generic narrative fallback is returned.

- [ ] **Step 3: Write minimal implementation**

```ts
const generatedNarrativeTerms = { "Stem, branch, root, role and seasonal reference in one dense study grid": { "zh-Hans": "在四柱矩阵中并列查看天干、地支、根气、柱位与时令" } };
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pnpm exec tsx --test tests/locale-copy.test.mjs`

Expected: PASS.

### Task 2: Add worldwide fallback city queries

**Files:**
- Modify: `tests/geocoding.test.mjs`
- Modify: `app/geocoding.ts`
- Modify: `app/global-location-field.tsx`
- Modify: `worker/index.ts`

**Interfaces:**
- Consumes: a city query and active locale.
- Produces: `GlobalLocation[]` with coordinates, country code, and IANA timezone.

- [ ] **Step 1: Write the failing test**

```js
assert.match(buildGlobalFallbackGeocodingUrl("Đà Nẵng", "vi"), /nominatim/);
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pnpm exec tsx --test tests/geocoding.test.mjs`

Expected: FAIL because no global fallback URL builder exists.

- [ ] **Step 3: Write minimal implementation**

```ts
export function buildGlobalFallbackGeocodingUrl(query: string, locale: string) {
  return `/api/geocode?q=${encodeURIComponent(query)}&locale=${encodeURIComponent(locale)}`;
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pnpm exec tsx --test tests/geocoding.test.mjs`

Expected: PASS.

### Task 3: Validate original professional chart layouts and release

**Files:**
- Modify: `app/complete-chart-board.tsx`
- Modify: `app/globals.css`
- Test: `tests/locale-copy.test.mjs`, `tests/chart-engine.test.mjs`

- [ ] **Step 1: Add narrow regression assertions for four-pillar and twelve-palace structures**
- [ ] **Step 2: Verify the new assertions fail if either structure is removed**
- [ ] **Step 3: Improve only the existing original matrix and twelve-palace presentation**
- [ ] **Step 4: Run `pnpm test`, `pnpm run lint`, and `pnpm run build`**
- [ ] **Step 5: Deploy the built Worker and verify the public homepage returns HTTP 200**
