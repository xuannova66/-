# Method Completeness Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Give every current Xuanyuan method a distinct, layered local chart rather than routing toolkit methods through a generic comparison board.

**Architecture:** Extend the existing deterministic chart-model with method-family builders that return the common `CompleteChart` contract. Keep the source input, time basis, ritual stage, board renderer, and interpretation request unchanged so richer structures automatically reach the existing multilingual chart and AI-ready reading flow.

**Tech Stack:** TypeScript, React 19, Vinext, Node test runner.

## Global Constraints

- Do not copy Qingnang code, layout, source text, or proprietary calculation logic.
- Use independent, deterministic local study structures with an explicit cultural-study disclaimer.
- Preserve civil time, true-solar-time note, global place selection, and the existing credit-gated AI-ready interpretation workflow.
- Every tool must expose a distinct board label plus method-specific cells and sections.

---

### Task 1: Lock independent method contracts with tests

**Files:**
- Create: `tests/method-completeness.test.mjs`
- Modify: `package.json`

**Interfaces:**
- Consumes `createCompleteChart(input)` from `app/chart-model.ts`.
- Defines the required board labels and section ids for toolkit methods and synthesis routes.

- [ ] **Step 1: Write the failing test**

```js
const tools = ["toolkit-time", "toolkit-elements", "toolkit-dream", "toolkit-name", "toolkit-tarot", "toolkit-iching", "toolkit-natal"];
for (const tool of tools) {
  const chart = createCompleteChart({ ...base, module: tool });
  assert.notEqual(chart.board.label, "Synthesis local study map");
  assert.ok(chart.sections.length >= 5);
}
```

- [ ] **Step 2: Run the test and verify it fails**

Run: `pnpm exec tsx --test tests/method-completeness.test.mjs`

Expected: FAIL because time, elements, dream, and name currently fall through to the generic synthesis board.

- [ ] **Step 3: Add focused chart builders**

Add independent builders in `app/chart-model.ts` for timing, five-elements, dream, name, tarot, I Ching, and natal study. Each builder must include at least five method-specific sections and a non-generic board label while preserving input-derived calendar and place facts.

- [ ] **Step 4: Run the test and verify it passes**

Run: `pnpm exec tsx --test tests/method-completeness.test.mjs`

Expected: PASS.

### Task 2: Expand synthesis and inquiry evidence layers

**Files:**
- Modify: `app/chart-model.ts`
- Modify: `tests/method-completeness.test.mjs`

**Interfaces:**
- Extends comparison-style charts (`hecan`, `compatibility`, `wenshi`) with tool-appropriate sections rather than generic labels alone.

- [ ] **Step 1: Write the failing test**

```js
assert.ok(createCompleteChart({ ...base, module: "hecan" }).sections.some((x) => x.id === "pillar-crosscheck"));
assert.ok(createCompleteChart({ ...base, module: "compatibility" }).sections.some((x) => x.id === "pair-resonance"));
assert.ok(createCompleteChart({ ...base, module: "wenshi" }).sections.some((x) => x.id === "inquiry-triangulation"));
```

- [ ] **Step 2: Run test and verify it fails**

Run: `pnpm exec tsx --test tests/method-completeness.test.mjs`

Expected: FAIL because the three routes share the generic comparison sections.

- [ ] **Step 3: Add independent synthesis sections**

Create a comparison builder that adds tool-specific cross-check, paired context, or inquiry triangulation sections according to `input.module`.

- [ ] **Step 4: Run test and verify it passes**

Run: `pnpm exec tsx --test tests/method-completeness.test.mjs`

Expected: PASS.

### Task 3: Verify the complete flow

**Files:**
- Modify: `package.json`
- Modify only if verification finds a defect.

- [ ] **Step 1: Run targeted chart tests**

Run: `pnpm exec tsx --test tests/chart-engine.test.mjs tests/method-completeness.test.mjs`

Expected: PASS.

- [ ] **Step 2: Run full verification**

Run: `pnpm test && pnpm lint && pnpm build`

Expected: all tests and builds pass; the existing payment QR image lint warning may remain.

- [ ] **Step 3: Inspect local tool pages**

Open toolkit time, elements, dream, name, tarot, I Ching, natal, plus a synthesis route. Confirm each reaches ritual, complete chart, and interpretation without falling back to a generic chart.
