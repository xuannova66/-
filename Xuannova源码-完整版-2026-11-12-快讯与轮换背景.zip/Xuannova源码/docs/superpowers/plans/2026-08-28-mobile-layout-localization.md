# Mobile Layout and Localization Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make every published Xuanyuan Institute interface language complete and make all user-facing routes usable at phone widths.

**Architecture:** Retain the existing `Locale` record architecture and extend its test contracts so visible labels cannot silently fall back to source language. Add responsive overrides to the existing CSS system rather than duplicating page markup, while dense chart boards keep their information in an explicit local scrolling surface.

**Tech Stack:** React 19, TypeScript, Vinext/Vite, CSS, Node test runner, Cloudflare Workers.

## Global Constraints

- Published locales are exactly `en`, `zh-Hans`, `zh-Hant`, `ja`, `ko`, `vi`, and `th`.
- Do not translate proper names, payment network names, URLs, cryptographic hashes, or user-entered values.
- Phone baseline is 360–430px; no page-level horizontal scrolling.
- Dense chart data remains available; only its own chart viewport may scroll horizontally.
- Add tests before production code changes and observe each new test fail first.

### Task 1: Lock in locale and phone layout contracts

**Files:**
- Modify: `tests/locale-copy.test.mjs`
- Modify: `tests/chart-engine.test.mjs`
- Modify: `tests/rendered-html.test.mjs`

**Interfaces:**
- Consumes: `publishedLocales`, `getSuiteCopy`, chart board CSS, and global responsive CSS.
- Produces: regression checks that fail when a locale dictionary is incomplete or dense mobile boards can cause page-level overflow.

- [ ] **Step 1: Write failing localization contract**

```js
test("every published locale has complete action and status copy", async () => {
  for (const locale of publishedLocales) {
    assert.ok(getSuiteCopy(locale).shared.account.length > 0);
    assert.ok(creditCopy(locale).viewMembership.length > 0);
    assert.ok(interpretationCopy[locale].serviceError.length > 0);
  }
});
```

- [ ] **Step 2: Write failing phone layout contract**

```js
test("phone layout confines dense charts and long account values", async () => {
  assert.match(styles, /@media \(max-width: 650px\)[\s\S]*\.study-stage-screen \{ overflow-x: clip; \}/);
  assert.match(styles, /\.professional-bazi-board \{[^}]*overflow-x: auto/);
  assert.match(styles, /\.commerce-qr code[^{]*\{[^}]*overflow-wrap: anywhere/);
});
```

- [ ] **Step 3: Run focused tests to verify RED**

Run: `pnpm exec tsx --test tests/locale-copy.test.mjs tests/chart-engine.test.mjs && node --test tests/rendered-html.test.mjs`

Expected: failures for the missing complete-copy and phone containment assertions.

### Task 2: Complete locale handling at every UI boundary

**Files:**
- Modify: `app/study-suite.ts`
- Modify: `app/ui-copy.ts`
- Modify: `app/interpretation-panel.tsx`
- Modify: `app/member-commerce-center.tsx`
- Modify: `app/account-contact-center.tsx`
- Modify: `app/admin-console.tsx`
- Modify: `app/complete-chart-board.tsx`

**Interfaces:**
- Consumes: `Locale` and existing per-component `Record<Locale, …>` dictionaries.
- Produces: locale-safe visible strings, including complete service-state text and board labels.

- [ ] **Step 1: Add the smallest missing locale fields**

```ts
type InterpretationCopy = {
  // existing fields
  serviceError: string;
  configurationError: string;
  providerBusyError: string;
  responseRetryError: string;
};
```

- [ ] **Step 2: Route all static visible component labels through the corresponding locale record**

```tsx
<small>{text.invitations}</small>
// Keep em dashes, network identifiers and user values as data.
```

- [ ] **Step 3: Run focused tests to verify GREEN**

Run: `pnpm exec tsx --test tests/locale-copy.test.mjs tests/chart-engine.test.mjs && node --test tests/rendered-html.test.mjs`

Expected: all focused tests pass.

### Task 3: Rework compact-screen layout without discarding chart data

**Files:**
- Modify: `app/globals.css`
- Modify: `app/account-contact-center.module.css`
- Modify: `app/archive-cover-mobile.css`

**Interfaces:**
- Consumes: existing semantic class names such as `.site-header`, `.mobile-menu`, `.study-stage-screen`, `.professional-bazi-board`, `.professional-ziwei-board`, `.member-commerce-center`, and `.admin-console`.
- Produces: touch-safe single-column layouts and controlled chart scrolling for widths through 430px.

- [ ] **Step 1: Add a constrained phone route viewport**

```css
@media (max-width: 650px) {
  .study-stage-screen, .membership-screen, .credits-screen, .admin-screen {
    overflow-x: clip;
  }
  .professional-bazi-board {
    overscroll-behavior-x: contain;
    -webkit-overflow-scrolling: touch;
  }
}
```

- [ ] **Step 2: Make long values and controls wrap at phone widths**

```css
@media (max-width: 650px) {
  .commerce-qr code, .commerce-orders b, .admin-table code {
    overflow-wrap: anywhere;
    white-space: normal;
  }
}
```

- [ ] **Step 3: Preserve selected chart detail, member actions, and admin actions in one-column/touch layouts**

```css
@media (max-width: 480px) {
  .complete-chart-heading, .interpretation-credit-status, .commerce-account > div {
    grid-template-columns: 1fr;
  }
}
```

- [ ] **Step 4: Run the focused tests to verify GREEN**

Run: `pnpm exec tsx --test tests/chart-engine.test.mjs && node --test tests/rendered-html.test.mjs`

Expected: all focused tests pass.

### Task 4: Validate, inspect, and release

**Files:**
- Verify: `tests/locale-copy.test.mjs`, `tests/chart-engine.test.mjs`, `tests/rendered-html.test.mjs`
- Verify: `app/globals.css`, `app/complete-chart-board.tsx`, `app/member-commerce-center.tsx`, `app/admin-console.tsx`

- [ ] **Step 1: Run the complete automated suite**

Run: `pnpm test && pnpm run lint`

Expected: all tests pass and lint reports no errors.

- [ ] **Step 2: Inspect mobile and desktop routes**

At 390px and desktop width, inspect English, Japanese, Korean, Vietnamese and Thai routes for the header, a dense study board, membership, credits and owner console. Confirm no page-level horizontal overflow, clipped controls, untranslated static interface labels, or unreadable touch targets.

- [ ] **Step 3: Deploy current build and verify public availability**

Run: `pnpm exec wrangler deploy --config dist/server/wrangler.json --name xuanyuan-institute-preview`

Expected: a successful Worker version and HTTP 200 from the public URL.
