# Xuanyuan Credit Membership Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a truthful, multilingual credit wallet so every generated interpretation consumes 50 credits except the Synthesis Reading, which consumes 300 credits, while exposing the owner-defined USDT packages without pretending a payment has been processed.

**Architecture:** Keep the pricing and debit rules in a small pure `credit-wallet.ts` module, then persist only the resulting wallet state in the browser, using the same device-local boundary as the existing email session. The top-level page owns the wallet and passes a debit callback into both regular-study and toolkit interpretation panels; the membership route renders the balance, package catalogue, and a payment-channel state driven by an empty, safe owner configuration object.

**Tech Stack:** Next.js client components, TypeScript, browser `localStorage`, Node built-in test runner through `tsx`, CSS custom properties.

## Global Constraints

- Charge exactly 300 credits for `hecan` and exactly 50 credits for every other interpretation tool.
- Display exactly these packages: `9.9 U / 50 credits`, `30 U / 170 credits`, `50 U / 280 credits`, `100 U / 600 credits`.
- Start every browser wallet at 0 credits; do not add a local “paid” button or fabricate a completed USDT payment.
- Keep QR image, recipient address, checkout URL, and payment verification disabled until the owner supplies them.
- Translate every new visible string for `en`, `zh-Hans`, `zh-Hant`, `ja`, `ko`, `vi`, and `th`.
- Preserve the current device-local privacy model; do not transmit email, questions, chart data, payment data, or wallet state.

---

## File structure

- `app/credit-wallet.ts` — exact package constants, cost policy, immutable debit logic, and browser wallet persistence.
- `app/payment-config.ts` — intentionally blank owner-only payment-channel settings and a derived configured flag.
- `app/credit-copy.ts` — fully translated wallet and paid-interpretation UI copy for all seven locales.
- `app/interpretation-panel.tsx` — displays balance/cost and requests a debit before generating the local reading.
- `app/account-contact-center.tsx` — renders wallet balance, price rules, packages, and a truthful unconfigured USDT state.
- `app/page.tsx` — owns wallet state and wires debits and membership navigation into both kinds of reading screen.
- `app/study-suite.ts` — removes outdated wording that says this edition never processes payments.
- `app/globals.css` — visual treatment and responsive behaviour for the wallet, package cards, and paywall notice.
- `tests/credit-wallet.test.mjs` — pricing, package, debit, and safe payment configuration coverage.
- `tests/interpretation-credit-flow.test.mjs` — verifies UI source passes debit/navigation dependencies before invoking the local adapter.

### Task 1: Create and test the credit policy module

**Files:**
- Create: `app/credit-wallet.ts`
- Create: `tests/credit-wallet.test.mjs`

**Interfaces:**
- Produces `creditPackages`, `interpretationCost(tool)`, `createCreditWallet()`, `spendCredits(wallet, tool)`, `readCreditWallet()`, and `saveCreditWallet(wallet)`.
- `spendCredits` returns `{ wallet, cost }` for sufficient balance and `null` for insufficient balance.

- [ ] **Step 1: Write the failing test**

```js
const wallet = createCreditWallet(350);
assert.equal(interpretationCost("hecan"), 300);
assert.equal(interpretationCost("bazi"), 50);
assert.deepEqual(spendCredits(wallet, "hecan"), {
  cost: 300,
  wallet: { balance: 50 },
});
assert.equal(spendCredits(createCreditWallet(49), "bazi"), null);
assert.deepEqual(creditPackages.map(({ usdt, credits }) => [usdt, credits]), [
  ["9.9", 50], ["30", 170], ["50", 280], ["100", 600],
]);
```

- [ ] **Step 2: Run the focused test to verify it fails**

Run: `pnpm exec tsx --test tests/credit-wallet.test.mjs`

Expected: FAIL because the credit-wallet module does not exist.

- [ ] **Step 3: Write the minimal implementation**

```ts
export const creditPackages = [
  { id: "seed", usdt: "9.9", credits: 50 },
  { id: "path", usdt: "30", credits: 170 },
  { id: "ritual", usdt: "50", credits: 280 },
  { id: "synthesis", usdt: "100", credits: 600 },
] as const;

export type CreditWallet = { balance: number };
export const createCreditWallet = (balance = 0): CreditWallet => ({ balance: Math.max(0, Math.floor(balance)) });
export const interpretationCost = (tool: string) => tool === "hecan" ? 300 : 50;
export function spendCredits(wallet: CreditWallet, tool: string) {
  const cost = interpretationCost(tool);
  return wallet.balance < cost ? null : { cost, wallet: { balance: wallet.balance - cost } };
}
```

- [ ] **Step 4: Add browser persistence with invalid-data fallback**

```ts
const walletKey = "xuanyuan-institute-credit-wallet";
export function readCreditWallet(): CreditWallet {
  if (typeof window === "undefined") return createCreditWallet();
  try {
    const parsed = JSON.parse(window.localStorage.getItem(walletKey) ?? "") as CreditWallet;
    return typeof parsed.balance === "number" ? createCreditWallet(parsed.balance) : createCreditWallet();
  } catch { return createCreditWallet(); }
}
export function saveCreditWallet(wallet: CreditWallet) {
  if (typeof window !== "undefined") window.localStorage.setItem(walletKey, JSON.stringify(createCreditWallet(wallet.balance)));
}
```

- [ ] **Step 5: Run the focused test to verify it passes**

Run: `pnpm exec tsx --test tests/credit-wallet.test.mjs`

Expected: PASS.

### Task 2: Define the inactive payment channel and translation boundary

**Files:**
- Create: `app/payment-config.ts`
- Create: `app/credit-copy.ts`
- Modify: `tests/credit-wallet.test.mjs`

**Interfaces:**
- Produces `paymentConfig` and `hasConfiguredPaymentChannel`.
- Produces `creditCopy(locale)` with wallet, package, paywall, and payment-channel labels.

- [ ] **Step 1: Extend the failing test**

```js
const { paymentConfig, hasConfiguredPaymentChannel } = await import("../app/payment-config.ts");
assert.equal(paymentConfig.checkoutUrl, "");
assert.equal(paymentConfig.qrImageUrl, "");
assert.equal(hasConfiguredPaymentChannel, false);
```

- [ ] **Step 2: Run the focused test to verify it fails**

Run: `pnpm exec tsx --test tests/credit-wallet.test.mjs`

Expected: FAIL because the payment configuration module does not exist.

- [ ] **Step 3: Create the safe owner configuration**

```ts
export const paymentConfig = {
  checkoutUrl: "",
  qrImageUrl: "",
  recipientAddress: "",
  networkLabel: "",
  verificationMode: "manual" as const,
};
export const hasConfiguredPaymentChannel = Boolean(
  paymentConfig.checkoutUrl || paymentConfig.qrImageUrl || paymentConfig.recipientAddress,
);
```

- [ ] **Step 4: Add all seven translation records**

Create a `CreditCopy` type with labels for `wallet`, `available`, `standardRule`, `synthesisRule`, `packages`, `payWithUsdt`, `paymentPending`, `paymentSafetyNote`, `cost`, `insufficient`, and `viewMembership`; add a complete record for each supported locale.

- [ ] **Step 5: Run the focused test to verify it passes**

Run: `pnpm exec tsx --test tests/credit-wallet.test.mjs`

Expected: PASS.

### Task 3: Gate every reading before the local adapter runs

**Files:**
- Modify: `app/interpretation-panel.tsx`
- Create: `tests/interpretation-credit-flow.test.mjs`

**Interfaces:**
- `InterpretationPanel` accepts `wallet`, `onSpend(tool): boolean`, and `onOpenMembership()` in addition to `chart` and `locale`.
- Calls `onSpend(chart.tool)` before `createLocalInterpretation(request)`.

- [ ] **Step 1: Write the failing source-contract test**

```js
const source = await readFile(new URL("../app/interpretation-panel.tsx", import.meta.url), "utf8");
assert.match(source, /onSpend\(chart\.tool\)/);
assert.match(source, /if \(!onSpend\(chart\.tool\)\)/);
assert.match(source, /createLocalInterpretation\(request\)/);
assert.match(source, /onOpenMembership/);
```

- [ ] **Step 2: Run the focused test to verify it fails**

Run: `pnpm exec tsx --test tests/interpretation-credit-flow.test.mjs`

Expected: FAIL because the panel does not receive a wallet or request a debit.

- [ ] **Step 3: Update the panel**

```tsx
const cost = interpretationCost(chart.tool);
const interpretStudy = () => {
  if (!onSpend(chart.tool)) { setBlocked(true); return; }
  setBlocked(false);
  setResponse(createLocalInterpretation(request));
};
```

Render the exact localized cost and available balance above the action. On an insufficient balance, render a localized notice and a button that invokes `onOpenMembership`; do not create a reading.

- [ ] **Step 4: Run the focused test to verify it passes**

Run: `pnpm exec tsx --test tests/interpretation-credit-flow.test.mjs`

Expected: PASS.

### Task 4: Build the membership wallet and USDT package screen

**Files:**
- Modify: `app/account-contact-center.tsx`
- Modify: `app/study-suite.ts`
- Modify: `app/globals.css`

**Interfaces:**
- `AccountContactCenter` accepts `wallet: CreditWallet`.
- The screen renders the available balance, both price rules, four package cards, and an honest inactive checkout state if `hasConfiguredPaymentChannel` is false.

- [ ] **Step 1: Write the failing source-contract test**

```js
const source = await readFile(new URL("../app/account-contact-center.tsx", import.meta.url), "utf8");
assert.match(source, /creditPackages\.map/);
assert.match(source, /paymentPending/);
assert.match(source, /wallet\.balance/);
```

- [ ] **Step 2: Run the focused test to verify it fails**

Run: `pnpm exec tsx --test tests/interpretation-credit-flow.test.mjs`

Expected: FAIL because the account screen has no credit wallet.

- [ ] **Step 3: Implement the wallet card and package grid**

Place it before the device-local email card. Use the actual `creditPackages` data, display each `U` amount and credit quantity, and make the payment action disabled when no channel is configured. When a checkout URL is supplied later, use a normal external link and retain a non-automatic verification notice.

- [ ] **Step 4: Replace contradictory membership copy**

Update each `membership` record in `app/study-suite.ts` so it states that account and credit handling are device-local during this preview, while payment confirmation requires the owner’s configured verification path. Do not leave any language saying the product will never process payments.

- [ ] **Step 5: Add responsive CSS**

Add `.credit-wallet-card`, `.credit-balance`, `.credit-rules`, `.credit-package-grid`, `.credit-package`, and `.payment-channel-note` rules following the existing square-corner, fine-line Xuanyuan visual system. At 650px, make cards one column and preserve readable number spacing.

- [ ] **Step 6: Run both focused tests**

Run: `pnpm exec tsx --test tests/credit-wallet.test.mjs tests/interpretation-credit-flow.test.mjs`

Expected: PASS.

### Task 5: Wire shared wallet state into every interpretation route

**Files:**
- Modify: `app/page.tsx`
- Modify: `tests/interpretation-credit-flow.test.mjs`

**Interfaces:**
- `Home` creates wallet state using `readCreditWallet()` and persists updates with `saveCreditWallet()`.
- `spend(tool): boolean` debits only through `spendCredits` and returns false if balance is too low.
- `StudyScreen` and `ToolkitScreen` receive wallet/debit/navigation dependencies and pass them to `InterpretationPanel`.

- [ ] **Step 1: Extend the failing source-contract test**

```js
const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
assert.match(page, /readCreditWallet/);
assert.match(page, /spendCredits/);
assert.match(page, /<InterpretationPanel[\s\S]*onSpend/);
assert.match(page, /onOpenMembership/);
```

- [ ] **Step 2: Run the focused test to verify it fails**

Run: `pnpm exec tsx --test tests/interpretation-credit-flow.test.mjs`

Expected: FAIL because the page does not own or distribute wallet state.

- [ ] **Step 3: Implement state ownership and route wiring**

```tsx
const [wallet, setWallet] = useState(() => readCreditWallet());
const spend = (tool: string) => {
  const next = spendCredits(wallet, tool);
  if (!next) return false;
  setWallet(next.wallet);
  saveCreditWallet(next.wallet);
  return true;
};
```

Pass `wallet`, `onSpend={spend}`, and `onOpenMembership={() => navigate("membership")}` to regular-study and toolkit panels, then pass `wallet` into the membership screen.

- [ ] **Step 4: Run focused tests, lint, and production build**

Run: `pnpm exec tsx --test tests/credit-wallet.test.mjs tests/interpretation-credit-flow.test.mjs && pnpm lint && pnpm build`

Expected: all commands exit 0.

### Task 6: Visually verify and publish the local preview update

**Files:**
- No production source changes expected unless visual QA finds a defect.

- [ ] **Step 1: Run the local app and inspect the member route at desktop and mobile widths**

Run: `pnpm dev`

Expected: wallet grid is readable in all themes and package cards stack at mobile width.

- [ ] **Step 2: Inspect an ordinary-tool reading with 0 credits and a synthesis reading with 0 credits**

Expected: both are blocked, show their correct 50/300 costs, and route to membership without generating an answer.

- [ ] **Step 3: Deploy the verified public preview**

Run: `pnpm exec wrangler deploy --config dist/server/wrangler.json --name xuanyuan-institute-preview`

Expected: deploy prints a public `workers.dev` URL without exposing credentials.

- [ ] **Step 4: Health check the public URL**

Run: `curl --fail --silent --show-error --head --max-time 20 https://xuanyuan-institute-preview.xuanyuan-institute-preview.workers.dev/`

Expected: HTTP 200.

## Self-review

- Pricing requirement is covered by Tasks 1, 3, and 5.
- Exact USDT package requirement is covered by Tasks 1 and 4.
- QR/link deferral and no fake confirmation are covered by Task 2 and Task 4.
- Seven-language coverage is covered by Task 2 and propagated by Tasks 3–4.
- Local privacy and payment-verification limitation are covered by Tasks 1, 2, and 4.
- Regular routes and toolkit routes are covered by Tasks 3 and 5.
