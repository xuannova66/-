# Commerce Administration Core Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver a secure, server-backed USDT payment review and credit system with a password-protected member flow and administrator console.

**Architecture:** Route all authentication, member, order, and admin operations through same-origin Worker APIs backed by Cloudflare D1. Keep payment addresses and QR images public, keep the supplied administrator password and session signing key in Worker secrets, and treat admin approval as the only operation that can issue credits.

**Tech Stack:** Cloudflare Workers, D1/SQLite prepared statements, Web Crypto PBKDF2 and HMAC, React/TypeScript, Vinext, Node built-in tests.

## Global Constraints

- Never hard-code or log the administrator password or Worker signing secret.
- Never issue credits from a QR click, an order submission, or client-side state.
- Only `hecan` costs 300 credits; every other interpretation costs 50.
- Support exactly TRC20 and BSC / BEP20 using the supplied QR images and addresses.
- Use the supplied Telegram URL as the community destination.
- Preserve all seven locales for visible additions.

---

### Task 1: Define and test commerce policy

**Files:**
- Create: `worker/commerce-policy.ts`
- Create: `tests/commerce-policy.test.mjs`

**Interfaces:**
- Produces `paymentNetworks`, `creditPackages`, `packageById(id)`, and `interpretationCost(tool)`.

- [x] **Step 1: Write a failing test for exact network addresses, package prices, and 300/50 credit policy.**
- [x] **Step 2: Run `pnpm exec tsx --test tests/commerce-policy.test.mjs`; expect missing-module failure.**
- [x] **Step 3: Implement immutable policy constants without secrets.**
- [x] **Step 4: Run the focused test; expect pass.**

### Task 2: Add D1 schema and secure Worker API

**Files:**
- Create: `migrations/0001_commerce_core.sql`
- Create: `worker/commerce-api.ts`
- Modify: `worker/index.ts`
- Modify: `vite.config.ts`
- Modify: `.openai/hosting.json`
- Test: `tests/commerce-api.test.mjs`

**Interfaces:**
- `handleCommerceApi(request, env): Promise<Response | null>` handles `/api/auth/*`, `/api/member/*`, `/api/orders/*`, and `/api/admin/*`.
- D1 tables: `members`, `payment_orders`, `credit_ledger`, `admin_audit`.

- [x] **Step 1: Write failing tests for malformed requests, unauthenticated access, and exact package validation.**
- [x] **Step 2: Run focused tests; expect failure before API exists.**
- [x] **Step 3: Implement PBKDF2 password hashing, HMAC session cookies, parameterized D1 operations, and single-approval ledger transaction.**
- [x] **Step 4: Add D1 binding configuration and migration.**
- [ ] **Step 5: Run focused tests and TypeScript build; expect pass.** Vite production build passes; repository-wide `tsc` still reports pre-existing type issues in chart and local DB files outside this change.

### Task 3: Build account checkout and admin surfaces

**Files:**
- Create: `app/member-commerce-center.tsx`
- Create: `app/admin-console.tsx`
- Modify: `app/account-contact-center.tsx`
- Modify: `app/page.tsx`
- Modify: `app/globals.css`
- Test: `tests/commerce-ui-contract.test.mjs`

**Interfaces:**
- `MemberCommerceCenter({ locale })` owns member registration, session refresh, checkout selection, and hash submission.
- `AdminConsole({ locale })` owns admin login and order review/decision UX.

- [x] **Step 1: Write failing UI contract tests for both QR networks, transaction hash submission, admin approval, and server balance retrieval.**
- [x] **Step 2: Run focused tests; expect failure before components exist.**
- [x] **Step 3: Implement the member checkout screen, including copy address, QR display, exact network warning, package picker, and pending order history.**
- [x] **Step 4: Implement the admin console and attach it to `#admin`.**
- [x] **Step 5: Add responsive styles and run focused tests.**

### Task 4: Gate interpretations by server-backed credits and add modes

**Files:**
- Modify: `app/interpretation-panel.tsx`
- Create: `app/interpretation-modes.ts`
- Test: `tests/interpretation-credit-flow.test.mjs`

**Interfaces:**
- `InterpretationPanel` reads session balance from `/api/member/me` and reserves credits using `/api/member/spend` before response generation.
- Provides `structured` and `conversation` modes without claiming a remote AI response until an API key is later added.

- [x] **Step 1: Write failing tests for server debit request and both modes.**
- [x] **Step 2: Run focused test; expect failure.**
- [x] **Step 3: Implement API debit integration, error handling, and per-tool conversation starter prompts.**
- [x] **Step 4: Run focused test; expect pass.**

### Task 5: Build, provision, migrate, deploy, and verify

**Files:**
- Modify only if deployment verification exposes a defect.

- [x] **Step 1: Run `pnpm test && pnpm lint && pnpm build`.**
- [x] **Step 2: Run `wrangler whoami`, create a dedicated D1 database, and set its Worker binding.**
- [x] **Step 3: Apply `migrations/0001_commerce_core.sql` with `wrangler d1 migrations apply <db> --remote`.**
- [x] **Step 4: Set administrator email, administrator password, and session secret as Worker secrets without logging them.**
- [x] **Step 5: Deploy and verify the public membership flow, rejected unauthenticated admin route, and administrator sign-in.**
