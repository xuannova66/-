# Seven-Language Completeness Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Remove untranslated or mixed-language interface copy from every supported locale.

**Architecture:** Existing locale records remain the source of truth for authored copy. Component-specific strings are placed in exhaustive locale records, and existing chart label resolvers retain responsibility for generated calculation labels. Tests validate locale-map completeness and rendered language isolation.

**Tech Stack:** React 19, TypeScript, Node test runner, tsx, vinext.

## Global Constraints

- Support exactly `en`, `zh-Hans`, `zh-Hant`, `ja`, `ko`, `vi`, and `th` in this pass.
- Preserve proper names, user-entered values, dates, celestial stems and branches, source titles, and payment addresses.
- Do not expose credentials or alter server-side commerce data.

---

### Task 1: Identify and test remaining mixed-language UI copy

**Files:**
- Modify: `tests/locale-copy.test.mjs`
- Inspect: `app/site-content.ts`, `app/ui-copy.ts`, `app/account-contact-center.tsx`, `app/member-commerce-center.tsx`, `app/interpretation-panel.tsx`, `app/complete-chart-board.tsx`

**Interfaces:**
- Consumes: `Locale` and every locale-aware UI copy map.
- Produces: regression assertions for exhaustive seven-language user-facing copy.

- [ ] **Step 1: Add failing assertions for all language maps and known leaked labels**

```js
for (const locale of locales) assert.ok(copy[locale]);
assert.doesNotMatch(nonEnglishHtml, /Sign in|Credits|AI interpretation/);
```

- [ ] **Step 2: Run locale tests before edits**

Run: `pnpm exec tsx --test tests/locale-copy.test.mjs`

Expected: existing untranslated component labels or incomplete mappings are reported.

### Task 2: Complete authored interface copy

**Files:**
- Modify: affected `app/*.tsx` copy maps and locale helpers identified by Task 1.
- Test: `tests/locale-copy.test.mjs`, `tests/rendered-html.test.mjs`

**Interfaces:**
- Consumes: `Locale` selected by the visitor.
- Produces: localized labels, notices, errors, actions, placeholders, and helper text for all seven languages.

- [ ] **Step 1: Add every missing locale entry and replace direct visible literals**

```ts
const copy: Record<Locale, { label: string }> = {
  en: { label: "..." },
  "zh-Hans": { label: "..." },
  "zh-Hant": { label: "..." },
  ja: { label: "..." },
  ko: { label: "..." },
  vi: { label: "..." },
  th: { label: "..." },
};
```

- [ ] **Step 2: Run focused locale and rendering tests**

Run: `pnpm exec tsx --test tests/locale-copy.test.mjs && node --test tests/rendered-html.test.mjs`

Expected: all localized copy tests pass.

### Task 3: Release and verify

**Files:**
- Modify: generated `dist/` output only through the build command.

- [ ] **Step 1: Run complete validation**

Run: `pnpm test && pnpm run lint`

Expected: the production build succeeds, all tests pass, and lint has no errors.

- [ ] **Step 2: Deploy the existing Worker**

Run: `pnpm exec wrangler deploy --config dist/server/wrangler.json --name xuanyuan-institute-preview`

Expected: deployment reports a new Worker version.
