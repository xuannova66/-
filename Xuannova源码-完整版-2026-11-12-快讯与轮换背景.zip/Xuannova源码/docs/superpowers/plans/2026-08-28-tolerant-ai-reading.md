# Tolerant AI Reading Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Let every non-empty interpretation question reach the AI and render any meaningful provider response.

**Architecture:** The browser and Worker both treat only whitespace-only input as invalid. The DeepSeek adapter converts structured JSON, minimal JSON, or plain text into the app's stable `InterpretationReading` shape so the existing UI can render it without changing its response contract.

**Tech Stack:** React 19, TypeScript, Cloudflare Workers, Node test runner, tsx.

## Global Constraints

- Keep API credentials server-only and do not log provider responses.
- Do not deduct credits until a usable AI reading exists.
- Retain the existing non-deterministic cultural-study and high-stakes safety constraints.

---

### Task 1: Accept non-empty questions

**Files:**
- Modify: `worker/commerce-api.ts:670-690`
- Modify: `app/interpretation-panel.tsx:35-100`
- Test: `tests/commerce-api.test.mjs`
- Test: `tests/interpretation-credit-flow.test.mjs`

**Interfaces:**
- Consumes: `QUESTION_REQUIRED` error contract from `/api/interpretations`.
- Produces: a request for every trimmed question whose length is at least one.

- [ ] **Step 1: Write the failing tests**

```js
const body = interpretationBody();
body.question = "?";
assert.equal(response?.status, 200);
assert.match(panel, /question\.trim\(\)\.length === 0/);
```

- [ ] **Step 2: Verify tests fail before the implementation**

Run: `pnpm exec tsx --test tests/commerce-api.test.mjs tests/interpretation-credit-flow.test.mjs`

Expected: the one-character question is rejected by the existing two-character validation.

- [ ] **Step 3: Implement the minimal validation change**

```ts
if (!compactText(payload?.question, 1_000)) {
  return json({ error: "Enter a question before requesting an interpretation", code: "QUESTION_REQUIRED" }, { status: 400 });
}
```

Use the matching `question.trim().length === 0` condition in the client-side disabled state and submit guard.

- [ ] **Step 4: Verify the focused tests pass**

Run: `pnpm exec tsx --test tests/commerce-api.test.mjs tests/interpretation-credit-flow.test.mjs`

Expected: all focused tests pass.

### Task 2: Normalize meaningful provider output

**Files:**
- Modify: `worker/deepseek.ts:50-95`
- Test: `tests/deepseek-api.test.mjs`

**Interfaces:**
- Consumes: DeepSeek `message.content` as a string.
- Produces: `InterpretationReading` with a non-empty summary whenever the provider content is meaningful.

- [ ] **Step 1: Write failing parser tests**

```js
assert.equal(deepseek.parseInterpretationResponse('{"answer":"A concise reply."}').summary, "A concise reply.");
assert.equal(deepseek.parseInterpretationResponse('A plain provider reply.').summary, "A plain provider reply.");
```

- [ ] **Step 2: Verify the parser tests fail before implementation**

Run: `pnpm exec tsx --test tests/deepseek-api.test.mjs`

Expected: the existing parser rejects missing required JSON fields and plain text.

- [ ] **Step 3: Implement normalization**

```ts
const answer = text(record?.summary ?? record?.answer ?? record?.content ?? record?.message, 8_000);
if (answer) return { title: text(record?.title, 120) || "AI", summary: answer, sections, followUps };
```

When JSON parsing fails, use the non-empty trimmed response as the summary; only reject blank content.

- [ ] **Step 4: Verify the focused parser tests pass**

Run: `pnpm exec tsx --test tests/deepseek-api.test.mjs`

Expected: every DeepSeek test passes.

### Task 3: Verify and release

**Files:**
- Modify: generated `dist/` output only through the build command.

- [ ] **Step 1: Run the complete validation suite**

Run: `pnpm test && pnpm run lint`

Expected: production build succeeds, all tests pass, and lint has no errors.

- [ ] **Step 2: Deploy to the existing Worker**

Run: `pnpm exec wrangler deploy --config dist/server/wrangler.json --name xuanyuan-institute-preview`

Expected: the Worker reports a new deployed version.

- [ ] **Step 3: Test the deployed endpoint with a temporary member**

Run a registered temporary account with credits through `/api/interpretations` using a one-character question and a minimal provider response fixture.

Expected: HTTP 200 with a non-empty `response.summary`, then remove the temporary member and ledger rows.
