# DeepSeek Interpretation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Return a live, localized DeepSeek interpretation for a signed-in member’s generated chart without exposing the API key or charging for failed provider calls.

**Architecture:** The browser posts its selected language, reading mode, question, tool, and complete generated chart to a same-origin Worker endpoint. The Worker validates the signed session and available credits, calls DeepSeek from the server, validates its JSON response, then records the debit only after a successful response. The client renders the returned structured reading and server-authoritative balance.

**Tech Stack:** React/Vinext, Cloudflare Worker and D1, DeepSeek Chat Completions API, Node test runner.

## Global Constraints

- Keep `DEEPSEEK_API_KEY` only in a Cloudflare Worker secret; never put it in client code, source files, test fixtures, output, or logs.
- Use DeepSeek’s server-side `/chat/completions` JSON-object response mode with a configurable model that defaults to `deepseek-v4-flash`.
- Enforce same-origin, signed member session, input-size limits, and the existing 50/300-credit policy before returning a reading.
- Do not expose provider response bodies or API credentials in errors; do not debit a member if DeepSeek cannot return a valid reading.
- Preserve all seven supported UI languages and request the selected response language.

---

### Task 1: Define and test the DeepSeek adapter

**Files:**
- Create: `worker/deepseek.ts`
- Create: `tests/deepseek-api.test.mjs`

**Interfaces:**
- Produces: `buildInterpretationMessages(request, mode)` and `requestDeepSeekInterpretation(request, mode, apiKey, model, fetchImpl?)`.
- Returns: `{ title: string; summary: string; sections: Array<{ title: string; text: string }>; followUps: string[] }`.

- [ ] **Step 1: Write failing adapter tests**

```js
assert.match(messages[0].content, /JSON/);
assert.match(messages[1].content, /career question/);
assert.deepEqual(parseInterpretationResponse(JSON.stringify(validResponse)), validResponse);
assert.throws(() => parseInterpretationResponse("not json"));
```

- [ ] **Step 2: Run the focused test and verify it fails**

Run: `pnpm exec tsx --test tests/deepseek-api.test.mjs`

Expected: FAIL because `worker/deepseek.ts` does not exist.

- [ ] **Step 3: Implement the adapter**

```ts
const response = await fetchImpl("https://api.deepseek.com/chat/completions", {
  method: "POST",
  headers: { authorization: `Bearer ${apiKey}`, "content-type": "application/json" },
  body: JSON.stringify({ model, messages, response_format: { type: "json_object" }, thinking: { type: "disabled" } }),
});
```

Validate the message is bounded JSON and contains only non-empty title, summary, section and follow-up strings.

- [ ] **Step 4: Run the focused test and verify it passes**

Run: `pnpm exec tsx --test tests/deepseek-api.test.mjs`

Expected: PASS.

### Task 2: Add the authenticated, credit-backed Worker route

**Files:**
- Modify: `worker/commerce-api.ts`
- Modify: `worker/index.ts`
- Modify: `tests/commerce-api.test.mjs`

**Interfaces:**
- Consumes: `requestDeepSeekInterpretation` from `worker/deepseek.ts`.
- Produces: `POST /api/interpretations` returning `{ response, cost, member }`.

- [ ] **Step 1: Write failing route tests**

```js
const response = await api.handleCommerceApi(new Request("https://preview.example/api/interpretations", { method: "POST" }), env);
assert.equal(response.status, 401);
assert.match(source, /url.pathname === "\/api\/interpretations"/);
```

- [ ] **Step 2: Run the focused test and verify it fails**

Run: `pnpm exec tsx --test tests/commerce-api.test.mjs`

Expected: FAIL because the route does not exist.

- [ ] **Step 3: Implement validation, provider call, and conditional debit**

```ts
if (member.credits < cost) return error("Insufficient credits", 402);
const response = await requestDeepSeekInterpretation(request, mode, env.DEEPSEEK_API_KEY, env.DEEPSEEK_MODEL);
const debit = await db.prepare("UPDATE members SET credits = credits - ? WHERE id = ? AND credits >= ?").bind(cost, member.id, cost).run();
```

Only insert the credit ledger and return the provider output when the conditional debit succeeds. Map provider configuration, timeout, and response errors to safe HTTP messages.

- [ ] **Step 4: Run the focused test and verify it passes**

Run: `pnpm exec tsx --test tests/commerce-api.test.mjs`

Expected: PASS.

### Task 3: Connect the reading screen to the live route

**Files:**
- Modify: `app/interpretation-panel.tsx`
- Modify: `tests/interpretation-credit-flow.test.mjs`

**Interfaces:**
- Consumes: `POST /api/interpretations` result `{ response, member: { balance } }`.
- Produces: a server-backed interpretation screen that displays the selected structured or conversation presentation.

- [ ] **Step 1: Write failing source-flow assertions**

```js
assert.match(panel, /fetch\("\/api\/interpretations"/);
assert.match(panel, /mode, chart: request\.chart/);
assert.doesNotMatch(panel, /createLocalInterpretation\(request\)/);
```

- [ ] **Step 2: Run the focused test and verify it fails**

Run: `pnpm exec tsx --test tests/interpretation-credit-flow.test.mjs`

Expected: FAIL because the panel still calls the debit-only route and local adapter.

- [ ] **Step 3: Implement the client call and localized copy**

```ts
const result = await fetch("/api/interpretations", { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify({ tool: chart.tool, locale, question, mode, chart: request.chart }) });
```

Render only a successful validated server result, update the displayed balance, and keep all copy in the current selected language.

- [ ] **Step 4: Run the focused test and verify it passes**

Run: `pnpm exec tsx --test tests/interpretation-credit-flow.test.mjs`

Expected: PASS.

### Task 4: Verify, deploy, and configure the secret

**Files:**
- Modify: `README.md` only if a deployment configuration section does not already document Worker secrets.

- [ ] **Step 1: Run all verification**

Run: `pnpm test && pnpm run lint && pnpm run build`

Expected: all tests and build pass; lint has no errors.

- [ ] **Step 2: Deploy the Worker**

Run: `pnpm exec wrangler deploy --config dist/server/wrangler.json`

Expected: a new `xuanyuan-institute-preview.workers.dev` version is reported.

- [ ] **Step 3: Set the secret without exposing it to source control**

Run: `pnpm exec wrangler secret put DEEPSEEK_API_KEY --name xuanyuan-institute-preview --config dist/server/wrangler.json`

Expected: Wrangler prompts privately for the key and confirms secret update. Do not paste the key into chat or a source file.
