# Original Feature Coverage Expansion Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans (recommended) to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add an original Daily Rhythm flow, discoverable method registry, per-method input contracts, and chart-to-library study-shelf links.

**Architecture:** Retain `study-suite.ts` as the route definition source and extend it with explicit metadata. `chart-model.ts` gains a dedicated daily builder that returns the existing `CompleteChart` contract. Existing React flow components consume the metadata rather than duplicating conditionals, while `library-catalogue.ts` remains the source of public source records.

**Tech Stack:** TypeScript, React 19, Vinext, Node test runner.

## Global Constraints

- Build an independent cultural-study product; do not copy Qingnang pages, copy, layout, assets, code, calculation logic, or proprietary payment mechanics.
- Preserve civil time, true-solar-time note, global place selection, the existing credit-gated reading flow, and the study disclaimer.
- Localize every new user-facing string into `en`, `zh-Hans`, `zh-Hant`, `ja`, `ko`, `vi`, and `th`.
- Use test-first red-green cycles for every code behavior change.

---

### Task 1: Define and test the route metadata contract

**Files:**
- Modify: `tests/method-completeness.test.mjs`
- Modify: `app/study-suite.ts`

**Interfaces:**
- Produces `studyRoutes` record `daily` with `form: "daily"`, `group: "rhythm"`, and `libraryCategory: "foundation"`.
- Produces `getStudyRoute(route)` for safe route lookup.

- [ ] **Step 1: Write the failing test**

```js
const { getStudyRoute } = await import("../app/study-suite.ts");
const daily = getStudyRoute("daily");
assert.equal(daily?.form, "daily");
assert.equal(daily?.group, "rhythm");
assert.equal(daily?.libraryCategory, "foundation");
assert.equal(getStudyRoute("missing-route"), undefined);
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pnpm exec tsx --test tests/method-completeness.test.mjs`

Expected: FAIL because the `daily` route and `getStudyRoute` do not yet exist.

- [ ] **Step 3: Write minimal implementation**

Add `daily` to the study-route registry and export `getStudyRoute(route: StudyRoute)`. Expand the route type with a library category and use a narrow record lookup for the helper.

- [ ] **Step 4: Run test to verify it passes**

Run: `pnpm exec tsx --test tests/method-completeness.test.mjs`

Expected: PASS.

### Task 2: Build and test the Daily Rhythm chart model

**Files:**
- Modify: `tests/chart-engine.test.mjs`
- Modify: `app/chart-model.ts`

**Interfaces:**
- `createCompleteChart({ module: "daily", ...input })` returns a board named `Daily rhythm study field`.
- Its sections include `daily-calendar`, `solar-term-context`, `twelve-windows`, `elemental-climate`, and `grounded-sequence`.

- [ ] **Step 1: Write the failing test**

```js
const daily = createCompleteChart({ ...base, module: "daily" });
assert.equal(daily.board.label, "Daily rhythm study field");
for (const id of ["daily-calendar", "solar-term-context", "twelve-windows", "elemental-climate", "grounded-sequence"]) {
  assert.ok(daily.sections.some((section) => section.id === id));
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pnpm exec tsx --test tests/chart-engine.test.mjs`

Expected: FAIL because `daily` currently falls through to the generic comparison board.

- [ ] **Step 3: Write minimal implementation**

Create `dailyRhythmBoard(result)` using local calendar facts and deterministic symbolic rhythm data. Route `daily` to this builder and do not describe outcomes as auspicious, guaranteed, or predictive.

- [ ] **Step 4: Run test to verify it passes**

Run: `pnpm exec tsx --test tests/chart-engine.test.mjs`

Expected: PASS.

### Task 3: Surface the method index and study-shelf connection

**Files:**
- Modify: `tests/rendered-html.test.mjs`
- Modify: `app/study-navigation.ts`
- Modify: `app/page.tsx`
- Modify: `app/complete-chart-board.tsx`
- Modify: `app/ui-copy.ts`
- Modify: `app/globals.css`

**Interfaces:**
- The navigation renders an accessible `All study methods` control and includes the Daily Rhythm route.
- A complete chart renders an accessible `Study shelf` link associated with the active route's library category.

- [ ] **Step 1: Write the failing test**

```js
assert.match(html, /All study methods/);
assert.match(html, /Daily Rhythm/);
assert.match(html, /Study shelf/);
```

- [ ] **Step 2: Run test to verify it fails**

Run: `node --test tests/rendered-html.test.mjs`

Expected: FAIL because these controls are not rendered.

- [ ] **Step 3: Write minimal implementation**

Render grouped route records from the study registry in navigation, add route-specific form display rules in the page, and render a chart-level library anchor. Add seven-locale UI copy and responsive rules for the method index and shelf action.

- [ ] **Step 4: Run test to verify it passes**

Run: `node --test tests/rendered-html.test.mjs`

Expected: PASS.

### Task 4: Verify the expanded product path

**Files:**
- Modify only if verification reveals a defect.

- [ ] **Step 1: Run focused tests**

Run: `pnpm exec tsx --test tests/chart-engine.test.mjs tests/method-completeness.test.mjs && node --test tests/rendered-html.test.mjs`

Expected: PASS.

- [ ] **Step 2: Run full verification**

Run: `pnpm test && pnpm lint && pnpm build`

Expected: tests/build pass; lint may retain the existing image-performance warning but has no errors.

- [ ] **Step 3: Inspect the user flow locally**

Open the landing page, open All Study Methods, select Daily Rhythm, complete the date/place flow, generate the local chart, and verify the Daily Rhythm board and Study Shelf action are visible.

- [ ] **Step 4: Publish the verified preview**

Run: `pnpm exec wrangler whoami >/dev/null && pnpm exec wrangler deploy --config dist/server/wrangler.json --name xuanyuan-institute-preview`

Expected: deploy output includes the existing preview URL.

