# Tolerant AI Reading Design

## Goal

Accept every non-empty interpretation question and display a usable AI reading whenever the provider returns meaningful content.

## Design

The client accepts any non-whitespace question, including one-character questions, and sends it with the completed chart. The Worker repeats that validation and returns `QUESTION_REQUIRED` only for an empty value.

DeepSeek responses are normalized into the existing reading contract. A complete structured JSON result keeps its title, summary, sections, and follow-ups. A minimal JSON response with an `answer`, `content`, or `message` field becomes a reading. A non-empty plain-text response also becomes a reading instead of being rejected merely because it is not JSON.

The provider instruction continues to prohibit deterministic fate claims, guaranteed outcomes, and medical, legal, financial, or safety directives. This preserves an honest cultural-study experience while allowing ordinary questions to receive a response.

## Error Handling

An empty question stays on the page with a direct prompt and does not call the provider or consume credits. A blank provider response remains an error and is retried once; valid provider content is never discarded because optional headings, sections, or follow-up prompts are absent.

## Verification

Tests cover one-character question submission, minimal JSON normalization, and plain-text normalization. The full build, test suite, lint check, deployment, and a live provider request are run before completion.
