# Original Feature Coverage Expansion

## Goal

Make Xuanyuan Institute more complete as an independent, multilingual cultural-study product. The work uses only high-level, publicly observable product categories as a coverage benchmark; it does not reproduce Qingnang's pages, text, assets, source code, branded terminology, payment flow, or calculation logic.

## Public-category audit

The public categories observed on the referenced site include birth charts, paired profiles, question charts, combined views, a daily rhythm entry, utility tools, source reading, and account/credit flows. Xuanyuan already has independent routes for birth, paired, question, celestial, reflective, account, credits, and its reading library. The expansion fills four product-level gaps rather than copying another product:

1. A standalone Daily Rhythm route, derived from the user's selected calendar basis and place.
2. A tool index that makes every existing study method discoverable by family and route.
3. Per-method input contracts so a method can declare the facts it needs before entering the shared ritual and chart sequence.
4. Source shelves that join every primary tool to its existing original library records.

## Chosen design

### Daily Rhythm

Add a `daily` study route to the life-rhythm family. It accepts date, optional time, location, time-basis preference, and a short focus. Its chart is an independent local cultural-study layout with calendar anchors, solar-term context, a twelve-window rhythm strip, five-element climate, and a grounded reflection sequence. It must not state that it selects auspicious/inauspicious dates or guarantees a result.

### Method registry and discovery

Make the study-suite the single registry for every route. Each record declares its family, form type, visual type, and library category. The navigation can therefore provide a compact All Methods index without duplicating method names. This makes current tools reachable from a visible route index while preserving the existing major-category navigation.

### Input contracts

Add a method metadata map that declares which inputs are meaningful for each current tool family: birth profile, paired profile, inquiry, daily rhythm, or reflection. The existing shared form continues to carry locale, place, civil/true-solar choice, ritual flow, chart and reading. The UI only reveals extra inputs required by the active method, avoiding a generic form pretending every tool uses the same data.

### Source connection

Map each primary route to source-library categories already held in `library-catalogue.ts`. Show a compact "Study shelf" link after a chart is generated. It opens the existing source explorer filtered to the relevant category and never fabricates quotations or claims that the output is authoritative.

## Data and error behavior

- The daily route validates that a date exists before creating the local chart.
- Method registry lookups have a safe route-level fallback to prevent navigation failures.
- Date, place and time-basis remain visible in generated charts; a missing location retains civil-time behavior and displays an explicit no-location state.
- Readings remain cultural-study references with the existing disclaimer and credit controls.

## Localization and accessibility

- New route labels, form labels, validation copy, board labels and source-shelf labels must exist for English, Simplified Chinese, Traditional Chinese, Japanese, Korean, Vietnamese and Thai.
- New navigation controls must use named landmarks and accessible button/link labels.
- The daily chart and all-method index must remain usable at the existing mobile breakpoint.

## Verification

- Add failing-first tests for the daily chart's independent board/sections and the registry's route/category contract.
- Add a UI contract that verifies the new route is visible in the method index and that the generated chart exposes its library connection.
- Run the focused tests, full test suite, lint, production build, local-browser path check, and then update the existing preview deployment.

