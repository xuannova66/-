# Commerce Administration and Chart Hardening Design

## Purpose

Turn the existing public preview into a usable paid-study service: members can create a password-protected account, submit a USDT transaction hash after paying to the supplied TRC20 or BSC address, and receive credits only after an administrator approves the payment. Add an administrator console restricted to the supplied administrator email and a deployment secret, then make the existing chart and interpretation interface more explicit about calculation sources and supported reading modes.

## Confirmed inputs

- Administrator email: supplied by the owner in chat.
- Administrator password: supplied by the owner in chat; stored only as a Cloudflare Worker secret.
- Community destination: `https://t.me/xuannova3`.
- Payment methods: supplied TokenPocket QR images and the supplied TRC20 / BSC addresses.
- Credit packages: 9.9 U / 50, 30 U / 170, 50 U / 280, 100 U / 600.
- Interpretation pricing: 300 credits for `hecan`; 50 credits for every other tool.

## Architecture

Cloudflare D1 is the authoritative store for members, payment orders, credit ledger entries, and administrator audit events. The Worker intercepts same-origin `/api/*` requests before the app handler; it uses parameterized SQL only. Member passwords are salted and hashed with Web Crypto PBKDF2, sessions are HMAC-signed HttpOnly cookies, and the admin password plus signing key are Worker secrets.

The membership view becomes the checkout flow: register/sign in, select TRC20 or BSC, scan the matching supplied QR code, copy its address, provide the selected package and transaction hash, then see a pending review state. The admin screen uses the same secure cookie: it lists payment requests, verifies package/network/transaction information, and can approve exactly once, writing a positive ledger entry and updating the account balance atomically.

The chart layer remains a cultural-study interface rather than a fate or financial claim. Its deterministic data uses the existing MIT-licensed `lunar-javascript` for calendar/Four Pillars primitives, adds the MIT-licensed `iztro` engine for Zi Wei chart facts, and adds a separately tested MIT-licensed Qimen engine only if the package is installable and its APIs are verified. No commercial site code, private data, or undisclosed proprietary algorithms are copied.

## User journeys

### Member

1. Register an email and personal password, or sign in.
2. View server-backed credit balance and ledger.
3. Select an exact credit package and network.
4. Scan the network-specific QR/address and transfer the exact USDT amount.
5. Submit transaction hash. The order is `pending`; no credits are issued automatically.
6. After admin approval, refresh balance and generate a paid interpretation.

### Administrator

1. Open `#admin`, enter the approved email and supplied administrator password.
2. View pending, approved, and rejected orders with the package, network, transaction hash, member email, and timestamp.
3. Approve or reject an order. Approval adds credits once only and records both the credit ledger entry and audit event.
4. Sign out from the admin console.

## Security and failure rules

- QR images and public receiving addresses may be public; passwords, session signing keys, and deployment tokens never enter browser code or source control.
- API routes return 401 for missing/invalid sessions, 403 for non-admin sessions, 409 for duplicate registration/transaction hash or a non-pending order, and 400 for malformed inputs.
- An order only grants credits during explicit admin approval. Selecting a card, opening Telegram, or submitting a hash never grants a credit.
- The admin console is unavailable until deployment secrets are present.
- Account and payment state are server-backed; the prior browser-local wallet is only a preview fallback and does not represent paid balance.
- Exact parity with any commercial charting product is not claimed. Every calculation family is marked with its implemented source and test coverage.

## Scope staged for today

1. Production payment/admin core: D1 schema/migration, API, secure member/admin auth, checkout, payment review, server ledger, QR/Telegram configuration.
2. Interpretation product: "structured reading" and "conversation" tabs, per-tool prompts, reading history stored to the signed-in account.
3. Chart hardening: surface existing Four Pillars/Shen Sha/life-cycle data, add Zi Wei engine facts and life-timeline panels, and upgrade Qimen if the chosen open-source engine compiles and passes its published deterministic cases.
4. Every remaining method keeps its own standalone input, ritual, chart, and reading stages. Methods without a verified open-source computational engine remain clearly labelled as deterministic local reference boards rather than being misrepresented as authoritative calculation engines.
