# Seven-Language Completeness Design

## Goal

Make every visible website experience complete and natural in the seven supported interfaces: English, Simplified Chinese, Traditional Chinese, Japanese, Korean, Vietnamese, and Thai.

## Scope

The pass covers shared navigation, account and credit workflows, contact and administrator surfaces, tool input and ritual stages, chart and reading panels, error and empty states, generated chart labels, and library interactions. Static product names, calendar stems, branches, source titles, wallet addresses, and user-entered values remain unchanged.

## Design

Each user-facing component must select copy from an exhaustive `Record<Locale, ...>` or use the existing locale-aware label resolver. English fallback is allowed only for fixed proper names and source material, never for an actionable UI label, notice, error, title, or helper text in the six non-English interfaces.

The audit starts from visible React text nodes and string literals, then verifies locale maps have all seven keys and language switching does not leak application-interface text from another locale. Text is edited for native tone rather than mechanically translated word-for-word.

## Verification

Automated locale tests will require all seven locale maps to be exhaustive and reject known unlocalized UI text in every non-English interface. The complete test suite, build, lint, and responsive render checks run before deployment.
