# Professional BaZi and Zi Wei Chart Surfaces

## Goal

Replace the generic card-first presentation of the existing BaZi and Zi Wei outputs with two original, dense chart surfaces. The work improves information hierarchy and professional readability without copying another service's protected layout, visual assets, text, or code.

## BaZi surface

- Keep the existing independently calculated four-pillar data and expanded reference layers.
- Present the core chart as a columnar matrix: Year, Month, Day and Hour form the columns; symbolic fields form the rows.
- The visible core rows are heavenly stem, earthly branch, ten-god relation, hidden stems, NaYin, life stage and pillar shen-sha.
- Add an adjacent compact context block for solar/lunar date, civil or true-solar time, seasonal command, day master and element balance.
- Render luck-cycle and annual-cycle layers in a dense tabular band below the core matrix.

## Zi Wei surface

- Keep the existing independently generated twelve-palace data and detailed sections.
- Present twelve palace panels as a 4×4 perimeter grid with the four central slots combined into a single centre information well.
- Each palace panel exposes palace name, branch/stem, principal and supporting stars, transformation, minor star, condition, decade limit and annual reference.
- The centre well retains life/body anchor, bureau element, solar/lunar date and selected time basis.
- Keep detailed layers accessible below the main board instead of duplicating all fields in every palace.

## Shared interaction and localisation

- Preserve the input → ritual → chart → interpretation flow and the mobile two-column fallback.
- Keep all static labels mapped through the seven locale dictionaries; unknown English source text may not surface in a non-English interface.
- Do not present deterministic predictions or guaranteed outcomes.

## Testing

- Add contracts proving that BaZi uses the four-pillar matrix and Zi Wei uses a twelve-palace perimeter layout with a centre well.
- Confirm existing method-specific fields remain available and test both layouts in the renderer.
- Run the focused tests, full suite, lint and production build before publishing.
