# Mobile Layout and Localization Design

## Goal

Make the seven published interfaces—English, Simplified Chinese, Traditional Chinese, Japanese, Korean, Vietnamese, and Thai—fully legible and usable on phone-sized screens without untranslated visible interface copy.

## Responsive layout

- Treat 360–430px as the primary phone range and 651–860px as a compact tablet range.
- Keep the language control and menu trigger visible in the header; move route actions into the mobile menu.
- Stack route headings, forms, wallet/account sections, package controls, contact cards, library records, and admin controls into one-column flows.
- Preserve dense BaZi and Zi Wei data rather than hiding it. Their chart areas may scroll horizontally within a labelled board viewport while the page itself must not create horizontal overflow.
- Use touch-friendly controls, compact metadata, wrapped labels, and breakable addresses/hashes in account and payment areas.

## Localization

- Use the existing seven `Locale` keys as the complete publishing set.
- Localize every user-facing static label, status, CTA, placeholder, and generated chart label through locale records or existing board-term mapping.
- Keep proper nouns, traditional chart characters, URLs, payment networks, and user-entered values unchanged; these are data, not fallback UI copy.
- Add source-level regression tests for the mobile protections and for locale records that make a missing published-language value fail CI.

## Validation

- Test-first: add the responsive/localization contract before production changes and verify it fails.
- Run focused locale/layout tests, the complete test suite, type/build, and lint.
- Inspect the live page at phone and desktop widths in English and non-Latin interface languages, checking header, a dense chart route, membership, and owner console.
