# Dodo Payments 对接与审核清单（2026-11-02）

代码已经接好：在“购买积分”页加了银行卡支付，走 Dodo 的托管收银台。公司注册好、Dodo 审核通过后，只需填写环境变量，不用改代码。

**边界**：USDT 链上支付、钱包登录、合约都没动。Dodo 只用于积分套餐，不用于器物坊。

---

## 一、技术对接（已完成）

| 环节 | 做法 | 位置 |
|---|---|---|
| 创建支付 | 用户点“银行卡支付” → 服务器调用 Dodo `POST /checkouts`，带上套餐对应的产品、用户邮箱、返回地址、订单号 → 跳转到 Dodo 收银台 | `worker/dodo.ts`、`/api/payments/dodo/checkout` |
| 付款后返回 | 回到 `/credits?dodo_order=…`，页面自动轮询订单状态，到账后提示 | `app/member-commerce-center.tsx` |
| 到账 | 只认 Dodo 的 Webhook，不认浏览器返回 | `/api/payments/dodo/webhook` |
| Webhook 安全 | ① 按 Standard Webhooks 规则校验签名（HMAC-SHA256），超过 5 分钟的拒收<br>② 同一事件 ID 只处理一次（防重放）<br>③ 加积分前再向 Dodo `GET /payments/{id}` 读一次，确认金额、状态和订单号对得上 | `worker/commerce-api.ts` |
| 处理的事件 | `payment.succeeded` 加积分（只加一次）；`payment.failed`、`payment.cancelled` 标记失败；`refund.succeeded` 扣回积分 | 同上 |
| 邀请奖励 | 银行卡首单和 USDT 首单一样只奖励一次 | 同上 |
| 数据表 | `dodo_orders`、`dodo_webhook_events`、`dodo_invitation_rewards`（迁移 `0013_dodo_payments.sql`） | `migrations/` |
| 测试 | 集成测试：正常付款加分一次；伪造签名、重放、金额不符都不加分；退款扣回 | `tests/reading-credit-integration.test.mjs` |

**没填 Dodo 配置时**：银行卡按钮不显示，网站其他功能照常。

---

## 二、上线步骤（等公司注册好后）

1. **注册 Dodo 账户**，用公司身份提交审核（见第三节材料）。
2. 审核期间先用 **测试模式**：
   - 在 Dodo 后台（Test Mode）建 4 个“一次性付款”产品，价格与网站一致：

     | 网站套餐 ID | 名称建议 | 价格 |
     |---|---|---|
     | `seed` | Starter reading pack（20 credits） | US$4.99 |
     | `path` | Popular reading pack（50 credits） | US$9.90 |
     | `ritual` | Large reading pack（120 credits） | US$19.90 |
     | `synthesis` | Premium reading pack（280 credits） | US$39.90 |

     产品名建议写成“解读包 / reading pack”，不要写成“代币”“充值”“储值”。原因见第四节第 3 条。
   - 在 Dodo 后台 → Developer → Webhooks 添加地址 `https://xuannova.com/api/payments/dodo/webhook`。
   - 勾选事件：`payment.succeeded`、`payment.failed`、`payment.cancelled`、`refund.succeeded`。
   - 把 Webhook 签名密钥（`whsec_…`）和 API Key 填进服务器的 `/etc/xuanyuan/xuanyuan.env`：
     ```
     DODO_API_KEY=（测试模式的 key）
     DODO_WEBHOOK_SECRET=whsec_…
     DODO_ENVIRONMENT=test
     DODO_PRODUCTS={"seed":"pdt_…","path":"pdt_…","ritual":"pdt_…","synthesis":"pdt_…"}
     ```
   - 重启服务：`sudo systemctl restart xuanyuan`。
   - 用 Dodo 提供的测试卡买一个套餐，确认积分到账、积分记录里有一条。
3. **审核通过后切正式**：
   - 在 Live Mode 重新建 4 个产品和 Webhook（测试和正式的 ID、密钥不通用）。
   - 换成正式的 key、密钥和产品 ID，把 `DODO_ENVIRONMENT` 改为 `live`，重启。
   - 用真卡买最小的套餐，确认到账，再在 Dodo 后台全额退款，确认积分被扣回。
4. **填公司信息**：`app/contact-config.ts` 里的 `legalEntity`，填公司名称和注册地址。三份政策页底部会自动显示。

> **密钥只填在服务器的环境变量里，不要写进代码，也不要发在聊天里。**

---

## 三、审核要准备的材料

依据 Dodo 文档“Verification Process”和“Merchant Acceptance Policy”。

| 材料 | 说明 | 状态 |
|---|---|---|
| 公司注册证明 | 公司注册号、注册证书（如 Certificate of Incorporation）；税号可选 | 待公司注册 |
| 董事和受益人身份证件 | 所有董事、持股或控制 10% 以上的人都要提供政府签发的证件，并做自拍活体检测（Persona）；拍证件不要翻拍屏幕或复印件，最多 3 次机会 | 运营准备 |
| 公司银行账户 | 户名必须与公司注册名称一致 | 运营准备 |
| 产品信息表 | 网址、一句话描述、类别、交付方式（数字、即时）、自动化程度、合规敏感点、对接方式、社媒链接 | 运营填写，可用下方建议文案 |
| 网站已上线且可访问 | 审核员会打开网站核对；网站内容必须与表格一致 | 部署后满足 |

**产品信息表建议文案**：
- 一句话描述：“Xuannova is a seven-language website for learning Eastern traditional culture. It offers free calculation tools (BaZi, Zi Wei, I Ching) and paid AI-generated study readings, for education and entertainment only.”
- 类别：Education / Entertainment (digital content)
- 交付方式：Digital, delivered instantly on the website (credits unlock AI-generated text readings)
- 自动化程度：Fully automated, with no manual one-to-one consulting
- 合规敏感点：Astrology-related content, presented as entertainment and cultural learning, with no predictions or guarantees

---

## 四、审核标准逐条核对

| # | Dodo 的要求 | 网站现状 | 状态 |
|---|---|---|---|
| 1 | 占星类属于“需审核”类别，条件是“仅供娱乐，不做断言或预测” | 页脚写明“全部内容为东方传统文化研习内容，供学习与娱乐参考”；每份解读末尾注明“传统文化研习内容”；服务条款保留完整说明（不构成命运预测、医疗建议或任何结果保证）。11 月 3 日按运营要求，首屏不再放免责句 | ✅ 已做；审核时把服务条款指给审核员 |
| 2 | 禁止宗教/灵性服务（灵性指导、付费祈福、仪式、信仰咨询） | 网站不卖祈福、法事、开光。本轮把加载动画的“起局仪式”改为“正在起局”（7 种语言）。旧的“spiritual seekers”等文案代码里还有，但页面上不显示 | ✅ 已做 |
| 3 | 储值、游戏币、礼品卡受限或禁止 | 服务条款写明（本轮补充，7 种语言）：积分没有现金价值，只能在本站使用，不能转让、转售或提现；套餐写成“N 积分，可解锁约 N/20 份完整解读”。**建议 Dodo 产品名写成“解读包”**（见第二节） | ✅ 已做；产品名由运营按建议填写 |
| 4 | 禁止加密货币相关业务（钱包、代币、交易所等） | 网站本身不卖加密产品，但同时接受 USDT 付款并支持钱包登录，“购买积分”页标题旁写着“BSC 链上 USDT”。**审核员可能对此有疑问** | ⚠️ 需决定，见下方说明 |
| 5 | 只支持数字商品，不支持实物 | 积分、解读、视频课都是数字内容。器物坊卖实物，只用 USDT 付款，不走 Dodo，并放在独立子域名 `shop.xuannova.com` | ✅ 已做；提交时说明器物坊不用 Dodo |
| 6 | 禁止人工一对一的咨询、教练服务 | 解读是自动生成的。“专属顾问”是免费客服，不收费 | ✅ 已做 |
| 7 | 不登录也能看到价格 | “购买积分”页未登录可见 4 个套餐的美元价格和积分数 | ✅ 已做（浏览器实测） |
| 8 | 服务条款、隐私政策、退款与取消政策，放在固定位置 | 页脚有三个链接，7 种语言；退款政策已写明银行卡付款的退款方式 | ✅ 已做 |
| 9 | 有人回复的客服联系方式 | 页脚有邮箱、Telegram、X、WhatsApp、LINE、KakaoTalk 图标；政策页底部写明客服邮箱 Xuannova66@gmail.com | ✅ 已做；需有人及时回复 |
| 10 | 网站内容与表格一致，网站可访问（不能全站要求登录） | 首页、工具、藏经阁、视频课程列表未登录都能打开 | ✅ 已做 |
| 11 | 显示公司名称和地址 | `legalEntity` 留空，政策页暂显示“Xuannova” | ⏳ 公司注册后填写 |
| 12 | 年龄要求 | 服务条款写明须年满 18 岁 | ✅ 已做 |
| 13 | 退款、拒付处理 | Dodo 退款后自动扣回对应积分（部分退款按比例）；如果用户已经用掉，只扣剩余部分，不会扣成负数，差额请运营在后台查看积分记录后处理 | ✅ 已做 |

### 关于第 4 条（USDT 和钱包），供你决定

Dodo 的政策写的是“不允许加密相关的业务（Crypto-related offerings）”。我们是把 USDT 当作付款方式之一，并没有卖加密产品，但审核员看到“钱包登录”和“BSC 链上 USDT”，可能会要求解释，甚至拒绝。可选做法：

- **A. 照现状提交**，在产品信息表里说明：“USDT 只是可选的付款方式，网站不出售、不兑换、不托管任何加密资产。”
- **B. 提交审核前隐藏 USDT 和钱包入口**，只是前端不显示，链上代码不动；审核通过后再决定是否恢复。

这一条会影响网站功能，你没确认之前我没有改。

---

## 五、资料来源

- Dodo 文档：Merchant Acceptance Policy（可接受与受限业务）
- Dodo 文档：Prohibited Business Categories
- Dodo 文档：Verification Process（审核材料、网站要求、常见驳回原因）
- Dodo 文档：Checkout Sessions、Webhooks（Standard Webhooks 签名规则）
