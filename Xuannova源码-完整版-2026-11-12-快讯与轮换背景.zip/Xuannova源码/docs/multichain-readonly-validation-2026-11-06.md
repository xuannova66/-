# 多链支付：首轮只读验证

这些是开发快照，不是代币身份、安全性、实际成交、充分流动性或上线批准。未发起授权、签名或真实转账；报价随区块和市场变化。BSC 所用 18 位代币是现有项目配置的 Binance-Peg USDC，不能与 Circle 原生 USDC 混同。

## BSC

区块 131955163；使用 PancakeSwap V2 路由，仅检查直连 USDC 和经 WBNB 的两跳路线。BNB、USDT、ASTER、LINK、XAUt、SHIB、CAKE、BTCB、WETH、USD1、XRP、ZEC、UNI、AAVE、SOL、DOGE、AAPLB、TSLAB、NVDAB、GOOGLB 在 4.99 和 39.90 USDC 两档各获得至少一条报价；链上返回的精度与草稿清单一致。USDC 为结算币，未执行兑换报价；WLFI 缺少地址。报价不保证交易能执行，不证明上述资产官方身份，也不证明不收转账税。

较大金额的单位成本与较小金额比较：WETH 约高 26.74%，ZEC 约高 9.24%，AAVE 约高 6.85%，SOL 约高 1.87%。这是两档报价之间的观察差异，不是相对公允市场价的精确价格影响；这些路线需要独立公允价格、深度和可执行性校验，不能直接启用。

现有 `UsdcCheckoutPrototype` 已在 BSC 本地分叉链以 4.99 USDC 目标分别模拟 BNB、USDC、USDT、ASTER 四种输入，四次均在本地模拟向收款方结算 4.99 USDC。测试使用模拟钱包、从本地分叉池中模拟取币，且为了兼容本地 VM 对手续费地址的代码做了本地替换；因此不能证明真实手续费钱包可收款，也不是主网交易、钱包端验收或对新多币种草稿合约的审核。

## Ethereum

区块 26353819；使用 Uniswap V2 Router02，仅检查直连 USDC 和经 WETH 两跳。ETH、WETH、WBTC、LINK、UNI、AAVE 在 4.99 和 39.90 USDC 两档各获得至少一条报价。WBTC 精度为 8，其他所查精度为 18。Circle 文档列出的 Ethereum 原生 USDC 为 `0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48`。未进行真实兑换、钱包支付或代币身份审核。

## Solana

finalized slot 465997854：SOL（对应包装币）9 位；RAY、JLP、USDC、USDT、PUMP 均为 6 位。前五项由传统 SPL Token 程序管理；PUMP 由 Token-2022 程序管理。现有直付验证草稿只支持传统 SPL，不能凭此开放 PUMP 支付。Circle 文档列出的 Solana USDC mint 与草稿一致。未进行 Solana 兑换报价或真实交易测试。

补充只读检查：在 finalized slot 466072415，向 Solana 主网 RPC 查询用户提供的收款钱包 `BzDaU6VKyMtN14QeVuCMva2SGmHLeeYy2GAAG9muJNq2` 持有的主网 USDC token accounts，返回空列表。该钱包当时没有查询到对应 USDC 收款代币账户；实际收款前需创建并复核代币账户及其资金承担方式，不能仅用钱包地址当作 SPL 代币账户。该结果是指定区块的快照，后续需重新检查；本次没有创建账户或转账。检查脚本为 `scripts/check-solana-recipient.draft.mjs`。

## TRON

公共节点只读返回 WTRX 和 USDT 合约 decimals 均为 6。该检查未独立确认节点网络、代币身份、TRX→USDT 兑换路线或真实付款；TRX 是原生资产，WTRX 不是原生 TRX。

## 尚未完成的上线条件

- 官方来源逐个核验代币身份及映射资产风险，确认 WLFI 地址。
- 校验各币税制、实际路由、报价可执行性、价格偏离、余额及钱包体验。
- 完成 Solana、TRON 兑换实现及核验，覆盖 Token-2022 能力边界。
- 完成新合约审查、真实测试网交易、多链入账和异常恢复；不得把本次只读报价视为支付成功验证。

## BSC 两个 V2 工厂同区块对照

区块 131963740，PancakeSwap V2 与 Uniswap V2，各检查直连 USDC 和经 WBNB 两跳；两个路由的 factory 链上返回值分别与两家官方文档一致。按相同输出比较输入数量，4.99 档 BNB 两家差约 3.43%、USDT 约 4.35%、CAKE 约 11.57%；39.90 档差异更大。ASTER 等多项在本次查询的 Uniswap V2 指定路径没有取得有效报价，原因可能是路径、深度或 RPC 错误，不能据此断定无市场。

因此不能把“两个 V2 池的即时报价平均值”直接当成可靠的独立市场价，也不能直接拿其相互差异作为公允价格偏差；较浅池自身的冲击成本会干扰判断。下一步需验证其他有深度的协议及报价口径，结合真实可执行价格、抗操纵的时间窗口、流动性门槛和代币税制，再决定能否执行 2% 规则。此项尚未接入线上。

参考：[Uniswap V2 部署](https://developers.uniswap.org/docs/protocols/v2/deployments)、[PancakeSwap V2 部署](https://developer.pancakeswap.finance/contracts/v2/addresses)、[Uniswap V2 预言机](https://developers.uniswap.org/docs/protocols/v2/concepts/oracles)。

参考：[Circle USDC 地址](https://developers.circle.com/stablecoins/usdc-contract-addresses)、[Uniswap V2 部署地址](https://developers.uniswap.org/docs/protocols/v2/deployments)、[TRON 只读合约调用](https://developers.tron.network/docs/trc20-contract-interaction)。
# BSC V2/V3 同区块补充观察

使用 `scripts/compare-bsc-v3.draft.mjs` 在 BSC 区块 131964502 只读对比 PancakeSwap V2 与 V3 直连 USDC 的 exact-output 报价，分别请求 4.99 和 39.90 USDC；V3 在存在的 0.01%、0.05%、0.25%、1% 费率池中选择输入最低的报价。价差以两者较低输入为分母：

| 输入币 | 4.99 USDC 差异 | 39.90 USDC 差异 | 观察 |
| --- | ---: | ---: | --- |
| BNB（WBNB） | 0.16% | 0.18% | 直连 V2/V3 均有报价 |
| USDT | 0.48% | 0.49% | 直连 V2/V3 均有报价 |
| CAKE | 0.15% | 0.71% | 直连 V2/V3 均有报价 |
| BTCB | 0.68% | 3.21% | 大套餐超过 2%，不可假定始终接近 |
| LINK | 不可比较 | 不可比较 | 本次直连调用未取得报价，不代表没有其他路径 |
| ASTER | 不可比较 | 不可比较 | 本次 V3 直连取得报价，V2 直连未取得报价 |

该比较仅是同一时刻的两个报价，并非独立公允价格、抗操纵预言机、交易模拟或代币无税证明；结果可能随区块改变。它只测直连，不覆盖中转路径，也没有验证以太坊、Solana 或 TRON。现有付款草稿执行的是 V2 路由，不能将 V3 的报价直接当作该合约可执行价格。链上价格保护仍需确定可靠参考与失败关闭策略，并进行实际链上联调和安全审计；未具备上线条件。

